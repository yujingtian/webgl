# 本文件用来处理打包测试


# 返回打包测试接口的规则
def getGroupTestList():
    global sGroupTestList
    sGroupTestList = []
    yzItem = {}
    yzItem['groupName'] = 'collector'
    yzItem['testpath'] = {
        '/api/collector/add': {
            'data': 'id,[ids]'
        },
        '/api/collector/get': [],
        '/api/collector/delete': []
    }
    sGroupTestList.append(yzItem)


# 返回格式化后的打包测试接口规则
def getFormatGroupTestMap():

    print(sGroupTestList)
    groupTestMap = {}
    sFunctionList = []
    for groupTest in sGroupTestList:
        testpathList = groupTest['testpath']
        for sFunctionNo in testpathList:
            if sFunctionNo not in sFunctionList:
                sFunctionList.append(sFunctionNo)
    groupTestMap['functionList'] = sFunctionList
    groupTestMap['data'] = sGroupTestList
    return groupTestMap


getGroupTestList()

if __name__ == "__main__":
    print(getFormatGroupTestMap())