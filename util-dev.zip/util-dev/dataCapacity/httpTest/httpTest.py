# 本文件用来处理http测试
from typing import List
import tools
import requests
import time
import json
import doExcel
import groupTest
from selenium import webdriver
from urllib import parse
from specilSucessRule import CheckSucessRule
from initTestData import InitRule, getSPecilIntefaceSucessRuleMap, getsPecilIntefaceRuleMap, getsPecilRuleMap

sPecilFiledMap = {}
sPecilRuleMap = {}
sPecilIntefaceRuleMap = {}
sPecilIntefaceSucessRuleMap = {}
unTestIntefaceList = []
swaggerIntefaceMap = {}

testResultList = []


# 获取driver的session
def getSession():
    global rRequests
    rRequests = requests.Session()
    rRequests.headers.clear()
    for cookie in driver.get_cookies():
        rRequests.cookies.set(cookie['name'], cookie['value'])


# cas认证
def Login(sUserID: str, sPwd: str, sbaseUrl: str, sPort: str):
    sUrl = 'http://10.20.23.181:8081/cas/login?service=http%3A%2F%2F' + sbaseUrl + '%3A' + sPort + '%2Fuser%2Flogin'
    global driver
    driver = webdriver.Chrome()
    driver.get(sUrl)
    time.sleep(1)
    # 输入用户名
    username = driver.find_element_by_id('username')
    username.send_keys(sUserID)
    # 输入密码
    password = driver.find_element_by_name('password')
    password.send_keys(sPwd)
    time.sleep(1)
    button = driver.find_element_by_id('submitBtn')
    button.click()
    time.sleep(1)


# 单独测试一个接口
def testOneInteface(sFunction: str, questType: str, inFiled: List,
                    sbaseUrl: str, sPort: str, sGroupName: str):
    yzIntefaceResult = {}
    yzIntefaceResult['function'] = sFunction
    yzIntefaceResult['questType'] = questType

    isSecuss = False
    resultText = ''
    params = {}
    data = {}
    if questType == 'get':
        sDict = params
        for inFiledItem in inFiled:
            sFiledName = inFiledItem['filedName']
            sFiledType = inFiledItem['filedDocType']

            # 检查功能是否是打包测试的功能
            isFind = False
            if sGroupName.strip() != '':
                if sFiledName in sPecilFiledMap[sGroupName]:
                    params[sFiledName] = sPecilFiledMap[sGroupName][sFiledName]
                    isFind = True
                    continue

            # 检查功能是否存在规则
            if not isFind:
                if sFunction in sPecilIntefaceRuleMap:
                    # 遍历所有规则参数的字段，检查是否存在目前要赋值的字段,存在的情况下只取第一条
                    for ruleValueList in sPecilIntefaceRuleMap[sFunction]:
                        if sFiledName in sPecilFiledMap[ruleValueList]:
                            params[sFiledName] = sPecilFiledMap[ruleValueList][
                                sFiledName]
                            break

        res = rRequests.get('http://' + sbaseUrl + ':' + sPort + sFunction,
                            params=params,
                            data=data)
    else:
        sDict = data
        for inFiledItem in inFiled:
            sFiledName = inFiledItem['filedName']
            sFiledType = inFiledItem['filedDocType']

            # 检查功能是否是打包测试的功能
            isFind = False
            if sGroupName.strip() != '':
                if sFiledName in sPecilFiledMap[sGroupName]:
                    data[sFiledName] = sPecilFiledMap[sGroupName][sFiledName]
                    isFind = True
                    continue

            # 检查功能是否存在规则
            if not isFind:
                if sFunction in sPecilIntefaceRuleMap:
                    # 遍历所有规则参数的字段，检查是否存在目前要赋值的字段,存在的情况下只取第一条
                    for ruleValueList in sPecilIntefaceRuleMap[sFunction]:
                        if ruleValueList in sPecilFiledMap:
                            if sFiledName in sPecilFiledMap[ruleValueList]:
                                data[sFiledName] = sPecilFiledMap[
                                    ruleValueList][sFiledName]
                                break

        res = rRequests.post('http://' + sbaseUrl + ':' + sPort + sFunction,
                             params=params,
                             json=data)
    print(res.status_code)
    json_response = res.content.decode()
    dict_json = json.loads(json_response)
    print(sFunction)
    if res.status_code != 200:
        print(sFunction + '测试失败：', end='')
        isSecuss = False
        print(res.text)
        resultText = res.text
    elif 'success' in dict_json:
        if str(dict_json['success']) == 'True':
            # 如果存在特殊校验规则的需要支持特殊校验规则
            if sFunction in sPecilIntefaceSucessRuleMap:
                SucessRuleList = sPecilIntefaceSucessRuleMap[sFunction]
                sucessFlag = True
                for SucessRule in SucessRuleList:
                    tmpSucessFlag, sFailMsg = CheckSucessRule(
                        SucessRule, sDict)
                    if not tmpSucessFlag:
                        sucessFlag = False
                        break
                if sucessFlag:
                    print(sFunction + '测试成功')
                    isSecuss = True
                    resultText = str(dict_json)
                    # print(dict_json)
                else:
                    print(sFunction + '测试失败：', end='')
                    isSecuss = False
                    print(sFailMsg)
                    resultText = sFailMsg
            else:
                print(sFunction + '测试成功')
                isSecuss = True
                # print(dict_json)
                resultText = str(dict_json)
        else:
            print(sFunction + '测试失败：', end='')
            isSecuss = False
            print(res.text)
            resultText = res.text
    else:
        print(sFunction + '测试成功(没有success)：', end='')
        isSecuss = True
        # print(dict_json)
        resultText = str(dict_json)
    print('params:', end='')
    print(params)
    print('data:', end='')
    print(data)

    yzIntefaceResult['isSecuss'] = isSecuss
    yzIntefaceResult['resultText'] = resultText
    yzIntefaceResult['inData'] = str(sDict)
    testResultList.append(yzIntefaceResult)
    return dict_json


# 接口列表测试
def TestIntefaceMap(sbaseUrl: str, sPort: str, intefaceDict: dict,
                    isRealTest: bool):
    global testResultMap
    if isRealTest:
        #此处需要清空结果列表
        testResultList.clear()
    for sFunction in intefaceDict:
        if sFunction in unTestIntefaceList:
            continue
        print(sFunction)
        questType = intefaceDict[sFunction]['REQUEST_METHOD']
        inFiled = intefaceDict[sFunction]['inFiled']
        testOneInteface(sFunction, questType, inFiled, sbaseUrl, sPort, '')


# 打包接口测试
def GroupTest(groupTestMap: map, groupName: str):
    functionList = groupTestMap['functionList']
    for groupItem in groupTestMap['data']:
        sGroupName = groupItem['groupName']
        # 打包测试包名为空表示执行不受限制，不为空表示只执行指定包名的测试
        if sGroupName == groupName or groupName.strip() == '':
            sTestPathList = groupItem['testpath']
            if sGroupName not in sPecilFiledMap:
                sPecilFiledMap[sGroupName] = {}
            for sFunction in sTestPathList:
                print(swaggerIntefaceMap[sFunction]['inFiled'])
                resultJson = testOneInteface(
                    sFunction=sFunction,
                    questType=swaggerIntefaceMap[sFunction]['REQUEST_METHOD'],
                    inFiled=swaggerIntefaceMap[sFunction]['inFiled'],
                    sbaseUrl=sBaseUrl,
                    sPort=sPort,
                    sGroupName=sGroupName)
                sOutFiledRuleMap = sTestPathList[sFunction]
                for sOutField in sOutFiledRuleMap:
                    sValue = resultJson[sOutField]
                    sNewFiledList = str(sOutFiledRuleMap[sOutField]).split(',')
                    for sNewFiled in sNewFiledList:
                        if '[' in sNewFiled:
                            sNewFiled = sNewFiled.replace('[',
                                                          '').replace(']', '')
                            sPecilFiledMap[sGroupName][sNewFiled] = [sValue]
                        else:
                            sPecilFiledMap[sGroupName][sNewFiled] = sValue


# 初始化
def initdata():
    global swaggerIntefaceMap, sPecilRuleMap, sPecilFiledMap, sPecilIntefaceSucessRuleMap, sPecilIntefaceRuleMap
    swaggerIntefaceMap = tools.LoadDict('swaggerInteface')

    sPecilRuleMap = getsPecilRuleMap()
    sPecilFiledMap = InitRule(sPecilRuleMap, sPecilFiledMap)
    sPecilIntefaceSucessRuleMap = getSPecilIntefaceSucessRuleMap()
    sPecilIntefaceRuleMap = getsPecilIntefaceRuleMap()


if __name__ == "__main__":
    # 需测试待修复
    unTestIntefaceList.append('/api/monitor/add')
    unTestIntefaceList.append('/api/monitor/delete')

    # 无需测试
    unTestIntefaceList.append('/api/monitor/batchExportMonitor')
    unTestIntefaceList.append('/api/monitor/batchImportMonitorConfig')
    unTestIntefaceList.append('/api/systemConfig/batchExportBizConfig')
    unTestIntefaceList.append('/api/systemConfig/batchExportSystemConfig')
    unTestIntefaceList.append('/api/systemConfig/batchImportAlarmChannel')
    unTestIntefaceList.append('/api/systemConfig/batchImportBizConfig')
    unTestIntefaceList.append('/api/systemConfig/batchImportSystemConfig')
    unTestIntefaceList.append('/api/systemConfig/batchExportAlarmChannel')
    unTestIntefaceList.append('/api/systemConfig/batchExportAuditLog')

    initdata()

    sBaseUrl = '10.20.144.93'
    sPort = '17100'
    # sBaseUrl = '192.168.170.93'
    # sPort = '8888'
    Login(sUserID='admin',
          sPwd='hundsun0A!',
          sbaseUrl='10.20.144.93',
          sPort='17100')
    getSession()
    driver.close()

    moreTestType = 2
    # 全接口测试
    if moreTestType == 0:
        # 第一次创建测试数据
        TestIntefaceMap(sbaseUrl='10.20.144.93',
                        sPort='17100',
                        intefaceDict=swaggerIntefaceMap,
                        isRealTest=False)
        # 第二次开始测试接口
        TestIntefaceMap(sbaseUrl='10.20.144.93',
                        sPort='17100',
                        intefaceDict=swaggerIntefaceMap,
                        isRealTest=True)
        doExcel.SaveIntefaceTestResult(testResultList, unTestIntefaceList)
    # 单接口测试
    elif moreTestType == 1:
        sFunction = '/api/collector/delete'
        print(swaggerIntefaceMap[sFunction]['inFiled'])
        testOneInteface(
            sFunction=sFunction,
            questType=swaggerIntefaceMap[sFunction]['REQUEST_METHOD'],
            inFiled=swaggerIntefaceMap[sFunction]['inFiled'],
            sbaseUrl=sBaseUrl,
            sPort=sPort,
            sGroupName='')
    # 打包接口测试
    elif moreTestType == 2:
        groupTestMap = groupTest.getFormatGroupTestMap()
        GroupTest(groupTestMap, 'collector')
