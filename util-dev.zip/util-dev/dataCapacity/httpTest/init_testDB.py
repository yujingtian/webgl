# 本文件用来处理数据库资源


# 返回特殊取数规则
def getDBMap():
    sDBMap = {}
    sMySqlMap = {}
    sMySqlMap['181See'] = {
        'ip': '10.20.23.181',
        'port': '3306',
        'user': 'hs_bbm',
        'pwd': 'hundsun',
        'serName': 'hs_bbm'
    }

    sDBMap['MySql'] = sMySqlMap
    return sDBMap


if __name__ == "__main__":
    print(getDBMap())
