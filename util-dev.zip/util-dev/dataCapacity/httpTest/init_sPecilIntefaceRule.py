# 本文件用来处理接口取数的规则
sPecilIntefaceRuleMap = {}


# 返回接口取数的规则
def getsPecilIntefaceRuleMap():
    sPecilIntefaceRuleMap['/api/alarmAndGraph/listAlarmDetailDocuments'] = [
        'bbm_alarm_history'
    ]
    sPecilIntefaceRuleMap['/api/alarmAndGraph/closeAlarmRule'] = [
        'closeAlarmRule', 'bbm_alarm_history_for_closeAlarmRule'
    ]
    sPecilIntefaceRuleMap['/api/alarmAndGraph/enableAlarmRule'] = [
        'bbm_alarm_history_for_enableAlarmRule'
    ]
    sPecilIntefaceRuleMap['/api/alarmAndGraph/listAlarmHistory'] = [
        'bbm_alarm_history', 'pageQery'
    ]
    sPecilIntefaceRuleMap['/api/alarmAndGraph/getAlarmHistoryInfo'] = [
        'bbm_alarm_history'
    ]
    sPecilIntefaceRuleMap['/api/alarmAndGraph/listChildNode'] = [
        'listChildNode'
    ]
    sPecilIntefaceRuleMap['/api/alarmAndGraph/listGraphAndTableConfig'] = [
        'listGraphAndTableConfig'
    ]
    sPecilIntefaceRuleMap['/api/alarmAndGraph/listTableDataDocuments'] = [
        'listGraphAndTableConfig'
    ]
    sPecilIntefaceRuleMap['/api/alarmAndGraph/queryGraphData'] = [
        'listGraphAndTableConfig', 'pageQery', 'AlarmGraphCustomJson'
    ]
    sPecilIntefaceRuleMap['/api/alarmAndGraph/queryTableData'] = [
        'listGraphAndTableConfig', 'pageQery', 'AlarmGraphCustomJson'
    ]
    sPecilIntefaceRuleMap['/api/bizGroup/allocateBizMonitor'] = [
        'SimpleUserAndGroup', 'BizMonitorExtConfig', 'BizGroupConfig',
        'BizMonitorConfig', 'VoPermission', 'dateTime', 'topID', 'RandomMap'
    ]
    sPecilIntefaceRuleMap['/api/bizGroup/createGroup'] = [
        'SimpleUserAndGroup', 'BizGroupExtConfig', 'BizMonitorExtConfig',
        'dateTime', 'RandomMap', 'BizGroupConfig', 'topID'
    ]
    sPecilIntefaceRuleMap['/api/bizGroup/deleteBizGroup'] = ['deleteBizGroup']
    sPecilIntefaceRuleMap['/api/bizGroup/deleteBizMonitor'] = [
        'deleteBizMonitor'
    ]
    sPecilIntefaceRuleMap['/api/bizGroup/getBizGroupInfo'] = [
        'getBizGroupInfo'
    ]
    sPecilIntefaceRuleMap['/api/bizGroup/getBizMonitorInfo'] = [
        'getBizMonitorInfo'
    ]
    sPecilIntefaceRuleMap['/api/bizGroup/getCustomConfig'] = [
        'getCustomConfig'
    ]
    sPecilIntefaceRuleMap['/api/bizGroup/updateBizMonitor'] = [
        'updateBizMonitor'
    ]
    sPecilIntefaceRuleMap['/api/collector/add'] = [
        'collectorConfig', 'VoPermission', 'datetime', 'RandomMap'
    ]
    sPecilIntefaceRuleMap['/api/collector/delete'] = [
        'collectorDelete', 'collectorDelete_const'
    ]
    sPecilIntefaceRuleMap['/api/collector/get'] = ['collectorGet']
    sPecilIntefaceRuleMap['/api/collector/listCollectorHistory'] = [
        'collectorGet'
    ]
    sPecilIntefaceRuleMap['/api/collector/recoverCollector'] = [
        'collectorHisGet'
    ]
    sPecilIntefaceRuleMap['/api/collector/update'] = ['collector_update']
    sPecilIntefaceRuleMap['/api/historyVersion/getCollectorHistory'] = [
        'collectorHisGet'
    ]
    sPecilIntefaceRuleMap['/api/historyVersion/getMonitorHistory'] = [
        'MonitorHisGet'
    ]
    sPecilIntefaceRuleMap['/fire/startTask'] = ['startTask']
    sPecilIntefaceRuleMap['/api/systemConfig/systemLogDetail'] = [
        'systemLogDetail'
    ]
    sPecilIntefaceRuleMap['/api/systemConfig/getCronTaskLatestLog'] = [
        'taskEnum'
    ]
    sPecilIntefaceRuleMap['/api/systemConfig/closeDownGrade'] = [
        'DownGradeTrue'
    ]
    sPecilIntefaceRuleMap['/api/systemConfig/openDownGrade'] = [
        'DownGradeTrue'
    ]
    sPecilIntefaceRuleMap['/api/systemConfig/closeCronTask'] = ['TimingTask']
    sPecilIntefaceRuleMap['/api/systemConfig/openCronTask'] = ['TimingTask']
    sPecilIntefaceRuleMap['/api/systemConfig/oneAuditLogDetail'] = [
        'oneAuditLogDetail'
    ]
    sPecilIntefaceRuleMap['/api/systemConfig/manualFireCronTask'] = [
        'taskEnum'
    ]
    sPecilIntefaceRuleMap['/api/bizGroup/updateGroup'] = ['updateGroup']
    sPecilIntefaceRuleMap['/api/collector/list'] = ['pageQery']
    sPecilIntefaceRuleMap['/api/monitor/batchExportMonitor'] = [
        'batchExportMonitor'
    ]
    sPecilIntefaceRuleMap['/api/systemConfig/updateBizConfig'] = [
        'CUSTOMBizConfig', 'ConfigValue'
    ]
    sPecilIntefaceRuleMap['/api/systemConfig/updateSystemConfig'] = [
        'CUSTOMSystemConfig', 'ConfigValue'
    ]
    sPecilIntefaceRuleMap['/api/systemConfig/updateUserGroup'] = [
        'UserGroupCUSTOM', 'UserGroupCUSTOM_Value'
    ]
    sPecilIntefaceRuleMap['/api/monitor/get'] = ['monitor']
    sPecilIntefaceRuleMap['/api/monitor/listMonitorHistory'] = [
        'MonitorHisGet', 'pageQery'
    ]
    sPecilIntefaceRuleMap['/api/monitor/recoverMonitor'] = [
        'MonitorHisGet'
    ]
    sPecilIntefaceRuleMap['/api/monitor/update'] = [
        'monitorUpdate'
    ]
    sPecilIntefaceRuleMap['/api/systemConfig/addUserGroup'] = [
        'UserGroupAdd'
    ]
    sPecilIntefaceRuleMap['/api/monitor/add'] = [
        'monitorAdd'
    ]
    return sPecilIntefaceRuleMap