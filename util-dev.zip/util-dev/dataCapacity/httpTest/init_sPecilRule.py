# 本文件用来初始化特殊取数规则
sPecilRuleMap = {}


# 返回特殊取数规则
def getsPecilRuleMap():
    sPecilRuleMap['startTask'] = {'type': 'String', 'data': {"type": "1"}}
    sPecilRuleMap['UserGroupAdd'] = {'type': 'String', 'data': {"name":"[random]","admin":{"groupSet":[],"userSet":[]},"allocate":{"groupSet":[],"userSet":[]},"desp":"[random]"}}
    sPecilRuleMap['collectorDelete_const'] = {
        'type': 'String',
        'data': {
            "empty": "true"
        }
    }
    sPecilRuleMap['UserGroupCUSTOM'] = {
        'type': 'MySql',
        'data': {
            'DBName':'181See',
            'sql':
            "select id,a.name from bbm_user_group a where a.type = 'CUSTOM' and a.admin_user_json='{\"empty\":false,\"groupSet\":[],\"userSet\":[{\"id\":1,\"key\":\"U1\",\"name\":\"admin\"}]}'",
            'cols': 'id,name',
            'outCols': 'id,name'
        }
    }
    sPecilRuleMap['UserGroupCUSTOM_Value'] = {
        'type': 'String',
        'data': {
            "id": 46,
            "name": "测试用户分组",
            "admin": {
                "groupSet": [],
                "userSet": []
            },
            "allocate": {
                "groupSet": [],
                "userSet": []
            },
            "desp": "[random]"
        }
    }
    sPecilRuleMap['taskEnum'] = {
        'type': 'Enum',
        'data': {
            "taskEnum": [
                'SEE_USER_GROUP', 'SEE_APP', 'SEE_MGR_RULES',
                'CLEAN_INFLUX_DB', 'CLEAN_IMPORT_FILE', 'CLEAN_DATABASE',
                'CLEAN_DB_NO_INFLUX_DB'
            ],
            "timingTaskEnum": ['SEE_USER_GROUP', 'SEE_APP', 'SEE_MGR_RULES']
        }
    }
    sPecilRuleMap['CUSTOMSystemConfig'] = {
        'type': 'MySql',
        'data': {
            'DBName':'181See',
            'sql':
            "select id,type,a.key from bbm_system_config a where a.type='CUSTOM_TYPE' and a.`value` like '%{%'",
            'cols': 'id,type,key',
            'outCols': 'id,type,key'
        }
    }
    sPecilRuleMap['CUSTOMBizConfig'] = {
        'type': 'MySql',
        'data': {
            'DBName':'181See',
            'sql':
            "select id,type,a.key from bbm_biz_config a where a.type = 'CUSTOM_TYPE' and a.`value` like '%{%'",
            'cols': 'id,type,key',
            'outCols': 'id,type,key'
        }
    }
    sPecilRuleMap['ConfigValue'] = {
        'type': 'String',
        'data': {
            'value': '{"value":"[random]"}'
        }
    }
    sPecilRuleMap['DownGradeTrue'] = {
        'type': 'MySql',
        'data': {
            'DBName':'181See',
            'sql':
            "select id from bbm_system_config a where a.type='SWITCHER' and a.`value`='true'",
            'cols': 'id',
            'outCols': 'id'
        }
    }
    sPecilRuleMap['updateGroup'] = {
        'type': 'String',
        'data': {
            "admin": {
                "groupSet": [],
                "userSet": [{
                    "id": 1,
                    "key": "U1",
                    "name": "admin",
                    "type": "USER"
                }]
            },
            "auth": {
                "groupSet": [],
                "userSet": []
            },
            "bizGroupExtConfig": {
                "alarmReceiver": {
                    "groupSet": [],
                    "userSet": []
                }
            },
            "name": "想测试而已",
            "desp": "[random]",
            "type": "BIZ_MONITOR_GROUP",
            "parentId": 65412,
            "nodeId": 293373
        }
    }
    sPecilRuleMap['TimingTask'] = {
        'type': 'MySql',
        'data': {
            'DBName':'181See',
            'sql':
            "select id from bbm_system_config a where a.type='TIMING_TASK' and a.`value`='{\"status\":true}'",
            'cols': 'id',
            'outCols': 'id'
        }
    }
    sPecilRuleMap['oneAuditLogDetail'] = {
        'type': 'MySql',
        'data': {
            'DBName':'181See',
            'sql': "select id from bbm_op_log a where a.type='audit'",
            'cols': 'id',
            'outCols': 'id'
        }
    }
    sPecilRuleMap['systemLogDetail'] = {
        'type': 'MySql',
        'data': {
            'DBName':'181See',
            'sql':
            "select id from bbm_op_log a where a.type = 'SYSTEM_LOG' limit 100",
            'cols': 'id',
            'outCols': 'id'
        }
    }
    sPecilRuleMap['collectorHisGet'] = {
        'type': 'MySql',
        'data': {
            'DBName':'181See',
            'sql':
            "select id,ref_id from bbm_version_history a where a.type = 'COLLECTOR'",
            'cols': 'id,ref_id',
            'outCols': 'id,refId'
        }
    }
    sPecilRuleMap['MonitorHisGet'] = {
        'type': 'MySql',
        'data': {
            'DBName':'181See',
            'sql':
            "select id,ref_id,version from bbm_version_history a where a.type = 'MONITOR'",
            'cols': 'id,ref_id,ref_id,version',
            'outCols': 'id,refId,equalsRefId,equalsVersion'
        }
    }
    sPecilRuleMap['collectorGet'] = {
        'type': 'MySql',
        'data': {
            'DBName':'181See',
            'sql': "select id from bbm_collector_definition",
            'cols': 'id,id,id',
            'outCols': 'id,equalsRefId,refId'
        }
    }
    sPecilRuleMap['collectorDelete'] = {
        'type': 'MySql',
        'data': {
            'DBName':'181See',
            'sql':
            "select id from bbm_collector_definition a where a.`mode` ='USER_INPUT' and a.operator='admin' and a.`name` like '自助系统测试%'",
            'cols': 'id',
            'outCols': 'ids',
            'list': ['id']
        }
    }
    sPecilRuleMap['monitorUpdate'] = {
        'type': 'String',
        'data': {"admin":{"groupSet":[],"userSet":[{"id":20,"key":"U20","name":"ldp(ldp)","type":"USER"},{"id":21,"key":"U21","name":"deploy(deploy)","type":"USER"},{"id":38,"key":"U38","name":"555(zhangmx36439)","type":"USER"}]},"auth":{"groupSet":[],"userSet":[{"id":20,"key":"U20","name":"ldp(ldp)","type":"USER"},{"id":21,"key":"U21","name":"deploy(deploy)","type":"USER"}]},"monitorConfig":{"defaultAlarmConfigList":[{"advancedAlarm":"","alarmChannelDescriptionList":[{"channelName":"SEE微信","id":62}],"alarmLevel":1,"alarmStrategy":{"code":1,"hasInput":"false","name":"总是报警"},"alarmStrategyExt":"","alarmTplContent":"3333","connectType":"NONE","desp":"","enable":"true","itemList":[{"columnName":"123","comparator":"GREATER","metricsName":"1","targetValue":"333","valueType":"DOUBLE"}],"title":"3333","type":"自定义","updateTime":1621824905075}],"defaultGraphConfigList":[{"configContent":"333","name":"333"}],"passiveDataModel":{"metricsConfigList":[]},"collectorId":482},"collectorId":482,"name":"冒烟自测","desp":"[random]","pub":"true","type":"ACTIVE","id":751,"version":"0.0.1"}
    }
    sPecilRuleMap['collectorAdd'] = {
        'type': 'String',
        'data': {
            "pub": "true",
            "type": "AVIATOR",
            "version": "V1.0.0.1",
            "workLevel": "1"
        }
    }
    sPecilRuleMap['collectorConfig'] = {
        'type': 'String',
        'data': {
            "collectorConfig": {
                "aviatorConfig": {
                    "argsList": [{
                        "desp": "string",
                        "enable": "true",
                        "key": "string",
                        "name": "string",
                        "type": "NUMBER",
                        "value": "string"
                    }],
                    "scriptContent":
                    "string"
                },
                "dataModel": {
                    "metricsConfigList": [{
                        "columnList": [{
                            "aggType": "NONE",
                            "defaultValue": "string",
                            "desp": "string",
                            "name": "string",
                            "needTag": "true",
                            "remark": "string",
                            "valueType": "STRING"
                        }],
                        "desp":
                        "string",
                        "name":
                        "string"
                    }]
                },
                "publicAccess": "true",
                "workLevel": "NONE"
            }
        }
    }
    sPecilRuleMap['getCustomConfig'] = {
        'type': 'MySql',
        'data': {
            'DBName':'181See',
            'sql':
            "select id,left(content_json,INSTR(content_json,',')-1) as content_json from (\
select id,SUBSTR(a.content_json FROM INSTR(a.content_json,'{\"bindMonitorId\":') + LENGTH('{\"bindMonitorId\":') FOR 100) \
    as content_json from bbm_cmdb_tree_node a where a.type = 'BIZ_MONITOR') t",
            'cols': 'id,content_json',
            'outCols': 'bizMonitorId,monitorId'
        }
    }
    sPecilRuleMap['getBizGroupInfo'] = {
        'type': 'MySql',
        'data': {
            'DBName':'181See',
            'sql':
            "select id from bbm_cmdb_tree_node a where a.type ='BIZ_MONITOR_GROUP'",
            'cols': 'id',
            'outCols': 'id'
        }
    }
    sPecilRuleMap['getBizMonitorInfo'] = {
        'type': 'MySql',
        'data': {
            'DBName':'181See',
            'sql':
            "select id from bbm_cmdb_tree_node a where a.type ='BIZ_MONITOR'",
            'cols': 'id',
            'outCols': 'id'
        }
    }
    sPecilRuleMap['deleteBizGroup'] = {
        'type': 'MySql',
        'data': {
            'DBName':'181See',
            'sql':
            "select id from bbm_cmdb_tree_node a where a.content_json = '' and a.admin_json like '%\"name\":\"string\"%' and a.type ='BIZ_MONITOR_GROUP'",
            'cols': 'id',
            'outCols': 'id'
        }
    }
    sPecilRuleMap['deleteBizMonitor'] = {
        'type': 'MySql',
        'data': {
            'DBName':'181See',
            'sql':
            "select id from bbm_cmdb_tree_node a where a.content_json = '' and a.admin_json like '%\"name\":\"string\"%' and a.type ='BIZ_MONITOR'",
            'cols': 'id',
            'outCols': 'id'
        }
    }
    sPecilRuleMap['closeAlarmRule'] = {
        'type': 'String',
        'data': {
            'duration': '-1'
        }
    }
    sPecilRuleMap['children'] = {
        'type': 'String',
        'data': {
            'children': ["null"]
        }
    }
    sPecilRuleMap['BizGroupExtConfig'] = {
        'type': 'String',
        'data': {
            "bizGroupExtConfig": {
                "alarmReceiver": {
                    "admin": "true",
                    "groupSet": [{
                        "id": "0",
                        "name": "string"
                    }],
                    "userSet": [{
                        "id": "0",
                        "name": "string"
                    }]
                }
            }
        }
    }
    sPecilRuleMap['dateTime'] = {
        'type': 'page',
        'data': {
            'updateTime': 'unix_time',
            'createTime': 'unix_time'
        }
    }
    sPecilRuleMap['RandomMap'] = {
        'type': 'Random',
        'data': {
            'enable': 'C1',
            'name': 'C8',
            'desp': 'C10',
            'modeDesp': 'C10',
            'mode': 'C4'
        }
    }
    sPecilRuleMap['topID'] = {
        'type': 'String',
        'data': {
            'type': 'None',
            "nodeId": "0",
            "parentId": "0"
        }
    }
    sPecilRuleMap['VoPermission'] = {
        'type': 'String',
        'data': {
            "permission": {
                "delete": "true",
                "update": "true",
                "visit": "true"
            }
        }
    }
    sPecilRuleMap['BizMonitorConfig'] = {
        'type': 'String',
        'data': {
            "monitorConfig": {
                "alarmRuleList": [{
                    "advancedAlarm":
                    "string",
                    "alarmChannelDescriptionList": [{
                        "channelName": "string",
                        "id": "0"
                    }],
                    "alarmLevel":
                    "0",
                    "alarmStrategy": {
                        "code": "0",
                        "hasInput": "true",
                        "name": "string"
                    },
                    "alarmStrategyExt":
                    "string",
                    "alarmTplContent":
                    "string",
                    "connectType":
                    "OR",
                    "desp":
                    "string",
                    "enable":
                    "true",
                    "itemList": [{
                        "columnName": "string",
                        "comparator": "EQUAL",
                        "metricsName": "string",
                        "targetValue": "string",
                        "valueType": "STRING"
                    }],
                    "title":
                    "string",
                    "type":
                    "string",
                    "updateTime":
                    "0"
                }],
                "bindMonitorId":
                "0",
                "coverage":
                "string",
                "cron":
                "0 */1 * * * ?",
                "enable":
                "true",
                "graphConfigList": [{
                    "configContent": "string",
                    "name": "string"
                }],
                "onlyTradingDay":
                "true",
                "scheduleId":
                "0",
                "scriptArgsList": [{
                    "desp": "string",
                    "enable": "true",
                    "key": "string",
                    "name": "string",
                    "type": "NUMBER",
                    "value": "string"
                }],
                "version":
                "string"
            }
        }
    }
    sPecilRuleMap['BizGroupConfig'] = {
        'type': 'String',
        'data': {
            "groupConfig": {
                "bizGroupId": "0",
                "name": "[random]"
            }
        }
    }
    sPecilRuleMap['SimpleUserAndGroup'] = {
        'type': 'String',
        'data': {
            "admin": {
                "admin": "true",
                "groupSet": [{
                    "id": "0",
                    "name": "string"
                }],
                "userSet": [{
                    "id": "0",
                    "name": "string"
                }]
            },
            "auth": {
                "admin": "true",
                "groupSet": [{
                    "id": "0",
                    "name": "string"
                }],
                "userSet": [{
                    "id": "0",
                    "name": "string"
                }]
            }
        }
    }
    sPecilRuleMap['BizMonitorExtConfig'] = {
        'type': 'String',
        'data': {
            "bizGroupExtConfig": {
                "alarmReceiver": {
                    "admin": "true",
                    "groupSet": [{
                        "id": "0",
                        "name": "string"
                    }],
                    "userSet": [{
                        "id": "0",
                        "name": "string"
                    }]
                }
            },
            "bizMonitorExtConfig": {
                "alarmReceiver": {
                    "admin": "true",
                    "groupSet": [{
                        "id": "0",
                        "name": "string"
                    }],
                    "userSet": [{
                        "id": "0",
                        "name": "string"
                    }]
                }
            }
        }
    }
    sPecilRuleMap['AlarmGraphCustomJson'] = {
        'type': 'String',
        'data': {
            'customJson': {
                "columnList": ["string"],
                "echartsConfig": {},
                "extraWhere": {},
                "groupByAlias": "string",
                "groupByList": ["string"],
                "metrics": "string",
                "renameYAxis": "string",
                "type": "LINE",
                "yAxisAttribute": "string"
            }
        }
    }
    sPecilRuleMap['listChildNode'] = {
        'type': 'MySql',
        'data': {
            'DBName':'181See',
            'sql':
            "select id,IF(LEFT(path,INSTR(path,'-')-1) = '',path,LEFT(path,INSTR(path,'-')-1)) as node_id from bbm_cmdb_tree_node a where a.type = 'BIZ_MONITOR'",
            'cols': 'id,node_id',
            'outCols': 'bizMonitorId,nodeId'
        }
    }
    sPecilRuleMap['listGraphAndTableConfig'] = {
        'type': 'MySql',
        'data': {
            'DBName':'181See',
            'sql':
            "select id,IF(LEFT(path,INSTR(path,'-')-1) = '',path,LEFT(path,INSTR(path,'-')-1)) as node_id from bbm_cmdb_tree_node a where a.type = 'BIZ_MONITOR_GROUP'",
            'cols': 'id,node_id',
            'outCols': 'bizMonitorId,nodeId'
        }
    }
    sPecilRuleMap['bizMonitorId'] = {
        'type': 'MySql',
        'data': {
            'DBName':'181See',
            'sql':
            "select id from bbm_cmdb_tree_node a where a.type = 'BIZ_MONITOR'",
            'cols': 'id',
            'outCols': 'bizMonitorId'
        }
    }
    sPecilRuleMap['monitor'] = {
        'type': 'MySql',
        'data': {
            'DBName':'181See',
            'sql':
            "select id from bbm_monitor_definition",
            'cols': 'id',
            'outCols': 'id'
        }
    }
    sPecilRuleMap['batchExportMonitor'] = {
        'type': 'MySql',
        'data': {
            'DBName':'181See',
            'sql':
            "select group_concat(id) as idlist from (select id from bbm_monitor_definition a limit 10) b",
            'cols': 'idlist',
            'outCols': 'idList',
            'list': ['idList']
        }
    }
    sPecilRuleMap['pageQery'] = {
        'type': 'page',
        'data': {
            'pageNumber': range(0, 5),
            'pageSize': range(1, 30),
            'endTime': 'unix_time',
            'startTime': 'unix_time'
        }
    }
    sPecilRuleMap['bbm_alarm_history'] = {
        'type': 'MySql',
        'data': {
            'DBName':'181See',
            'sql':
            "select id,alarm_level,biz_monitor_id,monitor_status,node_id,alarm_rule from bbm_alarm_history a",
            'cols':
            'id,alarm_level,biz_monitor_id,monitor_status,node_id,alarm_rule,node_id',
            'outCols':
            'alarmHistoryId,alarmLevel,bizMonitorId,monitorStatus,node_id,alarmRuleName,nodeId'
        }
    }
    sPecilRuleMap['bbm_alarm_history_for_closeAlarmRule'] = {
        'type': 'MySql',
        'data': {
            'DBName':'181See',
            'sql':
            "select id,alarm_level,biz_monitor_id,monitor_status,node_id,alarm_rule from bbm_alarm_history a where a.monitor_status = '1'",
            'cols':
            'id,alarm_level,biz_monitor_id,monitor_status,node_id,alarm_rule,node_id',
            'outCols':
            'alarmHistoryId,alarmLevel,bizMonitorId,monitorStatus,node_id,alarmRuleName,nodeId'
        }
    }
    sPecilRuleMap['bbm_alarm_history_for_enableAlarmRule'] = {
        'type': 'MySql',
        'data': {
            'DBName':'181See',
            'sql':
            "select id,alarm_level,biz_monitor_id,monitor_status,node_id,alarm_rule from bbm_alarm_history a where a.monitor_status = '3'",
            'cols':
            'id,alarm_level,biz_monitor_id,monitor_status,node_id,alarm_rule,node_id',
            'outCols':
            'alarmHistoryId,alarmLevel,bizMonitorId,monitorStatus,node_id,alarmRuleName,nodeId'
        }
    }
    sPecilRuleMap['updateBizMonitor'] = {
        'type': 'String',
        'data': {
            "admin": {
                "groupSet": [],
                "userSet": [{
                    "id": 1,
                    "key": "U1",
                    "name": "admin",
                    "type": "USER"
                }, {
                    "id": 19,
                    "key": "U19",
                    "name": "duanhaifei(duanhaifei)",
                    "type": "USER"
                }, {
                    "id": 20,
                    "key": "U20",
                    "name": "ldp(ldp)",
                    "type": "USER"
                }, {
                    "id": 22,
                    "key": "U22",
                    "name": "aa-name(aaaaaa)",
                    "type": "USER"
                }]
            },
            "auth": {
                "groupSet": [],
                "userSet": [{
                    "id": 20,
                    "key": "U20",
                    "name": "ldp(ldp)",
                    "type": "USER"
                }, {
                    "id": 21,
                    "key": "U21",
                    "name": "deploy(deploy)",
                    "type": "USER"
                }]
            },
            "bizMonitorExtConfig": {
                "alarmReceiver": {
                    "groupSet": [],
                    "userSet": [{
                        "id": 20,
                        "key": "U20",
                        "name": "ldp(ldp)",
                        "type": "USER"
                    }, {
                        "id": 21,
                        "key": "U21",
                        "name": "deploy(deploy)",
                        "type": "USER"
                    }]
                }
            },
            "monitorConfig": {
                "name":
                "333333333333",
                "desp":
                "333333333333333333334",
                "bindMonitorId":
                "707",
                "monitorScope":
                "0",
                "plan":
                "1",
                "palnOption":
                "128",
                "coverage":
                "{\"alarmRuleList\":[{\"advancedAlarm\":\"\",\"alarmChannelDespcriptionList\":[],\"alarmLevel\":0,\"alarmReceiver\":{\"groupSet\":[],\"userSet\":[]},\"alarmStrategyExt\":\"\",\"alarmTplContent\":\"微服务act各分片之间存在${checkInfo.diffCount}条记录不一致\",\"connectType\":\"NONE\",\"desp\":\"\",\"enable\":false,\"itemList\":[{\"columnName\":\"bizError\",\"comparator\":\"GREATER\",\"metricsName\":\"checkInfo\",\"targetValue\":\"0\",\"valueType\":\"LONG\"}],\"title\":\"act_act_sys_config\",\"type\":\"\",\"updateTime\":0}],\"bindMonitorId\":267,\"coverage\":\"{\\\"conditionList\\\":[{\\\"condition\\\":\\\"broker\\\\\\\\-.*?\\\\\\\\-svr\\\",\\\"key\\\":\\\"productTypeName\\\"}],\\\"op\\\":\\\"SINGLE\\\"}\",\"cron\":\"1\",\"enable\":true,\"graphConfigList\":[],\"scheduleId\":0,\"scriptArgsList\":[]}",
                "cron":
                "",
                "parentId":
                "237749",
                "admin": ["U1", "U19", "U20", "U22"],
                "auth": ["U20", "U21"],
                "alarmReceiver": ["U20", "U21"],
                "enable":
                "true",
                "graphConfigList": [{
                    "configContent": "111111111111",
                    "name": "111111111111",
                    "permission": {
                        "delete": "true",
                        "update": "true",
                        "visit": "true"
                    }
                }],
                "alarmRuleList": [{
                    "advancedAlarm": "11111111111111",
                    "alarmChannelDescriptionList": [],
                    "alarmLevel": 1,
                    "alarmStrategy": {
                        "code": 1,
                        "hasInput": "false",
                        "name": "总是报警"
                    },
                    "alarmStrategyExt": "",
                    "alarmTplContent": "111111111111111",
                    "connectType": "NONE",
                    "desp": "",
                    "enable": "true",
                    "itemList": [],
                    "permission": {
                        "delete": "true",
                        "update": "true",
                        "visit": "true"
                    },
                    "title": "111111111111",
                    "type": "自定义",
                    "updateTime": 1621147510623
                }, {
                    "advancedAlarm":
                    "3333333333333",
                    "alarmChannelDescriptionList": [{
                        "channelName": "钉钉",
                        "id": 42
                    }],
                    "alarmLevel":
                    0,
                    "alarmStrategy": {
                        "code": 1,
                        "hasInput": "false",
                        "name": "总是报警"
                    },
                    "alarmStrategyExt":
                    "",
                    "alarmTplContent":
                    "333333333",
                    "connectType":
                    "NONE",
                    "desp":
                    "",
                    "enable":
                    "true",
                    "itemList": [],
                    "permission": {
                        "delete": "true",
                        "update": "true",
                        "visit": "true"
                    },
                    "title":
                    "333333333333",
                    "type":
                    "自定义",
                    "updateTime":
                    1621415321441
                }],
                "scriptArgsList": [],
                "onlyTradingDay":
                "false",
                "scheduleId":
                128
            },
            "name": "333333333333",
            "desp": "[random]",
            "parentId": "237749",
            "type": "BIZ_MONITOR",
            "nodeId": 237973
        }
    }
    sPecilRuleMap['collector_update'] = {
        'type': 'String',
        'data': {
            "admin": {
                "groupSet": [],
                "userSet": [{
                    "id": 1,
                    "key": "U1",
                    "name": "admin",
                    "type": "USER"
                }]
            },
            "auth": {
                "groupSet": [],
                "userSet": []
            },
            "collectorConfig": {
                "aviatorConfig": {
                    "argsList": [{
                        "desp": "string",
                        "enable": "true",
                        "name": "string",
                        "type": "null",
                        "value": "string"
                    }],
                    "scriptContent":
                    "string"
                },
                "dataModel": {
                    "metricsConfigList": [{
                        "name":
                        "string",
                        "desp":
                        "string",
                        "columnList": [{
                            "aggType": "NONE",
                            "defaultValue": "string",
                            "desp": "string",
                            "name": "string",
                            "needTag": "true",
                            "remark": "string",
                            "valueType": "STRING",
                            "tabName": "string"
                        }]
                    }]
                },
                "workLevel": "NONE"
            },
            "name": "qcbazxut",
            "desp": "[random]",
            "pub": "false",
            "id": 483,
            "mode": "USER_INPUT",
            "version": "0.0.1"
        }
    }
    sPecilRuleMap['monitorAdd'] = {
        'type': 'String',
        'data': {
  "admin": {
    "admin": "true",
    "groupSet": [
      {
        "id": 0,
        "name": "string"
      }
    ],
    "userSet": [
      {
        "id": 0,
        "name": "string"
      }
    ]
  },
  "alarmRuleConfig": {
    "advancedAlarm": "string",
    "alarmChannelDescriptionList": [
      {
        "channelName": "string",
        "id": 0
      }
    ],
    "alarmLevel": 0,
    "alarmStrategy": {
      "code": 0,
      "hasInput": "true",
      "name": "string"
    },
    "alarmStrategyExt": "string",
    "alarmTplContent": "string",
    "connectType": "OR",
    "desp": "string",
    "enable": "true",
    "itemList": [
      {
        "columnName": "string",
        "comparator": "EQUAL",
        "metricsName": "string",
        "targetValue": "1",
        "valueType": "STRING"
      }
    ],
    "title": "string",
    "type": "string",
    "updateTime": 0
  },
  "auth": {
    "admin": "true",
    "groupSet": [
      {
        "id": 0,
        "name": "string"
      }
    ],
    "userSet": [
      {
        "id": 0,
        "name": "string"
      }
    ]
  },
  "collectorDesp": "string",
  "collectorId": 0,
  "collectorName": "string",
  "createTime": 0,
  "desp": "string",
  "id": 0,
  "mode": "NONE",
  "modeDesp": "string",
  "monitorConfig": {
    "collectorId": 0,
    "dataModel": {
      "metricsConfigList": [
        {
          "columnList": [
            {
              "aggType": "NONE",
              "defaultValue": "string",
              "desp": "string",
              "name": "string",
              "needTag": "true",
              "remark": "string",
              "valueType": "STRING"
            }
          ],
          "desp": "string",
          "name": "string"
        }
      ]
    },
    "defaultAlarmConfigList": [
      {
        "advancedAlarm": "string",
        "alarmChannelDescriptionList": [
          {
            "channelName": "string",
            "id": 0
          }
        ],
        "alarmLevel": 0,
        "alarmStrategy": {
          "code": 0,
          "hasInput": "true",
          "name": "string"
        },
        "alarmStrategyExt": "string",
        "alarmTplContent": "string",
        "connectType": "OR",
        "desp": "string",
        "enable": "true",
        "itemList": [
          {
            "columnName": "string",
            "comparator": "EQUAL",
            "metricsName": "string",
            "targetValue": "string",
            "valueType": "STRING"
          }
        ],
        "title": "string",
        "type": "string",
        "updateTime": 0
      }
    ],
    "defaultGraphConfigList": [
      {
        "configContent": "string",
        "name": "string"
      }
    ],
    "monitorId": 0,
    "passiveDataModel": {
      "metricsConfigList": [
        {
          "columnList": [
            {
              "aggType": "NONE",
              "defaultValue": "string",
              "desp": "string",
              "name": "string",
              "needTag": "true",
              "remark": "string",
              "valueType": "STRING"
            }
          ],
          "desp": "string",
          "name": "string"
        }
      ]
    }
  },
  "name": "[random]",
  "permission": {
    "delete": "true",
    "update": "true",
    "visit": "true"
  },
  "pub": "true",
  "type": "string",
  "typeDesp": "string",
  "updateTime": 0,
  "version": "0.0.1"
}
    }
    return sPecilRuleMap
