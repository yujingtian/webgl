# 本文件用来处理excel
import xlwt
import os
import tools
import datetime


# 将接口测试的结果进行保存
def SaveIntefaceTestResult(testResultList: list, unTestIntefaceList: list):
    # 创建一个workbook 设置编码
    workbook = xlwt.Workbook(encoding='utf-8')
    # 初始化样式
    headStyle = xlwt.XFStyle()
    lineStyle = xlwt.XFStyle()
    # 为样式创建字体
    headFont = xlwt.Font()
    headFont.name = '宋体'
    # 黑体
    headFont.bold = True
    # 下划线
    headFont.underline = False
    # 斜体字
    headFont.italic = False

    LineFont = xlwt.Font()
    LineFont.name = '宋体'
    # 黑体
    LineFont.bold = False
    # 下划线
    LineFont.underline = False
    # 斜体字
    LineFont.italic = False
    # 单元格背景色
    pattern = xlwt.Pattern()
    pattern.pattern = xlwt.Pattern.SOLID_PATTERN
    pattern.pattern_fore_colour = 0x2C
    # 单元边框
    borders = xlwt.Borders()
    # DASHED虚线 NO_LINE没有 THIN实线
    borders.left = xlwt.Borders.THIN
    borders.right = xlwt.Borders.THIN
    borders.top = xlwt.Borders.THIN
    borders.bottom = xlwt.Borders.THIN
    borders.left_colour = 0x40
    borders.right_colour = 0x40
    borders.top_colour = 0x40
    borders.bottom_colour = 0x40

    # 设定样式
    headStyle.font = headFont
    headStyle.pattern = pattern
    headStyle.borders = borders

    lineStyle.borders = borders
    lineStyle.font = LineFont
    #自动换行
    lineStyle.alignment.wrap = 1
    lineStyle.alignment.vert = 0x00

    # 创建一个worksheet
    worksheet = workbook.add_sheet('不测试接口', cell_overwrite_ok=False)
    worksheet.col(1).width = 256 * 50
    # 写入excel
    # 参数对应 行, 列, 值
    worksheet.write(1, 1, '功能号', headStyle)
    iRowIndex = 1
    for sIntefaceFunction in unTestIntefaceList:
        iRowIndex = iRowIndex + 1
        worksheet.write(iRowIndex, 1, sIntefaceFunction, lineStyle)

    # 创建一个worksheet
    worksheet = workbook.add_sheet('接口测试', cell_overwrite_ok=False)
    # 设置单元格宽度
    worksheet.col(1).width = 256 * 50
    worksheet.col(2).width = 256 * 25
    worksheet.col(3).width = 256 * 25
    worksheet.col(4).width = 256 * 100
    worksheet.col(6).width = 256 * 100

    # 写入excel
    # 参数对应 行, 列, 值
    worksheet.write(1, 1, '功能号', headStyle)
    worksheet.write(1, 2, '请求方式', headStyle)
    worksheet.write(1, 3, '测试结果', headStyle)
    worksheet.write_merge(1, 1, 4, 5, '测试入参', headStyle)
    worksheet.write_merge(1, 1, 6, 7, '测试结果', headStyle)

    iRowIndex = 1
    # 写结果
    for yzIntefaceResult in testResultList:
        sFunction = yzIntefaceResult['function']
        sQuestType = yzIntefaceResult['questType']
        if yzIntefaceResult['isSecuss']:
            isSecuss = '测试成功'
        else:
            isSecuss = '测试失败'
        sResultText = yzIntefaceResult['resultText']
        sResultText = sResultText.replace("'", '"')
        inData = yzIntefaceResult['inData']
        inData = inData.replace("'", '"')
        iRowIndex = iRowIndex + 1
        worksheet.write(iRowIndex, 1, sFunction, lineStyle)
        worksheet.write(iRowIndex, 2, sQuestType, lineStyle)
        worksheet.write(iRowIndex, 3, isSecuss, lineStyle)
        worksheet.write_merge(iRowIndex, iRowIndex, 4, 5, inData[:32000], lineStyle)
        worksheet.write_merge(iRowIndex, iRowIndex, 6, 7, sResultText[:32000],
                              lineStyle)

    # 保存
    FileName = tools.getProjectPath(
    ) + '/httpTest/testResult/' + datetime.datetime.now().strftime(
        '%Y%m%d%H%M%S') + '.xls'
    workbook.save(FileName)
    print(FileName + '生成成功')
