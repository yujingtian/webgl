# 本文件用来初始化接口校验成功的特殊规则
sPecilIntefaceSucessRuleMap = {}


def getSPecilIntefaceSucessRuleMap():
    sPecilIntefaceSucessRuleMap['/api/alarmAndGraph/enableAlarmRule'] = [{
        'type':
        'MySql',
        'data': {
            'ip':
            '10.20.23.181',
            'port':
            '43306',
            'user':
            'hs_bbm',
            'pwd':
            'hs_bbm',
            'serName':
            'hs_bbm',
            'sql':
            "select monitor_status,alarm_end_time from bbm_alarm_history a \
                where a.biz_monitor_id=%(bizMonitorId)s and a.node_id = %(nodeId)s and a.alarm_rule='%(alarmRuleName)s'",
            "checkRule": [{
                'type': 'count',
                'data': {
                    'monitor_status':
                    [['1', 1, 'max', 'monitor_status等于1的数据超过1条'],
                     ['2', -1, 'any', '']]
                }
            }, {
                'type':
                'equal',
                'data': [['monitor_status', '1', 'alarm_end_time', 'None'],
                         ['monitor_status', '2', 'alarm_end_time',
                          'not None']],
                'ErrorMsg':
                '存在数据不合法'
            }]
        }
    }]
    sPecilIntefaceSucessRuleMap['/api/alarmAndGraph/closeAlarmRule'] = [{
        'type':
        'MySql',
        'data': {
            'ip':
            '10.20.23.181',
            'port':
            '43306',
            'user':
            'hs_bbm',
            'pwd':
            'hs_bbm',
            'serName':
            'hs_bbm',
            'sql':
            "select monitor_status,alarm_end_time from bbm_alarm_history a \
                where a.biz_monitor_id=%(bizMonitorId)s and a.node_id = %(nodeId)s and a.alarm_rule='%(alarmRuleName)s'",
            "checkRule": [{
                'type': 'count',
                'data': {
                    'monitor_status': [['3', -1, 'any', ''],
                                       ['2', -1, 'any', '']]
                }
            }]
        }
    }]
    return sPecilIntefaceSucessRuleMap