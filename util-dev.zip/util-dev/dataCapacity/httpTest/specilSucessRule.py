# 本文件处理成功的判断逻辑
import time
import datetime
from mysqlTools import GetDB, CloseDB, SelectDB


# 检查是否满足特殊规则
def CheckSucessRule(SucessRule, sDict):
    sRuleType = SucessRule['type']
    sData = SucessRule['data']
    checkRuleList = sData['checkRule']

    # 取数方式为通过MySql
    if sRuleType.upper() == 'MySql'.upper():
        sIP = sData['ip']
        sPort = int(sData['port'])
        sUser = sData['user']
        sPwd = sData['pwd']
        sSerName = sData['serName']
        sSql = sData['sql']
        GetDB(sUser=sUser, sPwd=sPwd, sIP=sIP, sPort=sPort, sSerName=sSerName)
        sSqlStr = sSql % sDict
        print(sSqlStr)
        one = None
        one = SelectDB(sSqlStr)
        CloseDB()
        for checkRule in checkRuleList:
            sCheckRuleType = str(checkRule['type'])
            # 求数量
            if sCheckRuleType.upper() == 'count'.upper():
                sCheckRuleData = checkRule['data']
                for sCheckFiledName in sCheckRuleData:
                    # 已知求count，此处对求count的字段进行数据清洗
                    tmpMap = {}
                    for item in one:
                        sKey = item[sCheckFiledName]
                        if sKey in tmpMap:
                            sNo = tmpMap[sKey] + 1
                        else:
                            tmpMap[sKey] = 1
                    subRuleList = sCheckRuleData[sCheckFiledName]
                    checkValueList = []
                    for subRule in subRuleList:
                        sCheckValue = str(subRule[0])  #比较的值
                        sCount = subRule[1]  #比较的数量
                        sCheckFunc = str(subRule[2])  #比较的方法
                        sFailMsg = subRule[3]  #不匹配返回的说明

                        if sCheckValue not in checkValueList:
                            checkValueList.append(sCheckValue)

                        if sCheckValue in tmpMap:
                            sDBCount = tmpMap[sCheckValue]
                        else:
                            sDBCount = 0

                        # 最大
                        if sCheckFunc.upper() == 'max'.upper():
                            if sDBCount > sCount:
                                return False, sFailMsg
                        # 最小
                        elif sCheckFunc.upper() == 'min'.upper():
                            if sDBCount < sCount:
                                return False, sFailMsg
                        # 相等
                        elif sCheckFunc.upper() == 'equal'.upper():
                            if sDBCount != sCount:
                                return False, sFailMsg
                    # 检查是否存在额外值
                    for sKey in tmpMap:
                        if str(sKey) not in checkValueList:
                            return False, sCheckFiledName + '出现超出数据范围的值'
            # 求值相等
            elif sCheckRuleType.upper() == 'equal'.upper():
                sCheckRuleData = checkRule['data']
                sFailMsg = checkRule['ErrorMsg']
                for dbItem in one:
                    # 拿数据库记录去匹配规则
                    isMate = False
                    for sCheckRuleItem in sCheckRuleData:
                        sKeyCount = len(sCheckRuleItem)
                        if sKeyCount == 4:
                            sFirstFiledName = sCheckRuleItem[0]  #第一个字段
                            sFirstFiledValue = sCheckRuleItem[1]  #第一个值
                            sSecoundFiledName = sCheckRuleItem[2]  #第二个字段
                            sSecoundFiledValue = str(
                                sCheckRuleItem[3])  #第二个字段值

                            sFirstDBValue = dbItem[sFirstFiledName]
                            sSecoundDBValue = dbItem[sSecoundFiledName]
                            if str(sFirstDBValue) != sFirstFiledValue:
                                continue
                            if sSecoundFiledValue.upper() == 'None'.upper():
                                if sSecoundDBValue != None:
                                    continue
                            elif sSecoundFiledValue.upper(
                            ) == 'not None'.upper():
                                if (sSecoundDBValue == None):
                                    continue
                                if (not isinstance(sSecoundDBValue,
                                                   datetime.datetime)
                                    ) and (len(sSecoundDBValue) == 0):
                                    continue
                            elif sSecoundFiledValue != sSecoundDBValue:
                                continue
                            isMate = True
                            break
                    if not isMate:
                        return False, sFailMsg

    return True, ''