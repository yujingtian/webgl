# 本文件处理测试用的初始数据
import tools
import random
import init_sPecilIntefaceSucessRule
import init_sPecilIntefaceRule
import init_sPecilRule
import createData
import init_testDB
from mysqlTools import GetDB, CloseDB, SelectDB


# 返回特殊取数规则
def getsPecilRuleMap():
    return init_sPecilRule.getsPecilRuleMap()


# 返回处理接口取数的规则
def getsPecilIntefaceRuleMap():
    return init_sPecilIntefaceRule.getsPecilIntefaceRuleMap()


# 返回接口校验成功的特殊规则
def getSPecilIntefaceSucessRuleMap():
    return init_sPecilIntefaceSucessRule.getSPecilIntefaceSucessRuleMap()


# 处理自定义规则
def InitRule(sPecilRuleMap, sPecilFiledMap):
    DBMap = init_testDB.getDBMap()
    for sRuleName in sPecilRuleMap:
        sType = str(sPecilRuleMap[sRuleName]['type'])
        sData = sPecilRuleMap[sRuleName]['data']

        # 取数方式为通过MySql
        if sType.upper() == 'MySql'.upper():
            sDBName = sData['DBName']
            sDBInfo = DBMap['MySql'][sDBName]
            sIP = sDBInfo['ip']
            sPort = int(sDBInfo['port'])
            sUser = sDBInfo['user']
            sPwd = sDBInfo['pwd']
            sSerName = sDBInfo['serName']
            sSql = sData['sql']
            cols = str(sData['cols']).split(',')
            outCols = str(sData['outCols']).split(',')
            listFiled = []
            if 'list' in sData:
                listFiled = sData['list']

            GetDB(sUser=sUser,
                  sPwd=sPwd,
                  sIP=sIP,
                  sPort=sPort,
                  sSerName=sSerName)
            one = SelectDB(sSql)
            CloseDB()
            if len(one) > 0:
                iLoop = random.randint(0, len(one) - 1)
                valueInfo = one[iLoop]
                yzItem = {}
                for iLoop in range(0, len(cols)):
                    if cols[iLoop] in listFiled:
                        yzItem[outCols[iLoop]] = [valueInfo[cols[iLoop]]]
                    else:
                        yzItem[outCols[iLoop]] = valueInfo[cols[iLoop]]
                sPecilFiledMap[sRuleName] = yzItem
        # 取数方式为分页模式
        elif sType.upper() == 'page'.upper():
            yzItem = {}
            for sKey in sData:
                sObjectValue = sData[sKey]
                if isinstance(sObjectValue, range):
                    sValue = sObjectValue[random.randint(
                        0,
                        len(sObjectValue) - 1)]
                    yzItem[sKey] = sValue
                elif isinstance(sObjectValue, str):
                    if sObjectValue == 'unix_time':
                        yzItem[sKey] = str(tools.unix_time())
            sPecilFiledMap[sRuleName] = yzItem
        # 取数方式为固定值
        elif sType.upper() == 'String'.upper():
            yzItem = {}
            for sKey in sData:
                sValue = sData[sKey]
                if isinstance(sValue, dict):
                    sValue = changeStringValue(sValue)
                elif isinstance(sValue, str):
                    if sKey in [
                            'name', 'desp', 'value'
                    ] and '[random]'.upper() in str(sValue).upper():
                        sValue = str(sValue).replace(
                            '[random]',
                            createData.getFiledValue(sKey, 'C8', 0))
                yzItem[sKey] = sValue
            sPecilFiledMap[sRuleName] = yzItem
        # 取数方式为利用造数工厂
        elif sType.upper() == 'Random'.upper():
            yzItem = {}
            for sKey in sData:
                sKeyType = sData[sKey]
                sValue = createData.getFiledValue(sKey, sKeyType, 0)
                yzItem[sKey] = sValue
            sPecilFiledMap[sRuleName] = yzItem
        # 取数方式为枚举
        elif sType.upper() == 'Enum'.upper():
            yzItem = {}
            for sKey in sData:
                sListType = sData[sKey]
                iValueListCount = len(sListType)
                sValue = sListType[random.randint(0, iValueListCount - 1)]
                yzItem[sKey] = sValue
            sPecilFiledMap[sRuleName] = yzItem

    return sPecilFiledMap


# 向下3层根据random产生数据
def changeStringValue(sDict: dict):
    for sKey in sDict:
        if sKey in ['name', 'desp'] and '[random]'.upper() in str(
                sDict[sKey]).upper():
            sDict[sKey] = str(sDict[sKey]).replace(
                '[random]', createData.getFiledValue(sKey, 'C8', 0))
        elif isinstance(sDict[sKey], dict):
            for subKey in sDict[sKey]:
                if subKey in ['name', 'desp'] and '[random]'.upper() in str(
                        sDict[sKey][subKey]).upper():
                    sDict[sKey][subKey] = str(sDict[sKey][subKey]).replace(
                        '[random]', createData.getFiledValue(subKey, 'C8', 0))
                elif isinstance(sDict[sKey][subKey], dict):
                    for tsubKey in sDict[sKey][subKey]:
                        if tsubKey in [
                                'name', 'desp'
                        ] and '[random]'.upper() in str(
                                sDict[sKey][subKey][tsubKey]).upper():
                            sDict[sKey][subKey][tsubKey] = str(
                                sDict[sKey][subKey]).replace(
                                    '[random]',
                                    createData.getFiledValue(tsubKey, 'C8', 0))
    return sDict
