package com.hundsun.dcinfo.friendlylink.service.api;

import com.hundsun.dcinfo.friendlylink.pojo.FriendlyLink;

import java.util.List;

/**
 * @author Star_King
 */
public interface FriendlyLinkService {
    /**
     * 根据链接名查询链接信息
     * @param friendName 链接名
     * @return 链接对象列表
     */
    List<FriendlyLink> searchFriendlyLinkByName(String friendName);

    /**
     * 根据链接名和用户ID查询链接信息
     * @param friendName 链接名
     * @param userID 用户ID
     * @return 链接对象
     */
    FriendlyLink searchLinkByNameAndUserID(String friendName, String userID);

    /**
     * 在数据库中根据用户Id查询友情链接，查询基础链接和该用户的链接
     * @param userID 用户ID
     * @return 链接对象列表
     */
    List<FriendlyLink> searchFriendlyLinkByUserID(String userID);

    /**
     * 添加友情链接
     * @param friendlyLink 友情链接对象
     * @return 添加成功标志，成功返回true，失败返回false
     */
    boolean addFriendlyLink(FriendlyLink friendlyLink);

    /**
     * 根据链接名删除友情链接
     * @param friendName 链接名
     * @param userID 用户ID
     * @return 删除成功标志，成功返回true，失败返回false
     */
    boolean removeFriendlyLinkByNameAndUserID(String friendName, String userID);

    /**
     * 修改友情链接
     * @param friendlyLink 友情链接信息
     * @return 修改成功标志，成功返回true，失败返回false
     */
    boolean changeFriendlyLink(FriendlyLink friendlyLink);

    /**
     * 查询全部基础链接
     * @return 友情链接对象列表
     */
    List<FriendlyLink> searchAllBasicLink();

    /**
     * 修改友情链接
     * @param friendlyLink 友情链接信息
     * @return 修改成功标志，成功返回true，失败返回false
     */
    boolean changeFriendlyLink1(FriendlyLink friendlyLink);

    /**
     * 查询数据库中最新的友情链接的order是多少
     * @return order
     */
    Integer searchLastFriendlyOrder();

    /**
     * 查询数据库中是否含有这个order
     * @param order 要查询的order
     * @return 含有的标志，如果有则返回true，否则返回false
     */
    boolean existFriendlyOrder(Integer order);

    /**
     * 根据order顺序查询FriendlyLink
     * @param friendOrder order
     * @return FriendlyLink对象
     */
    FriendlyLink searchFriendlyLinkByOrder(Integer friendOrder);

    /**
     * 根据链接名与flag查看用户是否关联此基链
     * @param friendName
     * @param flag
     * @return
     */
    FriendlyLink searchLinkByNameAndFlag(String friendName, int flag);

    /**
     * 删除基链中的userID，从此该基链与该userID无关
     * @param friendName
     * @param userID
     * @return
     */
    Boolean addUserID(String friendName, String userID);

    Boolean updateOrder(String userID, String substring);

}
