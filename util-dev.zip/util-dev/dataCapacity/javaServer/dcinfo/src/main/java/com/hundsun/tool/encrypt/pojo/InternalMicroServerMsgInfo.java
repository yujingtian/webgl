package com.hundsun.tool.encrypt.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

/**
 * 微服务内部调用T3加密时的入参
 *
 * @author Star_King
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class InternalMicroServerMsgInfo {
    private String testServer;
    /**
     * 功能号
     */
    private String functionId;
    /**
     * 微服务别名
     */
    private String serverAlias;

    /**
     * 用于分片定位
     */
    private Map<Object, Object> shardingInfo;

    /**
     * 存放了票据信息、密码字段、IAR会话标识
     */
    private Map<Object, Object> security;

    /**
     * 要传递的参数，Json格式
     */
    private Map<Object, Object> param;
}
