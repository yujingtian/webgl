package com.hundsun.tool.t2Encrypt.service;

import java.util.Map;
/**
 * @Author: kcaumber
 * @Date: 10/21/21 10:34 AM
 */
public interface T2EncryptService {
    Map<String, String> qryStockHoldersByFundAccount();
}
