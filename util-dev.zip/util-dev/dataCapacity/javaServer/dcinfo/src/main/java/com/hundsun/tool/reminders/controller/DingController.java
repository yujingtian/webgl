package com.hundsun.tool.reminders.controller;

import com.alibaba.fastjson.JSONObject;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.hundsun.dcinfo.jumpToMail.controller.DingTalkController;
import com.hundsun.tool.reminders.entity.BigBagOut;
import com.hundsun.tool.reminders.entity.SpliBag;
import com.hundsun.tool.reminders.service.DingService;
import com.hundsun.tool.utils.TransClassUtil;
import com.hundsun.tool.utils.CheckDay;
import com.hundsun.tool.utils.ResultEntity;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.text.ParseException;
import java.util.*;

/**
 * @Author: kcaumber
 * @Date: 2021/11/11 17:37
 */
@CrossOrigin
@RestController
@RequestMapping("/sendDing")
public class DingController {

    private final DingService dingService;
    private final DingTalkController dingTalkController;

    public DingController(@Qualifier("dingService") DingService dingService, @Qualifier("dingTalkController") DingTalkController dingTalkController1) {
        this.dingService = dingService;
        this.dingTalkController = dingTalkController1;
    }

    @RequestMapping("/AcctQA")
    public String AcctQA() throws ParseException, JsonProcessingException, NoSuchAlgorithmException, InvalidKeyException, UnsupportedEncodingException {

        if (!CheckDay.checkWorkDay()){
            return ResultEntity.failWithoutData("今天不是工作日").returnResult();
        }

        List<String> operatorInGroupList = dingService.selectIDByTeamName("业务研发二组");

        String remindMsg = ""; // 非账户msg
        String remindZHMsg = ""; // 账户MSG；
        System.out.println("大群");
        List<String> phoneList = new ArrayList<>();
        List<String> phoneZHList = new ArrayList<>();
        // 检查大包中还在新增和审核状态的修改单
        List<Map<String,String>> bigBagOutDateList = dingService.bigBagOutDate(); // 包名

        if (bigBagOutDateList.size() > 0) {


            for (Map<String, String> bigBagOutDate : bigBagOutDateList){

                List<Map<String, String>> reworkListByBagName = dingService.SearchReworking(bigBagOutDate.get("bagname")); // 获取该包包含的修改单
                List<BigBagOut> bigBagOutList = new ArrayList<>(); // 分割后的非账户修改单列表
                List<BigBagOut> bigBagOutZHList = new ArrayList<>(); // 分割后的账户修改单列表
                // 将修改单按接收人切割
                if (reworkListByBagName != null){
                    for (Map<String, String> rework : reworkListByBagName){
                        if (rework.get("sys_receiver_sign").matches("(.*),(.*)")){
                            List<String> list = Arrays.asList(rework.get("sys_receiver_sign").split(","));
                            for (String s : list){
                                if (!operatorInGroupList.contains(s)){
                                    bigBagOutList.add(new BigBagOut(rework.get("reworking_id"), s, rework.get("reworking_status_no")));
                                } else {
                                    bigBagOutZHList.add(new BigBagOut(rework.get("reworking_id"), s, rework.get("reworking_status_no")));
                                }
                            }
                        } else {
                            if (!operatorInGroupList.contains(rework.get("sys_receiver_sign"))){
                                bigBagOutList.add(new BigBagOut(rework.get("reworking_id"), rework.get("sys_receiver_sign"), rework.get("reworking_status_no")));
                            } else {
                                bigBagOutZHList.add(new BigBagOut(rework.get("reworking_id"), rework.get("sys_receiver_sign"), rework.get("reworking_status_no")));
                            }
                        }
                    }

                    // 大群部分

                    Map<String, List<String>> xzMap = new LinkedHashMap<>(); // 对应新增非账户用户修改单
                    Map<String, List<String>> shMap = new LinkedHashMap<>(); // 对应yz非账户用户修改单

                    for (BigBagOut bigBagOut : bigBagOutList){
                        List<String> tmp_reworkingIdList = new ArrayList<>();
                        if (bigBagOut.getReworkingStatusNo().equals("501") || bigBagOut.getReworkingStatusNo().equals("503")){
                            tmp_reworkingIdList = new ArrayList<>();
                            if (xzMap.get(bigBagOut.getSysReceiverSign()) != null){
                                tmp_reworkingIdList = xzMap.get(bigBagOut.getSysReceiverSign());
                            }
                            tmp_reworkingIdList.add(bigBagOut.getReworkingId());
                            xzMap.put(bigBagOut.getSysReceiverSign(), tmp_reworkingIdList);
                        } else {
                            tmp_reworkingIdList = new ArrayList<>();
                            if (shMap.get(bigBagOut.getSysReceiverSign()) != null){
                                tmp_reworkingIdList = shMap.get(bigBagOut.getSysReceiverSign());
                            }
                            tmp_reworkingIdList.add(bigBagOut.getReworkingId());
                            shMap.put(bigBagOut.getSysReceiverSign(), tmp_reworkingIdList);
                        }
                    }
                    Map<String, Object> initResult = dingService.initMsg(remindMsg, bigBagOutDate.get("bagname"), bigBagOutDate.get("lastdjdate"), bigBagOutDate.get("outbagdate"), shMap, xzMap);
                    remindMsg = String.valueOf(initResult.get("remindMsg"));
                    phoneList.addAll(TransClassUtil.castList(initResult.get("phoneList"), String.class));

                    // 账户部分
                    xzMap = new LinkedHashMap<>(); // 对应新增账户用户修改单
                    shMap = new LinkedHashMap<>(); // 对应yz账户用户修改单

                    for (BigBagOut bigBagOut : bigBagOutZHList){
                        List<String> tmp_reworkingIdList = new ArrayList<>();
                        if (bigBagOut.getReworkingStatusNo().equals("501") || bigBagOut.getReworkingStatusNo().equals("503")){
                            tmp_reworkingIdList = new ArrayList<>();
                            if (xzMap.get(bigBagOut.getSysReceiverSign()) != null){
                                tmp_reworkingIdList = xzMap.get(bigBagOut.getSysReceiverSign());
                            }
                            tmp_reworkingIdList.add(bigBagOut.getReworkingId());
                            xzMap.put(bigBagOut.getSysReceiverSign(), tmp_reworkingIdList);
                        } else {
                            tmp_reworkingIdList = new ArrayList<>();
                            if (shMap.get(bigBagOut.getSysReceiverSign()) != null){
                                tmp_reworkingIdList = shMap.get(bigBagOut.getSysReceiverSign());
                            }
                            tmp_reworkingIdList.add(bigBagOut.getReworkingId());
                            shMap.put(bigBagOut.getSysReceiverSign(), tmp_reworkingIdList);
                        }
                    }

                    initResult = dingService.initMsg(remindZHMsg, bigBagOutDate.get("bagname"), bigBagOutDate.get("lastdjdate"), bigBagOutDate.get("outbagdate"), shMap, xzMap);
                    remindZHMsg = String.valueOf(initResult.get("remindMsg"));
                    phoneZHList.addAll(TransClassUtil.castList(initResult.get("phoneList"), String.class));
                }
           }

        }


        // 检查特殊包修改单进度
        List<Map<String, String>> reworkingList = dingService.SearchSpilBagDate(); // 特殊包包名列表
        List<SpliBag> spilBagDateList = new ArrayList<>(); // 分割后的大群修改单列表
        List<SpliBag> spilBagDateZHList = new ArrayList<>(); //分割后的账户修改单
        // 将修改单按接收人切割
        for (Map<String, String> rework : reworkingList) {
            if (rework.get("sys_receiver_sign").matches("(.*),(.*)")){
                List<String> list = Arrays.asList(rework.get("sys_receiver_sign").split(","));
                for (String s : list){
                    if (!operatorInGroupList.contains(s)){
                        spilBagDateList.add(new SpliBag(rework.get("bagname"), rework.get("reworking_id"), rework.get("lastdjdate"), rework.get("outbagdate"), rework.get("endreminddate"), rework.get("reworking_status_no"), s));
                    } else {
                        spilBagDateZHList.add(new SpliBag(rework.get("bagname"), rework.get("reworking_id"), rework.get("lastdjdate"), rework.get("outbagdate"), rework.get("endreminddate"), rework.get("reworking_status_no"), s));
                    }
                }
            } else {
                if (!operatorInGroupList.contains(rework.get("sys_receiver_sign"))){
                    spilBagDateList.add(new SpliBag(rework.get("bagname"), rework.get("reworking_id"), rework.get("lastdjdate"), rework.get("outbagdate"), rework.get("endreminddate"), rework.get("reworking_status_no"), rework.get("sys_receiver_sign")));
                } else {
                    spilBagDateZHList.add(new SpliBag(rework.get("bagname"), rework.get("reworking_id"), rework.get("lastdjdate"), rework.get("outbagdate"), rework.get("endreminddate"), rework.get("reworking_status_no"), rework.get("sys_receiver_sign")));
                }
            }
        }

        // 大群
        Map<String, List<String>> xzMap = new LinkedHashMap<>(); // 对应新增用户修改单
        Map<String, List<String>> shMap = new LinkedHashMap<>(); // 对应yz用户修改单
        List<String> spBagInfo = new ArrayList<>(); //当前组涉及到的包
        String vBagName = "";
        String vlastdjdate = "";
        String voutbagdate = "";
        for (SpliBag spliBag : spilBagDateList) {
            List<String> tmp_reworkingIdList = new ArrayList<>();
            if (spBagInfo.contains(spliBag.getBagname())) {
                if (spliBag.getReworkingStatusNo().equals("501") || spliBag.getReworkingStatusNo().equals("503")) {
                    tmp_reworkingIdList = new ArrayList<>();
                    if (xzMap.get(spliBag.getSysReceiverSign()) != null){
                        tmp_reworkingIdList = xzMap.get(spliBag.getSysReceiverSign());
                    }
                    tmp_reworkingIdList.add(spliBag.getReworkingID());
                    xzMap.put(spliBag.getSysReceiverSign(), tmp_reworkingIdList);
                } else {
                    tmp_reworkingIdList = new ArrayList<>();
                    if (shMap.get(spliBag.getSysReceiverSign()) != null) {
                        tmp_reworkingIdList = shMap.get(spliBag.getSysReceiverSign());
                    }
                    tmp_reworkingIdList.add(spliBag.getReworkingID());
                    shMap.put(spliBag.getSysReceiverSign(), tmp_reworkingIdList);
                }
            } else {
                if (vBagName.length() > 0) {
                    Map<String, Object> initResult = dingService.initMsg(remindMsg, vBagName, vlastdjdate, voutbagdate, shMap, xzMap);
                    remindMsg = String.valueOf(initResult.get("remindMsg"));
                    phoneList.addAll(TransClassUtil.castList(initResult.get("phoneList"), String.class));
                }
                spBagInfo.add(spliBag.getBagname());
                shMap = new LinkedHashMap<>();
                xzMap = new LinkedHashMap<>();
                vBagName = spliBag.getBagname();
                vlastdjdate = spliBag.getLastdjdate();
                voutbagdate = spliBag.getOutbagdate();
                tmp_reworkingIdList = new ArrayList<>();
                tmp_reworkingIdList.add(spliBag.getReworkingID());
                if (spliBag.getReworkingStatusNo().equals("501") || spliBag.getReworkingStatusNo().equals("503")) {
                    xzMap.put(spliBag.getSysReceiverSign(), tmp_reworkingIdList);
                } else {
                    shMap.put(spliBag.getSysReceiverSign(), tmp_reworkingIdList);
                }
            }
        }

        if (xzMap.size() > 0 || shMap.size() > 0) {
            System.out.println(spilBagDateList.get(spilBagDateList.size() - 1) + spilBagDateList.get(spilBagDateList.size() - 1).getLastdjdate() + spilBagDateList.get(spilBagDateList.size() - 1).getOutbagdate());
            Map<String, Object> initResult = dingService.initMsg(remindMsg, spilBagDateList.get(spilBagDateList.size() - 1).getBagname(), spilBagDateList.get(spilBagDateList.size() - 1).getLastdjdate(), spilBagDateList.get(spilBagDateList.size() - 1).getOutbagdate(), shMap, xzMap);
            remindMsg = String.valueOf(initResult.get("remindMsg"));
            phoneList.addAll(TransClassUtil.castList(initResult.get("phoneList"), String.class));
        }


        // 账户
        xzMap = new LinkedHashMap<>(); // 对应新增用户修改单
        shMap = new LinkedHashMap<>(); // 对应yz用户修改单
        spBagInfo = new ArrayList<>(); //当前组涉及到的包
        vBagName = "";
        vlastdjdate = "";
        voutbagdate = "";

        for (SpliBag spliBag : spilBagDateZHList){
            List<String> tmp_reworkingIdList = new ArrayList<>();
            if (spBagInfo.contains(spliBag.getBagname())) {
                if (spliBag.getReworkingStatusNo().equals("501") || spliBag.getReworkingStatusNo().equals("503")) {
                    tmp_reworkingIdList = new ArrayList<>();
                    if (xzMap.get(spliBag.getSysReceiverSign()) != null){
                        tmp_reworkingIdList = xzMap.get(spliBag.getSysReceiverSign());
                    }
                    tmp_reworkingIdList.add(spliBag.getReworkingID());
                    xzMap.put(spliBag.getSysReceiverSign(), tmp_reworkingIdList);
                } else {
                    tmp_reworkingIdList = new ArrayList<>();
                    if (shMap.get(spliBag.getSysReceiverSign()) != null) {
                        tmp_reworkingIdList = shMap.get(spliBag.getSysReceiverSign());
                    }
                    tmp_reworkingIdList.add(spliBag.getReworkingID());
                    shMap.put(spliBag.getSysReceiverSign(), tmp_reworkingIdList);
                }
            } else {
                if (vBagName.length() > 0) {
                    Map<String, Object> initResult = dingService.initMsg(remindZHMsg, vBagName, vlastdjdate, voutbagdate, shMap, xzMap);
                    remindZHMsg = String.valueOf(initResult.get("remindMsg"));
                    phoneZHList.addAll(TransClassUtil.castList(initResult.get("phoneList"), String.class));
                }
                spBagInfo.add(spliBag.getBagname());
                shMap = new LinkedHashMap<>();
                xzMap = new LinkedHashMap<>();
                vBagName = spliBag.getBagname();
                vlastdjdate = spliBag.getLastdjdate();
                voutbagdate = spliBag.getOutbagdate();
                tmp_reworkingIdList = new ArrayList<>();
                tmp_reworkingIdList.add(spliBag.getReworkingID());
                if (spliBag.getReworkingStatusNo().equals("501") || spliBag.getReworkingStatusNo().equals("503")) {
                    xzMap.put(spliBag.getSysReceiverSign(), tmp_reworkingIdList);
                } else {
                    shMap.put(spliBag.getSysReceiverSign(), tmp_reworkingIdList);
                }
            }
        }

        if (xzMap.size() > 0 || shMap.size() > 0) {
            System.out.println(spilBagDateZHList.get(spilBagDateZHList.size() - 1) + spilBagDateZHList.get(spilBagDateZHList.size() - 1).getLastdjdate() + spilBagDateZHList.get(spilBagDateZHList.size() - 1).getOutbagdate());
            Map<String, Object> initResult = dingService.initMsg(remindZHMsg, spilBagDateZHList.get(spilBagDateZHList.size() - 1).getBagname(), spilBagDateZHList.get(spilBagDateZHList.size() - 1).getLastdjdate(), spilBagDateZHList.get(spilBagDateZHList.size() - 1).getOutbagdate(), shMap, xzMap);
            remindZHMsg = String.valueOf(initResult.get("remindMsg"));
            phoneZHList.addAll(TransClassUtil.castList(initResult.get("phoneList"), String.class));
        }

        // 发送钉钉
        Map<String, String>  result = new HashMap<>();
        // 大群
        Map<String, Object> dingMessageMap = dingService.assemblyDingMessage(remindMsg, phoneList, "质保产品组");
        String msgInfo = JSONObject.toJSONString(dingMessageMap);
        result.put("质保", dingTalkController.sendDingTalk(msgInfo));

        // 账户
        dingMessageMap = dingService.assemblyDingMessage(remindZHMsg, phoneZHList, "业务研发二组");
        msgInfo = JSONObject.toJSONString(dingMessageMap);
        result.put("账户", dingTalkController.sendDingTalk(msgInfo));
        return ResultEntity.successWithData(result).returnResult();
    }


}
