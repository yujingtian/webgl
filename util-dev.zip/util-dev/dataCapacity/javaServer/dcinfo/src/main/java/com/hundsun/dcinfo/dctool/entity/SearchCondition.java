package com.hundsun.dcinfo.dctool.entity;

import lombok.Data;

@Data
public class SearchCondition {
    private Integer pageSize;
    private Integer currentPage;
    private String keywords;
    private String toolName;
    private String series;
    private String userID;
}
