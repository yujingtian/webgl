package com.hundsun.tool.reminders.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.hundsun.dcinfo.jumpToMail.controller.DingTalkController;
import com.hundsun.tool.reminders.service.TsTaskService;
import com.hundsun.tool.utils.CheckDay;
import com.hundsun.tool.utils.DBWorkUtil;
import com.hundsun.tool.utils.HttpClientUtil;
import com.hundsun.tool.utils.ResultEntity;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.awt.*;
import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

/**
 * @Author: kcaumber
 * @Date: 2021/11/8 10:36
 */
@CrossOrigin
@RestController
@RequestMapping("/TsTaskReminder")
public class TsTaskController {

    private static String synTsTaskList = "merge into HS_ASSET.TSTASKLIST a using (\n" +
            "select * from HS_ASSET.TMP_TSTASKLIST b) c on (a.TASK_ID = c.TASK_ID)\n" +
            "when matched then\n" +
            "update set a.MODIFY_VER_NAMES = c.MODIFY_VER_NAMES,\n" +
            "a.PRODUCT_ID = c.PRODUCT_ID, \n" +
            "a.DEMAND_ID = c.DEMAND_ID,\n" +
            "a.ASSIGN_DATE = c.ASSIGN_DATE,\n" +
            "a.COMPLETED_STATUS = c.COMPLETED_STATUS,\n" +
            "a.DESIGNER = c.DESIGNER,\n" +
            "a.EXPECTED_PELEASE_DATE = c.EXPECTED_PELEASE_DATE,\n" +
            "a.FIRST_ASSIGN_DATE = c.FIRST_ASSIGN_DATE,\n" +
            "a.IS_USER_TEST = c.IS_USER_TEST,\n" +
            "a.MODIFY_DATE = c.MODIFY_DATE,\n" +
            "a.MODULE_NAMES = c.MODULE_NAMES,\n" +
            "a.PRODUCT_VERSION_TYPE= c.PRODUCT_VERSION_TYPE,\n" +
            "a.PROGRAMER = c.PROGRAMER,\n" +
            "a.PROMISE_DATE = c.PROMISE_DATE,\n" +
            "a.REAL_DEV_DATE = c.REAL_DEV_DATE,\n" +
            "a.RESULT_REVIEWER = c.RESULT_REVIEWER,\n" +
            "a.SUGESSTION = c.SUGESSTION,\n" +
            "a.TASK_ASSIGNER = c.TASK_ASSIGNER,\n" +
            "a.TASK_DIFFICULTY = c.TASK_DIFFICULTY,\n" +
            "a.TASK_OWNER = c.TASK_OWNER,\n" +
            "a.TASK_REQ_DESC = c.TASK_REQ_DESC,\n" +
            "a.TASK_STATUS = c.TASK_STATUS,\n" +
            "a.TASK_TYPE = c.TASK_TYPE,\n" +
            "a.WORK_ACCOUNT = c.WORK_ACCOUNT\n" +
            "when not matched then\n" +
            "insert (a.TASK_ID, a.MODIFY_VER_NAMES, a.PRODUCT_ID, a.DEMAND_ID, a.ASSIGN_DATE, a.COMPLETED_STATUS, a.DESIGNER, a.EXPECTED_PELEASE_DATE, a.FIRST_ASSIGN_DATE, a.IS_USER_TEST, a.MODIFY_DATE, a.MODULE_NAMES, a.PRODUCT_VERSION_TYPE, a.PROGRAMER, a.PROMISE_DATE, a.REAL_DEV_DATE, a.RESULT_REVIEWER, a.SUGESSTION, a.TASK_ASSIGNER, a.TASK_DIFFICULTY, a.TASK_OWNER, a.TASK_REQ_DESC, a.TASK_STATUS, a.TASK_TYPE, a.WORK_ACCOUNT)\n" +
            "values (c.TASK_ID, c.MODIFY_VER_NAMES, c.PRODUCT_ID, c.DEMAND_ID, c.ASSIGN_DATE, c.COMPLETED_STATUS, c.DESIGNER, c.EXPECTED_PELEASE_DATE, c.FIRST_ASSIGN_DATE, c.IS_USER_TEST, c.MODIFY_DATE, c.MODULE_NAMES, c.PRODUCT_VERSION_TYPE, c.PROGRAMER, c.PROMISE_DATE, c.REAL_DEV_DATE, c.RESULT_REVIEWER, c.SUGESSTION, c.TASK_ASSIGNER, c.TASK_DIFFICULTY, c.TASK_OWNER, c.TASK_REQ_DESC, c.TASK_STATUS, c.TASK_TYPE, c.WORK_ACCOUNT)";

    private static String deleteTmpTaskList = "delete hs_asset.TMP_TSTASKLIST a where a.TASK_ID in (select b.TASK_ID from hs_asset.TSTASKLIST b)";

    private final static Logger LOGGER = Logger.getLogger("com.hundsun.tool.reminders.controller.TsTaskController");

    private final TsTaskService tsTaskService;
    private final DingTalkController dingTalkController;

    public TsTaskController(@Qualifier("tsTaskService") TsTaskService tsTaskService, @Qualifier("dingTalkController") DingTalkController dingTalkController) {
        this.tsTaskService = tsTaskService;
        this.dingTalkController = dingTalkController;
    }


    @RequestMapping("/daily")
    public String daily() throws JsonProcessingException, NoSuchAlgorithmException, InvalidKeyException, UnsupportedEncodingException, SQLException, ParseException {

        String url = "http://10.20.26.231:12222/ts/getTaskListsFromTs";

        List<String> paramList = new ArrayList<>();

        Map<String, String> tsTaskParamMapAcct = new HashMap<>();
        tsTaskParamMapAcct.put("productId", "20151206");
        tsTaskParamMapAcct.put("taskStatus", "2,3,1");
        tsTaskParamMapAcct.put("modifyVerName", "%V202%0%.%.000%");
        tsTaskParamMapAcct.put("expectedReleaseDate", "2021-08-11");
        paramList.add(JSONObject.toJSONString(tsTaskParamMapAcct));

        Map<String, String> tsTaskParamMapOther = new HashMap<>();
        tsTaskParamMapOther.put("productId", "20170403,20160702");
        tsTaskParamMapOther.put("taskStatus", "2,3,1");
        tsTaskParamMapOther.put("modifyVerName", "%V202%0%.%.000%");
        tsTaskParamMapOther.put("expectedReleaseDate", "2021-08-11");

        paramList.add(JSONObject.toJSONString(tsTaskParamMapOther));

        for (String json : paramList){
            String result = HttpClientUtil.doPostJson(url, json);
            JSONObject resultMap = JSON.parseObject(result);
            if (resultMap.getObject("code", Integer.class) != 20000){
                LOGGER.warning("获取最新任务数据失败");
                return ResultEntity.failWithoutData("获取最新任务数据失败").returnResult();
            }

            JSONArray dataJson = resultMap.getJSONArray("data");

//        Tmp_TsTaskList数据库更新
            boolean insertSuccess = tsTaskService.InsertTmpTSTaskList(dataJson);
            if (insertSuccess){
                LOGGER.info("数据库数据更新成功");
            } else {
                LOGGER.warning("数据库数据更新失败");
            }
        }

        DBWorkUtil.ExecDB(synTsTaskList);
        DBWorkUtil.ExecDB(deleteTmpTaskList);

        return sendDing();
    }

    @RequestMapping("/sendDing")
    public String sendDing() throws UnsupportedEncodingException, NoSuchAlgorithmException, InvalidKeyException, JsonProcessingException, ParseException {
        if (CheckDay.checkWorkDay()){
            Map<String, Object> messageMap = tsTaskService.assemblyMessage();

            Map<String, Object> dingMessageMap = tsTaskService.assemblyDingMessage(messageMap);

            dingMessageMap.put("groupName", "质保增量包提醒");

            String msgInfo = JSONObject.toJSONString(dingMessageMap);
            return dingTalkController.sendDingTalk(msgInfo);
        } else {
            return ResultEntity.successWithDataMsg("今天不是工作日", null).returnResult();
        }

    }
}
