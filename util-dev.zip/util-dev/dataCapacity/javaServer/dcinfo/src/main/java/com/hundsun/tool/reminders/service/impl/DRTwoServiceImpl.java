package com.hundsun.tool.reminders.service.impl;

import com.hundsun.tool.reminders.entity.DingPersonInfo;
import com.hundsun.tool.reminders.entity.TSPass;
import com.hundsun.tool.reminders.service.DRTwoService;
import com.hundsun.tool.reminders.service.DingPersonInfoService;
import com.hundsun.tool.utils.DBWorkUtil;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.*;
import java.util.logging.Logger;

/**
 * @Author: kcaumber
 * @Date: 2021/11/10 18:26
 */
@Service("drTwoService")
public class DRTwoServiceImpl implements DRTwoService {

    private static final Logger LOGGER = Logger.getLogger("com.hundsun.tool.reminders.service.impl.DRTwoServiceImpl");

    private final DingPersonInfoService dingPersonInfoService;

    public DRTwoServiceImpl(@Qualifier("dingPersonInfoService") DingPersonInfoService dingPersonInfoService) {
        this.dingPersonInfoService = dingPersonInfoService;
    }

    @Override
    public List<TSPass> getTsPassData() {

        Date currentDate = new Date();
        SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
        // 日期格式
        String firstDateMonthly = format.format(currentDate).substring(0,6) + "01";

        String sqlStr = "select t.mender_no as 工号,\n" +
                "       (select t2.operator_name\n" +
                "          from hs_asset.TsOperators t2\n" +
                "         where t2.operator_no = t.mender_no) as 姓名,\n" +
                "       t.sl as 递交数量,\n" +
                "       t.thsl as 打回修改单数,\n" +
                "       round((t.sl - t.thsl) / t.sl * 100) as 一次性通过率\n" +
                "  from (select a.mender_no,\n" +
                "               count(0) as sl,\n" +
                "               nvl((select count(0) as thsl\n" +
                "                     from hs_asset.tssynproinfo b\n" +
                "                    where b.testdonedate between " + firstDateMonthly + " and\n" +
                "                          (select to_number(to_char(sysdate, 'YYYYMMDD'))\n" +
                "                             from dual)\n" +
                "                      and b.mender_no = a.mender_no\n" +
                "                      and b.test_backs > 0\n" +
                "                      and instr('Y,N,用户测试', b.test_result) > 0\n" +
                "                    group by b.mender_no),\n" +
                "                   0) as thsl\n" +
                "          from hs_asset.tssynproinfo a\n" +
                "         where a.testdonedate between " + firstDateMonthly +"and\n" +
                "               (select to_number(to_char(sysdate, 'YYYYMMDD')) from dual)\n" +
                "           and a.mender_no in (select b.employeecode\n" +
                "                                 from hs_asset.Teammembers b\n" +
                "                                where (b.teamname = '业务研发二组')\n" +
                "                                  )\n" +
                "           and instr('Y,N,用户测试', a.test_result) > 0\n" +
                "         group by a.mender_no) t";

        ArrayList<Map<String, String>> resultList = DBWorkUtil.SelectDB(sqlStr);
        List<TSPass> resList = new ArrayList<>();
        if (resultList == null){
            return null;
        } else {
            for (Map<String, String> result : resultList) {
                TSPass sh = new TSPass();
                sh.setOperatorNo(result.get("工号"));
                sh.setOperatorName(result.get("姓名"));
                sh.setSl(Integer.parseInt(result.get("递交数量")));
                sh.setThsl(Integer.parseInt(result.get("打回修改单数")));
                sh.setPassRate(Integer.parseInt(result.get("一次性通过率")));
                resList.add(sh);
            }
            LOGGER.info("完成对通过率的计算");
        }

        return resList;
    }

    @Override
    public Map<String, Object> assemblyMessage(List<TSPass> tsPassList) {
        Map<String, Object> messageMap = new HashMap<>();
        List<String> phoneNoList = new LinkedList<>();

        String content = "【研发二组小伙伴每月修改单通过率】\n";
        content = content + "时间段\n";
        Date currentDate = new Date();
        SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
        // 日期格式
        String firstDateMonthly = format.format(currentDate).substring(0,6) + "01";

        content = content + firstDateMonthly + " --> " + format.format(currentDate) + "\n";

        if (tsPassList == null || tsPassList.size() == 0){
            content = content + "暂无修改单通过率";
        } else {
            content = content + "修改单通过率:\n";
// 姓名、递交单数、打回修改单数、一次性通过率
            content = content + "姓名           " + "递交单数\t\t" + "打回修改单数\t\t" + "一次性通过率\n";
            for (TSPass tsPass : tsPassList){
                DingPersonInfo dingPerson = dingPersonInfoService.selectByOperatorNo(tsPass.getOperatorNo()).get(0);
                String phoneNo;
                if (dingPerson == null){
                    LOGGER.warning("未找到对应钉钉信息");
                    phoneNo = "000000";
                    content = content + "@" + phoneNo + "    ";
                } else {
                    phoneNo = dingPerson.getDDID();
                    content = content + "@" + phoneNo;
                    for (int i = 0; i < 24 - 4 * dingPerson.getOperatorName().length(); i++){
                        content = content + " ";
                    }
                }
                phoneNoList.add(phoneNo);
                content = content + tsPass.getSl();
                for (int i = 0; i < 9 - String.valueOf(tsPass.getSl()).length(); i++){
                    content = content + "  ";
                }
                content = content + tsPass.getThsl();
                for (int i = 0; i < 11 - String.valueOf(tsPass.getThsl()).length(); i++){
                    content = content + "  ";
                }
                content = content + tsPass.getPassRate() + "%\n";
            }
        }

        messageMap.put("receiveList", phoneNoList);
        messageMap.put("content", content);
        return messageMap;
    }

    @Override
    public Map<String, Object> assemblyDingMessage(Map<String, Object> messageMap) {
        Map<String, Object> dingMessageMap = new HashMap<>();
        dingMessageMap.put("msgtype", "text");
        dingMessageMap.put("content", messageMap.get("content"));
        dingMessageMap.put("receiveList", messageMap.get("receiveList"));
        dingMessageMap.put("isAtAll", false);
        return dingMessageMap;    }
}
