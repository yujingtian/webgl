package com.hundsun.tool.sqltool.util;

import com.alibaba.druid.pool.DruidDataSource;
import com.hundsun.tool.variable.service.api.VariableService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * 数据库连接池的池的管理类，下面会把数据库连接池的池简称为 池
 * @author Star_King
 */
@Component
public class DataSourcesUtil {
    private static final Logger LOGGER = Logger.getLogger("com.hundsun.tool.sqltool.util.DataSourcesUtil");

    private static final List<DruidDataSource> DATA_SOURCES = new ArrayList<>(10);

    private static final List<Integer> MAX_ACTIVE_LIST = new ArrayList<>(10);

    private static final int CORE_NUM = Runtime.getRuntime().availableProcessors();

    private static ThreadPoolExecutor timedThreadPool = new ThreadPoolExecutor(CORE_NUM, 10, 3000,
            TimeUnit.MILLISECONDS, new ArrayBlockingQueue<>(5), new ThreadPoolExecutor.DiscardOldestPolicy());

    public static void setTimedThreadPool(ThreadPoolExecutor timedThreadPool) {
        DataSourcesUtil.timedThreadPool = timedThreadPool;
    }

    public synchronized static boolean addDataSource(DruidDataSource dataSource) {
        if (dataSource.getUrl() == null || dataSource.getUsername() == null) {
            LOGGER.log(Level.WARNING, "要添加的连接池未配置url和用户名！");
            return false;
        }
        DATA_SOURCES.add(dataSource);
        MAX_ACTIVE_LIST.add(dataSource.getMaxActive());
        executeTimedThread(indexOfDataSource(dataSource.getUrl(), dataSource.getUsername()));
        LOGGER.log(Level.INFO, "成功添加了连接池！");
        return true;
    }

    public synchronized static DruidDataSource getDataSource(int index) {
        if (index >= DATA_SOURCES.size() || index < 0) {
            LOGGER.log(Level.WARNING, "下标异常！");
            return null;
        }
        return DATA_SOURCES.get(index);
    }

    public static Integer getLastMaxActive(int index) {
        if (index >= DATA_SOURCES.size() || index < 0) {
            LOGGER.log(Level.WARNING, "下标异常！");
            return null;
        }
        return MAX_ACTIVE_LIST.get(index);
    }

    public static void setLastMaxActive(int index, Integer maxActive) {
        if (index >= DATA_SOURCES.size() || index < 0) {
            LOGGER.log(Level.WARNING, "下标异常！");
            return;
        }
        MAX_ACTIVE_LIST.set(index, maxActive);
    }

    public synchronized static int indexOfDataSource(String url, String username) {
        for (int i = 0; i < DATA_SOURCES.size(); i++) {
            DruidDataSource source = DATA_SOURCES.get(i);
            if (source != null) {
                boolean urlEquals = source.getUrl().equals(url);
                boolean usernameEquals = source.getUsername().equals(username);
                if (urlEquals && usernameEquals) {
                    return i;
                }
            }
        }
        return -1;
    }

    public synchronized static void removeDataSource(int index) {
        if (index >= DATA_SOURCES.size() || index < 0) {
            LOGGER.log(Level.WARNING, "下标异常！");
            return;
        }
        DATA_SOURCES.set(index, null);
        MAX_ACTIVE_LIST.set(index, null);
    }

    private static void executeTimedThread(int index) {
        TimedThread runnable = new TimedThread();
        runnable.setIndex(index);
        timedThreadPool.execute(runnable);
    }
}
