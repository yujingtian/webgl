package com.hundsun.dcinfo.dctool.entity;

import com.hundsun.dcinfo.dctool.entity.Tool;
import com.hundsun.dcinfo.param.entity.ToolParam;
import lombok.Data;

import java.util.List;

@Data
public class ToolParamPojo {
    List<ToolParam> paramList;
    Tool tool;
    String userID;
}
