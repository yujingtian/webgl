package com.hundsun.tool.sqltool.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.hundsun.tool.sqltool.pojo.DcDbServerInfo;
import com.hundsun.tool.sqltool.service.api.DcDbServerInfoService;
import com.hundsun.tool.sqltool.util.JdbcConnectUtil;
import com.hundsun.tool.utils.ResultEntity;
import com.iceolive.util.StringUtil;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.*;

import java.sql.SQLException;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * @author Star_King
 */
@CrossOrigin
@RestController
@RequestMapping("/sql")
public class SqlToolController {
    private static final Logger LOGGER = Logger.getLogger("com.hundsun.tool.sqltool.controller.SqlToolController");

    private final DcDbServerInfoService dcDbServerInfoService;

    public SqlToolController(@Qualifier("dcDbServerInfoService") DcDbServerInfoService dcDbServerInfoService) {
        this.dcDbServerInfoService = dcDbServerInfoService;
    }

    /**
     * 内部调用
     */
    @PostMapping("/connect")
    public String connectTest(@RequestBody Map<String, String> map) throws JsonProcessingException, SQLException {
        String serverAlias = map.get("serverAlias");
        String username = map.get("username");
        String sql = map.get("sql");
        // 参数合法性判断
        if (StringUtil.isBlank(serverAlias) || StringUtil.isBlank(username)) {
            LOGGER.log(Level.WARNING, "入参出错！");
            return ResultEntity.failWithoutData("入参出错！").returnResult();
        }
        serverAlias = serverAlias.trim();
        username = username.trim();
        // 根据别名和用户名查询数据库信息
        DcDbServerInfo info = dcDbServerInfoService.searchDcDbServerInfoByAliasAndUsername(serverAlias, username);
        if (info == null) {
            LOGGER.log(Level.WARNING, "无目标数据库信息！");
            return ResultEntity.failWithoutData("无目标数据库信息！").returnResult();
        }
        return getResult(info, sql);
    }

    /**
     * 外部调用
     */
    @PostMapping("/externalConnect")
    public String externalConnect(@RequestBody Map<String, String> map) throws JsonProcessingException, SQLException {
        String dbIP = map.get("dbIP");
        String dbPort = map.get("dbPort");
        String dbSid = map.get("dbSid");
        String dbName = map.get("dbName");
        String dbType = map.get("dbType");
        String dbUser = map.get("dbUser");
        String dbPwd = map.get("dbPwd");
        DcDbServerInfo dcDbServerInfo = new DcDbServerInfo();
        dcDbServerInfo.setDbIP(dbIP);
        dcDbServerInfo.setDbPort(Integer.parseInt(dbPort));
        if ("0".equals(dbType)) {
            dcDbServerInfo.setDbName(dbName);
        } else {
            dcDbServerInfo.setDbSid(dbSid);
        }
        dcDbServerInfo.setDbPwd(dbPwd);
        dcDbServerInfo.setDbUser(dbUser);
        dcDbServerInfo.setDbType(dbType);

        String sql = map.get("sql");
        return getResult(dcDbServerInfo, sql);
    }

    private String getResult(DcDbServerInfo dcDbServerInfo, String sql) throws JsonProcessingException, SQLException {
        // 测试能否正常连接
        boolean connected = JdbcConnectUtil.connectTest(dcDbServerInfo);
        if (StringUtil.isEmpty(sql)) {
            // 连通性测试
            return JdbcConnectUtil.returnConnectResult(connected);
        } else {
            sql = sql.trim();
            // 执行sql测试
            if (!connected) {
                return JdbcConnectUtil.returnConnectResult(false);
            }
            // 可以连接则执行sql
            return JdbcConnectUtil.executeSelect(dcDbServerInfo, sql);
        }
    }
}
