package com.hundsun.tool.functest.t3.pojo;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @author wenping 2021-08-03 14:16
 */
@Data
public class TestNameVO implements Serializable {
    private static final long serialVersionUID = 8930293847329L;
    private int curPage;
    private int pageSize;
    private int total;
    private List<TestName> testNameList;
}
