package com.hundsun.dcinfo.menu.service;

import com.hundsun.dcinfo.menu.entity.Dcmenu;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author Wanglei
 * @since 2021-07-30
 */
public interface IDcmenuService extends IService<Dcmenu> {
    public List<Dcmenu> getCanSearchByOne();

    public String getOfflineUrl();

    public List<Dcmenu> getMenuList(String keyword, Integer start, Integer end);
}
