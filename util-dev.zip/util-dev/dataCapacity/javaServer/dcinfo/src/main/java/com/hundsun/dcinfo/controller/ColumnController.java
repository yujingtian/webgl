package com.hundsun.dcinfo.controller;

import com.hundsun.dcinfo.util.Result;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@CrossOrigin
@RequestMapping(value = "/data")
public class ColumnController {
    @RequestMapping("/getInfo")
    public Result getInfo(@RequestParam String str) {
        // 结果集封装到Map中
        try {
            Map<String, Object> res = new HashMap<>();
            String[] strArr = str.split("\u0001");
            int columnSum = Integer.parseInt(strArr[0]); // 总列数
            int dataSum = Integer.parseInt(strArr[1]); // 数据行数
            List<String> columns = new ArrayList<>(); // 列名列表
            int start = 2;
            int end = start + columnSum;
            for (int i = start; i < end; i++) {
                columns.add(strArr[i]);
            }
            res.put("column", columns);
            if (dataSum <= 0) {
                res.put("record", null);
            } else {
                // 数据存储每行记录的开始和结束位置
                int[][] info = new int[dataSum][2];
                for (int i = 0; i < dataSum; i++) {
                    start = end;
                    end = start + columnSum;
                    info[i][0] = start;
                    info[i][1] = end;
                }
                // 记录每行数据的列表集合
                List<List<String>> data = new ArrayList<>();
                for (int i = 0; i < info.length; i++) {
                    List<String> strings = new ArrayList<>();
                    for (int s = info[i][0]; s < info[i][1]; s++) {
                        strings.add(strArr[s]);
                    }
                    data.add(strings);
                }
                res.put("record", data);
            }
            return new Result(true, "查询成功！", res);
        } catch (ArrayIndexOutOfBoundsException e) {
            return new Result(false, "参数错误！", null);
        }
    }
}