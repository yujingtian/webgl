package com.hundsun.dcinfo.param.entity;

import lombok.Data;

import java.util.List;

@Data
public class ParamList {
    List<ToolParam> list;
}
