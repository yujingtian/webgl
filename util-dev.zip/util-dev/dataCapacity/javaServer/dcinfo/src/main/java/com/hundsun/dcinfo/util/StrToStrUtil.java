package com.hundsun.dcinfo.util;

public class StrToStrUtil {
    public static String strToStrWithoutHeadZero(String str) {
        return Integer.parseInt(str) + "";
    }
}
