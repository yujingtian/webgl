package com.hundsun.tool.sqltool.exception;

import java.io.PrintStream;
import java.io.PrintWriter;

/**
 * @author Star_King
 */
public class NoSuchVariableException extends RuntimeException {
    public NoSuchVariableException() {
    }

    public NoSuchVariableException(String message) {
        super(message);
    }

    public NoSuchVariableException(String message, Throwable cause) {
        super(message, cause);
    }

    public NoSuchVariableException(Throwable cause) {
        super(cause);
    }

    public NoSuchVariableException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

    @Override
    public void printStackTrace(PrintStream s) {
        super.printStackTrace(s);
    }

    @Override
    public void printStackTrace(PrintWriter s) {
        super.printStackTrace(s);
    }
}
