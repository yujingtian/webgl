package com.hundsun.tool.functest.t3.pojo;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * 对应表细节
 * @author wenping 2021-07-20 14:37
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@TableName("DCTTHREETEST")
public class TThreeTest implements Serializable {
    private static final long serialVersionUID = 8930293847393L;

    @JsonIgnore
    @TableField(value = "TEST_ID")
    private Integer testID;
    @TableField(value = "SERVICE_NAME")
    private String serviceName;
    @TableField(value = "FUNC_NUM_STR")
    private String funcNumStr;
    @TableField(value = "PARAMETER")
    private String parameter;
    @TableField(value = "ORD")
    private int ord;
}
