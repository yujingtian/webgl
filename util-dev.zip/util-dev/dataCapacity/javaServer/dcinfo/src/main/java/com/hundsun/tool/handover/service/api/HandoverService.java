package com.hundsun.tool.handover.service.api;

import com.hundsun.tool.handover.pojo.Handover;

import java.util.List;

/**
 * @author Star_King
 */
public interface HandoverService {
    /**
     * 查询全部Handover表记录
     * @return Handover对象列表
     */
    List<Handover> searchAllHandover();

    /**
     * 查询全部带有USER_ID字段的Handover记录
     * @return Handover对象列表
     */
    List<Handover> searchAllHasUser();

    /**
     * 根据表名查询Handover表记录
     * @param tableName 表名
     * @return Handover对象
     */
    Handover searchHandoverByName(String tableName);

    /**
     * 根据表别名查询Handover表记录
     * @param tableAlias 表别名
     * @return Handover对象
     */
    Handover searchHandoverByAlias(String tableAlias);

    /**
     * 根据表名和别名联合查询Handover表记录
     * @param tableName 表名
     * @param tableAlias 别名
     * @return Handover对象
     */
    Handover searchHandoverByNameAndAlias(String tableName, String tableAlias);

    /**
     * 添加一行Handover记录
     * @param handover Handover对象
     * @return 添加成功标志
     */
    boolean addHandover(Handover handover);

    /**
     * 根据表名删除一条Handover记录
     * @param tableName 表名
     * @return 删除成功标志
     */
    boolean removeHandoverByName(String tableName);

    /**
     * 根据别名删除一行Handover记录
     * @param tableAlias 别名
     * @return 删除成功标志
     */
    boolean removeHandoverByAlias(String tableAlias);

    /**
     * 更新一条Handover记录
     * @param handover Handover对象
     * @return 更新成功标志
     */
    boolean changeHandover(Handover handover);

    /**
     * 判断数据库中是否存在该表
     * @param tableName 表名
     * @return 存在的标志
     */
    boolean existTable(String tableName);

    /**
     * 判断表中是否含有某一列
     * @param tableName 表名
     * @param column 列名
     * @return 存在的标志
     */
    boolean existColumn(String tableName, String column);

    /**
     * 修改tableName表的USER_ID字段
     * @param oldUserID 旧值
     * @param newUserID 新值
     * @param tableName 表名
     * @param columnName 列名
     * @return 修改成功标志
     */
    boolean changeTable(String oldUserID, String newUserID, String tableName, String columnName);
}
