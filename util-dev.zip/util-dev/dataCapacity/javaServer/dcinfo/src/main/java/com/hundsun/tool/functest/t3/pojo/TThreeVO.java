package com.hundsun.tool.functest.t3.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * 对应测试用例详细页面字段
 * @author wenping 2021-08-03 9:50
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TThreeVO implements Serializable {
    private static final long serialVersionUID = 8930293847399L;
    private String testName;
    private String groupAlias;
    private String userID;
    private String testServer;
    private String shardingInfo;
    private String security;
    private List<TThreeTest> tThreeTestList;
}
