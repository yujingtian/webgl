package com.hundsun.dcinfo.series.mapper;

import com.hundsun.dcinfo.series.entity.Series;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.math.BigDecimal;
import java.util.List;

/**
 * <p>
 * Mapper 接口
 * </p>
 *
 * @author Wanglei
 * @since 2021-07-15
 */
@Mapper
public interface SeriesMapper extends BaseMapper<Series> {
    @Select("select HS_ASSET.DCSERIESINFO_ID_SEQ.nextval from dual")
    public BigDecimal getNextIdByDual();

    @Select("SELECT * FROM HS_ASSET.DCSERIESINFO WHERE UPPER(SER_NAME) = #{serName} and PARENT_ID = #{pId}")
    public List<Series> isCanAddThisName(String serName, BigDecimal pId);

    @Select("SELECT VARIABLE_VALUE FROM HS_ASSET.DCVARIABLEINFO WHERE VARIABLE_NAME = #{str}")
    public String getRemoteUrl(String str);

    @Select("SELECT VARIABLE_VALUE FROM HS_ASSET.DCVARIABLEINFO WHERE VARIABLE_NAME ='tool_update_is_delete_dat_file'")
    public String getUpdateIsDeleteDatFile();
}
