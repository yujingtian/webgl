package com.hundsun.tool.uf3Dictionary.entity;

import lombok.Data;

import java.util.Comparator;
import java.util.Objects;

/**
 * @Author tdragon.
 * @Date 2021/8/23.
 * @Time 20:40
 * @Description:
 */

@Data
public class UF2_Dictionary implements Comparator<UF2_Dictionary> {
    /** 字典编号 */
    private   String dicItem;
    /** 字典名 总的名字*/
    private   String itemDesc;
    /** 子项编号 */
    private String childItem;
    /** 子项名 描述*/
    private   String desc;

    /** 按照字符串升序 */
    @Override
    public int compare(UF2_Dictionary o1, UF2_Dictionary o2) {
        return o1.getDicItem().compareTo(o2.getDicItem());
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof UF2_Dictionary)) return false;
        UF2_Dictionary that = (UF2_Dictionary) o;
        return Objects.equals(dicItem, that.dicItem) &&
                Objects.equals(itemDesc, that.itemDesc) &&
                Objects.equals(childItem, that.childItem) &&
                Objects.equals(desc, that.desc);
    }

    @Override
    public int hashCode() {
        return Objects.hash(dicItem, itemDesc, childItem, desc);
    }
}
