package com.hundsun.dcinfo.friendlylink.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.hundsun.dcinfo.friendlylink.pojo.FriendlyLink;
import com.hundsun.dcinfo.friendlylink.service.api.FriendlyLinkService;
import com.hundsun.tool.utils.ResultEntity;
import com.iceolive.util.StringUtil;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * @author Star_King
 */
@CrossOrigin
@RestController
@RequestMapping("/friendlyLink")
public class FriendlyLinkController {
    private final FriendlyLinkService friendlyLinkService;

    /**
     * 使用了日志进行打印操作结果
     */
    private static final Logger LOGGER = Logger.getLogger("com.hundsun.dcinfo.friendlylink.controller.FriendlyLinkController");

    public FriendlyLinkController(@Qualifier("friendlyLinkService") FriendlyLinkService friendlyLinkService) {
        this.friendlyLinkService = friendlyLinkService;
    }

    private static final Lock LOCK = new ReentrantLock();

    /**
     * 根据用户ID查询友情链接，当传入userID时，查询到的是 基础链接+自定义链接，不传入userID时，查询到的是基础链接
     *
     * @param userID 用户ID，用于权限控制
     * @return 查询结果集
     */
    @PostMapping("/retrieveFriendlyLinkByUserID")
    public synchronized String retrieveFriendlyLinkByUserID(@RequestParam(value = "userID", defaultValue = "") String userID) throws JsonProcessingException {
        List<FriendlyLink> links;
        if (!StringUtil.isBlank(userID)) {
            // userID不传空，根据用户ID查询链接
            userID = userID.trim();
            try {
                userID = Integer.parseInt(userID) + "";
            } catch (NumberFormatException e) {
                return ResultEntity.failWithoutData("用户ID异常！").returnResult();
            }
            // 根据用户ID查询链接
            links = friendlyLinkService.searchFriendlyLinkByUserID(userID);
        } else {
            // userID传空值，查询全部基础链接
            links = friendlyLinkService.searchAllBasicLink();
        }
        return ResultEntity.successWithData(links).returnResult();
    }

    /**
     * 创建友情链接，其中链接名和链接地址为必须要传的
     */
    @PostMapping("/createFriendlyLink")
    public String createFriendlyLink(@RequestParam(value = "userID", defaultValue = "") String userID,
                                     @RequestParam(value = "friendName", defaultValue = "") String friendName,
                                     @RequestParam(value = "friendHref", defaultValue = "") String friendHref,
                                     @RequestParam(value = "iconHref", defaultValue = "") String iconHref,
                                     @RequestParam(value = "hrefAlias", defaultValue = "") String hrefAlias) throws JsonProcessingException {
        // 对userID处理
        if (!StringUtil.isBlank(userID)) {
            userID = userID.trim();
            try {
                userID = Integer.parseInt(userID) + "";
            } catch (NumberFormatException e) {
                return ResultEntity.failWithoutData("用户ID异常！").returnResult();
            }
        }
        friendName = (friendName == null ? null : friendName.trim());
        friendHref = (friendHref == null ? null : friendHref.trim());
        iconHref = (iconHref == null ? null : iconHref.trim());
        hrefAlias = (hrefAlias == null ? null : hrefAlias.trim());
        // 参数合法性判定
        if (StringUtil.isEmpty(friendName) || StringUtil.isEmpty(friendHref)) {
            LOGGER.log(Level.WARNING, "创建友情链接参数异常！");
            return ResultEntity.failWithoutData("参数异常！").returnResult();
        }
        // 查询当前数据库中有没有同名的自定义链接
        FriendlyLink link1 = friendlyLinkService.searchLinkByNameAndUserID(friendName, userID);
        // 如果有就返回消息
        if (link1 != null) {
            LOGGER.log(Level.WARNING, "数据库中已有同名链接！");
            return ResultEntity.failWithoutData("已有同名链接！").returnResult();
        }
        // 查询当前数据库中有没有同名的基础且关联的链接
        FriendlyLink link2 = friendlyLinkService.searchLinkByNameAndFlag(friendName, 1);
        if (link2 != null && (link2.getUserID() == null || !link2.getUserID().matches(".*" + userID + ".*"))){
            LOGGER.log(Level.WARNING, "数据库中已有同名链接！");
            return ResultEntity.failWithoutData("已有同名链接！").returnResult();
        }
        // 查询最后一个自定义链接的序号
        Integer friendOrder = friendlyLinkService.searchLastFriendlyOrder();
        if (friendOrder == null) {
            friendOrder = 10;
        }
        // 如果没有查到，则默认从11开始
        friendOrder++;
        FriendlyLink friendlyLink;
        if (StringUtil.isBlank(userID)) {
            friendlyLink = new FriendlyLink(friendName, friendHref, null, iconHref, hrefAlias, null, 1);
        } else {
            friendlyLink = new FriendlyLink(friendName, friendHref, userID, iconHref, hrefAlias, friendOrder, 0);
        }
        boolean success = friendlyLinkService.addFriendlyLink(friendlyLink);
        // 添加成功或失败都返回消息
        if (!success) {
            LOGGER.log(Level.WARNING, "创建友情链接失败！");
            return ResultEntity.failWithoutData("创建友情链接失败！").returnResult();
        } else {
            LOGGER.log(Level.INFO, "创建友情链接成功！");
            return ResultEntity.successWithoutData().returnResult();
        }
    }

    /**
     * 鉴于用户无权限删除其他用户的链接，故加上了权限控制
     *
     * @param userID     用户ID
     * @param friendName 友情链接名
     */
    @PostMapping("/deleteFriendlyLinkByFriendName")
    public String deleteFriendlyLink(@RequestParam(value = "userID", defaultValue = "") String userID,
                                     @RequestParam(value = "friendName", defaultValue = "") String friendName) throws JsonProcessingException {
        if (!StringUtil.isBlank(userID)) {
            userID = userID.trim();
            try {
                userID = Integer.parseInt(userID) + "";
            } catch (NumberFormatException e) {
                return ResultEntity.failWithoutData("用户ID异常！").returnResult();
            }
        }
        friendName = (friendName == null ? null : friendName.trim());
        // 参数合法性判断
        if (StringUtil.isEmpty(friendName)) {
            LOGGER.log(Level.WARNING, "删除友情链接时参数错误！");
            return ResultEntity.failWithoutData("参数错误！").returnResult();
        }
        // 查询数据库中是否有同名自定义链接
        FriendlyLink link1 = friendlyLinkService.searchLinkByNameAndUserID(friendName, userID);
        // 查询数据库内是否有同名的基础链接
        FriendlyLink link2 = friendlyLinkService.searchLinkByNameAndFlag(friendName, 1);
        if (link1 == null){
            if (link2 == null){
                return ResultEntity.failWithoutData("用户无该记录！").returnResult();
            } else {
                if (link2.getUserID() != null && link2.getUserID().matches(".*" + userID + ".*")){
                    return ResultEntity.failWithoutData("用户无该记录！").returnResult();
                } else {
                    if (friendlyLinkService.addUserID(friendName, userID)){
                        LOGGER.log(Level.INFO, "删除友情链接成功！");
                        return ResultEntity.successWithoutData().returnResult();
                    } else {
                        LOGGER.log(Level.WARNING, "删除友情链接失败！");
                        return ResultEntity.failWithoutData("删除友情链接失败！").returnResult();
                    }
                }
            }
        } else {
            boolean success = friendlyLinkService.removeFriendlyLinkByNameAndUserID(friendName, userID);
            // 删除成功或失败都返回消息
            if (!success) {
                LOGGER.log(Level.WARNING, "删除友情链接失败！");
                return ResultEntity.failWithoutData("删除友情链接失败！").returnResult();
            } else {
                LOGGER.log(Level.INFO, "删除友情链接成功！");
                return ResultEntity.successWithoutData().returnResult();
            }
        }
    }

    /**
     * 与删除一样，需要权限控制
     */
    @PostMapping("/updateFriendlyLink")
    public String updateFriendlyLink(@RequestParam(value = "userID", defaultValue = "") String userID,
                                     @RequestParam(value = "friendName", defaultValue = "") String friendName,
                                     @RequestParam(value = "friendHref", defaultValue = "") String friendHref,
                                     @RequestParam(value = "iconHref", defaultValue = "") String iconHref,
                                     @RequestParam(value = "hrefAlias", defaultValue = "") String hrefAlias) throws JsonProcessingException {
        if (!StringUtil.isBlank(userID)) {
            userID = userID.trim();
            try {
                userID = Integer.parseInt(userID) + "";
            } catch (NumberFormatException e) {
                return ResultEntity.failWithoutData("用户ID异常！").returnResult();
            }
        }
        friendName = (friendName == null ? null : friendName.trim());
        friendHref = (friendHref == null ? null : friendHref.trim());
        iconHref = (iconHref == null ? null : iconHref.trim());
        hrefAlias = (hrefAlias == null ? null : hrefAlias.trim());
        // 参数合法性判断
        if (StringUtil.isEmpty(friendName) || StringUtil.isEmpty(friendHref)) {
            LOGGER.log(Level.WARNING, "修改友情链接参数错误！");
            return ResultEntity.failWithoutData("参数错误！").returnResult();
        }
        // 查询最后一个自定义链接的序号
        Integer friendOrder = friendlyLinkService.searchLastFriendlyOrder();
        if (friendOrder == null) {
            friendOrder = 10;
        }
        // 如果没有查到，则默认从11开始
        friendOrder++;
        FriendlyLink link = new FriendlyLink(friendName, friendHref, userID, iconHref, hrefAlias, friendOrder, 0);

        // 查询数据库中是否有同名链接
        FriendlyLink link1 = friendlyLinkService.searchLinkByNameAndUserID(friendName, userID);
        FriendlyLink link2 = friendlyLinkService.searchLinkByNameAndFlag(friendName, 1);
        if (link1 == null){
            if (link2 == null){
                return ResultEntity.failWithoutData("用户无该记录！").returnResult();
            } else {
                if (link2.getUserID() != null && link2.getUserID().matches(".*" + userID + ".*")){
                    return ResultEntity.failWithoutData("用户无该记录！").returnResult();
                } else {
                    Boolean b1 = friendlyLinkService.addUserID(friendName, userID);
                    Boolean b2 = friendlyLinkService.addFriendlyLink(link);
                    if (b1 && b2){
                        LOGGER.log(Level.INFO, "修改友情链接成功！");
                        return ResultEntity.successWithoutData().returnResult();
                    } else {
                        LOGGER.log(Level.WARNING, "修改友情链接失败！");
                        return ResultEntity.failWithoutData("修改友情链接失败！").returnResult();
                    }
                }
            }
        } else {
            boolean success = friendlyLinkService.changeFriendlyLink(link);
            // 更新成功或失败都返回消息
            if (!success) {
                LOGGER.log(Level.WARNING, "修改友情链接失败！");
                return ResultEntity.failWithoutData("修改友情链接失败！").returnResult();
            } else {
                LOGGER.log(Level.INFO, "修改友情链接成功！");
                return ResultEntity.successWithoutData().returnResult();
            }
        }
    }

    @PostMapping("/exchangeOrder")
    public String exchangeOrder(@RequestParam("userID") String userID,
                                @RequestParam("nameList") List<String> nameList) throws JsonProcessingException {


        LOCK.lock();
        try{
            Boolean b = friendlyLinkService.updateOrder(userID, nameList.toString().substring(1, nameList.toString().length() - 1));
            if (!b){
                LOGGER.warning("修改序号失败！");
                return ResultEntity.failWithoutData("修改序号失败！").returnResult();
            }
        } finally {
            LOCK.unlock();
        }
            LOGGER.warning("修改序号成功！");
            return ResultEntity.successWithoutData().returnResult();
    }
}
