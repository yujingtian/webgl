package com.hundsun.tool.reminders.controller;

import com.alibaba.fastjson.JSONObject;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.hundsun.dcinfo.jumpToMail.controller.DingTalkController;
import com.hundsun.tool.reminders.entity.TSPass;
import com.hundsun.tool.reminders.service.BOPService;
import com.hundsun.tool.utils.CheckDay;
import com.hundsun.tool.reminders.util.getTSPass;
import com.hundsun.tool.utils.ResultEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.*;

import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

/**
 * @Author: kcaumber
 * @Date: 2021/11/1 16:31
 */
@CrossOrigin
@RestController
@RequestMapping("/BOPReminder")
public class BOPController {

    private static final Logger LOGGER = Logger.getLogger("com.hundsun.tool.reminders.controller.BOPController");

    private final BOPService bopService;

    @Autowired
    private DingTalkController dingTalkController;

    public BOPController(@Qualifier("bopService") BOPService bopService, DingTalkController dingTalkController) {
        this.bopService = bopService;
    }

    @RequestMapping("/monthly")
    public String monthly(@RequestParam(value = "dayNum", defaultValue = "") String dayNum) throws JsonProcessingException, NoSuchAlgorithmException, InvalidKeyException, UnsupportedEncodingException {

        if ("".equals(dayNum) || CheckDay.checkLastWorkDay(dayNum)){
            if (CheckDay.checkWorkDay()){
                getTSPass rsTP = new getTSPass();
                List<TSPass> tsPassList = rsTP.getRs();

                if (tsPassList == null || tsPassList.size() == 0){
                    LOGGER.warning("未查到数据");
                }

                Map<String, Object> messageMap = bopService.assemblyMessage(tsPassList);

                Map<String, Object> dingMessageMap = bopService.assemblyDingMessage(messageMap);
                dingMessageMap.put("groupName", "BOP业务组");
                String msgInfo = JSONObject.toJSONString(dingMessageMap);

                return dingTalkController.sendDingTalk(msgInfo);
            } else {
                return ResultEntity.failWithoutData("今天不是工作日").returnResult();
            }
        } else {
            return ResultEntity.failWithoutData("今天不是最后" + dayNum + "个工作日之一").returnResult();
        }

    }
}
