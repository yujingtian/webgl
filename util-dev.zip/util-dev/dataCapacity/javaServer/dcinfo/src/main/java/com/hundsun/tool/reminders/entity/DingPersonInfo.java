package com.hundsun.tool.reminders.entity;

/**
 * @Author: kcaumber
 * @Date: 2021/11/9 9:59
 */
public class DingPersonInfo {
    private String operatorNo;
    private String operatorName;
    private String DDID;

    public DingPersonInfo() {
    }

    public DingPersonInfo(String operatorNo, String operatorName, String DDID) {
        this.operatorNo = operatorNo;
        this.operatorName = operatorName;
        this.DDID = DDID;
    }

    public String getOperatorNo() {
        return operatorNo;
    }

    public void setOperatorNo(String operatorNo) {
        this.operatorNo = operatorNo;
    }

    public String getOperatorName() {
        return operatorName;
    }

    public void setOperatorName(String operatorName) {
        this.operatorName = operatorName;
    }

    public String getDDID() {
        return DDID;
    }

    public void setDDID(String DDID) {
        this.DDID = DDID;
    }

    @Override
    public String toString() {
        return "DingPersonInfo{" +
                "operatorNo='" + operatorNo + '\'' +
                ", operatorName='" + operatorName + '\'' +
                ", DDID='" + DDID + '\'' +
                '}';
    }
}
