package com.hundsun.dcinfo.file.controller;

import cn.hutool.core.util.IdUtil;
import com.hundsun.dcinfo.util.Result;
import com.iceolive.util.StringUtil;
import oracle.jdbc.proxy.annotation.Post;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/file")
@CrossOrigin
public class FileController {

    // 文件上传目录
    @Value("${fileDirPath}")
    private String fileDirPath;

    /**
     * 文件上传的接口，返回结果包括所在的服务器路径
     *
     * @param file 前端上传时的文件名
     * @return 处理结果
     */
    @PostMapping("/upload")
    public Result uploadFile(@RequestParam("file") MultipartFile file, @RequestParam(value = "originalFileName", defaultValue = "") String originalFileName) {
        File fileDir = new File(fileDirPath);
        // 文件夹不存在就创建文件夹
        if (!fileDir.exists()) {
            fileDir.mkdirs();
        }
        String oldFileName;// 上传的文件名
        String newFileName;// 新文件名带后缀
        String finalPath;// 路径+文件名
        try {
            // 原始资源文件名
            oldFileName = file.getOriginalFilename();

            if (!StringUtil.isEmpty(originalFileName)){
                assert oldFileName != null;
                String name = originalFileName + IdUtil.simpleUUID();
                if (name.length() > 40){
                    name = name.substring(0, 40);
                }
                newFileName =  name + oldFileName.substring(oldFileName.lastIndexOf('.'));
            }else {
                // 随机生成UUID文件名，并转成大写
                assert oldFileName != null;
                newFileName = IdUtil.simpleUUID() + oldFileName.substring(oldFileName.lastIndexOf('.'));
            }


            // 最终文件名
            finalPath = fileDirPath + newFileName;
            file.transferTo(new File(finalPath));
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return new Result(false, "上传失败！", null);
        }
        File newFile = new File(finalPath);
        if (!newFile.exists()) {
            // 最后判断文件是否存在目录中
            return new Result(false, "上传失败！", null);
        } else {
            // 返回路径
            return new Result(true, "上传成功!", newFileName);
        }
    }

    /**
     * 下载文件接口
     */
    @RequestMapping("/getFile")
    public Result downloadFile(HttpServletResponse response, String fileName) {
        if (fileName == null || "".equals(fileName)) {
            return new Result(false, "参数错误！", null);
        }
        fileName = fileDirPath + fileName;
        try {
            // filePath是指欲下载的文件的路径。
            File file = new File(fileName);
            if (!file.exists()) {
                return new Result(false, "不存在该文件！", null);
            }
            // 取得文件名。
            String filename = file.getName();
            // 取得文件的后缀名。
            String ext = filename.substring(filename.lastIndexOf(".") + 1).toUpperCase();
            // 以流的形式下载文件。
            InputStream fis = new BufferedInputStream(new FileInputStream(fileName));
            byte[] buffer = new byte[fis.available()];
            fis.read(buffer);
            fis.close();
            // 清空response
            response.reset();
            // 设置response的Header
            response.addHeader("Content-Disposition", "attachment;filename=" + new String(filename.getBytes()));
            response.addHeader("Content-Length", "" + file.length());
            response.addHeader("Access-Control-Allow-Origin", "*");
            OutputStream toClient = new BufferedOutputStream(response.getOutputStream());
            response.setContentType("application/octet-stream");
            toClient.write(buffer);
            toClient.flush();
            toClient.close();
        } catch (IOException e) {
            return new Result(false, "服务端异常！", null);
        }
        return null;
    }


    /**
     * 根据传入的路径删除文件或者目录
     *
     * @param fileName 文件名
     * @return 返回结果-
     */
    @RequestMapping("/deleteOneFile")
    public Result delFileByPath(@RequestParam String fileName) {
        fileName = fileDirPath + fileName;
        File file = new File(fileName);
        if (!file.exists()) {
            return new Result(false, "文件不存在或已被删除！", null);
        }
        if (file.isDirectory()) {
            return new Result(false, "目录不能删除！", null);
        }
        if (file.delete()) {
            return new Result(true, "删除成功！", null);
        } else {
            return new Result(false, "删除失败！", null);
        }
    }

    /**
     * 删除文件，若参数为目录，递归删除该目录下所有文件
     *
     * @param dir File对象
     * @return 返回处理结果
     */
    private static boolean deleteDir(File dir) {
        if (dir.isDirectory()) {
            String[] children = dir.list();
            //递归删除目录中的子目录下
            for (int i = 0; i < children.length; i++) {
                boolean success = deleteDir(new File(dir, children[i]));
                if (!success) {
                    return false;
                }
            }
        }
        // 目录此时为空，可以删除
        return dir.delete();
    }

    @PostMapping("/deleteAllFileByName")
    public Result deleteAllFileByName(String fileName, String suffix){
        File fileDir = new File(fileDirPath);
        if (!fileDir.exists()){
            return new Result(false, "该目录不存在！", null);
        }
        File[] fileList = fileDir.listFiles();
        if (!StringUtil.isEmpty(fileName)){
            for (int i = 0; i < fileList.length; i++){
                if (fileList[i].getName().matches(fileName + ".*") && fileList[i].getName().toLowerCase().matches(".*" + suffix.toLowerCase())){
                    if (!fileList[i].delete()){
                        return new Result(false, "删除文件" + fileList[i].getName() + "失败！", null);
                    }
                }
            }
        }
        return new Result(true, "删除成功！", null);

    }
}
