package com.hundsun.dcinfo.series.entity;

import java.math.BigDecimal;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 
 * </p>
 *
 * @author Wanglei
 * @since 2021-07-15
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("DCSERIESINFO")
public class Series implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId("SER_ID")
    private BigDecimal serId;

    @TableField("SER_NAME")
    private String serName;

    @TableField("PARENT_ID")
    private BigDecimal parentId;

    @TableField("REMARK")
    private String remark;


}
