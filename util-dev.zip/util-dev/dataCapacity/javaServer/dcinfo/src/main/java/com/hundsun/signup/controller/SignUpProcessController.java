package com.hundsun.signup.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.extension.api.R;
import com.hundsun.common.mapper.UserMapper;
import com.hundsun.dcinfo.util.Result;
import com.hundsun.jrescloud.common.util.StringUtils;
import com.hundsun.signup.exception.SignUpException;
import com.hundsun.signup.pojo.SignUpUserInfo;
import com.hundsun.signup.service.SignUpUserInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.Collections;
import java.util.List;


/**
 * @author wenping 2021-07-30 13:38
 */
@RestController
@CrossOrigin
@RequestMapping("/signup")
public class SignUpProcessController {

    @Value("${mailServerUrl}")
    private String mailServerUrl;

    @Autowired
    private SignUpUserInfoService signUpService;

    @Autowired
    private UserMapper userMapper;

    /**
     * 预注册处理
     * @param jsonStr
     * @return
     */
    @PostMapping("/process")
    @ResponseBody
    public Result process(@RequestBody String jsonStr, HttpServletRequest request, HttpServletResponse response) {
        JSONObject retJson = null;
        try {
            // 信息预处理
            retJson = signUpService.process(jsonStr);
        } catch (SignUpException e) {
            e.printStackTrace();
            return new Result(false, e.getMessage(), null);
        }
        if (retJson == null) {
            return new Result(false, "发送邮件或者钉钉失败！管理员正在调试，请稍后再试！", null);
        }
        // 设置response转发到发送邮件和钉钉消息的url处理
        response.setCharacterEncoding("UTF-8");
        response.setContentType("application/json;charset=utf-8");
        try {
            // 地址中带有中文，必须经过编码
            String encodeInfo = URLEncoder.encode(retJson.toJSONString(), "UTF-8");
            try {
            response.sendRedirect(mailServerUrl + "?jsonStr=" + encodeInfo);
            } catch (IOException e) {
                e.printStackTrace();
                return new Result(false, "发送邮件或者钉钉失败！管理员正在调试，请稍后再试！", null);
            }
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
            return new Result(false, "发送邮件或者钉钉失败！管理员正在调试，请稍后再试！", null);
        }
        return new Result(true, "注册成功！领导审核后，再登录", null);
    }

    /**
     * 收到处理后的反馈信息，更新状态并将预注册表内用户删除，并更新到DCUSERS表中
     * @param jsonStr
     * @return
     */
    @PostMapping("/handleResult")
    public Result receiveProcessResult(@RequestBody String jsonStr) {
        if (StringUtils.isEmpty(jsonStr)) {
            return new Result(false, "未选择任何数据", null);
        }
        JSONObject jsonObject = JSON.parseObject(jsonStr);
        List userList = jsonObject.getObject("userIDList", List.class);
        if (CollectionUtils.isEmpty(userList)) {
            return new Result(false, "未选择任何数据", null);
        }
        try {
            signUpService.receiveHandle(userList);
            return new Result(true, "处理成功", null);
        } catch (SignUpException e) {
            return new Result(false, e.getMessage(), null);
        }
    }

    @PostMapping("/showUsers")
    public Result showUsers(@RequestParam("userID") String userID,
                            @RequestParam(value = "curPage", defaultValue = "1") int curPage,
                            @RequestParam(value = "pageSize", defaultValue = "10") int pageSize) {
        if (StringUtils.isEmpty(userID)) {
            return new Result(false, "审核人ID不能为空！", null);
        }
        try {
            JSONObject retJson = signUpService.showUsers(userID, curPage, pageSize);
            if (retJson == null) {
                return new Result(true, "未查询到数据！", null);
            }
            return new Result(true, "查询成功", retJson);
        } catch (SignUpException e) {
            return new Result(false, e.getMessage(), null);
        }
    }

    @PostMapping("/reject")
    public Result reject(@RequestBody String jsonStr) {
        if (StringUtils.isEmpty(jsonStr)) {
            return new Result(false, "未选择任何数据", null);
        }
        JSONObject jsonObject = JSON.parseObject(jsonStr);
        List userList = jsonObject.getObject("userIDList", List.class);
        if (CollectionUtils.isEmpty(userList)) {
            return new Result(false, "未选择任何数据", null);
        }
        try {
            signUpService.reject(userList);
            return new Result(true, "处理成功", null);
        } catch (SignUpException e) {
            return new Result(false, e.getMessage(), null);
        }

    }
    /**
     * 测试重定向后的的参数处理
     * @param jsonStr
     * @return
     * */
    /*@GetMapping("/mailUrlTest")
    public Result mailUrlTest(@RequestParam("jsonStr") String jsonStr) {
        try {
            // 必须要解码
            String decodeInfo = URLDecoder.decode(jsonStr, "UTF-8");
            System.out.println("decodeInfo=" + new String(jsonStr));
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return new Result(true, "mailUrlTest成功", null);
    }*/

}
