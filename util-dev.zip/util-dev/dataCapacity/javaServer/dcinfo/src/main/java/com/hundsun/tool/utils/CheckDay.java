package com.hundsun.tool.utils;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * @Author: kcaumber
 * @Date: 2021/11/2 15:30
 */
public class CheckDay {

    public static boolean checkLastWorkDay(String dayNum) {
        Calendar cal1 = Calendar.getInstance();
        int month = cal1.get(Calendar.MONTH) + 1;
        int year = cal1.get(Calendar.YEAR);
        int day = cal1.get(Calendar.DATE);

        List<String> weekdayList = new ArrayList<>();

        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.YEAR, year);
        cal.set(Calendar.MONTH, month - 1);
        cal.set(Calendar.DATE, 1);

        while(cal.get(Calendar.YEAR) == year && cal.get(Calendar.MONTH) < month){

            int day1 = cal.get(Calendar.DAY_OF_WEEK);

            if(!(day1 == Calendar.SUNDAY || day1 == Calendar.SATURDAY)){
                weekdayList.add(String.valueOf(cal.get(Calendar.DATE)));
            }
            cal.add(Calendar.DATE, 1);
        }
        if (Integer.parseInt(dayNum) + 1 <= weekdayList.size()) {
            return weekdayList.subList(weekdayList.size() - Integer.parseInt(dayNum) - 1, weekdayList.size() - 1).contains(String.valueOf(day));
        }
        return false;
    }

    public static boolean checkWorkDay(){
        Calendar cal1 = Calendar.getInstance();
        int month = cal1.get(Calendar.MONTH) + 1;
        int year = cal1.get(Calendar.YEAR);
        int day = cal1.get(Calendar.DATE);

        List<String> weekdayList = new ArrayList<>();

        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.YEAR, year);
        cal.set(Calendar.MONTH, month - 1);
        cal.set(Calendar.DATE, 1);

        while(cal.get(Calendar.YEAR) == year && cal.get(Calendar.MONTH) < month){

            int day1 = cal.get(Calendar.DAY_OF_WEEK);

            if(!(day1 == Calendar.SUNDAY || day1 == Calendar.SATURDAY)){
                weekdayList.add(String.valueOf(cal.get(Calendar.DATE)));
            }
            cal.add(Calendar.DATE, 1);
        }
        return weekdayList.contains(String.valueOf(day));
    }

    public static String compare(Date dateExpect, Date date) {
        Calendar cal1 = Calendar.getInstance();
        cal1.setTime(dateExpect);

        Calendar cal2 = Calendar.getInstance();
        cal2.setTime(date);
        int day1= cal1.get(Calendar.DAY_OF_YEAR);
        int day2 = cal2.get(Calendar.DAY_OF_YEAR);

        int year1 = cal1.get(Calendar.YEAR);
        int year2 = cal2.get(Calendar.YEAR);
        if (year1 > year2) {
            int timeDistance = 0 ;
            for(int i = year2 ; i < year1 ; i++) {
                if(i%4==0 && i%100!=0 || i%400==0) {   //闰年
                    timeDistance += 366;
                }
                else {   //不是闰年
                    timeDistance += 365;
                }
            }
            return String.valueOf(timeDistance + (day1-day2));
        } else if (year1 < year2){
            int timeDistance = 0 ;
            for(int i = year1 ; i < year2; i++) {
                if(i%4==0 && i%100!=0 || i%400==0) {    //闰年
                    timeDistance += 366;
                } else {    //不是闰年
                    timeDistance += 365;
                }
            }
            return String.valueOf(day1 - day2 - timeDistance);
        } else {    //同一年
            return String.valueOf(day1-day2);
        }
    }
}
