package com.hundsun.tool.handover.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @author Star_King
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class HandoverInfo {
    private String oldUserID;
    private String newUserID;
    private List<String> tables;
}
