package com.hundsun.tool.sqltool.pojo;

import java.util.Date;

/**
 * @author Star_King
 */
public class ExecuteRecordLog {
    private Date date;
    private String task;
    private Boolean succeed;
}
