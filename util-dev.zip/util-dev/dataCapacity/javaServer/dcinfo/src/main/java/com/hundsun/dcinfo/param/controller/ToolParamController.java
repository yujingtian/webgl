package com.hundsun.dcinfo.param.controller;


import com.hundsun.dcinfo.param.entity.ParamList;
import com.hundsun.dcinfo.param.entity.ToolParam;
import com.hundsun.dcinfo.param.entity.UpParam;
import com.hundsun.dcinfo.param.service.ToolParamService;
import com.hundsun.dcinfo.util.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author Wanglei
 * @since 2021-08-05
 */
@RestController
@RequestMapping("/param/")
@CrossOrigin
public class ToolParamController {
    @Autowired
    private ToolParamService service;

    /**
     * 编辑页面批量添加配置接口
     *
     * @param data 数据实体
     * @return 处理结果
     */
    @PostMapping("/add")
    public Result addList(@RequestBody ParamList data) {
        if (data == null || data.getList().size() == 0) {
            return new Result(false, "参数错误！", null);
        } else {
            if (data.getList().size() == 1 && data.getList().get(0).getName().equals("")) {
                return new Result(true, null, null);
            }
            String toolId = data.getList().get(0).getToolId();
            return service.addParamList(toolId, data.getList());
        }
    }


    /**
     * 删除多个
     *
     * @param data 删除的对象
     * @return 处理结果
     */
    @PostMapping("/delete")
    public Result delMore(@RequestBody ParamList data) {
        if (data == null || data.getList().size() == 0) {
            return new Result(false, "参数错误！", null);
        } else {
            if (data.getList().size() == 1 && data.getList().get(0).getName().equals("")) {
                return new Result(true, null, null);
            }
            return service.delMore(data.getList());
        }
    }

    /**
     * 根据工具ID删除配置项，即删除该工具下的所有配置项
     *
     * @param toolId 工具ID
     * @return 处理结果
     */
    @PostMapping("/delByToolId")
    public Result delByToolId(String toolId) {
        if (!StringUtils.hasText(toolId)) {
            return new Result(false, "工具ID不不能为空！", null);
        }
        return service.delParamByToolId(toolId);
    }

    /**
     * 修改配置信息
     *
     * @param data 旧信息
     * @return 处理结果
     */
    @PostMapping("/update")
    public Result updateParam(@RequestBody ParamList data) {
        if (data == null || data.getList().size() == 0) {
            return new Result(false, "参数错误！", null);
        } else {
            if (data.getList().size() == 1 && data.getList().get(0).getName().equals("")) {
                return new Result(true, null, null);
            }
            return service.editParam(data);
        }
    }

    /**
     * 获取工具的json串配置信息
     *
     * @param toolId 工具ID
     * @return 返回处理结果
     */
    @GetMapping("/getJson")
    public Result generateJson(String toolId) {
        return service.generateJson(toolId);
    }
}
