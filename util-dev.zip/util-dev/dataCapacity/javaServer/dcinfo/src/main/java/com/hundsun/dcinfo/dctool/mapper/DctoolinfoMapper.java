package com.hundsun.dcinfo.dctool.mapper;

import com.hundsun.dcinfo.dctool.entity.Tool;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

/**
 * <p>
 * Mapper 接口
 * </p>
 *
 * @author jobob
 * @since 2021-07-12
 */
@Mapper
public interface DctoolinfoMapper extends BaseMapper<Tool> {
    @Update("UPDATE HS_ASSET.DCTOOLINFO SET PRODUCT_SERIES = #{newSeries} WHERE PRODUCT_SERIES = #{oldSeries}")
    public void batchUpdateSeries(String oldSeries, String newSeries);

    @Update("UPDATE DCTOOLINFO SET PRODUCT_SERIES = REPLACE(PRODUCT_SERIES, #{oldPath}, #{newPath})")
    public void batchUpdateSeriesNotAll(String oldPath, String newPath);
}
