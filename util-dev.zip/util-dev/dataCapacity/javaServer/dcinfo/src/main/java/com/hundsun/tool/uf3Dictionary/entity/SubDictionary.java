package com.hundsun.tool.uf3Dictionary.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

/**
 * @Author tdragon.
 * @Date 2021/8/22.
 * @Time 21:32
 * @Description:
 */

@Data
@TableName("hep_std_sub_dict_dept_tbl")
public class SubDictionary {
    /** 子项字典编号    */
    private String subEntry;
    /** 子项名 */
    private String dictPrompt;


}
