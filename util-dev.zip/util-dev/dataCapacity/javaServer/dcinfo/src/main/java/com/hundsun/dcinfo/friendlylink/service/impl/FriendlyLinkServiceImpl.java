package com.hundsun.dcinfo.friendlylink.service.impl;

import com.hundsun.dcinfo.friendlylink.mapper.FriendlyLinkMapper;
import com.hundsun.dcinfo.friendlylink.mapper.FriendlyOrderMapper;
import com.hundsun.dcinfo.friendlylink.pojo.FriendlyLink;
import com.hundsun.dcinfo.friendlylink.pojo.FriendlyOrder;
import com.hundsun.dcinfo.friendlylink.service.api.FriendlyLinkService;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

/**
 * @author Star_King
 */
@Service("friendlyLinkService")
public class FriendlyLinkServiceImpl implements FriendlyLinkService {
    private final FriendlyLinkMapper friendlyLinkMapper;

    private final FriendlyOrderMapper friendlyOrderMapper;

    @Override
    public List<FriendlyLink> searchFriendlyLinkByName(String friendName) {
        return friendlyLinkMapper.selectFriendlyLinkByName(friendName);
    }

    @Override
    public FriendlyLink searchLinkByNameAndUserID(String friendName, String userID) {
        List<FriendlyLink> links = friendlyLinkMapper.selectLinkByNameAndUserID(friendName, userID);
        if (links == null || links.isEmpty()) {
            return null;
        }
        return links.get(0);
    }

    public FriendlyLinkServiceImpl(@Qualifier("friendlyLinkMapper") FriendlyLinkMapper friendlyLinkMapper, FriendlyOrderMapper friendlyOrderMapper) {
        this.friendlyLinkMapper = friendlyLinkMapper;
        this.friendlyOrderMapper = friendlyOrderMapper;
    }

    @Override
    public boolean addFriendlyLink(FriendlyLink friendlyLink) {
        if (friendlyLink.getFriendHref() == null){
            friendlyLink.setFriendHref("");
        }
        if (friendlyLink.getIconHref() == null){
            friendlyLink.setIconHref("");
        }
        if (friendlyLink.getHrefAlias() == null){
            friendlyLink.setHrefAlias("");
        }
        int count1 = friendlyLinkMapper.insertFriendlyLink(friendlyLink);
        String newNameList = friendlyOrderMapper.selectOrderByUserID(friendlyLink.getUserID()).getNameList() + ", " + friendlyLink.getFriendName();
        int count2 = friendlyOrderMapper.updateOrder(friendlyLink.getUserID(), newNameList);
        return count1 != 0 && count2 != 0;
    }

    @Override
    public boolean removeFriendlyLinkByNameAndUserID(String friendName, String userID) {
        FriendlyLink friendlyLink = searchLinkByNameAndUserID(friendName, userID);
        Integer friendOrder = friendlyLink.getFriendOrder();
        Integer integer = friendlyLinkMapper.selectLastFriendlyOrder();
        int count = friendlyLinkMapper.deleteFriendlyLinkByNameAndUserID(friendName, userID);
        List<String> list = new ArrayList<>(Arrays.asList(friendlyOrderMapper.selectOrderByUserID(userID).getNameList().split(", ")));
        list.remove(friendName);
        int c = friendlyOrderMapper.updateOrder(userID, list.toString().substring(1, list.toString().length() - 1));
        if (integer.equals(friendOrder)) {
            return true;
        } else {
            int i = friendlyLinkMapper.updateFriendOrder(friendOrder);
            return count != 0 && i != 0;
        }
    }

    @Override
    public boolean changeFriendlyLink(FriendlyLink friendlyLink) {
        int count = friendlyLinkMapper.updateFriendlyLink(friendlyLink);
        return count != 0;
    }

    @Override
    public boolean changeFriendlyLink1(FriendlyLink friendlyLink) {
        int count = friendlyLinkMapper.updateFriendlyLink1(friendlyLink);
        return count != 0;
    }

    @Override
    public List<FriendlyLink> searchFriendlyLinkByUserID(String userID) {
        //检查一遍是否是新用户
        if (friendlyOrderMapper.selectOrderByUserID(userID) == null) {
            List<String> list = new LinkedList<>();
            for (FriendlyLink f : friendlyLinkMapper.selectAllBasicLink()) {
                list.add(f.getFriendName());
            }
            FriendlyOrder friendlyOrder = new FriendlyOrder(userID, list.toString().substring(1, list.toString().length() - 1));
            int b1 = friendlyOrderMapper.insertOrder(friendlyOrder);
//            int b2 = friendlyLinkMapper.updateUserID(", " + userID);
            if (b1 != 0) {
                return friendlyLinkMapper.selectAllBasicLink();
            } else {
                return null;
            }
        } else {
            List<String> nameList = Arrays.asList(friendlyOrderMapper.selectOrderByUserID(userID).getNameList().split(", "));
            List<FriendlyLink> friendlyLinks = new LinkedList<>();
            for (String s : nameList) {
                if (friendlyLinkMapper.selectLinkByNameAndUserID(s, userID).size() == 0) {
                    FriendlyLink friendlyLink = friendlyLinkMapper.selectLinkByNameAndFlag(s, 1);
                    if (friendlyLink != null) {
                        if (friendlyLink.getUserID() == null || !friendlyLink.getUserID().matches(".*" + userID + ".*")) {
                            friendlyLinks.add(friendlyLink);
                        }
                    }
                } else {
                    friendlyLinks.add(friendlyLinkMapper.selectLinkByNameAndUserID(s, userID).get(0));
                }
            }
            return friendlyLinks;
        }
    }

    @Override
    public Integer searchLastFriendlyOrder() {
        return friendlyLinkMapper.selectLastFriendlyOrder();
    }

    @Override
    public boolean existFriendlyOrder(Integer order) {
        List<FriendlyLink> friendlyLinks = friendlyLinkMapper.selectFriendlyOrder(order);
        return friendlyLinks != null && !friendlyLinks.isEmpty();
    }

    @Override
    public List<FriendlyLink> searchAllBasicLink() {
        return friendlyLinkMapper.selectAllBasicLink();
    }

    @Override
    public FriendlyLink searchFriendlyLinkByOrder(Integer friendOrder) {
        List<FriendlyLink> friendlyLinks = friendlyLinkMapper.selectFriendlyOrder(friendOrder);
        if (friendlyLinks == null || friendlyLinks.isEmpty()) {
            return null;
        }
        return friendlyLinks.get(0);
    }

    @Override
    public FriendlyLink searchLinkByNameAndFlag(String friendName, int flag) {
        return friendlyLinkMapper.selectLinkByNameAndFlag(friendName, flag);
    }

    @Override
    public Boolean addUserID(String friendName, String userID) {
        FriendlyLink link = friendlyLinkMapper.selectLinkByNameAndFlag(friendName, 1);
//        List<String> list1 = new ArrayList<String>(Arrays.asList(link.getUserID().split(", ")));
//        list1.remove(userID);
        String userIDList = link.getUserID();
        if (userIDList == null){
            link.setUserID(userID);
        } else {
            link.setUserID(userIDList + ", " + userID);
        }
        int b1 = friendlyLinkMapper.updateLinkUserID(link);
        List<String> list2 = new ArrayList<>(Arrays.asList(friendlyOrderMapper.selectOrderByUserID(userID).getNameList().split(", ")));
        list2.remove(link.getFriendName());
        int b2 = friendlyOrderMapper.updateOrder(userID, list2.toString().substring(1, list2.toString().length() - 1));
        return b1 > 0 && b2 > 0;
    }

    @Override
    public Boolean updateOrder(String userID, String nameList) {
        return friendlyOrderMapper.updateOrder(userID, nameList) > 0;
    }

}
