package com.hundsun.tool.functest.t3.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.generator.config.IFileCreate;
import com.hundsun.jrescloud.common.util.StringUtils;
import com.hundsun.dcinfo.util.Result;
import com.hundsun.tool.functest.t3.exception.T3Exception;
import com.hundsun.tool.functest.t3.pojo.TThreeTest;
import com.hundsun.tool.functest.t3.pojo.TThreeVO;
import com.hundsun.tool.functest.t3.pojo.TestName;
import com.hundsun.tool.functest.t3.pojo.TestNameVO;
import com.hundsun.tool.functest.t3.service.TThreeTestService;
import com.hundsun.tool.functest.t3.service.TestNameService;
import jdk.nashorn.internal.ir.LiteralNode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

/**
 * @author wenping 2021-07-21 14:55
 */
@RestController
@CrossOrigin
@RequestMapping("/tthreetest")
public class TThreeTestController {
    @Autowired
    private TThreeTestService ttService;

    @Autowired
    private TestNameService tNameService;

    @Autowired
    private TThreeTestService threeTestService;

    /**
     * 输入别名和用户ID，返回保存的信息，注该ID必须在DCUsers表中有
     * @param testName 测试用例名
     * @return
     */
    @PostMapping("/selectTestDetails")
    public Result select(@RequestParam(value = "testName", defaultValue = "") String testName) {
        if (StringUtils.isEmpty(testName)) {
            return new Result(false, "请输入测试用例名", null);
        }
        try {
            testName = testName.trim();
            TThreeVO tThreeVO = ttService.showTestDetails(testName);
            return new Result(true, "查询成功" , tThreeVO);
        } catch (Exception e) {
            return new Result(false, e.getMessage(), null);
        }
    }

    @PostMapping("/showAll")
    public Result showAll(@RequestParam(value = "testName", required = false, defaultValue = "") String testName,
                          @RequestParam(value = "userID", defaultValue = "") String userID,
                          @RequestParam(value = "curPage", required = false, defaultValue = "1") int curPage,
                          @RequestParam(value = "pageSize", required = false, defaultValue = "10") int pageSize,
                          @RequestParam(value="flag", defaultValue = "0") int flag) {
        if (StringUtils.isEmpty(userID)) {
            return new Result(false, "请填写用户ID", null);
        }
        if (curPage <= 0) {
            curPage = 1;
        }
        if (pageSize > 10) {
            pageSize = 10;
        }
        TestNameVO nameVO;
        try {
            testName = testName.trim();
            try {
                userID = String.valueOf(Integer.parseInt(userID));
            } catch (Exception e) {
                return new Result(false, "工号全为数字，请输入合法的工号！", null);
            }
            nameVO = tNameService.showAll(testName, userID, curPage, pageSize, flag);
            if (nameVO == null) {
                return new Result(false, "未查询到数据", null);
            }
        } catch (T3Exception e) {
            return new Result(false, e.getMessage(), null);
        }
        return new Result(true, "查询成功", nameVO);
    }


    /**
     * 保存测试接口的别名，微服务名，功能号，参数等一系列信息
     * @param paraData 输入json字符串，封装了要保存的信息
     * @return
     */
    @PostMapping("/save")
    public Result save(@RequestBody String paraData) {
        JSONObject paraMap = JSON.parseObject(paraData);
        String groupAlias = paraMap.getString("groupAlias");
        String testName = paraMap.getString("testName");
        String userID = paraMap.getString("userID");
        String testServer = paraMap.getString("testServer");
        if (StringUtils.isEmpty(testServer)) {
            testServer = "";
        }
        JSONObject shardingInfoJson = paraMap.getJSONObject("shardingInfo");
        String shardingInfo;
        String security;
        if (shardingInfoJson != null){
            shardingInfo = threeTestService.getString(shardingInfoJson.entrySet());
        } else {
            shardingInfo = "";
        }
        JSONObject securityJson = paraMap.getJSONObject("security");
        if (securityJson != null){
            security = threeTestService.getString(securityJson.entrySet());
        } else {
            security = "";
        }
        JSONArray data = paraMap.getJSONArray("data");

        if (StringUtils.isEmpty(userID)) {
            return new Result(false, "用户ID不能为空", null);
        }
        if (StringUtils.isEmpty(testName)) {
            return new Result(false, "测试用例名不能为空", null);
        }
        if (StringUtils.isEmpty(groupAlias)) {
            return new Result(false, "别名不能为空", null);
        }
        if (data == null) {
            return new Result(false, "请输入有效数据", null);
        }
        try{
            userID = String.valueOf(Integer.parseInt(userID.trim()));;
        } catch (Exception e) {
            return new Result(false, "工号全为数字，请输入合法的工号！", null);
        }
        int row = 0;
        try {
            testName = testName.trim();
            groupAlias = groupAlias.trim();
            row = ttService.save(new TestName(null, userID, testName, groupAlias, null, null, testServer, shardingInfo, security), data);
        } catch (T3Exception e) {
            return new Result(false, e.getMessage(), null);
        }
        return new Result(true, "插入成功，共插入有" + row + "行数据", null);
    }

    @PostMapping("/delete")
    public Result delete(@RequestParam(value = "testName", defaultValue = "") String testName,
                         @RequestParam(value = "userID", defaultValue = "") String userID) {
        if (StringUtils.isEmpty(testName)) {
            return new Result(false, "测试用例名不能为空!", null);
        }
        if (StringUtils.isEmpty(userID)) {
            return new Result(false, "用户ID不能为空！", null);
        }
        int delete = 0;
        try {
            testName = testName.trim();
            try{
                userID = String.valueOf(Integer.parseInt(userID));;
            } catch (Exception e) {
                return new Result(false, "工号全为数字，请输入合法的工号！", null);
            }
            delete = ttService.delete(testName, userID);
        } catch (T3Exception e) {
            return new Result(false, e.getMessage(), null);
        }
        if (delete == 0) {
            return new Result(false, "没有此条记录", null);
        }
        return new Result(true, "删除成功！,成功删除"  + delete + "条记录", null);
    }

    @PostMapping("/verify")
    public Result verify(@RequestParam(value = "testName", defaultValue = "") String testName,
                         @RequestParam(value = "userID", defaultValue = "") String userID){
        if (StringUtils.isEmpty(testName)) {
            return new Result(false, "测试用例名不能为空!", null);
        }
        if (StringUtils.isEmpty(userID)) {
            return new Result(false, "用户ID不能为空！", null);
        }

        int verify;
        try {
            testName = testName.trim();
            try{
                userID = String.valueOf(Integer.parseInt(userID));;
            } catch (Exception e) {
                return new Result(false, "工号全为数字，请输入合法的工号！", null);
            }
            verify = ttService.verify(testName, userID);
        } catch (T3Exception e) {
            return new Result(false, e.getMessage(), null);
        }
        if (verify == 0){
            return new Result(false, "该测试用例名已存在", null);
        } else {
            return new Result(true, "该测试用例名不存在", null);
        }
    }
}
