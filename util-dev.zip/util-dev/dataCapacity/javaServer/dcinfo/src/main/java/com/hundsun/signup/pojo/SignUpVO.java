package com.hundsun.signup.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Value;

import java.io.Serializable;
import java.util.List;

/**
 * 代办事项预注册展示当前用户下的预注册处理
 * @author wenping 2021-08-19 11:59
 */
@Data
public class SignUpVO implements Serializable {
    private static final long serialVersionUID = 40754325623L;
    private String userID;
    private String userName;
    private String groupName;
    private String taskType = "开户";

}
