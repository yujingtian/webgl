package com.hundsun.tool.collector.service.api;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

/**
 * @Author: kcaumber
 * @Date: 9/28/21 4:00 PM
 */
public interface SqlService {

    /**
     * 查找是否在表名是否都在数据库内
     * @param tableName 表名列表
     * @return 如在以上表名皆存在，否则返回不存在的表名
     */
    String selectTableByName(List<String> tableName);

    /**
     * 生成数据，插入数据库中
     * @param tableNameList 表名列表
     * @param schema 字段预设值
     * @return 返回Sql脚本文件以及cust_id、client_id、fundaccount、stockholder
     * @throws IOException
     * @throws SQLException
     */
    Map<String, Object> generateSql(List<String> tableNameList, Map<String, Object> schema, List<Map<String, Object>> jourInfoList) throws IOException, SQLException;

    /**
     * 根据名字删除SQL脚本
     * @param fileName 文件名
     * @return 删除成功标志
     */
    boolean deleteSQLScript(String fileName);

    /**
     * 根据业务目的生成数据
     * @param tableNameList
     * @param data
     * @return
     */
    Map<String, Object> generateSqlByBusiness(List<String> tableNameList, Map<String, Object> data, List<Map<String, Object>> jourInfoList) throws IOException;
}
