package com.hundsun.tool.handover.service.impl;

import com.hundsun.tool.handover.mapper.HandoverMapper;
import com.hundsun.tool.handover.pojo.Handover;
import com.hundsun.tool.handover.service.api.HandoverService;
import com.iceolive.util.StringUtil;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author Star_King
 */
@Service("handoverService")
public class HandoverServiceImpl implements HandoverService {
    private final HandoverMapper handoverMapper;

    public HandoverServiceImpl(@Qualifier("handoverMapper") HandoverMapper handoverMapper) {
        this.handoverMapper = handoverMapper;
    }

    @Override
    public List<Handover> searchAllHandover() {
        return handoverMapper.selectHandover("", "");
    }

    @Override
    public List<Handover> searchAllHasUser() {
        return handoverMapper.selectHasUser();
    }

    @Override
    public Handover searchHandoverByName(String tableName) {
        if (StringUtil.isEmpty(tableName)) {
            return null;
        }
        List<Handover> handovers = handoverMapper.selectHandover(tableName, "");
        if (handovers == null || handovers.isEmpty()) {
            return null;
        }
        return handovers.get(0);
    }

    @Override
    public Handover searchHandoverByAlias(String tableAlias) {
        if (StringUtil.isEmpty(tableAlias)) {
            return null;
        }
        List<Handover> handovers = handoverMapper.selectHandover("", tableAlias);
        if (handovers == null || handovers.isEmpty()) {
            return null;
        }
        return handovers.get(0);
    }

    @Override
    public Handover searchHandoverByNameAndAlias(String tableName, String tableAlias) {
        if (StringUtil.isEmpty(tableName) || StringUtil.isEmpty(tableAlias)) {
            return null;
        }
        List<Handover> handovers = handoverMapper.selectHandover(tableName, tableAlias);
        if (handovers == null || handovers.isEmpty()) {
            return null;
        }
        return handovers.get(0);
    }

    @Override
    public boolean addHandover(Handover handover) {
        return handoverMapper.insertHandover(handover) != 0;
    }

    @Override
    public boolean removeHandoverByName(String tableName) {
        if (StringUtil.isEmpty(tableName)) {
            return false;
        }
        return handoverMapper.deleteHandoverByName(tableName) != 0;
    }

    @Override
    public boolean removeHandoverByAlias(String tableAlias) {
        if (StringUtil.isEmpty(tableAlias)) {
            return false;
        }
        return handoverMapper.deleteHandoverByAlias(tableAlias) != 0;
    }

    @Override
    public boolean changeHandover(Handover handover) {
        return handoverMapper.updateHandover(handover) != 0;
    }

    @Override
    public boolean existTable(String tableName) {
        if (StringUtil.isEmpty(tableName)) {
            return false;
        }
        List<String> names = handoverMapper.selectTableName();
        return names.contains(tableName);
    }

    @Override
    public boolean changeTable(String oldUserID, String newUserID, String tableName, String columnName) {
        int count = handoverMapper.updateTable(oldUserID, newUserID, tableName, columnName);
        return count != 0;
    }

    @Override
    public boolean existColumn(String tableName, String column) {
        if (StringUtil.isEmpty(tableName) || StringUtil.isEmpty(column)) {
            return false;
        }
        List<String> list = handoverMapper.selectColumn(tableName);
        return list.contains(column);
    }
}
