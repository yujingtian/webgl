package com.hundsun.tool.reminders.service;

import java.text.ParseException;
import java.util.List;
import java.util.Map;

/**
 * @Author: kcaumber
 * @Date: 2021/11/11 18:46
 */
public interface DingService {
    List<Map<String, String>> bigBagOutDate();

    List<Map<String, String>> SearchReworking(String bagname);

    Map<String, Object> initMsg(String remindMsg, String bagname, String lastdjdate, String outbagdate, Map<String, List<String>> shMap, Map<String, List<String>> xzMap) throws ParseException;

    List<Map<String, String>> SearchSpilBagDate();

    List<String> selectIDByTeamName(String teamName);

    Map<String, Object> assemblyDingMessage(String remindMsg, List<String> phoneList, String 通过率测试);
}
