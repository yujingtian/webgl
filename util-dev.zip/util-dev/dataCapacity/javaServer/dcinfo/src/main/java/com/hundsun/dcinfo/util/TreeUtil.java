package com.hundsun.dcinfo.util;

import com.hundsun.dcinfo.series.entity.SeriesMenu;

import java.math.BigDecimal;
import java.util.*;

public class TreeUtil {
    public static List<SeriesMenu> menuTreeData(List<SeriesMenu> list) {
        // 转parentID属性相同的数据封装到一个List中
        Map<BigDecimal, List<SeriesMenu>> map = new HashMap<>();
        for (SeriesMenu menu : list) {
            if (!map.containsKey(menu.getParentId())) {
                LinkedList<SeriesMenu> Menus = new LinkedList<>();
                Menus.add(menu);
                map.put(menu.getParentId(), Menus);
            } else {
                List<SeriesMenu> menus = map.get(menu.getParentId());
                menus.add(menu);
            }
        }
        // 获取所有父类菜单,封装最终tree结果
        List<SeriesMenu> resultMenus = map.get(BigDecimal.valueOf(0l));

        // 递归获取所有子数值
        recursionTreeChild(map, resultMenus);
        return resultMenus;
    }

    public static void recursionTreeChild(Map<BigDecimal, List<SeriesMenu>> map, List<SeriesMenu> resultMenus) {
        for (SeriesMenu menu : resultMenus) {
            // 添加子级菜单
            if (map.containsKey(menu.getSerId())) {
                List<SeriesMenu> menus1 = map.get(menu.getSerId());
                menu.setChildren(menus1);
                // 递归调用
                recursionTreeChild(map, menus1);
            }
        }
    }
}
