package com.hundsun.tool.reminders.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @Author: kcaumber
 * @Date: 2021/12/20 11:26
 */
@Mapper
@Repository("tsSynMapper")
public interface TsSynMapper {

    List<String> getAllModifier();

    List<String> qryStockRework(List<String> modifier);
}
