package com.hundsun.tool.uf3Dictionary.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.util.Objects;

/**
 * @Author tdragon.
 * @Date 2021/8/22.
 * @Time 21:31
 * @Description:
 */
@Data
@TableName("hep_std_dict_dept_tbl")
public class UF3_Dictionary {
    /** 字典编号 */
    private String dictEntry;
    /** 字典名 */
    private String entryName;


    /** 子项字典编号    */
    private String subEntry;
    /** 子项名 */
    private String dictPrompt;

    /** 微服务名字 */
    private String enSystemStr;


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof UF3_Dictionary)) return false;
        UF3_Dictionary that = (UF3_Dictionary) o;
        return dictEntry.equals(that.dictEntry) &&
                entryName.equals(that.entryName) &&
                subEntry.equals(that.subEntry) &&
                dictPrompt.equals(that.dictPrompt) &&
                enSystemStr.equals(that.enSystemStr);
    }

    @Override
    public int hashCode() {
        return Objects.hash(dictEntry, entryName, subEntry, dictPrompt, enSystemStr);
    }
}
