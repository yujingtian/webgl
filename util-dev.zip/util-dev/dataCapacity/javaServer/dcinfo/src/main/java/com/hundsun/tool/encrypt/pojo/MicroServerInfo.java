package com.hundsun.tool.encrypt.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Star_King
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class MicroServerInfo {
    private String microServerAlias;
    private String serverIP;
    private String serverPort;
    private String licencePath;
}
