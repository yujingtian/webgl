package com.hundsun.dcinfo.friendlylink.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @Author: kcaumber
 * @Date: 9/10/21 2:21 PM
 */
public class FriendlyOrder {

    String userID;
    String nameList;

    public FriendlyOrder() {
    }

    public FriendlyOrder(String userID, String nameList) {
        this.userID = userID;
        this.nameList = nameList;
    }

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public String getNameList() {
        return nameList;
    }

    public void setNameList(String nameList) {
        this.nameList = nameList;
    }

    @Override
    public String toString() {
        return "FriendlyOrder{" +
                "userID='" + userID + '\'' +
                ", nameList='" + nameList + '\'' +
                '}';
    }
}
