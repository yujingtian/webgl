package com.hundsun.dcinfo.series.controller;


import com.hundsun.common.mapper.UserMapper;
import com.hundsun.dcinfo.dctool.service.ToolService;
import com.hundsun.dcinfo.series.entity.Series;
import com.hundsun.dcinfo.series.entity.SeriesMenu;
import com.hundsun.dcinfo.series.service.ISeriesService;
import com.hundsun.dcinfo.util.Result;
import com.hundsun.dcinfo.util.StrToStrUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author Wanglei
 * @since 2021-07-15
 */
@RestController
@RequestMapping("/series/")
@CrossOrigin
public class SeriesController {
    @Autowired
    ISeriesService service;

    @Autowired
    ToolService toolService;

    @Autowired
    private UserMapper userMapper;

    /**
     * 添加系列
     *
     * @param series 系列实体封装
     * @return 返回添加结果
     */
    @RequestMapping("/add")
    @Transactional(rollbackFor = Exception.class)
    public Result addSeries(Series series, String userID) {
        // 判断参数是否为空，添加允许ID为空
        if (!StringUtils.hasText(userID) || !isAllow(series, true) || series.getSerName().contains(".")) {
            return new Result(false, "参数错误！", null);
        }
        userID = StrToStrUtil.strToStrWithoutHeadZero(userID); // 去除数字前的0，再转为字符串
        if (!isAllowedUser(userID)) {
            return new Result(false, "该用户不存在！", null);
        }

        // 顶级UF30和UF20分支已经创建，不能在创建顶级系列
        if (series.getParentId().compareTo(BigDecimal.ZERO) == 0 ||
                series.getSerName().trim().equals("UF30") || series.getSerName().trim().equals("UF20")) {
            return new Result(false, "不能添加顶级系列！", null);
        }

        // 不能添加默认文件夹
        if (series.getSerName().equals("默认")) {
            return new Result(false, "不能添加默认系列！", null);
        }

        // 判断父级是否还存在
        Series parentSeries = service.getById(series.getParentId());
        if (parentSeries == null) {
            return new Result(false, "父系列不存在！", null);
        }

        // 若父级是默认，或者同一个父级下有相同的名字，则不许再该下面添加
        if (parentSeries.getSerName().equals("默认") || !service.isCanAddHere(series.getSerName().toUpperCase(), series.getParentId())) {
            return new Result(false, "不能在此处添加！", null);
        }

        // 判断父系列下是否有工具信息
        // 1.获取父级系列的全路径
        String curPath = service.getAllPath(series.getParentId());
        if (curPath.split("\\.").length >= 5) {
            return new Result(false, "最大层级为5！", null);
        }
        // 2.根据全路径判断该系列下是否有工具的存在
        if (toolService.isHasThisSeries(curPath)) {
            // 有工具，转移到默认分支
            Series addDefault = new Series();
            // 添加默认分支
            addDefault.setSerName("默认"); // 设置默认名
            addDefault.setRemark("默认");  // 设置说明
            addDefault.setParentId(series.getParentId()); // 设置父ID
            service.insertOne(addDefault);   // 保存默认分支
            // 更新工具的分支
            toolService.batchUpdateSeries(curPath, curPath + ".默认");
        }
        if (service.insertOne(series)) {
            return new Result(true, "添加成功！", null);
        } else {
            return new Result(false, "添加失败！", null);
        }
    }

    @RequestMapping("/edit")
    @Transactional(rollbackFor = Exception.class)
    public Result updateSeriesById(Series series, String userID) {
        // 必须传入ID
        if (series.getSerId() == null || series.getSerId().equals(BigDecimal.ZERO) ||
                series.getSerName().contains(".") || !StringUtils.hasText(userID)
        ) {
            return new Result(false, "参数错误！", null);
        }
        userID = StrToStrUtil.strToStrWithoutHeadZero(userID); // 去除数字前的0，再转为字符串
        if (!isAllowedUser(userID)) {
            return new Result(false, "该用户不存在！", null);
        }
        // 根据ID获取旧系列信息
        Series oldSeries = service.getById(series.getSerId());

        // 判断该系列是否已被删除
        if (oldSeries == null) {
            return new Result(false, "该系列不存在！", null);
        }
        // 不能修改顶级系列
        if (oldSeries.getParentId().equals(BigDecimal.ZERO)) {
            return new Result(false, "顶级系列不能修改！", null);
        }

        // 判断是否改变父级，不允许改变父级
        if (!series.getParentId().equals(oldSeries.getParentId())) {
            return new Result(false, "不能修改系列的父级！", null);
        }
        // 1.先获取该系列的路径信息
        String originalPath = service.getAllPath(series.getSerId());
        // 2.根据系列查询是否存在工具信息
        if (!toolService.isHasThisSeriesOrChildSeries(originalPath)) {
            // 没有工具信息,可以直接修改
            if (service.updateById(series)) {
                return new Result(true, "修改成功！", null);
            } else {
                return new Result(false, "修改失败！", null);
            }
        } else {
            // 有工具信息，保存后用新路径替换旧路径
            // (1)先修改系列表，获取新的path
            service.updateById(series);
            String newPath = service.getAllPath(series.getSerId());
            // (2)再修改工具表
            toolService.batchUpdateSeriesNotAll(originalPath, newPath);
            return new Result(true, "修改成功！", null);
        }
    }

    /**
     * 删除系列
     *
     * @param serId 删除系列的ID
     * @return 返回操作的结果
     */
    @RequestMapping("/delete")
    public Result deleteSeriesById(@RequestParam BigDecimal serId, String userID) {
        if (serId == null || serId.compareTo(BigDecimal.ZERO) < 1 || !StringUtils.hasText(userID)) {
            return new Result(false, "参数错误！", null);
        }
        userID = StrToStrUtil.strToStrWithoutHeadZero(userID); // 去除数字前的0，再转为字符串
        if (!isAllowedUser(userID)) {
            return new Result(false, "该用户不存在！", null);
        }
        // 找到该系列信息,判断是否为顶级系列
        Series series = service.getById(serId);
        if (series == null) {
            return new Result(false, "该系列不存在！", null);
        }
        if (series.getParentId().equals(BigDecimal.ZERO)) {
            return new Result(false, "顶级系列不能删除！", null);
        }
        // 判断当前系列下是否有工具信息，有工具信息不许删除
        String allPath = service.getAllPath(serId);
        if (toolService.isHasThisSeriesOrChildSeries(allPath)) {
            return new Result(false, "不能删除，系列下有工具信息！", null);
        }
        if (service.deleteById(serId)) {
            return new Result(true, "删除成功！", null);
        } else {
            return new Result(false, "删除失败！", null);
        }
    }

    /**
     * 获取系列树
     *
     * @return 返回层级树
     */
    @RequestMapping("/getSeriesTree")
    public Result getSeriesTree() {
        // 获取系列树
        List<SeriesMenu> tree = service.getSeriesTree();
        if (tree.size() > 0) {
            return new Result(true, "Success!", tree);
        } else {
            return new Result(false, "Failed!", tree);
        }
    }

    /**
     * 判断参数是否合法
     *
     * @param series        实体类
     * @param isAllowIdNull 是否允许id为空
     * @return 返回结果
     */
    public static boolean isAllow(Series series, boolean isAllowIdNull) {
        // 父ID和系列名一定不能为空
        if (series.getParentId() == null || series.getSerName() == null) {
            return false;
        }
        if (!StringUtils.hasText(series.getSerName()) || series.getParentId().compareTo(BigDecimal.ZERO) < 1) {
            return false;
        }
        if (!isAllowIdNull) {
            return series.getSerId() != null;
        } else {
            return true;
        }
    }

    public boolean isAllowedUser(String userID) {
        return userMapper.selectByOperatorNo(userID) != null;
    }
}
