package com.hundsun.tool.collector.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.hundsun.tool.collector.service.api.SqlService;
import com.hundsun.tool.collector.util.SqlTool;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.StringRequestEntity;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import sun.nio.ch.SelectorImpl;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @Author: kcaumber
 * @Date: 9/28/21 3:57 PM
 */
@Service("sqlService")
public class SqlServiceImpl implements SqlService {

    @Value("${sqlScriptDirPath}")
    private String sqlScriptDirPath;

    @Override
    public String selectTableByName(List<String> tableName) {

        List<String> tableNameList = SqlTool.getTableNames();

        for (String tName : tableName) {
            if (!tableNameList.contains(tName)) {
                return tName;
            }
        }
        return "以上表名皆存在";

    }

    @Override
    public Map<String, Object> generateSql(List<String> tableNameList, Map<String, Object> schema, List<Map<String, Object>> jourInfoList) throws IOException {

        // 创建脚本文件用于存储SQL
        Date currentTime = new Date();
        SimpleDateFormat format = new SimpleDateFormat("yyMMddHHmmss");
        // 日期格式
        String currentTimeString = format.format(currentTime);

        File file = new File(sqlScriptDirPath + tableNameList.get(0) + currentTimeString + ".txt");

        FileOutputStream fos = new FileOutputStream(file);

        // 获取所有字段名，并去重
        Set<String> allFieldName = new HashSet<>();
        for (String tName : tableNameList) {
            allFieldName.addAll(SqlTool.getColumnNames(tName));
        }
        if (allFieldName.size() == 0) {
            return null;
        }

        // 生成json串用于获取随机值
        Map<String, Object> secondLevel = new HashMap<>();

        for (String s : allFieldName) {
            Map<String, Object> thirdLevel = new HashMap<>();
            thirdLevel.put("type", "stardard");
            secondLevel.put(s.toLowerCase(), thirdLevel);
        }
        Map<String, Object> topLevel = new HashMap<>();
        topLevel.put("type", "Object");
        topLevel.put("schema", secondLevel);

        String jsonStr = JSONObject.toJSONString(topLevel);

        String specialValueStr = "{\n" +
                "    \"type\": \"Object\",\n" +
                "    \"schema\": {\n" +
                "        \"serial_no\": {\n" +
                "            \"type\":\"stardard\"\n" +
                "        },\n" +
                "        \"position_str\": {\n" +
                "            \"type\": \"stardard\"\n" +
                "        },\n" +
                "        \"file_guid\":{\n" +
                "            \"type\":\"stardard\"\n" +
                "        },\n" +
                "        \"file_obj\":{\n" +
                "            \"type\":\"stardard\"\n" +
                "        },\n" +
                "        \"report_no\":{\n" +
                "            \"type\":\"stardard\"\n" +
                "        }\n" +
                "    }\n" +
                "}";

        // 获取随机值
        String targetURL = "http://10.20.20.97:7784/30DataCapacity/GetTypeJsonData";

        Map<String, Object> sqlValue = JSON.parseObject(getRandomData(targetURL, jsonStr));

        // 指定值进行赋值
        for (String s : schema.keySet()) {
            sqlValue.put(s, schema.get(s));
        }
        String table_name = "";
        int k = 0;
        // 组装SQL，并执行
        for (String tName : tableNameList) {
            if (tName.matches(".*_JOUR")){
                Map<String, Object> specialValue = JSON.parseObject(getRandomData(targetURL, specialValueStr));
                for (String s : specialValue.keySet()){
                    sqlValue.put(s, specialValue.get(s));
                }
                Date newCurrTime = new Date();
                SimpleDateFormat initDateFor = new SimpleDateFormat("yyyyMMdd");
                SimpleDateFormat currTimeFor = new SimpleDateFormat("HHmmss");
                // 日期格式
                String initDate = initDateFor.format(newCurrTime);
                String currTime = currTimeFor.format(newCurrTime);

//                sqlValue.put("init_date", initDate);
                sqlValue.put("curr_date", initDate);
                sqlValue.put("curr_time", currTime);
                sqlValue.put("report_time", currTime);
                sqlValue.put("return_time", currTime);

                String tableName = String.valueOf(jourInfoList.get(k).get("tableName"));
                if (!tName.equals(jourInfoList.get(k).get("jour_name"))){
                    return null;
                }
                sqlValue.put("table_name", tableName.substring(tableName.lastIndexOf(".") + 1).toLowerCase());
                sqlValue.put("business_flag", jourInfoList.get(k).get("business_flag"));
                k++;
            }


            List<String> fieldNameList = SqlTool.getColumnNames(tName);

            String SQL = "insert into " + tName + "(";



            for (String s : fieldNameList) {
                SQL = SQL + s + ",";
            }
            SQL = SQL.substring(0, SQL.length() - 1) + ") values (";

            // 获取流水表特定随机值


            for (String s : fieldNameList) {
                if ("!".equals(sqlValue.get(s.toLowerCase()))){
                    sqlValue.put(s.toLowerCase(), "0");
                }
                if ("".equals(sqlValue.get(s.toLowerCase()))){
                    sqlValue.put(s.toLowerCase(), " ");
                }

                SQL = SQL + "'" + sqlValue.get(s.toLowerCase()) + "',";

            }
            SQL = SQL.substring(0, SQL.length() - 1) + ")";
            System.out.println(SQL);

            SqlTool.doSQLOperate(SQL);

            // SQL脚本输出到文件
            String fileSQL = SQL + "\n";

            fos.write(fileSQL.getBytes());
        }

        fos.close();

        // 组成返回值
        Map<String, Object> resultMap = new HashMap<>();
        if (sqlValue.get("cust_id") != null) {
            resultMap.put("cust_id", sqlValue.get("cust_id"));
        }
        if (sqlValue.get("client_id") != null) {
            resultMap.put("client_id", sqlValue.get("client_id"));
        }
        if (sqlValue.get("fund_account") != null) {
            resultMap.put("fund_account", sqlValue.get("fund_account"));
        }
        if (sqlValue.get("stockholder") != null) {
            resultMap.put("stockholder", sqlValue.get("stockholder"));
        }
        resultMap.put("fileName", tableNameList.get(0) + currentTimeString + ".txt");
        return resultMap;
    }

    @Override
    public boolean deleteSQLScript(String fileName) {
        File file = new File(sqlScriptDirPath + fileName);
        if (file.exists()) {
            file.delete();
            return true;
        } else {
            return false;
        }
    }

    @Override
    public Map<String, Object> generateSqlByBusiness(List<String> tableNameList, Map<String, Object> schema, List<Map<String, Object>> jourInfoList) throws IOException {

        // 创建脚本文件用于存储SQL
        Date currentTime = new Date();
        SimpleDateFormat format = new SimpleDateFormat("yyMMddHHmmss");
        // 日期格式
        String currentTimeString = format.format(currentTime);

        File file = new File(sqlScriptDirPath + tableNameList.get(0) + currentTimeString + ".txt");

        FileOutputStream fos = new FileOutputStream(file);

        // 获取所有字段名，并去重
        Set<String> allFieldName = new HashSet<>();
        for (String tName : tableNameList) {
            allFieldName.addAll(SqlTool.getColumnNames(tName));
        }
        if (allFieldName.size() == 0) {
            return null;
        }

        // 生成json串用于获取随机值
        Map<String, Object> secondLevel = new HashMap<>();

        for (String s : allFieldName) {
            Map<String, Object> thirdLevel = new HashMap<>();
            thirdLevel.put("type", "stardard");
            secondLevel.put(s.toLowerCase(), thirdLevel);
        }
        Map<String, Object> topLevel = new HashMap<>();
        topLevel.put("type", "Object");
        topLevel.put("schema", secondLevel);

        String jsonStr = JSONObject.toJSONString(topLevel);

        String specialValueStr = "{\n" +
                "    \"type\": \"Object\",\n" +
                "    \"schema\": {\n" +
                "        \"serial_no\": {\n" +
                "            \"type\":\"stardard\"\n" +
                "        },\n" +
                "        \"position_str\": {\n" +
                "            \"type\": \"stardard\"\n" +
                "        },\n" +
                "        \"file_guid\":{\n" +
                "            \"type\":\"stardard\"\n" +
                "        },\n" +
                "        \"file_obj\":{\n" +
                "            \"type\":\"stardard\"\n" +
                "        },\n" +
                "        \"report_no\":{\n" +
                "            \"type\":\"stardard\"\n" +
                "        }\n" +
                "    }\n" +
                "}";

        // 获取随机值
        String targetURL = "http://10.20.20.97:7784/30DataCapacity/GetTypeJsonData";

        Map<String, Object> sqlValue = JSON.parseObject(getRandomData(targetURL, jsonStr));

        // 指定值进行赋值
        for (String s : schema.keySet()) {
            sqlValue.put(s, schema.get(s));
        }

        sqlValue.put("nrfa_account_number", sqlValue.get("client_id"));
        sqlValue.put("fund_account", sqlValue.get("client_id"));
        String table_name = "";
        int k = 0;
        // 组装SQL，并执行
        for (String tName : tableNameList) {
            if (tName.matches(".*_JOUR")){
                Map<String, Object> specialValue = JSON.parseObject(getRandomData(targetURL, specialValueStr));
                for (String s : specialValue.keySet()){
                    sqlValue.put(s, specialValue.get(s));
                }
                Date newCurrTime = new Date();
                SimpleDateFormat initDateFor = new SimpleDateFormat("yyyyMMdd");
                SimpleDateFormat currTimeFor = new SimpleDateFormat("HHmmss");
                // 日期格式
                String initDate = initDateFor.format(newCurrTime);
                String currTime = currTimeFor.format(newCurrTime);

//                sqlValue.put("init_date", initDate);
                sqlValue.put("curr_date", initDate);
                sqlValue.put("curr_time", currTime);
                sqlValue.put("report_time", currTime);
                sqlValue.put("return_time", currTime);

                String tableName = String.valueOf(jourInfoList.get(k).get("tableName"));
                if (!tName.equals(jourInfoList.get(k).get("jour_name"))){
                    return null;
                }
                sqlValue.put("table_name", tableName.substring(tableName.lastIndexOf(".") + 1).toLowerCase());
                sqlValue.put("business_flag", jourInfoList.get(k).get("business_flag"));
                k++;
            }

            List<String> fieldNameList = SqlTool.getColumnNames(tName);

            String SQL = "insert into " + tName + "(";



            for (String s : fieldNameList) {
                SQL = SQL + s + ",";
            }
            SQL = SQL.substring(0, SQL.length() - 1) + ") values (";

            // 获取流水表特定随机值

            for (String s : fieldNameList) {
                if ("!".equals(sqlValue.get(s.toLowerCase()))){
                    sqlValue.put(s.toLowerCase(), "0");
                }
                if ("".equals(sqlValue.get(s.toLowerCase()))){
                    sqlValue.put(s.toLowerCase(), " ");
                }
                SQL = SQL + "'" + sqlValue.get(s.toLowerCase()) + "',";

            }
            SQL = SQL.substring(0, SQL.length() - 1) + ")";
            System.out.println(SQL);

            SqlTool.doSQLOperate(SQL);

            // SQL脚本输出到文件
            String fileSQL = SQL + "\n";

            fos.write(fileSQL.getBytes());
        }

        fos.close();

        // 组成返回值
        Map<String, Object> resultMap = new HashMap<>();
        if (sqlValue.get("cust_id") != null) {
            resultMap.put("cust_id", sqlValue.get("cust_id"));
        }
        if (sqlValue.get("client_id") != null) {
            resultMap.put("client_id", sqlValue.get("client_id"));
        }
        if (sqlValue.get("fund_account") != null) {
            resultMap.put("fund_account", sqlValue.get("fund_account"));
        }
        if (sqlValue.get("stockholder") != null) {
            resultMap.put("stockholder", sqlValue.get("stockholder"));
        }
        resultMap.put("fileName", tableNameList.get(0) + currentTimeString + ".txt");
        return resultMap;
    }

    private String getRandomData(String targetURL, String jsonStr) {
        PostMethod postMethod = new PostMethod(targetURL);
        try {
            postMethod.setRequestEntity(new StringRequestEntity(jsonStr, "application/json", "UTF-8"));
            HttpClient client = new HttpClient();
            client.getHttpConnectionManager().getParams().setConnectionTimeout(5000);
            int status = client.executeMethod(postMethod);

            if (status == HttpStatus.SC_OK) {
                InputStream inputStream = postMethod.getResponseBodyAsStream();
                BufferedReader br = new BufferedReader(new InputStreamReader(inputStream));
                StringBuffer stringBuffer = new StringBuffer();
                String str = "";
                while ((str = br.readLine()) != null) {
                    stringBuffer.append(str);
                }
                return stringBuffer.toString();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            postMethod.releaseConnection();
        }
        return null;
    }
}
