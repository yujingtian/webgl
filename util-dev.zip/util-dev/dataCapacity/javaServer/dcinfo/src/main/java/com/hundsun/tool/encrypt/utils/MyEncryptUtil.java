package com.hundsun.tool.encrypt.utils;


import com.hundsun.jrescloud.common.util.T3EncryptUtil;

/**
 * @author Star_King
 */
public class MyEncryptUtil {
    /**
     * 一户通账号密码用AES加密
     * @param clientId 一户通账号
     * @param clearPwd 明文
     * @return 密文
     */
    public static String t3ClientAes(String clientId, String clearPwd) {
        return T3EncryptUtil.encode(clientId, T3EncryptUtil.AUTH_TYPE_CLIENTIID, T3EncryptUtil.ENCODE_TYPE_AES, clearPwd);
    }

    /**
     * 资产账户账号密码用AES加密
     * @param assetId 资产账户账号
     * @param clearPwd 明文
     * @return 密文
     */
    public static String t3AssetAes(String assetId, String clearPwd) {
        return T3EncryptUtil.encode(assetId, T3EncryptUtil.AUTH_TYPE_FUNDACCOUNT, T3EncryptUtil.ENCODE_TYPE_AES, clearPwd);
    }

    /**
     * 操作员账号密码用AES加密
     * @param adminId 操作员账号
     * @param clearPwd 明文
     * @return 密文
     */
    public static String t3AdminAes(String adminId, String clearPwd) {
        return T3EncryptUtil.encode(adminId, T3EncryptUtil.AUTH_TYPE_OPOPERATORNO, T3EncryptUtil.ENCODE_TYPE_AES, clearPwd);
    }

    /**
     * 一户通账号密码用国密加密
     * @param clientId 一户通账号
     * @param clearPwd 明文
     * @return 密文
     */
    public static String t3ClientNational(String clientId, String clearPwd) {
        return T3EncryptUtil.encode(clientId, T3EncryptUtil.AUTH_TYPE_CLIENTIID, T3EncryptUtil.ENCODE_TYPE_GM, clearPwd);
    }

    /**
     * 资产账户账号密码用GM加密
     * @param assetId 资产账户账号
     * @param clearPwd 明文
     * @return 密文
     */
    public static String t3AssetNational(String assetId, String clearPwd) {
        return T3EncryptUtil.encode(assetId, T3EncryptUtil.AUTH_TYPE_FUNDACCOUNT, T3EncryptUtil.ENCODE_TYPE_GM, clearPwd);
    }

    /**
     * 操作员账号密码用AES加密
     * @param adminId 操作员账号
     * @param clearPwd 明文
     * @return 密文
     */
    public static String t3AdminNational(String adminId, String clearPwd) {
        return T3EncryptUtil.encode(adminId, T3EncryptUtil.AUTH_TYPE_OPOPERATORNO, T3EncryptUtil.ENCODE_TYPE_GM, clearPwd);
    }
}
