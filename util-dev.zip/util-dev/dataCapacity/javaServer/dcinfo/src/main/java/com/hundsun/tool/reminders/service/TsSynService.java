package com.hundsun.tool.reminders.service;

import com.alibaba.fastjson.JSONArray;

import java.util.List;
import java.util.Map;

/**
 * @Author: kcaumber
 * @Date: 2021/12/20 11:22
 */
public interface TsSynService {

    Map<String, String> getUserInfo();

    String getAllModifier();

    List<String> qryStockRework(List<String> modifier);

    List<String> InsertTmpReworkList(JSONArray dataJson, Map<String, String> userDict);

}
