package com.hundsun.tool.collector.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.hundsun.tool.collector.service.api.BusinPurposeService;
import com.hundsun.tool.collector.service.api.SqlService;
import com.hundsun.tool.collector.service.api.TablePurposeService;
import com.hundsun.tool.utils.ResultEntity;
import com.iceolive.util.StringUtil;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.sql.SQLException;
import java.util.*;
import java.util.logging.Logger;

/**
 * @Author: kcaumber
 * @Date: 9/28/21 3:26 PM
 */
@CrossOrigin
@RestController
@RequestMapping("/collector")
public class CollectorController {

    private static final Logger LOGGER = Logger.getLogger("com.hundsun.tool.collector.controller.CollectorController");

    private final SqlService sqlService;
    private final BusinPurposeService businPurposeService;
    private final TablePurposeService tablePurposeService;

    public CollectorController(@Qualifier("sqlService") SqlService sqlService,
                               @Qualifier("businPurposeService") BusinPurposeService businPurposeService,
                               @Qualifier("tablePurposeService") TablePurposeService tablePurposeService){
        this.sqlService = sqlService;
        this.businPurposeService = businPurposeService;
        this.tablePurposeService = tablePurposeService;
    }

    @PostMapping("/insertBusinData")
    public String insertBusinData(@RequestBody String BusinData) throws IOException, SQLException {

        if (StringUtil.isEmpty(BusinData)){
            LOGGER.warning("请输入需要插入数据的表名或业务目的");
            return ResultEntity.failWithoutData("请输入需要插入数据的表名或业务目的").returnResult();
        }

        JSONObject jsonObject = JSON.parseObject(BusinData);

        String tableName = jsonObject.getString("tableName");
        String businessType = jsonObject.getString("businessType");
        Map<String, Object> data = jsonObject.getJSONObject("data");

        String insertKind;

        if (!StringUtil.isEmpty(tableName)){
            insertKind = "表名";
            LOGGER.info("根据表名完成数据插入");
        } else if (!StringUtil.isEmpty(businessType)){
            insertKind = "业务目的";
            LOGGER.info("根据业务目的完成数据插入");
        } else {
            LOGGER.warning("请输入需要插入数据的表名或业务目的");
            return ResultEntity.failWithoutData("请输入需要插入数据的表名或业务目的").returnResult();
        }

        if ("表名".equals(insertKind)){
            List<String> tableNameList = Arrays.asList(tableName.split(","));

            if (!"以上表名皆存在".equals(sqlService.selectTableByName(tableNameList))){
                LOGGER.warning("表名" + sqlService.selectTableByName(tableNameList) + "不存在");
                return ResultEntity.failWithoutData("表名" + sqlService.selectTableByName(tableNameList) + "不存在").returnResult();
            }
            if ("个人开户".equals(businessType)){
                return ResultEntity.successWithData(tablePurposeService.generateDataByPerson(tableNameList, data)).returnResult();
            } else if ("机构开户".equals(businessType)){
                return ResultEntity.successWithData(tablePurposeService.generateDataByOrgan(tableNameList, data)).returnResult();
            } else if ("产品开户".equals(businessType)){
                return ResultEntity.successWithData(tablePurposeService.generateDataByProduce(tableNameList, data)).returnResult();
            } else if ("创业板权限开通".equals(businessType)){
                businPurposeService.generateDataByGemAuth(data);
                return "创业板权限开通";
            } else {
                LOGGER.warning("请输入指定业务类别(个人开户, 机构开户, 产品开户, 创业板权限开通)");
                return ResultEntity.failWithoutData("请输入指定业务类别(个人开户, 机构开户, 产品开户, 创业板权限开通)").returnResult();
            }
        } else {
            if ("个人开户".equals(businessType)){
                Map<String, Object> resultMap = businPurposeService.generateDataByPerson(data);
                return ResultEntity.successWithData(resultMap).returnResult();
            } else if ("机构开户".equals(businessType)){
                return ResultEntity.successWithData(businPurposeService.generateDataByOrgan(data)).returnResult();
            } else if ("产品开户".equals(businessType)){
                return ResultEntity.successWithData(businPurposeService.generateDataByProduce(data)).returnResult();
            } else if ("创业板权限开通".equals(businessType)){
                businPurposeService.generateDataByGemAuth(data);
                return "创业板权限开通";
            } else {
                LOGGER.warning("请输入指定业务类别(个人开户, 机构开户, 产品开户, 创业板权限开通)");
                return ResultEntity.failWithoutData("请输入指定业务类别(个人开户, 机构开户, 产品开户, 创业板权限开通)").returnResult();
            }
        }

    }

    @PostMapping("/deleteSQLScript")
    public String deleteSQLScript(@RequestParam(value = "fileName", defaultValue = "") String fileName) throws JsonProcessingException {
        if (StringUtil.isEmpty(fileName)){
            LOGGER.warning("请输入fileName");
            return ResultEntity.failWithoutData("请输入fileName").returnResult();
        }

        boolean success = sqlService.deleteSQLScript(fileName);

        if (success){
            LOGGER.info("文件删除成功");
            return ResultEntity.successWithoutData().returnResult();
        } else {
            LOGGER.warning("文件删除失败");
            return ResultEntity.failWithoutData("文件删除失败").returnResult();
        }
    }

    @PostMapping("/selectTableByBusinessType")
    public String selectTableByBusinessType (@RequestParam(value = "businessType", defaultValue = "") String businessType) throws JsonProcessingException {
        if (StringUtil.isEmpty(businessType)){
            LOGGER.warning("businessType为空");
            return ResultEntity.failWithoutData("businessType为空").returnResult();
        } else if ("个人开户".equals(businessType)){
            Map<String, List<String>> tableMap = new HashMap<>();
            List<String> tableNameList = new ArrayList<>();

            tableNameList.add("HS_ACT.act_nrfacct_person".toUpperCase());
            tableNameList.add("HS_CIC.cic_person".toUpperCase());
//            tableNameList.add("HS_ACT.act_account_info_jourunt_info_jour".toUpperCase());
            tableMap.put("act.postNrfacctpersonAdd", tableNameList);

            // 非居民金融账户名称信息增加 act.postNrfacctnameAdd
            tableNameList = new ArrayList<>();
            tableNameList.add("HS_ACT.act_nrfacct_name".toUpperCase());
            tableNameList.add("HS_CIC.cic_nrfacct_name".toUpperCase());
//            tableNameList.add("HS_ACT.act_account_info_jour".toUpperCase());
            tableMap.put("act.postNrfacctnameAdd", tableNameList);

            // 非居民金融账户地址信息增加
            tableNameList = new ArrayList<>();
            tableNameList.add("HS_ACT.act_nrfacct_address".toUpperCase());
            tableNameList.add("HS_CIC.cic_nrfacct_address".toUpperCase());
//            tableNameList.add("HS_ACT.act_account_info_jour".toUpperCase());
            tableMap.put("act.postNrfacctaddressAdd", tableNameList);


            // 客户开户(完成)
            tableNameList = new ArrayList<>();
            tableNameList.add("HS_ACT.act_client".toUpperCase());
            tableNameList.add("HS_ACT.act_phonenum_place".toUpperCase());
            tableNameList.add("HS_ACT.act_person".toUpperCase());
            tableNameList.add("HS_ACT.act_tel".toUpperCase());
            tableNameList.add("HS_ACT.act_address".toUpperCase());
            tableNameList.add("HS_CIC.cic_custtoacct".toUpperCase());
            tableNameList.add("HS_CIC.cic_basic_info".toUpperCase());
            tableNameList.add("HS_CIC.cic_person".toUpperCase());
            tableNameList.add("HS_CIC.cic_relation_person".toUpperCase());
            tableNameList.add("HS_CIC.cic_additionid".toUpperCase());
            tableNameList.add("HS_CIC.cic_contact_person".toUpperCase());
            tableNameList.add("HS_CIC.cic_address".toUpperCase());
            tableNameList.add("HS_CIC.cic_tel".toUpperCase());
//            tableNameList.add("HS_ACT.act_account_info_jour".toUpperCase());
            tableMap.put("act.postClientOpen", tableNameList);

            // 资产账户开户(完成)
            tableNameList = new ArrayList<>();
            tableNameList.add("HS_ACT.act_fund_account".toUpperCase());
            tableNameList.add("HS_IIC.iic_auth_user".toUpperCase());
            tableNameList.add("HS_IIC.iic_revert_password".toUpperCase());
//            tableNameList.add("HS_ACT.act_fund_account_jour".toUpperCase());
//            tableNameList.add("HS_ACT.act_fund_account_control_jour".toUpperCase());
            tableMap.put("act.postFundacctOpen", tableNameList);

            // 一码通开户(完成)
            tableNameList = new ArrayList<>();
            tableNameList.add("act_csdc_acode_acct".toUpperCase());
//            tableNameList.add("act_csdc_acode_acct_jour".toUpperCase());
            tableMap.put("act.postDataswapAcodeOpen", tableNameList);

            //证券账户开户(完成)
            tableNameList = new ArrayList<>();
            tableNameList.add("HS_ACT.act_csdc_holder".toUpperCase());
//            tableNameList.add("HS_ACT.act_csdc_holder_jour".toUpperCase());
            tableNameList.add("HS_ACT.act_stock_holder".toUpperCase());
//            tableNameList.add("HS_ACT.act_stk_account_control_jour".toUpperCase());
//            tableNameList.add("HS_ACT.act_stock_holder_jour".toUpperCase());
            tableMap.put("act.postDataswapHolderOpen", tableNameList);

            tableMap.put("ftc.postFundMoneyTypeOpenInner", new ArrayList<>());
            tableMap.put("ftc.postFundMoneyTypeOpen", new ArrayList<>());
            tableMap.put("ftc.postBankaccountCtsAcctOpenFromSecu", new ArrayList<>());
            tableMap.put("ftc.postBanktransferPreBankCtsAcctOpen", new ArrayList<>());

            return ResultEntity.successWithData(tableMap).returnResult();
        } else if ("机构开户".equals(businessType)){
            Map<String, List<String>> tableMap = new HashMap<>();
            List<String> tableNameList = new ArrayList<>();

            tableNameList.add("HS_ACT.act_organ".toUpperCase());
            tableNameList.add("HS_ACT.act_nrfacct_organ".toUpperCase());
            tableNameList.add("HS_CIC.cic_nrfacct_organ".toUpperCase());
            tableMap.put("act.postNrfacctorganAdd", tableNameList);

            tableNameList = new ArrayList<>();
            tableNameList.add("HS_ACT.act_nrfacct_name".toUpperCase());
            tableNameList.add("HS_CIC.cic_nrfacct_name".toUpperCase());
            tableMap.put("act.postNrfacctnameAdd", tableNameList);

            tableNameList = new ArrayList<>();
            tableNameList.add("HS_ACT.act_nrfacct_address".toUpperCase());
            tableNameList.add("HS_CIC.cic_nrfacct_address".toUpperCase());
            tableMap.put("act.postNrfacctaddressAdd", tableNameList);

            tableNameList = new ArrayList<>();
            tableNameList.add("HS_ACT.act_nrfacct_controller".toUpperCase());
            tableNameList.add("HS_CIC.cic_nrfacct_controller".toUpperCase());
            tableMap.put("act.postNrfacctcontrollerAdd", tableNameList);

            return ResultEntity.successWithData("tableMap").returnResult();
        } else if ("产品".equals(businessType)){
            Map<String, List<String>> tableMap = new HashMap<>();
            List<String> tableNameList = new ArrayList<>();

            tableNameList.add("HS_ACT.act_organ".toUpperCase());
            tableNameList.add("HS_ACT.act_nrfacct_organ".toUpperCase());
            tableNameList.add("HS_CIC.cic_nrfacct_organ".toUpperCase());
            tableMap.put("act.postNrfacctorganAdd", tableNameList);

            tableNameList = new ArrayList<>();
            tableNameList.add("HS_ACT.act_nrfacct_name".toUpperCase());
            tableNameList.add("HS_CIC.cic_nrfacct_name".toUpperCase());
            tableMap.put("act.postNrfacctnameAdd", tableNameList);

            tableNameList = new ArrayList<>();
            tableNameList.add("HS_ACT.act_nrfacct_address".toUpperCase());
            tableNameList.add("HS_CIC.cic_nrfacct_address".toUpperCase());
            tableMap.put("act.postNrfacctaddressAdd", tableNameList);

            tableNameList = new ArrayList<>();
            tableNameList.add("HS_ACT.act_nrfacct_controller".toUpperCase());
            tableNameList.add("HS_CIC.cic_nrfacct_controller".toUpperCase());
            tableMap.put("act.postNrfacctcontrollerAdd", tableNameList);

            return ResultEntity.successWithData("tableMap").returnResult();
        } else {
            LOGGER.warning("当前业务不支持查询");
            return ResultEntity.failWithoutData("当前业务不支持查询").returnResult();

        }
    }

}
