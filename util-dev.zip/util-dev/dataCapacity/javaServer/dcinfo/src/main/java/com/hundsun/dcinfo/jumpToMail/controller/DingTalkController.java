package com.hundsun.dcinfo.jumpToMail.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.hundsun.dcinfo.jumpToMail.pojo.DingTalk;
import com.hundsun.dcinfo.jumpToMail.service.DingTalkService;
import com.hundsun.dcinfo.jumpToMail.util.DingPostUtil;
import com.hundsun.dcinfo.jumpToMail.util.Result;
import com.hundsun.tool.utils.ResultEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;


/**
 * @Author: kcaumber
 * @Date: 8/25/21 1:17 PM
 */
@CrossOrigin
@RestController
@RequestMapping("/dingTalk")
public class DingTalkController {

    @Autowired
    private DingTalkService dingTalkService;

    /**
     * 新增钉钉机器人信息
     * @param webHook
     * @param groupName
     * @param secret
     * @return
     */
    @RequestMapping("/insertDingTalk")
    public Result insertDingTalk(@RequestParam("webHook") String webHook,
                                 @RequestParam("groupName") String groupName,
                                 @RequestParam("secret") String secret) {


        DingTalk dingTalk = new DingTalk(webHook, groupName, secret);
        String result = dingTalkService.insertDingTalk(dingTalk);
        if ("新增成功".equals(result)){
            return new Result(true, result, null);
        } else {
            return new Result(false, result, null);
        }
    }

    /**
     * 删除对应群组名的钉钉机器人记录
     * @param groupName
     * @return
     */
    @RequestMapping("/deleteDingTalk")
    public Result deleteDingTalk(@RequestParam("groupName") String groupName){

        String result = dingTalkService.deleteDingTalk(groupName);
        if ("删除成功".equals(result)){
            return new Result(true, result, null);
        } else {
            return new Result(false, result, null);
        }
    }

    /**
     * 更新对应群组名的钉钉机器人信息
     * @param webHook
     * @param groupName
     * @param secret
     * @return
     */
    @RequestMapping("/updateDingTalk")
    public Result updateDingTalk(@RequestParam("webHook") String webHook,
                                 @RequestParam("groupName") String groupName,
                                 @RequestParam("secret") String secret){

        DingTalk dingTalk = new DingTalk(webHook, groupName, secret);
        String result = dingTalkService.updateDingTalk(dingTalk);

        if ("更新成功".equals(result)){
            return new Result(true, result, null);
        } else {
            return new Result(false, result, null);
        }
    }

    /**
     * 查找所有机器人信息
     * @return
     */
    @RequestMapping("/selectAllDT")
    public Result selectAllDT(){
        return new Result(true, "查找完成", dingTalkService.selectAllDT());
    }

    /**
     * 查找对应群组名机器人信息
     * @param groupName
     * @return
     */
    @RequestMapping("/selectByGroupName")
    public Result selectByGroupName(@RequestParam("groupName") String groupName){
        if (groupName.length() > 0){
            DingTalk dingTalk = dingTalkService.selectByGroupName(groupName);
            if (dingTalk == null){
                return new Result(true, "查找完成,未查找到相应记录", null);

            } else {
                return new Result(true, "查找完成", dingTalk);
            }
        } else {
            return new Result(false, "groupName为空", null);
        }
    }

    @PostMapping("/sendDingTalk")
    public String sendDingTalk(@RequestBody String msgInfo) throws JsonProcessingException, NoSuchAlgorithmException, InvalidKeyException, UnsupportedEncodingException {
        JSONObject paramMap = JSON.parseObject(msgInfo);
        if (msgInfo == null){
            return ResultEntity.failWithoutData("非法参数").returnResult();
        }
        String groupName = paramMap.getString("groupName");
        DingTalk dingTalk = dingTalkService.selectByGroupName(groupName);

        if (dingTalk == null){
            return ResultEntity.failWithoutData("该群组名不存在").returnResult();
        }
        String url = DingPostUtil.addSign(dingTalk.getWebHook(), dingTalk.getSecret());

        String msgtype = paramMap.getString("msgtype");
        String content = paramMap.getString("content");
        JSONArray receiveListJson = paramMap.getJSONArray("receiveList");
        List<String> receiveList = new ArrayList<>();
        for (int i = 0; i < receiveListJson.size(); i++){
            String receive = (String) receiveListJson.get(i);
            receiveList.add(receive);
        }

        boolean isAtAll = paramMap.getBoolean("isAtAll");

        String response = DingPostUtil.sendText(url, msgtype, content, null, null, receiveList, isAtAll);

        System.out.println("相应结果：" + response);
        return "{\"errcode\":0,\"errmsg\":\"ok\"}".equals(response) ? ResultEntity.successWithDataMsg("消息已发送成功",null).returnResult() : ResultEntity.failWithoutData("发送失败" + response).returnResult();
    }
}
