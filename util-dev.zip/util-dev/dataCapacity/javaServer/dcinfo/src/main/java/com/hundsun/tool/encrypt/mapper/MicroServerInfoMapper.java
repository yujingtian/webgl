package com.hundsun.tool.encrypt.mapper;

import com.hundsun.tool.encrypt.pojo.MicroServerInfo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author Star_King
 */
@Mapper
@Repository("microServerInfoMapper")
public interface MicroServerInfoMapper {
    /**
     * 根据客户端别名查询数据库中的所有MicroServerInfo记录
     * @param serverAlias 客户端别名
     * @return 客户端列表
     */
    List<MicroServerInfo> selectInfoByName(@Param("serverAlias") String serverAlias);

    /**
     * 根据IP和端口号查询所有MicroServerInfo记录
     * @param serverIP IP地址
     * @param serverPort 端口号
     * @return 客户端列表
     */
    List<MicroServerInfo> selectInfoByIPAndPort(@Param("serverIP") String serverIP,
                                                @Param("serverPort") String serverPort);
}
