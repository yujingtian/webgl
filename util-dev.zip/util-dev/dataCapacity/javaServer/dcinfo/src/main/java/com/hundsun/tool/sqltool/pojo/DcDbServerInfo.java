package com.hundsun.tool.sqltool.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 对应数据库信息表DCDBSERVERINFO表
 * @author Star_King
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class DcDbServerInfo {
    /**
     * 唯一标识id
     */
    private String dbId;
    /**
     * 数据库类型，0-MySql,1-Oracle11g,2-Oracle19C
     */
    private String dbType;
    /**
     * 数据库所在ip
     */
    private String dbIP;
    /**
     * 数据库端口
     */
    private Integer dbPort;
    /**
     * 数据库为oracle时有值对应sid
     */
    private String dbSid;
    /**
     * 数据库为Mysql时有值对应数据库名
     */
    private String dbName;
    /**
     * 数据库用户实例名
     */
    private String dbUser;
    /**
     * 数据库密码
     */
    private String dbPwd;
}
