package com.hundsun.tool.sqltool.filter;

import com.alibaba.druid.filter.FilterEventAdapter;
import com.alibaba.druid.proxy.jdbc.StatementProxy;
import com.hundsun.tool.sqltool.util.FilterUtil;
import lombok.SneakyThrows;

/**
 * 判断sql是否合法的过滤器
 * @author Star_King
 */
public class OracleSqlFilter extends FilterEventAdapter {
    @Override
    protected void statementExecuteUpdateBefore(StatementProxy statement, String sql) {
    }

    @SneakyThrows
    @Override
    protected void statementExecuteQueryBefore(StatementProxy statement, String sql) {
        FilterUtil.isLegal("oracle", sql);
        super.statementExecuteQueryBefore(statement, sql);
    }
}
