package com.hundsun.signup.exception;

import cn.hutool.crypto.asymmetric.Sign;

/**
 * @author wenping 2021-07-30 14:43
 */
public class SignUpException extends Exception{
    public SignUpException(){};
    public SignUpException(String message) {
        super(message);
    }
    public SignUpException(String message, Throwable cause) {
        super(message, cause);
    }
}
