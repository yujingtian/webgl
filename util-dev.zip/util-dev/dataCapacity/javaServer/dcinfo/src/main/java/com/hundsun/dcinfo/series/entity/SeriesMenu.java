package com.hundsun.dcinfo.series.entity;

import lombok.Data;

import java.math.BigDecimal;
import java.util.List;

@Data
public class SeriesMenu {

    private BigDecimal serId;

    private String serName;

    private BigDecimal parentId;

    private String remark;

    private List<SeriesMenu> children;

    public SeriesMenu(Series series) {
        serId = series.getSerId();
        serName = series.getSerName();
        remark = series.getRemark();
        parentId = series.getParentId();
    }
}
