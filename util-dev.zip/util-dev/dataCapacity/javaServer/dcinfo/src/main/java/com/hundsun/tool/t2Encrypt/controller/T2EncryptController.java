package com.hundsun.tool.t2Encrypt.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.hundsun.jrescloud.common.t2.dataset.DatasetService;
import com.hundsun.jrescloud.common.t2.dataset.IDataset;
import com.hundsun.jrescloud.common.t2.event.IPack;
import com.hundsun.jrescloud.common.t2.event.PackService;
import com.hundsun.t2sdk.impl.client.T2Services;
import com.hundsun.t2sdk.interfaces.T2SDKException;
import com.hundsun.tool.t2Encrypt.exception.T2Exception;
import com.hundsun.tool.t2Encrypt.service.T2EncryptService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hundsun.jrescloud.common.util.StringUtils;
import com.hundsun.tool.t2Encrypt.util.T2ServiceUtil;
import com.hundsun.tool.t2Encrypt.util.T2Util;
import com.hundsun.tool.utils.DBWorkUtil;
import com.hundsun.tool.utils.ResultEntity;
import com.hundsun.tool.utils.TransClassUtil;
import com.iceolive.util.StringUtil;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.*;

import java.io.UnsupportedEncodingException;
import java.util.*;
import java.util.logging.Logger;

/**
 * @Author: kcaumber
 * @Date: 10/9/21 10:34 AM
 */
@CrossOrigin
@RestController
@RequestMapping("/T2Encrypt")
public class T2EncryptController {

    private static final Logger LOGGER = Logger.getLogger("com.hundsun.tool.t2Encrypt.controller.T2EncryptController");

    private final T2EncryptService t2EncryptService;

    public T2EncryptController(@Qualifier("t2EncryptService")T2EncryptService t2EncryptService) {
        this.t2EncryptService = t2EncryptService;
    }

    @PostMapping("/externalSendMessage")
    public String externalSendMessage(@RequestBody String msgInfo) throws JsonProcessingException, InterruptedException, T2SDKException, UnsupportedEncodingException, T2Exception {

        if (StringUtil.isEmpty(msgInfo)){
            LOGGER.warning("输入数据为空");
            return ResultEntity.failWithoutData("输入数据为空").returnResult();
        }
        JSONObject jsonObject = JSON.parseObject(msgInfo);

        String functionId = jsonObject.getString("functionId");
        String serverIP = jsonObject.getString("serverIP");
        String serverPort = jsonObject.getString("serverPort");
        String testServer = jsonObject.getString("testServer"); // 这个可能不需要

        if (StringUtil.isEmpty(functionId) || StringUtil.isEmpty(serverIP) || StringUtil.isEmpty(serverPort)){
            LOGGER.warning("参数functionId或serverIP或serverPort为空");
            return ResultEntity.failWithoutData("参数functionId或serverIP或serverPort为空").returnResult();
        }

        JSONObject shardingInfoJson = jsonObject.getJSONObject("shardingInfo");
        Map<String, Object> shardingInfo = new HashMap<>();
        if (StringUtils.isEmpty(shardingInfoJson)){
            shardingInfo.put("custId", "");
        } else {
            for (Map.Entry<String, Object> entry : shardingInfoJson.entrySet()) {
                shardingInfo.put(entry.getKey(), entry.getValue());
            }
        }

        JSONObject securityJson = jsonObject.getJSONObject("security");
        Map<String, Object> security = new HashMap<>();
        if (!StringUtil.isEmpty(securityJson)){
            for (Map.Entry<String, Object> entry : securityJson.entrySet()){
                security.put(entry.getKey(), entry.getValue());
            }
        }

        JSONObject paramJson = jsonObject.getJSONObject("param");
        List<Map<String, Object>> paramList = new ArrayList<>(); // 最终传递的参数
        if (!StringUtil.isEmpty(paramJson)){
            for (Map.Entry<String, Object> entry : paramJson.entrySet()){ // 得到Map<String, Object> 的param

                if (entry.getValue() instanceof List){ // 判断是否为clob类型 （否）
                    List<String> list = TransClassUtil.castList(entry.getValue(), String.class); // 将obj to List
                    for (int i = 0; i < list.size(); i++){ // 遍历list
                        Map<String, Object> paramMap = new LinkedHashMap<>(); // new Map 用以接收已存在的参数键值对，（或新增）
                        if (paramList.size() > i) { // 若当前i位置已有Map，则paramMap接受家谱已存在的键值对
                            paramMap = paramList.get(i);
                            paramMap.put(entry.getKey(), list.get(i)); // 将新的键值对加入当前Map
                            paramList.remove(i); // 更新List
                            paramList.add(i, paramMap);
                        } else {
                            paramMap.put(entry.getKey(), list.get(i)); // 当新增Map时，直接添加
                            paramList.add(paramMap);
                        }
                    }
                } else {
                    try {

                        Map<String, Object> map = TransClassUtil.castMap(entry.getValue()); // 如果是clob类型，先获取clob的值转成的Map类型（Map<String, List<String>）
                        for (Map.Entry<String, Object> clobEntry : map.entrySet()){ // 遍历map，将Map转成List
                            List<String> clobList = TransClassUtil.castList(clobEntry.getValue(), String.class); // 将Object转成List


                            for (int i = 0; i < clobList.size(); i++){
                                Map<String, Object> paramMap = new LinkedHashMap<>();
                                Map<String, Object> clobMap = new LinkedHashMap<>();
                                if (paramList.size() > i) { // paramList中已有数据

                                    paramMap = paramList.get(i);
                                    clobMap = TransClassUtil.castMap(paramMap.get(entry.getKey()));
                                    if (clobMap == null) clobMap = new LinkedHashMap<>();
                                    clobMap.put(clobEntry.getKey(), clobList.get(i));
                                    paramMap.put(entry.getKey(), clobMap);
                                    paramList.remove(i);
                                    paramList.add(i, paramMap);
                                } else {
                                    clobMap.put(clobEntry.getKey(), clobList.get(i));
                                    paramMap.put(entry.getKey(), clobMap);
                                    paramList.add(paramMap);
                                }
                            }
                        }

                    } catch (Exception ee){
                        ee.printStackTrace();
                        LOGGER.warning("param内参数格式有误");
                        return ResultEntity.failWithoutData("param内参数格式有误").returnResult();
                    }
                }
            }
        }


        // 切割大字段
        for (Map<String, Object> param : paramList) {
            for (Map.Entry<String, Object> entry : param.entrySet()){
                if (entry.getValue() instanceof String) {
                    continue;
                } else {
                    List<Map> newParam = new ArrayList<>();
                    ObjectMapper objectMapper = new ObjectMapper();
                    Map map = objectMapper.readValue(entry.getValue().toString(), Map.class);
                    newParam.add(map);
                    param.put(entry.getKey(), newPackParam(newParam));
                }
            }
        }
        T2Services server = readExternalConfiguration(serverIP, serverPort);
        return T2Util.trySend(server, functionId, paramList);

    }



    @PostMapping("/internalSendMessage")
    public String internalSendMessage(@RequestBody String msgInfo) throws JsonProcessingException {
        if (StringUtil.isEmpty(msgInfo)){
            LOGGER.warning("输入数据为空");
            return ResultEntity.failWithoutData("输入数据为空").returnResult();
        }

        JSONObject jsonObject = JSON.parseObject(msgInfo);

//        String fund_account = jsonObject.getString("fund_account");
        String functionId = jsonObject.getString("functionId");

        JSONObject paramJson = jsonObject.getJSONObject("param");
        Map<String, Object> param = new HashMap<>();
        if (!StringUtil.isEmpty(paramJson)){
            for (Map.Entry<String, Object> entry : paramJson.entrySet()){
                if (String.valueOf(entry.getKey()).matches(".*_clob")){
                    Map<String, List<Object>> clobMap = new ObjectMapper().convertValue(entry.getValue(), Map.class);
                    param.put(entry.getKey(), clobMap);
                } else {
                    param.put(entry.getKey(), entry.getValue());
                }
            }
        }



//            ResultSet rs = new ResultSet(T2ServiceUtil.sendMessage(functionId, param, null));
//            List<Map<String,String>> resList = rs.getDataset();
//            System.out.println(resList);


        return ResultEntity.successWithDataMsg("调用成功", null).returnResult();
    }


    /**
     * 切割大字段
     * @param paramStr
     * @return
     */
    private List<Map> paramSplit(String paramStr) throws UnsupportedEncodingException, T2Exception, JsonProcessingException {
        int maxLength = 4000;
        String defaultCharset = "GBK";

        byte[] paramBytes = paramStr.getBytes(defaultCharset);
        List<Map> newParam = new ArrayList<>();
        int order_no = 1;
        while (paramBytes.length > maxLength) {
            int i;
            Map<String, String> map = new HashMap<>();
            for (i = maxLength - 1; i >= 2; i--) {
                // 反向查找形如","的组合作为json串的切割点
                if (paramBytes[i] == 34 && paramBytes[i - 1] == 44 && paramBytes[i - 2] == 34) break;
            }
            //如果走到这里说明无法找到切割点,这说明入参不是一个格式正确的json串或者有其中某个字段单个长度就已经超过4000
            if(i == 1){
                throw new T2Exception("-1", "json串无法切割:"+paramStr, "");
            }
            // 0到i-1即为开头到逗号处作为一个串 长度为i
            map.put("param_data", new String(paramBytes, 0, i, defaultCharset));
            map.put("order_no", String.valueOf(order_no));
            newParam.add(map);
            order_no++;
            paramBytes = Arrays.copyOfRange(paramBytes, i, paramBytes.length);
        }

//        Map<String, String> map = new HashMap<>();
//        map.put("param_data", new String(paramBytes, defaultCharset));
//        map.put("order_no", String.valueOf(order_no));
        ObjectMapper objectMapper = new ObjectMapper();
        Map map = objectMapper.readValue(new String(paramBytes, defaultCharset), Map.class);


        newParam.add(map);
        return newParam;
    }

    private byte[] newPackParam(List<Map> param) {
        IPack pack = PackService.getPacker(1, "GBK");
        IDataset dataset = DatasetService.getInstace().getDataset(param);
        pack.addDataset(dataset);
        byte[] buff = pack.Pack();
        return buff;

    }

    private T2Services readExternalConfiguration(String serverIP, String serverPort) throws InterruptedException, T2Exception {
        String sqlStr = "SELECT a.LICENCE_PATH FROM DCMICROSERVERINFO a where a.SVRIP = '" + serverIP + "' and a.SVRPORT = '" + serverPort + "'";
        ArrayList<Map<String, String>> maps = DBWorkUtil.SelectDB(sqlStr);

        if (maps == null) {
            throw new T2Exception("101", "未查到证书地址，请至微服务管理添加", "");
        } else {
            String licensePath = maps.get(0).get("LICENCE_PATH".toLowerCase());
            String EXTERNAL_PATH = "D:\\dataCapacity\\DCFile\\" + UUID.randomUUID().toString().substring(0, 20) + ".xml";
            int index = T2ServiceUtil.addServer(serverIP, serverPort, licensePath, EXTERNAL_PATH);
            return T2ServiceUtil.getServer(index);
        }
    }
}
