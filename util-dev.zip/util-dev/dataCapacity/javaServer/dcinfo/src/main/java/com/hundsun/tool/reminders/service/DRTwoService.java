package com.hundsun.tool.reminders.service;

import com.hundsun.tool.reminders.entity.TSPass;

import java.util.List;
import java.util.Map;

/**
 * @Author: kcaumber
 * @Date: 2021/11/10 18:26
 */
public interface DRTwoService {

    List<TSPass> getTsPassData();

    Map<String, Object> assemblyMessage(List<TSPass> tsPassList);

    Map<String, Object> assemblyDingMessage(Map<String, Object> messageMap);

}
