package com.hundsun.tool.functest.t3.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.hundsun.common.mapper.UserMapper;
import com.hundsun.jrescloud.common.util.StringUtils;
import com.hundsun.tool.functest.t3.exception.T3Exception;
import com.hundsun.tool.functest.t3.mapper.TestNameMapper;
import com.hundsun.tool.functest.t3.pojo.TestName;
import com.hundsun.tool.functest.t3.pojo.TestNameVO;
import com.hundsun.tool.functest.t3.service.TestNameService;
import org.apache.ibatis.jdbc.SQL;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.sql.SQLException;
import java.util.Collections;
import java.util.List;

/**
 * @author wenping 2021-07-28 13:56
 */
@Service
public class TestNameServiceImpl implements TestNameService{

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private TestNameMapper testMapper;
    /**
     * 根据测试用例名查询测试用例[ID，测试用例名，别名]
     * @param testName 测试用例名
     * @return
     */
    @Override
    public TestName selectByTestName(String testName) {
        return testMapper.selectByTestName(testName);
    }

    /**
     * 一条[测试用例名，别名]，其中ID是主键，自增
     * @param testName 一条[测试用例名，别名]
     * @return
     * @throws SQLException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public int insert(TestName testName) {
       return testMapper.insert(testName);
    }

    /**
     * 选择最大的ID
     * @return
     */
    @Override
    public Integer selectMaxID() {
        return testMapper.selectMaxID();
    }


    @Override
    public TestNameVO showAll(String testName, String userID, int curPage, int pageSize, int flag) throws T3Exception {
        // 然后判断该用户ID是否存在数据库中
        if (userMapper.selectByOperatorNo(userID) == null) {
            throw new T3Exception(userID + "不存在！请先注册");
        }
        // 如果测试用例名不为空，首先判断测试用例名是否存在数据库中
        if (StringUtils.isNotEmpty(testName)) {
            if (selectByTestName(testName) == null) {
                throw new T3Exception(testName + "不存在！");
            }
        }
        int total = 0;
        if (flag == 0) {
            total = testMapper.selectCountGroupTests(testName, userID);
        } else {
            total = testMapper.selectCountMyTests(testName, userID);
        }
        if (total == 0) {
            return null;
        }
        // 当前页的起始位置
        int startIndex = (curPage-1) * pageSize + 1;
        if (startIndex > total) {
            startIndex = 1;
            curPage = 1;
        }
        // 当前页的结束位置
        int endIndex = curPage * pageSize;
        if (endIndex > total) {
            endIndex = total;
        }
        List<TestName> testNameList = null;
        if (flag == 0) {
            testNameList = testMapper.selectPageGroupTests(testName, userID, startIndex, endIndex);
        } else {
            testNameList = testMapper.selectPageMyTests(testName, userID, startIndex, endIndex);
        }
        if (CollectionUtils.isEmpty(testNameList)) {
            throw new T3Exception("未查询到记录!");
        }
        TestNameVO nameVO = new TestNameVO();
        nameVO.setCurPage(curPage);
        nameVO.setPageSize(pageSize);
        nameVO.setTotal(total);
        nameVO.setTestNameList(testNameList);
        return nameVO;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public TestName delete(String testName, String userID) throws T3Exception {
        TestName oneTestName = testMapper.selectByTestName(testName);
        if (oneTestName == null) {
            return null;
        }
        if (!oneTestName.getUserID().equals(userID)) {
            throw new T3Exception("No Permission!");
        }
        testMapper.delete(testName);
        return oneTestName;
    }
}
