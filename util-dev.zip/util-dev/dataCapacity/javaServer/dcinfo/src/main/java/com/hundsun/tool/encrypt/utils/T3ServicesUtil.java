package com.hundsun.tool.encrypt.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.hundsun.t2sdk.impl.environment.ClientEnvironment;
import com.hundsun.t2sdk.interfaces.T2SDKException;
import com.hundsun.t3sdk.impl.client.ClientImpl;
import com.hundsun.t3sdk.impl.client.T3Services;
import com.hundsun.tool.sqltool.exception.NoSuchVariableException;
import com.hundsun.tool.utils.ResultEntity;
import com.hundsun.tool.variable.pojo.Variable;
import com.hundsun.tool.variable.service.api.VariableService;
import org.dom4j.Document;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.io.*;
import java.util.*;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

/**
 * 服务池工具类
 * @author Star_King
 */
@Component
public class T3ServicesUtil {
    private static VariableService variableService;

    @Autowired
    public void setVariableService(@Qualifier("variableService") VariableService variableService) {
        T3ServicesUtil.variableService = variableService;
    }

    private static final List<T3Services> SERVERS = new ArrayList<>(10);

    private static final List<Map<String, String>> SERVER_CONFIGS = new ArrayList<>(10);

    private static final Logger LOGGER = Logger.getLogger("com.hundsun.tool.encrypt.utils.T3ServicesUtil");

    private static final int CORE_NUM = Runtime.getRuntime().availableProcessors();

    private static ThreadPoolExecutor timedThreadPool = new ThreadPoolExecutor(CORE_NUM, 10, 3000,
            TimeUnit.MILLISECONDS, new ArrayBlockingQueue<>(5), new ThreadPoolExecutor.DiscardOldestPolicy());

    public static void setTimedThreadPool(ThreadPoolExecutor timedThreadPool) {
        T3ServicesUtil.timedThreadPool = timedThreadPool;
    }

    public synchronized static int addServer(String serverIP, String serverPort, String licencePath, String configPath) throws InterruptedException {
        // 查询服务池中是否已经有该server
        int configIndex = indexOfServerConfig(serverIP, serverPort, licencePath);
        if (configIndex != -1) {
            // 有的话就返回即可
            return configIndex;
        }
        // 创建并配置Server环境
        T3Services server = new T3Services();
        // 创建配置文件
        Document document = T3Util.createDocument(serverIP, serverPort, licencePath);
        try {
            // 将配置文件写在外存，如果目录和文件不存在就会自动创建
            T3Util.write(document, configPath);
        } catch (IOException e) {
            LOGGER.log(Level.WARNING, "写配置文件失败！");
        }
        // 一个只接受文件位置的方法
        server.setT2sdkConfigString(configPath);

        try {
            server.init();
        } catch (T2SDKException e1) {
            e1.printStackTrace();
            LOGGER.warning(e1.getErrorNo() + e1.getErrorInfo() + e1.getErrorMessage());
        }
        server.start();
        // 等待创建完成，防止获取连接失败
        Thread.sleep(500);
        File file = new File(configPath);
        if (file.exists()) {
            boolean delete = file.delete();
            if (delete) {
                LOGGER.info("配置文件删除成功！");
            } else {
                LOGGER.warning("配置文件删除失败！");
            }
        }
        // 配置连接池
        configThreadPool();
        // 将server添加到服务池中
        Map<String, String> map = new HashMap<>(4);
        map.put("serverIP", serverIP);
        map.put("serverPort", serverPort);
        map.put("licencePath", licencePath);
        SERVER_CONFIGS.add(map);
        SERVERS.add(server);
        executeTimedThread(indexOfServerConfig(serverIP, serverPort, licencePath));
        LOGGER.log(Level.INFO, "成功在池中添加了server！");
        return SERVERS.size() - 1;
    }

    private static void configThreadPool() {
        int maxPoolSize;
        int aliveTime;
        int queueSize;
        int aliveTime1;

        try {
            maxPoolSize = getParam("t3_threadPool_maxPoolSize");
        } catch (NoSuchVariableException | NumberFormatException e) {
            maxPoolSize = 50;
            e.printStackTrace();
        }

        try {
            aliveTime = getParam("t3_threadPool_aliveTime");
        } catch (NoSuchVariableException | NumberFormatException e) {
            aliveTime = 3000;
            e.printStackTrace();
        }

        try {
            queueSize = getParam("t3_threadPool_blockingQueueSize");
        } catch (NoSuchVariableException | NumberFormatException e) {
            queueSize = 20;
            e.printStackTrace();
        }

        try {
            aliveTime1 = getParam("t3_pool_aliveTime");
        } catch (NoSuchVariableException | NumberFormatException e) {
            aliveTime1 = 30;
            e.printStackTrace();
        }
        ThreadPoolExecutor timedThreadPool = new ThreadPoolExecutor(CORE_NUM, maxPoolSize, aliveTime,
                TimeUnit.MILLISECONDS, new ArrayBlockingQueue<>(queueSize), new ThreadPoolExecutor.DiscardOldestPolicy());
        setTimedThreadPool(timedThreadPool);
        TimedThread.setActiveTime(aliveTime1);
    }

    private static Integer getParam(String variableName) {
        Variable variable = variableService.searchVariableByName(variableName);
        if (variable == null) {
            LOGGER.warning("数据库中无" + variableName + "信息");
            throw new NoSuchVariableException("数据库中无该变量信息！");
        }
        String variableValue = variable.getVariableValue();
        return Integer.parseInt(variableValue);
    }

    private synchronized static int indexOfServerConfig(String serverIP, String serverPort, String licencePath) {
        for (int i = 0; i < SERVER_CONFIGS.size(); i++) {
            Map<String, String> map = SERVER_CONFIGS.get(i);
            if (map != null) {
                boolean equals1 = map.get("serverIP").equals(serverIP);
                boolean equals2 = map.get("serverPort").equals(serverPort);
                boolean equals3 = map.get("licencePath").equals(licencePath);
                if (equals1 && equals2 && equals3) {
                    return i;
                }
            }
        }
        return -1;
    }

    public synchronized static T3Services getServer(int index) {
        return SERVERS.get(index);
    }

    public synchronized static void removeServer(int index) {
        if (index >= SERVERS.size() || index < 0) {
            LOGGER.log(Level.WARNING, "下标异常！");
            return;
        }
        SERVERS.set(index, null);
        SERVER_CONFIGS.set(index, null);
    }

    private static void executeTimedThread(int index) {
        TimedThread runnable = new TimedThread();
        runnable.setIndex(index);
        timedThreadPool.execute(runnable);
    }

    public static String testTThree(String serverAlias, String serverIP, String serverPort, String licencePath, String configPath) throws InterruptedException, IOException {

        // 创建并配置Server环境
        T3Services server = new T3Services();
        // 创建配置文件
        Document document = T3Util.createDocument(serverIP, serverPort, licencePath);
        try {
            // 将配置文件写在外存，如果目录和文件不存在就会自动创建
            T3Util.write(document, configPath);
        } catch (IOException e) {
            LOGGER.log(Level.WARNING, "写配置文件失败！");
            return ResultEntity.failWithoutData("写配置文件失败！").returnResult();
        }
        // 一个只接受文件位置的方法
        server.setT2sdkConfigString(configPath);
        try {
            server.init();
            LOGGER.info("初始化成功！");
        } catch (T2SDKException e1) {
            e1.printStackTrace();
            LOGGER.warning(e1.getErrorNo() + e1.getErrorInfo() + e1.getErrorMessage());
            return ResultEntity.failWithoutData("初始化失败！" + e1.getErrorNo() + e1.getErrorInfo() + e1.getErrorMessage()).returnResult();
        }

        File logFile = new File("D:\\dataCapacity\\javaServer\\log\\log.txt");

        PrintStream ps = new PrintStream(new FileOutputStream(logFile));
        PrintStream old = System.out;
        System.setOut(ps);

        server.start();
        Thread.sleep(500);

        System.out.flush();
        System.setOut(old);

        BufferedReader br = new BufferedReader(new FileReader(logFile));
        String contentLine;
        while ((contentLine = br.readLine()) != null) {
            if (contentLine.toLowerCase().matches(".*" + "error!Failed to create connections within the specified time!".toLowerCase() + ".*")){
                server.stop();
                return ResultEntity.failWithoutData("服务连接失败！").returnResult();
            }
        }

        File file = new File(configPath);
        if (file.exists()) {
            boolean delete = file.delete();
            if (delete) {
                LOGGER.info("配置文件删除成功！");
            } else {
                LOGGER.warning("配置文件删除失败！");
            }
        }
        server.stop();
        return ResultEntity.successWithoutData().returnResult();
    }
}
