package com.hundsun.tool.collector.service.impl;

import com.hundsun.tool.collector.service.api.BusinPurposeService;
import com.hundsun.tool.collector.service.api.SqlService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.logging.Logger;

/**
 * @Author: kcaumber
 * @Date: 9/30/21 9:31 AM
 */
@Service("businPurposeService")
public class BusinPurposeServiceImpl implements BusinPurposeService {

    @Autowired
    private SqlService sqlService;

    private static final Logger LOGGER = Logger.getLogger("com.hundsun.tool.collector.service.impl.BusinPurposeServiceImpl");

    @Override
    public Map<String, Object> generateDataByPerson(Map<String, Object> data) throws IOException, SQLException {

        Map<String, Object> dataAdd = new HashMap<>();
        List<Map<String, Object>> jourInfoList = new LinkedList<>();

        List<String> tableNameList = new LinkedList<>();
        // 非居民金融账户个人信息增加 涉及表
        Map<String, Object> tableInfo = new HashMap<>();
        tableNameList.add("HS_ACT.act_person".toUpperCase());
        tableNameList.add("HS_ACT.act_nrfacct_person".toUpperCase());
        tableInfo.put("tableName", "HS_ACT.act_nrfacct_person".toUpperCase());
        tableInfo.put("business_flag", 48008);
        tableInfo.put("jour_name", "HS_ACT.act_account_info_jour".toUpperCase());
        tableNameList.add("HS_ACT.act_account_info_jour".toUpperCase());
        jourInfoList.add(tableInfo);

        tableInfo = new HashMap<>();
        tableNameList.add("HS_CIC.cic_person".toUpperCase());
        tableInfo.put("tableName", "HS_CIC.cic_person".toUpperCase());
        tableInfo.put("business_flag", 12503);
        tableInfo.put("jour_name", "HS_CIC.cic_person_jour".toUpperCase());
        tableNameList.add("HS_CIC.cic_person_jour".toUpperCase());
        jourInfoList.add(tableInfo);

        tableInfo = new HashMap<>();
        tableNameList.add("HS_CIC.cic_nrfacct_person".toUpperCase());
        tableInfo.put("tableName", "HS_CIC.cic_nrfacct_person".toUpperCase());
        tableInfo.put("business_flag", 12539);
        tableInfo.put("jour_name", "HS_CIC.cic_nrfacct_person_jour".toUpperCase());
        tableNameList.add("HS_CIC.cic_nrfacct_person_jour".toUpperCase());
        jourInfoList.add(tableInfo);

        // 非居民金融账户名称信息增加 act.postNrfacctnameAdd
        tableInfo = new HashMap<>();
        tableNameList.add("HS_ACT.act_nrfacct_name".toUpperCase());
        tableInfo.put("tableName", "HS_ACT.act_nrfacct_name".toUpperCase());
        tableInfo.put("business_flag", 48017);
        tableInfo.put("jour_name", "HS_ACT.act_account_info_jour".toUpperCase());
        tableNameList.add("HS_ACT.act_account_info_jour".toUpperCase());
        jourInfoList.add(tableInfo);

        tableNameList.add("HS_CIC.cic_nrfacct_name".toUpperCase());
        tableInfo.put("tableName", "HS_CIC.cic_nrfacct_name".toUpperCase());
        tableInfo.put("business_flag", 12548);
        tableInfo.put("jour_name", "HS_ACT.act_account_info_jour".toUpperCase());
        tableNameList.add("HS_CIC.cic_nrfacct_name_jour".toUpperCase());
        jourInfoList.add(tableInfo);

        // 非居民金融账户地址信息增加
        tableInfo = new HashMap<>();
        tableNameList.add("HS_ACT.act_nrfacct_address".toUpperCase());
        tableInfo.put("tableName", "HS_ACT.act_nrfacct_address".toUpperCase());
        tableInfo.put("business_flag", 48020);
        tableInfo.put("jour_name", "HS_ACT.act_account_info_jour".toUpperCase());
        tableNameList.add("HS_ACT.act_account_info_jour".toUpperCase());
        jourInfoList.add(tableInfo);

        tableInfo = new HashMap<>();
        tableNameList.add("HS_CIC.cic_nrfacct_address".toUpperCase());
        tableInfo.put("tableName", "HS_CIC.cic_nrfacct_address".toUpperCase());
        tableInfo.put("business_flag", 12551);
        tableInfo.put("jour_name", "HS_CIC.cic_nrfacct_address_jour".toUpperCase());
        tableNameList.add("HS_CIC.cic_nrfacct_address_jour".toUpperCase());
        jourInfoList.add(tableInfo);

        // 客户开户(完成)
        tableInfo = new HashMap<>();
        tableNameList.add("HS_ACT.act_client".toUpperCase());
        tableInfo.put("tableName", "HS_ACT.act_client".toUpperCase());
        tableInfo.put("business_flag", 1801);
        tableInfo.put("jour_name", "HS_ACT.act_account_info_jour".toUpperCase());
        tableNameList.add("HS_ACT.act_account_info_jour".toUpperCase()); //         data.putIfAbsent("business_flag", 1801);
        jourInfoList.add(tableInfo);

        tableInfo = new HashMap<>();
        tableInfo.put("tableName", "HS_ACT.act_client".toUpperCase());
        tableInfo.put("business_flag", 1801);
        tableInfo.put("jour_name", "HS_ACT.act_client_jour".toUpperCase());
        tableNameList.add("HS_ACT.act_client_jour".toUpperCase());
        jourInfoList.add(tableInfo);

        tableInfo = new HashMap<>();
        tableNameList.add("HS_ACT.act_phonenum_place".toUpperCase());
        tableInfo.put("tableName", "HS_ACT.act_phonenum_place".toUpperCase());
        tableInfo.put("business_flag", 48198);
        tableInfo.put("jour_name", "HS_ACT.act_phonenum_place_jour".toUpperCase());
        tableNameList.add("HS_ACT.act_phonenum_place_jour".toUpperCase()); //         data.putIfAbsent("business_flag", 1801);
        jourInfoList.add(tableInfo);

        tableInfo = new HashMap<>();
        tableNameList.add("HS_ACT.act_person".toUpperCase());
        tableInfo.put("tableName", "HS_ACT.act_person".toUpperCase());
        tableInfo.put("business_flag", 1801);
        tableInfo.put("jour_name", "HS_ACT.act_account_info_jour".toUpperCase());
        tableNameList.add("HS_ACT.act_account_info_jour".toUpperCase()); //         data.putIfAbsent("business_flag", 1801);
        jourInfoList.add(tableInfo);

        tableInfo = new HashMap<>();
        tableNameList.add("HS_ACT.act_tel".toUpperCase());
        tableInfo.put("tableName", "HS_ACT.act_tel".toUpperCase());
        tableInfo.put("business_flag", 1801);
        tableInfo.put("jour_name", "HS_ACT.act_account_info_jour".toUpperCase());
        tableNameList.add("HS_ACT.act_account_info_jour".toUpperCase()); //         data.putIfAbsent("business_flag", 1801);
        jourInfoList.add(tableInfo);

        tableInfo = new HashMap<>();
        tableNameList.add("HS_ACT.act_address".toUpperCase());
        tableInfo.put("tableName", "HS_ACT.act_address".toUpperCase());
        tableInfo.put("business_flag", 1801);
        tableInfo.put("jour_name", "HS_ACT.act_account_info_jour".toUpperCase());
        tableNameList.add("HS_ACT.act_account_info_jour".toUpperCase()); //         data.putIfAbsent("business_flag", 1801);
        jourInfoList.add(tableInfo);

//        cic.postPersonInner
        tableInfo = new HashMap<>();
        tableNameList.add("HS_CIC.cic_custtoacct".toUpperCase());
        tableInfo.put("tableName", "HS_CIC.cic_custtoacct".toUpperCase());
        tableInfo.put("business_flag", 12515);
        tableInfo.put("jour_name", "HS_CIC.cic_custto_acct_jour".toUpperCase());
        tableNameList.add("HS_CIC.cic_custto_acct_jour".toUpperCase()); //         data.putIfAbsent("business_flag", 1801);
        jourInfoList.add(tableInfo);

        tableInfo = new HashMap<>();
        tableNameList.add("HS_CIC.cic_basic_info".toUpperCase());
        tableInfo.put("tableName", "HS_CIC.cic_basic_info".toUpperCase());
        tableInfo.put("business_flag", 12500);
        tableInfo.put("jour_name", "HS_CIC.cic_basic_info_jour".toUpperCase());
        tableNameList.add("HS_CIC.cic_basic_info_jour".toUpperCase()); //         data.putIfAbsent("business_flag", 1801);
        jourInfoList.add(tableInfo);

        tableInfo = new HashMap<>();
        tableNameList.add("HS_CIC.cic_person".toUpperCase());
        tableInfo.put("tableName", "HS_CIC.cic_person".toUpperCase());
        tableInfo.put("business_flag", 12503);
        tableInfo.put("jour_name", "HS_CIC.cic_person_jour".toUpperCase());
        tableNameList.add("HS_CIC.cic_person_jour".toUpperCase()); //         data.putIfAbsent("business_flag", 1801);
        jourInfoList.add(tableInfo);

        tableInfo = new HashMap<>();
        tableNameList.add("HS_CIC.cic_relation_person".toUpperCase());
        tableInfo.put("tableName", "HS_CIC.cic_relation_person".toUpperCase());
        tableInfo.put("business_flag", 12521);
        tableInfo.put("jour_name", "HS_CIC.cic_relation_person_jour".toUpperCase());
        tableNameList.add("HS_CIC.cic_relation_person_jour".toUpperCase()); //         data.putIfAbsent("business_flag", 1801);
        jourInfoList.add(tableInfo);

        tableInfo = new HashMap<>();
        tableNameList.add("HS_CIC.cic_additionid".toUpperCase());
        tableInfo.put("tableName", "HS_CIC.cic_additionid".toUpperCase());
        tableInfo.put("business_flag", 12518);
        tableInfo.put("jour_name", "HS_CIC.cic_additionid_jour".toUpperCase());
        tableNameList.add("HS_CIC.cic_additionid_jour".toUpperCase()); //         data.putIfAbsent("business_flag", 1801);
        jourInfoList.add(tableInfo);

        tableInfo = new HashMap<>();
        tableNameList.add("HS_CIC.cic_contact_person".toUpperCase());
        tableInfo.put("tableName", "HS_CIC.cic_contact_person".toUpperCase());
        tableInfo.put("business_flag", 12530);
        tableInfo.put("jour_name", "HS_CIC.cic_contact_person_jour".toUpperCase());
        tableNameList.add("HS_CIC.cic_contact_person_jour".toUpperCase()); //         data.putIfAbsent("business_flag", 1801);
        jourInfoList.add(tableInfo);

        tableInfo = new HashMap<>();
        tableNameList.add("HS_CIC.cic_address".toUpperCase());
        tableInfo.put("tableName", "HS_CIC.cic_address".toUpperCase());
        tableInfo.put("business_flag", 12567);
        tableInfo.put("jour_name", "HS_CIC.cic_address_jour".toUpperCase());
        tableNameList.add("HS_CIC.cic_address_jour".toUpperCase()); //         data.putIfAbsent("business_flag", 1801);
        jourInfoList.add(tableInfo);

        tableInfo = new HashMap<>();
        tableNameList.add("HS_CIC.cic_tel".toUpperCase());
        tableInfo.put("tableName", "HS_CIC.cic_tel".toUpperCase());
        tableInfo.put("business_flag", 12583);
        tableInfo.put("jour_name", "HS_CIC.cic_tel_jour".toUpperCase());
        tableNameList.add("HS_CIC.cic_tel_jour".toUpperCase()); //         data.putIfAbsent("business_flag", 1801);
        jourInfoList.add(tableInfo);

        // 资产账户开户(完成)
        tableInfo = new HashMap<>();
        tableNameList.add("HS_ACT.act_fund_account".toUpperCase());
        tableInfo.put("tableName", "HS_ACT.act_fund_account".toUpperCase());
        tableInfo.put("business_flag", 1001);
        tableNameList.add("HS_ACT.act_fund_account_jour".toUpperCase());
        tableInfo.put("jour_name", "HS_ACT.act_fund_account_jour".toUpperCase());
        jourInfoList.add(tableInfo);

        tableInfo = new HashMap<>();
        tableNameList.add("HS_ACT.act_fund_account_control_jour".toUpperCase()); //         data.putIfAbsent("business_flag", 1001);
        tableInfo.put("tableName", "HS_ACT.act_fund_account".toUpperCase());
        tableInfo.put("business_flag", 1001);
        tableInfo.put("jour_name", "HS_ACT.act_fund_account_control_jour".toUpperCase());
        jourInfoList.add(tableInfo);

//        iic.postAuthuserOpenInner
        tableInfo = new HashMap<>();
        tableNameList.add("HS_IIC.iic_auth_user".toUpperCase());
        tableInfo.put("tableName", "HS_IIC.iic_auth_user".toUpperCase());
        tableInfo.put("business_flag", 15600);
        tableInfo.put("jour_name", "HS_IIC.iic_auth_user_jour".toUpperCase());
        tableNameList.add("HS_IIC.iic_auth_user_jour".toUpperCase()); //         data.putIfAbsent("business_flag", 1801);
        jourInfoList.add(tableInfo);

        tableNameList.add("HS_IIC.iic_revert_password".toUpperCase());

        // 一码通开户(完成)
        tableInfo = new HashMap<>();
        tableNameList.add("HS_ACT.act_csdc_acode_acct".toUpperCase());
        tableInfo.put("tableName", "HS_ACT.act_csdc_acode_acct".toUpperCase());
        tableInfo.put("business_flag", 1189);
        tableInfo.put("jour_name", "HS_ACT.act_csdc_acode_acct_jour".toUpperCase());
        tableNameList.add("HS_ACT.act_csdc_acode_acct_jour".toUpperCase()); //         data.putIfAbsent("business_flag", 1189);
        jourInfoList.add(tableInfo);


        //证券账户开户(完成)
        tableInfo = new HashMap<>();
        tableNameList.add("HS_ACT.act_csdc_holder".toUpperCase());
        tableInfo.put("tableName", "HS_ACT.act_csdc_holder".toUpperCase());
        tableInfo.put("business_flag", 1185);
        tableInfo.put("jour_name", "HS_ACT.act_csdc_holder_jour".toUpperCase());
        tableNameList.add("HS_ACT.act_csdc_holder_jour".toUpperCase());
        jourInfoList.add(tableInfo);

        tableInfo = new HashMap<>();
        tableNameList.add("HS_ACT.act_stock_holder".toUpperCase());
        tableInfo.put("tableName", "HS_ACT.act_stock_holder".toUpperCase());
        tableInfo.put("business_flag", 1104);
        tableInfo.put("jour_name", "HS_ACT.act_stock_holder_jour".toUpperCase());
        tableNameList.add("HS_ACT.act_stock_holder_jour".toUpperCase());
        jourInfoList.add(tableInfo);

        tableInfo = new HashMap<>();
        tableNameList.add("HS_ACT.act_stk_account_control_jour".toUpperCase());
        tableInfo.put("tableName", "HS_ACT.act_stock_holder".toUpperCase());
        tableInfo.put("business_flag", 1104);
        tableInfo.put("jour_name", "HS_ACT.act_stk_account_control_jour".toUpperCase());
        jourInfoList.add(tableInfo);

        //客户开户、资产账户开户
        dataAdd.put("sign_flag", '1');
        dataAdd.put("open_type", '0');
        dataAdd.put("client_status", '0');
        Date newCurrTime = new Date();
        SimpleDateFormat initDateFor = new SimpleDateFormat("yyyyMMdd");
        dataAdd.put("open_date", initDateFor.format(newCurrTime));
        dataAdd.put("sign_date", initDateFor.format(newCurrTime));
        dataAdd.put("init_date", initDateFor.format(newCurrTime));
        dataAdd.put("op_entrust_way", '4');
        dataAdd.put("reason_limit", ' ');
        dataAdd.put("valid_date", "29991231");
        dataAdd.put("handle_flag", '0');
        dataAdd.put("oper_kind", '1');
        dataAdd.put("restriction", "1");
        dataAdd.put("sub_oper_kind", '1');
        dataAdd.put("open_business", "B");
        dataAdd.put("asset_prop", '0');
        dataAdd.put("fundacct_status",'0');

        // 一码通开户
        dataAdd.put("acode_account", " ");
        dataAdd.put("csdc_account_kind", '0');
        dataAdd.put("csdc_client_gender", '1');
        dataAdd.put("csdc_degree_code", " ");
        dataAdd.put("csdc_netsvr_flag", '0');
        dataAdd.put("csdc_netsvr_password", " ");
        dataAdd.put("csdc_openorgan_code", " ");
        dataAdd.put("csdc_opennet_code", " ");

//        证券开户
        dataAdd.put("holder_kind", '0');
        dataAdd.put("csdc_holder_status", "00");
        dataAdd.put("csdc_relation_flag", '1');
        dataAdd.put("holder_level", '0');
        dataAdd.put("report_level", '0');
        dataAdd.put("seat_no", "");
        dataAdd.put("regflag", '0');
        dataAdd.put("main_flag", '1');
        dataAdd.put("holder_status", '0');

//        非居民金融账户
        dataAdd.put("organ_flag", '0');

        Map<String, Object> allData = new HashMap<>();
        allData.putAll(dataAdd);
        allData.putAll(data);


        return sqlService.generateSqlByBusiness(tableNameList, allData, jourInfoList);
    }

    @Override
    public Map<String, Object> generateDataByOrgan(Map<String, Object> data) throws IOException, SQLException {

        List<String> tableNameList = new LinkedList<>();
        Map<String, Object> dataAdd = new HashMap<>();
        List<Map<String, Object>> jourInfoList = new LinkedList<>();
        Map<String, Object> tableInfo = new HashMap<>();

        tableInfo = new HashMap<>();
        tableNameList.add("HS_ACT.act_client".toUpperCase());
        tableInfo.put("tableName", "HS_ACT.act_client".toUpperCase());
        tableInfo.put("business_flag", 13100);
        tableInfo.put("jour_name", "HS_ACT.act_client_jour".toUpperCase());
        tableNameList.add("HS_ACT.act_client_jour".toUpperCase());
        jourInfoList.add(tableInfo);

        tableInfo = new HashMap<>();
        tableNameList.add("HS_ACT.act_phonenum_place".toUpperCase());
        tableInfo.put("tableName", "HS_ACT.act_phonenum_place".toUpperCase());
        tableInfo.put("business_flag", 48198);
        tableInfo.put("jour_name", "HS_ACT.act_phonenum_place_jour".toUpperCase());
        tableNameList.add("HS_ACT.act_phonenum_place_jour".toUpperCase()); //         data.putIfAbsent("business_flag", 1801);
        jourInfoList.add(tableInfo);

        tableInfo = new HashMap<>();
        tableNameList.add("HS_ACT.act_organ".toUpperCase());
        tableInfo.put("tableName", "HS_ACT.act_organ".toUpperCase());
        tableInfo.put("business_flag", 1801);
        tableInfo.put("jour_name", "HS_ACT.act_account_info_jour".toUpperCase());
        tableNameList.add("HS_ACT.act_account_info_jour".toUpperCase()); //         data.putIfAbsent("business_flag", 1801);
        jourInfoList.add(tableInfo);

        tableInfo = new HashMap<>();
        tableNameList.add("HS_ACT.act_tel".toUpperCase());
        tableInfo.put("tableName", "HS_ACT.act_tel".toUpperCase());
        tableInfo.put("business_flag", 1801);
        tableInfo.put("jour_name", "HS_ACT.act_account_info_jour".toUpperCase());
        tableNameList.add("HS_ACT.act_account_info_jour".toUpperCase()); //         data.putIfAbsent("business_flag", 1801);
        jourInfoList.add(tableInfo);

        tableInfo = new HashMap<>();
        tableNameList.add("HS_ACT.act_address".toUpperCase());
        tableInfo.put("tableName", "HS_ACT.act_address".toUpperCase());
        tableInfo.put("business_flag", 1801);
        tableInfo.put("jour_name", "HS_ACT.act_account_info_jour".toUpperCase());
        tableNameList.add("HS_ACT.act_account_info_jour".toUpperCase()); //         data.putIfAbsent("business_flag", 1801);
        jourInfoList.add(tableInfo);

//        cic.postOrganInner
        tableInfo = new HashMap<>();
        tableNameList.add("HS_CIC.cic_custtoacct".toUpperCase());
        tableInfo.put("tableName", "HS_CIC.cic_custtoacct".toUpperCase());
        tableInfo.put("business_flag", 12515);
        tableInfo.put("jour_name", "HS_CIC.cic_custto_acct_jour".toUpperCase());
        tableNameList.add("HS_CIC.cic_custto_acct_jour".toUpperCase()); //         data.putIfAbsent("business_flag", 1801);
        jourInfoList.add(tableInfo);

        tableInfo = new HashMap<>();
        tableNameList.add("HS_CIC.cic_basic_info".toUpperCase());
        tableInfo.put("tableName", "HS_CIC.cic_basic_info".toUpperCase());
        tableInfo.put("business_flag", 12500);
        tableInfo.put("jour_name", "HS_CIC.cic_basic_info_jour".toUpperCase());
        tableNameList.add("HS_CIC.cic_basic_info_jour".toUpperCase()); //         data.putIfAbsent("business_flag", 1801);
        jourInfoList.add(tableInfo);

        tableInfo = new HashMap<>();
        tableNameList.add("HS_CIC.cic_organ".toUpperCase());
        tableInfo.put("tableName", "HS_CIC.cic_organ".toUpperCase());
        tableInfo.put("business_flag", 12506);
        tableInfo.put("jour_name", "HS_CIC.cic_organ_jour".toUpperCase());
        tableNameList.add("HS_CIC.cic_organ_jour".toUpperCase()); //         data.putIfAbsent("business_flag", 1801);
        jourInfoList.add(tableInfo);

        tableInfo = new HashMap<>();
        tableNameList.add("HS_CIC.cic_relation_person".toUpperCase());
        tableInfo.put("tableName", "HS_CIC.cic_relation_person".toUpperCase());
        tableInfo.put("business_flag", 12521);
        tableInfo.put("jour_name", "HS_CIC.cic_relation_person_jour".toUpperCase());
        tableNameList.add("HS_CIC.cic_relation_person_jour".toUpperCase()); //         data.putIfAbsent("business_flag", 1801);
        jourInfoList.add(tableInfo);

        tableInfo = new HashMap<>();
        tableNameList.add("HS_CIC.cic_additionid".toUpperCase());
        tableInfo.put("tableName", "HS_CIC.cic_additionid".toUpperCase());
        tableInfo.put("business_flag", 12518);
        tableInfo.put("jour_name", "HS_CIC.cic_additionid_jour".toUpperCase());
        tableNameList.add("HS_CIC.cic_additionid_jour".toUpperCase()); //         data.putIfAbsent("business_flag", 1801);
        jourInfoList.add(tableInfo);

        tableInfo = new HashMap<>();
        tableNameList.add("HS_CIC.cic_contact_person".toUpperCase());
        tableInfo.put("tableName", "HS_CIC.cic_contact_person".toUpperCase());
        tableInfo.put("business_flag", 12530);
        tableInfo.put("jour_name", "HS_CIC.cic_contact_person_jour".toUpperCase());
        tableNameList.add("HS_CIC.cic_contact_person_jour".toUpperCase()); //         data.putIfAbsent("business_flag", 1801);
        jourInfoList.add(tableInfo);

        tableInfo = new HashMap<>();
        tableNameList.add("HS_CIC.cic_address".toUpperCase());
        tableInfo.put("tableName", "HS_CIC.cic_address".toUpperCase());
        tableInfo.put("business_flag", 12567);
        tableInfo.put("jour_name", "HS_CIC.cic_address_jour".toUpperCase());
        tableNameList.add("HS_CIC.cic_address_jour".toUpperCase()); //         data.putIfAbsent("business_flag", 1801);
        jourInfoList.add(tableInfo);

        tableInfo = new HashMap<>();
        tableNameList.add("HS_CIC.cic_tel".toUpperCase());
        tableInfo.put("tableName", "HS_CIC.cic_tel".toUpperCase());
        tableInfo.put("business_flag", 12583);
        tableInfo.put("jour_name", "HS_CIC.cic_tel_jour".toUpperCase());
        tableNameList.add("HS_CIC.cic_tel_jour".toUpperCase()); //         data.putIfAbsent("business_flag", 1801);
        jourInfoList.add(tableInfo);

        // 非居民金融账户机构信息增加
        tableInfo = new HashMap<>();
        tableNameList.add("HS_ACT.act_nrfacct_organ".toUpperCase());
        tableInfo.put("tableName", "HS_ACT.act_nrfacct_organ".toUpperCase());
        tableInfo.put("business_flag", 48011);
        tableInfo.put("jour_name", "HS_ACT.act_csdc_acode_acct_jour".toUpperCase());
        tableNameList.add("HS_ACT.act_csdc_acode_acct_jour".toUpperCase());
        jourInfoList.add(tableInfo);

        tableInfo = new HashMap<>();
        tableNameList.add("HS_CIC.cic_nrfacct_organ".toUpperCase());
        tableInfo.put("tableName", "HS_CIC.cic_nrfacct_organ".toUpperCase());
        tableInfo.put("business_flag", 12542);
        tableInfo.put("jour_name", "HS_CIC.cic_nrfacct_organ_jour".toUpperCase());
        tableNameList.add("HS_CIC.cic_nrfacct_organ_jour".toUpperCase()); //         data.putIfAbsent("business_flag", 1801);
        jourInfoList.add(tableInfo);

        // 非居民金融账户名称信息增加 act.postNrfacctnameAdd
        tableInfo = new HashMap<>();
        tableNameList.add("HS_ACT.act_nrfacct_name".toUpperCase());
        tableInfo.put("tableName", "HS_ACT.act_nrfacct_name".toUpperCase());
        tableInfo.put("business_flag", 48017);
        tableInfo.put("jour_name", "HS_ACT.act_account_info_jour".toUpperCase());
        tableNameList.add("HS_ACT.act_account_info_jour".toUpperCase());
        jourInfoList.add(tableInfo);

        tableInfo = new HashMap<>();
        tableNameList.add("HS_CIC.cic_nrfacct_name".toUpperCase());
        tableInfo.put("tableName", "HS_CIC.cic_nrfacct_name".toUpperCase());
        tableInfo.put("business_flag", 12548);
        tableInfo.put("jour_name", "HS_CIC.cic_nrfacct_name_jour".toUpperCase());
        tableNameList.add("HS_CIC.cic_nrfacct_name_jour".toUpperCase());
        jourInfoList.add(tableInfo);

        // 非居民金融账户地址信息增加
        tableInfo = new HashMap<>();
        tableNameList.add("HS_ACT.act_nrfacct_address".toUpperCase());
        tableInfo.put("tableName", "HS_ACT.act_nrfacct_address".toUpperCase());
        tableInfo.put("business_flag", 48020);
        tableInfo.put("jour_name", "HS_ACT.act_account_info_jour".toUpperCase());
        tableNameList.add("HS_ACT.act_account_info_jour".toUpperCase());
        jourInfoList.add(tableInfo);

        tableInfo = new HashMap<>();
        tableNameList.add("HS_CIC.cic_nrfacct_address".toUpperCase());
        tableInfo.put("tableName", "HS_CIC.cic_nrfacct_address".toUpperCase());
        tableInfo.put("business_flag", 12551);
        tableInfo.put("jour_name", "HS_CIC.cic_nrfacct_address_jour".toUpperCase());
        tableNameList.add("HS_CIC.cic_nrfacct_address_jour".toUpperCase());

        // 非居民金融账户控制人信息增加
        tableInfo = new HashMap<>();
        tableNameList.add("HS_ACT.act_nrfacct_controller".toUpperCase());
        tableInfo.put("tableName", "HS_ACT.act_nrfacct_controller".toUpperCase());
        tableInfo.put("business_flag", 48014);
        tableInfo.put("jour_name", "HS_ACT.act_account_info_jour".toUpperCase());
        tableNameList.add("HS_ACT.act_account_info_jour".toUpperCase());
        jourInfoList.add(tableInfo);

        tableInfo = new HashMap<>();
        tableNameList.add("HS_CIC.cic_nrfacct_controller".toUpperCase());
        tableInfo.put("tableName", "HS_CIC.cic_nrfacct_controller".toUpperCase());
        tableInfo.put("business_flag", 48014);
        tableInfo.put("jour_name", "HS_CIC.cic_nrfacct_controller_jour".toUpperCase());
        tableNameList.add("HS_CIC.cic_nrfacct_controller_jour".toUpperCase());
        jourInfoList.add(tableInfo);


//
        dataAdd.put("organ_flag", '1');
        dataAdd.put("op_entrust_way", '4');
        dataAdd.put("sign_flag", '1');
        dataAdd.put("open_type", '0');
        Date newCurrTime = new Date();
        SimpleDateFormat initDateFor = new SimpleDateFormat("yyyyMMdd");
        dataAdd.put("open_date", initDateFor.format(newCurrTime));
        dataAdd.put("sign_date", initDateFor.format(newCurrTime));
        dataAdd.put("init_date", initDateFor.format(newCurrTime));
        dataAdd.put("main_flag", '1');

        Map<String, Object> allData = new HashMap<>();
        allData.putAll(dataAdd);
        allData.putAll(data);

        return sqlService.generateSqlByBusiness(tableNameList, allData, jourInfoList);
    }

    @Override
    public Map<String, Object> generateDataByProduce(Map<String, Object> data) throws IOException, SQLException {

        List<String> tableNameList = new LinkedList<>();
        Map<String, Object> dataAdd = new HashMap<>();
        List<Map<String, Object>> jourInfoList = new LinkedList<>();
        Map<String, Object> tableInfo = new HashMap<>();

        // 非居民金融账户机构信息增加
        tableInfo = new HashMap<>();
        tableNameList.add("HS_ACT.act_organ".toUpperCase());
        tableNameList.add("HS_ACT.act_nrfacct_organ".toUpperCase());
        tableInfo.put("tableName", "HS_ACT.act_nrfacct_organ".toUpperCase());
        tableInfo.put("business_flag", 48011);
        tableInfo.put("jour_name", "HS_ACT.act_csdc_acode_acct_jour".toUpperCase());
        tableNameList.add("HS_ACT.act_csdc_acode_acct_jour".toUpperCase());
        jourInfoList.add(tableInfo);

        tableInfo = new HashMap<>();
        tableNameList.add("HS_CIC.cic_nrfacct_organ".toUpperCase());
        tableInfo.put("tableName", "HS_CIC.cic_nrfacct_organ".toUpperCase());
        tableInfo.put("business_flag", 12542);
        tableInfo.put("jour_name", "HS_CIC.cic_nrfacct_organ_jour".toUpperCase());
        tableNameList.add("HS_CIC.cic_nrfacct_organ_jour".toUpperCase()); //         data.putIfAbsent("business_flag", 1801);
        jourInfoList.add(tableInfo);

        // 非居民金融账户名称信息增加 act.postNrfacctnameAdd
        tableInfo = new HashMap<>();
        tableNameList.add("HS_ACT.act_nrfacct_name".toUpperCase());
        tableInfo.put("tableName", "HS_ACT.act_nrfacct_name".toUpperCase());
        tableInfo.put("business_flag", 48017);
        tableInfo.put("jour_name", "HS_ACT.act_account_info_jour".toUpperCase());
        tableNameList.add("HS_ACT.act_account_info_jour".toUpperCase());
        jourInfoList.add(tableInfo);

        tableInfo = new HashMap<>();
        tableNameList.add("HS_CIC.cic_nrfacct_name".toUpperCase());
        tableInfo.put("tableName", "HS_CIC.cic_nrfacct_name".toUpperCase());
        tableInfo.put("business_flag", 12548);
        tableInfo.put("jour_name", "HS_CIC.cic_nrfacct_name_jour".toUpperCase());
        tableNameList.add("HS_CIC.cic_nrfacct_name_jour".toUpperCase());
        jourInfoList.add(tableInfo);

        // 非居民金融账户地址信息增加
        tableInfo = new HashMap<>();
        tableNameList.add("HS_ACT.act_nrfacct_address".toUpperCase());
        tableInfo.put("tableName", "HS_ACT.act_nrfacct_address".toUpperCase());
        tableInfo.put("business_flag", 48020);
        tableInfo.put("jour_name", "HS_ACT.act_account_info_jour".toUpperCase());
        tableNameList.add("HS_ACT.act_account_info_jour".toUpperCase());
        jourInfoList.add(tableInfo);

        tableInfo = new HashMap<>();
        tableNameList.add("HS_CIC.cic_nrfacct_address".toUpperCase());
        tableInfo.put("tableName", "HS_CIC.cic_nrfacct_address".toUpperCase());
        tableInfo.put("business_flag", 12551);
        tableInfo.put("jour_name", "HS_CIC.cic_nrfacct_address_jour".toUpperCase());
        tableNameList.add("HS_CIC.cic_nrfacct_address_jour".toUpperCase());

        // 非居民金融账户控制人信息增加
        tableInfo = new HashMap<>();
        tableNameList.add("HS_ACT.act_nrfacct_controller".toUpperCase());
        tableInfo.put("tableName", "HS_ACT.act_nrfacct_controller".toUpperCase());
        tableInfo.put("business_flag", 48014);
        tableInfo.put("jour_name", "HS_ACT.act_account_info_jour".toUpperCase());
        tableNameList.add("HS_ACT.act_account_info_jour".toUpperCase());
        jourInfoList.add(tableInfo);

        tableInfo = new HashMap<>();
        tableNameList.add("HS_CIC.cic_nrfacct_controller".toUpperCase());
        tableInfo.put("tableName", "HS_CIC.cic_nrfacct_controller".toUpperCase());
        tableInfo.put("business_flag", 48014);
        tableInfo.put("jour_name", "HS_CIC.cic_nrfacct_controller_jour".toUpperCase());
        tableNameList.add("HS_CIC.cic_nrfacct_controller_jour".toUpperCase());
        jourInfoList.add(tableInfo);


        dataAdd.put("organ_flag", '3');
        dataAdd.put("op_entrust_way", '4');
        dataAdd.put("sign_flag", '1');
        dataAdd.put("open_type", '0');
        Date newCurrTime = new Date();
        SimpleDateFormat initDateFor = new SimpleDateFormat("yyyyMMdd");
        dataAdd.put("open_date", initDateFor.format(newCurrTime));
        dataAdd.put("sign_date", initDateFor.format(newCurrTime));
        dataAdd.put("init_date", initDateFor.format(newCurrTime));
        dataAdd.put("main_flag", '1');

        Map<String, Object> allData = new HashMap<>();
        allData.putAll(dataAdd);
        allData.putAll(data);

        return sqlService.generateSqlByBusiness(tableNameList, allData, jourInfoList);
    }

    @Override
    public Map<String, Object> generateDataByGemAuth(Map<String, Object> data) {
        return null;
    }
}
