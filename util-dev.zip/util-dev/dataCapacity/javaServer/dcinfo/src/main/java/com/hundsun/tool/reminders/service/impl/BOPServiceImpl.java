package com.hundsun.tool.reminders.service.impl;

import com.hundsun.tool.reminders.entity.DingPersonInfo;
import com.hundsun.tool.reminders.entity.TSPass;
import com.hundsun.tool.reminders.service.BOPService;
import com.hundsun.tool.reminders.service.DingPersonInfoService;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.*;
import java.util.logging.Logger;

/**
 * @Author: kcaumber
 * @Date: 2021/11/1 17:15
 */
@Service("bopService")
public class BOPServiceImpl implements BOPService {

    private static final Logger LOGGER = Logger.getLogger("com.hundsun.tool.reminders.service.impl.BOPServiceImpl");

    private final DingPersonInfoService dingPersonInfoService;

    public BOPServiceImpl(@Qualifier("dingPersonInfoService") DingPersonInfoService dingPersonInfoService) {
        this.dingPersonInfoService = dingPersonInfoService;
    }


    @Override
    public Map<String, Object> assemblyMessage(List<TSPass> tsPassList) {

        Map<String, Object> messageMap = new HashMap<>();
        List<String> phoneNoList = new LinkedList<>();

        String content = "【BOP小伙伴每月修改单通过率】\n";
        content = content + "时间段\n";

        Date currentDate = new Date();
        SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
        // 日期格式
        String firstDateMonthly = format.format(currentDate).substring(0,6) + "01";

        content = content + firstDateMonthly + " --> " + format.format(currentDate) + "\n";

        if (tsPassList == null || tsPassList.size() == 0){
            content = content + "暂无修改单通过率";
        } else {
            content = content + "修改单通过率:\n";
// 姓名、递交单数、打回修改单数、一次性通过率
            content = content + "姓名           " + "递交单数\t\t" + "打回修改单数\t\t" + "一次性通过率\n";
            for (TSPass tsPass : tsPassList){
                DingPersonInfo dingPerson = dingPersonInfoService.selectByOperatorNo(tsPass.getOperatorNo()).get(0);
                String phoneNo;
                if (dingPerson == null){
                    LOGGER.warning("未找到对应钉钉信息");
                    phoneNo = "000000";
                    content = content + "@" + phoneNo + "      ";
                } else {
                    phoneNo = dingPerson.getDDID();
                    content = content + "@" + phoneNo;
                    for (int i = 0; i < 24 - 4 * dingPerson.getOperatorName().length(); i++){
                        content = content + " ";
                    }
                }
                phoneNoList.add(phoneNo);
                content = content + tsPass.getSl();
                for (int i = 0; i < 9 - String.valueOf(tsPass.getSl()).length(); i++){
                    content = content + "  ";
                }
                content = content + tsPass.getThsl();
                for (int i = 0; i < 11 - String.valueOf(tsPass.getThsl()).length(); i++){
                    content = content + "  ";
                }
                content = content + tsPass.getPassRate() + "%\n";
            }
        }

        messageMap.put("receiveList", phoneNoList);
        messageMap.put("content", content);
        return messageMap;


    }

    @Override
    public Map<String, Object> assemblyDingMessage(Map<String, Object> messageMap) {

        Map<String, Object> dingMessageMap = new HashMap<>();
        dingMessageMap.put("msgtype", "text");
        dingMessageMap.put("content", messageMap.get("content"));
        dingMessageMap.put("receiveList", messageMap.get("receiveList"));
        dingMessageMap.put("isAtAll", false);
        return dingMessageMap;
    }
}
