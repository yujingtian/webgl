package com.hundsun.dcinfo.jumpToMail.util;

import com.alibaba.fastjson.JSON;
import org.apache.commons.codec.binary.Base64;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.io.*;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @Author: kcaumber
 * @Date: 2021/11/2 9:22
 */
public class DingPostUtil {

    public static String addSign(String webhook, String secret) throws NoSuchAlgorithmException, UnsupportedEncodingException, InvalidKeyException {
        Long timestamp = System.currentTimeMillis();

        String stringToSign = timestamp + "\n" + secret;
        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(new SecretKeySpec(secret.getBytes("UTF-8"), "HmacSHA256"));
        byte[] signData = mac.doFinal(stringToSign.getBytes("UTF-8"));
        String sign = URLEncoder.encode(new String(Base64.encodeBase64(signData)),"UTF-8");

        return webhook + "&timestamp=" + timestamp + "&sign=" + sign;
    }

    public static String sendText(String url, String msgtype, String content, String title, String text, List<String> receiveList, boolean isAtAll) {
        PrintWriter out = null;
        BufferedReader in = null;
        String result = "";
        Map<String, Object> json = new HashMap();
        Map<String, Object> at = new HashMap();

        if ("text".equals(msgtype)) {

            json.put("msgtype", msgtype);
            Map<String, Object> localText = new HashMap();
            localText.put("content", content);
            json.put("text", localText);
            at.put("atMobiles", receiveList);
            at.put("isAtAll", isAtAll);
            json.put("at", at);
        } else {
            if (!"markdown".equals(msgtype)) {
                return "当前类型不适配";
            }

            Map<String, Object> markdown = new HashMap();
            json.put("msgtype", msgtype);
            markdown.put("title", title);
            markdown.put("text", text);
            json.put("markdown", markdown);
            at.put("atMobiles", receiveList);
            at.put("isAtAll", isAtAll);
            json.put("at", at);
        }

        try {
            URL realUrl = new URL(url);
            URLConnection conn = realUrl.openConnection();
            conn.setRequestProperty("Content-type", "application/json;charset=UTF-8");
            conn.setRequestProperty("accept", "*/*");
            conn.setRequestProperty("connection", "Keep-Alive");
            conn.setRequestProperty("user-agent", "Fiddler");
            conn.setDoOutput(true);
            conn.setDoInput(true);
            out = new PrintWriter(conn.getOutputStream());
            out.print(JSON.toJSONString(json));
            out.flush();

            String line;
            for(in = new BufferedReader(new InputStreamReader(conn.getInputStream())); (line = in.readLine()) != null; result = result + line) {
            }
        } catch (Exception var18) {
            System.out.println(var18);
            var18.printStackTrace();
        } finally {
            try {
                if (out != null) {
                    out.close();
                }

                if (in != null) {
                    in.close();
                }
            } catch (IOException var17) {
                var17.printStackTrace();
            }

        }

        return result;
    }
}
