package com.hundsun.exception;

import com.hundsun.dcinfo.util.Result;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.NoHandlerFoundException;

@ControllerAdvice
public class ExceptionController {
    @ResponseBody
    @ExceptionHandler(NoHandlerFoundException.class)
    public Result hasNotThisUrl() {
        return new Result(false, "没有此资源，请检查请求地址和参数是否正确！", null);
    }
}
