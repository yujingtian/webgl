package com.hundsun.dcinfo.friendlylink.mapper;

import com.hundsun.dcinfo.friendlylink.pojo.FriendlyLink;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author Star_King
 */
@Mapper
@Repository("friendlyLinkMapper")
public interface FriendlyLinkMapper {
    /**
     * 在数据库中添加一条FriendlyLink记录
     * @param friendlyLink 友情链接
     * @return 影响的记录数
     */
    int insertFriendlyLink(FriendlyLink friendlyLink);

    /**
     * 根据链接名和用户ID查询链接信息
     * @param friendName 链接名
     * @param userID 用户ID
     * @return 链接对象
     */
    List<FriendlyLink> selectLinkByNameAndUserID(@Param("friendName") String friendName,
                                           @Param("userID") String userID);

    /**
     * 在数据库中根据链接名删除一条记录
     * @param friendName 链接名
     * @param userID 用户ID
     * @return 影响的记录数
     */
    int deleteFriendlyLinkByNameAndUserID(@Param("friendName") String friendName,
                                          @Param("userID") String userID);

    /**
     * 在数据库中更新一条记录
     * @param friendlyLink 友情链接
     * @return 影响的记录数
     */
    int updateFriendlyLink(FriendlyLink friendlyLink);

    /**
     * 在数据库中更新一条记录
     * @param friendlyLink 友情链接
     * @return 影响的记录数
     */
    int updateFriendlyLink1(FriendlyLink friendlyLink);

    /**
     * 查询全部基础链接
     * @return 友情链接对象列表
     */
    List<FriendlyLink> selectAllBasicLink();

    /**
     * 在数据库中根据链接名查询友情链接
     * @param friendName 链接名
     * @return 友情链接对象列表
     */
    List<FriendlyLink> selectFriendlyLinkByName(@Param("friendName") String friendName);

    /**
     * 将friendOrder以后的顺序依次减1
     * @param friendOrder friendOrder
     * @return 影响的记录数
     */
    int updateFriendOrder(Integer friendOrder);

    /**
     * 查询数据库中最新的友情链接的order是多少
     * @return order
     */
    Integer selectLastFriendlyOrder();

    /**
     * 根据order顺序查询FriendlyLink
     * @param friendOrder order
     * @return FriendlyLink对象
     */
    List<FriendlyLink> selectFriendlyOrder(Integer friendOrder);

    /**
     * 将数据库内USER_ID字段增加新增用户
     * @param userID
     * @return
     */
    int updateUserID(String userID);

    /**
     * 根据userID与friendOrder查询链接
     * @param userID
     * @param friendOrder
     * @return
     */
    FriendlyLink selectFriendlyLinkByUserIDAndOrder(String userID, Integer friendOrder);

    /**
     * 根据链接名与flag查看用户是否关联此基链
     * @param friendName
     * @param friendFlag
     * @return
     */
    FriendlyLink selectLinkByNameAndFlag(String friendName, int friendFlag);

    /**
     * 更新基链的userID
     * @param link
     * @return
     */
    int updateLinkUserID(FriendlyLink link);
}
