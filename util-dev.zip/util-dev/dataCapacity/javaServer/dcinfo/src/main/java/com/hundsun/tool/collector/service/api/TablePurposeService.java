package com.hundsun.tool.collector.service.api;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

/**
 * @Author: kcaumber
 * @Date: 2021/10/22 16:56
 */
public interface TablePurposeService {
    Map<String, Object> generateDataByPerson(List<String> tableNameList, Map<String, Object> data) throws IOException, SQLException;

    Map<String, Object> generateDataByOrgan(List<String> tableNameList, Map<String, Object> data) throws IOException, SQLException;

    Map<String, Object> generateDataByProduce(List<String> tableNameList, Map<String, Object> data) throws IOException, SQLException;
}
