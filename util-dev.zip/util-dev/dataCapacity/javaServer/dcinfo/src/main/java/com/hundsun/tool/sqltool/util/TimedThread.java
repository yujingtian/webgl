package com.hundsun.tool.sqltool.util;

import com.alibaba.druid.pool.DruidDataSource;
import com.hundsun.tool.variable.service.api.VariableService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

/**
 * @author Star_King
 */
@Component
public class TimedThread implements Runnable {
    private Integer index;

    private static Integer maxActive;

    private static Integer aliveTime;

    public void setIndex(Integer index) {
        this.index = index;
    }

    public static void setMaxActive(Integer maxActive) {
        TimedThread.maxActive = maxActive;
    }

    public static void setAliveTime(Integer aliveTime) {
        TimedThread.aliveTime = aliveTime;
    }

    private static VariableService variableService;

    @Autowired
    public void setVariableService(@Qualifier("variableService") VariableService variableService) {
        TimedThread.variableService = variableService;
    }

    @Override
    public void run() {
        DruidDataSource dataSource = DataSourcesUtil.getDataSource(index);
        long connectCount1;
        long connectCount2;
        long count = 0L;
        if (dataSource == null) {
            return;
        }
        while (dataSource != null) {
            while (true) {
                connectCount1 = dataSource.getConnectCount();
//                if (connectCount1 > maxActive) {
//                    dataSource = null;
//                    DataSourcesUtil.removeDataSource(index);
//                    break;
//                }
                try {
                    TimeUnit.MINUTES.sleep(1);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                connectCount2 = dataSource.getConnectCount();
                if (connectCount1 != connectCount2) {
                    count = 0;
                    continue;
                } else {
                    count++;
                }
                if (count >= aliveTime) {
                    dataSource = null;
                    DataSourcesUtil.removeDataSource(index);
                    break;
                }
            }
        }
        Logger.getLogger("com.hundsun.tool.sqltool.util.TimedThread").info("连接池被回收！");
    }
}
