package com.hundsun.tool.collector.service.api;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Map;

/**
 * @Author: kcaumber
 * @Date: 9/30/21 9:31 AM
 */
public interface BusinPurposeService {
    /**
     * 个人开户
     * @param data 预设值
     * @return 返回Sql脚本文件以及cust_id、client_id、fundaccount、stockholder
     * @throws IOException
     * @throws SQLException
     */
    Map<String, Object> generateDataByPerson(Map<String, Object> data) throws IOException, SQLException;

    /**
     * 机构开户
     * @param data 预设值
     * @return 返回Sql脚本文件以及cust_id、client_id、fundaccount、stockholder
     * @throws IOException
     * @throws SQLException
     */
    Map<String, Object> generateDataByOrgan(Map<String, Object> data) throws IOException, SQLException;

    /**
     * 产品开户
     * @param data 预设值
     * @return 返回Sql脚本文件以及cust_id、client_id、fundaccount、stockholder
     * @throws IOException
     * @throws SQLException
     */
    Map<String, Object> generateDataByProduce(Map<String, Object> data) throws IOException, SQLException;

    /**
     * 开通创业板权限
     * @param data 预设值
     * @return 返回Sql脚本文件以及cust_id、client_id、fundaccount、stockholder
     */
    Map<String, Object> generateDataByGemAuth(Map<String, Object> data);
}
