package com.hundsun.tool.reminders.entity;

/**
 * @Author: kcaumber
 * @Date: 2021/11/12 10:55
 */
public class SpliBag {

    private String bagname;
    private String reworkingID;
    private String lastdjdate;
    private String outbagdate;
    private String endreminddate;
    private String reworkingStatusNo;
    private String sysReceiverSign;

    public SpliBag() {
    }

    public SpliBag(String bagname, String reworkingID, String lastdjdate, String outbagdate, String endreminddate, String reworkingStatusNo, String sysReceiverSign) {
        this.bagname = bagname;
        this.reworkingID = reworkingID;
        this.lastdjdate = lastdjdate;
        this.outbagdate = outbagdate;
        this.endreminddate = endreminddate;
        this.reworkingStatusNo = reworkingStatusNo;
        this.sysReceiverSign = sysReceiverSign;
    }

    public String getBagname() {
        return bagname;
    }

    public void setBagname(String bagname) {
        this.bagname = bagname;
    }

    public String getReworkingID() {
        return reworkingID;
    }

    public void setReworkingID(String reworkingID) {
        this.reworkingID = reworkingID;
    }

    public String getLastdjdate() {
        return lastdjdate;
    }

    public void setLastdjdate(String lastdjdate) {
        this.lastdjdate = lastdjdate;
    }

    public String getOutbagdate() {
        return outbagdate;
    }

    public void setOutbagdate(String outbagdate) {
        this.outbagdate = outbagdate;
    }

    public String getEndreminddate() {
        return endreminddate;
    }

    public void setEndreminddate(String endreminddate) {
        this.endreminddate = endreminddate;
    }

    public String getReworkingStatusNo() {
        return reworkingStatusNo;
    }

    public void setReworkingStatusNo(String reworkingStatusNo) {
        this.reworkingStatusNo = reworkingStatusNo;
    }

    public String getSysReceiverSign() {
        return sysReceiverSign;
    }

    public void setSysReceiverSign(String sysReceiverSign) {
        this.sysReceiverSign = sysReceiverSign;
    }

    @Override
    public String toString() {
        return "SpliBag{" +
                "bagname='" + bagname + '\'' +
                ", reworkingID='" + reworkingID + '\'' +
                ", lastdjdate='" + lastdjdate + '\'' +
                ", outbagdate='" + outbagdate + '\'' +
                ", endreminddate='" + endreminddate + '\'' +
                ", reworkingStatusNo='" + reworkingStatusNo + '\'' +
                ", sysReceiverSign='" + sysReceiverSign + '\'' +
                '}';
    }
}
