package com.hundsun.tool.functest.t3.pojo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.naming.Name;
import java.beans.Transient;
import java.io.Serializable;
import java.sql.Date;

/**
 * @author wenping 2021-07-28 11:34
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName("DCTESTNAME")
public class TestName implements Serializable {
    private static final long serialVersionUID = 8930293847392L;
    @JsonIgnore
    @TableId(value = "ID", type = IdType.ASSIGN_ID)
    private Integer ID;
    
    @TableField("USER_ID")
    private String userID;

    @TableField("TEST_NAME")
    private String testName;

    @JsonIgnore
    @TableField("GROUP_ALIAS")
    private String groupAlias;

    @TableField("MOD_TIME")
    private String modTime;

    @TableField(exist = false)
    private String userName;

    @JsonIgnore
    @TableField("TEST_SERVER")
    private String testServer;

    @TableField(value = "SHARDING_INFO")
    private String shardingInfo;

    @TableField(value = "SECURITY")
    private String security;
}
