package com.hundsun.tool.encrypt.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.hundsun.jrescloud.common.util.StringUtils;
import com.hundsun.t3sdk.impl.client.T3Services;
import com.hundsun.tool.encrypt.pojo.MicroServerInfo;
import com.hundsun.tool.encrypt.service.api.MicroServerInfoService;
import com.hundsun.tool.encrypt.utils.MyEncryptUtil;
import com.hundsun.tool.encrypt.utils.T3ServicesUtil;
import com.hundsun.tool.encrypt.utils.T3Util;
import com.hundsun.tool.utils.ResultEntity;
import com.hundsun.tool.variable.pojo.Variable;
import com.hundsun.tool.variable.service.api.VariableService;
import com.iceolive.util.StringUtil;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * @author Star_King
 */
@CrossOrigin
@RestController
@RequestMapping("/T3Encrypt")
public class T3EncryptController {
    private final MicroServerInfoService microServerInfoService;

    private final VariableService variableService;

    private final Logger LOGGER = Logger.getLogger("com.hundsun.tool.encrypt.controller.T3EncryptController");

    public T3EncryptController(@Qualifier("microServerInfoService") MicroServerInfoService microServerInfoService, @Qualifier("variableService") VariableService variableService) {
        this.microServerInfoService = microServerInfoService;
        this.variableService = variableService;
    }

    /**
     * 外部调用接口
     *
     * @param msgInfo ExternalMicroServerMsgInfo类型对象
     * @return T3返回值
     * @throws Exception 抛出异常
     */
    @PostMapping("/externalSendMessage")
    public String externalSendMessage(@RequestBody String msgInfo) throws Exception {
        JSONObject paraMap = JSON.parseObject(msgInfo);

        if (msgInfo == null) {
            // 参数合法性判断
            LOGGER.log(Level.WARNING, "非法参数！");
        } else {
            LOGGER.log(Level.INFO, msgInfo.toString());
            // 获取参数
            String userID = paraMap.getString("userId");
            String functionId = paraMap.getString("functionId");
            String serverIP = paraMap.getString("serverIP");
            String serverPort = paraMap.getString("serverPort");

            userID = (userID == null ? null : userID.trim());
            functionId = functionId.trim();
            serverIP = (serverIP == null ? null : serverIP.trim());
            serverPort = (serverPort == null ? null : serverPort.trim());

            Map<Object, Object> security = new HashMap<>();
            Map<Object, Object> param = new HashMap<>();

            JSONObject shardingInfoJson = paraMap.getJSONObject("shardingInfo");
            Map<Object, Object> shardingInfo = new HashMap<>();
            if (StringUtils.isEmpty(shardingInfoJson)){
                shardingInfo.put("custId", "");
            } else {
                for (Map.Entry<String, Object> entry : shardingInfoJson.entrySet()) {
                    shardingInfo.put(entry.getKey(), entry.getValue());
                }
            }

            JSONObject securityJson = paraMap.getJSONObject("security");
            if (!StringUtil.isEmpty(securityJson)){
                for (Map.Entry<String, Object> entry : securityJson.entrySet()){
                    security.put(entry.getKey(), entry.getValue());
                }
            }
            // 身份验证
            if (!isLegal(userID)) {
                LOGGER.log(Level.WARNING, "非法用户！");
            } else {
                String testServer = paraMap.getString("testServer");
                testServer = (testServer == null || "".equals(testServer) ? null : testServer.trim());
                String name = (StringUtil.isBlank(testServer) ? "hsbroker." + functionId.split("\\.")[0] : testServer);
                JSONObject paramJson = paraMap.getJSONObject("param");
                if (!StringUtil.isEmpty(paramJson)){
                    for (Map.Entry<String, Object> entry : paramJson.entrySet()){
                        param.put(entry.getKey(), entry.getValue());
                    }
                }
                dealWithParam(param);
                // 读取环境配置
                T3Services server = readExternalConfiguration(serverIP, serverPort);
                // 发送消息
                return T3Util.trySend(server, functionId, name, shardingInfo, security, param);
            }
        }
        return ResultEntity.failWithoutData("未知错误！").returnResult();
    }

    /**
     * 内部调用T3接口
     *
     * @param msgInfo InternalMicroServerMsgInfo对象
     * @return T3返回值
     */
    @PostMapping("/internalSendMessage")
    public String internalSendMessage(@RequestBody String msgInfo) throws Exception {
        JSONObject paraMap = JSON.parseObject(msgInfo);

        if (msgInfo == null) {
            LOGGER.log(Level.WARNING, "非法参数！");
        } else {
            String serverAlias = paraMap.getString("serverAlias");
            String functionId = paraMap.getString("functionId");
            String testServer = paraMap.getString("testServer");

            functionId = functionId.trim();
            serverAlias = serverAlias.trim();
            testServer = (testServer == null || "".equals(testServer) ? null : testServer.trim());
            String name = (StringUtil.isBlank(testServer) ? "hsbroker." + functionId.split("\\.")[0] : testServer);

            Map<Object, Object> param = new HashMap<>();
            Map<Object, Object> security = new HashMap<>();

            JSONObject shardingInfoJson = paraMap.getJSONObject("shardingInfo");
            Map<Object, Object> shardingInfo = new HashMap<>();
            if (StringUtils.isEmpty(shardingInfoJson)){
                shardingInfo.put("custId", "");
            } else {
                for (Map.Entry<String, Object> entry : shardingInfoJson.entrySet()) {
                    shardingInfo.put(entry.getKey(), entry.getValue());
                }
            }

            JSONObject securityJson = paraMap.getJSONObject("security");
            if (!StringUtil.isEmpty(securityJson)){
                for (Map.Entry<String, Object> entry : securityJson.entrySet()){
                    security.put(entry.getKey(), entry.getValue());
                }
            }
            JSONObject paramJson = paraMap.getJSONObject("param");
            if (!StringUtil.isEmpty(paramJson)){
                for (Map.Entry<String, Object> entry : paramJson.entrySet()){
                    param.put(entry.getKey(), entry.getValue());
                }
            }
            dealWithParam(param);
            T3Services server = readInternalConfiguration(serverAlias);
            return T3Util.trySend(server, functionId, name, shardingInfo, security, param);
        }
        return ResultEntity.failWithoutData("未知错误！").returnResult();
    }

    private boolean isLegal(String userID) {
        if (!StringUtil.isBlank(userID)) {
            userID = userID.trim();
            try {
                userID = Integer.parseInt(userID) + "";
            } catch (NumberFormatException e) {
                return false;
            }
        }
        return true;
    }

    /**
     * 读取外部配置文件
     */
    private T3Services readExternalConfiguration(String serverIP, String serverPort) throws Exception {
        // 根据IP + port 查询微服务信息
        MicroServerInfo serverInfo = microServerInfoService.searchInfoByIPAndPort(serverIP, serverPort);
        String EXTERNAL_PATH = "D:\\dataCapacity\\DCFile\\" + UUID.randomUUID().toString().substring(0, 20) + ".xml";
        // 添加server
        int index = T3ServicesUtil.addServer(serverInfo.getServerIP(),
                serverInfo.getServerPort(), serverInfo.getLicencePath(), EXTERNAL_PATH);
        return T3ServicesUtil.getServer(index);
    }

    /**
     * 读取内部配置文件
     */
    private T3Services readInternalConfiguration(String serverAlias) throws Exception {
        MicroServerInfo serverInfo = microServerInfoService.searchInfoByAlias(serverAlias);
        String INTERNAL_PATH = "D:\\dataCapacity\\DCFile\\" + UUID.randomUUID().toString().substring(0, 20) + ".xml";
        int index = T3ServicesUtil.addServer(serverInfo.getServerIP(),
                serverInfo.getServerPort(), serverInfo.getLicencePath(), INTERNAL_PATH);
        return T3ServicesUtil.getServer(index);
    }

    /**
     * 对于特殊参数作特殊处理
     */
    private void dealWithParam(Map<Object, Object> param) {
        if (param.containsKey("client_id") && param.containsKey("trade_password")) {
            Variable variable = variableService.searchVariableByName("t3_tradePwd_encrypt");
            if ("1".equals(variable.getVariableValue())) {
                String id = (String) param.get("client_id");
                String password = (String) param.get("trade_password");
                String national = MyEncryptUtil.t3ClientNational(id, password);
                param.put("trade_password", national);
            }
        }
        if (param.containsKey("fund_account") && param.containsKey("fund_password")) {
            Variable variable = variableService.searchVariableByName("t3_fundPwd_encrypt");
            if ("1".equals(variable.getVariableValue())) {
                String id = (String) param.get("fund_account");
                String password = (String) param.get("fund_password");
                String national = MyEncryptUtil.t3AssetNational(id, password);
                param.put("fund_password", national);
            }
        }
    }

    @PostMapping("/testTThree")
    private String testTThree(@RequestParam(value = "serverAlias", defaultValue = "") String serverAlias,
                              @RequestParam(value = "serverIP", defaultValue = "") String serverIP,
                              @RequestParam(value = "serverPort", defaultValue = "") String serverPort,
                              @RequestParam(value = "licencePath", defaultValue = "") String licencePath) throws Exception {


        if ("".equals(serverAlias)){
            return ResultEntity.failWithoutData("微服务别名为空！").returnResult();
        }
        if ("".equals(serverIP)){
            return ResultEntity.failWithoutData("微服务地址为空！").returnResult();
        }
        if ("".equals(serverPort)){
            return ResultEntity.failWithoutData("微服务端口为空！").returnResult();
        }
        if ("".equals(licencePath)){
            return ResultEntity.failWithoutData("证书为空！").returnResult();
        }
        licencePath = "D:\\dataCapacity\\DCFile\\" + licencePath;

        String configPath = "D:\\dataCapacity\\DCFile\\" + UUID.randomUUID().toString().substring(0, 20) + ".xml";

        String s = T3ServicesUtil.testTThree(serverAlias, serverIP, serverPort, licencePath, configPath);
        JSONObject jsonObject = JSON.parseObject(s);
        Boolean b = jsonObject.getObject("success", Boolean.class);
        if (b){
            return ResultEntity.successWithData("连接测试通过！").returnResult();
        } else {
            return s;
        }

    }
}
