package com.hundsun.tool.handover.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Star_King
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Handover {
    private String tableName;
    private String tableAlias;
    private String hasUser;
}
