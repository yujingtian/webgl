package com.hundsun.dcinfo.series.service;

import com.hundsun.dcinfo.series.entity.Series;
import com.baomidou.mybatisplus.extension.service.IService;
import com.hundsun.dcinfo.series.entity.SeriesMenu;
import com.hundsun.dcinfo.util.Result;

import java.math.BigDecimal;
import java.util.List;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author Wanglei
 * @since 2021-07-15
 */
public interface ISeriesService extends IService<Series> {
    public BigDecimal getInsertId();

    public boolean isHasSameNameInOneParentSeries(Series series);

    public String getAllPath(BigDecimal serId);

    public boolean insertOne(Series series);

    public List<SeriesMenu> getSeriesTree();

    public boolean deleteById(BigDecimal serId);

    public boolean isCanAddInfoInThisSeries(String path);

    public BigDecimal getLatsIdByPath(String oldSeries);

    public boolean isCanAddHere(String toUpperCase,BigDecimal pId);

    public boolean getUpdateIsDeleteDatFile();

}
