package com.hundsun.tool.uf3Dictionary.Tool;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.hundsun.dcinfo.jumpToMail.controller.JumpController;
import com.hundsun.tool.task.timed.controller.TimedTaskController;
import com.hundsun.tool.task.timed.pojo.TimedTaskParam;
import com.hundsun.tool.task.timed.util.QuartzUtil;
import com.hundsun.tool.uf3Dictionary.entity.UF2_Dictionary;
import com.hundsun.tool.uf3Dictionary.entity.UF3_Dictionary;
import com.hundsun.tool.uf3Dictionary.mapper.DictMapper;
import com.hundsun.tool.utils.ResultEntity;
import com.hundsun.tool.variable.mapper.VariableMapper;
import com.hundsun.tool.variable.pojo.Variable;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.compress.utils.IOUtils;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.dom4j.DocumentException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.tmatesoft.svn.core.SVNException;
import org.tmatesoft.svn.core.SVNProperties;
import org.tmatesoft.svn.core.io.SVNRepository;

import javax.annotation.Resource;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import java.io.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.*;

/**
 * @Author tdragon.
 * @Date 2021/8/25.
 * @Time 15:47
 * @Description: 用以发送 uf2 3 的数据字典差异的excel
 */
@Slf4j
@RestController
public class SendEmailController {

    @Autowired
    private JavaMailSenderImpl mailSender;

    @Autowired
    QuartzUtil quartzUtil;

    @Autowired
    JumpController jumpController;

    @Autowired
    DictMapper dictMapper;

    @Autowired
    VariableMapper variableMapper;

    @Value("${svnUrl}")
    private String url;

    @Value("${svnName}")
    private String name;

    @Value("${svnPwd}")
    private String pwd;

    @Value("${spring.mail.username}")
    String fromEmail;


//    @Value("${sendComplexMail}")
//    String sendComplexMail;

    TimedTaskParam timedTaskParam=new TimedTaskParam();

    public void sendComplexMail() throws MessagingException {
        //复杂邮件
        MimeMessage mimeMessage = mailSender.createMimeMessage();
        MimeMessageHelper messageHelper = new MimeMessageHelper(mimeMessage,true);
        messageHelper.setFrom(fromEmail);
        messageHelper.setTo("longtao40733@hundsun.com");
//        messageHelper.setTo("zhoupeng12447@hundsun.com");
        messageHelper.setSubject("自动发送");
        messageHelper.setText("",false);
//      messageHelper.addInline("UF2.0与3.0字典差异样本", new File("uf2_3.xlsx"));
        File file = new File("uf2_3.xlsx");

        System.out.println("file.getPath() " + file.getPath());
        System.out.println("file.getAbsolutePath() " + file.getAbsolutePath());
        messageHelper.addAttachment(file.getName(), file);
        mailSender.send(mimeMessage);
    }



    @Scheduled(cron ="0 0 9 ? * MON")
    @PostMapping("sendUF2_3Mail2")
    public String sendUFMail() throws MessagingException, IOException, SVNException, DocumentException, ParseException {
        timedTaskParam.setUserID("123456");
        timedTaskParam.setTask("com.hundsun.tool.uf3Dictionary.Tool.SendEmailController.sendUFMail");
//      timedTaskParam.setCron("0 0 9 ? * MON");
        timedTaskParam.setCron("0/2 * * * * ?");
        timedTaskParam.setTaskType("1");
        Date currentTime = new Date();
        Date start=new Date(currentTime.getTime()+1000);
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss");
        String currentTimeString = format.format(start);
        timedTaskParam.setStartTime(currentTimeString);
        //5分钟后结束
        timedTaskParam.setEndTime(format.format(new Date(currentTime.getTime()+1000*60*5)));
        HashMap<String, Object> hashMap = new HashMap<>(16);
        hashMap.put("String","执行中");
        List<Map<String,Object>> objects = new ArrayList<>();
        objects.add(hashMap);
        timedTaskParam.setParams(objects);
        timedTaskParam.setFlag("0");
//        quartzUtil.createTask(timedTaskParam);
//        log.info("{}",timedTaskParam);
        /*登录svn 下载文件dict.xml 并解析*/
        SVNRepository repository = OperateSvn.getRepository(url, name, pwd);
        //此变量用来存放要查看的文件的属性名/属性值列表。
        SVNProperties fileProperties = new SVNProperties();
        //此输出流用来存放要查看的文件的内容。
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        //创建xml文件
        File file = new File("dict.xml");
        String absolutePath = file.getAbsolutePath();
        //         写入
        OutputStream outputStream=new FileOutputStream(file);
        long l = repository.getFile("/trunk/Sources/DevCodes/经纪业务运营平台V21/公共资源/dict.xml", -1, fileProperties, baos);
        outputStream.write(baos.toByteArray());

        List<UF2_Dictionary> uf2Dictionaries = ExcelTool.parseXml();
        List<UF3_Dictionary> uf3Dictionaries = dictMapper.getAllDictionariesSection(uf2Dictionaries.get(0).getDicItem(), "999999");

        uf3Dictionaries.stream().sorted(Comparator.comparingInt(o -> Integer.parseInt(o.getDictEntry())));
        //可以看出这区间也有uf2不包含
        System.out.println("uf3Dictionaries.get(0) = " + uf3Dictionaries.get(0));
        //这 uf2 没得的
        List<UF3_Dictionary> nonBetweenDictItem = dictMapper.getAllDictionariesNonBetweenDictItem();
        System.out.println("nonBetweenDictItem = " + nonBetweenDictItem.size());

        uf3Dictionaries.forEach((e) -> {
            e.setDictEntry(e.getDictEntry() == null ? "" : e.getDictEntry());
            e.setEntryName(e.getEntryName() == null ? "" : e.getEntryName());
            e.setSubEntry(e.getSubEntry() == null ? "" : e.getSubEntry());
            e.setDictPrompt(e.getDictPrompt() == null ? "" : e.getDictPrompt());
        });
        /** 填充好并形成excel  */
        fillExcel(uf3Dictionaries,uf2Dictionaries,outputStream);
        /** 转换 multipartfile --->file */
        File excel = new File("uf2_3.xlsx");
        FileInputStream inputStream = new FileInputStream(excel);

        MultipartFile attachment=new MockMultipartFile("file",excel.getName(),"text/plain",IOUtils.toByteArray(inputStream));

        JSONObject jsonObject = new JSONObject();
        HashMap<String, String> map = new HashMap<>();
        //接收人
        Variable emailReceiverList = variableMapper.selectVariableByName("DictDiffEmailReceiverList");
//        receiver.add("longtao40733@hundsun.com");
        String receiver = emailReceiverList.getVariableValue();
        //发送附件给指定人
        jumpController.sendMailComplex(attachment,"自动发送", "自动发送", receiver);
        sendComplexMail();
        return ResultEntity.successWithoutData().returnResult();
    }


  public  void fillExcel(List<UF3_Dictionary> uf3Dictionaries,List<UF2_Dictionary> uf2Dictionaries,OutputStream outputStream) throws IOException {
      LocalDateTime start = LocalDateTime.now();
      log.info("填充excel数据开始时间：" + start);
      XSSFWorkbook workbook = new XSSFWorkbook();
        CellStyle style = workbook.createCellStyle();
        OutputStream writeExcelStream = new FileOutputStream("uf2_3.xlsx");
        XSSFSheet s1 = workbook.createSheet("uf2独有的");
        XSSFSheet s2 = workbook.createSheet("uf3独有的");
        ExcelTool.setTableHead(s1, style);
        ExcelTool.setTableHead(s2, style);
        int uf3length = uf3Dictionaries.size();
        int uf2length = uf2Dictionaries.size();
        log.info("一开始得到的数据 uf2length = " + uf2length);
        log.info("一开始得到的数据 uf3length = " + uf3length);
        //先把两边都重复的行都去掉
        HashSet<UF2_Dictionary> uf2set = new HashSet<>(uf2Dictionaries);
        log.info("uf2set.size() = " + uf2set.size());
        HashSet<UF3_Dictionary> uf3set = new HashSet<>(uf3Dictionaries);
        log.info("uf3set.size() = " + uf3set.size());
      List<UF3_Dictionary> nonBetweenDictItem = dictMapper.getAllDictionariesNonBetweenDictItem();
      HashSet<UF3_Dictionary> nonBetweenSet = new HashSet<>(nonBetweenDictItem);
        log.info("nonBetweenSet.size() = " + nonBetweenSet.size());

        HashMap<String, UF2_Dictionary> uf2HashMap = new HashMap<>();

        HashMap<String, UF3_Dictionary> uf3HashMap = new HashMap<>();

        HashMap<String, UF3_Dictionary> uf3PutRepeatMap = new HashMap<>();

        int uf2Repeat=0;
        int uf3Repeat=0;
        for (UF3_Dictionary uf3_dictionary : uf3set) {
            String dictEntry = uf3_dictionary.getDictEntry();
            String entryName = uf3_dictionary.getEntryName();
            String subEntry = uf3_dictionary.getSubEntry();
            String dictPrompt = uf3_dictionary.getDictPrompt();
            String enSystemStr = uf3_dictionary.getEnSystemStr();
            String key = dictEntry + entryName + subEntry + dictPrompt;
            if(!uf3HashMap.containsKey(key)){
                uf3HashMap.put(key,uf3_dictionary);
            }else {
                uf3Repeat++;
                uf3PutRepeatMap.put(key,uf3_dictionary);
                //                System.out.println("set之后 4字段作为key 还有重复: "+key+" 旧值"+uf3HashMap.get(key));
            }
        }
        for (UF2_Dictionary uf2_dictionary : uf2set) {
            String dicItem = uf2_dictionary.getDicItem();
            String itemDesc = uf2_dictionary.getItemDesc();
            String childItem = uf2_dictionary.getChildItem();
            String desc = uf2_dictionary.getDesc();
            String key = dicItem + itemDesc + childItem + desc;
            if(!uf2HashMap.containsKey(key)){
                uf2HashMap.put(key, uf2_dictionary);
            }else {
                uf2Repeat++;
            }

        }
        int uf2_no_uf3=0;
        //通过uf3key 找 uf2
        for (Map.Entry<String, UF3_Dictionary> entry : uf3HashMap.entrySet()) {
            UF3_Dictionary uf3v = entry.getValue();
            UF2_Dictionary uf2v = uf2HashMap.get(entry.getKey());
            // uf2 中没得 uf3的 都用同一个key 字典编号+字典名+子项编号+子项名
            //            uf3 独有
            if (!uf2HashMap.containsKey(entry.getKey())) {
                uf2_no_uf3++;
                XSSFRow row = s2.createRow(uf2_no_uf3+2);
                row.createCell(12).setCellValue(uf3v.getDictEntry());
                row.createCell(13).setCellValue(uf3v.getEntryName());
                row.createCell(15).setCellValue(uf3v.getSubEntry());
                row.createCell(16).setCellValue(uf3v.getDictPrompt());
                row.createCell(17).setCellValue(uf3v.getEnSystemStr());
                //               System.out.println("key= " + entry.getKey() + " and value= " + entry.getValue());
            }
        }


        int uf3_no_uf2=0;
        for (Map.Entry<String, UF2_Dictionary> entry : uf2HashMap.entrySet()) {
            UF2_Dictionary uf2v = entry.getValue();
            if(!uf3HashMap.containsKey(entry.getKey())){
                //                uf2独有
                uf3_no_uf2++;
                XSSFRow row = s1.createRow(uf3_no_uf2+2);
                row.createCell(0).setCellValue(uf2v.getDicItem());
                row.createCell(1).setCellValue(uf2v.getItemDesc());
                row.createCell(3).setCellValue(uf2v.getChildItem());
                row.createCell(4).setCellValue(uf2v.getDesc());
            }
        }

      log.info("set后 为转化map put进去 uf3Repeat = " + uf3Repeat);
      log.info("set后 为转化map put进去 uf2Repeat = " + uf2Repeat);
      log.info("uf2不包含uf3 key uf2_no_uf3 即uf3独有的 = " + uf2_no_uf3);
      log.info("uf3不包含uf2 key uf3_no_uf2 即uf2独有的 = " + uf3_no_uf2);
      log.info("uf2HashMap size()= " + uf2HashMap.size());
      log.info("uf3HashMap size()= " + uf3HashMap.size());
      log.info("uf3PutRepeatMap.size() = " + uf3PutRepeatMap.size());
      workbook.write(writeExcelStream);
      outputStream.flush();
      workbook.close();
      outputStream.close();
      LocalDateTime end = LocalDateTime.now();
      log.info("填充excel数据结束时间：" + end);
      Duration duration=Duration.between(end, start);
      log.info("耗时："+duration.getSeconds());
    }

}
