package com.hundsun.tool.reminders.entity;

/**
 * @Author: kcaumber
 * @Date: 2021/11/11 19:11
 */
public class BigBagOut {

    private String reworkingId;
    private String sysReceiverSign;
    private String reworkingStatusNo;

    public BigBagOut() {
    }

    public BigBagOut(String reworkingId, String sysReceiverSign, String reworkingStatusNo) {
        this.reworkingId = reworkingId;
        this.sysReceiverSign = sysReceiverSign;
        this.reworkingStatusNo = reworkingStatusNo;
    }

    public String getReworkingId() {
        return reworkingId;
    }

    public void setReworkingId(String reworkingId) {
        this.reworkingId = reworkingId;
    }

    public String getSysReceiverSign() {
        return sysReceiverSign;
    }

    public void setSysReceiverSign(String sysReceiverSign) {
        this.sysReceiverSign = sysReceiverSign;
    }

    public String getReworkingStatusNo() {
        return reworkingStatusNo;
    }

    public void setReworkingStatusNo(String reworkingStatusNo) {
        this.reworkingStatusNo = reworkingStatusNo;
    }

    @Override
    public String toString() {
        return "BigBagOut{" +
                "reworkingId='" + reworkingId + '\'' +
                ", sysReceiverSign='" + sysReceiverSign + '\'' +
                ", reworkingStatusNo='" + reworkingStatusNo + '\'' +
                '}';
    }
}
