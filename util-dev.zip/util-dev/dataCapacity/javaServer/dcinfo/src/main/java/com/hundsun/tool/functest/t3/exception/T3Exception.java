package com.hundsun.tool.functest.t3.exception;

/**
 * 该异常类是为了处理批量插入数据时，有字段数为空的情况下，插入异常
 * @author wenping 2021-07-23 17:28
 */
public class T3Exception extends Exception{
    public T3Exception(){}

    public T3Exception(String message) {
        super(message);
    }

}
