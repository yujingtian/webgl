package com.hundsun.tool.encrypt.service.impl;

import com.hundsun.tool.encrypt.mapper.MicroServerInfoMapper;
import com.hundsun.tool.encrypt.pojo.MicroServerInfo;
import com.hundsun.tool.encrypt.service.api.MicroServerInfoService;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author Star_King
 */
@Scope("prototype")
@Service("microServerInfoService")
public class MicroServerInfoServiceImpl implements MicroServerInfoService {
    private final MicroServerInfoMapper microServerInfoMapper;

    public MicroServerInfoServiceImpl(@Qualifier("microServerInfoMapper") MicroServerInfoMapper microServerInfoMapper) {
        this.microServerInfoMapper = microServerInfoMapper;
    }

    @Override
    public MicroServerInfo searchInfoByAlias(String serverAlias) {
        if (serverAlias == null || "".equals(serverAlias)) {
            System.out.println("传入的微服务别名不合法！");
            return null;
        }
        List<MicroServerInfo> infos = microServerInfoMapper.selectInfoByName(serverAlias);
        if (infos.isEmpty()) {
            System.out.println("数据库中没有该客户端相关信息！");
            return null;
        }
        return infos.get(0);
    }

    @Override
    public MicroServerInfo searchInfoByIPAndPort(String serverIP, String serverPort) {
        if (serverIP == null || "".equals(serverIP) || serverPort == null || "".equals(serverPort)) {
            System.out.println("传入参数不合法！");
            return null;
        }
        List<MicroServerInfo> infos = microServerInfoMapper.selectInfoByIPAndPort(serverIP, serverPort);
        if (infos.isEmpty()) {
            System.out.println("数据库中没有该客户端相关信息！");
            return null;
        }
        return infos.get(0);
    }
}
