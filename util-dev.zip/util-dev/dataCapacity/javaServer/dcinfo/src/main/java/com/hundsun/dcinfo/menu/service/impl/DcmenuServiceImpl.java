package com.hundsun.dcinfo.menu.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.hundsun.dcinfo.menu.entity.Dcmenu;
import com.hundsun.dcinfo.menu.mapper.DcmenuMapper;
import com.hundsun.dcinfo.menu.service.IDcmenuService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author Wanglei
 * @since 2021-07-30
 */
@Service
public class DcmenuServiceImpl extends ServiceImpl<DcmenuMapper, Dcmenu> implements IDcmenuService {

    @Override
    public List<Dcmenu> getCanSearchByOne() {
        QueryWrapper<Dcmenu> wrapper = new QueryWrapper<>();
        wrapper.eq("CANSEARCH", "1");
        List<Dcmenu> list = baseMapper.selectList(wrapper);
        return list;
    }

    @Override
    public String getOfflineUrl() {
        QueryWrapper<Dcmenu> wrapper = new QueryWrapper<>();
        wrapper.eq("MENU_CAPTION", "离线工具");
        Dcmenu one = baseMapper.selectOne(wrapper);
        return one.getMenuUrl();
    }

    @Override
    public List<Dcmenu> getMenuList(String keyword, Integer start, Integer end) {
        return baseMapper.getMenuList(keyword, start, end);
    }
}
