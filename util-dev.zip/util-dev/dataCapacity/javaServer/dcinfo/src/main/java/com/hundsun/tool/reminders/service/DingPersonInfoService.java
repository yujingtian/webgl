package com.hundsun.tool.reminders.service;

import com.hundsun.tool.reminders.entity.DingPersonInfo;

import java.util.List;

/**
 * @Author: kcaumber
 * @Date: 2021/11/1 17:41
 */
public interface DingPersonInfoService {
    List<String> selectPhoneByOperatorNo(String operatorNo);

    List<DingPersonInfo> selectByOperatorNo(String operatorNo);
}
