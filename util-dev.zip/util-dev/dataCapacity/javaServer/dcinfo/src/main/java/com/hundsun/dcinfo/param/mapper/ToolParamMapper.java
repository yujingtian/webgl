package com.hundsun.dcinfo.param.mapper;

import com.hundsun.dcinfo.param.entity.ToolParam;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author Wanglei
 * @since 2021-08-05
 */
@Mapper
public interface ToolParamMapper extends BaseMapper<ToolParam> {

}
