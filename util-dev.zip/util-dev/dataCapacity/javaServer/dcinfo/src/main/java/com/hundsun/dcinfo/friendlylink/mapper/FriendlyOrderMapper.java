package com.hundsun.dcinfo.friendlylink.mapper;

import com.hundsun.dcinfo.friendlylink.pojo.FriendlyOrder;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

/**
 * @Author: kcaumber
 * @Date: 9/10/21 2:15 PM
 */
@Mapper
@Repository("LinkOrderMapper")
public interface FriendlyOrderMapper {
    /**
     * 根据userID，查找对应的排序
     * @param userID
     * @return
     */
    FriendlyOrder selectOrderByUserID(String userID);

    /**
     * 新建一条friendlyOrder
     * @param friendlyOrder
     * @return
     */
    int insertOrder(FriendlyOrder friendlyOrder);

    int updateOrder(String userID, String nameList);
}
