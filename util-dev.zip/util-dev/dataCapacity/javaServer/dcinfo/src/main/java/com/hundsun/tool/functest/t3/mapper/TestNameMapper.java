package com.hundsun.tool.functest.t3.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hundsun.tool.functest.t3.pojo.TestName;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

import java.sql.SQLException;
import java.util.List;

/**
 * @author wenping 2021-07-28 13:48
 */
@Mapper
@Repository
public interface TestNameMapper extends BaseMapper<TestName> {
    /**
     * 根据测试用例名字查询
     * @param testName 测试用例名
     * @return
     */
//    @Select("select * from DCTESTNAME where TEST_NAME = #{testName}")
    TestName selectByTestName(@Param("testName") String testName);

    /**
     * 插入一条[测试用例名，别名]到DCTESTNAME
     * @param testName 一条[测试用例名，别名]
     * @return
     */
//    @Insert("insert into DCTESTNAME(ID, USER_ID, TEST_NAME, GROUP_ALIAS, MOD_TIME) VALUES(#{testName.ID}, #{testName.userID}, #{testName.testName}, #{testName.groupAlias})")
//    int insert(@Param("testName") TestName testName);

    /**
     * 选择最大的ID
     * @return
     */
    @Select("select max(ID) from DCTESTNAME")
    Integer selectMaxID();

    int selectCountGroupTests(@Param("testName") String testName, @Param("userID") String userID);

    List<TestName> selectPageGroupTests(@Param("testName") String testName, @Param("userID") String userID, int startIndex, int endIndex);

    int selectCountMyTests(@Param("testName") String testName, @Param("userID") String userID);

    List<TestName> selectPageMyTests(@Param("testName") String testName, @Param("userID") String userID, int startIndex, int endIndex);


    @Delete("delete from DCTESTNAME where TEST_NAME = #{testName}")
    int delete(@Param("testName") String testName);
}
