package com.hundsun.dcinfo.controller;

import com.alibaba.fastjson.JSONObject;
import com.hundsun.dcinfo.dctool.entity.Tool;
import com.hundsun.dcinfo.series.mapper.SeriesMapper;
import com.hundsun.dcinfo.util.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;


@RestController
@RequestMapping("/30DataCapacity")
@CrossOrigin
public class CallOtherApp {
    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private SeriesMapper mapper;

    @RequestMapping("/GetTypeJsonData")
    public Object call7777GetTypeJson(@RequestBody JSONObject jsonObject) {
        String url = mapper.getRemoteUrl("python_admin_url") + "/30DataCapacity/GetTypeJsonData";
        return restTemplate.postForObject(url, jsonObject, Object.class);
    }
}
