package com.hundsun.tool.reminders.mapper;

import com.hundsun.tool.reminders.entity.DingPersonInfo;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @Author: kcaumber
 * @Date: 2021/11/1 17:46
 */
@Mapper
@Repository("dingPersonInfoMapper")
public interface DingPersonInfoMapper {
    List<String> selectPhoneByOperatorNo(String operatorNo);

    List<DingPersonInfo> selectByOperatorNo(String operatorNo);
}
