package com.hundsun.tool.t2Encrypt.service.impl;

import com.hundsun.tool.t2Encrypt.service.T2EncryptService;
import org.springframework.stereotype.Service;
import java.util.HashMap;
import java.util.Map;

/**
 * @Author: kcaumber
 * @Date: 10/21/21 10:34 AM
 */
@Service("t2EncryptService")
public class T2EncryptServiceImpl implements T2EncryptService {

    @Override
    public Map<String, String> qryStockHoldersByFundAccount() {
        Map<String, Object> params = new HashMap<>();
        params.put("arch_image_no", "113457");
        params.put("check_flag", "0");


        return new HashMap<>();
    }
}
