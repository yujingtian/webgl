package com.hundsun.tool.uf3Dictionary.mapper;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * @Author tdragon.
 * @Date 2021/8/22.
 * @Time 21:44
 * @Description:
 */

@Mapper
@DS("hs_efficiency")
public interface SubDictMapper extends BaseMapper<SubDictMapper>{
}
