package com.hundsun.tool.utils;

import java.sql.*;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.logging.Logger;

/**
 * @Author: kcaumber
 * @Date: 2021/11/8 14:31
 */
public class DBWorkUtil {

    private final static Logger LOGGER = Logger.getLogger("com.hundsun.tool.utils.DBWorkUtil");

    private static final String url = "jdbc:oracle:thin:@10.20.23.102:1521:HS2008"; // 链接字符串
    private static final String user = "hs_asset";
    private static final String pwd = "hundsun";
    private static Connection con = null;

    public static boolean ExecParamDB(String sqlStr, ArrayList<Map<String, Object>> param){
        boolean success = true;
        PreparedStatement pstm = null;
        try {
            con = DriverManager.getConnection(url, user, pwd);
            pstm = con.prepareStatement(sqlStr);
            for (int i = 0; i < param.size(); i++){
                int j =1;
                for (Map.Entry<String, Object> entry : param.get(i).entrySet()){
                    pstm.setObject(j, entry.getValue());
                    j++;
                }
                pstm.addBatch();
                if (i % 100 == 0){
                    pstm.executeBatch();
                    pstm.clearBatch();
                }
            }
            pstm.executeBatch();
        } catch (SQLException throwables) {
            LOGGER.warning("批量处理报错了,sql运行中止");
            throwables.printStackTrace();
            success = false;
        } finally {
            // 关闭执行通道
            if (pstm != null) {
                try {
                    pstm.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            // 关闭连接通道
            try {
                if (con != null && (!con.isClosed())) {
                    try {
                        con.close();
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return success;
    }

    public static ArrayList<Map<String, String>> SelectDB(String sqlStr){
        PreparedStatement pstm = null;
        try {
            con = DriverManager.getConnection(url, user, pwd);
            pstm = con.prepareStatement(sqlStr);
            ResultSet rs = pstm.executeQuery();
            ResultSetMetaData resultSetMetaData = rs.getMetaData();
            ArrayList<Map<String, String>> resultList = new ArrayList<>();
            while (rs.next()){
                Map<String, String> result = new LinkedHashMap<>();
                for (int i = 1; i <= resultSetMetaData.getColumnCount(); i++){
                    result.put(resultSetMetaData.getColumnName(i).toLowerCase(), rs.getString(resultSetMetaData.getColumnName(i)));
                }
                resultList.add(result);
            }

            return resultList;
        } catch (SQLException throwables) {
            LOGGER.warning("查询报错");
            throwables.printStackTrace();
            return null;
        } finally {
            // 关闭执行通道
            if (pstm != null) {
                try {
                    pstm.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            // 关闭连接通道
            try {
                if (con != null && (!con.isClosed())) {
                    try {
                        con.close();
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public static boolean ExecDB(String sqlStr) {
        boolean success = true;
        PreparedStatement pstm = null;
        try {
            con = DriverManager.getConnection(url, user, pwd);
            pstm = con.prepareStatement(sqlStr);
            pstm.executeQuery();
        } catch (SQLException throwables) {
            LOGGER.warning("SQL语句执行报错");
            throwables.printStackTrace();
            success =false;
        } finally {
            // 关闭执行通道
            if (pstm != null) {
                try {
                    pstm.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            // 关闭连接通道
            try {
                if (con != null && (!con.isClosed())) {
                    try {
                        con.close();
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return success;
    }
}
