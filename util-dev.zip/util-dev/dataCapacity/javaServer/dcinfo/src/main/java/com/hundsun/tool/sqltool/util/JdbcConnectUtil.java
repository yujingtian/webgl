package com.hundsun.tool.sqltool.util;

import com.alibaba.druid.filter.Filter;
import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.druid.sql.parser.ParserException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.hundsun.tool.sqltool.exception.NoSuchVariableException;
import com.hundsun.tool.sqltool.filter.MysqlSqlFilter;
import com.hundsun.tool.sqltool.filter.OracleSqlFilter;
import com.hundsun.tool.sqltool.pojo.DcDbServerInfo;
import com.hundsun.tool.utils.ResultEntity;
import com.hundsun.tool.variable.pojo.Variable;
import com.hundsun.tool.variable.service.api.VariableService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.sql.*;
import java.util.*;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * JDBC的一些工具方法类
 *
 * @author Star_King
 */
@Component("jdbcConnectUtil")
public class JdbcConnectUtil {
    private static VariableService variableService;

    @Autowired
    public void setVariableService(@Qualifier("variableService") VariableService variableService) {
        JdbcConnectUtil.variableService = variableService;
    }

    private static final LinkedList<Connection> CONNECTION_QUEUE = new LinkedList<>();

    private static final Logger LOGGER = Logger.getLogger("com.hundsun.tool.sqltool.util.JdbcConnectUtil");

    private static final ThreadLocal<Boolean> QUERY_SUCCESS = new ThreadLocal<>();

    /**
     * 判断Mysql数据库是否可以连接
     *
     * @param ip       IP地址
     * @param port     端口号
     * @param username 用户名
     * @param password 密码
     * @return 连接成功标志，成功返回true，失败返回false
     */
    public static boolean mysqlConnectTest(String ip, String port, String username, String password) {
        String URL = "jdbc:mysql://" + ip + ":" + port + "/";
        registerDriver("com.mysql.cj.jdbc.Driver");
        return testGetConnection(URL, username, password);
    }

    /**
     * 判断Oracle数据库是否可以连接
     *
     * @param ip       IP地址
     * @param port     端口号
     * @param username 用户名
     * @param password 密码
     * @return 连接成功标志，成功返回true，失败返回false
     */
    public static boolean oracle11gConnectTest(String ip, String port, String sid, String username, String password) {
        String URL = "jdbc:oracle:thin:@" + ip + ":" + port + ":" + sid;
        registerDriver("oracle.jdbc.OracleDriver");
        return testGetConnection(URL, username, password);
    }

    /**
     * 判断Oracle数据库是否可以连接
     *
     * @param ip       IP地址
     * @param port     端口号
     * @param username 用户名
     * @param password 密码
     * @return 连接成功标志，成功返回true，失败返回false
     */
    public static boolean oracle19cConnectTest(String ip, String port, String sid, String username, String password) {
        String URL = "jdbc:oracle:thin:@" + ip + ":" + port + "/" + sid;
        registerDriver("oracle.jdbc.OracleDriver");
        return testGetConnection(URL, username, password);
    }

    /**
     * 注册驱动
     *
     * @param driverClassName 驱动类名
     */
    public static void registerDriver(String driverClassName) {
        try {
            Class.forName(driverClassName);
        } catch (ClassNotFoundException e) {
            LOGGER.log(Level.WARNING, "驱动注册失败！");
        }
    }

    /**
     * 测试连接
     *
     * @param URL      URL
     * @param username 用户名
     * @param password 密码
     * @return 连接成功标志，成功返回true，失败返回false
     */
    public static boolean testGetConnection(String URL, String username, String password) {
        try {
            DriverManager.getConnection(URL, username, password);
            return true;
        } catch (Exception e) {
            LOGGER.log(Level.WARNING, "数据库连接失败！");
            return false;
        }
    }

    /**
     * 用连接池获取连接
     *
     * @return Connection连接
     */
    public static Connection getConnection(DruidDataSource dataSource) {
        try {
            adjustDatasource(dataSource);
            return dataSource.getConnection();
        } catch (Exception e) {
            System.out.print("连接失败！");
            return null;
        }
    }

    private static void adjustDatasource(DruidDataSource dataSource) {
        int maxActive = getParam("sql_datasource_maxActive");
        int index = DataSourcesUtil.indexOfDataSource(dataSource.getUrl(), dataSource.getUsername());
        Integer lastMaxActive = DataSourcesUtil.getLastMaxActive(index);
        if (lastMaxActive == null) {
            return;
        }
        if (lastMaxActive > maxActive) {
            long connectCount = dataSource.getConnectCount();
            if (connectCount > maxActive) {
                for (int i = 0; i < connectCount - maxActive + 1; i++) {
                    Connection head = CONNECTION_QUEUE.poll();
                    try {
                        if (head != null) {
                            head.close();
                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
        DataSourcesUtil.setLastMaxActive(index, maxActive);
        dataSource.setMaxActive(maxActive);
        TimedThread.setMaxActive(maxActive);
    }

    /**
     * 测试连接的总入口
     *
     * @param info 数据库表DCDBSERVERINFO中查询到的记录对象
     * @return 连接成功标志，成功返回true，失败返回false
     */
    public static boolean connectTest(DcDbServerInfo info) {
        boolean connected = false;
        if ("0".equals(info.getDbType())) {
            // 执行Mysql
            connected = mysqlConnectTest(info.getDbIP(), String.valueOf(info.getDbPort()), info.getDbUser(), info.getDbPwd());
        } else if ("2".equals(info.getDbType())) {
            // 执行Oracle19c
            connected = oracle19cConnectTest(info.getDbIP(), String.valueOf(info.getDbPort()), info.getDbSid(), info.getDbUser(), info.getDbPwd());
        } else if ("1".equals(info.getDbType())) {
            // 执行Oracle11g
            connected = oracle11gConnectTest(info.getDbIP(), String.valueOf(info.getDbPort()), info.getDbSid(), info.getDbUser(), info.getDbPwd());
        }
        return connected;
    }

    /**
     * 返回ResultEntity的Json格式
     *
     * @param connected 连接成功的标志
     * @return ResultEntity的Json格式字符串
     * @throws JsonProcessingException 抛出异常
     */
    public static String returnConnectResult(boolean connected) throws JsonProcessingException {
        if (connected) {
            LOGGER.log(Level.INFO, "建立连接成功！");
            return ResultEntity.successWithoutData().returnResult();
        } else {
            LOGGER.log(Level.WARNING, "建立连接失败！");
            return ResultEntity.failWithoutData("建立连接失败！").returnResult();
        }
    }

    /**
     * 执行查询
     *
     * @param info 数据库表DCDBSERVERINFO中查询到的记录对象
     * @param sql  执行的sql语句
     * @return 查询到的结果集，以ResultEntity的json字符串的形式给出，
     * 其中包含data域中包含List<List<String>>形式的二维数组，其中二维数组第一行为表头，用来存储查询到的结果集
     */
    public static String executeSelect(DcDbServerInfo info, String sql) throws JsonProcessingException, SQLException {
        String dbType = info.getDbType();
        String dbIP = info.getDbIP();
        Integer dbPort = info.getDbPort();
        String dbSid = info.getDbSid();
        String dbName = info.getDbName();
        String dbUser = info.getDbUser();
        String dbPwd = info.getDbPwd();
        String mysqlURL = "jdbc:mysql://" + dbIP + ":" + dbPort + "/" + dbName;
        String oracle11gURL = "jdbc:oracle:thin:@" + dbIP + ":" + dbPort + ":" + dbSid;
        String oracle19cURL = "jdbc:oracle:thin:@" + dbIP + ":" + dbPort + "/" + dbSid;

        if ("0".equals(dbType)) {
            // 执行Mysql
            return execute(sql, dbUser, dbPwd, mysqlURL);
        } else if ("1".equals(dbType)) {
            // 执行Oracle11g
            return execute(sql, dbUser, dbPwd, oracle11gURL);
        } else if ("2".equals(dbType)) {
            // 执行Oracle19c
            return execute(sql, dbUser, dbPwd, oracle19cURL);
        } else {
            LOGGER.log(Level.WARNING, "非法的数据库类型！");
            return ResultEntity.failWithoutData("").returnResult();
        }
    }

    private static String execute(String sql, String dbUser, String dbPwd, String URL) throws SQLException, JsonProcessingException {
        // 获取连接池
        DruidDataSource dataSource = getDataSource(dbUser, dbPwd, URL);
        Connection connection;
        try {
            // 获取连接
            connection = getConnection(dataSource);
            // 将连接池加到了池中
            CONNECTION_QUEUE.add(connection);
        } catch (ParserException e) {
            return ResultEntity.failWithoutData("查询失败！").returnResult();
        }
        // 查询sql
        List<List<Map<String, String>>> result = getSelectResult(connection, sql);
        if (!QUERY_SUCCESS.get()) {
            LOGGER.log(Level.WARNING, "查询失败！");
            // 防止内存泄露
            QUERY_SUCCESS.remove();
            return ResultEntity.failWithoutData("查询失败！").returnResult();
        } else {
            LOGGER.log(Level.INFO, "查询成功！");
            QUERY_SUCCESS.remove();
            return ResultEntity.successWithData(result).returnResult();
        }
    }

    private static DruidDataSource getDataSource(String dbUser, String dbPwd, String URL) {
        DruidDataSource dataSource;
        // 判断池中是否有该连接池
        int index = DataSourcesUtil.indexOfDataSource(URL, dbUser);
        if (index == -1) {
            // 如果不存在，就创建新的连接池
            dataSource = new DruidDataSource();
            dataSource.setUrl(URL);
            dataSource.setUsername(dbUser);
            dataSource.setPassword(dbPwd);
            // 设置参数
            druidConfig(dataSource);
            // 设置拦截器
            List<Filter> filters = new ArrayList<>(10);
            // 判断数据库类型
            if (URL.startsWith("jdbc:mysql")) {
                dataSource.setDriverClassName("com.mysql.cj.jdbc.Driver");
                MysqlSqlFilter filter = new MysqlSqlFilter();
                filters.add(filter);
            } else if (URL.startsWith("jdbc:oracle:thin:@")) {
                dataSource.setDriverClassName("oracle.jdbc.OracleDriver");
                OracleSqlFilter filter = new OracleSqlFilter();
                filters.add(filter);
            } else {
                LOGGER.log(Level.WARNING, "URL出错！");
            }
            // 设置过滤器，将非法语句拦截
            dataSource.setProxyFilters(filters);
            // 添加到池中
            boolean success = DataSourcesUtil.addDataSource(dataSource);
            if (!success) {
                return null;
            }
        } else {
            // 如果存在就取出即可
            dataSource = DataSourcesUtil.getDataSource(index);
        }
        return dataSource;
    }

    /**
     * 配置一个连接池的参数
     *
     * @param dataSource 连接池对象
     */
    private static void druidConfig(DruidDataSource dataSource) {
        try {
            Integer initialSize = getParam("sql_datasource_initialSize");
            dataSource.setInitialSize(initialSize);
        } catch (NoSuchVariableException | NumberFormatException e) {
            dataSource.setInitialSize(5);
            e.printStackTrace();
        }

        try {
            Integer minIdle = getParam("sql_datasource_minIdle");
            dataSource.setMinIdle(minIdle);
        } catch (NoSuchVariableException | NumberFormatException e) {
            dataSource.setMinIdle(5);
            e.printStackTrace();
        }

        try {
            Integer maxActive = getParam("sql_datasource_maxActive");
            dataSource.setMaxActive(maxActive);
            TimedThread.setMaxActive(maxActive);
        } catch (NoSuchVariableException | NumberFormatException e) {
            dataSource.setMaxActive(10);
            e.printStackTrace();
        }

        try {
            dataSource.setMaxWait(getParam("sql_datasource_maxWait"));
        } catch (NoSuchVariableException | NumberFormatException e) {
            dataSource.setMaxWait(10000);
            e.printStackTrace();
        }

        try {
            dataSource.setTimeBetweenEvictionRunsMillis(getParam("sql_datasource_timeBetweenEvictionRunsMillis"));
        } catch (NoSuchVariableException | NumberFormatException e) {
            dataSource.setTimeBetweenEvictionRunsMillis(30000);
            e.printStackTrace();
        }

        int CORE_NUM = Runtime.getRuntime().availableProcessors();
        int maxPoolSize;
        int aliveTime;
        int queueSize;
        int aliveTime1;

        try {
            maxPoolSize = getParam("sql_threadPool_maxPoolSize");
        } catch (NoSuchVariableException | NumberFormatException e) {
            maxPoolSize = 50;
            e.printStackTrace();
        }

        try {
            aliveTime = getParam("sql_threadPool_aliveTime");
        } catch (NoSuchVariableException | NumberFormatException e) {
            aliveTime = 3000;
            e.printStackTrace();
        }

        try {
            queueSize = getParam("sql_threadPool_blockingQueueSize");
        } catch (NoSuchVariableException | NumberFormatException e) {
            queueSize = 20;
            e.printStackTrace();
        }

        try {
            aliveTime1 = getParam("sql_pool_aliveTime");
        } catch (NoSuchVariableException | NumberFormatException e) {
            aliveTime1 = 30;
            e.printStackTrace();
        }
        ThreadPoolExecutor timedThreadPool = new ThreadPoolExecutor(CORE_NUM, maxPoolSize, aliveTime,
                TimeUnit.MILLISECONDS, new ArrayBlockingQueue<>(queueSize), new ThreadPoolExecutor.DiscardOldestPolicy());
        DataSourcesUtil.setTimedThreadPool(timedThreadPool);
        TimedThread.setAliveTime(aliveTime1);

    }

    private static Integer getParam(String variableName) {
        Variable variable = variableService.searchVariableByName(variableName);
        if (variable == null) {
            throw new NoSuchVariableException("数据库中无该变量信息！");
        }
        String variableValue = variable.getVariableValue();
        return Integer.parseInt(variableValue);
    }

    /**
     * 根据sql查询数据库，并将结果封装到二维数组中，其中二维数组的每一个值都是一个键值对
     *
     * @param connection 连接对象
     * @param sql        sql语句
     * @return 二维数组，其中二维数组的每一个值都是一个键值对
     * @throws SQLException 抛出异常
     */
    public static List<List<Map<String, String>>> getSelectResult(Connection connection, String sql) throws SQLException {
        QUERY_SUCCESS.set(false);
        if (connection != null) {
            List<List<Map<String, String>>> list = new ArrayList<>(10);
            PreparedStatement statement = connection.prepareStatement(sql, ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            // 查询到的结果集
            ResultSet resultSet;
            try {
                resultSet = statement.executeQuery();
                ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
                int columnCount = resultSetMetaData.getColumnCount();
                List<String> columnNameList = new ArrayList<>(10);
                for (int i = 0; i < columnCount; i++) {
                    String columnName = resultSetMetaData.getColumnName(i + 1);
                    columnNameList.add(columnName);
                }
                // 将结果集封装
                while (resultSet.next()) {
                    List<Map<String, String>> tempList = new ArrayList<>(10);
                    for (int j = 0; j < columnCount; j++) {
                        Map<String, String> tempMap = new HashMap<>(2);
                        String columnName = columnNameList.get(j);
                        String value = resultSet.getString(columnName);
                        tempMap.put(columnName, value);
                        tempList.add(tempMap);
                    }
                    list.add(tempList);
                }
                QUERY_SUCCESS.set(true);
                return list;
            } catch (Throwable throwable) {
                return null;
            }
        } else {
            return null;
        }
    }
}