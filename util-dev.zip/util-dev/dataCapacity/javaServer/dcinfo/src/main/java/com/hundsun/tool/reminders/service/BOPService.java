package com.hundsun.tool.reminders.service;

import com.hundsun.tool.reminders.entity.TSPass;

import java.util.List;
import java.util.Map;

/**
 * @Author: kcaumber
 * @Date: 2021/11/1 17:15
 */
public interface BOPService {
    Map<String, Object> assemblyMessage(List<TSPass> tsPassList);

    Map<String, Object> assemblyDingMessage(Map<String, Object> messageMap);
}
