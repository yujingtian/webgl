package com.hundsun.dcinfo.param.entity;

import lombok.Data;

@Data
public class UpParam {
    private ToolParam oldParam;
    private ToolParam newParam;
}
