package com.hundsun.tool.t2Encrypt.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.hundsun.jrescloud.common.t2.context.ContextUtil;
import com.hundsun.jrescloud.common.t2.dataset.DatasetService;
import com.hundsun.jrescloud.common.t2.dataset.IDataset;
import com.hundsun.jrescloud.common.t2.dataset.IDatasets;
import com.hundsun.jrescloud.common.t2.event.EventReturnCode;
import com.hundsun.jrescloud.common.t2.event.EventType;
import com.hundsun.jrescloud.common.t2.event.IEvent;
import com.hundsun.t2sdk.impl.client.T2Services;

import com.hundsun.t2sdk.interfaces.T2SDKException;
import com.hundsun.tool.utils.ResultEntity;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;

import java.util.*;
import java.util.logging.Logger;

/**
 * @Author: kcaumber
 * @Date: 2021/11/12 16:04
 */
public class T2Util {

    private static final Logger LOGGER = Logger.getLogger("com.hundsun.tool.t2Encrypt.util.T2Util");

    public static Document createDocument(String serverIP, String serverPort, String licencePath) {
        Document document = DocumentHelper.createDocument();
        Element root = document.addElement("t2sdk-configuration");
        root.addElement("performance")
                .addAttribute("heartbeatTime", "400") //心跳间隔
                .addAttribute("acquireConnWaitTime", "3000") // 连接等待时间ms
                .addAttribute("registerTime", "600") //保持时间 s
                .addAttribute("reconnInterval", "0") // 重连时间间隔
                .addAttribute("localServerName", "t2sdk") // 客户端名称
                .addAttribute("callBackTime", "5000") // 同步发送等待时间
                .addAttribute("enmCompress", "true"); // 是否压缩包体
        Element parents = root.addElement("parents");
        Element parent = parents.addElement("parent")
                .addAttribute("parentName", "myServer") // 本节点主动去连接的T2节点名
                .addAttribute("safeLevel", "NONE"); // 明文
        parent.addElement("limit")
                .addAttribute("licenseFile", licencePath)
                .addAttribute("encrypt", "HSBlowfish"); // 证书加密
        Element members = parent.addElement("members");
        Random r = new Random(1);
        int no = r.nextInt(100);
        members.addElement("member")
                .addAttribute("no", String.valueOf(no)) // 多成员时不能重复
                .addAttribute("address", serverIP)
                .addAttribute("port", serverPort)
                .addAttribute("charset", "gbk")
                .addAttribute("poolSize", "1");
        Element logAdapter = root.addElement("logAdapter")
                .addAttribute("className", "com.hundsun.t2sdk.impl.util.CommonLogAdapter");
        LOGGER.info("生成配置文件成功！");
        return document;

    }

    public static String trySend(T2Services server, String functionId, List<Map<String, Object>> paramList) throws T2SDKException, JsonProcessingException {

        List<Map<String, Object>> resultList = new ArrayList<>();
        for (Map<String, Object> param : paramList) {
            IEvent event = ContextUtil.getServiceContext().getEventFactory()
                    .getEventByAlias(functionId, EventType.ET_REQUEST);
            IDataset dataset = DatasetService.getDefaultInstance().getDataset(paramList.get(0));

            event.putEventData(dataset);
            IEvent rsp = server.getClient("myServer").sendReceive(event, 10000);
            if (rsp.getReturnCode() != EventReturnCode.I_OK) { //返回错误
                IDatasets result = rsp.getEventDatas();
                IDataset ds = result.getDataset(0);
                ds.beforeFirst();
                ds.next();
                String errorNo = ds.getString("error_no");
                String errorInfo = ds.getString("error_info") + "[" + functionId + "]";
                String errorPathInfo = ds.getString("error_pathinfo");

                return ResultEntity.failWithDataMsg(errorNo + " : " + errorInfo + " : " + errorPathInfo, resultList).returnResult();
            } else {
                resultList.addAll(getResponse(rsp));
            }
        }
        return ResultEntity.successWithData(resultList).returnResult();



    }

    private static List<Map<String, Object>> getResponse(IEvent rsp) throws T2SDKException, JsonProcessingException {

        //获得结果集
        IDatasets result = rsp.getEventDatas();
        //获得结果集总数
        int datasetCount = result.getDatasetCount();
        System.out.println(datasetCount);
        List<Map<String, Object>> resultMapList = new ArrayList<>();

        //遍历所有的结果集
        for (int i = 0; i < datasetCount; i++) {
            // 开始读取单个结果集的信息
            IDataset ds = result.getDataset(i);
            int columnCount = ds.getColumnCount();
            // 遍历单个结果集记录，遍历前首先将指针置到开始
            ds.beforeFirst();
            while (ds.hasNext()) {
                Map<String, Object> resultMap = new LinkedHashMap<>();
                ds.next();
                // 遍历单个结果集列信息
                for (int j = 1; j <= columnCount; j++) {
                    resultMap.put(ds.getColumnName(j), ds.getStringArray(j));
                }
                resultMapList.add(resultMap);
            }
        }
        return resultMapList;
    }


}

