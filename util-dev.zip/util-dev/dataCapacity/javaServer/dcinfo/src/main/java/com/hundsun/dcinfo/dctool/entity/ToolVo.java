package com.hundsun.dcinfo.dctool.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ToolVo {
    private Integer current;
    private Integer size;
    private Long total;
    private List<Tool> list;
}
