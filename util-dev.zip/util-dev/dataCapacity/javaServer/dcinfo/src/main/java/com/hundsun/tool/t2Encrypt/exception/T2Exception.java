package com.hundsun.tool.t2Encrypt.exception;

import java.util.HashMap;
import java.util.Map;

/**
 * @Author: kcaumber
 * @Date: 2021/11/17 16:06
 */
public class T2Exception extends Throwable {

    private Map<String, String> errorInfos = new HashMap();

    public String getBaseBizRuntimeExceptionInfo() {
        return this.getErrorNo() + "->" + this.getErrorInfo() + "->" + this.getErrorPathInfo();
    }
    public Map<String, String> getErrorInfos() {
        return this.errorInfos;
    }

    public T2Exception(String errorNo, String errorInfo, String errorPathInfo) {
        this.errorInfos.put("errorNo", errorNo);
        this.errorInfos.put("errorInfo", errorInfo);
        this.errorInfos.put("errorPathInfo", errorPathInfo);
    }

    public T2Exception(Exception e) {
        this.errorInfos.put("errorNo", "-1");
        this.errorInfos.put("errorInfo", e.getLocalizedMessage());
        this.errorInfos.put("errorPathInfo", e.fillInStackTrace().toString());
    }

    public String getErrorNo() {
        return (String)this.errorInfos.get("errorNo");
    }

    public String getErrorInfo() {
        return (String)this.errorInfos.get("errorInfo");
    }

    public String getErrorPathInfo() {
        return (String)this.errorInfos.get("errorPathInfo");
    }}
