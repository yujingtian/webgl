package com.hundsun.dcinfo.jumpToMail.service;

import com.hundsun.dcinfo.jumpToMail.pojo.DingTalk;

import java.util.List;

/**
 * @Author: kcaumber
 * @Date: 8/25/21 10:48 AM
 */
public interface DingTalkService {

    String insertDingTalk(DingTalk dingTalk);

    String deleteDingTalk(String groupName);

    List<DingTalk> selectAllDT();

    DingTalk selectByGroupName(String groupName);

    String updateDingTalk(DingTalk dingTalk);
}
