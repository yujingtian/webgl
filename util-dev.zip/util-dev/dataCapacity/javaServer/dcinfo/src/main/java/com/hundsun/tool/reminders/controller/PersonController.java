package com.hundsun.tool.reminders.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.hundsun.tool.utils.DBWorkUtil;
import com.hundsun.tool.utils.ResultEntity;
import com.iceolive.util.StringUtil;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * @Author: kcaumber
 * @Date: 2021/11/19 14:07
 */
@CrossOrigin
@RestController
@RequestMapping("/person")
public class PersonController {

    @RequestMapping("/insert")
    public String insert(@RequestParam(value = "no", defaultValue = "") String no,
                         @RequestParam(value = "name", defaultValue = "") String name,
                         @RequestParam(value = "teamName", defaultValue = "") String teamName,
                         @RequestParam(value = "teamLeader", defaultValue = "") String teamLeader,
                         @RequestParam(value = "DDID", defaultValue = "") String DDID) throws JsonProcessingException {

        if (StringUtil.isEmpty(no) || StringUtil.isEmpty(name) || StringUtil.isEmpty(teamName) || StringUtil.isEmpty(teamLeader) || StringUtil.isEmpty(DDID)){
            return ResultEntity.failWithoutData("部分参数为空，请检查").returnResult();
        }
        if (no.length() != 5){
            return ResultEntity.failWithoutData("请输入五位工号").returnResult();
        }
        if (!("1".equals(teamLeader) || "0".equals(teamLeader))){
            return ResultEntity.failWithoutData("1为TeamLeader，0为普通组员，请勿输入其他字符").returnResult();
        }
        if (DDID.length() != 11){
            return ResultEntity.failWithoutData("请输入十一位钉钉注册手机号").returnResult();
        }

        Map<String, Boolean> resultMap = new LinkedHashMap<>();
        ArrayList<Map<String, String>> resultList;
        String sqlStr = "select * from HS_ASSET.tsoperators a where a.OPERATOR_NO = '" + no + "'";
        resultList = DBWorkUtil.SelectDB(sqlStr);
        if (resultList == null){
            resultMap.put("tsoperators", false);
        } else {
            if (resultList.size() == 0){
                sqlStr = "insert into HS_ASSET.TSOPERATORS (OPERATOR_NO, OPERATOR_NAME) VALUES ('" + no + "', '" + name + "')";
            } else {
                sqlStr = "update HS_ASSET.TSOPERATORS set OPERATOR_NAME = '" + name + "' where OPERATOR_NO = '" + no + "'";
            }
            resultMap.put("tsoperators", DBWorkUtil.ExecDB(sqlStr));
        }

        sqlStr = "select * from HS_ASSET.TEAMMEMBERS a where a.EMPLOYEECODE = '" + no + "'";
        resultList = DBWorkUtil.SelectDB(sqlStr);
        if (resultList == null){
            resultMap.put("teammembers", false);
        } else {
            if (resultList.size() == 0) {
                sqlStr = "insert into HS_ASSET.TEAMMEMBERS (EMPLOYEECODE, TEAMNAME, TEAMLEADER) VALUES ('" + no + "', '" + teamName + "', '" + teamLeader + "')";
            } else {
                sqlStr = "update HS_ASSET.TEAMMEMBERS set TEAMNAME = '" + teamName + "', TEAMLEADER = '" + teamLeader + "' where EMPLOYEECODE = '" + no + "'";
            }
            resultMap.put("teammembers", DBWorkUtil.ExecDB(sqlStr));
        }

        sqlStr = "select * from HS_ASSET.DINGPERSONINFO where OPERATOR_NO = '" + no + "'";
        resultList = DBWorkUtil.SelectDB(sqlStr);
        if (resultList == null){
            resultMap.put("dingpersoninfo", false);
        } else {
            if (resultList.size() == 0) {
                sqlStr = "insert into DINGPERSONINFO (OPERATOR_NO, OPERATOR_NAME, DDID) VALUES ('" + no + "', '" + name + "', '" + DDID +"')";
            } else {
                sqlStr = "update HS_ASSET.DINGPERSONINFO set OPERATOR_NAME = '" + name + "', DDID = '" + DDID + "' where OPERATOR_NO = '" + no + "'";
            }
            resultMap.put("dingpersoninfo", DBWorkUtil.ExecDB(sqlStr));
        }

        sqlStr = "select * from HS_ASSET.DCMODIFIER where OPERATOR_NO = '" + no + "'";
        resultList = DBWorkUtil.SelectDB(sqlStr);
        if (resultList == null){
            resultMap.put("dcmodifier", false);
        } else {
            if (resultList.size() == 0){
                sqlStr = "insert into HS_ASSET.DCMODIFIER (OPERATOR_NO) values (" + no + ")";
                resultMap.put("dcmodifier", DBWorkUtil.ExecDB(sqlStr));
            }
        }
        return ResultEntity.successWithData(resultMap).returnResult();
    }


    @RequestMapping("/delete")
    public String delete (@RequestParam(value = "no", defaultValue = "") String no) throws JsonProcessingException {
        if (StringUtil.isEmpty(no)){
            return ResultEntity.failWithoutData("工号为空，请重新输入").returnResult();
        }
        if (no.length() != 5){
            return ResultEntity.failWithoutData("请输入五位工号").returnResult();
        }
        String sqlStr = "delete from HS_ASSET.DCMODIFIER where OPERATOR_NO = '" + no +"'";
        Map<String, Boolean> map = new HashMap<>();
        map.put("DCMODIFIER", DBWorkUtil.ExecDB(sqlStr));

        sqlStr = "delete from HS_ASSET.TEAMMEMBERS where EMPLOYEECODE = '" + no + "'";
        map.put("TEAMMEMBERS", DBWorkUtil.ExecDB(sqlStr));
        return ResultEntity.successWithData(map).returnResult();
    }

    @RequestMapping("/deleteAnyway")
    public String deleteAnyway(@RequestParam(value = "no", defaultValue = "") String no) throws JsonProcessingException {
        if (StringUtil.isEmpty(no)){
            return ResultEntity.failWithoutData("工号为空，请重新输入").returnResult();
        }
        if (no.length() != 5){
            return ResultEntity.failWithoutData("请输入五位工号").returnResult();
        }
        String sqlStr = "";
        Map<String, Boolean> resultMap = new HashMap<>();

        sqlStr = "delete from HS_ASSET.tsoperators where OPERATOR_NO = '" + no +"'";
        resultMap.put("tsoperators", DBWorkUtil.ExecDB(sqlStr));

        sqlStr = "delete from HS_ASSET.TEAMMEMBERS a where a.EMPLOYEECODE = '" + no +"'";
        resultMap.put("teammembers", DBWorkUtil.ExecDB(sqlStr));

        sqlStr = "delete from HS_ASSET.DINGPERSONINFO a where a.OPERATOR_NO = '" + no +"'";
        resultMap.put("dingpersoninfo", DBWorkUtil.ExecDB(sqlStr));

        sqlStr = "delete from HS_ASSET.DCMODIFIER where OPERATOR_NO = '" + no +"'";
        resultMap.put("DCMODIFIER", DBWorkUtil.ExecDB(sqlStr));

        return ResultEntity.successWithDataMsg("此操作直接删除对应工号的信息，相关修改单可能会报错，如有误，请及时联系管理员补救", resultMap).returnResult();
    }
}
