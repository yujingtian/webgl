package com.hundsun.tool.reminders.service;

import com.alibaba.fastjson.JSONArray;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.Map;

/**
 * @Author: kcaumber
 * @Date: 2021/11/8 13:56
 */
public interface TsTaskService {

    boolean InsertTmpTSTaskList(JSONArray dataJson) throws SQLException;

    Map<String, Object> assemblyMessage() throws ParseException;

    Map<String, Object> assemblyDingMessage(Map<String, Object> messageMap);
}
