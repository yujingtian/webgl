package com.hundsun.dcinfo.param.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.hundsun.dcinfo.dctool.entity.Tool;
import com.hundsun.dcinfo.dctool.service.ToolService;
import com.hundsun.dcinfo.param.entity.ParamList;
import com.hundsun.dcinfo.param.entity.ToolParam;
import com.hundsun.dcinfo.param.mapper.ToolParamMapper;
import com.hundsun.dcinfo.param.service.ToolParamService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.hundsun.dcinfo.util.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import sun.net.ftp.FtpClientProvider;

import java.sql.Wrapper;
import java.util.*;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author Wanglei
 * @since 2021-08-05
 */
@Service
public class ToolParamServiceImpl extends ServiceImpl<ToolParamMapper, ToolParam> implements ToolParamService {
    @Autowired
    private ToolService toolService;


    /**
     * 添加工具配置列表
     *
     * @param toolId 工具ID
     * @param list   配置列表
     * @return 返回处理信息
     */
    @Override
    public Result addParamList(String toolId, List<ToolParam> list) {
        // 查询工具是否存在
        if (toolService.getById(toolId) == null) {
            return new Result(false, "不存在此工具,无法在此添加！", null);
        }
        QueryWrapper<ToolParam> wrapper = new QueryWrapper<>();
        wrapper.eq("TOOL_ID", toolId);
        List<ToolParam> inDbList = this.list(wrapper);
        // 处理完整保证数据库中记录不超过十项
        if (list.size() > 10 || (inDbList.size() + list.size()) > 10) {
            return new Result(false, "配置最多十项！", null);
        }
        List<String> nameList = new ArrayList<>();
        // 将已有的工具名称添加到检查集合中
        for (ToolParam param : inDbList) {
            nameList.add(param.getName());
        }
        for (int i = 0; i < list.size(); i++) {
            list.get(i).setToolId(toolId);
            // 判断参数是否重复
            if (nameList.contains(list.get(i).getName())) {
                return new Result(false, "参数错误！", null);
            } else {
                nameList.add(list.get(i).getName());
            }
        }
        if (this.saveBatch(list)) {
            return new Result(true, "添加成功！", null);
        } else {
            return new Result(false, "数据异常！", null);
        }
    }


    /**
     * 根据工具ID删除所有
     *
     * @param toolId 所属工具ID
     * @return 返回处理结果
     */
    @Override
    public Result delParamByToolId(String toolId) {
        // 构造删除条件
        QueryWrapper<ToolParam> wrapper = new QueryWrapper<>();
        wrapper.eq("TOOL_ID", toolId);
        if (this.remove(wrapper)) {
            return new Result(true, "删除成功！", null);
        } else {
            return new Result(false, "删除失败！", null);
        }
    }

    /**
     * 单个修改工具参数
     *
     * @param data 旧工具信息
     * @return 返回除了结果
     */
    @Override
    public Result editParam(ParamList data) {
        QueryWrapper<ToolParam> queryWrapper = new QueryWrapper<>();
        for (ToolParam param : data.getList()) {
            queryWrapper.clear();
            queryWrapper.eq("TOOL_ID", param.getToolId());
            queryWrapper.eq("name", param.getName());
            baseMapper.update(param, queryWrapper);
        }
        return new Result(true, "修改成功！", null);
    }

    /**
     * 生产配置的json串
     *
     * @param toolId 工具ID
     * @return 返回值
     */
    @Override
    public Result generateJson(String toolId) {
        QueryWrapper<ToolParam> wrapper = new QueryWrapper<>();
        wrapper.eq("TOOL_ID", toolId);
        List<ToolParam> list = this.list(wrapper);
        if (list.size() > 0) {
            Map<String, String> map = new HashMap<>();
            for (ToolParam tool : list) {
                map.put(tool.getName(), tool.getRemark());
            }
            return new Result(true, "查询成功！", map);
        } else {
            return new Result(false, "没有记录！", null);
        }
    }

    /**
     * 根据传过来的实体删除多个
     *
     * @param list 实体列表
     * @return
     */
    @Override
    public Result delMore(List<ToolParam> list) {
        QueryWrapper<ToolParam> wrapper = new QueryWrapper<>();
        for (ToolParam param : list) {
            wrapper.clear();
            wrapper.eq("TOOL_ID", param.getToolId());
            wrapper.eq("NAME", param.getName());
            this.remove(wrapper);
        }
        return new Result(true, "删除成功！", null);
    }

    /**
     * 根据工具ID查寻所有配置
     *
     * @param toolId 工具ID
     * @return 返回数据
     */
    @Override
    public List<ToolParam> getAllByToolId(String toolId) {
        QueryWrapper<ToolParam> wrapper = new QueryWrapper<>();
        wrapper.eq("TOOL_ID", toolId);
        List<ToolParam> list = this.list(wrapper);
        return list;
    }
}
