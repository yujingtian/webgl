package com.hundsun.tool.reminders.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.hundsun.dcinfo.jumpToMail.controller.DingTalkController;
import com.hundsun.tool.reminders.service.TsSynService;
import com.hundsun.tool.utils.HttpClientUtil;
import com.hundsun.tool.utils.ResultEntity;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.text.ParseException;
import java.util.*;
import java.util.logging.Logger;

/**
 * @Author: kcaumber
 * @Date: 2021/12/20 11:11
 */
@CrossOrigin
@RestController
@RequestMapping("/tsSyn")
public class TsSynController {

    private static final Logger LOGGER = Logger.getLogger("com.hundsun.tool.reminders.controller.TsSynController");

    private final TsSynService tsSynService;
    private final DingController dingController;
    private final DingTalkController dingTalkController;

    public TsSynController(@Qualifier("tsSynService") TsSynService tsSynService, DingController dingController, @Qualifier("dingTalkController") DingTalkController dingTalkController) {
        this.tsSynService = tsSynService;
        this.dingController = dingController;
        this.dingTalkController = dingTalkController;
    }

    @PostMapping("/daily")
    public String daily() throws JsonProcessingException, InterruptedException, InvalidKeyException, NoSuchAlgorithmException, ParseException, UnsupportedEncodingException {

        LOGGER.info("获取用户信息");
        Map<String, String> userDict = tsSynService.getUserInfo();

        String modifier = tsSynService.getAllModifier();
        LOGGER.info("获取存量修改单信息");
        List<String> stockReworkList = tsSynService.qryStockRework(Arrays.asList(modifier.split(",")));
        LOGGER.info("获取手头待处理的修改单");

        Map<String, String> DCLReworkParam = new HashMap<String, String>(){{
            put("modifyStatus", "0,1,2,3,4,5,6,7,8,9,11,12");
            put("receiver", modifier);
        }};

        LOGGER.info("modifier:" + modifier);
        List<String> dclList = getReworkInfo(DCLReworkParam, userDict);
        LOGGER.info("等待15s");
        Thread.sleep(15000);
        LOGGER.info("获取已完成的修改单");

        Map<String, String> finalReworkParam = new HashMap<String, String>(){{
            put("modifyStatus","0,1,2,3,4,5,6,7,8,9,11,12");
            put("modifier", modifier);
            put("commitDate", "2021-08-19");
        }};

        List<String> finalList = getReworkInfo(finalReworkParam, userDict);
        LOGGER.info("判断本次遗失的修改单号");
        String modifyNum = "";
        ArrayList<String> lostList = new ArrayList<>();
        for (String reworkingID : stockReworkList) {
            if (dclList != null && finalList != null) {
                if (!dclList.contains(reworkingID) && !finalList.contains(reworkingID)) {
                    modifyNum = modifyNum + "," + reworkingID;
                    lostList.add(reworkingID);
                }
            } else if (dclList == null && finalList != null) {
                if (!finalList.contains(reworkingID)) {
                    modifyNum = modifyNum + "," + reworkingID;
                    lostList.add(reworkingID);
                }
            } else if (dclList != null) {
                if (!dclList.contains(reworkingID)) {
                    modifyNum = modifyNum + "," + reworkingID;
                    lostList.add(reworkingID);
                }
            } else {
                modifyNum = modifyNum + "," + reworkingID;
                lostList.add(reworkingID);
            }
        }
        if (modifyNum.startsWith(",")) modifyNum = modifyNum.substring(1);
        List<String> lostHaveList = new ArrayList<>();
        LOGGER.info("遗失修改单" + modifyNum);
        if (modifyNum.length() > 0) {
            LOGGER.info("等待15s");
            Thread.sleep(15000);
            LOGGER.info("开始查找遗失修改单");
            String finalModifyNum = modifyNum;
            Map<String, String> lostReworkParam = new HashMap<String, String>(){{
                put("modifyStatus", "");
                put("modifyNum", finalModifyNum);
            }};
            lostHaveList = getReworkInfo(lostReworkParam, userDict);
            LOGGER.info("开始查找TS上找不到的修改单");
            String lostModifyNum = "";
            for (String reworkingID : lostList) {
                if (lostHaveList != null && !lostHaveList.contains(reworkingID)) {
                    lostModifyNum = lostModifyNum + "," + reworkingID;
                }
            }
            if (lostModifyNum.startsWith(",")){
                lostModifyNum = lostModifyNum.substring(1);
                LOGGER.info("找不到的修改单:" + lostModifyNum);
            }
        }

//        dingController.AcctQA();

        return ResultEntity.successWithoutData().returnResult();
    }

    private List<String> getReworkInfo(Map<String, String> dclReworkParam, Map<String, String> userDict) {

        String url = "http://10.20.26.231:12222/ts/getTsListByModeifedNumsFromTs";
        String resultExt = HttpClientUtil.doPostJson(url, JSONObject.toJSONString(dclReworkParam));
        JSONObject resultMap = JSON.parseObject(resultExt);
        if (resultMap.getObject("code", Integer.class) != 20000){
            LOGGER.warning("获取最新修改单数据失败");
            return null;
        } else {
            LOGGER.info("200");
            JSONArray dataJson = resultMap.getJSONArray("data");
            List<String> result = tsSynService.InsertTmpReworkList(dataJson, userDict);
            return result;
        }
    }
}
