package com.hundsun.dcinfo.series.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.hundsun.dcinfo.series.entity.Series;
import com.hundsun.dcinfo.series.entity.SeriesMenu;
import com.hundsun.dcinfo.series.mapper.SeriesMapper;
import com.hundsun.dcinfo.series.service.ISeriesService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.hundsun.dcinfo.util.TreeUtil;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author Wanglei
 * @since 2021-07-15
 */
@Service
public class SeriesServiceImpl extends ServiceImpl<SeriesMapper, Series> implements ISeriesService {
    @Override
    public BigDecimal getInsertId() {
        return baseMapper.getNextIdByDual();
    }

    /**
     * 判断同一个父类下是否有相同的系列名
     *
     * @param series 要添加的系列的封装对象
     * @return 存在：true,也就是不能添加，不存在：false,允许添加
     */
    @Override
    public boolean isHasSameNameInOneParentSeries(Series series) {
        // 构造查询条件
        QueryWrapper<Series> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("PARENT_ID", series.getParentId());
        queryWrapper.eq("SER_NAME", series.getSerName());
        int count = this.count(queryWrapper);
        return count > 0;
    }

    /**
     * 传入一个系列对象，返回根系列到此系列的全路径
     *
     * @param serId 当前Id
     * @return 返回全路径
     */
    @Override
    public String getAllPath(BigDecimal serId) {
        Series cur = this.getById(serId);
        String res = cur.getSerName();
        BigDecimal pId = cur.getParentId();
        while (pId.intValue() != 0) {
            Series temp = this.getById(pId);
            pId = temp.getParentId();
            res = temp.getSerName() + "." + res;
        }
        return res;
    }

    @Override
    public boolean insertOne(Series series) {
        // 从系列获取ID并设置
        series.setSerId(baseMapper.getNextIdByDual());
        return this.save(series);
    }

    @Override
    public List<SeriesMenu> getSeriesTree() {
        // 获取系列列表
        List<Series> list = this.list();
        // 构造原始菜单
        List<SeriesMenu> rootMenu = new ArrayList<>();
        for (Series data : list) {
            SeriesMenu menu = new SeriesMenu(data);
            rootMenu.add(menu);
        }
        List<SeriesMenu> menus = TreeUtil.menuTreeData(rootMenu);
        return menus;
    }

    @Override
    public boolean deleteById(BigDecimal serId) {
        // 获取该ID的子ID
        List<BigDecimal> ids = new ArrayList<>();
        ids.add(serId);
        this.getIds(ids, serId);
        // 删除分类
        int i = baseMapper.deleteBatchIds(ids);
        return i > 0;
    }

    /**
     * 根据路径判断时刻可以在此节点下插入文件
     *
     * @param series 系列全字符
     * @return 返回结果
     */
    @Override
    public boolean isCanAddInfoInThisSeries(String series) {
        BigDecimal serId;
        String[] strArr = series.split("\\.");
        List<String> asList = Arrays.asList(strArr);
        if (!asList.get(0).equals("UF30") && !asList.get(0).equals("UF20")) {
            return false;
        }
        // 若是顶级系列，不能添加
        if (asList.size() == 1) {
            return false;
        }
        QueryWrapper<Series> wrapper = new QueryWrapper<>();
        wrapper.eq("SER_NAME", asList.get(0));
        Series one = this.getOne(wrapper);
        serId = one.getSerId(); // 获取第一个ID
        for (int i = 1; i < asList.size(); i++) {
            wrapper.clear();
            wrapper.eq("SER_NAME", asList.get(i));
            wrapper.eq("PARENT_ID", serId);
            one = this.getOne(wrapper);
            if (one == null) return false;
            serId = one.getSerId();
        }
        wrapper.clear();
        wrapper.eq("PARENT_ID", serId);
        List<Series> seriesList = this.list(wrapper);

        // 没有子系列可以添加，有子系列不能添加
        return seriesList.size() == 0;
    }

    /**
     * 根据系列返回最后一个的ID
     *
     * @param serPath 系列名
     * @return 返回默认的ID值，需要根据ID删除
     */
    @Override
    public BigDecimal getLatsIdByPath(String serPath) {

        BigDecimal serId;
        String[] strArr = serPath.split("\\.");
        List<String> asList = Arrays.asList(strArr);
        QueryWrapper<Series> wrapper = new QueryWrapper<>();
        wrapper.eq("SER_NAME", asList.get(0));
        Series one = this.getOne(wrapper);
        serId = one.getSerId(); // 获取第一个ID
        System.out.println("path" + serPath);
        for (int i = 1; i < asList.size(); i++) {
            wrapper.clear();
            wrapper.eq("SER_NAME", asList.get(i));
            wrapper.eq("PARENT_ID", serId);
            one = this.getOne(wrapper);
            serId = one.getSerId();
        }
        return serId;
    }

    /**
     * 返回能否添加此名字
     *
     * @param serName
     * @return
     */
    @Override
    public boolean isCanAddHere(String serName, BigDecimal pId) {
        int size = baseMapper.isCanAddThisName(serName, pId).size();
        return size == 0;
    }

    /**
     * 返回True表示删除
     * false便是不删除
     *
     * @return
     */
    @Override
    public boolean getUpdateIsDeleteDatFile() {
        return baseMapper.getUpdateIsDeleteDatFile().equals("0");
    }

    public void getIds(List<BigDecimal> ids, BigDecimal id) {
        //查询二级分类的对象
        QueryWrapper<Series> wrapper = new QueryWrapper<>();
        //folder_id==数据库父id
        wrapper.eq("PARENT_ID", id);
        List<Series> list = baseMapper.selectList(wrapper);
        //遍历二级分类的对象，把二级分类的id加入到要删除的集合中
        for (Series data : list) {
            BigDecimal id1 = data.getSerId();
            ids.add(id1);
            //把二级分类的每一个ID，查询它下面的子节点
            this.getIds(ids, id1);
        }
    }
}
