package com.hundsun.dcinfo.menu.mapper;

import com.hundsun.dcinfo.menu.entity.Dcmenu;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * <p>
 * Mapper 接口
 * </p>
 *
 * @author Wanglei
 * @since 2021-07-30
 */
@Mapper
public interface DcmenuMapper extends BaseMapper<Dcmenu> {
    @Select("SELECT * FROM (SELECT ROWNUM R , S.* from HS_ASSET.DCMENU S WHERE S.CANSEARCH ='1' AND S.MENU_CAPTION like #{keywords}) where R>=#{start} and R<= #{end}")
    public List<Dcmenu> getMenuList(String keywords, Integer start, Integer end);
}
