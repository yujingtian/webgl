package com.hundsun.tool.reminders.service.impl;

import com.hundsun.tool.reminders.entity.DingPersonInfo;
import com.hundsun.tool.reminders.service.DingPersonInfoService;
import com.hundsun.tool.reminders.service.DingService;
import com.hundsun.tool.utils.CheckDay;
import com.hundsun.tool.utils.DBWorkUtil;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @Author: kcaumber
 * @Date: 2021/11/11 18:46
 */
@Service("dingService")
public class DingServiceImpl implements DingService {

    private final DingPersonInfoService dingPersonInfoService;

    public DingServiceImpl(@Qualifier("dingPersonInfoService") DingPersonInfoService dingPersonInfoService) {
        this.dingPersonInfoService = dingPersonInfoService;
    }

    @Override
    public List<Map<String, String>> bigBagOutDate() {

        Date currentDate = new Date();
        SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
        String today = format.format(currentDate);

        String sSearchBigBagOutDateSql = "select distinct a.bagname,a.lastdjdate,a.outbagdate,a.endreminddate\n" +
                "                               from hs_asset.bagoutinfo a \n" +
                "                              where a.txdate <= " + today + " \n" +
                "                                and a.endreminddate >= " + today + " \n" +
                "                                and isbigbag = '1'";

        return DBWorkUtil.SelectDB(sSearchBigBagOutDateSql);
    }

    @Override
    public List<Map<String, String>> SearchReworking(String bagname) {

        String sSearchReworkingSql = "select distinct a.reworking_id,a.sys_receiver_sign,a.reworking_status_no\n" +
                "                           from hs_asset.tssynproinfo a \n" +
                "                        where a.rework_ver = '" + bagname + "' \n" +
                "                          and not exists (select 1 \n" +
                "                                            from hs_asset.laterreworking b\n" +
                "                                           where b.reworking_id = a.reworking_id\n" +
                "                                         )\n" +
                "                          and a.reworking_id not in (select reworking_id from hs_asset.dropTask)\n" +
                "                          and a.reworking_status_no in ('501','504','503') \n" +
                "                          and a.sys_receiver_sign in (select b.operator_no \n" +
                "                                                        from hs_asset.dingPersonInfo b \n" +
                "                                                      )";
        return DBWorkUtil.SelectDB(sSearchReworkingSql);
    }

    @Override
    public List<Map<String, String>> SearchSpilBagDate() {
        Date currentDate = new Date();
        SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
        String today = format.format(currentDate);

        String sSearchSpilBagDateSql = "select distinct a.bagname,a.reworking_id,a.lastdjdate,a.outbagdate,a.endreminddate,b.reworking_status_no,b.sys_receiver_sign  \n" +
                "                           from hs_asset.bagoutinfo a,hs_asset.tssynproinfo b \n" +
                "                          where a.reworking_id = b.reworking_id\n" +
                "                            and b.reworking_id not in (select reworking_id from hs_asset.dropTask)\n" +
                "                            and b.reworking_status_no in ('501','504','503')\n" +
                "                            and a.txdate <= " + today + " \n" +
                "                            and a.endreminddate >= " + today + " \n" +
                "                          order by a.bagname";
        return DBWorkUtil.SelectDB(sSearchSpilBagDateSql);
    }

    @Override
    public List<String> selectIDByTeamName(String teamName) {

        String sGetOperatorNoListByTeamName = "select distinct a.EMPLOYEECODE from TEAMMEMBERS a WHERE a.TEAMNAME = '" + teamName + "'";
        List<Map<String, String>> result = DBWorkUtil.SelectDB(sGetOperatorNoListByTeamName);
        if (result != null){
            List<String> resultList = new ArrayList<>();
            for (Map<String, String> map : result){
                resultList.add(map.get("EMPLOYEECODE".toLowerCase()));
            }
            return resultList;
        }
        return null;
    }

    @Override
    public Map<String, Object> assemblyDingMessage(String remindMsg, List<String> phoneList, String groupName) {

        Map<String, Object> messageMap = new HashMap<>();

        messageMap.put("msgtype", "text");
        messageMap.put("content", remindMsg);
        messageMap.put("receiveList", phoneList);
        messageMap.put("isAtAll", false);
        messageMap.put("groupName", groupName);
        return messageMap;
    }


    @Override
    public Map<String, Object> initMsg(String remindMsg, String bagname, String lastdjdate, String outbagdate, Map<String, List<String>> shMap, Map<String, List<String>> xzMap) throws ParseException {

        List<String> phoneList = new ArrayList<>();

        if (shMap.size() > 0 || xzMap.size() > 0) {
            if (remindMsg.length() > 0){
                remindMsg = remindMsg + "--------------------------------------------------------------------------------------\n";
            }
            remindMsg = remindMsg + "【" + bagname + "】\n截止开发递交日期:" + lastdjdate + "(倒计时:" + DateDiff(lastdjdate) + "天)\n" +
                    "发包日期:" + outbagdate + "(倒计时:" + DateDiff(outbagdate) + "天)\n";
        }

        if (xzMap.size() > 0) {
            remindMsg = remindMsg + "待递交修改单:\n";
            String tmpRemindMsg = "";
            for (Map.Entry<String, List<String>> entry : xzMap.entrySet()){
                String sRewordingStr = "";
                int iCount = 1;
                for (String sReworkingID : entry.getValue()){
                    if (iCount > 4){
                        iCount = 0;
                        sRewordingStr = sRewordingStr + ",\n" + sReworkingID;
                    } else {
                        sRewordingStr = sRewordingStr + "," + sReworkingID;
                    }
                    iCount++;
                }
                String sDingStr = "";
                List<DingPersonInfo> dingPersonInfoList = dingPersonInfoService.selectByOperatorNo(entry.getKey());
                if (dingPersonInfoList.size() > 0){
                    sDingStr = "@" + dingPersonInfoList.get(0).getDDID();
                    phoneList.add(dingPersonInfoList.get(0).getDDID());
                } else {
                    sDingStr = entry.getKey();
                }
                tmpRemindMsg = tmpRemindMsg + "\n     " + sRewordingStr.substring(1) + "(" + sDingStr + ")";
            }
            remindMsg = remindMsg + tmpRemindMsg.substring(1) + "\n";
        }

        if (shMap.size() > 0){
            remindMsg = remindMsg + "待审核修改单:\n";
            String tmpRemindMsg = "";
            for (Map.Entry<String, List<String>> entry : shMap.entrySet()){
                String sRewordingStr = "";
                int iCount = 1;
                for (String sReworkingID : entry.getValue()){
                    if (iCount > 4){
                        iCount = 0;
                        sRewordingStr = sRewordingStr + ",\n" + sReworkingID;
                    } else {
                        sRewordingStr = sRewordingStr + "," + sReworkingID;
                    }
                    iCount++;
                }
                String sDingStr = "";
                List<DingPersonInfo> dingPersonInfoList = dingPersonInfoService.selectByOperatorNo(entry.getKey());
                if (dingPersonInfoList.size() > 0){
                    sDingStr = "@" + dingPersonInfoList.get(0).getDDID();
                    phoneList.add(dingPersonInfoList.get(0).getDDID());
                } else {
                    sDingStr = entry.getKey();
                }
                tmpRemindMsg = tmpRemindMsg + "\n     " + sRewordingStr.substring(1) + "(" + sDingStr + ")";
            }
            remindMsg = remindMsg + tmpRemindMsg.substring(1) + "\n";
        }

        Map<String, Object> result = new HashMap<>();
        result.put("remindMsg", remindMsg);
        result.put("phoneList", phoneList);
        return result;
    }



    private String DateDiff(String sDate) throws ParseException {
        SimpleDateFormat sdf  =   new  SimpleDateFormat( "yyyy-MM-dd HH:mm:ss" );
        sDate = sDate.substring(0, 4) + "-" + sDate.substring(4, 6) + "-" + sDate.substring(6, 8) + " 00:00:00";
        Date dateExpect = sdf.parse(sDate);
        Date currentDate = new Date();
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String today = format.format(currentDate);
        Date date = sdf.parse(today);

        return CheckDay.compare(dateExpect, date);


    }
}
