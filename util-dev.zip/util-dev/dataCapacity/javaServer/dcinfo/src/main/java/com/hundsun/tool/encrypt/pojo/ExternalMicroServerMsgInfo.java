package com.hundsun.tool.encrypt.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

/**
 * 微服务外部调用T3加密时的入参
 *
 * @author Star_King
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ExternalMicroServerMsgInfo {
    /**
     * 发送方Id
     */
    private String userID;
    /**
     * 用来替换微服务名的字段
     */
    private String testServer;
    /**
     * 功能号
     */
    private String functionId;
    /**
     * 接收方IP
     */
    private String serverIP;
    /**
     * 接收方端口
     */
    private String serverPort;

    /**
     * 用于分片定位
     */
    private Map<Object, Object> shardingInfo;

    /**
     * 存放了票据信息、密码字段、IAR会话标识
     */
    private Map<Object, Object> security;

    /**
     * 传递的参数
     */
    private Map<Object, Object> param;
}
