package com.hundsun.signup.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hundsun.signup.pojo.SignUpUserInfo;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author wenping 2021-07-30 13:41
 */
@Mapper
@Repository
public interface SignUpUserInfoMapper extends BaseMapper<SignUpUserInfo> {
    @Select("select * from DCSIGNUPUSERINFO where USER_ID = #{userID}")
    SignUpUserInfo selectOneByUserID(@Param("userID") String userID);

    @Transactional(rollbackFor = Exception.class)
    @Update("update DCSIGNUPUSERINFO set STATE = 1 where USER_ID = #{userID}")
    int updateState(@Param("userID") String userID);

    @Transactional(rollbackFor = Exception.class)
    @Delete("delete from DCSIGNUPUSERINFO where USER_ID = #{userID}")
    int deleteByUserID(@Param("userID") String userID);
}
