package com.hundsun.dcinfo.dctool.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableField;

import java.io.Serializable;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 *
 * </p>
 *
 * @author jobob
 * @since 2021-07-12
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("DCTOOLINFO")
public class Tool implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableField("CREATE_OPERATOR_NO")
    private String createNo;

    @TableField("MOD_OPERATOR_NO")
    private String modNo;

    @TableField("TOOL_NAME")
    private String name;

    @TableField("SERVER_PATH")
    private String path;

    @TableField("PRODUCT_SERIES")
    private String series;

    @TableField("REMARK")
    private String remark;

    @TableField("KEYWORDS")
    private String keywords;

    @TableId("TOOL_ID")
    private String id;

    @TableField(exist = false)
    private String menuCaption;

    @TableField(exist = false)
    private String menuUrl;
}
