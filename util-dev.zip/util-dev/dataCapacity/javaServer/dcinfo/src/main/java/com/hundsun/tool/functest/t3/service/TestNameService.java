package com.hundsun.tool.functest.t3.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.hundsun.tool.functest.t3.exception.T3Exception;
import com.hundsun.tool.functest.t3.pojo.TestName;
import com.hundsun.tool.functest.t3.pojo.TestNameVO;
import org.apache.ibatis.annotations.Select;

import java.sql.SQLException;
import java.util.List;

/**
 * @author wenping 2021-07-28 13:54
 */
public interface TestNameService {
    /**
     * 根据测试用例名字查询
     * @param testName 测试用例名
     * @return
     */
    TestName selectByTestName(String testName);

   /* *
     * 插入一条[测试用例名，别名]到DCTESTNAME
     * @param testName 一条[测试用例名，别名]
     * @return
     * @throws SQLException 如果测试用例名已存在，则报异常
     */
    int insert(TestName testName);

    /**
     * 选择最大的ID
     * @return
     */
    Integer selectMaxID();

    TestNameVO showAll(String testName, String userID, int curPage, int pageSize, int flag) throws T3Exception;

    TestName delete(String testName, String userID) throws T3Exception;
}
