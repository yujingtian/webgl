package com.hundsun.signup.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.hundsun.common.mapper.TeamMemberMapper;
import com.hundsun.common.mapper.UserMapper;
import com.hundsun.common.utils.MD5Util;
import com.hundsun.signup.exception.SignUpException;
import com.hundsun.signup.mapper.SignUpUserInfoMapper;
import com.hundsun.signup.pojo.SignUpUserInfo;
import com.hundsun.signup.pojo.SignUpVO;
import com.hundsun.signup.service.SignUpUserInfoService;
import com.hundsun.common.pojo.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.util.LinkedList;
import java.util.List;

/**
 * 预注册处理类
 * @author wenping 2021-07-30 14:14
 */
@Service
public class SignUpUserInfoServiceImpl implements SignUpUserInfoService {

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private SignUpUserInfoMapper signMapper;

    /**
     * 预注册时，用户信息预处理
     * @param jsonStr
     * @return
     * @throws SignUpException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public JSONObject process(String jsonStr) throws SignUpException {
        JSONObject fromWeb = JSON.parseObject(jsonStr);
        SignUpUserInfo signUpUserInfo = fromWeb.getObject("signUpUserInfo", SignUpUserInfo.class);
        signUpUserInfo = trim(signUpUserInfo);
        // 判断在预注册表中是否存在该用户
        if (isExist(signUpUserInfo.getUserID())) {
            throw new SignUpException("重复注册！");
        }
        // 判断该用户工号是否是真实的
        if (userMapper.selectByOperatorNo(signUpUserInfo.getUserID()) != null) {
            throw new SignUpException(signUpUserInfo.getUserID() + "已注册，请登录！");
        }
        // 获得领导人的工号
        List<String> leaderIDList = userMapper.selectLeaderNoListByGroupName(signUpUserInfo.getGroupName());
        // 如果为空则说明没有直属领导
        if (CollectionUtils.isEmpty(leaderIDList)) {
            throw new SignUpException("没有该组或者该组没有直属领导，邮件发送失败！");
        }
        // 将领导人的工号List转换成str以便存入数据库保存
        StringBuilder strLeaderIDList = new StringBuilder();
        for (int i = 0; i < leaderIDList.size(); i++) {
            if (i != 0) {
                strLeaderIDList.append(",");
            }
            strLeaderIDList.append(leaderIDList.get(i));
        }
        // 设置当前状态为0，表示领导还未审核
        signUpUserInfo.setState(0);
        // MD5加密
        signUpUserInfo.setPwd(MD5Util.getMD5(signUpUserInfo.getPwd()));
        signUpUserInfo.setReceiverIDList(strLeaderIDList.toString());
        // 查找到领导的邮箱
        List<String> leaderEmailList = userMapper.selectEmailByOperatorNo(leaderIDList);
        if (CollectionUtils.isEmpty(leaderEmailList)) {
            throw new SignUpException("未查找到领导的邮箱！请联系管理员或者领导");
        }
        // 将领导者们的邮箱封装为字符串形式
        StringBuilder strLeaderEmailList = new StringBuilder();
        for (int i = 0; i < leaderEmailList.size(); i++) {
            if (i != 0) {
                strLeaderEmailList.append(",");
            }
            strLeaderEmailList.append(leaderEmailList.get(i));
        }

        // 查找到领导的电话号码
        List<String> leaderPhoneList = userMapper.selectPhoneNumberByOperatorNo(leaderIDList);
        if (CollectionUtils.isEmpty(leaderPhoneList)) {
            throw new SignUpException("未查找到领导的电话号码！请联系管理员或者领导");
        }
        // 将领导者们的电话号码封装为字符串形式
        StringBuilder strLeaderPhoneList = new StringBuilder();
        for (int i = 0; i < leaderPhoneList.size(); i++) {
            if (i != 0) {
                strLeaderPhoneList.append(",");
            }
            strLeaderPhoneList.append(leaderPhoneList.get(i));
        }
        // 插入到预注册用户信息表中
        try {
            signMapper.insert(signUpUserInfo);
        } catch (Exception e) {
            e.printStackTrace();
            throw new SignUpException("出错拉，管理员正在处理，请稍后再试！");
        }

        // 封装信息到json中
        JSONObject retJson = new JSONObject();
        JSONObject userInfoJson = new JSONObject();
        retJson.put("userInfo", userInfoJson);
        userInfoJson.put("userID", signUpUserInfo.getUserID());
        userInfoJson.put("userName", signUpUserInfo.getUserName());
        userInfoJson.put("groupName", signUpUserInfo.getGroupName());
        JSONObject mailMsgJson = fromWeb.getJSONObject("mailMessage");
        // 如果是用邮箱信息
        if (mailMsgJson != null) {
            mailMsgJson.put("receiverList", leaderEmailList);
//            mailMsgJson.put("receiverList", strLeaderEmailList);
            retJson.put("mailMessage", mailMsgJson);
        }
        // 如果有钉钉信息
        JSONObject dingTalkMsgJson = fromWeb.getJSONObject("dingTalkMessage");
        if (dingTalkMsgJson != null) {
            dingTalkMsgJson.put("receiverList", leaderPhoneList);
//            dingTalkMsgJson.put("receiverList", strLeaderPhoneList);
            retJson.put("dingTalkMessage", dingTalkMsgJson);
        }
        return retJson;
    }

    /**
     * 判断当前用户是否已经存在预注册表中
     * @param userID
     * @return
     */
    @Override
    public boolean isExist(String userID) {
        if (signMapper.selectOneByUserID(userID) == null) {
            return false;
        }
        return true;
    }


    /**
     * 去除用户填写信息时不小心误触的前后空格
     * @param signUpUserInfo
     * @return
     */
    public SignUpUserInfo trim(SignUpUserInfo signUpUserInfo) {
        signUpUserInfo.setUserName(signUpUserInfo.getUserName().trim());
        signUpUserInfo.setUserID(String.valueOf(Integer.parseInt(signUpUserInfo.getUserID().trim())));
        signUpUserInfo.setGroupName(signUpUserInfo.getGroupName().trim());
        signUpUserInfo.setEmail(signUpUserInfo.getEmail().trim());
        signUpUserInfo.setMobileTel(signUpUserInfo.getMobileTel().trim());
        return signUpUserInfo;
    }

    /**
     * 领导处理完邮件或者钉钉消息后的后续处理
     * @param userIDList
     * @return
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public int receiveHandle(List<Object> userIDList) throws SignUpException {
        for (Object obj : userIDList) {
            String userID  = (String)obj;
            SignUpUserInfo signUpUserInfo = signMapper.selectOneByUserID(userID);
            // 删除本地注册表用户
            try {
                signMapper.deleteByUserID(userID);
            } catch (Exception e) {
                e.printStackTrace();
                throw new SignUpException("出错拉，管理员正在解决，请稍后再试！");
            }
            // 更新状态
            updateState(signUpUserInfo.getUserID());
            User user = new User();
            user.setOperatorNo(signUpUserInfo.getUserID());
            user.setOperatorName(signUpUserInfo.getUserName());
            user.setOperatorPWD(signUpUserInfo.getPwd());
            user.setGroupName(signUpUserInfo.getGroupName());
            user.setEmail(signUpUserInfo.getEmail());
            user.setMobileTel(signUpUserInfo.getMobileTel());
            // 将用户信息插入到DCUSERS表中
            try {
                userMapper.insert(user);
            } catch (Exception e) {
                e.printStackTrace();
                throw new SignUpException("出错拉，管理员正在解决，请稍后再试！");
            }
        }
        return 1;
    }

    /**
     * 更新状态
     * @param userID
     * @return
     * @throws SignUpException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public int updateState(String userID) throws SignUpException{
        try {
            signMapper.updateState(userID);
        }catch (Exception e) {
            e.printStackTrace();
            throw new SignUpException("出错拉，管理员正在解决，请稍后再试！");
        }
        return 1;
    }

    @Override
    public JSONObject showUsers(String userID, int curPage, int pageSize) throws SignUpException {
        QueryWrapper<SignUpUserInfo> queryWrapper = new QueryWrapper<>();
        queryWrapper.likeLeft("RECEIVER_ID_LIST", "," + userID)
                .or().likeRight("RECEIVER_ID_LIST", userID + ",")
                .or().like("RECEIVER_ID_LIST", "," + userID + ",")
                .or().eq("RECEIVER_ID_LIST", userID);
        if (curPage <= 0) {
            curPage = 1;
        }
        if (pageSize > 10) {
            pageSize = 10;
        }
        int total = signMapper.selectCount(queryWrapper);
        if (total == 0) {
            return null;
        }
        Page<SignUpUserInfo> page = signMapper.selectPage(new Page<SignUpUserInfo>(curPage, pageSize, total), queryWrapper);
        List<SignUpUserInfo> userInfoList = page.getRecords();
        List<SignUpVO> retUser = new LinkedList<>();
        for (SignUpUserInfo userInfo : userInfoList) {
            SignUpVO t = new SignUpVO();
            t.setUserID(userInfo.getUserID());
            t.setUserName(userInfo.getUserName());
            t.setGroupName(userInfo.getGroupName());
            retUser.add(t);
        }
        JSONObject retJson = new JSONObject();
        retJson.put("curPage", curPage);
        retJson.put("pageSize", pageSize);
        retJson.put("total", total);
        retJson.put("userInfoList", retUser);
        return retJson;
    }

    @Override
    public int reject(List<Object> userIDList) throws SignUpException {
        for (Object obj : userIDList) {
            String userID = (String) obj;
            try {
                signMapper.deleteByUserID(userID);
            } catch (Exception e) {
                throw new SignUpException("拒绝失败！");
            }
        }
        return 0;
    }

    /**
     * 给钉钉消息增加前缀 "@" + phoneNumber + " "，以便能够@到个人
     * @param dingTalk
     * @return
     */
    /*public String getDingTalkContentPrefix(DingTalk dingTalk) {
        StringBuilder content = new StringBuilder();
        for (String phoneNumber : dingTalk.getAtUserIds()) {
            content.append("@")
                    .append(phoneNumber)
                    .append(" ");
        }
        return content.toString();
    }*/

}
