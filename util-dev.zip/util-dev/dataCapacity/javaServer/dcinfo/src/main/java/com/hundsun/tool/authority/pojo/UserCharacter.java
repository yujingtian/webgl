package com.hundsun.tool.authority.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Star_King
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserCharacter {
    private String userId;
    private String characterId;
}
