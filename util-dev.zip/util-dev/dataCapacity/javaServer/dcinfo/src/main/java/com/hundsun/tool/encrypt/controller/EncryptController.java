package com.hundsun.tool.encrypt.controller;

import com.hundsun.tool.encrypt.utils.MyEncryptUtil;
import com.hundsun.tool.utils.ResultEntity;
import org.springframework.web.bind.annotation.*;

/**
 * @author Star_King
 */
@CrossOrigin
@RestController
@RequestMapping("/Encrypt")
public class EncryptController {
    /**
     * 一户通账号密码用AES加密
     * @param clientId 一户通账号
     * @param clearPwd 明文
     * @return 密文
     */
    @PostMapping("/T3/AES/Client")
    public String t3ClientAes(@RequestParam(value = "clientId", defaultValue = "") String clientId,
                              @RequestParam(value = "clearPwd", defaultValue = "") String clearPwd) throws Exception {
        String ciphertext = MyEncryptUtil.t3ClientAes(clientId, clearPwd);
        return ResultEntity.successWithData(ciphertext).returnResult();
    }

    /**
     * 资产账户账号密码用AES加密
     * @param assetId 资产账户账号
     * @param clearPwd 明文
     * @return 密文
     */
    @PostMapping("/T3/AES/Asset")
    public String t3AssetAes(@RequestParam(value = "assetId", defaultValue = "") String assetId,
                             @RequestParam(value = "clearPwd", defaultValue = "") String clearPwd) throws Exception {
        String ciphertext = MyEncryptUtil.t3AssetAes(assetId, clearPwd);
        return ResultEntity.successWithData(ciphertext).returnResult();
    }

    /**
     * 操作员账号密码用AES加密
     * @param adminId 操作员账号
     * @param clearPwd 明文
     * @return 密文
     */
    @PostMapping("/T3/AES/Admin")
    public String t3AdminAes(@RequestParam(value = "adminId", defaultValue = "") String adminId,
                             @RequestParam(value = "clearPwd", defaultValue = "") String clearPwd) throws Exception {
        String ciphertext = MyEncryptUtil.t3AdminAes(adminId, clearPwd);
        return ResultEntity.successWithData(ciphertext).returnResult();
    }

    /**
     * 一户通账号密码用国密加密
     * @param clientId 一户通账号
     * @param clearPwd 明文
     * @return 密文
     */
    @PostMapping("/T3/National/Client")
    public String t3ClientNational(@RequestParam(value = "clientId", defaultValue = "") String clientId,
                                   @RequestParam(value = "clearPwd", defaultValue = "") String clearPwd) throws Exception {
        String ciphertext = MyEncryptUtil.t3ClientNational(clientId, clearPwd);
        return ResultEntity.successWithData(ciphertext).returnResult();
    }

    /**
     * 资产账户账号密码用GM加密
     * @param assetId 资产账户账号
     * @param clearPwd 明文
     * @return 密文
     */
    @PostMapping("/T3/National/Asset")
    public String t3AssetNational(@RequestParam(value = "assetId", defaultValue = "") String assetId,
                                  @RequestParam(value = "clearPwd", defaultValue = "") String clearPwd) throws Exception {
        String ciphertext = MyEncryptUtil.t3AssetNational(assetId, clearPwd);
        return ResultEntity.successWithData(ciphertext).returnResult();
    }

    /**
     * 操作员账号密码用AES加密
     * @param adminId 操作员账号
     * @param clearPwd 明文
     * @return 密文
     */
    @PostMapping("/T3/National/Admin")
    public String t3AdminNational(@RequestParam(value = "adminId", defaultValue = "") String adminId,
                                  @RequestParam(value = "clearPwd", defaultValue = "") String clearPwd) throws Exception {
        String ciphertext = MyEncryptUtil.t3AdminNational(adminId, clearPwd);
        return ResultEntity.successWithData(ciphertext).returnResult();
    }
}
