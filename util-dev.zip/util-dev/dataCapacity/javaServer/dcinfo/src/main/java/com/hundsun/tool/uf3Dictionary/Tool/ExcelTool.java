package com.hundsun.tool.uf3Dictionary.Tool;

import com.hundsun.tool.uf3Dictionary.entity.UF2_Dictionary;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * @Author tdragon.
 * @Date 2021/8/23.
 * @Time 20:29
 * @Description:
 */

@Slf4j
public class ExcelTool {
    /** 设置excel表头样式 uf2.0 3.0 */
    public static void setTableHead(Sheet sheet, CellStyle style){
        style.setAlignment(HorizontalAlignment.CENTER);
        Row r1 = sheet.createRow(0);
        sheet.addMergedRegion(new CellRangeAddress(
                0, //first row (0-based)
                0, //last row  (0-based)
                1, //first column (0-based)
                2  //last column  (0-based)
        ));
        Cell c2 = r1.createCell(1);
        c2.setCellValue("UF2.0");
        style.setAlignment(HorizontalAlignment.CENTER);
        c2.setCellStyle(style);
        sheet.addMergedRegion(new CellRangeAddress(
                0, //first row (0-based)
                0, //last row  (0-based)
                13, //first column (0-based)
                14  //last column  (0-based)
        ));
        Cell c3 = r1.createCell(13);
        c3.setCellValue("UF3.0");
        c3.setCellStyle(style);


        Row r2 = sheet.createRow(1);
        r2.createCell(0).setCellValue("字典编号");
        r2.createCell(1).setCellValue("字典名");
        r2.createCell(3).setCellValue("子项编号");
        r2.createCell(4).setCellValue("子项名");

        r2.createCell(12).setCellValue("字典编号");
        r2.createCell(13).setCellValue("字典名");
        r2.createCell(15).setCellValue("子项编号");
        r2.createCell(16).setCellValue("子项名");
        r2.createCell(17).setCellValue("微服务名");

    }

    public static  List<UF2_Dictionary> parseXml() throws DocumentException {
        SAXReader saxReader = new SAXReader();
        List<UF2_Dictionary> list = new ArrayList<>();
        Document document = saxReader.read(new File("dict.xml"));
        Element rootElement = document.getRootElement();
        System.out.println("rootElement = " + rootElement.getName());
        Iterator iterator = rootElement.elementIterator();
        while (iterator.hasNext()){
            Element next = (Element) iterator.next();
            String itemDesc = next.attributeValue("itemDesc");
            String dicItem=next.attributeValue("dicItem");
            String childItem = next.attributeValue("childItem");
            String desc = next.attributeValue("desc");
            UF2_Dictionary dictionary = new UF2_Dictionary();
            dictionary.setDicItem(dicItem==null?"":dicItem);
            dictionary.setItemDesc(itemDesc==null?"":itemDesc);
            dictionary.setChildItem(childItem==null?"":childItem);
            dictionary.setDesc(desc==null?"":desc);
            list.add(dictionary);
            if(dicItem!=null){
                list.sort(dictionary);
            }else{ break;}
        }
        return  list;
    }

    /** 填充数据 */
    public static void fillData(String excelName) throws IOException {
        LocalDateTime start = LocalDateTime.now();
        System.out.println("start="+start);
        XSSFWorkbook workbook = new XSSFWorkbook();
        CellStyle style = workbook.createCellStyle();
        File file=new File(excelName+".xls");
        OutputStream outputStream=new FileOutputStream(excelName+".xls");
        Sheet s1=workbook.createSheet("数据字典名找不到对应的");
        Sheet s2=workbook.createSheet("数据字典名相同，字典子项不一样");
        ExcelTool.setTableHead(s1,style);
        ExcelTool.setTableHead(s2,style);
        workbook.write(outputStream);
        workbook.close();
        LocalDateTime end = LocalDateTime.now();
        log.debug("end = " + end);
        Duration duration=Duration.between(end, start);
        log.info("耗时：{}",duration.getSeconds());
        log.info("大小约："+file.length()/1024/1024+"MB");
    }

}
