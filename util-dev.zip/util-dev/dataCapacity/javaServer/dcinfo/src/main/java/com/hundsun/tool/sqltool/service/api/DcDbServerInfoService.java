package com.hundsun.tool.sqltool.service.api;

import com.hundsun.tool.sqltool.pojo.DcDbServerInfo;

/**
 * @author Star_King
 */
public interface DcDbServerInfoService {
    /**
     * 根据微服务别名和数据库用户名查询数据库信息
     * @param serverAlias 微服务别名
     * @param username 数据库用户名
     * @return DcDbServerInfo对象列表
     */
    DcDbServerInfo searchDcDbServerInfoByAliasAndUsername(String serverAlias, String username);
}
