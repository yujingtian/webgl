package com.hundsun.dcinfo.dctool.controller;

import com.hundsun.common.mapper.UserMapper;
import com.hundsun.dcinfo.dctool.entity.ToolParamPojo;
import com.hundsun.dcinfo.dctool.entity.ToolVo;
import com.hundsun.dcinfo.dctool.entity.Tool;
import com.hundsun.dcinfo.dctool.entity.SearchCondition;
import com.hundsun.dcinfo.dctool.service.ToolService;
import com.hundsun.dcinfo.param.entity.ToolParam;
import com.hundsun.dcinfo.param.service.ToolParamService;
import com.hundsun.dcinfo.series.service.ISeriesService;
import com.hundsun.dcinfo.util.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.io.File;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author jobob
 * @since 2021-07-12
 */
@RestController
@RequestMapping("/tool")
@CrossOrigin
@Transactional(rollbackFor = Exception.class)
public class ToolController {

    @Value("${curPage}")
    private Integer curPage;

    @Value("${pageSize}")
    private Integer myPageSize;

    // 文件上传目录
    @Value("${fileDirPath}")
    private String fileDirPath;
    /**
     * 注入service
     */
    @Autowired
    private ToolService service;

    @Autowired
    private ISeriesService seriesService;

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private ToolParamService toolParamService;

    /**
     * @param pojo 封装的tool和param信息
     * @return 返回处理信息
     */
    @Transactional(rollbackFor = Exception.class)
    @PostMapping("/add")
    public Result saveInfo(@RequestBody ToolParamPojo pojo) {
        Tool tool = pojo.getTool();
        String userID = StrToStrUtil.strToStrWithoutHeadZero(pojo.getUserID());
        List<ToolParam> paramList = pojo.getParamList();
        // 写入到文件并返回文件名
        tool.setRemark(FileUtil.writeToFile(tool.getRemark(), fileDirPath));
        // 参数校验
        if (!StringUtils.hasText(userID) || dcIsNull(tool, false) || userID.trim().length() > 5) {
            return new Result(false, "参数错误！", null);
        }
        if (!isAllowedUser(userID)) {
            return new Result(false, "该用户不存在！", null);
        }
        // 判断能否在此系列添加,判断规则,有子系列不许添加
        if (!seriesService.isCanAddInfoInThisSeries(tool.getSeries())) {
            return new Result(false, "不能在此处添加！", null);
        }
        if (service.insertOne(tool, userID, paramList)) {
            return new Result(true, "保存成功！", null);
        } else {
            return new Result(false, "保存失败！", null);
        }
    }

    /**
     * 修改工具信息
     *
     * @param tool 封装的dctoolinfo信息
     * @return 返回处理信息
     */
    @Transactional(rollbackFor = Exception.class)
    @PostMapping("/update")
    public Result updateInfo(Tool tool, String userID) {
        // 参数校验
        if (!StringUtils.hasText(userID) || dcIsNull(tool, true) || userID.trim().length() > 5) {
            return new Result(false, "参数错误！", null);
        }
        // 去除UserID前面的0
        userID = StrToStrUtil.strToStrWithoutHeadZero(userID);
        // 判断是否存在该用户
        if (!isAllowedUser(userID)) {
            return new Result(false, "该用户不存在！", null);
        }
        // 判断工具是否存在，不存在返回错误信息
        Tool oldTool = service.getById(tool.getId());
        if (null == oldTool) {
            return new Result(false, "工具不存在或者已经被删除！", null);
        }
        if (!userID.equals(oldTool.getCreateNo()) && !userID.equals(oldTool.getModNo())) {
            return new Result(false, "无权修改！", null);
        }
        tool.setRemark(FileUtil.writeToFile(tool.getRemark(), fileDirPath));
        // 强制将创建者No设置为旧No
        tool.setModNo(userID);
        tool.setCreateNo(oldTool.getCreateNo());
        // 判断能否在此系列添加,判断规则,有子系列不许添加
        if (!seriesService.isCanAddInfoInThisSeries(tool.getSeries())) {
            return new Result(false, "不能在此处添加！", null);
        }
        String oldSeries = oldTool.getSeries();
        BigDecimal serId = BigDecimal.ZERO;
        // 若该工具处于默认系列下，且将其转移走了，同时该默认系列下没有别的工具信息，则删除该默认分类
        if (oldSeries.substring(oldSeries.lastIndexOf(".") + 1).equals("默认")) {
            // 判断默认下是否有其他系列
            if (!service.isHasThisSeriesButThis(oldSeries, oldTool.getId())) {
                //没有其他工具，需要删除默认这个系列
                serId = seriesService.getLatsIdByPath(oldSeries);
            }
        }
        // 判断该文件是否在默认系列下
        if (service.editById(tool)) {
            // 更新成功判断是否修改了文件
            if (!tool.getPath().trim().equals(oldTool.getPath().trim())) {
                // 获取旧文件后缀名
                String oldPath = oldTool.getPath().trim();
                String oldExt = oldPath.substring(oldPath.lastIndexOf('.'));
                // 如果后缀为dat判断是否允许删除dat文件
                if (!oldExt.equals("dat") || seriesService.getUpdateIsDeleteDatFile()) {
                    //删除旧文件
                    FileUtil.deleteFileByURL(fileDirPath + oldTool.getPath());
                }
            }
            // 判断serID是否为0，不为0，需要删除
            if (serId != BigDecimal.ZERO) {
                seriesService.deleteById(serId);
            }
            FileUtil.deleteFileByURL(fileDirPath + oldTool.getRemark());// 删除旧的说明文件
            return new Result(true, "修改成功！", null);
        } else {
            return new Result(false, "修改失败！", null);
        }
    }

    /**
     * 删除工具接口
     *
     * @param toolID 工具ID
     * @return 返回操作信息
     */
    @Transactional(rollbackFor = Exception.class)
    @PostMapping("/delete")
    public Result deleteDCTool(String toolID, String userID) {
        // 参数校验，id不能为空，工具ID不能为空
        if (!StringUtils.hasText(userID) || userID.trim().length() > 5 || !StringUtils.hasText(toolID)) {
            return new Result(false, "参数错误！", null);
        }
        // 去除UserID前面的0
        userID = StrToStrUtil.strToStrWithoutHeadZero(userID);
        if (!isAllowedUser(userID)) {
            return new Result(false, "该用户不存在！", null);
        }
        Tool tool = service.getById(toolID.trim());
        if (tool == null) {
            return new Result(false, "该工具不存在或者已经被删除！", null);
        }
        // 不能删除别人创建的工具
        if (!tool.getCreateNo().equals(userID)) {
            return new Result(false, "无权删除！", null);
        }
        String oldSeries = tool.getSeries();
        BigDecimal serId = BigDecimal.ZERO;
        // 若删除的工具处于默认系列下，同时该默认系列下没有别的工具信息，则删除该默认分类
        if (oldSeries.substring(oldSeries.lastIndexOf(".") + 1).equals("默认")) {
            // 判断默认下是否有其他系列
            if (!service.isHasThisSeriesButThis(oldSeries, tool.getId())) {
                //没有其他工具，需要删除默认这个系列
                serId = seriesService.getLatsIdByPath(oldSeries);
            }
        }
        File file = new File(fileDirPath + tool.getPath());
        if (file.exists()){
            if (!file.delete()){
                return new Result(false, "删除工具文件失败", null);
            }
        }
        if (service.delById(toolID)) {
            // 判断serID是否为0，不为0，需要删除
            if (serId != BigDecimal.ZERO) {
                seriesService.deleteById(serId);
            }
            FileUtil.deleteFileByURL(fileDirPath + tool.getPath());// 删除旧文件
            FileUtil.deleteFileByURL(fileDirPath + tool.getRemark());// 删除说明
            return new Result(true, "删除成功！", null);
        } else {
            return new Result(false, "删除失败", null);
        }
    }

    /**
     * 根据ID查询工具信息
     *
     * @param toolID 工具ID
     * @return 返回工具信息
     */
    @RequestMapping(value = "/getToolById")
    public Result getToolByID(String toolID) {
        if (!StringUtils.hasText(toolID)) {
            return new Result(false, "参数错误！", null);
        }
        Tool tool = service.getById(toolID.trim());
        if (tool != null) {
            Map<String, Object> map = new HashMap<>();
            tool.setRemark(FileUtil.getString(tool.getRemark(), fileDirPath));
            map.put("tool", tool);
            List<ToolParam> paramList = toolParamService.getAllByToolId(toolID);
            map.put("paramList", paramList);
            return new Result(true, "查询成功！", map);
        } else {
            return new Result(false, "该工具不存在或者已经被删除！", null);
        }
    }

    /**
     * @param condition 查询条件封装
     * @return 放回结果
     */
    /**
     * {
     * "pageSize": 5, // 每页显示条数，默认50条，使用默认值需要传入0
     * "currentPage": 0, // 页码数，默认第一页，使用默认需要传入0
     * "toolName": "", // 工具名，不按此项搜索传入空字符
     * "remark": "", // 工具说明，不按此项搜索传入空字符
     * "keywords": "" // 关键词，可传入多个，之间使用英文逗号间隔开，不按此项搜索传入空字符
     * "userID"：用户ID,用来匹配创建者和最后修改者
     * }
     */
    @RequestMapping(value = "/search")
    public Result getDCToolBySearch(SearchCondition condition) {
        // 校验参数
        if (!StringUtils.hasText(condition.getUserID())) {
            return new Result(false, "参数错误！", null);
        }
        // 去除UserID前面的0
        condition.setUserID(StrToStrUtil.strToStrWithoutHeadZero(condition.getUserID()));
        if (condition.getCurrentPage() == null || condition.getCurrentPage() <= 0) {
            condition.setCurrentPage(curPage);
        }
        if (condition.getPageSize() == null || condition.getPageSize() <= 0) {
            condition.setPageSize(myPageSize);
        }
        ToolVo vo = service.selectByPage(condition);
        if (vo.getList() == null) {
            return new Result(true, "没有符合条件的记录！", vo);
        } else {
            return new Result(true, "查询成功！", vo);
        }
    }

    /**
     * 判断传入的参数是否有空参
     *
     * @param tool      对象参数
     * @param containID 是否必须传入ID
     * @return true:验证通过，false验证不通过
     */
    public boolean dcIsNull(Tool tool, boolean containID) {
        // 参数不许为null,有一个null，就不能添加
        // 参数不许为空字符，有一个空字符不许添加
        if (!StringUtils.hasText(tool.getName()) || !StringUtils.hasText(tool.getRemark()) ||
                !StringUtils.hasText(tool.getKeywords()) || !StringUtils.hasText(tool.getSeries()) ||
                !StringUtils.hasText(tool.getPath())
        ) return true;

        if (!containID) {
            return false;
        } else {
            return (tool.getId() == null || tool.getId().trim().equals(""));
        }
    }

    public boolean isAllowedUser(String userID) {
        return userMapper.selectByOperatorNo(userID) != null;
    }
}
