package com.hundsun.dcinfo.friendlylink.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Star_King
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class FriendlyLink {
    private String friendName;
    private String friendHref;
    private String userID;
    private String iconHref;
    private String hrefAlias;
    private Integer friendOrder;
    private Integer friendFlag;
}
