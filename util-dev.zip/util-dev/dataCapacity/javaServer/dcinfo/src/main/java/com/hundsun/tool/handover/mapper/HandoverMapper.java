package com.hundsun.tool.handover.mapper;

import com.hundsun.tool.handover.pojo.Handover;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author Star_King
 */
@Mapper
@Repository("handoverMapper")
public interface HandoverMapper {
    /**
     * 查询Handover表记录
     * @param tableName 表名
     * @param tableAlias 表别名
     * @return Handover对象列表
     */
    List<Handover> selectHandover(@Param("tableName") String tableName,
                                  @Param("tableAlias") String tableAlias);

    /**
     * 查询全部带有USER_ID字段的Handover记录
     * @return Handover对象列表
     */
    List<Handover> selectHasUser();

    /**
     * 添加一行Handover记录
     * @param handover Handover对象
     * @return 影响的记录数
     */
    int insertHandover(Handover handover);

    /**
     * 根据表名删除一条Handover记录
     * @param tableName 表名
     * @return 影响的记录数
     */
    int deleteHandoverByName(@Param("tableName") String tableName);

    /**
     * 根据别名删除一行Handover记录
     * @param tableAlias 别名
     * @return 影响的记录数
     */
    int deleteHandoverByAlias(@Param("tableAlias") String tableAlias);

    /**
     * 更新一条Handover记录
     * @param handover Handover对象
     * @return 影响的记录数
     */
    int updateHandover(Handover handover);

    /**
     * 查询数据库中以tableName为表名的表
     * @return 表名列表
     */
    List<String> selectTableName();

    /**
     * 查询表中的全部列名
     * @param tableName 表名
     * @return 列名列表
     */
    List<String> selectColumn(@Param("tableName") String tableName);

    /**
     * 修改tableName表的USER_ID字段
     * @param oldUserID 旧值
     * @param newUserID 新值
     * @param tableName 表名
     * @param columnName 列名
     * @return 影响的记录数
     */
    int updateTable(@Param("oldUserID") String oldUserID,
                    @Param("newUserID") String newUserID,
                    @Param("tableName") String tableName,
                    @Param("columnName") String columnName);
}
