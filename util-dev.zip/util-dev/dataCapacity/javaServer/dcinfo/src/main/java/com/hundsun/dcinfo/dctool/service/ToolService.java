package com.hundsun.dcinfo.dctool.service;

import com.hundsun.dcinfo.dctool.entity.ToolVo;
import com.hundsun.dcinfo.dctool.entity.Tool;
import com.baomidou.mybatisplus.extension.service.IService;
import com.hundsun.dcinfo.dctool.entity.SearchCondition;
import com.hundsun.dcinfo.param.entity.ToolParam;

import java.util.List;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author jobob
 * @since 2021-07-12
 */
public interface ToolService extends IService<Tool> {
    public ToolVo selectByPage(SearchCondition condition);

    public boolean isHasThisSeries(String path);

    public void batchUpdateSeries(String oldPath, String newPath);

    public boolean isHasThisSeriesOrChildSeries(String path);

    public void batchUpdateSeriesNotAll(String oldPath, String newPath);

    public boolean insertOne(Tool tool, String userID, List<ToolParam> param);

    public boolean editById(Tool tool);

    public boolean isHasThisSeriesButThis(String oldSeries, String toolId);

    public boolean delById(String toolID);
}
