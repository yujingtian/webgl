package com.hundsun.tool.reminders.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.hundsun.tool.reminders.service.TsTaskService;
import com.hundsun.tool.utils.CheckDay;
import com.hundsun.tool.utils.DBWorkUtil;
import org.springframework.stereotype.Service;

import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.logging.Logger;

/**
 * @Author: kcaumber
 * @Date: 2021/11/8 13:56
 */
@Service("tsTaskService")
public class TsTaskServiceImpl implements TsTaskService {

    private static final Logger LOGGER = Logger.getLogger("com.hundsun.tool.reminders.service.impl.TsTaskServiceImpl");
    @Override
    public boolean InsertTmpTSTaskList(JSONArray dataJson) throws SQLException {

        ArrayList<Map<String, Object>> params = new ArrayList<>();

//        数据库数据更新
        for (Object object : dataJson) {
            JSONObject jsonObject = JSON.parseObject(JSON.toJSONString(object));
            Map<String, Object> param = new LinkedHashMap<>();
            param.put("taskID", jsonObject.getString("taskNum")); // 任务编号
            param.put("modifyVerNames", jsonObject.getString("modifyVerNames")); // 修改版本
            param.put("productID", jsonObject.getString("projectId").length() == 0 ? " " : jsonObject.getString("projectId")); // 产品ID
            param.put("demandID", jsonObject.getString("reqNums").length() == 0 ? " " : jsonObject.getString("reqNums")); // 需求编号
            param.put("assignDate", GetStrandingDate(jsonObject.getString("assignDate")));
            param.put("completedStatus", jsonObject.getString("completedStatus").length() == 0 ? " " : jsonObject.getString("completedStatus"));
            param.put("desinger", jsonObject.getString("desinger").length() == 0 ? " " : jsonObject.getString("desinger"));
            param.put("expectedReleaseDate", GetStrandingDate(jsonObject.getString("expectedReleaseDate")));
            param.put("firstAssignDate", GetStrandingDate(jsonObject.getString("firstAssignDate")));
            param.put("isUserTest", jsonObject.getString("isUserTest").length() == 0 ? " " : jsonObject.getString("isUserTest"));
            param.put("modifyDate", GetStrandingDate(jsonObject.getString("modifyDate")));
            param.put("moduleNames", jsonObject.getString("moduleNames").length() == 0 ? " " : jsonObject.getString("moduleNames"));
            param.put("productVersionType", jsonObject.getString("productVersionType").length() == 0 ? " " : jsonObject.getString("productVersionType"));
            param.put("programer", jsonObject.getString("programer").length() == 0 ? " " : jsonObject.getString("programer"));
            param.put("promiseDate", GetStrandingDate(jsonObject.getString("promiseDate")));
            param.put("realDevDate", GetStrandingDate(jsonObject.getString("realDevDate")));
            param.put("resultReviewer", jsonObject.getString("resultReviewer").length() == 0 ? " " : jsonObject.getString("resultReviewer"));
            param.put("sugesstion", FormatSugesstion(jsonObject.getString("sugesstion")));
            param.put("taskAssigner", jsonObject.getString("taskAssigner").length() == 0 ? " " : jsonObject.getString("taskAssigner"));
            param.put("taskDifficulty", jsonObject.getString("taskDifficulty").length() == 0 ? " " : jsonObject.getString("taskDifficulty"));
            param.put("taskOwner", jsonObject.getString("taskOwner").length() == 0 ? " " : jsonObject.getString("taskOwner"));
            param.put("taskReqDesc", FormatReqDesc(jsonObject.getString("taskReqDesc")));
            param.put("taskStatus", jsonObject.getString("taskStatus").length() == 0 ? " " : jsonObject.getString("taskStatus"));
            param.put("taskType", jsonObject.getString("taskType").length() == 0 ? " " : jsonObject.getString("taskType"));
            param.put("workAccount", jsonObject.getString("workAccount").length() == 0 ? " " : jsonObject.getString("workAccount"));

            params.add(param);
        }
        if (params.size() > 0){
            String sqlStr = "insert into HS_ASSET.TMP_TSTASKLIST (TASK_ID, MODIFY_VER_NAMES, PRODUCT_ID, DEMAND_ID, ASSIGN_DATE, COMPLETED_STATUS, DESIGNER, EXPECTED_PELEASE_DATE, FIRST_ASSIGN_DATE, IS_USER_TEST, MODIFY_DATE, MODULE_NAMES, PRODUCT_VERSION_TYPE, PROGRAMER, PROMISE_DATE, REAL_DEV_DATE, RESULT_REVIEWER, SUGESSTION, TASK_ASSIGNER, TASK_DIFFICULTY, TASK_OWNER, TASK_REQ_DESC, TASK_STATUS, TASK_TYPE, WORK_ACCOUNT) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            return DBWorkUtil.ExecParamDB(sqlStr, params);
        }

        return false;

    }



    @Override
    public Map<String, Object> assemblyMessage() throws ParseException {

//        发送钉钉通知
        String sqlAcctStr = "select a.product_id,a.MODIFY_VER_NAMES,a.EXPECTED_PELEASE_DATE,count(0) as icount\n" +
                "from hs_asset.TSTaskList a\n" +
                "where a.product_id = '20151206'\n" +
                "group by a.product_id,a.MODIFY_VER_NAMES,a.EXPECTED_PELEASE_DATE order by a.PRODUCT_ID desc, a.MODIFY_VER_NAMES";
        String sqlBopStr = "select a.product_id,a.MODIFY_VER_NAMES, a.EXPECTED_PELEASE_DATE,count(0) as icount\n" +
                "from hs_asset.TSTaskList a\n" +
                "where a.product_id = '20160702' and a.MODIFY_VER_NAMES not like '%BOP1.0-EAS%'\n" +
                "group by a.product_id,a.MODIFY_VER_NAMES ,a.EXPECTED_PELEASE_DATE order by a.MODIFY_VER_NAMES";
        String sqlEligStr = "select a.product_id,a.MODIFY_VER_NAMES, a.EXPECTED_PELEASE_DATE,count(0) as icount\n" +
                "from hs_asset.TSTaskList a\n" +
                "where a.product_id = '20170403'\n" +
                "group by a.product_id,a.MODIFY_VER_NAMES ,a.EXPECTED_PELEASE_DATE order by a.MODIFY_VER_NAMES";

        ArrayList<Map<String, String>> AcctList = DBWorkUtil.SelectDB(sqlAcctStr);
        ArrayList<Map<String, String>> BopList = DBWorkUtil.SelectDB(sqlBopStr);
        ArrayList<Map<String, String>> EligList = DBWorkUtil.SelectDB(sqlEligStr);

        Integer iBopSumCount = 0;
        Integer iActSumCount = 0;
        String BopPeple = "15910706832";
        String EligPeplo = "17328856623";
        String allPeplo = "18668168601";
        Integer itxCount = 230;
        String lastBopReworkVer = "";
        String lastEligReworkVer = "";
        String remindStr = "";
        List<String> phoneList = new ArrayList<>();

        if (BopList != null && EligList != null){

            for (Map<String, String> bop : BopList){

                if (DateCompare(bop.get("EXPECTED_PELEASE_DATE".toLowerCase()), 14)) {

                    for (Map<String, String> elig : EligList){
                        if (elig.get("modify_ver_names").substring(elig.get("modify_ver_names").lastIndexOf("V")).equals(bop.get("modify_ver_names").substring(bop.get("modify_ver_names").lastIndexOf("V")))){
                            remindStr = remindStr + "Elig已有任务" + elig.get("icount") + "\n";
                            remindStr = remindStr + "BOP已有任务" + bop.get("icount") + "\n";
                            remindStr = "版本:" + bop.get("modify_ver_names").substring(bop.get("modify_ver_names").lastIndexOf("V")) + "\n------------------------------------------------\n" + remindStr;
                            iBopSumCount = Integer.parseInt(elig.get("icount")) + Integer.parseInt(bop.get("icount"));
                            break;
                        }
                    }
                }
                if (iBopSumCount != 0){
                    break;
                }
            }
            phoneList.add(BopPeple);
            phoneList.add(EligPeplo);
        } else if(BopList != null) {
            for (Map<String, String> bop : BopList){
                if (DateCompare(bop.get("EXPECTED_PELEASE_DATE".toLowerCase()), 14)) {
                    lastBopReworkVer = BopList.get(0).get("modify_ver_names").substring(BopList.get(0).get("modify_ver_names").lastIndexOf("V"));
                    remindStr = remindStr + "BOP已有任务" + BopList.get(0).get("icount") + "\n";
                    remindStr = "版本:" +lastBopReworkVer + "\n------------------------------------------------\n" + remindStr;
                    phoneList.add(BopPeple);
                    iBopSumCount = Integer.parseInt(bop.get("icount"));
                    break;
                }

            }

        } else if (EligList != null) {

            for (Map<String, String> elig : EligList){
                if (DateCompare(elig.get("EXPECTED_PELEASE_DATE".toLowerCase()), 14)){
                    lastEligReworkVer = EligList.get(0).get("modify_ver_names").substring(EligList.get(0).get("modify_ver_names").lastIndexOf("V"));
                    remindStr = remindStr + "Elig已有任务" + EligList.get(0).get("icount");
                    remindStr = "版本:" + lastEligReworkVer + "\n------------------------------------------------\n" + remindStr;
                    phoneList.add(EligPeplo);
                    iBopSumCount = Integer.parseInt(elig.get("icount"));
                }
            }
        }
        remindStr = remindStr + "------------------------------------------------";

        if (AcctList != null){
            for (Map<String, String> taskReminder : AcctList) {
                if (DateCompare(taskReminder.get("EXPECTED_PELEASE_DATE".toLowerCase()), 0)){
                    remindStr = remindStr + "\n账户" + taskReminder.get("modify_ver_names") + "已有任务" + taskReminder.get("icount") + " ";
                    iActSumCount += Integer.parseInt(taskReminder.get("icount"));
                }

            }
        }


        remindStr = remindStr + "\n目前共有业务集中运营平台任务" + iBopSumCount;
        if (iBopSumCount >= itxCount){
            remindStr = remindStr + "@" + allPeplo + "@" + BopPeple + "@" + EligPeplo;
            phoneList.add(allPeplo);
        } else {
            phoneList = new ArrayList<>();
            phoneList.add(allPeplo);
        }
        remindStr = remindStr + "\n目前共有账户任务" + iActSumCount + "@" + allPeplo;

        Map<String, Object> messageMap = new HashMap<>();
        messageMap.put("receiveList", phoneList);
        messageMap.put("content", remindStr);
        return messageMap;
    }

    @Override
    public Map<String, Object> assemblyDingMessage(Map<String, Object> messageMap) {
        Map<String, Object> dingMessageMap = new HashMap<>();
        dingMessageMap.put("msgtype", "text");
        dingMessageMap.put("content", messageMap.get("content"));
        dingMessageMap.put("receiveList", messageMap.get("receiveList"));
        dingMessageMap.put("isAtAll", false);
        return dingMessageMap;
    }

    private String GetProductId(String productName){
        if ("账户管理2.0".equals(productName)){
            return "00073";
        } else if ("UF2.0".equals(productName)){
            return "00100";
        } else if ("档案管理平台".equals(productName)){
            return "00002";
        } else if ("业务集中运营平台".equals(productName)) {
            return "00003";
        } else if ("统一适当性管理平台".equals(productName)){
            return "00001";
        } else if ("融资融券2.0".equals(productName)){
            return "00100";
        } else if ("转融通".equals(productName)){
            return "00100";
        } else {
            return "99999";
        }
    }


    private String GetStrandingDate(String assignDate) {
        if (assignDate.length() == 0){
            return " ";
        } else if (assignDate.length() == 10){
            return assignDate.substring(0, 4) + assignDate.substring(5, 7) + assignDate.substring(8);
        } else if (assignDate.length() > 10){
            return assignDate.substring(0, 4) + assignDate.substring(5, 7) + assignDate.substring(8, 10);
        } else {
            LOGGER.warning("时间格式转换错误");
            return "0";
        }
    }

    private String GetTestType(String isUserTest) {

        if (" ".equals(isUserTest)){
            return " ";
        } else if ("0".equals(isUserTest)) {
            return "现场测试";
        } else if ("1".equals(isUserTest)) {
            return "测试部测试";
        } else if ("2".equals(isUserTest)) {
            return "现场测试与测试部同步测试";
        } else if ("3".equals(isUserTest)) {
            return "PM验收";
        } else if ("4".equals(isUserTest)) {
            return "开发自测";
        } else {
            return "测试类型转换失败";
        }
    }

    private String GetVersionType(String productVersionType) {

        if (" ".equals(productVersionType)){
            return " ";
        } else if ("0".equals(productVersionType)) {
            return "基线版本";
        } else if ("1".equals(productVersionType)) {
            return "增量版本";
        } else if ("2".equals(productVersionType)) {
            return "补丁版本";
        } else if ("6".equals(productVersionType)) {
            return "测试版本";
        } else if ("7".equals(productVersionType)) {
            return "脚本";
        } else {
            return "测试类型转换失败";
        }
    }

    private String FormatSugesstion(String sugesstion) {
        if ("".equals(sugesstion)) {
            return " ";
        } else {
            sugesstion = sugesstion.replaceAll("</div><div>", "\n");
            sugesstion = sugesstion.replaceAll("<br>", "\n");
            sugesstion = sugesstion.replaceAll("</div>", "");
            sugesstion = sugesstion.replaceAll("<div>", "");

            String str = "";
            while (sugesstion.matches("(.*)<(.*)>(.*)")){
                sugesstion = sugesstion.substring(sugesstion.indexOf(">") + 1);
                str = str + sugesstion.substring(0, sugesstion.matches("(.*)<(.*)") ? sugesstion.indexOf("<") : sugesstion.length());
                if (str.endsWith("]")){
                    str = str + "\n";
                }
            }
            return str.replaceAll("&nbsp", " ").trim();
        }
    }

    private String GetTaskDifficluty(String taskDifficulty){
        if (" ".equals(taskDifficulty)){
            return " ";
        } else if ("-1".equals(taskDifficulty)){
            return "空";
        } else if ("1".equals(taskDifficulty)) {
            return "高";
        } else if ("2".equals(taskDifficulty)) {
            return "中";
        } else if ("3".equals(taskDifficulty)) {
            return "低";
        } else if ("4".equals(taskDifficulty)) {
            return "极高";
        } else if ("5".equals(taskDifficulty)) {
            return "极低";
        } else {
            return "任务难度转换失败";
        }
    }


    private String FormatReqDesc(String taskReqDesc) {
        if ("".equals(taskReqDesc)) {
            return " ";
        } else {
            taskReqDesc = taskReqDesc.replaceAll("</div><div>", "\n");
            taskReqDesc = taskReqDesc.replaceAll("<br>", "\n");
            taskReqDesc = taskReqDesc.replaceAll("</div>", "");
            taskReqDesc = taskReqDesc.replaceAll("<div>", "");

            String str = "";
            while (taskReqDesc.matches("(.*)<(.*)>(.*)")){
                taskReqDesc = taskReqDesc.substring(taskReqDesc.indexOf(">") + 1);
                str = str + taskReqDesc.substring(0, taskReqDesc.matches("(.*)<(.*)") ? taskReqDesc.indexOf("<") : taskReqDesc.length());
                if (str.endsWith("]")){
                    str = str + "\n";
                }
            }
            return str.replaceAll("&nbsp", " ").trim();
        }
    }

    private String GetTaskStatus(String taskStatus) {
        if (" ".equals(taskStatus)) {
            return " ";
        } else if ("0".equals(taskStatus)) {
            return "草稿";
        } else if ("1".equals(taskStatus)) {
            return "待审核";
        } else if ("2".equals(taskStatus)) {
            return "待下达";
        } else if ("3".equals(taskStatus)) {
            return "已下达";
        } else if ("6".equals(taskStatus)) {
            return "已作废";
        } else if ("7".equals(taskStatus)) {
            return "审核退回";
        } else if ("8".equals(taskStatus)) {
            return "已撤回";
        } else {
            return "任务状态转换失败";
        }
    }

    private String GetTaskType(String taskType) {
        if (" ".equals(taskType)) {
            return " ";
        } else if ("-1".equals(taskType)) {
            return "空";
        } else if ("0".equals(taskType)) {
            return "缺陷";
        } else if ("1".equals(taskType)) {
            return "日常服务事件";
        } else if ("2".equals(taskType)) {
            return "个性业务需求";
        } else if ("3".equals(taskType)) {
            return "通用业务需求";
        } else if ("4".equals(taskType)) {
            return "改进业务需求";
        } else {
            return "需求类型转换失败";
        }
    }

    /**
     * SDate与今天比较，大于dayNum天返回true
     * @param sDate 待比较时间
     * @param dayNum 相差天数
     * @return
     * @throws ParseException
     */
    private boolean DateCompare(String sDate, Integer dayNum) throws ParseException {
        SimpleDateFormat sdf  =   new  SimpleDateFormat( "yyyy-MM-dd HH:mm:ss" );
        sDate = sDate.substring(0, 4) + "-" + sDate.substring(4, 6) + "-" + sDate.substring(6, 8) + " 00:00:00";
        Date dateExpect = sdf.parse(sDate);
        Date currentDate = new Date();
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String today = format.format(currentDate);
        Date date = sdf.parse(today);
        if (Integer.parseInt(CheckDay.compare(dateExpect, date)) > dayNum) return true;
        else return false;


    }
}
