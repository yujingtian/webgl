package com.hundsun.tool.sqltool.service.impl;

import com.hundsun.tool.sqltool.mapper.DcDbServerInfoMapper;
import com.hundsun.tool.sqltool.pojo.DcDbServerInfo;
import com.hundsun.tool.sqltool.service.api.DcDbServerInfoService;
import com.iceolive.util.StringUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author Star_King
 */
@Service("dcDbServerInfoService")
public class DcDbServerInfoServiceImpl implements DcDbServerInfoService {
    private final DcDbServerInfoMapper dcDbServerInfoMapper;

    public DcDbServerInfoServiceImpl(@Qualifier("dcDbServerInfoMapper") DcDbServerInfoMapper dcDbServerInfoMapper) {
        this.dcDbServerInfoMapper = dcDbServerInfoMapper;
    }

    @Override
    public DcDbServerInfo searchDcDbServerInfoByAliasAndUsername(String serverAlias, String username) {
        if (StringUtil.isBlank(username)) {
            System.out.println("illegal param!");
            return null;
        }
        List<DcDbServerInfo> dcDbServerInfos = dcDbServerInfoMapper.selectDbInfoByAliasAndUsername(serverAlias, username);
        return dcDbServerInfos.isEmpty() ? null : dcDbServerInfos.get(0);
    }
}

