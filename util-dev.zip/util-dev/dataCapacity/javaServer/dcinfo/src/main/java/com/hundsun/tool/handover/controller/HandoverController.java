package com.hundsun.tool.handover.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.hundsun.tool.handover.pojo.Handover;
import com.hundsun.tool.handover.pojo.HandoverInfo;
import com.hundsun.tool.handover.service.api.HandoverService;
import com.hundsun.tool.utils.ResultEntity;
import com.iceolive.util.StringUtil;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;
import java.util.stream.Collectors;

/**
 * @author Star_King
 */
@CrossOrigin
@RestController
@RequestMapping("/handover")
public class HandoverController {
    private final HandoverService handoverService;

    private static final Logger LOGGER = Logger.getLogger("com.hundsun.tool.handover.controller.HandoverController");

    public HandoverController(@Qualifier("handoverService") HandoverService handoverService) {
        this.handoverService = handoverService;
    }

    @PostMapping("/handover")
    public String handover(@RequestBody HandoverInfo info) throws JsonProcessingException {
        // 获取参数
        String oldUserID = info.getOldUserID();
        String newUserID = info.getNewUserID();
        if (!StringUtil.isBlank(oldUserID)) {
            oldUserID = oldUserID.trim();
            try {
                oldUserID = Integer.parseInt(oldUserID) + "";
            } catch (NumberFormatException e) {
                return ResultEntity.failWithoutData("用户ID异常！").returnResult();
            }
        }
        if (!StringUtil.isBlank(newUserID)) {
            newUserID = newUserID.trim();
            try {
                newUserID = Integer.parseInt(newUserID) + "";
            } catch (NumberFormatException e) {
                return ResultEntity.failWithoutData("用户ID异常！").returnResult();
            }
        }
        List<String> tables = info.getTables();
        // 合法性判断
        if (StringUtil.isEmpty(oldUserID) || StringUtil.isEmpty(newUserID) || tables == null || tables.isEmpty()) {
            LOGGER.warning("转移权限参数异常！");
            return ResultEntity.failWithoutData("参数异常！").returnResult();
        }
        // 根据表别名查询表信息
        List<Handover> Handovers = new ArrayList<>(10);
        for (String table : tables) {
            Handover handover = handoverService.searchHandoverByAlias(table);
            if (handover != null) {
                Handovers.add(handover);
            }
        }
        // stream流进行筛选，选出含有USER_ID字段的表，对于DCTOOLINFO表的CREATE_OPERATOR字段
        List<Handover> list = Handovers.stream().filter(item -> "1".equals(item.getHasUser()) ||
                "DCTOOLINFO".equals(item.getTableName())).collect(Collectors.toList());

        boolean flag = true;
        // 对其中的每一个表都进行修改，将旧的人员ID变为新人员ID
        for (Handover handover : list) {
            boolean success;
            if ("DCTOOLINFO".equals(handover.getTableName())) {
                // 对于DCTOOLINFO表的特殊处理
                success = handoverService.changeTable(oldUserID, newUserID, handover.getTableName(), "MOD_OPERATOR_NO");
            } else {
                // 通用处理
                success = handoverService.changeTable(oldUserID, newUserID, handover.getTableName(), "USER_ID");
            }
            if (!success) {
                flag = false;
            }
        }
        // 返回结果
        if (flag) {
            return ResultEntity.successWithoutData().returnResult();
        } else {
            return ResultEntity.failWithoutData("修改失败！").returnResult();
        }
    }

    @PostMapping("/retrieve")
    public String retrieveHandover(@RequestParam(value = "tableName", defaultValue = "") String tableName,
                                   @RequestParam(value = "tableAlias", defaultValue = "") String tableAlias) throws JsonProcessingException {
        if ("".equals(tableName) && "".equals(tableAlias)) {
            List<Handover> handovers = handoverService.searchAllHandover();
            LOGGER.info("查询Handover成功！");
            return ResultEntity.successWithData(handovers).returnResult();
        }
        Handover handover;
        if ("".equals(tableName)) {
            handover = handoverService.searchHandoverByAlias(tableAlias);
        } else if ("".equals(tableAlias)){
            handover = handoverService.searchHandoverByName(tableName);
        } else {
            handover = handoverService.searchHandoverByNameAndAlias(tableName, tableAlias);
        }
        if (handover == null) {
            LOGGER.warning("查询Handover失败！");
            return ResultEntity.failWithoutData("查询失败！").returnResult();
        } else {
            LOGGER.info("查询Handover成功！");
            return ResultEntity.successWithData(handover).returnResult();
        }
    }

    @PostMapping("/create")
    public String createHandover(@RequestParam(value = "tableName", defaultValue = "") String tableName,
                                 @RequestParam(value = "tableAlias", defaultValue = "") String tableAlias,
                                 @RequestParam(value = "hasUser", defaultValue = "") String hasUser) throws JsonProcessingException {
        boolean hasUserCheck = !"0".equals(hasUser) && !"1".equals(hasUser);
        if ("".equals(tableName) || "".equals(hasUser) || hasUserCheck) {
            LOGGER.warning("创建Handover参数异常！");
            return ResultEntity.failWithoutData("参数异常！").returnResult();
        }
        Handover handover = handoverService.searchHandoverByName(tableName);
        if (handover != null) {
            LOGGER.warning("表中已包含了该表名！");
            return ResultEntity.failWithoutData("表中已包含了该表名！").returnResult();
        }
        if (!handoverService.existTable(tableName)) {
            LOGGER.warning("数据库中不存在该表！");
            return ResultEntity.failWithoutData("数据库中存在该表！").returnResult();
        }
        if (!handoverService.existColumn(tableName, "USER_ID")) {
            LOGGER.warning("该表中无USER_ID字段！");
            return ResultEntity.failWithoutData("该表中无USER_ID字段！").returnResult();
        }
        Handover handover1 = new Handover(tableName, tableAlias, hasUser);
        boolean success = handoverService.addHandover(handover1);
        if (success) {
            LOGGER.info("添加Handover记录成功！");
            return ResultEntity.successWithoutData().returnResult();
        } else {
            LOGGER.warning("添加Handover记录失败！");
            return ResultEntity.failWithoutData("添加Handover记录失败！").returnResult();
        }
    }

    @PostMapping("/delete")
    public String deleteHandover(@RequestParam(value = "tableName", defaultValue = "") String tableName,
                                 @RequestParam(value = "tableAlias", defaultValue = "") String tableAlias) throws JsonProcessingException {
        if ("".equals(tableName) && "".equals(tableAlias)) {
            LOGGER.warning("删除Handover参数异常！");
            return ResultEntity.failWithoutData("参数异常！").returnResult();
        }
        boolean success;
        if ("".equals(tableAlias)) {
            success = handoverService.removeHandoverByName(tableName);
        } else {
            success = handoverService.removeHandoverByAlias(tableAlias);
        }
        if (success) {
            LOGGER.info("删除Handover记录成功！");
            return ResultEntity.successWithoutData().returnResult();
        } else {
            LOGGER.warning("删除Handover记录失败！");
            return ResultEntity.failWithoutData("删除Handover记录失败！").returnResult();
        }
    }

    @PostMapping("/update")
    public String updateHandover(@RequestParam(value = "tableName", defaultValue = "") String tableName,
                                 @RequestParam(value = "tableAlias", defaultValue = "") String tableAlias,
                                 @RequestParam(value = "hasUser", defaultValue = "") String hasUser) throws JsonProcessingException {
        boolean hasUserCheck = !"0".equals(hasUser) && !"1".equals(hasUser);
        if ("".equals(tableName) || hasUserCheck) {
            LOGGER.warning("修改Handover参数异常！");
            return ResultEntity.failWithoutData("参数异常！").returnResult();
        }
        Handover handover1 = handoverService.searchHandoverByAlias(tableAlias);
        boolean user_id = handoverService.existColumn(handover1.getTableName(), "USER_ID");
        boolean b1 = user_id && "0".equals(hasUser);
        boolean b2 = !user_id && "1".equals(hasUser);
        if (b1 || b2) {
            LOGGER.warning("非法修改标志位！");
            return ResultEntity.failWithoutData("非法修改标志位！").returnResult();
        }
        Handover handover = new Handover(tableName, tableAlias, hasUser);
        boolean success = handoverService.changeHandover(handover);
        if (success) {
            LOGGER.info("修改Handover记录成功！");
            return ResultEntity.successWithoutData().returnResult();
        } else {
            LOGGER.warning("修改Handover记录失败！");
            return ResultEntity.failWithoutData("修改Handover记录失败！").returnResult();
        }
    }
}
