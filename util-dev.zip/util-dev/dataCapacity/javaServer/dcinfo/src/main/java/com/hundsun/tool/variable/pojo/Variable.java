package com.hundsun.tool.variable.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Star_King
 */
public class Variable {
    private String variableName;
    private String variableAlias;
    private String variableValue;
    private String variableDescription;

    public Variable() {
    }

    public Variable(String variableName, String variableAlias, String variableValue, String variableDescription) {
        this.variableName = variableName;
        this.variableAlias = variableAlias;
        this.variableValue = variableValue;
        this.variableDescription = variableDescription;
    }

    public String getVariableName() {
        return variableName;
    }

    public void setVariableName(String variableName) {
        this.variableName = variableName;
    }

    public String getVariableAlias() {
        return variableAlias;
    }

    public void setVariableAlias(String variableAlias) {
        this.variableAlias = variableAlias;
    }

    public String getVariableValue() {
        return variableValue;
    }

    public void setVariableValue(String variableValue) {
        this.variableValue = variableValue;
    }

    public String getVariableDescription() {
        return variableDescription;
    }

    public void setVariableDescription(String variableDescription) {
        this.variableDescription = variableDescription;
    }

    @Override
    public String toString() {
        return "Variable{" +
                "variableName='" + variableName + '\'' +
                ", variableAlias='" + variableAlias + '\'' +
                ", variableValue='" + variableValue + '\'' +
                ", variableDescription='" + variableDescription + '\'' +
                '}';
    }
}
