package com.hundsun.dcinfo.param.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 
 * </p>
 *
 * @author Wanglei
 * @since 2021-08-05
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("DCTOOLPARAM")
public class ToolParam implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId("TOOL_ID")
    private String toolId;

    @TableField("NAME")
    private String name;

    @TableField("REMARK")
    private String remark;


}
