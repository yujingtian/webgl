package com.hundsun.tool.functest.t3.service;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.extension.service.IService;
import com.hundsun.tool.functest.t3.exception.T3Exception;
import com.hundsun.tool.functest.t3.pojo.TThreeTest;
import com.hundsun.tool.functest.t3.pojo.TThreeVO;
import com.hundsun.tool.functest.t3.pojo.TestName;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * @author wenping 2021-07-20 17:28
 */
public interface TThreeTestService extends IService<TThreeTest> {
    /**
     * 根据测试用例名和用户ID查询属于用户ID同一组的所有测试用例，并按照ORD排序返回
     * @param testName 测试用例名
     * @return
     * @throws T3Exception
     */
    TThreeVO showTestDetails(String testName) throws T3Exception;

    /**
     * 将测试用例[名和别名]和数据插入到DCTESTNAME和DCTTHREETEST中
     * @param testName 测试用例[名和别名]
     * @param data 从前端接收的json字符串组
     * @return
     * @throws T3Exception 如果有不符合的数据，则抛出异常，并回滚
     */
    int save(TestName testName, JSONArray data) throws T3Exception;

    int delete(String testName, String userID) throws T3Exception;

    int verify(String testName, String userID) throws T3Exception;

    String getString(Set<Map.Entry<String, Object>> entrySet);
}
