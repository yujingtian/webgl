package com.hundsun.tool.reminders.controller;

import com.alibaba.fastjson.JSONObject;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.hundsun.dcinfo.jumpToMail.controller.DingTalkController;
import com.hundsun.tool.reminders.entity.TSPass;
import com.hundsun.tool.reminders.service.DRTwoService;
import com.hundsun.tool.utils.CheckDay;
import com.hundsun.tool.utils.ResultEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

/**
 * @Author: kcaumber
 * @Date: 2021/11/10 18:25
 */
@CrossOrigin
@RestController
@RequestMapping("/DRTwoReminder")
public class DRTwoController {
    private static final Logger LOGGER = Logger.getLogger("com.hundsun.tool.reminders.controller.DRTwoReminder");

    private final DRTwoService drTwoService;

    @Autowired
    private DingTalkController dingTalkController;

    public DRTwoController(@Qualifier("drTwoService") DRTwoService drTwoService) {
        this.drTwoService = drTwoService;
    }

    @RequestMapping("/monthly")
    public String monthly(@RequestParam(value = "dayNum", defaultValue = "") String dayNum) throws UnsupportedEncodingException, NoSuchAlgorithmException, InvalidKeyException, JsonProcessingException {
        if ("".equals(dayNum) || CheckDay.checkLastWorkDay(dayNum)){
            if (CheckDay.checkWorkDay()) {
                List<TSPass> tsPassList = drTwoService.getTsPassData();

                if (tsPassList == null || tsPassList.size() == 0){
                    LOGGER.warning("未查到数据");
                }

                Map<String, Object> messageMap = drTwoService.assemblyMessage(tsPassList);

                Map<String, Object> dingMessageMap = drTwoService.assemblyDingMessage(messageMap);
                dingMessageMap.put("groupName", "业务研发二组");
                String msgInfo = JSONObject.toJSONString(dingMessageMap);

                return dingTalkController.sendDingTalk(msgInfo);
            } else {
                return ResultEntity.failWithoutData("今天不是工作日").returnResult();
            }

        } else {
            return ResultEntity.failWithoutData("今天不是最后" + dayNum + "个工作日之一").returnResult();
        }

    }
}
