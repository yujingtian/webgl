package com.hundsun.dcinfo.util;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Result {
    private Boolean success;
    private String msg;
    private Object data;
}
