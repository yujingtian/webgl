package com.hundsun.dcinfo.menu.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 
 * </p>
 *
 * @author Wanglei
 * @since 2021-07-30
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("DCMENU")
public class Dcmenu implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableField("MENU_CAPTION")
    private String menuCaption;

    @TableField("MENU_URL")
    private String menuUrl;

    @TableField("CANSEARCH")
    private String cansearch;
}
