package com.hundsun.tool.uf3Dictionary.mapper;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hundsun.tool.uf3Dictionary.entity.UF3_Dictionary;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @Author tdragon.
 * @Date 2021/8/22.
 * @Time 21:43
 * @Description:
 */
@Mapper
@DS("hs_efficiency")
@Repository
public interface DictMapper extends BaseMapper<UF3_Dictionary> {

    @Select("SELECT  " +
            " DISTINCT " +
            "a.uuid, " +
//            " count(*)," +
            " dict_uuid," +
            " b.uuid," +
            " dict_entry,entry_name,a.en_system_str,sub_entry, b.dict_prompt FROM hep_std_dict_dept_tbl a" +
            " left" +
            " JOIN hep_std_sub_dict_dept_tbl  b ON a.uuid=b.dict_uuid " +
            "where a.dict_entry>=#{param1} AND a.dict_entry<=#{param2}"+ " and a.belong_id = 'hsbroker' "+
            " ORDER BY a.dict_entry ASC ;")
    public List<UF3_Dictionary> getAllDictionariesSection(String startDicItem, String endDicItem);

    /**
     * 查询对应 uf2字典id 不在此区间的
     * @return
     */
    @Select("SELECT " +
            " DISTINCT " +
            "a.uuid," +
            " dict_uuid," +
            " b.uuid," +
            " dict_entry,entry_name,a.en_system_str,sub_entry, b.dict_prompt FROM hep_std_dict_dept_tbl a" +
            " left" +
            " JOIN hep_std_sub_dict_dept_tbl  b ON a.uuid=b.dict_uuid " +
            " where a.dict_entry " +
            " not in" +
            " (" +
            " SELECT  " +
            " DISTINCT " +
            " dict_entry FROM hep_std_dict_dept_tbl a " +
            " left" +
            " JOIN hep_std_sub_dict_dept_tbl  b ON a.uuid=b.dict_uuid " +
            " where a.dict_entry >='100' AND a.dict_entry<='99999'" + " and a.belong_id = 'hsbroker' "+
            " ORDER BY a.dict_entry ASC" +
            " )" +
            " and a.belong_id = 'hsbroker' "+
            " ORDER BY a.dict_entry ASC ;")
    public List<UF3_Dictionary> getAllDictionariesNonBetweenDictItem();

}
