package com.hundsun.tool.reminders.entity;

/**
 * @Author: kcaumber
 * @Date: 2021/11/1 16:38
 */
public class TSPass {

    private String operatorNo; // 工号
    private String operatorName; // 姓名
    private Integer sl; // 递交数量
    private Integer thsl; // 打回单数
    private Integer passRate; // 通过率

    public TSPass() {
    }

    public TSPass(String operatorNo, String operatorName, Integer sl, Integer thsl, Integer passRate) {
        this.operatorNo = operatorNo;
        this.operatorName = operatorName;
        this.sl = sl;
        this.thsl = thsl;
        this.passRate = passRate;
    }

    public String getOperatorNo() {
        return operatorNo;
    }

    public void setOperatorNo(String operatorNo) {
        this.operatorNo = operatorNo;
    }

    public String getOperatorName() {
        return operatorName;
    }

    public void setOperatorName(String operatorName) {
        this.operatorName = operatorName;
    }

    public Integer getSl() {
        return sl;
    }

    public void setSl(Integer sl) {
        this.sl = sl;
    }

    public Integer getThsl() {
        return thsl;
    }

    public void setThsl(Integer thsl) {
        this.thsl = thsl;
    }

    public Integer getPassRate() {
        return passRate;
    }

    public void setPassRate(Integer passRate) {
        this.passRate = passRate;
    }

    @Override
    public String toString() {
        return "TSPass{" +
                "operatorNo='" + operatorNo + '\'' +
                ", operatorName='" + operatorName + '\'' +
                ", sl=" + sl +
                ", thsl=" + thsl +
                ", passRate=" + passRate +
                '}';
    }
}
