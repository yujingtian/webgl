package com.hundsun.tool.utils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.*;

import static com.baomidou.mybatisplus.core.toolkit.BeanUtils.beanToMap;
import static com.baomidou.mybatisplus.core.toolkit.BeanUtils.mapToBean;

/**
 * @Author: kcaumber
 * @Date: 2021/11/12 13:06
 */
public class TransClassUtil {

    /**
     * object To List
     * @param obj
     * @param clazz
     * @param <T>
     * @return
     */
    public static <T> List<T> castList(Object obj, Class<T> clazz) {
        List<T> result = new ArrayList<T>();
        if (obj instanceof List<?>) {
            for (Object o : (List<?>) obj) {
                result.add(clazz.cast(o));
            }
            return result;
        }
        return null;
    }

    /**
     * obj to map
     * @param obj
     * @param <T>
     * @return
     */
    public static <T> Map<String, Object> castMap(Object obj) {
        return JSONObject.parseObject(JSON.toJSONString(obj));
    }

    public static Object mapToObj(Map<String,Object> map,Class<?> clz) throws Exception{
        Object obj = clz.newInstance();
        Field[] declaredFields = obj.getClass().getDeclaredFields();
        for(Field field:declaredFields){
            int mod = field.getModifiers();
            if(Modifier.isStatic(mod) || Modifier.isFinal(mod)){
                continue;
            }
            field.setAccessible(true);
            field.set(obj, map.get(field.getName()));
        }
        return obj;
    }

}
