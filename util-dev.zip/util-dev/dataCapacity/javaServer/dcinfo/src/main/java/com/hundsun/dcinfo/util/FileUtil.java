package com.hundsun.dcinfo.util;

import cn.hutool.core.util.IdUtil;

import java.io.*;

public class FileUtil {

    public static void deleteFileByURL(String fileName) {
        File file = new File(fileName);
        // 如果文件路径所对应的文件存在，并且是一个文件，则直接删除
        if (file.exists() && file.isFile()) {
            if (file.delete()) {
            } else {
            }
        } else {
        }
    }

    public static String writeToFile(String str, String dir) {
        String fileName = IdUtil.simpleUUID() + ".txt";
        String path = dir + fileName;
        File file = new File(path);
        try {
            // 创建新文件
            file.createNewFile();
            // 将内容写入到新文件
            FileWriter writer = new FileWriter(path);
            writer.write(str);
            writer.flush();
            writer.close();
        } catch (IOException e) {
            return "";
        }
        return fileName;

    }

    public static String getString(String file, String dir) {
        StringBuilder res = new StringBuilder();
        try {
            FileReader fw = new FileReader(dir + file);
            BufferedReader bf = new BufferedReader(fw);
            // 按行读取字符串
            String str;
            while ((str = bf.readLine()) != null) {
                res.append(str);
            }
            bf.close();
        } catch (IOException e) {
            return " ";
        }
        return res.toString();
    }
}
