package com.hundsun.tool.encrypt.service.api;

import com.hundsun.tool.encrypt.pojo.MicroServerInfo;

/**
 * @author Star_King
 */
public interface MicroServerInfoService {
    /**
     * 根据客户端别名查询第一条客户端信息
     * @param serverAlias 客户端别名
     * @return MicroServerInfo对象
     */
    MicroServerInfo searchInfoByAlias(String serverAlias);

    /**
     * 根据IP和端口号查询客户端信息
     * @param serverIP IP地址
     * @param serverPort 端口号
     * @return MicroServerInfo对象
     */
    MicroServerInfo searchInfoByIPAndPort(String serverIP, String serverPort);
}
