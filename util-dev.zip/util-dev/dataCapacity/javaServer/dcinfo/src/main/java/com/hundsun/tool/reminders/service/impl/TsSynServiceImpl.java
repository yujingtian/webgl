package com.hundsun.tool.reminders.service.impl;

import ch.qos.logback.classic.util.LogbackMDCAdapter;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.hundsun.jrescloud.common.code.ErrorCode;
import com.hundsun.tool.reminders.mapper.TsSynMapper;
import com.hundsun.tool.reminders.service.TsSynService;
import com.hundsun.tool.utils.DBWorkUtil;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @Author: kcaumber
 * @Date: 2021/12/20 11:22
 */
@Service("tsSynService")
public class TsSynServiceImpl implements TsSynService {
    private final TsSynMapper tsSynMapper;

    private String getUserInfoSql = "select distinct operator_no,operator_name from tsoperators";

    private String InsertTmpTssynproinfo = "insert into hs_asset.tmp_tssynproinfo (\n" +
            "REWORKING_ID,REWORKING_REMARK,SUGGESTION,SUMMARY,PROGRAM_PATH_A,\n" +
            "TEST_RESULT,REWORKING_STATUS_NO,REWORKING_STATUS_NAME,MENDER_NO,MENDER_SIGN,\n" +
            "INTEGRATION_DATE,BEGIN_DATE,STEPDATE_B,TEST_BACKS,PRODUCT_ID,\n" +
            "TESTDONEDATE,SYS_RECEIVER_SIGN,SYS_RECEIVER,TESTMAN_SIGN,MENDER_APPOINT,\n" +
            "WORKLOAD_ESTIMATE,URGENT_LEVEL,STEPDATE_A,JHBEGIN_DATE,IHOURS,\n" +
            "AUDITHOURS,AUDITREMARK,AUDIT_SIGN,TEST_QUESTION,BUG_LIST,\n" +
            "DEMAND_ID,DEMAND_SIDE,REWORK_VER,sys_receiver_signs,PROMISE_DATE) values (\n" +
            "?,?,?,?,?,\n" +
            "?,?,?,?,?,\n" +
            "?,?,?,?,?,\n" +
            "?,?,?,?,?,\n" +
            "?,?,?,?,?,\n" +
            "?,?,?,?,?,\n" +
            "?,?,?,?,?)";

    private String insertTmpProInfo = "insert into hs_asset.tmp_TSProInfo(reworking_id,proname,prover) values(?,?,?)";

    private String synTssynproinfo = "merge into hs_asset.tssynproinfo a using\n" +
            "                    (select * from hs_asset.tmp_tssynproinfo b) c on (a.reworking_id = c.reworking_id)\n" +
            "                    when matched then\n" +
            "                    update set a.reworking_remark = c.reworking_remark,\n" +
            "                                a.suggestion = c.suggestion,\n" +
            "                                a.summary = c.summary,\n" +
            "                                a.stepdate_b = c.stepdate_b,\n" +
            "                                a.program_path_a = c.program_path_a,\n" +
            "                                a.test_result = c.test_result,\n" +
            "                                a.reworking_status_no = c.reworking_status_no,\n" +
            "                                a.reworking_status_name = c.reworking_status_name,\n" +
            "                                a.mender_no = c.mender_no,\n" +
            "                                a.mender_sign = c.mender_sign,\n" +
            "                                a.integration_date = c.integration_date,\n" +
            "                                a.begin_date = c.begin_date,\n" +
            "                                a.test_backs = c.test_backs,\n" +
            "                                a.product_id = c.product_id,\n" +
            "                                a.testdonedate = c.testdonedate,\n" +
            "                                a.sys_receiver_sign = c.sys_receiver_sign,\n" +
            "                                a.sys_receiver = c.sys_receiver,\n" +
            "                                a.testman_sign = c.testman_sign,\n" +
            "                                a.mender_appoint = c.mender_appoint,\n" +
            "                                a.workload_estimate = c.workload_estimate,\n" +
            "                                a.urgent_level = c.urgent_level,\n" +
            "                                a.stepdate_a = c.stepdate_a,\n" +
            "                                a.jhbegin_date = c.jhbegin_date,\n" +
            "                                a.ihours = c.ihours,\n" +
            "                                a.audithours = c.audithours,\n" +
            "                                a.auditremark = c.auditremark,\n" +
            "                                a.audit_sign = c.audit_sign,\n" +
            "                                a.test_question = c.test_question,\n" +
            "                                a.bug_list = c.bug_list,\n" +
            "                                a.demand_id = c.demand_id,\n" +
            "                                a.demand_side = c.demand_side,\n" +
            "                                a.rework_ver = c.rework_ver,\n" +
            "                                a.sys_receiver_signs = c.sys_receiver_signs,\n" +
            "                                a.promise_date = c.promise_date\n" +
            "                    when not matched then\n" +
            "                    insert (a.reworking_id,a.reworking_remark,a.suggestion,a.summary,a.program_path_a,a.test_result,\n" +
            "                    a.reworking_status_no,a.reworking_status_name,a.mender_no,a.mender_sign,a.integration_date,\n" +
            "                    a.begin_date,a.stepdate_b,a.test_backs,a.product_id,a.testdonedate,a.sys_receiver_sign,\n" +
            "                    a.sys_receiver,a.testman_sign,a.mender_appoint,a.workload_estimate,a.urgent_level,a.stepdate_a,\n" +
            "                    a.jhbegin_date,a.ihours,a.audithours,a.auditremark,a.audit_sign,a.test_question,a.bug_list,\n" +
            "                    a.demand_id,a.demand_side,a.rework_ver,a.sys_receiver_signs,a.promise_date) values (c.reworking_id,c.reworking_remark,c.suggestion,c.summary,c.program_path_a,c.test_result,\n" +
            "                    c.reworking_status_no,c.reworking_status_name,c.mender_no,c.mender_sign,c.integration_date,\n" +
            "                    c.begin_date,c.stepdate_b,c.test_backs,c.product_id,c.testdonedate,c.sys_receiver_sign,\n" +
            "                    c.sys_receiver,c.testman_sign,c.mender_appoint,c.workload_estimate,c.urgent_level,c.stepdate_a,\n" +
            "                    c.jhbegin_date,c.ihours,c.audithours,c.auditremark,c.audit_sign,c.test_question,c.bug_list,\n" +
            "                    c.demand_id,c.demand_side,c.rework_ver,c.sys_receiver_signs,c.promise_date)";

    private String deleteTmpProinfo = "delete hs_asset.TSProInfo a where a.reworking_id in (select reworking_id from hs_asset.tmp_TSProInfo) ";

    private String synTsProInfo = "insert into hs_asset.TSProInfo(reworking_id,proname,prover) select reworking_id,proname,prover from hs_asset.tmp_TSProInfo";

    private Map<String, String> tsProjectDict = new HashMap<String, String>(){{
        put("20140707", "IFS");
        put("20180108", "机构柜台");
        put("20180816", "内存清算");
        put("20170403", "统一适当性管理平台");
        put("20151204", "UF2.0");
        put("20151206", "账户管理2.0");
        put("20160702", "业务集中运营平台");
        put("20150307", "独立用户3.0");
        put("20170601", "档案管理平台");
        put("20151205", "融资融券2.0");
        put("20150806", "转融通");
        put("20190601", "账户管理2.0");
    }};

    private Map<String, String> tsReworkStatusDict = new HashMap<String, String>(){{
        put("0", "新增");
        put("2", "新增");
        put("1", "待审核");
        put("3", "待集成");
        put("5", "待测试");
        put("6", "分配测试");
        put("7", "测试开始");
        put("8", "测试完成");
        put("9", "测试打回");
        put("10", "作废");
        put("11", "测试验证通过");
    }};

    public TsSynServiceImpl(@Qualifier("tsSynMapper") TsSynMapper tsSynMapper) {
        this.tsSynMapper = tsSynMapper;
    }

    @Override
    public Map<String, String> getUserInfo() {

        ArrayList<Map<String, String>> userInfoList = DBWorkUtil.SelectDB(getUserInfoSql);
        Map<String, String> result = new LinkedHashMap<>();
        if (userInfoList != null){
            for (Map<String, String> userInfo : userInfoList) {
                result.put(userInfo.get("operator_no"), userInfo.get("operator_name"));
            }
        }
        return result;
    }

    @Override
    public String getAllModifier() {
        List<String> modifier = tsSynMapper.getAllModifier();
        if (modifier == null) {
            return "";
        }
        String modifierStr = "";
        for (String m : modifier) {
            modifierStr = modifierStr + "," + m;
        }
        if (modifierStr.startsWith(",")){
            modifierStr = modifierStr.substring(1);
        }
        return modifierStr;
    }

    @Override
    public List<String> qryStockRework(List<String> modifier) {
        return tsSynMapper.qryStockRework(modifier);
    }

    @Override
    public List<String> InsertTmpReworkList(JSONArray dataJson, Map<String, String> userDict) {
        List<String> result = new ArrayList<>();
        Map<String, String> fileList = new HashMap<>();

        ArrayList<Map<String, Object>> params = new ArrayList<>();
        for (Object object : dataJson) {
            JSONObject jsonObject = JSON.parseObject(JSON.toJSONString(object));
            String reworking_id = jsonObject.getString("modifyNum"); // 修改单编号
            if (!result.contains(reworking_id)){
                result.add(reworking_id);
            }
            String sys_receiver = jsonObject.getString("receiver"); // 接收人工号
            String tmpReceiver = "";
            for (String userNo : sys_receiver.split(",")){
                tmpReceiver = tmpReceiver + userDict.getOrDefault(userNo, userNo) + ",";
            }
            if (tmpReceiver.length() > 0) {
                sys_receiver = tmpReceiver.substring(0, tmpReceiver.lastIndexOf(",")); // 接收人姓名
            } else {
                sys_receiver = tmpReceiver;
            }
            String reworking_Ver = jsonObject.getString("versionNO"); // 修改的版本
            String reworking_status_no = jsonObject.getString("modifyStatus"); // 修改单状态
            String mender_no = jsonObject.getString("modifier"); // 修改人
            String footNode = jsonObject.getString("modifySummary") == null ? " " : jsonObject.getString("modifySummary"); // 修改补充说明
            Float hours = jsonObject.getFloat("workAccount") == null ? 0 : jsonObject.getFloat("workAccount"); // 总工作量(h)
            Float workload_estimate = jsonObject.getFloat("workAccount") == null ? 0 : jsonObject.getFloat("workAccount");;
//            Integer hours = jsonObject.getInteger("workAccount") == null ? 0 : jsonObject.getInteger("workAccount"); // 总工作量(h)
//            Integer workload_estimate = jsonObject.getInteger("workAccount") == null ? 0 : jsonObject.getInteger("workAccount"); // 总工作量(h)
            String reworking_Remark = jsonObject.getString("memo") == null ? " " : jsonObject.getString("memo"); // 备注
            String suggestion = formatLongText(jsonObject.getString("modifyReason")); // 修改原因
            String summary = formatLongText(jsonObject.getString("modifyDesc")); // 修改说明
            String program_path_a = jsonObject.getString("outProgram") == null ? " " : jsonObject.getString("outProgram"); // 输出程序
            Integer integration_date = formatDate(jsonObject.getLong("integationDate")); // 集成日期
            Integer develop_date = formatDate(jsonObject.getLong("commitDate")); // 开发完成日期
            Integer promise_date = formatDate(jsonObject.getLong("promiseDate")); // 承诺日期
            Integer test_backs = jsonObject.getInteger("returnCount") == null ? 0 : jsonObject.getInteger("returnCount"); // 打回次数
            String product_name = tsProjectDict.get(jsonObject.getString("productId")); // 产品名称
            Integer testdonedate = formatDate(jsonObject.getLong("testDate")); // 测试完成日期
            Integer stepdate_a = formatDate(jsonObject.getLong("createDate")); // 创建日期
            String testman_sign = userDict.get(jsonObject.getString("tester") == null ? " " : jsonObject.getString("tester")); // 测试执行人
            if (testman_sign == null) testman_sign = " ";
            Integer jhbegin_date = formatDate(jsonObject.getLong("firstModifyDate")); // 要求开发完成日期
            String test_result = tsResultDict(jsonObject.getString("testResult")); // 测试结果
            Float audithours = jsonObject.getFloat("auditingAccount") == null ? 0 : jsonObject.getFloat("auditingAccount"); // 代码审核工作量(h)
            String auditremark = jsonObject.getString("auditingDesc") == null ? " " : jsonObject.getString("auditingDesc"); // 审核说明
            String audit_sign = getAudit(jsonObject.getString("auditor"), userDict);
            String test_question = jsonObject.getString("testMemo") == null ? " " : jsonObject.getString("testMemo"); // 测试发现问题及备注
            String bug_list = " "; // 发现的缺陷编号
            String fileListStr = formatModifyFile(jsonObject.getString("modifyFile")); // 修改的文件
            if (!fileListStr.trim().equals("")) {fileList.put(reworking_id, fileListStr);}
            String demand_id = jsonObject.getString("reqNums") == null ? " " : jsonObject.getString("reqNums"); // 需求编号
            String demand_side = jsonObject.getString("customername") == null ? " " : jsonObject.getString("customername"); // 需求提出方
            String sys_receiver_sign = jsonObject.getString("receiver"); //接收人工号

            Map<String, Object> itemDict = new LinkedHashMap<>();
            itemDict.put("reworking_id",reworking_id);
            itemDict.put("reworking_Remark", reworking_Remark);
            suggestion = suggestion.replaceAll("'", "''");
            itemDict.put("suggestion", suggestion.length() >= 2000 ? suggestion.substring(0, 2000) : suggestion);
            itemDict.put("summary", summary.length() >= 2000 ? summary.substring(0, 2000) : summary);
            itemDict.put("program_path_a", program_path_a);
            itemDict.put("test_result", test_result);
            itemDict.put("reworking_status_no", GetReworkingStatusNo(tsReworkStatusDict.get(reworking_status_no)));
            itemDict.put("reworking_status_name", tsReworkStatusDict.get(reworking_status_no));
            itemDict.put("mender_no", mender_no);
            itemDict.put("mender_sign", userDict.get(mender_no));
            if (develop_date == 0){
                itemDict.put("integration_date", 0);
                itemDict.put("begin_date", integration_date);
                itemDict.put("stepdate_b", 0);
            } else {
                itemDict.put("integration_date", develop_date);
                itemDict.put("begin_date", develop_date);
                itemDict.put("stepdate_b", develop_date);
            }
            itemDict.put("test_backs", test_backs);
            itemDict.put("product_id", GetProductId(product_name));
            itemDict.put("testdonedate", testdonedate);
            itemDict.put("sys_receiver_sign", sys_receiver_sign);
            itemDict.put("sys_receiver", sys_receiver);
            itemDict.put("testman_sign", testman_sign);
            itemDict.put("mender_appoint", mender_no);
            itemDict.put("workload_estimate", workload_estimate);
            itemDict.put("urgent_level", "一般");
            itemDict.put("stepdate_a",stepdate_a);
            itemDict.put("jhbegin_date", jhbegin_date);
            itemDict.put("ihours", hours);
            itemDict.put("audithours", audithours);
            itemDict.put("auditremark", auditremark.length() >= 2000 ? auditremark.substring(0, 2000) : auditremark);
            itemDict.put("audit_sign", audit_sign);
            itemDict.put("test_question", test_question.length() >= 2000 ? test_question.substring(0 ,2000) : test_question);
            itemDict.put("bug_list", bug_list);
            itemDict.put("demand_id", demand_id);
            itemDict.put("demand_side", demand_side);
            itemDict.put("rework_ver", reworking_Ver);
            itemDict.put("sys_receiver_signs", sys_receiver_sign);
            itemDict.put("promise_date", promise_date);

            params.add(itemDict);
        }

        DBWorkUtil.ExecDB("truncate table hs_asset.tmp_tssynproinfo");
        DBWorkUtil.ExecDB("truncate table hs_asset.tmp_TSProInfo");
        if (params.size() > 0) {
            DBWorkUtil.ExecParamDB(InsertTmpTssynproinfo, params);
            params = new ArrayList<>();
            for (Map.Entry<String, String> fileItemID : fileList.entrySet()) {
                String fileDetail = fileItemID.getValue();
                for (String proItem : fileDetail.split("\n")) {
                    if (proItem.trim().length() != 0) {
                        if (proItem.contains("[")) {
                            String proName = proItem.substring(0, proItem.indexOf("["));
                            String proVer = proItem.substring(proItem.lastIndexOf("[") + 1, proItem.lastIndexOf("]"));
                            Map<String, Object> itemDictPro = new LinkedHashMap<String, Object>(){{
                                put("reworking_id", fileItemID.getKey());
                                put("proname", proName);
                                put("prover", proVer);
                            }};
                            params.add(itemDictPro);
                        }
                    }
                }
            }
            DBWorkUtil.ExecParamDB(insertTmpProInfo, params);
        }
        DBWorkUtil.ExecDB(synTssynproinfo);
        DBWorkUtil.ExecDB(deleteTmpProinfo);
        DBWorkUtil.ExecDB(synTsProInfo);

        return result;
    }

    /**
     * 根据产品名获取产品编号
     * @param product_name
     * @return
     */
    private String GetProductId(String product_name) {
        if ("账户管理2.0".equals(product_name)) {
            return "00073";
        } else if ("UF2.0".equals(product_name)) {
            return "00100";
        } else if ("档案管理平台".equals(product_name)) {
            return "00002";
        } else if ("业务集中运营平台".equals(product_name)) {
            return "00001";
        } else if ("统一适当性管理平台".equals(product_name)) {
            return "00001";
        } else if ("独立用户3.0".equals(product_name)) {
            return "00001";
        } else if ("融资融券2.0".equals(product_name)) {
            return "00100";
        } else if ("转融通".equals(product_name)) {
            return "00100";
        } else {
            return "99999";
        }

    }

    /**
     * 根据状态编号返回状态编号
     * @param statusNo
     * @return
     */
    private String GetReworkingStatusNo(String statusNo) {

        if ("新增".equals(statusNo)) {
            return "501";
        } else if ("待审核".equals(statusNo)) {
            return "504";
        } else if ("审核退回".equals(statusNo)) {
            return "503";
        } else if ("待集成".equals(statusNo)) {
            return "512";
        } else if ("集成退回".equals(statusNo)) {
            return "503";
        } else if ("待测试".equals(statusNo)) {
            return "514";
        } else if ("分配测试".equals(statusNo)) {
            return "506";
        } else if ("测试开始".equals(statusNo)) {
            return "507";
        } else if ("测试完成".equals(statusNo)) {
            return "508";
        } else if ("测试打回".equals(statusNo)) {
            return "509";
        } else if ("作废".equals(statusNo)) {
            return "502";
        } else if ("测试验证通过".equals(statusNo)) {
            return "510";
        } else if ("测试验证不通过".equals(statusNo)) {
            return "511";
        } else {
            return "0";
        }
    }

    /**
     * 格式化修改文件
     * @param modifyFile
     * @return
     */
    private String formatModifyFile(String modifyFile) {
        if (modifyFile == null) {
            return " ";
        }
        String rStr = "";
        if (modifyFile.startsWith("<")) {
            while (modifyFile.lastIndexOf("<") != -1) {
                modifyFile = modifyFile.substring(modifyFile.indexOf(">") + 1);
                if (modifyFile.lastIndexOf("<") != -1) {
                    rStr = rStr + modifyFile.substring(0, modifyFile.indexOf("<"));
                } else {
                    rStr = rStr + modifyFile;
                }
                if (rStr.endsWith("]")) {
                    rStr = rStr + "\n";
                }
            }
        } else {
            rStr = modifyFile;
        }
        rStr = rStr.replaceAll("&nbsp;", " ");
        rStr = rStr.replaceAll("<br>", "\n");
        if (rStr.endsWith("\n")) {
            rStr = rStr.substring(0, rStr.lastIndexOf("\n"));
        }
        if (rStr.contains("----")) {
            rStr = rStr.substring(rStr.indexOf("----") + 4);
        }
        return rStr;
    }


    /**
     * 格式化修改原因
     * @param modifyReason
     * @return
     */
    private String formatLongText(String modifyReason) {
        if (modifyReason == null) {
            return " ";
        }
        String rStr = "";
        modifyReason = modifyReason.replaceAll("<br>", "\n");
        modifyReason = modifyReason.replaceAll("</div><div>", "\n");
        while (modifyReason.lastIndexOf("<") != -1) {
            rStr = rStr + modifyReason.substring(modifyReason.indexOf("<"));
            modifyReason = modifyReason.substring(modifyReason.indexOf(">") + 1);
            if (rStr.endsWith("]")) {
                rStr = rStr + "\n";
            }
        }
        rStr = rStr.replaceAll("&nbsp;", " ");
        if (rStr.endsWith("\n")) {
            rStr = rStr.substring(0, rStr.lastIndexOf("\n"));
        }
        return rStr;
    }

    /**
     * 格式化日期
     * @param date
     * @return
     */
    private Integer formatDate(Long date) {
        if (date == null) {
            return 0;
        }
        if (date.toString().length() == 0) {
            return 0;
        }
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(Math.round(date * Math.pow(10, 10-String.valueOf(date).length())) * 1000);//转换为毫秒
        Date dateA = calendar.getTime();
        SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
        return Integer.parseInt(format.format(dateA));
    }

    /**
     * 返回测试结果
     * @param testResult
     * @return
     */
    private String tsResultDict(String testResult) {
        if (testResult == null){
            return " ";
        } else if ("0".equals(testResult)) {
            return "Y";
        } else if ("1".equals(testResult)) {
            return "N";
        } else {
            return "N";
        }
    }

    /**
     * 返回代码审核人
     * @param auditor
     * @param userDict
     * @return
     */
    private String getAudit(String auditor, Map<String, String> userDict) {
        if (auditor == null) {
            return " ";
        }
        String sRes = "";
        for (String user : auditor.split(",")) {
            sRes = userDict.get(user) + "(" + user + "),";
        }
        if (sRes.endsWith(",")) {
            sRes = sRes.substring(0, sRes.lastIndexOf(","));
        }
        return sRes;
    }

}
