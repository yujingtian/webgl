package com.hundsun.signup.pojo;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

/**
 * @author wenping 2021-07-30 13:20
 */
@Data
@TableName("DCSIGNUPUSERINFO")
public class SignUpUserInfo {
    @TableField("USER_ID")
    private String userID;
    @TableField("USER_NAME")
    private String userName;
    @TableField("PWD")
    private String pwd;
    @TableField("GROUP_NAME")
    private String groupName;
    @TableField("STATE")
    private int state;
    @TableField("RECEIVER_ID_LIST")
    private String receiverIDList;
    @TableField("EMAIL")
    private String email;
    @TableField("MOBILE_TEL")
    private String mobileTel;
}
