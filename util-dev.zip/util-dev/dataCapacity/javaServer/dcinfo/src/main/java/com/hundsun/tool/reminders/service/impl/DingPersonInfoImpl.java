package com.hundsun.tool.reminders.service.impl;

import com.hundsun.tool.reminders.entity.DingPersonInfo;
import com.hundsun.tool.reminders.mapper.DingPersonInfoMapper;
import com.hundsun.tool.reminders.service.DingPersonInfoService;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @Author: kcaumber
 * @Date: 2021/11/1 17:41
 */
@Service("dingPersonInfoService")
public class DingPersonInfoImpl implements DingPersonInfoService {

    private final DingPersonInfoMapper dingPersonInfoMapper;

    public DingPersonInfoImpl(@Qualifier("dingPersonInfoMapper") DingPersonInfoMapper dingPersonInfoMapper) {
        this.dingPersonInfoMapper = dingPersonInfoMapper;
    }

    @Override
    public List<String> selectPhoneByOperatorNo(String operatorNo) {
        return dingPersonInfoMapper.selectPhoneByOperatorNo(operatorNo);
    }

    @Override
    public List<DingPersonInfo> selectByOperatorNo(String operatorNo) {
        return dingPersonInfoMapper.selectByOperatorNo(operatorNo);
    }
}
