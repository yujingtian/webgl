package com.hundsun.tool.sqltool.mapper;

import com.hundsun.tool.sqltool.pojo.DcDbServerInfo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author Star_King
 */
@Mapper
@Repository("dcDbServerInfoMapper")
public interface DcDbServerInfoMapper {
    /**
     * 根据微服务别名和数据库用户名查询数据库信息
     * @param serverAlias 微服务别名
     * @param username 数据库用户名
     * @return DcDbServerInfo对象列表
     */
    List<DcDbServerInfo> selectDbInfoByAliasAndUsername(@Param("serverAlias") String serverAlias,
                                                        @Param("username") String username);
}
