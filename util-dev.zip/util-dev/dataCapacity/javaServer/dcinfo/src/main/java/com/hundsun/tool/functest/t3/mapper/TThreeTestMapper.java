package com.hundsun.tool.functest.t3.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hundsun.tool.functest.t3.pojo.TThreeTest;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author wenping 2021-07-23 13:45
 */
@Mapper
@Repository("tThreeTestMapper")
public interface TThreeTestMapper extends BaseMapper<TThreeTest> {
    /**
     * 根据测试用例ID查询测试用例，并按照ORD排序返回
     * @param testID 测试用例ID
     * @return
     */
    List<TThreeTest> selectByTestID(@Param("testID") int testID);

    @Delete("delete from DCTTHREETEST where TEST_ID = #{testID}")
    int delete(@Param("testID") int testID);


}
