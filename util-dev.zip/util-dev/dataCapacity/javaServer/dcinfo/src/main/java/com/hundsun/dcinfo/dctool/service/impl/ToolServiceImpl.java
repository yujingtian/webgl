package com.hundsun.dcinfo.dctool.service.impl;

import cn.hutool.core.util.IdUtil;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.hundsun.dcinfo.dctool.entity.ToolVo;
import com.hundsun.dcinfo.dctool.entity.Tool;
import com.hundsun.dcinfo.dctool.entity.SearchCondition;
import com.hundsun.dcinfo.dctool.mapper.DctoolinfoMapper;
import com.hundsun.dcinfo.dctool.service.ToolService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.hundsun.dcinfo.menu.entity.Dcmenu;
import com.hundsun.dcinfo.menu.service.IDcmenuService;
import com.hundsun.dcinfo.param.entity.ToolParam;
import com.hundsun.dcinfo.param.service.ToolParamService;
import com.hundsun.dcinfo.util.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author jobob
 * @since 2021-07-12
 */
@Service
public class ToolServiceImpl extends ServiceImpl<DctoolinfoMapper, Tool> implements ToolService {

    @Autowired
    private IDcmenuService menuService;

    // 工具参数service
    @Autowired
    private ToolParamService toolParamService;

    @Override
    public ToolVo selectByPage(SearchCondition condition) {
        // 构造查询条件
        QueryWrapper<Tool> wrapper = new QueryWrapper<>();// 工具表查询条件
        QueryWrapper<Dcmenu> wrapperMenu = new QueryWrapper<>();// 菜单表查询条件
        wrapperMenu.eq("CANSEARCH", "1");
        // 获取离线工具的url
        String offlineUrl = menuService.getOfflineUrl();
        ToolVo toolVo;// 返回信息
        List<Tool> list = new ArrayList<>(); // 结果集列表
        IPage<Tool> dcPage = new Page<>(); // 工具结果集
        int totalPage;
        if (StringUtils.hasText(condition.getSeries())) {
            // 根据序列
            wrapper.eq("PRODUCT_SERIES", condition.getSeries().trim());
            int count = baseMapper.selectCount(wrapper);
            if (count == 0) {
                return new ToolVo(0, condition.getPageSize(), 0L, null);
            } else {
                // 合起来的总页数
                totalPage = count / condition.getPageSize() + (count % condition.getPageSize() == 0 ? 0 : 1);
                condition.setCurrentPage(condition.getCurrentPage() > totalPage ? totalPage : condition.getCurrentPage());
                // 先获取工具表中数据
                dcPage.setCurrent(condition.getCurrentPage()); // 当前页码数
                dcPage.setSize(condition.getPageSize());    // 页面大小
                dcPage = baseMapper.selectPage(dcPage, wrapper); // 查询结果集
                list = dcPage.getRecords(); // 将数据加入list
                for (Tool t : list) {
                    t.setMenuUrl(offlineUrl);
                }
                toolVo = new ToolVo(condition.getCurrentPage(), condition.getPageSize(), (long) count, list);
            }
        } else if (StringUtils.hasText(condition.getKeywords())) {
            String keywords = condition.getKeywords().trim();
            // 根据工具名
            wrapper.or().eq("TOOL_NAME", keywords);
            // 根据工具说明
            wrapper.or().like("REMARK", keywords);
            // 根据关键词
            wrapper.or().eq("KEYWORDS", keywords);
            wrapper.or().like("KEYWORDS", "," + keywords + ",");
            wrapper.or().likeLeft("KEYWORDS", "," + keywords);
            wrapper.or().likeRight("KEYWORDS", keywords + ",");
            // 菜单表
            wrapperMenu.like("MENU_CAPTION", keywords);
            // 分页
            // 获取工具表总数量
            int toolCount = baseMapper.selectCount(wrapper);
            // 获取菜单表总数量
            int menuCount = menuService.count(wrapperMenu);
            // 总记录数
            int count = toolCount + menuCount;
            if (count == 0) {
                return new ToolVo(0, condition.getPageSize(), 0L, null);
            } else {
                // 计算工具可占的总页数
                int toolTotalPage = toolCount / condition.getPageSize() + (toolCount % condition.getPageSize() == 0 ? 0 : 1);
                // 计算菜单的总页数
                int menuTotalPage = menuCount / condition.getPageSize() + (menuCount % condition.getPageSize() == 0 ? 0 : 1);
                // 合起来的总页数
                totalPage = count / condition.getPageSize() + (count % condition.getPageSize() == 0 ? 0 : 1);

                // 获取最大页码数，当currentPage大于最大页码数时，将当前页码数设置为最大页码数
                if (condition.getCurrentPage() > totalPage) {
                    condition.setCurrentPage(totalPage);
                }
                if (condition.getCurrentPage() <= toolTotalPage) {
                    // 当要取的页数小于等于tool的总页数时，说明工具表中有数据
                    // 先获取工具表中数据
                    dcPage.setCurrent(condition.getCurrentPage()); // 当前页码数
                    dcPage.setSize(condition.getPageSize());    // 页面大小
                    dcPage = baseMapper.selectPage(dcPage, wrapper); // 查询结果集
                    list = dcPage.getRecords(); // 将数据加入list
                    for (Tool t : list) {
                        t.setMenuUrl(offlineUrl);
                    }
                }
                // 当工具数据的最后一页不满时，计算需要的数据数
                List<Dcmenu> menuList = new ArrayList<>();
                if (condition.getCurrentPage() == toolTotalPage && condition.getPageSize() * condition.getCurrentPage() > toolCount) {
                    if (toolTotalPage == totalPage) {
                        // 最后一页包含工具信息，要么所有符合条件的菜单信息都在最后一页，要么没有菜单信息
                        menuList = menuService.list(wrapperMenu);
                    } else {
                        // 不是最后一页，既包含工具，也包含菜单
                        // 计算需要在本页补充菜单数据的数量
                        int leftNum = condition.getPageSize() - toolCount % condition.getPageSize();
                        menuList = menuService.getMenuList("%" + condition.getKeywords() + "%", 1, leftNum);

                    }
                }
                if (condition.getCurrentPage() > toolTotalPage) {
                    // 当当前页码数大于等于工具的最大页码数时，说明菜单表中有数据
                    // 获取当前是菜单的第几页
                    int page = condition.getCurrentPage() - toolTotalPage;
                    int start, end;
                    if (toolCount % condition.getPageSize() == 0) {
                        // 工具数据占据一整页
                        start = (page - 1) * condition.getPageSize() + 1;
                    } else {
                        page++;
                        int leftNum = condition.getPageSize() - toolCount % condition.getPageSize();
                        start = (page - 2) * condition.getPageSize() + leftNum + 1;
                    }
                    end = start + condition.getPageSize() - 1;
                    menuList = menuService.getMenuList("%" + condition.getKeywords() + "%", start, end);
                }
                for (Dcmenu m : menuList) {
                    Tool tool = new Tool();
                    tool.setName(m.getMenuCaption());
                    tool.setCreateNo("sys");
                    tool.setModNo("sys");
                    tool.setMenuCaption(m.getMenuCaption());
                    tool.setMenuUrl(m.getMenuUrl());
                    tool.setKeywords("");
                    list.add(tool);
                }
            }
            toolVo = new ToolVo(condition.getCurrentPage(), condition.getPageSize(), (long) count, list);
        } else {
            // 用户ID条件
            wrapper.or().eq("CREATE_OPERATOR_NO", condition.getUserID().trim());
            wrapper.or().eq("MOD_OPERATOR_NO", condition.getUserID().trim());
            // 分页
            // 获取工具表总数量
            int toolCount = baseMapper.selectCount(wrapper);
            if (toolCount <= 0) {
                return new ToolVo(0, condition.getPageSize(), 0L, null);
            } else {
                // 合起来的总页数
                totalPage = toolCount / condition.getPageSize() + (toolCount % condition.getPageSize() == 0 ? 0 : 1);
                if (condition.getCurrentPage() > totalPage) {
                    condition.setCurrentPage(totalPage);
                }
                // 先获取工具表中数据
                dcPage.setCurrent(condition.getCurrentPage()); // 当前页码数
                dcPage.setSize(condition.getPageSize());    // 页面大小
                dcPage = baseMapper.selectPage(dcPage, wrapper); // 查询结果集
                dcPage.setCurrent(condition.getCurrentPage());
                dcPage.setSize(condition.getPageSize());
                list = dcPage.getRecords(); // 将数据加入list
                for (Tool t : list) {
                    t.setMenuUrl(offlineUrl);
                }
                toolVo = new ToolVo(condition.getCurrentPage(), condition.getPageSize(), (long) toolCount, list);
            }
        }
        return toolVo;
    }

    /**
     * @param path 传入产品系列名，判断该产品系列下是否有产品
     * @return 有，返回true,没有返回false
     */
    @Override
    public boolean isHasThisSeries(String path) {
        QueryWrapper<Tool> wrapper = new QueryWrapper<>();// 查询条件
        wrapper.eq("PRODUCT_SERIES", path);
        List<Tool> list = baseMapper.selectList(wrapper);
        return list.size() != 0;
    }

    @Override
    public boolean isHasThisSeriesOrChildSeries(String path) {
        QueryWrapper<Tool> wrapper = new QueryWrapper<>();
        wrapper.likeRight("PRODUCT_SERIES", path);
        List<Tool> list = baseMapper.selectList(wrapper);
        return list.size() != 0;
    }

    @Override
    public void batchUpdateSeriesNotAll(String oldPath, String newPath) {
        baseMapper.batchUpdateSeriesNotAll(oldPath, newPath);
    }

    @Override
    public boolean insertOne(Tool tool, String userID, List<ToolParam> param) {
        // 设置工具ID
        String toolId = IdUtil.simpleUUID();
        tool.setId(toolId);
        // 设置创建者ID和最后操作者ID
        tool.setCreateNo(userID);
        tool.setModNo(userID);
        if (baseMapper.insert(tool) > 0) {
            // 添加成功，判断是否有配置信息
            if (param != null && param.size() > 0) {
                // 配置序列不为空，且配置条数不为0
                return toolParamService.addParamList(toolId, param).getSuccess();
            } else {
                return true;
            }
        } else {
            return false;
        }

    }

    @Override
    public boolean editById(Tool tool) {
        return baseMapper.updateById(tool) > 0;
    }

    /**
     * 判断是否还有其他工具属于该系列
     *
     * @param oldSeries 系列名
     * @param toolId    除了这个id
     * @return true:有   false:没有
     */
    @Override
    public boolean isHasThisSeriesButThis(String oldSeries, String toolId) {
        QueryWrapper<Tool> wrapper = new QueryWrapper<>();
        wrapper.eq("PRODUCT_SERIES", oldSeries);
        wrapper.ne("TOOL_ID", toolId);
        List<Tool> list = baseMapper.selectList(wrapper);
        return list.size() != 0;
    }

    @Override
    public boolean delById(String toolID) {
        if (this.removeById(toolID)) {
            if (toolParamService.getAllByToolId(toolID).isEmpty()){
                return true;
            } else {
                return toolParamService.delParamByToolId(toolID).getSuccess();
            }
        } else {
            return false;
        }
    }

    @Override
    public void batchUpdateSeries(String oldPath, String newPath) {
        baseMapper.batchUpdateSeries(oldPath, newPath);
    }
}
