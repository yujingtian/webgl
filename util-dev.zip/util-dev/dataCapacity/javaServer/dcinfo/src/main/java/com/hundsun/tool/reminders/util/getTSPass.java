package com.hundsun.tool.reminders.util;

import com.hundsun.tool.reminders.entity.TSPass;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @Author: kcaumber
 * @Date: 2021/11/1 16:48
 */
public class getTSPass {

    public List<TSPass> getRs() {
        String url = "jdbc:oracle:thin:@10.20.23.102:1521:HS2008"; // 链接字符串
        String user = "hs_asset";
        String pwd = "hundsun";
        Connection con = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;

        Date currentDate = new Date();
        SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
        // 日期格式
        String firstDateMonthly = format.format(currentDate).substring(0,6) + "01";

        try {
            con = DriverManager.getConnection(url, user, pwd);
            String sql = "select t.mender_no as 工号,\n" +
                    "       (select t2.operator_name\n" +
                    "          from hs_asset.TsOperators t2\n" +
                    "         where t2.operator_no = t.mender_no) as 姓名,\n" +
                    "       t.sl as 递交数量,\n" +
                    "       t.thsl as 打回修改单数,\n" +
                    "       round((t.sl - t.thsl) / t.sl * 100) as 一次性通过率\n" +
                    "  from (select a.mender_no,\n" +
                    "               count(0) as sl,\n" +
                    "               nvl((select count(0) as thsl\n" +
                    "                     from hs_asset.tssynproinfo b\n" +
                    "                    where b.testdonedate between " + firstDateMonthly + " and\n" +
                    "                          (select to_number(to_char(sysdate, 'YYYYMMDD'))\n" +
                    "                             from dual)\n" +
                    "                      and b.mender_no = a.mender_no\n" +
                    "                      and b.test_backs > 0\n" +
                    "                      and instr('Y,N,用户测试', b.test_result) > 0\n" +
                    "                    group by b.mender_no),\n" +
                    "                   0) as thsl\n" +
                    "          from hs_asset.tssynproinfo a\n" +
                    "         where a.testdonedate between " + firstDateMonthly + " and\n" +
                    "               (select to_number(to_char(sysdate, 'YYYYMMDD')) from dual)\n" +
                    "           and a.mender_no in (select b.employeecode\n" +
                    "                                 from hs_asset.Teammembers b\n" +
                    "                                where (b.teamname = '业务研发一组')\n" +
                    "                                  and b.employeecode not in ('12395')\n" +
                    "                                  )\n" +
                    "           and instr('Y,N,用户测试', a.test_result) > 0\n" +
                    "         group by a.mender_no) t";

            pstm = con.prepareStatement(sql);
            rs = pstm.executeQuery();
            List<TSPass> resList = new ArrayList<TSPass>(rs.getRow());
            while (rs.next()) {
                TSPass sh = new TSPass();
                sh.setOperatorNo(rs.getString("工号"));
                sh.setOperatorName(rs.getString("姓名"));
                sh.setSl(rs.getInt("递交数量"));
                sh.setThsl(rs.getInt("打回修改单数"));
                sh.setPassRate(rs.getInt("一次性通过率"));
                resList.add(sh);
            }
            System.out.println("完成对通过率的计算");
            return resList;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            // 关闭执行通道
            if (pstm != null) {
                try {
                    pstm.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            // 关闭连接通道
            try {
                if (con != null && (!con.isClosed())) {
                    try {
                        con.close();
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return null;
    }
}
