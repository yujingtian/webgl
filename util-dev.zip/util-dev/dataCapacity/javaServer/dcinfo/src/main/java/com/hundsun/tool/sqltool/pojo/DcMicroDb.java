package com.hundsun.tool.sqltool.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 对应微服务数据库信息关联表DCMICRODB
 * @author Star_King
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class DcMicroDb {
    /**
     * 微服务别名
     */
    private String microServerName;
    /**
     * 数据库记录的唯一标识id
     */
    private String dbId;
}
