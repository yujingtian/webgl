package com.hundsun.tool.functest.t3.service.impl;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.hundsun.common.mapper.UserMapper;
import com.hundsun.common.pojo.User;
import com.hundsun.jrescloud.common.util.StringUtils;
import com.hundsun.tool.functest.t3.exception.T3Exception;
import com.hundsun.tool.functest.t3.mapper.TThreeTestMapper;
import com.hundsun.tool.functest.t3.pojo.*;
import com.hundsun.tool.functest.t3.service.TThreeTestService;
import com.hundsun.tool.functest.t3.service.TestNameService;
import com.iceolive.util.StringUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.text.SimpleDateFormat;
import java.util.*;

/**
 * T3功能测试接口
 * @author wenping 2021-07-20 17:30
 */
@Service
public class TThreeTestServiceImpl extends ServiceImpl<TThreeTestMapper, TThreeTest> implements TThreeTestService {
    @Autowired
    private TestNameService testNameService;

    @Autowired
    private UserMapper userMapper;

    /**
     * 根据测试用例名和用户ID查询出所有跟当前用户同一组的所有用户的跟当前测试用例名相同的测试用例
     * @param testName 测试用例名
     * @return
     * @throws T3Exception
     */
    @Override
    public TThreeVO showTestDetails(String testName) throws T3Exception {
        // 根据测试用例名查询出测试用例[ID, 测试用例名，别名, shardingInfo, security]
        TestName test = testNameService.selectByTestName(testName);
        if (test == null) {
            throw new T3Exception(testName + "不存在");
        }
        List<TThreeTest> tThreeTests = baseMapper.selectByTestID(test.getID());
        TThreeVO tThreeVO = new TThreeVO();
        tThreeVO.setTestName(test.getTestName());
        tThreeVO.setGroupAlias(test.getGroupAlias());
        tThreeVO.setUserID(test.getUserID());
        if (StringUtil.isEmpty(test.getShardingInfo())){
            tThreeVO.setShardingInfo("");
        } else {
            tThreeVO.setShardingInfo(test.getShardingInfo());
        }
        if (StringUtil.isEmpty(test.getSecurity())){
            tThreeVO.setSecurity("");
        } else {
            tThreeVO.setSecurity(test.getSecurity());
        }
        System.out.println("test.getTestServer(): + " + test.getTestServer() );
        if (StringUtils.isEmpty(test.getTestServer())) {
            tThreeVO.setTestServer("");
        } else {
            tThreeVO.setTestServer(test.getTestServer());
        }
        tThreeVO.setTThreeTestList(tThreeTests);
        return tThreeVO;
    }

    /**
     * 批量插入数据
     * @param testName 测试用例[名和别名]
     * @param data 从前端接收的json字符串组
     * @return
     * @throws T3Exception
     */
    @Override
    @Transactional(rollbackFor = Exception.class, timeout = 1000)
    public int save(TestName testName, JSONArray data) throws T3Exception {
        int i = 0;
        try{
            int delete = delete(testName.getTestName(), testName.getUserID());
        } catch (Exception e) {
            e.printStackTrace();
            if (e.getMessage().equals("No Permission!")) {
                throw new T3Exception("测试用例名已存在，请更改！");
            }
        }
        // 首先插入到DCTESTNAME中记录[测试用例ID，测试用例名，别名]
        // 获取当前表中最大的ID，并加1作为当前记录的ID
        int maxID = testNameService.selectMaxID() == null ? 0 : testNameService.selectMaxID();
        testName.setID(maxID+1);
        java.util.Date date = new java.util.Date(System.currentTimeMillis());
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        String format = sdf.format(date);
        testName.setModTime(format);
        try {
            testNameService.insert(testName);
        } catch (Exception e) {
            e.printStackTrace();
            throw new T3Exception("出错啦，管理员正在处理，请稍后再试！");
        }
        try {
            for (; i < data.size(); i++) {
                TThreeTest tThree = new TThreeTest();
                tThree.setTestID(testName.getID());
                JSONObject jo = (JSONObject) data.get(i);
                String serviceName = jo.getString("serviceName");
                if (StringUtils.isEmpty(serviceName)) {
                    throw new T3Exception("服务名不能为空");
                }
                tThree.setServiceName(serviceName);

                String funcNumStr = jo.getString("funcNumStr");
                if (StringUtils.isEmpty(funcNumStr)) {
                    throw new T3Exception("功能号不能为空");
                }
                tThree.setFuncNumStr(funcNumStr);

                JSONObject parameter = jo.getJSONObject("parameter");
                if (parameter != null) {
                    tThree.setParameter(getString(parameter.entrySet()));
                } else {
                    tThree.setParameter("");
                }
                tThree.setOrd(i + 1);
                try{
                    baseMapper.insert(tThree);
                } catch (Exception e) {
                    e.printStackTrace();
                    throw new T3Exception("出错啦，管理员正在处理，请稍后再试！");
                }
            }
        }catch (JSONException e) {
            throw new T3Exception("请检查输入的json字符串是否有误！");
        }
        return i == data.size() ? i : 0;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public int delete(String testName, String userID) throws T3Exception {
        int row = 0;
        User user = userMapper.selectByOperatorNo(userID);
        if (user == null) {
            throw new T3Exception(userID + "不存在！请先注册");
        }
        TestName deleteTestName = testNameService.delete(testName, userID);
        if (deleteTestName == null) {
            return 0;
        }
        row = baseMapper.delete(deleteTestName.getID());
        return row;
    }

    @Override
    public int verify(String testName, String userID) throws T3Exception {
        User user = userMapper.selectByOperatorNo(userID);
        if (user == null) {
            throw new T3Exception(userID + "不存在！请先注册");
        }
        TestName selectTestName = testNameService.selectByTestName(testName);
        if (selectTestName != null){
            return 0;
        } else {
            return 1;
        }
    }

    /**
     * 将参数的json转换成key1:value1,key2:value2,...的字符串形式保存到中
     * @param entrySet 参数的json map格式
     * @return
     */
    @Override
    public String getString(Set<Map.Entry<String, Object>> entrySet) {
        if (entrySet == null) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        int i = 0;
        for (Map.Entry<String, Object> entry : entrySet) {
            if (i != 0) {
                sb.append(",");
            }
            sb.append(entry.getKey()).append(":").append(entry.getValue());
            i++;
        }
        return sb.toString();
    }


}
