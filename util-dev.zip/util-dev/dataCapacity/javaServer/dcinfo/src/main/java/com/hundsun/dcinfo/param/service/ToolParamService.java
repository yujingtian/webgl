package com.hundsun.dcinfo.param.service;

import com.hundsun.dcinfo.param.entity.ParamList;
import com.hundsun.dcinfo.param.entity.ToolParam;
import com.baomidou.mybatisplus.extension.service.IService;
import com.hundsun.dcinfo.util.Result;

import java.util.List;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author Wanglei
 * @since 2021-08-05
 */
public interface ToolParamService extends IService<ToolParam> {
    public Result addParamList(String toolId, List<ToolParam> list);

    public Result delParamByToolId(String toolId);

    public Result editParam(ParamList data);

    public Result generateJson(String toolId);

    public Result delMore(List<ToolParam> list);

    public List<ToolParam> getAllByToolId(String toolId);
}
