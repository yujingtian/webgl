package com.hundsun.tool.encrypt.utils;

import com.hundsun.t3sdk.impl.client.T3Services;

import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

/**
 * @author Star_King
 */
public class TimedThread implements Runnable {
    private int index;

    private static int activeTime;

    public void setIndex(int index) {
        this.index = index;
    }

    public static void setActiveTime(int activeTime) {
        TimedThread.activeTime = activeTime;
    }

    @Override
    public void run() {
        int count = 0;
        T3Services server = T3ServicesUtil.getServer(index);
        if (server == null) {
            return;
        }
        while (server != null) {
            while (true) {
                Set<String> clientNames1 = server.getAllClientNames();
                try {
                    TimeUnit.MINUTES.sleep(1);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                Set<String> clientNames2 = server.getAllClientNames();
                if (!equals(clientNames1, clientNames2)) {
                    count = 0;
                } else {
                    count++;
                }
                if (count >= activeTime) {
                    server = null;
                    T3ServicesUtil.removeServer(index);
                    break;
                }
            }
        }
        Logger.getLogger("com.hundsun.tool.encrypt.utils").info("服务池被回收！");
    }

    public static boolean equals(Set<String> set1, Set<String> set2){
        if(set1 == null || set2 ==null){
            return false;
        }
        if(set1.size()!=set2.size()){
            return false;
        }
        return set1.containsAll(set2);
    }
}
