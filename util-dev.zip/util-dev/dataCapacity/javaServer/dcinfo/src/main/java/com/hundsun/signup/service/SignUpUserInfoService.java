package com.hundsun.signup.service;

import com.alibaba.fastjson.JSONObject;
import com.hundsun.signup.exception.SignUpException;
import com.hundsun.signup.pojo.SignUpUserInfo;
import com.hundsun.signup.pojo.SignUpVO;

import java.util.List;

/**
 * @author wenping 2021-07-30 14:13
 */
public interface SignUpUserInfoService {
    JSONObject process(String jsonStr) throws SignUpException;

    boolean isExist(String userID);

    int receiveHandle(List<Object> userIDList) throws SignUpException;

    int updateState(String userID) throws SignUpException;

    JSONObject showUsers(String userID, int curPage, int pageSize) throws SignUpException;

    int reject(List<Object> userIDList) throws SignUpException;

}
