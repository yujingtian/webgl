def getCType(sFiledName: str):
    sFiledDocType = None
    if sFiledName in ['op_remark', 'en_bank_no']:
        sFiledDocType = 'C2000'
    elif sFiledName in [
            'op_station', 'arch_image_group_name', 'prodcash_ctrlstr'
    ]:
        sFiledDocType = 'C255'
    elif sFiledName in ['full_name']:
        sFiledDocType = 'C180'
    elif sFiledName in [
            'op_password', 'function_str', 'menu_code', 'cancel_serialno'
    ]:
        sFiledDocType = 'C64'
    elif sFiledName in ['id_no']:
        sFiledDocType = 'C40'
    elif sFiledName in ['contract_id']:
        sFiledDocType = 'C36'
    elif sFiledName in ['prod_code', 'trans_account']:
        sFiledDocType = 'C32'
    elif sFiledName in ['prodta_no', 'allot_no']:
        sFiledDocType = 'C24'
    elif sFiledName in ['HsStockAccount']:
        sFiledDocType = 'C20'
    elif sFiledName in [
            'operator_no', 'arch_image_group_id', 'client_id',
            'fund_account_src', 'prod_account', 'fund_account'
    ]:
        sFiledDocType = 'C18'
    elif sFiledName in ['other_agency', 'other_netno']:
        sFiledDocType = 'C10'
    elif sFiledName in ['stock_code']:
        sFiledDocType = 'C8'
    elif sFiledName in ['HsExchangeType', 'city_no']:
        sFiledDocType = 'C4'
    elif sFiledName in ['money_type']:
        sFiledDocType = 'C3'
    elif sFiledName in [
            'user_type', 'op_entrust_way', 'prod_cash_mode', 'organ_flag',
            'id_kind'
    ]:
        sFiledDocType = 'C1'
    elif sFiledName in [
            'serial_no', 'per_day_total_quota', 'organ_day_total_quota',
            'day_total_quota', 'day_used_quota', 'organ_min_balance',
            'per_min_balance', 'balance_unit', 'refund_balance', 'serial_no2',
            'entrust_balance', 'entrust_amount'
    ]:
        sFiledDocType = 'N10'
    elif sFiledName in [
            'op_branch_no', 'company_no', 'branch_no', 'start_contract_no',
            'stop_contract_no', 'current_contract_no', 'day_limit_times',
            'init_date', 'begin_time', 'end_time', 'corp_risk_level'
    ]:
        sFiledDocType = 'N8'
    elif sFiledName in ['HsRate']:
        sFiledDocType = 'N1'
    elif sFiledName in [
            'HsNumID', 'HsDate', 'HsTime', 'HsClientGroup', 'HsQuantity',
            'HsFutuCodeType', 'HsNum'
    ]:
        sFiledDocType = 'N8'
    elif sFiledName in [
            'HsAmount', 'HsFunctionID', 'HsFunctionNo', 'HsHighPrice2',
            'HsHighPrice', 'HsSerialNo'
    ]:
        sFiledDocType = 'N10'
    elif sFiledName in ['HsType', 'HsFlag', 'HsStatus']:
        sFiledDocType = 'C1'
    elif sFiledName in ['HsMoneyType', 'HsType', 'HsFlag']:
        sFiledDocType = 'C3'
    elif sFiledName in [
            'HsExchangeType', 'HsOtcType', 'HsStockType', 'HsMchType'
    ]:
        sFiledDocType = 'C4'
    elif sFiledName in ['HsBankID']:
        sFiledDocType = 'C6'
    elif sFiledName in ['HsOptCode', 'HsStockCode']:
        sFiledDocType = 'C8'
    elif sFiledName in ['HsBondCode']:
        sFiledDocType = 'C12'
    elif sFiledName in ['HsBondAccount', 'HsClientID', 'HsFundAccount']:
        sFiledDocType = 'C18'
    elif sFiledName in ['HsBankSerialID', 'HsDateTime', 'HsStockAccount']:
        sFiledDocType = 'C20'
    elif sFiledName in ['HsBankClientID']:
        sFiledDocType = 'C22'
    elif sFiledName in [
            'HsBankAccount', 'HsCardID', 'HsFundstkAccount', 'HsOptName',
            'HsOtcAccount', 'HsOtcCode', 'HsOtcName', 'HsSchemeCode',
            'HsSdcAccount', 'HsSdcCode', 'HsSdcName', 'HsStockName',
            'HsIDENTITY', 'HsMchAccount', 'HsMchCode', 'HsPhone'
    ]:
        sFiledDocType = 'C32'
    elif sFiledName in ['HsIDNo']:
        sFiledDocType = 'C40'
    elif sFiledName in ['HsName']:
        sFiledDocType = 'C60'
    elif sFiledName in ['HsName2']:
        sFiledDocType = 'C64'
    elif sFiledName in ['HsName5']:
        sFiledDocType = 'C90'
    elif sFiledName in ['HsName3', 'HsAddress']:
        sFiledDocType = 'C120'
    elif sFiledName in ['HsName4', 'HsAddress1']:
        sFiledDocType = 'C180'
    elif sFiledName in ['HsStation']:
        sFiledDocType = 'C255'
    elif sFiledName in ['HsJson']:
        sFiledDocType = 'C4000'
    elif 'HsChar' in sFiledName:
        sFiledDocType = 'C' + sFiledName.replace('HsChar', '').replace(
            'List', '')

    return sFiledDocType


if __name__ == "__main__":
    print(getCType('op_password'))