# 从hep上采集数据
import requests
import time
import json
import tools
import hsDataType
from bs4 import BeautifulSoup
from selenium import webdriver


# 获取driver的session
def getSession():
    global rRequests
    rRequests = requests.Session()
    rRequests.headers.clear()
    for cookie in driver.get_cookies():
        rRequests.cookies.set(cookie['name'], cookie['value'])


def Login(sUserID: str, sPwd: str):
    global driver
    driver = webdriver.Chrome()
    driver.get('http://hep.hundsun.com/login.htm')
    time.sleep(2)
    button = driver.find_element_by_id('doaminLogin')
    button.click()
    time.sleep(1)
    # 输入用户名
    username = driver.find_element_by_id('username')
    username.send_keys(sUserID)
    # 输入密码
    password = driver.find_element_by_name('password')
    password.send_keys(sPwd)
    time.sleep(1)
    button = driver.find_element_by_class_name('btn-submit')
    button.click()
    time.sleep(1)


# 获取接口列表信息
def getIntefaceList(html: str):
    sIntefaceList = []
    bs = BeautifulSoup(html, 'html.parser')
    scriptList = bs.find_all('script')
    for scriptItem in scriptList:
        if '<script type="text/javascript">' in str(
                scriptItem) and 'var interfaceList =' in str(scriptItem):
            sIntefaceHtml = str(
                scriptItem)[str(scriptItem).find('var interfaceList = ') +
                            len('var interfaceList = '):]
            sIntefaceHtml = sIntefaceHtml[:sIntefaceHtml.find('var ')]
            sIntefaceHtml = sIntefaceHtml.strip()[:-1]
            vIntefaceList = json.loads(sIntefaceHtml)
            for vIntefaceMap in vIntefaceList:
                sFunction = vIntefaceMap['interface_objectId_origin']
                sFunctionName = vIntefaceMap['interface_name_zh']
                sInterfaceId = vIntefaceMap['id']
                sCategoryId = vIntefaceMap['interface_out_category_id']
                sBelongId = vIntefaceMap['belong_id']

                yzItem = {}
                yzItem['function'] = sFunction
                yzItem['functionName'] = sFunctionName
                yzItem['interfaceId'] = sInterfaceId
                yzItem['categoryId'] = sCategoryId
                yzItem['belongId'] = sBelongId
                sIntefaceList.append(yzItem)
    print(len(sIntefaceList))
    svrInteFaceList = readIntefaceInfo(sIntefaceList)
    tools.SaveDict(svrInteFaceList, 'hepInteface')


# 根据列表信息获取明细接口信息
def readIntefaceInfo(sIntefaceList: list):
    sResultList = {}
    # sResultList = tools.LoadDict('hepInteface')
    iLoop = 0
    for sIntefaceItem in sIntefaceList:
        iLoop = iLoop + 1
        yzItem = {}
        sInterfaceId = sIntefaceItem['interfaceId']
        sCategoryId = sIntefaceItem['categoryId']
        sBelongId = sIntefaceItem['belongId']

        yzItem['function'] = sIntefaceItem['function']
        yzItem['functionName'] = sIntefaceItem['functionName']

        sUrl = 'http://hep.hundsun.com/interface/interface_view.htm'
        paramsMap = {}
        paramsMap['belong_id'] = sBelongId
        paramsMap['interface_id'] = sInterfaceId
        paramsMap['category_id'] = sCategoryId
        res = rRequests.get(url=sUrl, params=paramsMap)
        if res.status_code == 200:
            res.encoding = 'utf-8'
            html = res.text
            yzItem = readIntefaceInfoForHtml(html, yzItem)
            yzItem['interface_id'] = sInterfaceId
            svrName = str(yzItem['svrName'])
            sResultList['hsbroker.' + svrName + '/v/' +
                        yzItem['function']] = yzItem
        print(iLoop)
        if iLoop % 500 == 0:
            tools.SaveDict(sResultList, 'hepInteface')

    return sResultList


def readIntefaceInfoForHtml(sHtml: str, itemMap: map):
    bs = BeautifulSoup(sHtml, 'html.parser')
    # 提取微服务
    tbodyList = bs.find_all('tbody')
    for tbody in tbodyList:
        trList = tbody.find_all('tr')
        if len(trList) > 5:
            trItem = trList[4]
            tdList = trItem.find_all('td')
            svrName = tdList[0].text
            itemMap['svrName'] = svrName

    # 提取入参和出参
    scriptList = bs.find_all('script')
    for scriptItem in scriptList:
        if '<script type="text/javascript">' in str(
                scriptItem) and 'var inList =' in str(scriptItem):
            sInListHtml = str(
                scriptItem)[str(scriptItem).find('var inList =') +
                            len('var inList ='):]
            sInListHtml = sInListHtml[:sInListHtml.find('var ')]
            sOutListHtml = str(
                scriptItem)[str(scriptItem).find('var outList =') +
                            len('var outList ='):]
            sOutListHtml = sOutListHtml[:sOutListHtml.find('var ')]
            sInList = json.loads(sInListHtml)
            sOutList = json.loads(sOutListHtml)

    yzInList = []
    for inItem in sInList:
        if 'parent_name' in inItem:
            continue
        sFiledName = inItem['param_name_en']
        if 'doc_type' not in inItem:
            sFiledDocType = hsDataType.getCType(sFiledName)
            if sFiledDocType == None:
                sFiledDocType = ''
                print(sFiledName)
        else:
            sFiledDocType = inItem['doc_type']
        if 'dict_entry' in inItem:
            if inItem['dict_entry'] == None or inItem['dict_entry'] == 'null':
                sDictEntry = ''
            else:
                sDictEntry = inItem['dict_entry']
        else:
            sDictEntry = ''
        sFiledCName = inItem['param_name_zh']

        yzInItem = {}
        yzInItem['filedName'] = sFiledName
        yzInItem['filedDocType'] = sFiledDocType
        yzInItem['dictEntry'] = sDictEntry
        yzInItem['filedCName'] = sFiledCName
        yzInList.append(yzInItem)
    itemMap['inFiled'] = yzInList

    yzOutList = []
    for outItem in sOutList:
        if 'parent_name' in outItem:
            continue
        sFiledName = outItem['param_name_en']
        if 'doc_type' not in outItem:
            sFiledDocType = hsDataType.getCType(sFiledName)
            if sFiledDocType == None:
                sFiledDocType = ''
                print(sFiledName)
        else:
            sFiledDocType = outItem['doc_type']
        if sFiledName == 'rows' or 'dict_id' not in outItem:
            sDictEntry = ''
        elif outItem['dict_id'] == None or outItem['dict_id'] == 'null':
            sDictEntry = ''
        else:
            sDictEntry = outItem['dict_id']
        sFiledCName = outItem['param_name_zh']

        yzOutItem = {}
        yzOutItem['filedName'] = sFiledName
        yzOutItem['filedDocType'] = sFiledDocType
        yzOutItem['dictEntry'] = sDictEntry
        yzOutItem['filedCName'] = sFiledCName
        yzOutList.append(yzOutItem)
    itemMap['outFiled'] = yzOutList

    return itemMap


def doWork():
    print('开始工作了')
    Login(sUserID='zhoupeng12447', sPwd='Zhoupeng03')
    getSession()
    driver.close()
    res = rRequests.get(
        url=
        'http://hep.hundsun.com/interface/interface_view_index.htm?belong_id=T20150180'
    )
    if res.status_code == 200:
        res.encoding = 'utf-8'
        html = res.text
        getIntefaceList(html)


if __name__ == "__main__":
    doWork()
    # with open('D:/2.txt', 'r', encoding='utf-8') as rFile:
    #     sHtml = rFile.read()
    # yzItem = {}
    # yzItem['function'] = 'getCrdtblacklistQuery'
    # yzItem['functionName'] = '融资融券黑名单查询'
    # print(readIntefaceInfoForHtml(sHtml, yzItem))
