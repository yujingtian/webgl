# 本文件用来从HEP对应的数据库中提取标准字段的信息更新到stdTypeInfo.json
import tools
from mysqlTools import GetDB, CloseDB, SelectDB
from getConfig import GetConfig

if __name__ == "__main__":
    stdTypeInfo = {}
    sUser = GetConfig('hep_sql','sUser')
    sPwd = GetConfig('hep_sql','sPwd')
    sIP = GetConfig('hep_sql','sIP')
    sPortStr = GetConfig('hep_sql','sPort')
    sPort = 0
    for i in sPortStr:
        sPort = sPort * 10 + (ord(i) - ord('0'))
    sSerName = GetConfig('hep_sql','sSerName')
    GetDB(sUser,sPwd,sIP,sPort,sSerName)
    sStrOne = SelectDB(
        "select a.type_name,a.data_length from hep_c_business_data_type_dept_tbl a where a.standard_data_type in ('STDstr','String') and a.dept='hsbroker'"
    )
    sCharOne = SelectDB(
        "select a.type_name,a.data_length from hep_c_business_data_type_dept_tbl a where a.standard_data_type='STDsinglechar' and a.dept='hsbroker'"
    )
    CloseDB()

    for item in sStrOne:
        stdTypeInfo[item['type_name']] = 'C' + item['data_length']
    for item in sCharOne:
        stdTypeInfo[item['type_name']] = 'C1'

    print(stdTypeInfo)

    tools.SaveDict(stdTypeInfo, 'stdTypeInfo')
