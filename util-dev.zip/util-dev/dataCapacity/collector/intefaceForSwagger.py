# 本文件用来支持从swagger获取接口信息
import requests
import time
import json
import tools
from selenium import webdriver


# 获取driver的session
def getSession():
    global rRequests
    rRequests = requests.Session()
    rRequests.headers.clear()
    for cookie in driver.get_cookies():
        rRequests.cookies.set(cookie['name'], cookie['value'])


def LoGin(sUserID='zhoupeng12447', sPwd='Zhoupeng03'):
    global driver
    driver = webdriver.Chrome()
    driver.get('http://10.20.23.124:8888/v2/api-docs')
    time.sleep(1)
    # 输入用户名
    username = driver.find_element_by_id('username')
    username.send_keys(sUserID)
    # 输入密码
    password = driver.find_element_by_name('password')
    password.send_keys(sPwd)
    time.sleep(1)
    button = driver.find_element_by_id('submitBtn')
    button.click()
    time.sleep(1)


def doWork():
    print('开始工作了')
    LoGin(sUserID='admin', sPwd='hundsun0A!')
    getSession()
    driver.close()
    res = rRequests.get(url='http://10.20.23.124:8888/v2/api-docs')
    json_response = res.content.decode()
    dict_json = json.loads(json_response)
    return GetInterfaceDict(dict_json)


# 返回接口列表
def GetInterfaceDict(dict_json: dict):
    sResultDict = {}
    definitionList = dict_json['definitions']
    definitionMap = {}
    for sDefinitionName in definitionList:
        if 'properties' not in definitionList[sDefinitionName]:
            yzItemList = {
                'Map': {
                    'filedName': sDefinitionName,
                    'filedCName': '',
                    'filedDocType': sDefinitionName,
                    'dictEntry': '0'
                }
            }
        else:
            propertiesList = definitionList[sDefinitionName]['properties']
            yzItemList = {}
            for sFiledName in propertiesList:
                if 'type' in propertiesList[sFiledName]:
                    sFiledType = propertiesList[sFiledName]['type']
                else:
                    sRef = propertiesList[sFiledName]['$ref']
                    sFiledType = '@ ' + sRef[sRef.find('/definitions/') +
                                             len('/definitions/'):]

                if 'description' in propertiesList[sFiledName]:
                    sFiledDesc = propertiesList[sFiledName]['description']
                else:
                    sFiledDesc = ''

                if sFiledType == 'string':
                    sFiledType = 'C10'
                elif sFiledType == 'integer':
                    sFiledType = 'N4'
                else:
                    print(sFiledType)
                yzItemList[sFiledName] = {
                    'filedName': sFiledName,
                    'filedCName': sFiledDesc,
                    'filedDocType': sFiledType,
                    'dictEntry': '0'
                }

        definitionMap[sDefinitionName] = yzItemList

    pathsList = dict_json['paths']
    for pathInfo in pathsList:
        if pathInfo == '/error' or pathInfo[:
                                            7] == '/health' or pathInfo == '/svr-healthy/checkUser':
            continue
        itemMap = {}
        sFunction = pathInfo
        yzInList = []
        yzOutList = []

        for sRequestType in pathsList[pathInfo]:
            break

        # 处理入参
        if 'parameters' in pathsList[pathInfo][sRequestType]:

            if 'schema' not in pathsList[pathInfo][sRequestType]['parameters'][
                    0]:
                for sParametersList in pathsList[pathInfo][sRequestType][
                        'parameters']:
                    sFiledName = sParametersList['name']
                    sFiledDocType = sParametersList['type']
                    sFiledCName = ''
                    sDictEntry = '0'

                    if sFiledDocType == 'string':
                        sFiledDocType = 'C10'
                    elif sFiledDocType == 'integer':
                        sFiledDocType = 'N4'
                    else:
                        print(sFiledDocType)

                    yzInItem = {}
                    yzInItem['filedName'] = sFiledName
                    yzInItem['filedDocType'] = sFiledDocType
                    yzInItem['dictEntry'] = sDictEntry
                    yzInItem['filedCName'] = sFiledCName
                    yzInList.append(yzInItem)
            else:
                for item in pathsList[pathInfo][sRequestType]['parameters']:
                    if '$ref' not in item['schema']:
                        sFiledDocType = item['schema']['type']
                        if sFiledDocType == 'string':
                            sFiledDocType = 'C10'
                        elif sFiledDocType == 'integer':
                            sFiledDocType = 'N4'
                        else:
                            print(sFiledDocType)
                        sFiledName = item['name']
                        sFiledCName = item['description']
                        sDictEntry = '0'
                        yzInItem = {}
                        yzInItem['filedName'] = sFiledName
                        yzInItem['filedDocType'] = sFiledDocType
                        yzInItem['dictEntry'] = sDictEntry
                        yzInItem['filedCName'] = sFiledCName
                        yzInList.append(yzInItem)
                    else:
                        sInRef = str(item['schema']['$ref'])

                        sDefinitionName = sInRef[sInRef.find('/definitions/') +
                                                 len('/definitions/'):]

                        definitionItemList = definitionMap[sDefinitionName]
                        for definitionItem in definitionItemList:
                            sFiledName = definitionItemList[definitionItem][
                                'filedName']
                            sFiledDocType = definitionItemList[definitionItem][
                                'filedDocType']
                            sFiledCName = definitionItemList[definitionItem][
                                'filedCName']
                            sDictEntry = definitionItemList[definitionItem][
                                'dictEntry']

                            if sFiledDocType == 'string':
                                sFiledDocType = 'C10'
                            elif sFiledDocType == 'integer':
                                sFiledDocType = 'N4'
                            else:
                                print(sFiledDocType)

                            yzInItem = {}
                            yzInItem['filedName'] = sFiledName
                            yzInItem['filedDocType'] = sFiledDocType
                            yzInItem['dictEntry'] = sDictEntry
                            yzInItem['filedCName'] = sFiledCName
                            yzInList.append(yzInItem)

        # 处理出参
        if 'responses' in pathsList[pathInfo][sRequestType]:
            if 'schema' not in pathsList[pathInfo][sRequestType]['responses'][
                    '200']:
                sFiledName = pathsList[pathInfo][sRequestType]['parameters'][
                    0]['name']
                sFiledDocType = pathsList[pathInfo][sRequestType][
                    'parameters'][0]['type']
                sFiledCName = ''
                sDictEntry = '0'

                if sFiledDocType == 'string':
                    sFiledDocType = 'C10'
                elif sFiledDocType == 'integer':
                    sFiledDocType = 'N4'
                else:
                    print(sFiledDocType)

                yzOutItem = {}
                yzOutItem['filedName'] = sFiledName
                yzOutItem['filedDocType'] = sFiledDocType
                yzOutItem['dictEntry'] = sDictEntry
                yzOutItem['filedCName'] = sFiledCName
                yzOutList.append(yzOutItem)
            else:
                if '$ref' not in pathsList[pathInfo][sRequestType][
                        'responses']['200']['schema']:
                    sFiledName = pathsList[pathInfo][sRequestType][
                        'parameters'][0]['name']
                    sFiledDocType = pathsList[pathInfo][sRequestType][
                        'parameters'][0]['schema']['type']
                    sFiledCName = pathsList[pathInfo][sRequestType][
                        'parameters'][0]['description']
                    sDictEntry = '0'

                    if sFiledDocType == 'string':
                        sFiledDocType = 'C10'
                    elif sFiledDocType == 'integer':
                        sFiledDocType = 'N4'
                    else:
                        print(sFiledDocType)

                    yzOutItem = {}
                    yzOutItem['filedName'] = sFiledName
                    yzOutItem['filedDocType'] = sFiledDocType
                    yzOutItem['dictEntry'] = sDictEntry
                    yzOutItem['filedCName'] = sFiledCName
                    yzOutList.append(yzOutItem)
                else:
                    sOutRef = str(pathsList[pathInfo][sRequestType]
                                  ['responses']['200']['schema']['$ref'])
                    sDefinitionName = sOutRef[sInRef.find('/definitions/') +
                                              len('/definitions/'):]
                    definitionItemList = definitionMap[sDefinitionName]
                    for definitionItem in definitionItemList:
                        sFiledName = definitionItemList[definitionItem][
                            'filedName']
                        sFiledDocType = definitionItemList[definitionItem][
                            'filedDocType']
                        sFiledCName = definitionItemList[definitionItem][
                            'filedCName']
                        sDictEntry = definitionItemList[definitionItem][
                            'dictEntry']

                        if sFiledDocType == 'string':
                            sFiledDocType = 'C10'
                        elif sFiledDocType == 'integer':
                            sFiledDocType = 'N4'
                        else:
                            print(sFiledDocType)

                        yzOutItem = {}
                        yzOutItem['filedName'] = sFiledName
                        yzOutItem['filedDocType'] = sFiledDocType
                        yzOutItem['dictEntry'] = sDictEntry
                        yzOutItem['filedCName'] = sFiledCName
                        yzOutList.append(yzOutItem)

        itemMap['function'] = sFunction
        itemMap['inFiled'] = yzInList
        itemMap['outFiled'] = yzOutList
        itemMap['REQUEST_METHOD'] = sRequestType
        sResultDict[sFunction] = itemMap

    tools.SaveDict(sResultDict, 'swaggerInteface')


if __name__ == "__main__":
    doWork()
