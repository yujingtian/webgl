import requests
import time
from selenium import webdriver
from selenium.webdriver.chrome.options import Options


def getSession():
    global rRequests
    rRequests = requests.Session()
    rRequests.headers.clear()
    for cookie in driver.get_cookies():
        rRequests.cookies.set(cookie['name'], cookie['value'])


def Login(sUserID: str, sPwd: str):
    global driver
    chrome_options = Options()
    chrome_options.add_argument("--headless")
    driver = webdriver.Chrome(chrome_options=chrome_options)
    # driver = webdriver.Chrome()
    driver.get('http://10.20.144.78:8081')

    time.sleep(1)
    # 输入用户名
    username = driver.find_element_by_id('username')
    username.send_keys(sUserID)
    # 输入密码
    password = driver.find_element_by_name('password')
    password.send_keys(sPwd)
    time.sleep(1)
    button = driver.find_element_by_name('submit')
    button.click()
    time.sleep(1)


if __name__ == "__main__":
    Login('hebt36526', '1')
    getSession()
    driver.close()
    sData = {"pageNo": 1, "pageSize": 100}
    print(rRequests.headers)
    res = rRequests.post(
        url=
        'http://10.20.144.78:8081/acm/dssp/application/authority/query.json',
        data=sData,
        headers={
            "Authorization":
            "Bearer eyJhbGciOiJIUzUxMiJ9.eyJqdGkiOiI0Y2U5NjlkZjYyMzI0MTM5YWEyOGFiNzRiZTAyZTZlMCIsInN1YiI6ImhlYnQzNjUyNiIsImlhdCI6MTYzMDU2OTI4MywiZXhwIjoxNjMxNTE1MzYzfQ.QydLxW62cwEaYtsOWgHBZKSyn0jsJ85lmoj0IeiK-v0tJTkS3YPDJ_pdpjOq327rSOmdUbvfXo5mkS_6j_VK4w"
        })
    if res.status_code == 200:
        res.encoding = 'utf-8'
        html = res.text
        print(html)