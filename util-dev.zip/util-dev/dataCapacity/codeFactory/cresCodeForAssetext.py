# 本文件用来生成cres版的存管外部接口
import getConfig
import tools
import readStdfield
import datetime
import os

baseFiledToCSDCMap = {
    'csdc_report_no': 'YWLSH',
    'csdc_busi_kind': 'YWLB',
    'csdc_openorgan_code': 'KHJGDM',
    'csdc_opennet_code': 'KHWDDM',
    'report_date': 'SQRQ',
    'csdc_reserve1': 'BYZD1',
    'csdc_reserve2': 'BYZD2',
    'csdc_reserve3': 'BYZD3'
}

baseImportList = [
    'csdc_report_no', 'init_date', 'op_branch_no', 'operator_no', 'user_type',
    'op_password', 'op_station', 'op_entrust_way', 'menu_id', 'function_id',
    'branch_no', 'audit_action', 'client_id', 'fund_account', 'curr_date',
    'curr_time'
]


# 获取LF的最大功能号
def GetMaxLfFunctionNo(vDir: str):
    global returnObjectId
    sDir = sZhSoCode + vDir
    if returnObjectId == 0:
        for root, dirs, files in os.walk(sDir):
            for fileName in files:
                sFilePath = root + '/' + fileName
                sFilePath = sFilePath.replace('\\', '/').replace('//', '/')
                if '.function_design' in fileName:
                    sText, sEncoding = tools.LoadSrcCode(sFilePath)
                    for sLine in sText:
                        if '<basic objectId="' in sLine:
                            sObjectId = sLine[sLine.find('<basic objectId="') +
                                              len('<basic objectId="'):]
                            sObjectId = sObjectId[:sObjectId.find('"')]
                            iObjectId = int(sObjectId)
                            if iObjectId > returnObjectId:
                                returnObjectId = iObjectId
                            break
    returnObjectId = returnObjectId + 1
    return str(returnObjectId)


# 处理接口业务逻辑代码
def CreateLsInteface(IntefaceInfo, sOutPath, sEncoding, vIntefaceName,
                     sHSStdfieldMap):

    # 重新清洗接口用到的字段信息
    sFiledInfoMap = {}
    sFiledInfoList = IntefaceInfo['hsStdFiledInfo']['filedInfoList']
    sCsdcEntrustType = str(IntefaceInfo['CsdcEntrustType'])
    for sFiledName in sFiledInfoList:
        sFiledInfo = sFiledInfoList[sFiledName]
        sFiledCName = ''
        if 'name' not in sFiledInfo:
            sFiledCName = sHSStdfieldMap[sFiledName]['cname']
        else:
            sFiledCName = sFiledInfo['name']

        sDictNo = ''
        if 'dict' not in sFiledInfo:
            if sFiledName in sHSStdfieldMap:
                sDictNo = sHSStdfieldMap[sFiledName]['dict']
            else:
                sDictNo = ''

        yzItem = {'name': sFiledCName}
        if 'dict' in sFiledInfo:
            yzItem['dict'] = sFiledInfo['dict']
        if sDictNo.strip() != '':
            yzItem['dictNo'] = sDictNo

        sFiledInfoMap[sFiledName] = yzItem

    sLsFunctionList = IntefaceInfo['LsFunction']

    for sLsFunction in sLsFunctionList:
        tIntefaceName = vIntefaceName
        if 'name' in sLsFunctionList[sLsFunction]:
            tIntefaceName = sLsFunctionList[sLsFunction]['name']
        sBindValue = {}
        for sBindFiledName in sLsFunctionList[sLsFunction]:
            if sBindFiledName == 'name' or sBindFiledName == 'abbName' or sBindFiledName == 'CsdcEntrustType':
                continue
            sBindValue[sBindFiledName] = sLsFunctionList[sLsFunction][
                sBindFiledName]
        sFileName = 'LS_统一账户_' + tIntefaceName
        print('处理' + sFileName)

        sAbbName = tools.GetInteFaceAbbName(tIntefaceName)
        if 'abbName' in sLsFunctionList[sLsFunction]:
            sAbbName = sLsFunctionList[sLsFunction]['abbName']

        yzItem = {
            'objectId': sLsFunction,
            'AbbName': sAbbName,
            'vIntefaceName': tIntefaceName,
            'module_id': IntefaceInfo['module_id'],
            'time_kind': IntefaceInfo['time_kind']
        }

        reqList = IntefaceInfo['hsStdFiledInfo']['req']
        sImportStr = ''
        for reqItem in reqList:
            # 处理import
            if reqItem in baseImportList:
                continue
            if reqItem in sBindValue:
                continue
            sImportStr = sImportStr + '      <stdFieldQuote name="%(reqItem)s" flag="" comment=""/>\n' % {
                'reqItem': reqItem
            }

        yzItem['import'] = sImportStr

        valueList = ''
        if ',' in sCsdcEntrustType:
            valueList = "csdc_entrust_type = '%s'" % (
                sLsFunctionList[sLsFunction]['CsdcEntrustType'])
        for sBindFiledName in sBindValue:
            if len(sBindValue[sBindFiledName]) > 1:
                valueList = valueList + ',' + sBindFiledName + ' = "' + sBindValue[
                    sBindFiledName] + '"'
            else:
                valueList = valueList + ',' + sBindFiledName + " = '" + sBindValue[
                    sBindFiledName] + "'"

        if valueList != '':
            if valueList[:1] == ',':
                valueList = valueList[1:]
            valueList = '[' + valueList + ']'
        yzItem['valueList'] = valueList

        toDay = datetime.date.today().strftime('%Y%m%d')
        yzItem['toDay'] = toDay

        vText = '''\
<?xml version="1.0" encoding="UTF-8"?>

<hsdoc version="1.1.0">
  <basic>
    <basic objectId="%(objectId)s" version="V8.0.9.1" updateDate="%(toDay)s" description="" englishName="LS_UNITYACCOUNT_%(AbbName)s" flag="AF" returnResultSet="false" checkLicence="true" dataBaseName="" functionId="" serviceNo="" requirementNo="" requirementType="" requirementLevel="" auditNeed="false" auditType="" auditLevel="" operator="" subSystemId="" timeout="5000" needTransMonitor="false" noCallAS="false" defaultCallAS=""/>
  </basic>
  <parameter>
    <import>
      <stdFieldQuote name="op_branch_no" flag="D" comment=""/>
      <stdFieldQuote name="operator_no" flag="D" comment=""/>
      <stdFieldQuote name="user_type" flag="D" comment=""/>
      <stdFieldQuote name="op_password" flag="D" comment=""/>
      <stdFieldQuote name="op_station" flag="D" comment=""/>
      <stdFieldQuote name="op_entrust_way" flag="D" comment=""/>
      <stdFieldQuote name="menu_id" flag="D" comment=""/>
      <stdFieldQuote name="function_id" flag="D" comment=""/>
      <stdFieldQuote name="branch_no" flag="D" comment=""/>
      <stdFieldQuote name="audit_action" flag="D" comment=""/>
      <stdFieldQuote name="client_id" flag="" comment=""/>
      <stdFieldQuote name="fund_account" flag="" comment=""/>
%(import)s    </import>
    <export>
      <stdFieldQuote name="position_str" flag="" comment=""/>
    </export>
    <variable/>
  </parameter>
  <extend/>
  <code>
    [LF_统一账户_登记时间检查][en_time_kind = "%(time_kind)s"] 
    
    [AS_用户公用_业务许可证检查][module_id = %(module_id)s,license_type = '4']

    [AS_账户公用_账户基本参数信息获取][check_str="01"]
    
    [复核业务标志]
    
    [LF_统一账户_%(vIntefaceName)s]%(valueList)s
  </code>
  <ModifyLog/>
  <test/>
</hsdoc>
    ''' % yzItem

        with open(sOutPath + sFileName + '.service_design',
                  'w',
                  encoding=sEncoding) as wFile:
            wFile.write(vText)


# 处理接口业务逻辑代码
def CreateLFInteface(IntefaceInfo, sOutPath, sEncoding, vIntefaceName,
                     sHSStdfieldMap):

    # 重新清洗接口用到的字段信息
    sFiledInfoMap = {}
    sFiledInfoList = IntefaceInfo['hsStdFiledInfo']['filedInfoList']
    sCsdcEntrustType = str(IntefaceInfo['CsdcEntrustType'])
    for sFiledName in sFiledInfoList:
        sFiledInfo = sFiledInfoList[sFiledName]
        sFiledCName = ''
        if 'name' not in sFiledInfo:
            sFiledCName = sHSStdfieldMap[sFiledName]['cname']
        else:
            sFiledCName = sFiledInfo['name']

        sDictNo = ''
        if 'dict' not in sFiledInfo:
            if sFiledName in sHSStdfieldMap:
                sDictNo = sHSStdfieldMap[sFiledName]['dict']
            else:
                sDictNo = ''

        yzItem = {'name': sFiledCName}
        if 'dict' in sFiledInfo:
            yzItem['dict'] = sFiledInfo['dict']
        if sDictNo.strip() != '':
            yzItem['dictNo'] = sDictNo

        sFiledInfoMap[sFiledName] = yzItem

    sLsFunctionList = IntefaceInfo['LsFunction']

    for sLsFunction in sLsFunctionList:
        tIntefaceName = vIntefaceName
        if 'name' in sLsFunctionList[sLsFunction]:
            tIntefaceName = sLsFunctionList[sLsFunction]['name']

        sFileName = 'LF_统一账户_' + tIntefaceName
        print('处理' + sFileName)

        sAbbName = tools.GetInteFaceAbbName(tIntefaceName)

        if 'abbName' in sLsFunctionList[sLsFunction]:
            sAbbName = sLsFunctionList[sLsFunction]['abbName']

        sLfFunctionNo = '1' + sLsFunction
        if 'LfFuncctionNo' in sLsFunctionList[sLsFunction]:
            if sLsFunctionList[sLsFunction]['LfFuncctionNo'] == 'auto':
                sLfFunctionNo = GetMaxLfFunctionNo('业务逻辑/账户/统一账户/函数/')
            else:
                sLfFunctionNo = sLsFunctionList[sLsFunction]['LfFuncctionNo']

        yzItem = {
            'objectId': sLfFunctionNo,
            'AbbName': sAbbName,
            'vIntefaceName': vIntefaceName,
            'time_kind': IntefaceInfo['time_kind']
        }

        reqList = IntefaceInfo['hsStdFiledInfo']['req']
        sImportStr = ''
        for reqItem in reqList:
            # 处理import
            if reqItem in baseImportList:
                continue
            sImportStr = sImportStr + '      <stdFieldQuote name="%(reqItem)s" flag="" comment=""/>\n' % {
                'reqItem': reqItem
            }
        if ',' in sCsdcEntrustType:
            sImportStr = sImportStr + '      <stdFieldQuote name="%(reqItem)s" flag="" comment=""/>\n' % {
                'reqItem': 'csdc_entrust_type'
            }

        yzItem['import'] = sImportStr

        toDay = datetime.date.today().strftime('%Y%m%d')
        yzItem['toDay'] = toDay

        vText = '''\
<?xml version="1.0" encoding="UTF-8"?>

<hsdoc version="1.1.0">
  <basic>
    <basic objectId="%(objectId)s" version="V8.0.9.1" updateDate="%(toDay)s" description="" englishName="LF_UNITYACCOUNT_%(AbbName)s" flag="" returnResultSet="false" checkLicence="true" dataBaseName="" functionId="" serviceNo="" requirementNo="" requirementType="" requirementLevel="" auditNeed="false" auditType="" auditLevel="" operator="" subSystemId="" timeout="5000" needTransMonitor="false" noCallAS="false" defaultCallAS=""/>
  </basic>
  <parameter>
    <import>
      <stdFieldQuote name="op_branch_no" flag="D" comment=""/>
      <stdFieldQuote name="operator_no" flag="D" comment=""/>
      <stdFieldQuote name="user_type" flag="D" comment=""/>
      <stdFieldQuote name="op_password" flag="D" comment=""/>
      <stdFieldQuote name="op_station" flag="D" comment=""/>
      <stdFieldQuote name="op_entrust_way" flag="D" comment=""/>
      <stdFieldQuote name="menu_id" flag="D" comment=""/>
      <stdFieldQuote name="function_id" flag="D" comment=""/>
      <stdFieldQuote name="branch_no" flag="D" comment=""/>
      <stdFieldQuote name="audit_action" flag="D" comment=""/>
      <stdFieldQuote name="client_id" flag="" comment=""/>
      <stdFieldQuote name="fund_account" flag="" comment=""/>
%(import)s    </import>
    <export>
    <stdFieldQuote name="position_str" flag="" comment=""/>
    </export>
    <variable/>
  </parameter>
  <extend/>
  <code>
    [AS_统一账户_开户参数获取]
    hs_strncpy(@csdc_openorgan_code, lpResultSet-&gt;GetStr("openorgan_code"), sizeof(@csdc_openorgan_code) - 1);
    hs_strncpy(@csdc_opennet_code, lpResultSet-&gt;GetStr("opennet_code"), sizeof(@csdc_opennet_code) - 1);
    
    [AS_存管外部接口_%(vIntefaceName)s][finance_type = '1', position_str = @position_str, serial_no = @serial_no]
    [AS_用户公用_用户操作日志记录][trade_account = @fund_account, join_date = @init_date, join_serial_no = @serial_no, operator_action = 5]  
  </code>
  <ModifyLog/>
  <test/>
</hsdoc>
''' % yzItem

        with open(sOutPath + sFileName + '.function_design',
                  'w',
                  encoding=sEncoding) as wFile:
            wFile.write(vText)


# 处理接口原子代码
def CreateAsInteface(IntefaceInfo, sOutPath, sEncoding, vIntefaceName,
                     sHSStdfieldMap):
    sFileName = 'AS_存管外部接口_' + vIntefaceName
    print('处理' + sFileName)

    # 重新清洗接口用到的字段信息
    sFiledInfoMap = {}
    sFiledInfoList = IntefaceInfo['hsStdFiledInfo']['filedInfoList']
    for sFiledName in sFiledInfoList:
        sFiledInfo = sFiledInfoList[sFiledName]
        sFiledCName = ''
        if 'name' not in sFiledInfo:
            sFiledCName = sHSStdfieldMap[sFiledName]['cname']
        else:
            sFiledCName = sFiledInfo['name']

        sDictNo = ''
        if 'dict' not in sFiledInfo:
            if sFiledName in sHSStdfieldMap:
                sDictNo = sHSStdfieldMap[sFiledName]['dict']
            else:
                sDictNo = ''

        yzItem = {'name': sFiledCName}
        if 'dict' in sFiledInfo:
            yzItem['dict'] = sFiledInfo['dict']
        if sDictNo.strip() != '':
            yzItem['dictNo'] = sDictNo

        sFiledInfoMap[sFiledName] = yzItem

    yzItem = {
        'objectId': IntefaceInfo['functionNo'],
        'AbbName': tools.GetInteFaceAbbName(vIntefaceName)
    }

    reqList = IntefaceInfo['hsStdFiledInfo']['req']
    sfiledInfoList = IntefaceInfo['hsStdFiledInfo']['filedInfoList']

    sCsdcEntrustType = str(IntefaceInfo['CsdcEntrustType'])

    sStdFiled = IntefaceInfo['stdFiled']
    sStdFiledDx = {}
    for sStdFiledName in sStdFiled:
        sStdFiledDx[sStdFiled[sStdFiledName]] = sStdFiledName

    # 处理import和包
    sImportStr = ''
    sHeadPack = ''
    sBodyPack = ''
    for reqItem in reqList:
        sRepSrcFiled = ''
        # 处理包头
        sKG = ''.zfill(50 - len('@packer-&gt;AddField("%s");' %
                                (reqItem))).replace('0', ' ')
        if reqItem in baseFiledToCSDCMap:
            sRepSrcFiled = baseFiledToCSDCMap[reqItem]
        else:
            sRepSrcFiled = sStdFiledDx[reqItem]

        sHeadPack = sHeadPack + '  @packer-&gt;AddField("%s");%s//%s\n' % (
            reqItem, sKG, sRepSrcFiled)

        # 处理包体
        if reqItem == 'csdc_report_no':
            sKG = ''.zfill(50 -
                           len(' @packer-&gt;AddInt(@report_no)')).replace(
                               '0', ' ')
            sBodyPack = sBodyPack + "  @packer-&gt;AddInt(@report_no);%s//YWLSH\n" % (
                sKG)
        elif 'must' in sfiledInfoList[reqItem]:
            sMustStr = ''
            vMustStr = ''

            mustList = sfiledInfoList[reqItem]['must']
            sMustDesc = ''
            for sMustItem in mustList:
                if vMustStr != '':
                    sMustStr = '(' + vMustStr + ') || \n     ('
                    vMustStr = ''
                if sMustDesc != '':
                    sMustDesc = sMustDesc + ' 或 '
                for sMustFiledName in sMustItem:
                    if sMustDesc != '':
                        vMustStr = '(' + vMustStr + ') &amp;&amp; '
                    vMustDesc = ''
                    if type(sMustItem[sMustFiledName]) is dict:
                        for sMustFiledValue in sMustItem[sMustFiledName]:
                            if 'c[' in sMustFiledValue:
                                sIndex = sMustFiledValue[sMustFiledValue.
                                                         find('c[') +
                                                         len('c['):]
                                sIndex = sIndex[:sIndex.find(']')]
                                vMustDesc = vMustDesc + '第' + sIndex + '位为' + sMustItem[
                                    sMustFiledName][sMustFiledValue]
                                if vMustStr != '' and vMustStr[
                                        -11:] != '&amp;&amp; ' and vMustStr[
                                            -5:] != '|| \n     (':
                                    vMustStr = vMustStr + ' || '
                                vMustStr = vMustStr + "('%s' == @%s[%s])" % (
                                    sMustItem[sMustFiledName][sMustFiledValue],
                                    sMustFiledName, str(int(sIndex) - 1))
                    else:
                        for sMustFiledValue in sMustItem[sMustFiledName]:
                            vMustDesc = vMustDesc + sMustFiledValue + '、'
                            if vMustStr != '' and vMustStr[
                                    -11:] != '&amp;&amp; ' and vMustStr[
                                        -10:] != '|| \n     (':
                                vMustStr = vMustStr + ' || '
                            vMustStr = vMustStr + '(hs_strcmp(@%s, "%s") == 0)' % (
                                sMustFiledName, sMustFiledValue)
                    if sMustDesc != '' and sMustDesc[-2:] != '或 ':
                        sMustDesc = sMustDesc + '且'
                    sMustFiledCName = sFiledInfoMap[sMustFiledName]['name']
                    if vMustDesc[:1] == '第':
                        sMustDesc = sMustDesc + sMustFiledCName + vMustDesc + '时'
                    else:
                        sMustDesc = sMustDesc + sMustFiledCName + '为' + vMustDesc[:
                                                                                  -1] + '时'
            vMustStr = vMustStr.replace('() &amp;&amp; ', '')
            sMustStr = sMustStr + vMustStr

            if len(sMustStr.split('(')) > len(sMustStr.split(')')):
                sMustStr = sMustStr + ')'
            sMustDesc = reqItem + ' ' + sMustDesc + '必填'
            sBodyPack = sBodyPack + '\n  //' + sMustDesc + '\n  if '
            if '||' in sMustStr:
                sBodyPack = sBodyPack + '(' + sMustStr + ')\n'
            else:
                sBodyPack = sBodyPack + sMustStr + '\n'
            sKG = ''.zfill(48 - len('@packer-&gt;AddStr(@%s);' %
                                    (reqItem))).replace('0', ' ')
            sBodyPack = sBodyPack + '''\
  {
    @packer-&gt;AddStr(@%s);%s//%s
  }
  else
  {
    @packer-&gt;AddStr(" ");
  }

''' % (reqItem, sKG, sRepSrcFiled)
        else:
            sKG = ''.zfill(53 - len('@packer-&gt;AddField("%s");' %
                                    (reqItem))).replace('0', ' ')
            sBodyPack = sBodyPack + "  @packer-&gt;AddStr(@%s);%s//%s\n" % (
                reqItem, sKG, sRepSrcFiled)

        # 处理import
        if reqItem in baseImportList:
            continue
        sImportStr = sImportStr + '      <stdFieldQuote name="%(reqItem)s" flag="" comment=""/>\n' % {
            'reqItem': reqItem
        }
    if ',' in sCsdcEntrustType:
        sImportStr = sImportStr + '      <stdFieldQuote name="%(reqItem)s" flag="" comment=""/>\n' % {
            'reqItem': 'csdc_entrust_type'
        }
        sEntrustTypeStr = "  @inter_type = '5';\n"
        sEntrustTypeStr = sEntrustTypeStr + '  hs_snprintf(@sub_inter_type,sizeof(@sub_inter_type)-1,"%s%s","5",@csdc_entrust_type);'
    else:
        sEntrustTypeStr = "  @csdc_entrust_type = '%s';\n  @inter_type = '5';\n" % (
            sCsdcEntrustType)
        sEntrustTypeStr = sEntrustTypeStr + '  strcpy(@sub_inter_type,"5%s");' % (
            sCsdcEntrustType)

    yzItem['import'] = sImportStr
    yzItem['sEntrustTypeStr'] = sEntrustTypeStr
    yzItem['headPack'] = sHeadPack
    yzItem['bodyPack'] = sBodyPack

    toDay = datetime.date.today().strftime('%Y%m%d')
    yzItem['toDay'] = toDay

    vText = '''\
<?xml version="1.0" encoding="UTF-8"?>

<hsdoc version="1.1.0">
  <basic>
    <basic objectId="%(objectId)s" version="V8.0.9.1" updateDate="%(toDay)s" description="" englishName="AS_ASSETEXT_%(AbbName)s" flag="" returnResultSet="false" checkLicence="true" dataBaseName="" functionId="" serviceNo="" requirementNo="" requirementType="" requirementLevel="" auditNeed="false" auditType="" auditLevel="" operator="" subSystemId="" timeout="5000" needTransMonitor="false" noCallAS="false" defaultCallAS=""/>
  </basic>
  <parameter>
    <import>
      <stdFieldQuote name="op_branch_no" flag="D" comment=""/>
      <stdFieldQuote name="operator_no" flag="D" comment=""/>
      <stdFieldQuote name="user_type" flag="D" comment=""/>
      <stdFieldQuote name="op_password" flag="D" comment=""/>
      <stdFieldQuote name="op_station" flag="D" comment=""/>
      <stdFieldQuote name="op_entrust_way" flag="D" comment=""/>
      <stdFieldQuote name="menu_id" flag="D" comment=""/>
      <stdFieldQuote name="function_id" flag="D" comment=""/>
      <stdFieldQuote name="branch_no" flag="D" comment=""/>
      <stdFieldQuote name="audit_action" flag="D" comment=""/>
      <stdFieldQuote name="finance_type" flag="" comment=""/>
      <stdFieldQuote name="client_id" flag="" comment=""/>
      <stdFieldQuote name="fund_account" flag="" comment=""/>
      <stdFieldQuote name="curr_date" flag="" comment=""/>
      <stdFieldQuote name="curr_time" flag="" comment=""/>
      <stdFieldQuote name="init_date" flag="" comment=""/>
%(import)s    </import>
    <export>
      <stdFieldQuote name="serial_no" flag="" comment=""/>
      <stdFieldQuote name="position_str" flag="" comment=""/>
    </export>
    <variable/>
  </parameter>
  <extend/>
  <code>
%(sEntrustTypeStr)s
  
  [AF_存管外部接口_统一账户存管外部数据流水号获取]
  @report_no = lpResultSet-&gt;GetInt("report_no"); 
  
  //打包头
  @packer-&gt;BeginPack();
%(headPack)s

  //打包体
%(bodyPack)s

  @packer-&gt;EndPack(); 
  @business_data = @packer-&gt;GetPackBuf();
  vi_business_data = @packer-&gt;GetPackLen();
  
  [AF_存管外部接口_通用委托XML生成][file_obj = @file_obj]

  [AF_存管外部接口_统一账户存管外部数据添加][position_str = @position_str, serial_no = @serial_no, report_no = @report_no, req_content = @req_content]        	
  [AF_存管外部接口_主动推送][sub_inter_type=@sub_inter_type,inter_type=@inter_type]  
  </code>
  <ModifyLog/>
  <test/>
</hsdoc>
''' % yzItem

    with open(sOutPath + sFileName + '.aservice_design',
              'w',
              encoding=sEncoding) as wFile:
        wFile.write(vText)


# 处理AF_存管外部接口_主动推送
def CreateZDTS(IntefaceInfo, sZhSoCode, sOutPath):
    print('处理AF_存管外部接口_主动推送')
    sFilePath = sZhSoCode + '原子/账户/存管外部接口/函数/AF_存管外部接口_主动推送.afunction_design'
    sText, sEncoding = tools.LoadSrcCode(sFilePath)
    vText = ''
    sTimeKind = IntefaceInfo['time_kind']
    sCsdcEntrustType = str(IntefaceInfo['CsdcEntrustType'])
    sCsdcEntrustTypeList = sCsdcEntrustType.split(',')
    iIfLoop = 0
    for sLine in sText:
        if "@time_kind = '%s';" % (sTimeKind) in sLine:
            sIfStr = vText[vText.rfind('if ') + len('if '):]
            sIfStr = sIfStr[:sIfStr.find('{')]
            sIfStr = sIfStr[:sIfStr.rfind('\n')].strip()

            sIfStr = sIfStr[:-1]
            iIfLoop = len(sIfStr.split('||'))
            for sCsdcEntrustTypeItem in sCsdcEntrustTypeList:
                if '(hs_strcmp(@sub_inter_type,"5%s")==0)' % (
                        sCsdcEntrustTypeItem) in sIfStr:
                    continue
                iIfLoop = iIfLoop + 1
                if iIfLoop % 3 == 1:
                    sIfStr = sIfStr + ' ||\n       '
                    if sTimeKind != 'F':
                        sIfStr = sIfStr + '    '
                else:
                    sIfStr = sIfStr + ' || '
                sIfStr = sIfStr + '(hs_strcmp(@sub_inter_type,"5%s")==0)' % (
                    sCsdcEntrustTypeItem)
            vText = vText[:vText.rfind('if ') +
                          len('if ')] + sIfStr + ')\n  {\n'
        vText = vText + sLine + '\n'

    with open(sOutPath + 'AF_存管外部接口_主动推送.afunction_design',
              'w',
              encoding=sEncoding) as wFile:
        wFile.write(vText)

    return sEncoding


# 代码生成
def BuildCode(hsIntefaceMap, sOutPath):
    global sZhSoCode, returnObjectId
    returnObjectId = 0
    sPubResource = getConfig.GetConfig('UF20', 'pubResource',
                                       'codefactoryConfig.ini')

    sHSStdfieldMap = readStdfield.ReadHSStdfield(sPubResource +
                                                 'stdfields.xml')
    sZhSoCode = getConfig.GetConfig('UF20', 'ZHSOCode',
                                    'codefactoryConfig.ini')
    print(sZhSoCode)
    for sIntefaceName in hsIntefaceMap:
        vIntefaceName = sIntefaceName
        if '-' in vIntefaceName:
            vIntefaceName = vIntefaceName[vIntefaceName.find('-') + 1:]
            vIntefaceName = vIntefaceName.strip()
        sEncoding = CreateZDTS(hsIntefaceMap[sIntefaceName], sZhSoCode,
                               sOutPath)
        CreateAsInteface(hsIntefaceMap[sIntefaceName], sOutPath, sEncoding,
                         vIntefaceName, sHSStdfieldMap)
        CreateLsInteface(hsIntefaceMap[sIntefaceName], sOutPath, sEncoding,
                         vIntefaceName, sHSStdfieldMap)
        CreateLFInteface(hsIntefaceMap[sIntefaceName], sOutPath, sEncoding,
                         vIntefaceName, sHSStdfieldMap)


if __name__ == "__main__":
    sOutPath = 'F:/hundsun/svn/util/testFile/'
    hsIntefaceMap = {
        '消息接口 - 跨市场转登记账户及托管单元对应关系维护': {
            'CsdcEntrustType': 'j,k,l,m',
            'zxywlb': 'j',
            'time_kind': 'X',
            'functionNo': '2340230',
            'LsFunction': {
                '152050': {
                    'CsdcEntrustType': 'j',
                    'csdc_busi_kind': '01',
                    'name': '转板账户对应关系申报',
                    'abbName': 'EXCHBOARDACCT_REPORT',
                    'LfFuncctionNo': 'auto'
                },
                '152051': {
                    'CsdcEntrustType': 'k',
                    'csdc_busi_kind': '02',
                    'name': '转板账户对应关系修改',
                    'abbName': 'EXCHBOARDACCT_MOD',
                    'LfFuncctionNo': 'auto'
                },
                '152052': {
                    'CsdcEntrustType': 'l',
                    'csdc_busi_kind': '03',
                    'name': '转板账户对应关系查询',
                    'abbName': 'EXCHBOARDACCT_QRY',
                    'LfFuncctionNo': 'auto'
                },
                '152053': {
                    'CsdcEntrustType': 'm',
                    'csdc_busi_kind': '04',
                    'name': '转板配发账户交易限制查询',
                    'abbName': 'EBACCTTRADELIMIT_QRY',
                    'LfFuncctionNo': 'auto'
                }
            },
            'module_id': '465',
            'stdFiled': {
                'ZBLB': 'csdc_eb_busin_type',  #转板类别
                'ZQDM': 'csdc_stock_code',  #转板证券代码
                'GCZQZH': 'csdc_stock_account_src',  #过出证券账户
                'GCTGDY': 'csdc_seat_no_out',  #过出托管单元
                'GRZQZH': 'csdc_stock_account_dest',  #过入证券账户
                'GRTGDY': 'csdc_seat_no_dest_deal',  #过入托管单元
                'BYZD4': 'csdc_reserve4',  #备用字段4
                'GRZHBS': 'csdc_acct_mark_dest',  #过入账户标识
                'ZBXMBS': 'csdc_acct_limit_buy_mark',  #转板配发账户限买标识
                'ZDGXBS': 'csdc_reg_seat_mark',  #指定/托管关系标识
                'GRSYBS': 'csdc_stk_usedinfo_src',  #过入使用信息标识
                'YWRQ': 'csdc_busi_date',  #业务日期
                'YWPZBS': 'csdc_scan_flag'  #业务凭证报送标识
            },
            'hsStdFiledInfo': {
                'filedInfoList': {
                    'csdc_report_no': {},
                    'csdc_busi_kind': {
                        'dict': {
                            '01': '对应关系申报',
                            '02': '对应关系修改',
                            '03': '对应关系查询',
                            '04': '配发账户交易限制查询'
                        }
                    },
                    'csdc_eb_busin_type': {
                        'name': '转板类别',
                        'dict': {
                            '01': '新三板市场转板至沪市',
                            '02': '新三板市场转板至深市'
                        }
                    },
                    'csdc_stock_code': {
                        'name': '转板证券代码',
                        'must': [{
                            'csdc_busi_kind': ['01', '02', '03']
                        }]
                    },
                    'csdc_stock_account_src': {
                        'name': '过出证券账户号码',
                        'must': [{
                            'csdc_busi_kind': ['01', '02', '03']
                        }]
                    },
                    'csdc_seat_no_out': {
                        'name': '过出托管单元',
                        'must': [{
                            'csdc_busi_kind': ['01', '02', '03']
                        }]
                    },
                    'csdc_stock_account_dest': {
                        'name':
                        '过入证券账户号码',
                        'must': [{
                            'csdc_busi_kind': ['01', '02'],
                            'csdc_eb_busin_type': ['01']
                        }, {
                            'csdc_busi_kind': ['01', '02'],
                            'csdc_eb_busin_type': ['02'],
                            'csdc_spec_acct_mark_src': {
                                'c[4]': '1'
                            }
                        }]
                    },
                    'csdc_seat_no_dest_deal': {
                        'name':
                        '过入托管单元',
                        'must': [{
                            'csdc_busi_kind': ['01', '02'],
                            'csdc_eb_busin_type': ['02']
                        }]
                    },
                    'csdc_openorgan_code': {},
                    'csdc_opennet_code': {},
                    'report_date': {
                        'name': '申请日期'
                    },
                    'csdc_reserve1': {
                        'name': '备用字段1'
                    },
                    'csdc_reserve2': {
                        'name': '备用字段2'
                    },
                    'csdc_reserve3': {
                        'name': '备用字段3'
                    },
                    'csdc_reserve4': {
                        'name': '备用字段4'
                    },
                    'csdc_acct_mark_dest': {
                        'name': '过入账户标识',
                        'dict': {
                            '01': '中国结算选择的存量账户',
                            '02': '投资者申报的账户',
                            '03': '中国结算配发的新开账户'
                        }
                    },
                    'csdc_acct_limit_buy_mark': {
                        'name': '转板配发账户限买标识',
                        'dict': {
                            '1': '过入证券账户因转板配发被设置了禁止买入的交易限制',
                            '0': '过入证券账户未因转板配发被设置禁止买入的交易限制'
                        }
                    },
                    'csdc_reg_seat_mark': {
                        'name': '指定/托管关系标识',
                        'dict': {
                            '00': '过入证券账户无指定交易',
                            '01': '过入证券账户存在指定交易，其指定交易申报机构与过出托管单元所属机构一致',
                            '02': '过入证券账户存在指定交易，其指定交易申报机构与过出托管单元所属机构不一致',
                            '11': '过入托管单元与过出托管单元属于同一机构',
                            '12': '过入托管单元与过出托管单元属于不同机构'
                        }
                    },
                    'csdc_stk_usedinfo_src': {
                        'name': '过入使用信息标识',
                        'dict': {
                            '01': '过入托管单元所属机构为过入账户申报了使用信息',
                            '02': '过入托管单元所属机构没有为过入账户申报使用信息'
                        }
                    },
                    'csdc_busi_date': {},
                    'csdc_scan_flag': {},
                    'result_code': {},
                    'deal_info': {},
                    'csdc_spec_acct_mark_src': {
                        'name': '特殊过出账户标识'
                    }
                },
                'req': [
                    'csdc_report_no', 'csdc_busi_kind', 'csdc_eb_busin_type',
                    'csdc_stock_code', 'csdc_stock_account_src',
                    'csdc_seat_no_out', 'csdc_stock_account_dest',
                    'csdc_seat_no_dest_deal', 'csdc_openorgan_code',
                    'csdc_opennet_code', 'report_date', 'csdc_reserve1',
                    'csdc_reserve2', 'csdc_reserve3', 'csdc_reserve4'
                ],
                'rep': [
                    'csdc_report_no', 'csdc_busi_kind', 'csdc_eb_busin_type',
                    'csdc_stock_code', 'csdc_stock_account_src',
                    'csdc_seat_no_out', 'csdc_stock_account_dest',
                    'csdc_seat_no_dest_deal', 'csdc_openorgan_code',
                    'csdc_opennet_code', 'report_date', 'csdc_reserve1',
                    'csdc_reserve2', 'csdc_reserve3', 'csdc_reserve4',
                    'csdc_acct_mark_dest', 'csdc_acct_limit_buy_mark',
                    'csdc_reg_seat_mark', 'csdc_stk_usedinfo_src',
                    'csdc_busi_date', 'csdc_scan_flag', 'result_code',
                    'deal_info'
                ]
            },
            'DBSpecialFiled': {}
        }
    }
    BuildCode(hsIntefaceMap, sOutPath)