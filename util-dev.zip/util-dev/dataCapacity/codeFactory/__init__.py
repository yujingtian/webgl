# 本模块用来实现快速生成代码

# cCodeForHsExchtrans:生成C版的中登转换机代码
# delphiCodeForCSDC:生成delphi版的中登模拟器代码
# delphiCodeForHttpMsg:生成dalphi版的统一网关对接短信平台代码
# delphiCodeForStockHolderReg:生成delphi版的统一账户业务流水代码
# cresCodeForAssetext:生成cres版的存管外部接口
# cresCodeRecordNewField2Xml: 表结构新增字段记录到后台so模块XML文件中
# cresCodeRecordRiskFiles2Xml: 类型更换潜在风险文件确认，添加成功更换的字段记录到模块XML文件中
# buildStanCode: 解析传入的excel，生成相应的cres版标准代码
