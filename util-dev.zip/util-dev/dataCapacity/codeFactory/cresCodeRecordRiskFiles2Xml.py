# 本文件用来添加风险文件记录到模块XML文件中
import os
import re

import tools
import readStdfield as std
import readFiledType as fd
import time

# 源代码路径
srcPathMap = {}

sStdfieldsPath = '/公共资源/stdfields.xml'
sTypefieldsPath = '/公共资源/datatypes.xml'
sFieldsTypeMaps = {}
sFieldsOldTypeMaps = {}
reMarks1 = r'".*?"'
reMarkslash = r'".*?//.*?"'
reMarkDquote = r'".*?"'
# reMarkPslash = r'(?P<value>@@)'
reMarkPslash = r'@@(\d+)'
# reMarkCommentedA=r'/\*.*?\*/'
reMarkCommentedA = r'/\*.*?(\*/|$)'
# reMarkCommentedB=r'(^|/\*).*?\*/'
reMarkCommentedB = r'^.*?\*/'
reMarkcpy = r'hs_strncpy\((.*?)\);'
reMarkcat = r'hs_strncat\((.*?)\);'
reMarksemicolon = r'\((.*?)\);'
reMarksf = r'sizeof\((.*?)\)'
reMarkvar = r'name="(.*?)" type="(.*?)"'
reMarklistElement = r'@(.*?)($|\W)'
reMarkSelectInto = r'select (.*?) into (.*?)( from|$)'
reMarkInsertInto = r'insert into .*?\((.*?)\).*?(select(.*?)from|values\((.*?)\))'
reMarkField = r'sizeof\(@(.*?)\)'
reMarkchar = r'\[(.*?)\]'
sRiskFilesPath = '/riskfiles.txt'
sSqlPath = ''


# 获取对应文件路径
# srcPathMap={'业务逻辑...':{'module':{'服务':[],...},...},...}
def ReadSrcPath(sCodePaths):
    global srcPathMap
    for sCodePath in sCodePaths:
        srcPathRootMap = {}
        for root, dirs, files in os.walk(sCodePath):
            if 'module.xml' in files:
                srcDirFileMap = {}
                for dir in dirs:
                    sDirPath = root + '/' + dir
                    sDirPath = sDirPath.replace("\\", "/")
                    root = root.replace("\\", "/")
                    srcDirFileMap[dir] = os.listdir(sDirPath)
                srcPathRootMap[root] = srcDirFileMap
        srcPathMap[sCodePath] = srcPathRootMap


# 修改多个字段也只记录一条
def CreateModuleXML(sXmlDirPath, hsIntefaceMap):
    sXmlFilePath = sXmlDirPath + '/module.xml'
    print('开始写入修改记录到' + sXmlFilePath + '\n')
    sText, sEncoding = tools.LoadSrcCode(sXmlFilePath)
    bNeedWrite = True
    with open(sXmlFilePath, 'w', encoding=sEncoding) as wFile:
        for sLine in sText:
            if bNeedWrite and '<log>' in sLine:
                bNeedWrite = False
                sSerialNumber = sText[sText.index(sLine) + 4]
                sSerialNumber = sSerialNumber.split('<serialNumber>')[-1].split('</serialNumber>')[0]
                if sSerialNumber == hsIntefaceMap['serialNumber']:
                    print('修改记录已存在')
                else:
                    vLine = '''		<log>
                <position></position>
                <date>%(date)s</date>
                <version>%(version)s</version>
                <serialNumber>%(serialNumber)s</serialNumber>
                <user>%(user)s</user>
                <principal></principal>
                <cause></cause>
                <content>%(content)s</content>
                <tester></tester>
            </log>''' % hsIntefaceMap
                    wFile.write(vLine + '\n')
            wFile.write(sLine + '\n')


def CreateRecordSQL(sSqlPath, hsIntefaceMap, hsRootandsContentsVersionMap):
    global sStdfieldsPath
    global sTypefieldsPath
    global sFieldsTypeMaps
    global sFieldsOldTypeMaps
    allsubFileMaps = {}
    sContents = []
    for subfieldmaps in hsRootandsContentsVersionMap.values():
        for sfield, sfiletype in subfieldmaps.items():
            allsubFileMaps[sfield] = sfiletype
    for field, type in allsubFileMaps.items():
        sContent = field + '字段类型由' + sFieldsOldTypeMaps[field] + '变更为' + type
        sContents.append(sContent)

    print('开始写入修改记录到' + sSqlPath + '\n')
    sText, sEncoding = tools.LoadSrcCode(sSqlPath)
    bNeedWrite1 = True
    bNeedWrite2 = True
    with open(sSqlPath, 'w', encoding=sEncoding) as wFile:
        for sLine in sText:
            if bNeedWrite1 and '-- V' in sLine:
                bNeedWrite1 = False
                sTmp = sLine.split(' ')[1][1:].split('.')
                sVersion = 'V' + sTmp[0] + '.' + sTmp[1] + '.' + sTmp[2] + '.' + str(int(sTmp[3]) + 1)
                hsIntefaceMap['version'] = sVersion
                hsIntefaceMap['content'] = sContents[0]

                vLine = '''-- %(version)s  %(date)s  %(serialNumber)s %(user)s   %(requser)s     %(content)s''' % hsIntefaceMap
                wFile.write(vLine + '\n')
                for sTmp in sContents[1:]:
                    vLine = '''--                                                        %s''' % sTmp
                    wFile.write(vLine + '\n')
            if bNeedWrite2 and '--写在最后' in sLine:
                bNeedWrite2 = False
                vLine = '''-- begin %(version)s  %(date)s  %(serialNumber)s %(user)s   %(requser)s     %(content)s''' % hsIntefaceMap
                wFile.write(vLine + '\n')
                for sTmp in sContents[1:]:
                    vLine = '''--                                                             %s''' % sTmp
                    wFile.write(vLine + '\n')

                for sfield in allsubFileMaps.keys():
                    sOldOraType = fd.ReadHSDataType(sTypefieldsPath)[sFieldsOldTypeMaps[sfield]['oracle']]
                    sNewOraType = fd.ReadHSDataType(sTypefieldsPath)[allsubFileMaps[sfield]['oracle']]
                    snewSize = sNewOraType.split('(', 1)[-1].split(')', 1)[0].split(',', 1)[0]
                    vLine = '''prompt 
prompt 检查是否存在 %(oldType)s的 %(field)s 字段, 存在则更新为%(newType)s
begin
  for cur_pos in (select COLUMN_NAME, TABLE_NAME
    from user_tab_columns a
    where a.COLUMN_NAME = upper('%(field)s')
      and a.DATA_LENGTH < %(newSize)s and exists (select * from hsobjects t where a.TABLE_NAME = upper(t.object_name) and t.object_type <>'V')) loop
    execute immediate 'alter table '||cur_pos.TABLE_NAME || ' modify '||cur_pos.COLUMN_NAME||' %(newType)s';
  end loop;
end;
/
''' % {
                        'oldType': sOldOraType,
                        'field': sfield,
                        'newType': sNewOraType,
                        'newSize': snewSize
                    }
                    wFile.write(vLine + '\n')

                vLine = '''-- end   %(version)s  %(date)s  %(serialNumber)s %(user)s   %(requser)s     %(content)s''' % hsIntefaceMap
                wFile.write(vLine + '\n')
                for sTmp in sContents[1:]:
                    vLine = '''--                                                             %s''' % sTmp
                    wFile.write(vLine + '\n')
            wFile.write(sLine + '\n')


# 计算标准语言类型的大小
# 非标准语言类型则返回-1
def sizeofCType(sType):
    if sType == 'int':
        return 8
    elif sType == 'double':
        return 10
    elif 'char[' in sType:
        # char[10]
        # 10
        return int(re.search(reMarkchar, sType).group(1))
    else:
        return -1


# 计算字符串的所表示的大小
# 只有出现需替换字段才会返回二值元组
def CalcuField(str_, tupleVarTypeMaps):
    global sStdfieldsPath
    global sTypefieldsPath
    global sFieldsTypeMaps
    bNewTypeField = False
    sOldFieldHsType = ''
    if str_.isnumeric():
        return (int(str_),)
    elif str_.startswith('"'):
        str_ = eval(repr(str_).replace(r'\\', '\\'))  # 将\\ 转为 \ 为了计算转义字符
        return (len(str_) - 2,)  # 减去两个"
    elif 'sizeof' in str_:
        # sizeof(@pay_account) - 1
        # pay_account
        sField = re.search(reMarkField, str_).group(1)
        if sField in sFieldsTypeMaps.keys():
            sFieldHsType = sFieldsTypeMaps[sField]
            if sField in tupleVarTypeMaps:
                sOldFieldHsType = tupleVarTypeMaps[sField]
            else:
                sOldFieldHsType = std.ReadHSStdfield(sStdfieldsPath)[sField]
            bNewTypeField = True
        elif sField in tupleVarTypeMaps:
            sFieldHsType = tupleVarTypeMaps[sField]
        else:
            sFieldHsType = std.ReadHSStdfield(sStdfieldsPath)[sField]
        size = sizeofCType(fd.ReadHSDataType(sTypefieldsPath)[sFieldHsType]['c'])
        if bNewTypeField:
            return (size - 1, sField, sOldFieldHsType)
        else:
            return (size - 1,)
    else:
        sField = str_.replace('@', '')
        if sField in sFieldsTypeMaps.keys():
            sFieldHsType = sFieldsTypeMaps[sField]
            if sField in tupleVarTypeMaps:
                sOldFieldHsType = tupleVarTypeMaps[sField]
            else:
                sOldFieldHsType = std.ReadHSStdfield(sStdfieldsPath)[sField]
            bNewTypeField = True
        elif sField in tupleVarTypeMaps:
            sFieldHsType = tupleVarTypeMaps[sField]
        else:
            try:
                sFieldHsType = std.ReadHSStdfield(sStdfieldsPath)[sField]
            except:
                return (-10,)
        size = sizeofCType(fd.ReadHSDataType(sTypefieldsPath)[sFieldHsType]['c'])
        if bNewTypeField:
            return (size, sField, sOldFieldHsType)
        else:
            return (size,)


# 将复杂的数据库语句块分割,不应有 \n 等特殊符号
# 含有：lpad、rpad、nvl、trim、decode
# 返回列表，不可判断则返回空列表
def SplitFieldsString(sLine):
    symbolList = ['lpad(', 'rpad(', 'nvl(', 'trim(', '||']
    if 'decode(' in sLine:
        return []
    if all(symbol not in sLine for symbol in symbolList):
        return sLine.split(',')
    sCommaBlockList = sLine.split(',')
    intPar = -1
    indexBegin = -1
    bStart = False
    sFixTmp = ''
    for index, scommablock in enumerate(sCommaBlockList):
        if scommablock.count('(') > 0:
            bStart = True
            intPar = 0
            indexBegin = index
        if bStart:
            intPar += scommablock.count('(') - scommablock.count(')')
            if intPar == 0:
                sFixTmp += scommablock[:scommablock.rfind(')')]
                del sCommaBlockList[index]
                sCommaBlockList.insert(indexBegin, sFixTmp)
                sFixTmp = ''
                bStart = False
                intPar = -1
                continue
            del sCommaBlockList[index]
            sFixTmp += scommablock + ','
    for index2, scommablock2 in enumerate(sCommaBlockList):
        intSize = 0
        sDBarBlockList = scommablock2.split('||')
        for sdbarblock in sDBarBlockList:
            sTmpList = sdbarblock.split(',')
            if 'nvl(' in sdbarblock and 'pad(' in sdbarblock:
                if sdbarblock.find('nvl(') < sdbarblock.find('pad('):
                    sTmp = sTmpList[-3]
                else:
                    sTmp = sTmpList[-2]
                intSize += sTmp
            elif 'pad(' in sdbarblock:
                sTmp = sTmpList[-2]
                intSize += sTmp
            elif 'nvl(' in sdbarblock:
                if len(sDBarBlockList) >= 2:  # 若有||符号，并且单独出现nvl则不可判断
                    return []
                else:
                    intSize = sTmpList[0].replace('nvl(', '')  # 只有nvl，trim可能存在
            elif 'trim(' in sdbarblock:
                if len(sDBarBlockList) >= 2:  # 若有||符号，并且单独出现trim则不可判断
                    return []
                else:
                    intSize = sTmpList[0].replace('trim(', '')  # 只有trim
        sCommaBlockList[index2] = intSize
    return sCommaBlockList


# 在模块module.xml中添加记录
# 生成风险确认文件
def FindRiskFiles(sCodePath, hsIntefaceMap):
    global sFieldsTypeMaps
    global sFieldsOldTypeMaps
    print('开始遍历目录')
    sFieldsTypeMaps = hsIntefaceMap['fieldsTypeMaps']
    sCodes = ['hs_strncpy', 'hs_strncat']

    hsRootandsContentsVersionMap = {}
    for root, moduleMaps in srcPathMap.items():  # 模块组层 E:/HundSunCode/客户账户管理系统V22/原子
        for module, dirMaps in moduleMaps.items():  # 模块层  E:/HundSunCode/客户账户管理系统V22/原子/公用/账户公用(公用)
            subFieldMaps = {}
            sNums = []
            IntNums = []
            for dir, files in dirMaps.items():  # 模块内部层 函数,过程,...
                if dir == '过程':
                    continue
                for file in files:  # 模块内部文件层
                    sFilePath = module + '/' + dir + '/' + file
                    sText, sEncoding = tools.LoadSrcCode(sFilePath)
                    bCppCode = False  # 是否cpp代码块
                    bVarCode = False  # 是否内部变量代码块
                    intFlagCommented = 0
                    bSelectCode = False  # Select 语句块
                    bInsertCode = False  # Insert 语句块
                    sSelectInto = ''
                    sInsert = ''
                    tupleVarTypeMaps = {}  # 内部变量名——hs类型
                    for index, sLine in enumerate(sText):  # 文本行层
                        # <variable></variable>
                        if bVarCode or '<variable>' in sLine:
                            bVarCode = True
                            searchObj = re.search(reMarkvar, sLine)
                            if searchObj is not None:
                                tupleSearch = searchObj.groups()
                                tupleVarTypeMaps[tupleSearch[0]] = tupleSearch[1]
                            if '</variable>' in sLine:
                                bVarCode = False

                        if bCppCode or '<code>' in sLine:
                            bCppCode = True
                            indexSub = -1

                            def subDquote(matched):
                                global indexSub
                                indexSub += 1
                                return '@@' + str(indexSub)  # @@0 @@1

                            # asdas*/   strcpy(@init_date,"/*//*/",10); func(); /*//" " */ func2(); // " sdff " /*// */
                            # 引号内容歧义无效化
                            sQuote = []
                            if '"' in sLine:
                                # intFlagCommented==0 and '"' in sLine:
                                sQuote = re.findall(reMarkDquote, sLine)
                                sLine = re.sub(reMarkDquote, subDquote, sLine)

                            # asdas*/   strcpy(@init_date,@@0,10); func(); /*//@@1 */ func2(); // @@2 /*// */
                            # 清除行内块注释
                            if '*/' in sLine:
                                sLine = re.sub(reMarkCommentedA, '', sLine)
                            # asdas*/   strcpy(@init_date,@@0,10); func();  func2(); // @@2
                            # 清除行注释 //
                            if intFlagCommented == 0 and '//' in sLine:  # 若//出现在行中，则开始进行注释判断
                                sLine = sLine.split('//', 1)[0]

                            # asdas*/   strcpy(@init_date,@@0,10); func();  func2();
                            # 判断块注释 并且清除 /* ...end
                            if '/*' in sLine:
                                sLine = re.sub(reMarkCommentedA, '', sLine)
                                intFlagCommented = 1  # 预 块注释

                            # asdas*/   strcpy(@init_date,@@0,10); func();  func2();
                            # 判断块注释 并且清除 begin... */
                            if '*/' in sLine:
                                intFlagCommented = 0
                                sLine = re.sub(reMarkCommentedB, '', sLine)
                            if '*/' in sText[index + 1]:
                                intFlagCommented = 0  # 预 解除块注释
                            #    strcpy(@init_date,@@0,10); func();  func2();

                            # 预 块注释
                            if intFlagCommented > 1:
                                continue
                            elif intFlagCommented == 1:
                                intFlagCommented += 1

                            # 复原”“内容
                            def reStroe(matched):
                                return sQuote[int(matched.group(1))]

                            sLine = re.sub(reMarkPslash, reStroe, sLine)

                            # if (bendCommented or (not bCommented)) and any(sCode in sCodes for sCode in sLine) and any(
                            #         sField in sFieldsTypeMaps.keys() for sField in sLine):
                            if any(sCode in sCodes for sCode in sLine) and any(
                                    sField in sFieldsTypeMaps.keys() for sField in sLine):
                                sLine = sLine.expandtabs().replace(' ', '')
                                # ['@table_name,"sstholderuse//",sizeof(@table_name)-1', '@table_name, "bbb//bb", sizeof(@table_name) - 1']
                                reList = re.findall(reMarksemicolon, sLine)
                                # reListcat = re.findall(reMarkcat, sLine)
                                # hs_strncpy(@table_name, , sizeof(@table_name) - 1);
                                semiblockList = []  # [[],...]
                                for reEle in reList:
                                    semiblockList.append(reEle.split(','))
                                for commablockList in semiblockList:
                                    calcuTupleList = []
                                    for commablock in commablockList:
                                        calcuTupleList.append(CalcuField(commablock, tupleVarTypeMaps))
                                    # [(,),(,),(,)]
                                    if any(len(calcuTuple) == 3 for calcuTuple in calcuTupleList) and all(
                                            cal[0] >= 0 for cal in calcuTupleList):
                                        if calcuTupleList[1][0] > calcuTupleList[2][0] or calcuTupleList[0][0] < \
                                                calcuTupleList[2][0]:
                                            wfile = open(sCodePath + '/riskfiles.txt', mode='a')
                                            wfile.write(sFilePath + ' ' + str(index) + ' ' + sText(index) + '\n')
                                            wfile.close()
                                        else:
                                            for tup in calcuTupleList:
                                                if len(tup) == 3:
                                                    subFieldMaps[tup[1]] = sFieldsTypeMaps[tup[1]]
                                                    sFieldsOldTypeMaps[tup[1]] = tup[2]

                            if '/原子' in root:
                                if not bInsertCode and (bSelectCode or 'select ' in sLine):
                                    bSelectCode = True
                                    sSelectInto = sSelectInto + sLine.expandtabs().strip() + '\n'
                                    if ';' in sLine:
                                        # 'select init_data ,\nasasas\ninto @init_date_tmp , @aaa\nfrom optexeagreement'
                                        SelectIntoObj = re.search(reMarkSelectInto, sSelectInto, re.S)
                                        if SelectIntoObj is not None:
                                            reTupleTmp = SelectIntoObj.groups()
                                            # print:repr('init_data ,\nasasas\n', '@init_date_tmp , @aaa\n')
                                            reTupleEleSelect = reTupleTmp[0].replace('\n', '').replace(' ', '')
                                            reTupleEleInto = reTupleTmp[1].replace('\n', '').replace(' ', '')
                                            sProCFieldsList_s = SplitFieldsString(reTupleEleSelect)
                                            sProCFieldsList_i = reTupleEleInto.split(',')
                                            if sProCFieldsList_i:
                                                wfile = open(sCodePath + sRiskFilesPath, mode='a')
                                                wfile.write(
                                                    sFilePath + ' 代码块结束行 ' + str(index) + ' 请检查整个代码块 ' + sText(
                                                        index) + '\n')
                                                wfile.close()
                                            else:
                                                for eleSelect, eleInto in zip(sProCFieldsList_s, sProCFieldsList_i):
                                                    tupleSelect = CalcuField(eleSelect, tupleVarTypeMaps)
                                                    tupleInto = CalcuField(eleInto, tupleVarTypeMaps)

                                                    if 0 <= tupleSelect[0] <= tupleInto[0] or any(
                                                            -2 <= tup[0] < 0 for tup in [tupleSelect, tupleInto]):
                                                        if len(tupleSelect) == 3:
                                                            subFieldMaps[eleSelect] = sFieldsTypeMaps[eleSelect]
                                                            sFieldsOldTypeMaps[eleSelect] = tupleSelect[2]
                                                        if len(tupleInto) == 3:
                                                            subFieldMaps[eleInto] = sFieldsTypeMaps[eleInto]
                                                            sFieldsOldTypeMaps[eleInto] = tupleInto[2]
                                                    else:
                                                        wfile = open(sCodePath + '/riskfiles.txt', mode='a')
                                                        wfile.write(
                                                            sFilePath + ' 代码块结束行 ' + str(
                                                                index) + ' 请检查整个代码块 ' + sText(
                                                                index) + '\n')
                                                        wfile.close()
                                                        break
                                        # 复位
                                        sSelectInto = ''
                                        bSelectCode = False

                                if bInsertCode or 'insert ' in sLine:
                                    bInsertCode = True
                                    sInsert = sInsert + sLine.expandtabs().strip() + '\n'
                                    if ';' in sLine:
                                        InsertIntObj = re.search(reMarkInsertInto, sInsert, re.S)
                                        if InsertIntObj is not None:  # insert into 表名 values(值1，值2，......);
                                            reTupleTmp2 = InsertIntObj.groups()
                                            reTupleEleInsert = reTupleTmp2[0].replace('\n', '').replace(' ', '')
                                            if reTupleTmp2[2] is not None:
                                                reTupleEleInsertB = reTupleTmp2[2].replace('\n', '').replace(' ', '')
                                            else:
                                                reTupleEleInsertB = reTupleTmp2[3].replace('\n', '').replace(' ', '')
                                            sProCFieldsList_in = reTupleEleInsert.split(',')
                                            sProCFieldsList_b = SplitFieldsString(reTupleEleInsertB)
                                            if sProCFieldsList_b:
                                                wfile = open(sCodePath + '/riskfiles.txt', mode='a')
                                                wfile.write(
                                                    sFilePath + ' 代码块结束行 ' + str(index) + ' 请检查整个代码块 ' + sText(
                                                        index) + '\n')
                                                wfile.close()
                                            else:
                                                for eleInsert, eleB in zip(sProCFieldsList_in, sProCFieldsList_b):
                                                    eleInsert = eleInsert.replace('@', '')
                                                    tupleInsert = CalcuField(eleInsert, tupleVarTypeMaps)
                                                    tupleB = CalcuField(eleB, tupleVarTypeMaps)
                                                    if tupleInsert[0] >= tupleB[0] >= 0 or any(
                                                            -2 <= tup[0] < 0 for tup in [tupleInsert, tupleB]):
                                                        if len(tupleInsert) == 3:
                                                            subFieldMaps[eleInsert] = sFieldsTypeMaps[eleInsert]
                                                            sFieldsOldTypeMaps[eleInsert] = tupleInsert[2]
                                                        if len(tupleB) == 3:
                                                            subFieldMaps[eleB] = sFieldsTypeMaps[eleB]
                                                            sFieldsOldTypeMaps[eleB] = tupleB[2]
                                                    else:
                                                        wfile = open(sCodePath + '/riskfiles.txt', mode='a')
                                                        wfile.write(
                                                            sFilePath + ' 代码块结束行 ' + str(
                                                                index) + ' 请检查整个代码块 ' + sText(
                                                                index) + '\n')
                                                        wfile.close()
                                                        break
                                        # 复位
                                        sInsert = ''
                                        bInsertCode = False

                            if '</code>' in sLine:
                                break
            if subFieldMaps:
                for dir, files in dirMaps.items():  # module.xml文件夹层
                    for file in files:  # 文件夹层
                        sFilePath = module + '/' + dir + '/' + file
                        sText, sEncoding = tools.LoadSrcCode(sFilePath)
                        for sLine in sText:  # 文本行层
                            if '<version>' in sLine and '</version' in sLine:
                                sTmp = sLine.split('<version>')[-1].split('</version>')[0].strip()
                                if sTmp != '':
                                    sTmp = sTmp[1:]
                                    sNum = sTmp.split('.')
                                    IntNum = int(sTmp.replace('.', ''))
                                    sNums.append(sNum)
                                    IntNums.append(IntNum)
                                break

            if len(IntNums) != 0:
                index3 = IntNums.index(max(IntNums))
                sTmp = sNums[index3]
                sVersion = 'V' + sTmp[0] + '.' + sTmp[1] + '.' + sTmp[2] + '.' + str(int(sTmp[3]) + 1)
                hsRootandsContentsVersionMap[module] = [sVersion, subFieldMaps]
    return hsRootandsContentsVersionMap


def BuildCode(sCodePath, hsIntefaceMap):
    sCodePaths = [sCodePath, sCodePath]
    if sCodePath.rstrip().endswith('/'):
        sCodePaths[0] = sCodePath + '原子'
        sCodePaths[1] = sCodePath + '业务逻辑'
    else:
        sCodePaths[0] = sCodePath + '/原子'
        sCodePaths[1] = sCodePath + '/业务逻辑'
    ReadSrcPath(sCodePaths)

    hsRootandsContentsVersionMap = FindRiskFiles(sCodePath, hsIntefaceMap)
    for module, strs in hsRootandsContentsVersionMap.items():
        hsIntefaceMap['version'] = strs[0]
        sContent = '调整字段为新类型 '
        for sfilename, sfileType in strs[1].items():
            sContent += sfilename + ':' + sfileType + ','
        hsIntefaceMap['content'] = sContent
        CreateModuleXML(module, hsIntefaceMap)
    CreateRecordSQL(sSqlPath, hsIntefaceMap, hsRootandsContentsVersionMap)


if __name__ == "__main__":
    global sStdfieldsPath
    global sTypefieldsPath
    sCodePath = 'E:/HundSunCode/客户账户管理系统V22'
    sStdfieldsPath = sCodePath + sStdfieldsPath
    sTypefieldsPath = sCodePath + sTypefieldsPath

    date = time.strftime("%Y-%m-%d %H:%M", time.localtime())
    hsIntefaceMap = {
        'fieldsTypeMaps': {'a': 'aT', 'b': 'bT', 'c': 'cT'},
        'date': date,
        'serialNumber': 'tNum123456',
        'user': 'tUser',
        'requser': 'tReqUser'
    }
    BuildCode(sCodePath, hsIntefaceMap)
