# 本文件用来生成转换机的c代码
import os
import pinyin
import loadDoc
import tools

# 原代码路径
srcPathMap = {}


# 获取对应文件路径
def ReadSrcPath(sCodePath):
    global srcPathMap
    for root, dirs, files in os.walk(sCodePath):
        for fileName in files:
            sFilePath = root + '/' + fileName
            sFilePath = sFilePath.replace("\\", "/")
            if fileName in ['fsc_assettranssvr_impl.pc'
                            ] and 'fsc_assettrans_query' in root:
                srcPathMap[fileName] = sFilePath
            elif fileName in [
                    'Base.h', 'StdAfx.h', 'StkRegisterRepCS.cpp',
                    'StkRegisterRepCS.h', 'StkRegisterReqCS.cpp',
                    'StkRegisterReqCS.h', 'bp_account.cpp', 'bp_cs_account.rc',
                    'createdbf.cpp', 'function.cpp', 'parsexml.cpp'
            ] and 'bp_cs_account' in root:
                srcPathMap[fileName] = sFilePath

# 处理fsc_assettranssvr_impl.pc
def CreateAssettransQuery(vIntefaceName, zxywlb):
    if '查询' not in vIntefaceName and '核查' not in vIntefaceName:
        return ''


# 处理StdAfx.h 增量
def CreateStdAfx(sUnHasFiledMap, sAbbName, vIntefaceName, hsIntefaceInfo):
    print('开始处理StdAfx.h')
    sFunctionNo = hsIntefaceInfo['functionNo']
    sHsStdFiled = hsIntefaceInfo['stdFiled']
    # 加载StdAfx.h
    sText, sEncoding = tools.LoadSrcCode(srcPathMap['StdAfx.h'])
    sNo = ''
    isDefault = False
    isInclude = False
    isIncExist = False
    with open(srcPathMap['StdAfx.h'], 'w', encoding=sEncoding) as wFile:
        for sLine in sText:
            if isInclude and '#define '+sAbbName in sLine:
                isIncExist = True
            if '#include <windows.h>' in sLine:
                isInclude = True
            elif '//数据库表字段宏' in sLine:
                isDefault = True
                isInclude = False
            elif '//////////////////////////////////////////////////////////////////////////' in sLine and isInclude:
                isInclude = False
                isDefault = False
            elif '//////////////////////////////////////////////////////////////////////////' in sLine and isDefault:
                isInclude = False
                isDefault = False
                for sfiledName in sUnHasFiledMap:
                    if sfiledName in sHsStdFiled:
                        sKG = "".zfill(14 - len(sfiledName)).replace('0', " ")
                        sKG2 = "".zfill(31 - len(sHsStdFiled[sfiledName]) -
                                        2).replace('0', " ")
                        vLine = '#define DATABASE_FIELD_%(filedName)s%(kg)s"%(filedHsName)s"%(kg2)s//%(filedName)s %(filedCName)s' % {
                            'filedName': sfiledName,
                            'kg': sKG,
                            'kg2': sKG2,
                            'filedHsName': sHsStdFiled[sfiledName],
                            'filedCName':
                            sUnHasFiledMap[sfiledName]['filedCName']
                        }

                        wFile.write(vLine + '\n')
                    else:
                        print('新的接口字段没有找到对应的恒生字段:' + sfiledName)
            elif '//wuxy end' in sLine and str(
                    sText[sText.index(sLine) + 1]).strip() == '' and str(
                        sText[sText.index(sLine) +
                              2]).strip() == '' and isInclude:
                if not isIncExist:
                    wFile.write("#define %s  %s      //%s" %
                                (sAbbName, sFunctionNo, vIntefaceName) + '\n')

            wFile.write(sLine + '\n')


# 处理Base.h 增量
def CreateBase(intefaceMap, vIntefaceName):
    print('开始处理Base.h')
    sUseFiledList = {}
    sHasFiledList = []
    sUnHasFiledMap = {}
    sReqFiledList = intefaceMap['消息接口 - ' + vIntefaceName]['filedInfo']
    sRepFiledList = intefaceMap['应答-' + vIntefaceName]['filedInfo']
    # 整理用到的所有字段
    for sFiledItem in sReqFiledList:
        sFiledName = sFiledItem['filedName']
        if sFiledName not in sUseFiledList:
            sUseFiledList[sFiledName] = sFiledItem
    for sFiledItem in sRepFiledList:
        sFiledName = sFiledItem['filedName']
        if sFiledName not in sUseFiledList:
            sUseFiledList[sFiledName] = sFiledItem
    # 加载Base.h
    sText, sEncoding = tools.LoadSrcCode(srcPathMap['Base.h'])
    # 检查已有字段
    isTagClientInfo = False
    for sLine in sText:
        if 'typedef struct tagClientInfo' in sLine:
            isTagClientInfo = True
        elif '}ClientInfo, *PClientInfo;' in sLine:
            isTagClientInfo = False
        elif isTagClientInfo and 'char m_c' in sLine:
            sFiledName = sLine[sLine.find('char m_c') + len('char m_c'):]
            sFiledName = sFiledName[:sFiledName.find('[')]
            sHasFiledList.append(sFiledName)
    with open(srcPathMap['Base.h'], 'r', encoding=sEncoding) as rFile:
        sText2=rFile.read()
    with open(srcPathMap['Base.h'], 'w', encoding=sEncoding) as wFile:
        for sLine in sText:
            if '}ClientInfo, *PClientInfo;' in sLine:
                # 补充缺少的字段
                sLossFileds=[]
                sLossTmps=[]
                for sFiledName in sUseFiledList:
                    if sFiledName not in sHasFiledList and sFiledName not in [
                            'JGDM', 'JGSM'
                    ]:
                        sUnHasFiledMap[sFiledName] = sUseFiledList[sFiledName]

                        sLossFiled ='	char m_c' + sFiledName + '[' + str(
                            int(sUseFiledList[sFiledName]['filedLen']) +
                            1) + '];                  //' + str(
                                sUseFiledList[sFiledName]['filedCName'])+ '\n'
                        sLossTmp='char m_c' + sFiledName + '[' + str(
                            int(sUseFiledList[sFiledName]['filedLen']) +
                            1) + '];'
                        sLossTmps.append(sLossTmp)
                        sLossFileds.append(sLossFiled)
                for sT in sLossTmps:
                    if sText2.find(sT)!=-1:
                        index=sLossTmps.index(sT)
                        del sLossFileds[index]
                        del sLossTmps[index]
                if len(sLossFileds)>0:
                    wFile.write('\n')
                    wFile.writelines(sLossFileds)


            wFile.write(sLine + '\n')
    return sUnHasFiledMap


# 处理StkRegisterRepCS.cpp 增量 函数定义检测
def CrateStkRegisterRepCSCPP(intefaceMap, intefaceName, vIntefaceName,
                             hsIntefaceInfo):
    print('开始处理StkRegisterRepCS.cpp')
    zxywlb = hsIntefaceInfo['zxywlb']
    dBSpecialFiledMap = hsIntefaceInfo['DBSpecialFiled']
    sServiceType = intefaceMap[intefaceName]['ServiceType']
    sRepFiledList = intefaceMap['应答-' + vIntefaceName]['filedInfo']

    codeItem = {
        'ServiceType': sServiceType,
        'zxywlb': zxywlb,
        'abbName': tools.GetInteFaceAbbName(vIntefaceName),
        'vIntefaceName': vIntefaceName
    }
    # 加载StkRegisterRepCS.cpp
    sText, sEncoding = tools.LoadSrcCode(srcPathMap['StkRegisterRepCS.cpp'])

    isGetSubInterType = False
    isGetSubExist=False

    isPackHead = False
    isPackExist=False

    isConvertDBFToXML = False
    isConvertExist=False
    isFix=False
    match=0
    isBegin=True
    with open(srcPathMap['StkRegisterRepCS.cpp'], 'w',
              encoding=sEncoding) as wFile:
        for sLine in sText:
            if isGetSubInterType and 'case %(ServiceType)s:' % codeItem in sLine:
                isGetSubExist =True
            if isPackHead and 'case %(ServiceType)s:' % codeItem in sLine:
                isPackExist =True
            if isConvertDBFToXML and 'case %(ServiceType)s:' % codeItem in sLine:
                isConvertExist=True
            if 'char * CStkRegisterRepCS::GetSub_inter_type(char *cReport_no)' in sLine:
                isGetSubInterType = True
                isPackHead = False
                isConvertDBFToXML = False
            elif 'int CStkRegisterRepCS::PackHead(int iType)' in sLine:
                isPackHead = True
                isGetSubInterType = False
                isConvertDBFToXML = False
            elif 'int CStkRegisterRepCS::ConvertDBFToXML(int report_no,int iType, ZHQR **ppZHQRNode)' in sLine:
                isConvertDBFToXML = True
                isPackHead = False
                isGetSubInterType = False
            elif isConvertDBFToXML and 'default:' in sLine:
                isConvertDBFToXML = False
                if not isConvertExist:
                    vLine = '''	case %(ServiceType)s:
            iResult = ConvertDBFToPACK_%(abbName)s(iType, ppZHQRNode);
            memset(m_cSubInterType,0,8);
            strcpy(m_cSubInterType,"5%(zxywlb)s");
            g_lpfnWriteLog(LOG_IMPORTANT, "%(vIntefaceName)s回报处理，业务流水号:%%d\\n",report_no);
            break;''' % codeItem
                    wFile.write(vLine + '\n')

            elif isPackHead and 'default:' in sLine:
                isPackHead = False
                if not isPackExist:
                    vLine = '''	case %(ServiceType)s:
            //%(vIntefaceName)s
            iResult = PackHead_%(abbName)s();
            break;''' % codeItem
                    wFile.write(vLine + '\n')

            elif isGetSubInterType and ('default:' in sLine or sLine.replace(
                    '  ', '').strip() == '}'):
                isGetSubInterType = False
                if not isGetSubExist:
                    vLine = '''	case %(ServiceType)s:
            strcpy(cResult,"5%(zxywlb)s");
            break;''' % codeItem
                    wFile.write(vLine + '\n')
            if isFix or (('int CStkRegisterRepCS::PackHead_%(abbName)s()' % codeItem in sLine
                          or 'int CStkRegisterRepCS::ConvertDBFToPACK_%(abbName)s(' % codeItem in sLine)
                         and ';' not in sLine):
                isFix = True
                match += sLine.count('{')
                if match>0:
                    isBegin=False
                match -= sLine.count('}')
                if isBegin or match != 0:
                    continue
                elif not isBegin and match==0:
                    isFix=False
                    isBegin=True
                    continue


            wFile.write(sLine + '\n')

        # 补充的内容处理完了，开始处理新增方法
        vLine = '''
int CStkRegisterRepCS::PackHead_%(abbName)s()
{
	m_pPacker->BeginPack();
''' % codeItem
        wFile.write(vLine + '\n')

        for sFiledItem in sRepFiledList:
            sFiledName = sFiledItem['filedName']
            skg = "".zfill(23 - len(sFiledName)).replace('0', " ")
            sfiledNameChange = sFiledName
            if 'YWLSH' == sfiledNameChange:
                sfiledNameChange = 'YMTLS'
            elif sfiledNameChange in dBSpecialFiledMap:
                dBSpecialFiledMap = dBSpecialFiledMap[dBSpecialFiledMap]
            vLine = '''	m_pPacker->AddField(DATABASE_FIELD_%(filedNameChange)s);%(kg)s//%(filedName)s''' % {
                'filedName': sFiledName,
                'filedNameChange': sfiledNameChange,
                'kg': skg
            }
            wFile.write(vLine + '\n')


        vLine = '''	
	return 0;
}

int CStkRegisterRepCS::ConvertDBFToPACK_%(abbName)s(int iType, ZHQR **ppZHQRNode)
{
	int iResult = 0;
	char *pData = NULL;
	int _iReport;
	int iLen = 0;
	pData = (char *)(m_szReadDBF.GetField("YWLSH").AsString());
	if(pData == NULL)
	{
		g_lpfnWriteLog(LOG_WARNING, "取YWLSH失败!\\n");
		g_lpfnWriteLog(LOG_WARNING, "转换DBF到业务包错误!\\n");
		return -2;
	}

	_iReport = atoi(pData);
	if(m_iReportNo == -1)
	{
		(*ppZHQRNode)->report_no = _iReport;
		m_iReportNo = _iReport;
	}
	else if(m_iReportNo != _iReport)
	{
		g_lpfnWriteLog(LOG_INFO, "上一次读到的申报号: %%d, 现在读到的申报号: %%d，有新的回报!",\\
			m_iReportNo, _iReport);
		return 1;
	}
	
	m_pPacker->AddStr(pData);
	
''' % codeItem
        wFile.write(vLine.replace('%%', '%') + '\n')
        for sFiledItem in sRepFiledList:
            sFiledName = sFiledItem['filedName']
            if sFiledName == 'YWLSH':
                continue
            if 'RQ' in sFiledName and sFiledName not in ['KTRQ', 'YWRQ']:
                vLine = '''	iLen = strlen(m_szReadDBF.GetField("%(filedName)s").AsString());
	if( iLen <= 0 )
	{
		m_pPacker->AddStr((char *)("0"));
	}
	else
	{
		m_pPacker->AddStr((char *)(m_szReadDBF.GetField("%(filedName)s").AsString()));
	}''' % {
                    'filedName': sFiledName
                }
                wFile.write(vLine + '\n')
            else:
                vLine = '''	m_pPacker->AddStr((char *)(m_szReadDBF.GetField("%(filedName)s").AsString()));''' % {
                    'filedName': sFiledName
                }
                wFile.write(vLine + '\n')
        vLine = '''
	return 0;
}'''
        wFile.write(vLine)


# 处理StkRegisterRepCS.h 增量
def CreateStkRegisterRepCSH(sAbbName):
    print('开始处理StkRegisterRepCS.h')
    sText, sEncoding = tools.LoadSrcCode(srcPathMap['StkRegisterRepCS.h'])

    isConvertDBFToXML = False
    isPackHead = False
    isConvertExist=False
    isPackExist=False
    with open(srcPathMap['StkRegisterRepCS.h'], 'w',
              encoding=sEncoding) as wFile:
        for sLine in sText:
            if isConvertDBFToXML and 'int ConvertDBFToPACK_%s(int iType, ZHQR **ppZHQRNode);' % sAbbName in sLine:
                isConvertExist=True
            if isPackHead and 'int PackHead_%s();' % sAbbName in sLine:
                isPackExist=True
            if 'int ConvertDBFToXML(int report_no,int iType, ZHQR **ppZHQRNode);' in sLine:
                isConvertDBFToXML = True
                isPackHead = False
            elif 'int PackHead_YMTKH()' in sLine:
                isPackHead = True
                if isConvertDBFToXML and not isConvertExist:
                    wFile.write(
                        '    int ConvertDBFToPACK_%s(int iType, ZHQR **ppZHQRNode);\n'
                        % (sAbbName))
                isConvertDBFToXML = False

            elif isPackHead and '};' in sLine:
                isPackHead = False
                if not isPackExist:
                    wFile.write('    int PackHead_%s();\n' % (sAbbName))
            elif isConvertDBFToXML and len(sLine.replace('  ',
                                                         '').strip()) == 0:
                isConvertDBFToXML = False
                if not isConvertExist:
                    wFile.write(
                        '    int ConvertDBFToPACK_%s(int iType, ZHQR **ppZHQRNode);\n'
                        % (sAbbName))

            wFile.write(sLine + '\n')


# 处理StkRegisterReqCS.cpp 增量 函数定义检测
def CreateStkRegisterReqCSCPP(intefaceMap, vIntefaceName, hsIntefaceInfo,
                              sAbbName):
    print('开始处理StkRegisterReqCS.cpp')
    zxywlb = hsIntefaceInfo['zxywlb']

    sText, sEncoding = tools.LoadSrcCode(srcPathMap['StkRegisterReqCS.cpp'])
    sReqFiledList = intefaceMap['消息接口 - ' + vIntefaceName]['filedInfo']
    ServiceName = intefaceMap['消息接口 - ' + vIntefaceName]['ServiceName']
    ServiceType = intefaceMap['消息接口 - ' + vIntefaceName]['ServiceType']
    ServiceName = ServiceName + "".zfill(16 - len(ServiceName)).replace(
        '0', ' ')

    codeItem = {
        'zxywlb': zxywlb,
        'IntefaceName': vIntefaceName,
        'abbName': sAbbName,
        'ServiceName': ServiceName,
        'ServiceType': ServiceType
    }

    isSwitch = False
    isSwExist=False
    isFix=False
    match=0
    isBegin=True
    with open(srcPathMap['StkRegisterReqCS.cpp'], 'w',
              encoding=sEncoding) as wFile:
        for sLine in sText:
            if isSwitch and "case '%(zxywlb)s'"% codeItem in sLine:
                isSwExist=True
            if '	switch(pZHNode->sub_inter_type[1])' in sLine:
                isSwitch = True
            elif isSwitch and 'default:' in sLine:
                isSwitch = False
                if not isSwExist:
                    vline = '''		case '%(zxywlb)s':
                g_lpfnWriteLog(LOG_IMPORTANT, "开始执行%(IntefaceName)s!\\n");
                iResult = DoOpen%(abbName)s(pZHNode, iType, pFileName);
                break;''' % codeItem
                    wFile.write(vline + '\n')
            if isFix or ('int CStkRegisterReqCS::DoOpen%(abbName)s(' % codeItem in sLine
                         and ';' not in sLine):
                isFix = True
                match += sLine.count('{')
                if match>0:
                    isBegin=False
                match -= sLine.count('}')
                if isBegin or match != 0:
                    continue
                elif not isBegin and match==0:
                    isFix=False
                    isBegin=True
                    continue

            wFile.write(sLine + '\n')

        # 开始处理新增方法
        vline = '''
int CStkRegisterReqCS::DoOpen%(abbName)s(ZH *pZHNode, int iType, char *pFileName)
{
	if(pZHNode == NULL || pFileName == NULL)
		return -1;
	char cTemp[1024];
	
	int iResult = 0;
	if(iType == NOUNITE || iType == UNITE_NOFILE)
	{
		iResult = Create%(abbName)sDbf(g_cSubPath, pFileName);
		if(iResult != 0)
		{
			g_lpfnWriteLog(LOG_WARNING, "创建DBF %%s\\\\%%s失败，错误代码：%%d!\\n", g_cSubPath, pFileName, iResult);
			return -2;
		}
	}
	else
		g_lpfnWriteLog(LOG_INFO, "文件: %%s, 已经创建，加入到申报数据文件中!\\n", pFileName);
	
	sprintf(cTemp, "%%s\\\\%%s", g_cSubPath, pFileName);
	iResult = m_szWriteDBF.OpenDbf(cTemp, 1, 1);
	if(iResult != 0)
	{
		g_lpfnWriteLog(LOG_WARNING, "打开新建的%%s失败，错误代码：%%d!\\n", cTemp, iResult);
		return -3;
	}
	
	bool bResult = m_szWriteDBF.Append();
	if(!bResult)
	{
		m_szWriteDBF.CloseDbf();
		g_lpfnWriteLog(LOG_WARNING, "向%%s增加一行失败!\\n", cTemp);
		return -4;
	}
	
	//////////////////////////////////////////////////////////////////////////
	//解析%(IntefaceName)s推送消息
	iResult = ParseXML(%(abbName)s, (char *)(pZHNode->file_obj), pZHNode->m_iDataLen);
	if(iResult)
	{
		g_lpfnWriteLog(LOG_WARNING, "解释业务包错误，错误代码%%d!\\n", iResult);
		m_szWriteDBF.CloseDbf();
		return -5;
	}
	else
		g_lpfnWriteLog(LOG_INFO, "解释业务包成功!\\n");
	//////////////////////////////////////////////////////////////////////////
''' % codeItem
        wFile.write(vline.replace('%%', '%') + '\n')

        for sFiledItem in sReqFiledList:
            sFiledName = sFiledItem['filedName']
            kg = "".zfill(20 - len(sFiledName) * 2).replace('0', ' ')
            vLine = '''	m_szWriteDBF.GetField("%(filedname)s").SetValue(m_szClientInfo.m_c%(filedname)s);%(kg)s//%(filedname)s''' % {
                'filedname': sFiledName,
                'kg': kg
            }
            wFile.write(vLine + '\n')
        wFile.write('\n')

        vLine = '''	iResult = m_szWriteDBF.Post();
	
	//int iRecordNo = m_szWriteDBF.GetRecordCount() - 1;
	
	m_szWriteDBF.CloseDbf();
	
	if(iResult != 0)
	{
		g_lpfnWriteLog(LOG_WARNING, "写入DBF失败，错误代码：%%d!\\n", iResult);
		return -6;
	}
	else
		g_lpfnWriteLog(LOG_INFO, "写入DBF成功!\\n");
	
	if(iType == NOUNITE)
	{
		iResult = AppendReqDbf("CSDCC           ", "%(ServiceName)s", "%(ServiceType)s", pFileName, pZHNode);
		if(iResult != 0)
		{
			g_lpfnWriteLog(LOG_WARNING, "将请求记录增加到%%s失败，错误代码：%%d!\\n", cTemp, iResult);
			return -7;
		}
	}
	else
	{
		iResult = UniteAddToMap("CSDCC           ", "%(ServiceName)s", "%(ServiceType)s", pZHNode);
		if(iResult != 0)
		{
			g_lpfnWriteLog(LOG_WARNING, "请求加入到合并队列出错!\\n");
			return -8;
		}
		g_lpfnWriteLog(LOG_INFO, "合并申报写到%%s 中，交给线程加入到申报总文件中!\\n", cTemp);
	}
	
	return 0;
}''' % codeItem
        wFile.write(vLine.replace('%%', '%') + '\n')


# 处理StkRegisterReqCS.h
def CreateStkRegisterReqCSH(sAbbName):
    print('开始处理StkRegisterReqCS.h')
    sText, sEncoding = tools.LoadSrcCode(srcPathMap['StkRegisterReqCS.h'])

    isDoOpen = False
    isDoExist=False

    isCreate = False
    isCreExist=False

    isParseXML = False
    isParExist =False

    with open(srcPathMap['StkRegisterReqCS.h'], 'w',
              encoding=sEncoding) as wFile:
        for sLine in sText:
            if isDoOpen and 'int DoOpen%s(ZH *pZHNode, int iType = 0, char *pFileName = NULL);' % sAbbName in sLine:
                isDoExist=True
            if isCreate and 'int Create%sDbf(char *pSubPath, char *pNewFileName);' % sAbbName in sLine:
                isCreExist=True
            if isParseXML and 'int ParseXML_%s(char *pxmlData, int xmlDataLen);' % sAbbName in sLine:
                isParExist=True
            if '	//统一账户申报处理' in sLine:
                isDoOpen = True
                isCreate = False
                isParseXML = False
            elif '	//统一账户申报dbf文件创建' in sLine:
                isCreate = True
                isDoOpen = False
                isParseXML = False
            elif '	int ParseXML_YMTKH(char *pxmlData, int ixmlDataLen);' in sLine:
                isParseXML = True
                isCreate = False
                isDoOpen = False
            elif isParseXML and '//////////////////////////////////////////////////////////////////////////' in sLine:
                if not isParExist:
                    vLine = '''	int ParseXML_%s(char *pxmlData, int xmlDataLen);''' % (
                        sAbbName)
                    wFile.write(vLine + '\n')
            elif isCreate and '//////////////////////////////////////////////////////////////////////////' in sLine:
                isCreate = False
                if not isCreExist:
                    vLine = '''	int Create%sDbf(char *pSubPath, char *pNewFileName);''' % (
                        sAbbName)
                    wFile.write(vLine + '\n')
            elif isDoOpen and '//////////////////////////////////////////////////////////////////////////' in sLine:
                isDoOpen = False
                if not isDoExist:
                    vLine = '''    int DoOpen%s(ZH *pZHNode, int iType = 0, char *pFileName = NULL);''' % (
                        sAbbName)
                    wFile.write(vLine + '\n')

            wFile.write(sLine + '\n')


# 处理createdbf.cpp 增量 函数定义检测
def CreateCreatedbfCPP(intefaceMap, vIntefaceName, sAbbName):
    print('开始处理createdbf.cpp')
    sText, sEncoding = tools.LoadSrcCode(srcPathMap['createdbf.cpp'])
    sReqFiledList = intefaceMap['消息接口 - ' + vIntefaceName]['filedInfo']
    isFix = False  # 增量或是全量
    match = 0
    isBegin=True
    with open(srcPathMap['createdbf.cpp'], 'w', encoding=sEncoding) as wFile:
        for sLine in sText:
            if isFix or ('int CStkRegisterReqCS::Create%sDbf(' % (
            sAbbName) in sLine and ';' not in sLine):
                isFix = True
                match += sLine.count('{')
                if match>0:
                    isBegin=False
                match -= sLine.count('}')
                if isBegin or match != 0:
                    continue
                elif not isBegin and match==0:
                    isFix=False
                    isBegin=True
                    continue

            wFile.write(sLine + '\n')

        wFile.write('\n')
        vLine = '''int CStkRegisterReqCS::Create%(AbbName)sDbf(char *pSubPath, char *pNewFileName)
{
	char cTemp[1024];
	
	sprintf(cTemp, "%%s\\\\%%s", pSubPath, pNewFileName);
	
	remove(cTemp);
	int iResult = m_szDBFHelper.BeginCreate(cTemp);
	if(iResult != 0)
	{
		g_lpfnWriteLog(LOG_WARNING, "创建%%s失败，错误代码：%%d!\\n", cTemp, iResult);
		return -1;
	}

''' % {
            'AbbName': sAbbName
        }
        wFile.write(vLine.replace('%%', '%') + '\n')

        for sFiledItem in sReqFiledList:
            sFiledName = sFiledItem['filedName']
            sFiledCName = sFiledItem['filedCName']
            sFiledLen = sFiledItem['filedLen']
            kg = "".zfill(10 - len(sFiledName)).replace('0', ' ')
            vLine = '''	m_szDBFHelper.AddField("%(filedName)s", 'C', %(filedLen)s, 0);%(kg)s//%(filedCName)s''' % {
                'filedName': sFiledName,
                'filedCName': sFiledCName,
                'filedLen': sFiledLen,
                'kg': kg
            }
            wFile.write(vLine + '\n')

        vLine = '''
	iResult = m_szDBFHelper.EndCreate();
	if(iResult != 0)
	{
		g_lpfnWriteLog(LOG_WARNING, "结束创建%%s失败，错误代码：%%d", cTemp, iResult);
		return -2;
	}
	
	return 0;
}'''
        wFile.write(vLine.replace('%%', '%') + '\n')


# 处理function.cpp 增量
# 可以检测一个 else if中多个判断条件，并根据下一行调整
def CreateFunctionCpp(intefaceMap, vIntefaceName):
    print('开始处理function.cpp')
    sText, sEncoding = tools.LoadSrcCode(srcPathMap['function.cpp'])

    ServiceName = intefaceMap['消息接口 - ' + vIntefaceName]['ServiceName']
    ServiceType = intefaceMap['消息接口 - ' + vIntefaceName]['ServiceType']

    isBegin = False
    ServiceTypes=[]
    with open(srcPathMap['function.cpp'], 'w', encoding=sEncoding) as wFile:
        for index,sLine in enumerate(sText):
            if 'if(strncmp(pServiceDomain, "CSDCC",5) == 0 && strncmp(pServiceName, "%s",%s) == 0)' % (
                    ServiceName, str(len(ServiceName))) in sLine:
                isBegin = True
            elif isBegin and '}' in sLine:
                isBegin = False
                if ServiceType not in ServiceTypes:
                    vLine = '''		else if( strcmp(pServiceType, "%(ServiceType)s") == 0 )
                iType = %(ServiceType)s;''' % {
                        'ServiceType': ServiceType
                    }
                    wFile.write(vLine + '\n')
            if isBegin and 'if( strcmp(' in sLine:
                splitTmps=sLine.split('\"')
                if len(splitTmps) == 3:
                    ServiceTypes.append(splitTmps[1])
                else:
                    vLine = '''		else if( strcmp(pServiceType, "%(ServiceType)s") == 0 )''' % {
                    'ServiceType': sText[index+1][-3:-1]
                    }
                    wFile.write(vLine + '\n')
                    continue
            wFile.write(sLine + '\n')


# 处理parsexml.cpp 增量 函数定义检测
def CreatepParsexmlCPP(sAbbName, intefaceMap, vIntefaceName, hsIntefaceInfo):
    print('开始处理parsexml.cpp')
    sText, sEncoding = tools.LoadSrcCode(srcPathMap['parsexml.cpp'])
    sReqFiledList = intefaceMap['消息接口 - ' + vIntefaceName]['filedInfo']
    dBSpecialFiledMap = hsIntefaceInfo['DBSpecialFiled']

    isParseXML = False
    isFix = False  # 增量或是全量
    isExist=False
    match=0
    isBegin=True
    with open(srcPathMap['parsexml.cpp'], 'w', encoding=sEncoding) as wFile:
        for sLine in sText:
            if 'int CStkRegisterReqCS::ParseXML(int iFunctionID, char *pxmlData, int ixmlDataLen)' in sLine:
                isParseXML = True
            elif isParseXML and 'default:' in sLine:
                isParseXML = False
                if not isExist:
                    vLine = '''	case %(AbbName)s:      
            iResult = ParseXML_%(AbbName)s(pxmlData,ixmlDataLen);
            break;''' % {
                        'AbbName': sAbbName
                    }
                    wFile.write(vLine + '\n')
            if isParseXML and 'case '+sAbbName+':' in sLine:
                isExist=True
            if isFix or ('int CStkRegisterReqCS::ParseXML_%s(' % (
                    sAbbName) in sLine and ';' not in sLine):
                isFix = True
                match += sLine.count('{')
                if match>0:
                    isBegin=False
                match -= sLine.count('}')
                if isBegin or match != 0:
                    continue
                elif not isBegin and match==0:
                    isFix=False
                    isBegin=True
                    continue

            wFile.write(sLine + '\n')
        wFile.write('\n')

        vLine = '''int CStkRegisterReqCS::ParseXML_%(AbbName)s(char *pxmlData, int xmlDataLen)
{
	const char *pData = NULL;
	int iResult = 0;
	
	iResult = m_pUnPacker->Open(pxmlData,xmlDataLen);
	if(iResult != 0)
	{
		g_lpfnWriteLog(LOG_ERROR, "解obj字段包失败，错误代码: %%d!\\n", iResult);
		return -1;
	}
''' % {
            'AbbName': sAbbName
        }
        wFile.write(vLine.replace('%%', '%') + '\n')

        sRQLine = ''
        for sFiledItem in sReqFiledList:
            sFiledName = sFiledItem['filedName']
            if sFiledName[-2:] == 'RQ':
                sRQLine = sRQLine + '''    if ( strcmp(m_szClientInfo.m_c%(filedName)s,"0") == 0  ) 
	{
		memset(m_szClientInfo.m_c%(filedName)s,0x00,sizeof(m_szClientInfo.m_c%(filedName)s));
	}
''' % {
                    'filedName': sFiledName
                }

            kg = "".zfill(23 - len(sFiledName) * 2).replace('0', ' ')
            sfiledNameChange = sFiledName
            if 'YWLSH' == sfiledNameChange:
                sfiledNameChange = 'YMTLS'
            elif sfiledNameChange in dBSpecialFiledMap:
                dBSpecialFiledMap = dBSpecialFiledMap[dBSpecialFiledMap]
            vLine = '''	GETVALUE(m_pUnPacker,DATABASE_FIELD_%(filedNameChange)s,m_szClientInfo.m_c%(filedName)s);%(kg)s//%(filedName)s''' % {
                'filedName': sFiledName,
                'filedNameChange': sfiledNameChange,
                'kg': kg
            }
            wFile.write(vLine + '\n')

        vLine = sRQLine + '''
    return 0;
}
'''
        wFile.write(vLine + '\n')


# 代码生成
def BuildCode(sCodePath, intefaceMap, intefaceName, sOutCodeDir,
              hsIntefaceMap):
    vIntefaceName = intefaceName
    if vIntefaceName in intefaceMap:
        zxywlb = hsIntefaceMap[intefaceName]['zxywlb']
        sFunctionNo = hsIntefaceMap[intefaceName]['functionNo']
        ReadSrcPath(sCodePath)
        if '-' in vIntefaceName:
            vIntefaceName = vIntefaceName[vIntefaceName.find('-') + 1:]
            vIntefaceName = vIntefaceName.strip()
        vReqIntefaceName = ''
        if '消息接口 - ' + vIntefaceName in intefaceMap:
            vReqIntefaceName = '消息接口 - ' + vIntefaceName
        sAbbName = tools.GetInteFaceAbbName(vIntefaceName)
        CreateAssettransQuery(intefaceName, zxywlb)
        sUnHasFiledMap = CreateBase(intefaceMap, vIntefaceName)
        CreateStdAfx(sUnHasFiledMap, sAbbName, vIntefaceName,
                     hsIntefaceMap[intefaceName])
        CrateStkRegisterRepCSCPP(intefaceMap, intefaceName, vIntefaceName,
                                 hsIntefaceMap[intefaceName])
        CreateStkRegisterRepCSH(sAbbName)
        CreateStkRegisterReqCSCPP(intefaceMap, vIntefaceName,
                                  hsIntefaceMap[intefaceName], sAbbName)
        CreateStkRegisterReqCSH(sAbbName)
        CreateCreatedbfCPP(intefaceMap, vIntefaceName, sAbbName)
        CreateFunctionCpp(intefaceMap, vIntefaceName)
        CreatepParsexmlCPP(sAbbName, intefaceMap, vIntefaceName,
                           hsIntefaceMap[intefaceName])


if __name__ == "__main__":
    sFilePath = 'E:/HundSunCode/testFile/统一账户平台关于为转板上市证券跨市场转登记维护账户及托管单元对应关系的接口修订说明 （开发参考稿） - 20210525.docx'
    intefaceMap, resultJsonMap = loadDoc.LoadDoc(sFilePath)
    sCodePath = 'E:/HundSunCode/hsexchtrans_multi/'
    sOutCodeDir = 'E:/HundSunCode/testFile/'
    hsIntefaceMap = {
        '消息接口 - 跨市场转登记账户及托管单元对应关系维护': {
            'zxywlb': 'j',
            'functionNo': '2340230',
            'stdFiled': {
                'ZBLB': 'csdc_exch_board_type',  #转板类别
                'ZQDM': 'csdc_stock_code',  #转板证券代码
                'GCZQZH': 'csdc_stock_account_src',  #过出证券账户
                'GCTGDY': 'csdc_seat_no_out',  #过出托管单元
                'GRZQZH': 'csdc_stock_account_dest',  #过入证券账户
                'GRTGDY': 'csdc_seat_no_dest_deal',  #过入托管单元
                'BYZD4': 'csdc_reserve4',  #备用字段
                'GRZHBS': 'csdc_acct_mark_dest',  #过入账户标识
                'ZBXMBS': 'csdc_acct_limit_buy_mark',  #转板配发账户限买标识
                'ZDGXBS': 'csdc_reg_seat_mark',  #指定/托管关系标识
                'GRSYBS': 'csdc_stk_usedinfo_src',  #过入使用信息标识
                'YWRQ': 'csdc_busi_date',  #业务日期
                'YWPZBS': 'csdc_scan_flag'  #业务凭证报送标识
            },
            'DBSpecialFiled': {}
        }
    }
    BuildCode(sCodePath, intefaceMap, '消息接口 - 跨市场转登记账户及托管单元对应关系维护',
              sOutCodeDir, hsIntefaceMap)
