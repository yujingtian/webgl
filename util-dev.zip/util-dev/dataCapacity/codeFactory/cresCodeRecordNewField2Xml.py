# 本文件用来添加表结构新增字段记录到模块XML文件中
import os
import tools
import time

# 源代码路径
srcPathMap = {}


# 获取对应文件路径
# srcPathMap={{'root':{'服务':[],...},...}
def ReadSrcPath(sCodePath):
    global srcPathMap
    for root, dirs, files in os.walk(sCodePath):
        if 'module.xml' in files:
            srcDirFileMap = {}
            for dir in dirs:
                sDirPath = root + '/' + dir
                sDirPath = sDirPath.replace("\\", "/")
                root = root.replace("\\", "/")
                srcDirFileMap[dir] = os.listdir(sDirPath)
            srcPathMap[root] = srcDirFileMap


# 将修改记录写入xml文件中
def CreateModuleXML(sXmlDirPath, hsIntefaceMap):
    sXmlFilePath = sXmlDirPath + '/module.xml'
    print('开始写入修改记录到' + sXmlFilePath + '\n')
    sText, sEncoding = tools.LoadSrcCode(sXmlFilePath)
    bNeedWrite = True
    with open(srcPathMap[sXmlDirPath], 'w', encoding=sEncoding) as wFile:
        for sLine in sText:
            if bNeedWrite and '<log>' in sLine:
                bNeedWrite = False
                sSerialNumber = sText[sText.index(sLine) + 4]
                sSerialNumber = sSerialNumber.split('<serialNumber>')[-1].split('</serialNumber>')[0]
                if sSerialNumber == hsIntefaceMap['serialNumber']:
                    print('修改记录已存在')
                else:
                    vLine = '''		<log>
                <position></position>
                <date>%(date)s</date>
                <version>%(version)s</version>
                <serialNumber>%(serialNumber)s</serialNumber>
                <user>%(user)s</user>
                <principal></principal>
                <cause></cause>
                <content>%(content)s</content>
                <tester></tester>
            </log>''' % hsIntefaceMap
                    wFile.write(vLine + '\n')
            wFile.write(sLine + '\n')


def FindFieldInAs(sTable):
    print('开始遍历AS,AF文件\n')
    sSelectFromTable = ['select * from ' + sTable,
                        '[select插入表记录][%s]' % sTable,
                        '[插入表记录][%s]' % sTable]
    hsRootandVersionMap = {}
    for root, srcMaps in srcPathMap.items():  # 模块层
        sNums = []
        IntNums = []
        bFound = False  # 是否找到
        for dir, files in srcMaps.items():  # module.xml文件夹层
            if dir == '过程':
                continue
            if bFound:
                break
            for file in files:  # 文件夹层
                if bFound:
                    break
                sFilePath = root + '/' + dir + '/' + file
                sText, sEncoding = tools.LoadSrcCode(sFilePath)
                bCppCode = False  # 是否cpp代码块
                bCommented = False  # 是否块注释
                for sLine in sText:  # 文本行层
                    if bCppCode or '<code>' in sLine:
                        bCppCode = True
                        if '/*' in sLine:
                            bCommented = True
                        if '*/' in sLine:
                            bCommented = False
                        if not bCommented:
                            for sSelct in sSelectFromTable:
                                if sSelct in sLine:
                                    if '//' not in sLine.split(sSelct, 1)[0]:
                                        bFound = True
                                        print(sFilePath)
                                        break
                        if '</code>' in sLine:
                            break
        if bFound:
            for dir, files in srcMaps.items():  # module.xml文件夹层
                for file in files:  # 文件夹层
                    sFilePath = root + '/' + dir + '/' + file
                    sText, sEncoding = tools.LoadSrcCode(sFilePath)
                    for sLine in sText:  # 文本行层
                        if '<version>' in sLine and '</version' in sLine:
                            sTmp = sLine.split('<version>')[-1].split('</version>')[0].strip()
                            if sTmp != '':
                                sTmp = sTmp[1:]
                                sNum = sTmp.split('.')
                                IntNum = int(sTmp.replace('.', ''))
                                sNums.append(sNum)
                                IntNums.append(IntNum)
                            break

        if len(IntNums) != 0:
            index = IntNums.index(max(IntNums))
            sTmp = sNums[index]
            sVersion = 'V' + sTmp[0] + '.' + sTmp[1] + '.' + sTmp[2] + '.' + str(int(sTmp[3]) + 1)
            hsRootandVersionMap[root] = sVersion

    return hsRootandVersionMap


# 代码生成
def BuildCode(sCodePath, hsIntefaceMap):
    if sCodePath.rstrip().endswith('/'):
        sCodePathFind = sCodePath + '原子'
    else:
        sCodePathFind = sCodePath + '/原子'
    ReadSrcPath(sCodePathFind)

    sTableList = hsIntefaceMap['table']
    sFieldList = hsIntefaceMap['field']
    for sTable, sField in zip(sTableList, sFieldList):
        sContent = sTable + '新增字段' + sField
        hsIntefaceMap['content'] = sContent
        hsDirandVersionMap = FindFieldInAs(sTable)
        for dir_, sVersion in hsDirandVersionMap.items():
            hsIntefaceMap['version'] = sVersion
            CreateModuleXML(dir_, hsIntefaceMap)


if __name__ == "__main__":
    sCodePath = 'E:/HundSunCode/客户账户管理系统V22'
    date = time.strftime("%Y-%m-%d %H:%M", time.localtime())
    hsIntefaceMap = {
        'table': ['tTable', 'tTable2'],
        'field': ['tField', 'tField2'],
        'date': date,
        'serialNumber': 'tNum123456',
        'user': 'tUser',
    }
    BuildCode(sCodePath, hsIntefaceMap)
