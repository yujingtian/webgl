package com.hundsun.broker.ftc.pub.service.impl;

import com.hundsun.broker.ftc.pub.service.InnerFtcService;
import com.hundsun.jrescloud.rpc.annotation.CloudComponent;

import java.util.ArrayList;
import java.util.List;

@CloudComponent
public class InnerFtcServiceImpl implements InnerFtcService {
    @Override
    public List<GetBankaccountCancelcheckInnerOutput> getBankaccountCancelcheckInner(GetBankaccountCancelcheckInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public List<GetBankaccountCtsAcctInfoInnerOutput> getBankaccountCtsAcctInfoInner(GetBankaccountCtsAcctInfoInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public List<GetBankaccountMultiInnerOutput> getBankaccountMultiInner(GetBankaccountMultiInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public List<GetBankaccountTransAcctInfoInnerOutput> getBankaccountTransAcctInfoInner(GetBankaccountTransAcctInfoInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public GetBankargQryInnerOutput getBankargQryInner(GetBankargQryInnerInput var1) {
        return new GetBankargQryInnerOutput();
    }

    @Override
    public List<GetBanktransferResultInnerOutput> getBanktransferResultInner(GetBanktransferResultInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public GetFundInfoInnerOutput getFundInfoInner(GetFundInfoInnerInput var1) {
        return new GetFundInfoInnerOutput();
    }

    @Override
    public List<GetFundListByFundAccountInnerOutput> getFundListByFundAccountInner(GetFundListByFundAccountInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public List<GetFundaccountCloseCheckInnerOutput> getFundaccountCloseCheckInner(GetFundaccountCloseCheckInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public GetFundaccountSleepCheckInnerOutput getFundaccountSleepCheckInner(GetFundaccountSleepCheckInnerInput var1) {
        return new GetFundaccountSleepCheckInnerOutput();
    }

    @Override
    public PostBankaccountCtsAcctCancelFromSecuInnerOutput postBankaccountCtsAcctCancelFromSecuInner(PostBankaccountCtsAcctCancelFromSecuInnerInput var1) {
        return new PostBankaccountCtsAcctCancelFromSecuInnerOutput();
    }

    @Override
    public PostBankaccountSyncInnerOutput postBankaccountSyncInner(PostBankaccountSyncInnerInput var1) {
        return new PostBankaccountSyncInnerOutput();
    }

    @Override
    public void putFundaccountSleepInner(PutFundaccountSleepInnerInput var1) {

    }

    @Override
    public GetBankaccountOpenCheckInnerOutput getBankaccountOpenCheckInner(GetBankaccountOpenCheckInnerInput var1) {
        return new GetBankaccountOpenCheckInnerOutput();
    }

    @Override
    public void putFundCommonDealInner(PutFundCommonDealInnerInput var1) {

    }
}
