package com.hundsun.broker.prd.pub.service.impl;

import com.hundsun.broker.prd.pub.service.InnerPrdService;
import com.hundsun.jrescloud.rpc.annotation.CloudComponent;

import java.util.ArrayList;
import java.util.List;

@CloudComponent
public class InnerPrdServiceImpl implements InnerPrdService {
    @Override
    public List<GetFundaccountCancelInnerOutput> getFundaccountCancelInner(GetFundaccountCancelInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public List<GetProdholderCancelInnerOutput> getProdholderCancelInner(GetProdholderCancelInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public List<GetProdholderTransCancelInnerOutput> getProdholderTransCancelInner(GetProdholderTransCancelInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public void putFundaccountInner(PutFundaccountInnerInput var1) {

    }

    @Override
    public List<GetPayaccountCheckInnerOutput> getPayaccountCheckInner(GetPayaccountCheckInnerInput var1) {
        return new ArrayList<>();
    }
}
