package com.hundsun.broker.rpt.pub.service.impl;

import com.hundsun.broker.rpt.pub.service.InnerRptService;
import com.hundsun.jrescloud.rpc.annotation.CloudComponent;

import java.util.ArrayList;
import java.util.List;

@CloudComponent
public class InnerRptServiceImpl implements InnerRptService {
    @Override
    public List<GetActnrfacctorgansendInnerOutput> getActnrfacctorgansendInner(GetActnrfacctorgansendInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public List<GetActnrfacctpersonsendInnerOutput> getActnrfacctpersonsendInner(GetActnrfacctpersonsendInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public GetActstkholderusediffInnerOutput getActstkholderusediffInner(GetActstkholderusediffInnerInput var1) {
        return new GetActstkholderusediffInnerOutput();
    }
}
