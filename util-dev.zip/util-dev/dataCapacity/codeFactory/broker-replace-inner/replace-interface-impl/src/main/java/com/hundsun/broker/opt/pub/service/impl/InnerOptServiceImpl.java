package com.hundsun.broker.opt.pub.service.impl;

import com.hundsun.broker.opt.pub.service.InnerOptService;
import com.hundsun.jrescloud.rpc.annotation.CloudComponent;

import java.util.ArrayList;
import java.util.List;

@CloudComponent
public class InnerOptServiceImpl implements InnerOptService {
    @Override
    public void deleteExchangeclientinfoCancelInner(DeleteExchangeclientinfoCancelInnerInput var1) {

    }

    @Override
    public List<GetExchangeclientinfoCancelCheckInnerOutput> getExchangeclientinfoCancelCheckInner(GetExchangeclientinfoCancelCheckInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public GetFare2QryInnerOutput getFare2QryInner(GetFare2QryInnerInput var1) {
        return new GetFare2QryInnerOutput();
    }
}
