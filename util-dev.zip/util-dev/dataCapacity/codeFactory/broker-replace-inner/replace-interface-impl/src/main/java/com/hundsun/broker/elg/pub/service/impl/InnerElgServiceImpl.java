package com.hundsun.broker.elg.pub.service.impl;

import com.hundsun.broker.elg.pub.service.InnerElgService;
import com.hundsun.jrescloud.rpc.annotation.CloudComponent;

import java.util.ArrayList;
import java.util.List;

@CloudComponent
public class InnerElgServiceImpl implements InnerElgService {
    @Override
    public DeleteClientpreferByIdInnerOutput deleteClientpreferByIdInner(DeleteClientpreferByIdInnerInput var1) {
        return new DeleteClientpreferByIdInnerOutput();
    }

    @Override
    public DeleteDayinitinfoDataInitInnerOutput deleteDayinitinfoDataInitInner(DeleteDayinitinfoDataInitInnerInput var1) {
        return new DeleteDayinitinfoDataInitInnerOutput();
    }

    @Override
    public DeleteOpenRightDetailInnerOutput deleteOpenRightDetailInner(DeleteOpenRightDetailInnerInput var1) {
        return new DeleteOpenRightDetailInnerOutput();
    }

    @Override
    public DeleteStockholderElginfoInnerOutput deleteStockholderElginfoInner(DeleteStockholderElginfoInnerInput var1) {
        return new DeleteStockholderElginfoInnerOutput();
    }

    @Override
    public List<GetBusinAgreementInnerOutput> getBusinAgreementInner(GetBusinAgreementInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public GetBusinQualiargInnerOutput getBusinQualiargInner(GetBusinQualiargInnerInput var1) {
        return new GetBusinQualiargInnerOutput();
    }

    @Override
    public GetClientpreferByIdInnerOutput getClientpreferByIdInner(GetClientpreferByIdInnerInput var1) {
        return new GetClientpreferByIdInnerOutput();
    }

    @Override
    public GetCusQualiResultInnerOutput getCusQualiResultInner(GetCusQualiResultInnerInput var1) {
        return new GetCusQualiResultInnerOutput();
    }

    @Override
    public GetElgTestJourAndPaperInnerOutput getElgTestJourAndPaperInner(GetElgTestJourAndPaperInnerInput var1) {
        return new GetElgTestJourAndPaperInnerOutput();
    }

    @Override
    public GetOptAcctLimitListInnerOutput getOptAcctLimitListInner(GetOptAcctLimitListInnerInput var1) {
        return new GetOptAcctLimitListInnerOutput();
    }

    @Override
    public GetOptClientInfoListInnerOutput getOptClientInfoListInner(GetOptClientInfoListInnerInput var1) {
        return new GetOptClientInfoListInnerOutput();
    }

    @Override
    public List<GetProductInnerOutput> getProductInner(GetProductInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public DeleteProductInnerOutput deleteProductInner(DeleteProductInnerInput var1) {
        return new DeleteProductInnerOutput();
    }

    @Override
    public GetQueryIsTradingDayInnerOutput getQueryIsTradingDayInner(GetQueryIsTradingDayInnerInput var1) {
        return new GetQueryIsTradingDayInnerOutput();
    }

    @Override
    public List<GetSstaccountInnerOutput> getSstaccountInner(GetSstaccountInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public List<GetStockAcctCancelValidateInnerOutput> getStockAcctCancelValidateInner(GetStockAcctCancelValidateInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public PostAgreementSignInnerOutput postAgreementSignInner(PostAgreementSignInnerInput var1) {
        return new PostAgreementSignInnerOutput();
    }

    @Override
    public void postAutoBondExportInner(PostAutoBondExportInnerInput var1) {

    }

    @Override
    public void postCreditQuotaUpdateInner(PostCreditQuotaUpdateInnerInput var1) {

    }

    @Override
    public List<PostCusPreCheckInnerOutput> postCusPreCheckInner(PostCusPreCheckInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public PostDayinitinfoDataToprevInnerOutput postDayinitinfoDataToprevInner(PostDayinitinfoDataToprevInnerInput var1) {
        return new PostDayinitinfoDataToprevInnerOutput();
    }

    @Override
    public PostDayinitinfoSqlInnerOutput postDayinitinfoSqlInner(PostDayinitinfoSqlInnerInput var1) {
        return new PostDayinitinfoSqlInnerOutput();
    }

    @Override
    public PostElgAccountOpenSyncInnerOutput postElgAccountOpenSyncInner(PostElgAccountOpenSyncInnerInput var1) {
        return new PostElgAccountOpenSyncInnerOutput();
    }

    @Override
    public PostElgsstrestradeacctInnerOutput postElgsstrestradeacctInner(PostElgsstrestradeacctInnerInput var1) {
        return new PostElgsstrestradeacctInnerOutput();
    }

    @Override
    public PostOpenRightDetailInnerOutput postOpenRightDetailInner(PostOpenRightDetailInnerInput var1) {
        return new PostOpenRightDetailInnerOutput();
    }

    @Override
    public PostOptclientinfoQuotaInnerOutput postOptclientinfoQuotaInner(PostOptclientinfoQuotaInnerInput var1) {
        return new PostOptclientinfoQuotaInnerOutput();
    }

    @Override
    public PostProductInnerOutput postProductInner(PostProductInnerInput var1) {
        return new PostProductInnerOutput();
    }

    @Override
    public List<PostProductRulesCheckInnerOutput> postProductRulesCheckInner(PostProductRulesCheckInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public PostProductRulesConfirmInnerOutput postProductRulesConfirmInner(PostProductRulesConfirmInnerInput var1) {
        return new PostProductRulesConfirmInnerOutput();
    }

    @Override
    public List<PostProductcheckOutInnerOutput> postProductcheckOutInner(PostProductcheckOutInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public PostRefacctreportInnerOutput postRefacctreportInner(PostRefacctreportInnerInput var1) {
        return new PostRefacctreportInnerOutput();
    }

    @Override
    public PostSzOptSyncShDataInnerOutput postSzOptSyncShDataInner(PostSzOptSyncShDataInnerInput var1) {
        return new PostSzOptSyncShDataInnerOutput();
    }

    @Override
    public PutClientPreferPushInnerOutput putClientPreferPushInner(PutClientPreferPushInnerInput var1) {
        return new PutClientPreferPushInnerOutput();
    }

    @Override
    public PutDayinitinfoBatchDealInnerOutput putDayinitinfoBatchDealInner(PutDayinitinfoBatchDealInnerInput var1) {
        return new PutDayinitinfoBatchDealInnerOutput();
    }

    @Override
    public PutDayinitinfoDateChangeInnerOutput putDayinitinfoDateChangeInner(PutDayinitinfoDateChangeInnerInput var1) {
        return new PutDayinitinfoDateChangeInnerOutput();
    }

    @Override
    public PutRightsExpireInnerOutput putRightsExpireInner(PutRightsExpireInnerInput var1) {
        return new PutRightsExpireInnerOutput();
    }

    @Override
    public PutRiskLevelCreditCheckInnerOutput putRiskLevelCreditCheckInner(PutRiskLevelCreditCheckInnerInput var1) {
        return new PutRiskLevelCreditCheckInnerOutput();
    }

    @Override
    public PostProdAgreementInnerOutput postProdAgreementInner(PostProdAgreementInnerInput var1) {
        return new PostProdAgreementInnerOutput();
    }

    @Override
    public List<GetProdAgreementInnerOutput> getProdAgreementInner(GetProdAgreementInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public List<GetUnitycreditClientcrdtInnerOutput> getUnitycreditClientcrdtInner(GetUnitycreditClientcrdtInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public PutUnityCreditCrdtLevelSyncInnerOutput putUnityCreditCrdtLevelSyncInner(PutUnityCreditCrdtLevelSyncInnerInput var1) {
        return new PutUnityCreditCrdtLevelSyncInnerOutput();
    }

    @Override
    public DeleteGemacctinfoCancelInnerOutput deleteGemacctinfoCancelInner(DeleteGemacctinfoCancelInnerInput var1) {
        return new DeleteGemacctinfoCancelInnerOutput();
    }

    @Override
    public PostStbstdholderSstaccountInnerOutput postStbstdholderSstaccountInner(PostStbstdholderSstaccountInnerInput var1) {
        return new PostStbstdholderSstaccountInnerOutput();
    }
}
