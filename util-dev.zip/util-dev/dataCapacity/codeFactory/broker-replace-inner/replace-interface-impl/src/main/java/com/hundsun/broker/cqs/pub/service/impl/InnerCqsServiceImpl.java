package com.hundsun.broker.cqs.pub.service.impl;

import com.hundsun.broker.cqs.pub.service.InnerCqsService;
import com.hundsun.jrescloud.rpc.annotation.CloudComponent;

import java.util.ArrayList;
import java.util.List;

@CloudComponent
public class InnerCqsServiceImpl implements InnerCqsService {
    @Override
    public GetAmsagreesignHisPageInnerOutput getAmsagreesignHisPageInner(GetAmsagreesignHisPageInnerInput var1) {
        return new GetAmsagreesignHisPageInnerOutput();
    }

    @Override
    public GetAmsepapersignHisPageInnerOutput getAmsepapersignHisPageInner(GetAmsepapersignHisPageInnerInput var1) {
        return new GetAmsepapersignHisPageInnerOutput();
    }

    @Override
    public List<GetCmstwentyassetInnerOutput> getCmstwentyassetInner(GetCmstwentyassetInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public GetCqsstatementrecordsInnerOutput getCqsstatementrecordsInner(GetCqsstatementrecordsInnerInput var1) {
        return new GetCqsstatementrecordsInnerOutput();
    }

    @Override
    public List<GetCqssynctablestructureInnerOutput> getCqssynctablestructureInner(GetCqssynctablestructureInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public GetElgbusinassetInnerOutput getElgbusinassetInner(GetElgbusinassetInnerInput var1) {
        return new GetElgbusinassetInnerOutput();
    }

    @Override
    public List<GetElgclientpreferjourInnerOutput> getElgclientpreferjourInner(GetElgclientpreferjourInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public List<GetElghisassetInnerOutput> getElghisassetInner(GetElghisassetInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public List<GetElgstibclientassetsendInnerOutput> getElgstibclientassetsendInner(GetElgstibclientassetsendInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public List<GetElgtestjourInnerOutput> getElgtestjourInner(GetElgtestjourInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public List<GetPrddataprodrealInnerOutput> getPrddataprodrealInner(GetPrddataprodrealInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public GetSesblobfileDataInnerOutput getSesblobfileDataInner(GetSesblobfileDataInnerInput var1) {
        return new GetSesblobfileDataInnerOutput();
    }

    @Override
    public GetSesstkcodeInnerOutput getSesstkcodeInner(GetSesstkcodeInnerInput var1) {
        return new GetSesstkcodeInnerOutput();
    }

    @Override
    public PostCqsdeliververifyInnerOutput postCqsdeliververifyInner(PostCqsdeliververifyInnerInput var1) {
        return new PostCqsdeliververifyInnerOutput();
    }

    @Override
    public PostCqsstatementInnerOutput postCqsstatementInner(PostCqsstatementInnerInput var1) {
        return new PostCqsstatementInnerOutput();
    }

    @Override
    public PutArgInnerOutput putArgInner(PutArgInnerInput var1) {
        return new PutArgInnerOutput();
    }

    @Override
    public void putHsfunctionCacheInner(PutHsfunctionCacheInnerInput var1) {

    }
}
