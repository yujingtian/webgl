package com.hundsun.broker.dfzq.pub.service.impl;

import com.hundsun.broker.dfzq.pub.service.InnerDfzqService;
import com.hundsun.jrescloud.rpc.annotation.CloudComponent;

import java.util.ArrayList;
import java.util.List;

@CloudComponent
public class InnerDfzqServiceImpl implements InnerDfzqService {
    @Override
    public List<GetBankaccountInnerOutput> getBankaccountInner(GetBankaccountInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public PostBankCtsAcctOpenInnerOutput postBankCtsAcctOpenInner(PostBankCtsAcctOpenInnerInput var1) {
        return new PostBankCtsAcctOpenInnerOutput();
    }

    @Override
    public PostBankaccountAcctOpenInnerOutput postBankaccountAcctOpenInner(PostBankaccountAcctOpenInnerInput var1) {
        return new PostBankaccountAcctOpenInnerOutput();
    }

    @Override
    public List<GetAdviserAccountCancelCheckInnerOutput> getAdviserAccountCancelCheckInner(GetAdviserAccountCancelCheckInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public List<GetAdviserTransAccountCancelCheckInnerOutput> getAdviserTransAccountCancelCheckInner(GetAdviserTransAccountCancelCheckInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public List<GetProdHolderListInnerOutput> getProdHolderListInner(GetProdHolderListInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public DeleteBankCtsAcctInnerOutput deleteBankCtsAcctInner(DeleteBankCtsAcctInnerInput var1) {
        return new DeleteBankCtsAcctInnerOutput();
    }

    @Override
    public DeleteBankaccountAcctInnerOutput deleteBankaccountAcctInner(DeleteBankaccountAcctInnerInput var1) {
        return new DeleteBankaccountAcctInnerOutput();
    }

    @Override
    public GetfundAssetCertificationInnerOutput getfundAssetCertificationInner(GetfundAssetCertificationInnerInput var1) {
        return new GetfundAssetCertificationInnerOutput();
    }

    @Override
    public List<GetBankaccountCtsAcctInnerOutput> getBankaccountCtsAcctInner(GetBankaccountCtsAcctInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public List<GetBankaccountAcctInnerOutput> getBankaccountAcctInner(GetBankaccountAcctInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public List<GetFundCustBalanceInnerOutput> getFundCustBalanceInner(GetFundCustBalanceInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public List<GetFundListByFundAccountInnerOutput> getFundListByFundAccountInner(GetFundListByFundAccountInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public List<GetSysConfigSesInnerOutput> getSysConfigSesInner(GetSysConfigSesInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public GetBankaccountCancelcheckInnerOutput getBankaccountCancelcheckInner(GetBankaccountCancelcheckInnerInput var1) {
        return new GetBankaccountCancelcheckInnerOutput();
    }

    @Override
    public GetFundaccountCloseCheckInnerOutput getFundaccountCloseCheckInner(GetFundaccountCloseCheckInnerInput var1) {
        return new GetFundaccountCloseCheckInnerOutput();
    }

    @Override
    public List<GetSysConfigCrtInnerOutput> getSysConfigCrtInner(GetSysConfigCrtInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public List<GetSysConfigOptInnerOutput> getSysConfigOptInner(GetSysConfigOptInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public PostFundSaveFromSecuInnerOutput postFundSaveFromSecuInner(PostFundSaveFromSecuInnerInput var1) {
        return new PostFundSaveFromSecuInnerOutput();
    }

    @Override
    public PostShortMessageInnerOutput postShortMessageInner(PostShortMessageInnerInput var1) {
        return new PostShortMessageInnerOutput();
    }

    @Override
    public PostSendEmailInnerOutput postSendEmailInner(PostSendEmailInnerInput var1) {
        return new PostSendEmailInnerOutput();
    }

    @Override
    public PostSendEmailByFileInnerOutput postSendEmailByFileInner(PostSendEmailByFileInnerInput var1) {
        return new PostSendEmailByFileInnerOutput();
    }

    @Override
    public GetJsdCheckPasswordInnerOutput getJsdCheckPasswordInner(GetJsdCheckPasswordInnerInput var1) {
        return new GetJsdCheckPasswordInnerOutput();
    }

    @Override
    public List<GetClientInfoEiamsInnerOutput> getClientInfoEiamsInner(GetClientInfoEiamsInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public GetClientpreferMatchInnerOutput getClientpreferMatchInner(GetClientpreferMatchInnerInput var1) {
        return new GetClientpreferMatchInnerOutput();
    }

    @Override
    public GetCodeInnerOutput getCodeInner(GetCodeInnerInput var1) {
        return new GetCodeInnerOutput();
    }

    @Override
    public List<GetFundaccountCancelInnerOutput> getFundaccountCancelInner(GetFundaccountCancelInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public List<GetFundaccountInbusinessInnerOutput> getFundaccountInbusinessInner(GetFundaccountInbusinessInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public PostProdholderAddInnerOutput postProdholderAddInner(PostProdholderAddInnerInput var1) {
        return new PostProdholderAddInnerOutput();
    }

    @Override
    public GetProdholderQueryInnerOutput getProdholderQueryInner(GetProdholderQueryInnerInput var1) {
        return new GetProdholderQueryInnerOutput();
    }

    @Override
    public List<GetSysConfigZxInnerOutput> getSysConfigZxInner(GetSysConfigZxInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public PutStockHolderOpenFrozenOutput putStockHolderOpenFrozen(PutStockHolderOpenFrozenInput var1) {
        return new PutStockHolderOpenFrozenOutput();
    }

    @Override
    public DeleteProdholderAcctInnerOutput deleteProdholderAcctInner(DeleteProdholderAcctInnerInput var1) {
        return new DeleteProdholderAcctInnerOutput();
    }

    @Override
    public GetFundInfoInnerOutput getFundInfoInner(GetFundInfoInnerInput var1) {
        return new GetFundInfoInnerOutput();
    }

    @Override
    public PutProdholderSynModInnerOutput putProdholderSynModInner(PutProdholderSynModInnerInput var1) {
        return new PutProdholderSynModInnerOutput();
    }

    @Override
    public void putFundaccountInner(PutFundaccountInnerInput var1) {

    }

    @Override
    public List<GetProdholderTransCancelInnerOutput> getProdholderTransCancelInner(GetProdholderTransCancelInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public List<GetProdholderCancelInnerOutput> getProdholderCancelInner(GetProdholderCancelInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public PutProdholderFrozenInnerOutput putProdholderFrozenInner(PutProdholderFrozenInnerInput var1) {
        return new PutProdholderFrozenInnerOutput();
    }

    @Override
    public PostProdVideoInnerOutput postProdVideoInner(PostProdVideoInnerInput var1) {
        return new PostProdVideoInnerOutput();
    }

    @Override
    public List<GetBankReturnInfoInnerOutput> getBankReturnInfoInner(GetBankReturnInfoInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public List<GetPriceFromInformationCenterInnerOutput> getPriceFromInformationCenterInner(GetPriceFromInformationCenterInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public void putPriceJzjyInner(PutPriceJzjyInnerInput var1) {

    }

    @Override
    public List<GetFundaccountCancelCheckInnerOutput> getFundaccountCancelCheckInner(GetFundaccountCancelCheckInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public List<GetExchangeclientinfoCancelCheckInnerOutput> getExchangeclientinfoCancelCheckInner(GetExchangeclientinfoCancelCheckInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public void deleteExchangeclientinfoCancelInner(DeleteExchangeclientinfoCancelInnerInput var1) {

    }

    @Override
    public void putFundaccountCancelInner(PutFundaccountCancelInnerInput var1) {

    }
}
