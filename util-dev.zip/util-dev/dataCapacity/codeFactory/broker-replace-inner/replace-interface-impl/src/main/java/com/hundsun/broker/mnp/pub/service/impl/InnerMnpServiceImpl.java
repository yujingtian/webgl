package com.hundsun.broker.mnp.pub.service.impl;

import com.hundsun.broker.mnp.pub.service.InnerMnpService;
import com.hundsun.jrescloud.rpc.annotation.CloudComponent;

import java.util.ArrayList;
import java.util.List;

@CloudComponent
public class InnerMnpServiceImpl implements InnerMnpService {
    @Override
    public GetNoticelogInnerOutput getNoticelogInner(GetNoticelogInnerInput var1) {
        return new GetNoticelogInnerOutput();
    }

    @Override
    public DeleteDayinitinfoDatainitInnerOutput deleteDayinitinfoDatainitInner(DeleteDayinitinfoDatainitInnerInput var1) {
        return new DeleteDayinitinfoDatainitInnerOutput();
    }

    @Override
    public PostNoticelogOneGenerateInnerOutput postNoticelogOneGenerateInner(PostNoticelogOneGenerateInnerInput var1) {
        return new PostNoticelogOneGenerateInnerOutput();
    }

    @Override
    public PostNoticelogToCopyAddressInnerOutput postNoticelogToCopyAddressInner(PostNoticelogToCopyAddressInnerInput var1) {
        return new PostNoticelogToCopyAddressInnerOutput();
    }

    @Override
    public PutDayinitinfoDateChangeInnerOutput putDayinitinfoDateChangeInner(PutDayinitinfoDateChangeInnerInput var1) {
        return new PutDayinitinfoDateChangeInnerOutput();
    }

    @Override
    public PostNoticelogOneSendInnerOutput postNoticelogOneSendInner(PostNoticelogOneSendInnerInput var1) {
        return new PostNoticelogOneSendInnerOutput();
    }

    @Override
    public PostNoticelogGenerateInnerOutput postNoticelogGenerateInner(PostNoticelogGenerateInnerInput var1) {
        return new PostNoticelogGenerateInnerOutput();
    }

    @Override
    public List<GetNoticeargInnerOutput> getNoticeargInner(GetNoticeargInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public PostNoticelogBatchGenerateInnerOutput postNoticelogBatchGenerateInner(PostNoticelogBatchGenerateInnerInput var1) {
        return new PostNoticelogBatchGenerateInnerOutput();
    }

    @Override
    public List<GetNoticelogPollingInnerOutput> getNoticelogPollingInner(GetNoticelogPollingInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public PutNoticelogBatchAuditInnerOutput putNoticelogBatchAuditInner(PutNoticelogBatchAuditInnerInput var1) {
        return new PutNoticelogBatchAuditInnerOutput();
    }

    @Override
    public void putNoticelogWriteBackInner(PutNoticelogWriteBackInnerInput var1) {

    }

    @Override
    public List<GetNoticelogKindInnerOutput> getNoticelogKindInner(GetNoticelogKindInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public List<GetNoticetemplateInnerOutput> getNoticetemplateInner(GetNoticetemplateInnerInput var1) {
        return new ArrayList<>();
    }
}
