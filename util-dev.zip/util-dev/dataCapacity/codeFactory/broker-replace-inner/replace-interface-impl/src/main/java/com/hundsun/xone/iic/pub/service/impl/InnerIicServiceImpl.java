package com.hundsun.xone.iic.pub.service.impl;

import com.hundsun.jrescloud.rpc.annotation.CloudComponent;
import com.hundsun.xone.iic.pub.service.InnerIicService;

import java.util.ArrayList;
import java.util.List;

@CloudComponent
public class InnerIicServiceImpl implements InnerIicService {
    @Override
    public void deleteActAlreadyExistMapperInner(DeleteActAlreadyExistMapperInnerInput var1) {

    }

    @Override
    public void deleteAuthuserctrlAutoUnlockInner(DeleteAuthuserctrlAutoUnlockInnerInput var1) {

    }

    @Override
    public DeleteAuthusertransInnerOutput deleteAuthusertransInner(DeleteAuthusertransInnerInput var1) {
        return new DeleteAuthusertransInnerOutput();
    }

    @Override
    public void deleteAuthvaskeyInner(DeleteAuthvaskeyInnerInput var1) {

    }

    @Override
    public DeleteCachedAuthuserMapperInnerOutput deleteCachedAuthuserMapperInner(DeleteCachedAuthuserMapperInnerInput var1) {
        return new DeleteCachedAuthuserMapperInnerOutput();
    }

    @Override
    public DeleteDayinitinfoDataInitInnerOutput deleteDayinitinfoDataInitInner(DeleteDayinitinfoDataInitInnerInput var1) {
        return new DeleteDayinitinfoDataInitInnerOutput();
    }

    @Override
    public DeleteHistoryLogJourInnerOutput deleteHistoryLogJourInner(DeleteHistoryLogJourInnerInput var1) {
        return new DeleteHistoryLogJourInnerOutput();
    }

    @Override
    public void getAuthuserCheckPasswordInner(GetAuthuserCheckPasswordInnerInput var1) {

    }

    @Override
    public GetAuthuserCustIdInnerOutput getAuthuserCustIdInner(GetAuthuserCustIdInnerInput var1) {
        return new GetAuthuserCustIdInnerOutput();
    }

    @Override
    public List<GetAuthuserctrlPasswordErrorsInnerOutput> getAuthuserctrlPasswordErrorsInner(GetAuthuserctrlPasswordErrorsInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public GetAuthvaskeyInnerOutput getAuthvaskeyInner(GetAuthvaskeyInnerInput var1) {
        return new GetAuthvaskeyInnerOutput();
    }

    @Override
    public PostAuthuserOpenInnerOutput postAuthuserOpenInner(PostAuthuserOpenInnerInput var1) {
        return new PostAuthuserOpenInnerOutput();
    }

    @Override
    public PostAuthusertransInnerOutput postAuthusertransInner(PostAuthusertransInnerInput var1) {
        return new PostAuthusertransInnerOutput();
    }

    @Override
    public void postAuthvaskeyInner(PostAuthvaskeyInnerInput var1) {

    }

    @Override
    public PostFullAuthuserActInfoSyncInnerOutput postFullAuthuserActInfoSyncInner(PostFullAuthuserActInfoSyncInnerInput var1) {
        return new PostFullAuthuserActInfoSyncInnerOutput();
    }

    @Override
    public PostUfAuthuserOpenInnerOutput postUfAuthuserOpenInner(PostUfAuthuserOpenInnerInput var1) {
        return new PostUfAuthuserOpenInnerOutput();
    }

    @Override
    public PutAuthuserClientSignInnerOutput putAuthuserClientSignInner(PutAuthuserClientSignInnerInput var1) {
        return new PutAuthuserClientSignInnerOutput();
    }

    @Override
    public PutAuthuserDoubleFactorInnerOutput putAuthuserDoubleFactorInner(PutAuthuserDoubleFactorInnerInput var1) {
        return new PutAuthuserDoubleFactorInnerOutput();
    }

    @Override
    public PutAuthuserInnerOutput putAuthuserInner(PutAuthuserInnerInput var1) {
        return new PutAuthuserInnerOutput();
    }

    @Override
    public PutAuthuserModifyPasswordInnerOutput putAuthuserModifyPasswordInner(PutAuthuserModifyPasswordInnerInput var1) {
        return new PutAuthuserModifyPasswordInnerOutput();
    }

    @Override
    public PutAuthuserResetPasswordInnerOutput putAuthuserResetPasswordInner(PutAuthuserResetPasswordInnerInput var1) {
        return new PutAuthuserResetPasswordInnerOutput();
    }

    @Override
    public void putAuthuserctrlClearInner(PutAuthuserctrlClearInnerInput var1) {

    }

    @Override
    public PutAuthusertransInnerOutput putAuthusertransInner(PutAuthusertransInnerInput var1) {
        return new PutAuthusertransInnerOutput();
    }

    @Override
    public PutDayinitinfoDateChangeInnerOutput putDayinitinfoDateChangeInner(PutDayinitinfoDateChangeInnerInput var1) {
        return new PutDayinitinfoDateChangeInnerOutput();
    }

    @Override
    public DeleteAuthuserCacheInnerOutput deleteAuthuserCacheInner(DeleteAuthuserCacheInnerInput var1) {
        return new DeleteAuthuserCacheInnerOutput();
    }

    @Override
    public GetAuthuserTokenInnerOutput getAuthuserTokenInner(GetAuthuserTokenInnerInput var1) {
        return new GetAuthuserTokenInnerOutput();
    }
}
