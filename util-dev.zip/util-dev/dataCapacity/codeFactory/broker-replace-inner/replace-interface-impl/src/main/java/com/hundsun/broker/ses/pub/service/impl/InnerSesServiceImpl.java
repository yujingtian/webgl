package com.hundsun.broker.ses.pub.service.impl;

import com.hundsun.broker.ses.pub.service.InnerSesService;
import com.hundsun.jrescloud.rpc.annotation.CloudComponent;

import java.util.ArrayList;
import java.util.List;

@CloudComponent
public class InnerSesServiceImpl implements InnerSesService {
    @Override
    public List<GetFundaccountCancelCheckInnerOutput> getFundaccountCancelCheckInner(GetFundaccountCancelCheckInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public List<GetFunddetailjourInnerOutput> getFunddetailjourInner(GetFunddetailjourInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public List<GetStockholderCancelCheckInnerOutput> getStockholderCancelCheckInner(GetStockholderCancelCheckInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public List<GetStockholderInnerOutput> getStockholderInner(GetStockholderInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public PostEntrustRegisterInnerOutput postEntrustRegisterInner(PostEntrustRegisterInnerInput var1) {
        return new PostEntrustRegisterInnerOutput();
    }

    @Override
    public PutFundaccountActiveInnerOutput putFundaccountActiveInner(PutFundaccountActiveInnerInput var1) {
        return new PutFundaccountActiveInnerOutput();
    }

    @Override
    public PutFundaccountCancelInnerOutput putFundaccountCancelInner(PutFundaccountCancelInnerInput var1) {
        return new PutFundaccountCancelInnerOutput();
    }

    @Override
    public PutStockholderActiveInnerOutput putStockholderActiveInner(PutStockholderActiveInnerInput var1) {
        return new PutStockholderActiveInnerOutput();
    }

    @Override
    public PutStockholderCancelInnerOutput putStockholderCancelInner(PutStockholderCancelInnerInput var1) {
        return new PutStockholderCancelInnerOutput();
    }
}
