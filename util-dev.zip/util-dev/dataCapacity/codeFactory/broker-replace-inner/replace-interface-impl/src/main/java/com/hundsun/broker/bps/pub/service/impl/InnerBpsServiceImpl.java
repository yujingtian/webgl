package com.hundsun.broker.bps.pub.service.impl;

import com.hundsun.broker.bps.pub.service.InnerBpsService;
import com.hundsun.jrescloud.rpc.annotation.CloudAuth;
import com.hundsun.jrescloud.rpc.annotation.CloudComponent;

import java.util.ArrayList;
import java.util.List;

@CloudAuth
@CloudComponent
public class InnerBpsServiceImpl implements InnerBpsService {
    @Override
    public DeleteBpsClientPreOpenInnerOutput deleteBpsClientPreOpenInner(DeleteBpsClientPreOpenInnerInput var1) {
        return new DeleteBpsClientPreOpenInnerOutput();
    }

    @Override
    public GetBpsAcptBusindataInnerOutput getBpsAcptBusindataInner(GetBpsAcptBusindataInnerInput var1) {
        return new GetBpsAcptBusindataInnerOutput();
    }

    @Override
    public GetBpsAcptformInfoInnerOutput getBpsAcptformInfoInner(GetBpsAcptformInfoInnerInput var1) {
        return new GetBpsAcptformInfoInnerOutput();
    }

    @Override
    public List<GetBpsAcptformListInnerOutput> getBpsAcptformListInner(GetBpsAcptformListInnerInput var1) {
        return new ArrayList<GetBpsAcptformListInnerOutput>();
    }

    @Override
    public GetBpsClientPreOpenInnerOutput getBpsClientPreOpenInner(GetBpsClientPreOpenInnerInput var1) {
        return new GetBpsClientPreOpenInnerOutput();
    }

    @Override
    public PostBpsAcptbusinSubmitInnerOutput postBpsAcptbusinSubmitInner(PostBpsAcptbusinSubmitInnerInput var1) {
        return new PostBpsAcptbusinSubmitInnerOutput();
    }

    @Override
    public PostBpsAcptformByOnceInnerOutput postBpsAcptformByOnceInner(PostBpsAcptformByOnceInnerInput var1) {
        return new PostBpsAcptformByOnceInnerOutput();
    }

    @Override
    public PostBpsAcptformRegistInnerOutput postBpsAcptformRegistInner(PostBpsAcptformRegistInnerInput var1) {
        return new PostBpsAcptformRegistInnerOutput();
    }

    @Override
    public PostBpsClientPreOpenInnerOutput postBpsClientPreOpenInner(PostBpsClientPreOpenInnerInput var1) {
        return new PostBpsClientPreOpenInnerOutput();
    }
}
