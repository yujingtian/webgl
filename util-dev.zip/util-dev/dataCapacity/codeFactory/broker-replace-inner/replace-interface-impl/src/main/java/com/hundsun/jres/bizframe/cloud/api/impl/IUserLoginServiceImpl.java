package com.hundsun.jres.bizframe.cloud.api.impl;

import com.hundsun.jres.bizframe.bean.ChangeUserOutSiteBean;
import com.hundsun.jres.bizframe.bean.GetCurrUserIdByTokenBean;
import com.hundsun.jres.bizframe.bean.MenuTreeForGuofuBean;
import com.hundsun.jres.bizframe.bean.MenuTreeNode;
import com.hundsun.jres.bizframe.bean.RpcBean;
import com.hundsun.jres.bizframe.bean.UserAuthMenuSearchBean;
import com.hundsun.jres.bizframe.cloud.api.IUserLoginService;
import com.hundsun.jres.bizframe.bean.IndexInfoBean;
import com.hundsun.jres.bizframe.bean.LoginBean;
import com.hundsun.jres.bizframe.bean.MenuTreeNodeForMVC;
import com.hundsun.jres.bizframe.bean.TenantLogoInfoBean;
import com.hundsun.jres.bizframe.cloud.bean.ResultBean;
import com.hundsun.jres.bizframe.common.util.Key;
import com.hundsun.jres.bizframe.vo.LoginDto;
import com.hundsun.jres.bizframe.vo.ReturnDto;
import com.hundsun.jres.bizframe.vo.VeriyCodeResultDto;
import com.hundsun.jrescloud.rpc.annotation.CloudComponent;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@CloudComponent
public class IUserLoginServiceImpl implements IUserLoginService {

    @Override
    public LoginDto login(LoginBean var1) {
        return new LoginDto();
    }

    @Override
    public ReturnDto getEmailVerificationCode(LoginBean var1) {
        return new ReturnDto();
    }

    @Override
    public LoginDto freePasswordLogin(LoginBean var1) {
        return new LoginDto();
    }

    @Override
    public ReturnDto relogin(LoginBean var1) {
        return new ReturnDto();
    }

    @Override
    public ReturnDto logout(LoginBean var1) {
        return new ReturnDto();
    }

    @Override
    public List<MenuTreeNode> getUserAuthMenus(UserAuthMenuSearchBean var1) {
        return new ArrayList<>();
    }

    @Override
    public boolean loginHasValidateCode() {
        return true;
    }

    @Override
    public Key getSecurityKey(String var1, String var2) {
        return new Key();
    }

    @Override
    public List<MenuTreeForGuofuBean> getUserAuthMenusForGuoFu(LoginBean var1) {
        return new ArrayList<>();
    }

    @Override
    public boolean checkPwdExpired(LoginBean var1) {
        return true;
    }

    @Override
    public Integer expiredDays(LoginBean var1) {
        return 20260202;
    }

    @Override
    public ReturnDto createUserToken(LoginBean var1) {
        return new ReturnDto();
    }

    @Override
    public ReturnDto checkUserPwd(LoginBean var1) {
        return new ReturnDto();
    }

    @Override
    public List<MenuTreeNodeForMVC> getUserAuthMenusForMVC(LoginBean var1) {
        return new ArrayList<>();
    }

    @Override
    public Map<String, Object> getCheckedPwdStandard(String var1) {
        return new HashMap<>();
    }

    @Override
    public ReturnDto kickout(String var1) {
        return new ReturnDto();
    }

    @Override
    public IndexInfoBean getIndexInfo(LoginBean var1) {
        return new IndexInfoBean();
    }

    @Override
    public ReturnDto checkCurrUser(LoginBean var1) {
        return new ReturnDto();
    }

    @Override
    public LoginDto userTenantChange(LoginBean var1) {
        return new LoginDto();
    }

    @Override
    public ReturnDto languageChange(String var1, String var2) {
        return new ReturnDto();
    }

    @Override
    public VeriyCodeResultDto getVerifyCode() {
        return new VeriyCodeResultDto();
    }

    @Override
    public Boolean isMeetPwdStrength(String var1, String var2) {
        return true;
    }

    @Override
    public ResultBean isSessoinTimeout(String var1) {
        return new ResultBean();
    }

    @Override
    public List<MenuTreeNode> getNewUserAuthMenus(UserAuthMenuSearchBean var1) {
        return new ArrayList<>();
    }

    @Override
    public ReturnDto thirdLogin(RpcBean var1) {
        return new ReturnDto();
    }

    @Override
    public TenantLogoInfoBean getTenantLogo(LoginBean var1) {
        return new TenantLogoInfoBean();
    }

    @Override
    public boolean isMatchUserNameAndPwd(LoginBean var1) {
        return true;
    }

    @Override
    public String getUserAvatar(String var1) {
        return "admin";
    }

    @Override
    public ReturnDto checkUserPwdForUF3(LoginBean var1) {
        return new ReturnDto();
    }

    @Override
    public ReturnDto getCurrUserIdByToken(GetCurrUserIdByTokenBean var1) {
        return new ReturnDto();
    }

    @Override
    public List<MenuTreeNode> getUserSystems(UserAuthMenuSearchBean var1) {
        return new ArrayList<>();
    }

    @Override
    public ReturnDto initUserLoginRight(LoginBean var1) {
        return new ReturnDto();
    }

    @Override
    public ReturnDto changeUserOutSite(ChangeUserOutSiteBean var1) {
        return new ReturnDto();
    }

    @Override
    public LoginDto getCurrUserInfoByToken(LoginBean var1) {
        return new LoginDto();
    }
}
