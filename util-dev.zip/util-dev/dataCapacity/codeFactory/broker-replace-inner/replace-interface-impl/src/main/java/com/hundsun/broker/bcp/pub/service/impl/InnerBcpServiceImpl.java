package com.hundsun.broker.bcp.pub.service.impl;

import com.hundsun.broker.bcp.pub.service.InnerBcpService;
import com.hundsun.jrescloud.rpc.annotation.CloudAuth;
import com.hundsun.jrescloud.rpc.annotation.CloudComponent;

import java.util.ArrayList;
import java.util.List;

@CloudAuth
@CloudComponent
public class InnerBcpServiceImpl implements InnerBcpService {

    @Override
    public List<GetDataswapAcodeQueryInnerOutput> getDataswapAcodeQueryInner(GetDataswapAcodeQueryInnerInput var1) {
        return new ArrayList<GetDataswapAcodeQueryInnerOutput>();
    }

    @Override
    public List<GetDataswapHolderQueryInnerOutput> getDataswapHolderQueryInner(GetDataswapHolderQueryInnerInput var1) {
        return new ArrayList<GetDataswapHolderQueryInnerOutput>();
    }

    @Override
    public PutDataswapAcodeCheckInnerOutput putDataswapAcodeCheckInner(PutDataswapAcodeCheckInnerInput var1) {
        return new PutDataswapAcodeCheckInnerOutput();
    }

    @Override
    public PutDataswapGeneralCheckInnerOutput putDataswapGeneralCheckInner(PutDataswapGeneralCheckInnerInput var1) {
        return new PutDataswapGeneralCheckInnerOutput();
    }

    @Override
    public PutDataswapHolderCheckInnerOutput putDataswapHolderCheckInner(PutDataswapHolderCheckInnerInput var1) {
        return new PutDataswapHolderCheckInnerOutput();
    }
}
