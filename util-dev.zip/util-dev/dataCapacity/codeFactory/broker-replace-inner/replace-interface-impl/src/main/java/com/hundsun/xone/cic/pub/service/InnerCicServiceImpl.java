package com.hundsun.xone.cic.pub.service;

import com.hundsun.jrescloud.rpc.annotation.CloudAuth;
import com.hundsun.jrescloud.rpc.annotation.CloudComponent;

import java.util.ArrayList;
import java.util.List;

@CloudAuth
@CloudComponent
public class InnerCicServiceImpl implements InnerCicService{
    @Override
    public DeleteAdditionidInnerOutput deleteAdditionidInner(DeleteAdditionidInnerInput var1) {
        return new DeleteAdditionidInnerOutput();
    }

    @Override
    public DeleteAddressInnerOutput deleteAddressInner(DeleteAddressInnerInput var1) {
        return new DeleteAddressInnerOutput();
    }

    @Override
    public DeleteBeneficiaryInnerOutput deleteBeneficiaryInner(DeleteBeneficiaryInnerInput var1) {
        return new DeleteBeneficiaryInnerOutput();
    }

    @Override
    public DeleteContactpersonInnerOutput deleteContactpersonInner(DeleteContactpersonInnerInput var1) {
        return new DeleteContactpersonInnerOutput();
    }

    @Override
    public DeleteCusttoacctInnerOutput deleteCusttoacctInner(DeleteCusttoacctInnerInput var1) {
        return new DeleteCusttoacctInnerOutput();
    }

    @Override
    public DeleteDayinitinfoDataInitInnerOutput deleteDayinitinfoDataInitInner(DeleteDayinitinfoDataInitInnerInput var1) {
        return new DeleteDayinitinfoDataInitInnerOutput();
    }

    @Override
    public DeleteInfoxInnerOutput deleteInfoxInner(DeleteInfoxInnerInput var1) {
        return new DeleteInfoxInnerOutput();
    }

    @Override
    public DeleteNrfacctaddressInnerOutput deleteNrfacctaddressInner(DeleteNrfacctaddressInnerInput var1) {
        return new DeleteNrfacctaddressInnerOutput();
    }

    @Override
    public DeleteNrfacctcontrollerInnerOutput deleteNrfacctcontrollerInner(DeleteNrfacctcontrollerInnerInput var1) {
        return new DeleteNrfacctcontrollerInnerOutput();
    }

    @Override
    public DeleteNrfacctdictransInnerOutput deleteNrfacctdictransInner(DeleteNrfacctdictransInnerInput var1) {
        return new DeleteNrfacctdictransInnerOutput();
    }

    @Override
    public DeleteNrfacctnameInnerOutput deleteNrfacctnameInner(DeleteNrfacctnameInnerInput var1) {
        return new DeleteNrfacctnameInnerOutput();
    }

    @Override
    public DeleteNrfacctorganInnerOutput deleteNrfacctorganInner(DeleteNrfacctorganInnerInput var1) {
        return new DeleteNrfacctorganInnerOutput();
    }

    @Override
    public DeleteNrfacctpersonInnerOutput deleteNrfacctpersonInner(DeleteNrfacctpersonInnerInput var1) {
        return new DeleteNrfacctpersonInnerOutput();
    }

    @Override
    public DeletePartnerInnerOutput deletePartnerInner(DeletePartnerInnerInput var1) {
        return new DeletePartnerInnerOutput();
    }

    @Override
    public void deleteR1X1X3InfoInner(DeleteR1X1X3InfoInnerInput var1) {

    }

    @Override
    public DeleteRelationpersonInnerOutput deleteRelationpersonInner(DeleteRelationpersonInnerInput var1) {
        return new DeleteRelationpersonInnerOutput();
    }

    @Override
    public List<GetAdditionidInnerOutput> getAdditionidInner(GetAdditionidInnerInput var1) {
        return new ArrayList<GetAdditionidInnerOutput>();
    }

    @Override
    public List<GetAddressInnerOutput> getAddressInner(GetAddressInnerInput var1) {
        return new ArrayList<GetAddressInnerOutput>();
    }

    @Override
    public List<GetAllFieldrightInnerOutput> getAllFieldrightInner(GetAllFieldrightInnerInput var1) {
        return new ArrayList<GetAllFieldrightInnerOutput>();
    }

    @Override
    public List<GetAllRolerightInnerOutput> getAllRolerightInner(GetAllRolerightInnerInput var1) {
        return new ArrayList<GetAllRolerightInnerOutput>();
    }

    @Override
    public List<GetArgInnerOutput> getArgInner(GetArgInnerInput var1) {
        return new ArrayList<GetArgInnerOutput>();
    }

    @Override
    public List<GetBasicinfoByTelInnerOutput> getBasicinfoByTelInner(GetBasicinfoByTelInnerInput var1) {
        return new ArrayList<GetBasicinfoByTelInnerOutput>();
    }

    @Override
    public GetBasicinfoInnerOutput getBasicinfoInner(GetBasicinfoInnerInput var1) {
        return new GetBasicinfoInnerOutput();
    }

    @Override
    public List<GetBasicinfosInnerOutput> getBasicinfosInner(GetBasicinfosInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public List<GetBeneficiaryInnerOutput> getBeneficiaryInner(GetBeneficiaryInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public List<GetContactpersonInnerOutput> getContactpersonInner(GetContactpersonInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public GetCustCommInfoInnerOutput getCustCommInfoInner(GetCustCommInfoInnerInput var1) {
        return new GetCustCommInfoInnerOutput();
    }

    @Override
    public List<GetCusttoacctInnerOutput> getCusttoacctInner(GetCusttoacctInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public GetDayinitinfoInnerOutput getDayinitinfoInner(GetDayinitinfoInnerInput var1) {
        return new GetDayinitinfoInnerOutput();
    }

    @Override
    public List<GetDictionaryWithDictentryStrInnerOutput> getDictionaryWithDictentryStrInner(GetDictionaryWithDictentryStrInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public List<GetFieldrightInnerOutput> getFieldrightInner(GetFieldrightInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public List<GetFieldtonameInnerOutput> getFieldtonameInner(GetFieldtonameInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public List<GetImpTaskInnerOutput> getImpTaskInner(GetImpTaskInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public List<GetImportantholderInnerOutput> getImportantholderInner(GetImportantholderInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public List<GetInfosetInnerOutput> getInfosetInner(GetInfosetInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public List<GetInfoxInnerOutput> getInfoxInner(GetInfoxInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public List<GetLedgerActualsacctInnerOutput> getLedgerActualsacctInner(GetLedgerActualsacctInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public GetNextDateInnerOutput getNextDateInner(GetNextDateInnerInput var1) {
        return new GetNextDateInnerOutput();
    }

    @Override
    public List<GetNrfacctaddressInnerOutput> getNrfacctaddressInner(GetNrfacctaddressInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public List<GetNrfacctcontrollerInnerOutput> getNrfacctcontrollerInner(GetNrfacctcontrollerInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public GetNrfacctcontrollerctrlidInnerOutput getNrfacctcontrollerctrlidInner(GetNrfacctcontrollerctrlidInnerInput var1) {
        return new GetNrfacctcontrollerctrlidInnerOutput();
    }

    @Override
    public List<GetNrfacctdictransInnerOutput> getNrfacctdictransInner(GetNrfacctdictransInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public List<GetNrfacctnameInnerOutput> getNrfacctnameInner(GetNrfacctnameInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public GetNrfacctorganInnerOutput getNrfacctorganInner(GetNrfacctorganInnerInput var1) {
        return new GetNrfacctorganInnerOutput();
    }

    @Override
    public GetNrfacctpersonInnerOutput getNrfacctpersonInner(GetNrfacctpersonInnerInput var1) {
        return new GetNrfacctpersonInnerOutput();
    }

    @Override
    public GetOrganDetailInnerOutput getOrganDetailInner(GetOrganDetailInnerInput var1) {
        return new GetOrganDetailInnerOutput();
    }

    @Override
    public GetOrganInnerOutput getOrganInner(GetOrganInnerInput var1) {
        return new GetOrganInnerOutput();
    }

    @Override
    public List<GetOrganRelationDetailsInnerOutput> getOrganRelationDetailsInner(GetOrganRelationDetailsInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public GetOrganWithoutThreeFactorInnerOutput getOrganWithoutThreeFactorInner(GetOrganWithoutThreeFactorInnerInput var1) {
        return new GetOrganWithoutThreeFactorInnerOutput();
    }

    @Override
    public List<GetPartnerInnerOutput> getPartnerInner(GetPartnerInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public GetPersonDetailInnerOutput getPersonDetailInner(GetPersonDetailInnerInput var1) {
        return new GetPersonDetailInnerOutput();
    }

    @Override
    public GetPersonInnerOutput getPersonInner(GetPersonInnerInput var1) {
        return new GetPersonInnerOutput();
    }

    @Override
    public GetPervDateInnerOutput getPervDateInner(GetPervDateInnerInput var1) {
        return new GetPervDateInnerOutput();
    }

    @Override
    public List<GetPositionStrListInnerOutput> getPositionStrListInner(GetPositionStrListInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public GetPrevTableNamesInnerOutput getPrevTableNamesInner(GetPrevTableNamesInnerInput var1) {
        return new GetPrevTableNamesInnerOutput();
    }

    @Override
    public GetProdByOrganCustDetaiInnerOutput getProdByOrganCustDetaiInner(GetProdByOrganCustDetaiInnerInput var1) {
        return new GetProdByOrganCustDetaiInnerOutput();
    }

    @Override
    public GetProdByPersonCustDetaiInnerOutput getProdByPersonCustDetaiInner(GetProdByPersonCustDetaiInnerInput var1) {
        return new GetProdByPersonCustDetaiInnerOutput();
    }

    @Override
    public GetProdByProdCustInnerOutput getProdByProdCustInner(GetProdByProdCustInnerInput var1) {
        return new GetProdByProdCustInnerOutput();
    }

    @Override
    public GetProdInnerOutput getProdInner(GetProdInnerInput var1) {
        return new GetProdInnerOutput();
    }

    @Override
    public GetProdLedgerInnerOutput getProdLedgerInner(GetProdLedgerInnerInput var1) {
        return new GetProdLedgerInnerOutput();
    }

    @Override
    public GetProdOrganDetailInnerOutput getProdOrganDetailInner(GetProdOrganDetailInnerInput var1) {
        return new GetProdOrganDetailInnerOutput();
    }

    @Override
    public List<GetProdPossessorInnerOutput> getProdPossessorInner(GetProdPossessorInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public GetProduceProdpossessorIdInnerOutput getProduceProdpossessorIdInner(GetProduceProdpossessorIdInnerInput var1) {
        return new GetProduceProdpossessorIdInnerOutput();
    }

    @Override
    public List<GetRelationpersonInnerOutput> getRelationpersonInner(GetRelationpersonInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public List<GetSensitiveFieldInnerOutput> getSensitiveFieldInner(GetSensitiveFieldInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public List<GetTelByAcctInnerOutput> getTelByAcctInner(GetTelByAcctInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public PostAdditionidInnerOutput postAdditionidInner(PostAdditionidInnerInput var1) {
        return new PostAdditionidInnerOutput();
    }

    @Override
    public PostAddressInnerOutput postAddressInner(PostAddressInnerInput var1) {
        return new PostAddressInnerOutput();
    }

    @Override
    public PostBeneficiaryInnerOutput postBeneficiaryInner(PostBeneficiaryInnerInput var1) {
        return new PostBeneficiaryInnerOutput();
    }

    @Override
    public PostCicSqlInnerOutput postCicSqlInner(PostCicSqlInnerInput var1) {
        return new PostCicSqlInnerOutput();
    }

    @Override
    public PostContactpersonInnerOutput postContactpersonInner(PostContactpersonInnerInput var1) {
        return new PostContactpersonInnerOutput();
    }

    @Override
    public PostCusttoacctInnerOutput postCusttoacctInner(PostCusttoacctInnerInput var1) {
        return new PostCusttoacctInnerOutput();
    }

    @Override
    public PostDayinitinfoDataToPrevInnerOutput postDayinitinfoDataToPrevInner(PostDayinitinfoDataToPrevInnerInput var1) {
        return new PostDayinitinfoDataToPrevInnerOutput();
    }

    @Override
    public PostInfosetInnerOutput postInfosetInner(PostInfosetInnerInput var1) {
        return new PostInfosetInnerOutput();
    }

    @Override
    public PostInfoxInnerOutput postInfoxInner(PostInfoxInnerInput var1) {
        return new PostInfoxInnerOutput();
    }

    @Override
    public PostNrfacctaddressInnerOutput postNrfacctaddressInner(PostNrfacctaddressInnerInput var1) {
        return new PostNrfacctaddressInnerOutput();
    }

    @Override
    public PostNrfacctcontrollerInnerOutput postNrfacctcontrollerInner(PostNrfacctcontrollerInnerInput var1) {
        return new PostNrfacctcontrollerInnerOutput();
    }

    @Override
    public PostNrfacctdictransInnerOutput postNrfacctdictransInner(PostNrfacctdictransInnerInput var1) {
        return new PostNrfacctdictransInnerOutput();
    }

    @Override
    public PostNrfacctnameInnerOutput postNrfacctnameInner(PostNrfacctnameInnerInput var1) {
        return new PostNrfacctnameInnerOutput();
    }

    @Override
    public PostNrfacctorganInnerOutput postNrfacctorganInner(PostNrfacctorganInnerInput var1) {
        return new PostNrfacctorganInnerOutput();
    }

    @Override
    public PostNrfacctpersonInnerOutput postNrfacctpersonInner(PostNrfacctpersonInnerInput var1) {
        return new PostNrfacctpersonInnerOutput();
    }

    @Override
    public PostOrganInnerOutput postOrganInner(PostOrganInnerInput var1) {
        return new PostOrganInnerOutput();
    }

    @Override
    public PostOrganWithoutThreeFactorInnerOutput postOrganWithoutThreeFactorInner(PostOrganWithoutThreeFactorInnerInput var1) {
        return new PostOrganWithoutThreeFactorInnerOutput();
    }

    @Override
    public PostPartnerInnerOutput postPartnerInner(PostPartnerInnerInput var1) {
        return new PostPartnerInnerOutput();
    }

    @Override
    public PostPersonInnerOutput postPersonInner(PostPersonInnerInput var1) {
        return new PostPersonInnerOutput();
    }

    @Override
    public PostProdByOrganCustInnerOutput postProdByOrganCustInner(PostProdByOrganCustInnerInput var1) {
        return new PostProdByOrganCustInnerOutput();
    }

    @Override
    public PostProdByProdCustInnerOutput postProdByProdCustInner(PostProdByProdCustInnerInput var1) {
        return new PostProdByProdCustInnerOutput();
    }

    @Override
    public PostProdOrganCustInnerOutput postProdOrganCustInner(PostProdOrganCustInnerInput var1) {
        return new PostProdOrganCustInnerOutput();
    }

    @Override
    public PostProdPersonCustInnerOutput postProdPersonCustInner(PostProdPersonCustInnerInput var1) {
        return new PostProdPersonCustInnerOutput();
    }

    @Override
    public void postR1X1X3InfoInner(PostR1X1X3InfoInnerInput var1) {

    }

    @Override
    public PostRelationpersonInnerOutput postRelationpersonInner(PostRelationpersonInnerInput var1) {
        return new PostRelationpersonInnerOutput();
    }

    @Override
    public PostSignAccountInnerOutput postSignAccountInner(PostSignAccountInnerInput var1) {
        return new PostSignAccountInnerOutput();
    }

    @Override
    public PutAdditionidInnerOutput putAdditionidInner(PutAdditionidInnerInput var1) {
        return new PutAdditionidInnerOutput();
    }

    @Override
    public PutAdditionidSyncInnerOutput putAdditionidSyncInner(PutAdditionidSyncInnerInput var1) {
        return new PutAdditionidSyncInnerOutput();
    }

    @Override
    public PutAddressInnerOutput putAddressInner(PutAddressInnerInput var1) {
        return new PutAddressInnerOutput();
    }

    @Override
    public PutAddressSyncInnerOutput putAddressSyncInner(PutAddressSyncInnerInput var1) {
        return new PutAddressSyncInnerOutput();
    }

    @Override
    public PutAmlriskBatchInnerOutput putAmlriskBatchInner(PutAmlriskBatchInnerInput var1) {
        return new PutAmlriskBatchInnerOutput();
    }

    @Override
    public PutBasicinfoInnerOutput putBasicinfoInner(PutBasicinfoInnerInput var1) {
        return new PutBasicinfoInnerOutput();
    }

    @Override
    public PutBasicinfoThreefactorsInnerOutput putBasicinfoThreefactorsInner(PutBasicinfoThreefactorsInnerInput var1) {
        return new PutBasicinfoThreefactorsInnerOutput();
    }

    @Override
    public PutBeneficiaryBatchInnerOutput putBeneficiaryBatchInner(PutBeneficiaryBatchInnerInput var1) {
        return new PutBeneficiaryBatchInnerOutput();
    }

    @Override
    public PutBeneficiaryInnerOutput putBeneficiaryInner(PutBeneficiaryInnerInput var1) {
        return new PutBeneficiaryInnerOutput();
    }

    @Override
    public PutContactpersonInnerOutput putContactpersonInner(PutContactpersonInnerInput var1) {
        return new PutContactpersonInnerOutput();
    }

    @Override
    public PutContactpersonSyncInnerOutput putContactpersonSyncInner(PutContactpersonSyncInnerInput var1) {
        return new PutContactpersonSyncInnerOutput();
    }

    @Override
    public PutCreditInfoBatchInnerOutput putCreditInfoBatchInner(PutCreditInfoBatchInnerInput var1) {
        return new PutCreditInfoBatchInnerOutput();
    }

    @Override
    public PutCusttoacctInnerOutput putCusttoacctInner(PutCusttoacctInnerInput var1) {
        return new PutCusttoacctInnerOutput();
    }

    @Override
    public PutDayinitinfoDateChange2InnerOutput putDayinitinfoDateChange2Inner(PutDayinitinfoDateChange2InnerInput var1) {
        return new PutDayinitinfoDateChange2InnerOutput();
    }

    @Override
    public PutDayinitinfoDateChangeInnerOutput putDayinitinfoDateChangeInner(PutDayinitinfoDateChangeInnerInput var1) {
        return new PutDayinitinfoDateChangeInnerOutput();
    }

    @Override
    public PutImpTaskInnerOutput putImpTaskInner(PutImpTaskInnerInput var1) {
        return new PutImpTaskInnerOutput();
    }

    @Override
    public PutImpTaskJobInnerOutput putImpTaskJobInner(PutImpTaskJobInnerInput var1) {
        return new PutImpTaskJobInnerOutput();
    }

    @Override
    public PutImpTaskProgressInnerOutput putImpTaskProgressInner(PutImpTaskProgressInnerInput var1) {
        return new PutImpTaskProgressInnerOutput();
    }

    @Override
    public PutIncrementalDiffinfoPreProcessInnerOutput putIncrementalDiffinfoPreProcessInner(PutIncrementalDiffinfoPreProcessInnerInput var1) {
        return new PutIncrementalDiffinfoPreProcessInnerOutput();
    }

    @Override
    public PutIncrementalInfoSyncInnerOutput putIncrementalInfoSyncInner(PutIncrementalInfoSyncInnerInput var1) {
        return new PutIncrementalInfoSyncInnerOutput();
    }

    @Override
    public PutInfosetInnerOutput putInfosetInner(PutInfosetInnerInput var1) {
        return new PutInfosetInnerOutput();
    }

    @Override
    public PutInfoxInnerOutput putInfoxInner(PutInfoxInnerInput var1) {
        return new PutInfoxInnerOutput();
    }

    @Override
    public PutInfoxSyncInnerOutput putInfoxSyncInner(PutInfoxSyncInnerInput var1) {
        return new PutInfoxSyncInnerOutput();
    }

    @Override
    public PutLedgerActualsacctInnerOutput putLedgerActualsacctInner(PutLedgerActualsacctInnerInput var1) {
        return new PutLedgerActualsacctInnerOutput();
    }

    @Override
    public PutNrfacctaddressInnerOutput putNrfacctaddressInner(PutNrfacctaddressInnerInput var1) {
        return new PutNrfacctaddressInnerOutput();
    }

    @Override
    public PutNrfacctcontrollerBatchInnerOutput putNrfacctcontrollerBatchInner(PutNrfacctcontrollerBatchInnerInput var1) {
        return new PutNrfacctcontrollerBatchInnerOutput();
    }

    @Override
    public PutNrfacctcontrollerInnerOutput putNrfacctcontrollerInner(PutNrfacctcontrollerInnerInput var1) {
        return new PutNrfacctcontrollerInnerOutput();
    }

    @Override
    public PutNrfacctdictransInnerOutput putNrfacctdictransInner(PutNrfacctdictransInnerInput var1) {
        return new PutNrfacctdictransInnerOutput();
    }

    @Override
    public PutNrfacctnameInnerOutput putNrfacctnameInner(PutNrfacctnameInnerInput var1) {
        return new PutNrfacctnameInnerOutput();
    }

    @Override
    public PutNrfacctorganInnerOutput putNrfacctorganInner(PutNrfacctorganInnerInput var1) {
        return new PutNrfacctorganInnerOutput();
    }

    @Override
    public PutNrfacctpersonInnerOutput putNrfacctpersonInner(PutNrfacctpersonInnerInput var1) {
        return new PutNrfacctpersonInnerOutput();
    }

    @Override
    public PutOrganInnerOutput putOrganInner(PutOrganInnerInput var1) {
        return new PutOrganInnerOutput();
    }

    @Override
    public PutOrganRelationDetailsInnerOutput putOrganRelationDetailsInner(PutOrganRelationDetailsInnerInput var1) {
        return new PutOrganRelationDetailsInnerOutput();
    }

    @Override
    public PutOrganSyncInnerOutput putOrganSyncInner(PutOrganSyncInnerInput var1) {
        return new PutOrganSyncInnerOutput();
    }

    @Override
    public PutOrganWithoutThreeFactorInnerOutput putOrganWithoutThreeFactorInner(PutOrganWithoutThreeFactorInnerInput var1) {
        return new PutOrganWithoutThreeFactorInnerOutput();
    }

    @Override
    public PutPartnerBatchInnerOutput putPartnerBatchInner(PutPartnerBatchInnerInput var1) {
        return new PutPartnerBatchInnerOutput();
    }

    @Override
    public PutPartnerInnerOutput putPartnerInner(PutPartnerInnerInput var1) {
        return new PutPartnerInnerOutput();
    }

    @Override
    public PutPersonInnerOutput putPersonInner(PutPersonInnerInput var1) {
        return new PutPersonInnerOutput();
    }

    @Override
    public PutPersonSyncInnerOutput putPersonSyncInner(PutPersonSyncInnerInput var1) {
        return new PutPersonSyncInnerOutput();
    }

    @Override
    public PutProdInnerOutput putProdInner(PutProdInnerInput var1) {
        return new PutProdInnerOutput();
    }

    @Override
    public PutProdLedgerInnerOutput putProdLedgerInner(PutProdLedgerInnerInput var1) {
        return new PutProdLedgerInnerOutput();
    }

    @Override
    public PutProdPossessorInnerOutput putProdPossessorInner(PutProdPossessorInnerInput var1) {
        return new PutProdPossessorInnerOutput();
    }

    @Override
    public PutRelationpersonInnerOutput putRelationpersonInner(PutRelationpersonInnerInput var1) {
        return new PutRelationpersonInnerOutput();
    }

    @Override
    public PutRelationpersonSyncInnerOutput putRelationpersonSyncInner(PutRelationpersonSyncInnerInput var1) {
        return new PutRelationpersonSyncInnerOutput();
    }

    @Override
    public PutTelSyncInnerOutput putTelSyncInner(PutTelSyncInnerInput var1) {
        return new PutTelSyncInnerOutput();
    }

    @Override
    public PutThreeFactorsGroupInnerOutput putThreeFactorsGroupInner(PutThreeFactorsGroupInnerInput var1) {
        return new PutThreeFactorsGroupInnerOutput();
    }
}
