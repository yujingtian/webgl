package com.hundsun.broker.adapter.cms.pub.service.impl;

import com.hundsun.broker.adapter.cms.pub.service.InnerCmsActService;
import com.hundsun.broker.base.mq.MessageInfo;
import com.hundsun.jrescloud.rpc.annotation.CloudComponent;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@CloudComponent
public class InnerCmsActServiceImpl implements InnerCmsActService {
    @Override
    public Boolean postRefreshData(MessageInfo<Map<String, Object>> var1) {
        return true;
    }

    @Override
    public Boolean postOmcData(Map<String, Object> var1) {
        return true;
    }

    @Override
    public List<GetBankJourInnerOutput> getBankJourInner(GetBankJourInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public List<GetAverageDailyAssetOutput> getAverageDailyAssetInner(GetAverageDailyAssetInput var1) {
        return new ArrayList<>();
    }

    @Override
    public List<GetBankAcctInfoOutput> getBankAcctInfoInner(GetBankAcctInfoInput var1) {
        return new ArrayList<>();
    }
}
