package com.hundsun.broker.sps.pub.service.impl;

import com.hundsun.broker.sps.pub.service.InnerSpsService;
import com.hundsun.jrescloud.rpc.annotation.CloudAuth;
import com.hundsun.jrescloud.rpc.annotation.CloudComponent;

@CloudAuth
@CloudComponent
public class InnerSpsServiceImpl implements InnerSpsService {
    @Override
    public GetCfare2QryInnerOutput getCfare2QryInner(GetCfare2QryInnerInput var1) {
        return new GetCfare2QryInnerOutput();
    }

    @Override
    public GetCoffare2QryInnerOutput getCoffare2QryInner(GetCoffare2QryInnerInput var1) {
        return new GetCoffare2QryInnerOutput();
    }
}
