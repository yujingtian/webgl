package com.hundsun.broker.mp.pub.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.hundsun.broker.base.BaseService;
import com.hundsun.broker.base.mq.MessageInfo;
import com.hundsun.broker.mq.pub.service.AdapterMqService;
import com.hundsun.jrescloud.rpc.annotation.CloudComponent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Map;

/**
 * 消息接收接口实现类
 *
 * @author studio-auto
 * @date
 */
@CloudComponent
public class AdapterServiceImpl extends BaseService implements AdapterMqService {
    private static final Logger logger = LoggerFactory.getLogger(AdapterServiceImpl.class);

    @Override
    public void fundaccountOpenMq(MessageInfo<Object> messageInfo) {
        // 资产账户开户
        String jsonString = messageInfo.toString();
        JSONObject jsonObject = JSONObject.parseObject(jsonString);
        Map jsonToMap = JSONObject.parseObject(jsonObject.toJSONString());
        @SuppressWarnings("unchecked")
        Map<String, Object> data = (Map<String, Object>)jsonToMap.get("data");
        logger.info("已接到消息custebs_fundaccount_open");
        logger.info(messageInfo.toString());
    }
}
