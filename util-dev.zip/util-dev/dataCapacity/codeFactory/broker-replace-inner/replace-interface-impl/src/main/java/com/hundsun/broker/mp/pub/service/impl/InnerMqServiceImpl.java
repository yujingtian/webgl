package com.hundsun.broker.mp.pub.service.impl;

import com.alibaba.fastjson.JSON;
import com.hundsun.broker.base.AppContext;
import com.hundsun.broker.base.mq.MessageInfo;
import com.hundsun.broker.elg.pub.service.InnerElgService;
import com.hundsun.broker.mq.pub.service.InnerMqService;
import com.hundsun.jrescloud.rpc.annotation.CloudComponent;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

@CloudComponent
public class InnerMqServiceImpl implements InnerMqService {

    private static final String REPLACE_SEQ = "broker-replace-seq";

    @Override
    public PutMqInnerOutput PutMqInner(PutMqInnerInput putMqInnerInput) {
        long jourNumber = new Date().getTime();
        String jourNumberStr = Long.toString(jourNumber);
        String topic = putMqInnerInput.getTopic();
        String indexesStr = putMqInnerInput.getIndexes();
        indexesStr = indexesStr.replaceAll("\\\\\"","\"");
        Map indexes = JSON.parseObject(indexesStr);
        String mqData = putMqInnerInput.getMqData();
        mqData = mqData.replaceAll("\\\\\"","\"");
        Map paramap = JSON.parseObject(mqData);
        PutMqInnerOutput output = new PutMqInnerOutput();
        output.setSerialNo(jourNumber);
        sendMsg(topic,paramap,indexes,jourNumberStr,putMqInnerInput.getCustId());
        return output;
    }

    public static void sendMsg(String topic, Object data, Map<String, Object> indexes, String jourNumber,
                               String custId) {
        MessageInfo<Object> messageInfo = new MessageInfo<Object>();
        messageInfo.setIndexes(indexes);
        messageInfo.setTopic(topic);
        messageInfo.setData(data);
        messageInfo.setJourNumber(jourNumber);
        messageInfo.setCustId(custId);
        AppContext.publish(REPLACE_SEQ, messageInfo);
    }
}
