package com.hundsun.broker.pbs.pub.service.impl;

import com.hundsun.broker.pbs.pub.service.InnerPbsService;
import com.hundsun.jrescloud.rpc.annotation.CloudComponent;

import java.util.ArrayList;
import java.util.List;

@CloudComponent
public class InnerPbsServiceImpl implements InnerPbsService {
    @Override
    public List<GetAllbranchByCompanyNoInnerOutput> getAllbranchByCompanyNoInner(GetAllbranchByCompanyNoInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public List<GetAllbranchByUserIdInnerOutput> getAllbranchByUserIdInner(GetAllbranchByUserIdInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public GetBranchByUserIdInnerOutput getBranchByUserIdInner(GetBranchByUserIdInnerInput var1) {
        return new GetBranchByUserIdInnerOutput();
    }

    @Override
    public GetDictionarySingleInnerOutput getDictionarySingleInner(GetDictionarySingleInnerInput var1) {
        return new GetDictionarySingleInnerOutput();
    }

    @Override
    public List<GetDictionaryWithDictentryStrInnerOutput> getDictionaryWithDictentryStrInner(GetDictionaryWithDictentryStrInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public GetUserrightInnerOutput getUserrightInner(GetUserrightInnerInput var1) {
        return new GetUserrightInnerOutput();
    }

    @Override
    public PostFiledownloadInnerOutput postFiledownloadInner(PostFiledownloadInnerInput var1) {
        return new PostFiledownloadInnerOutput();
    }

    @Override
    public PutFiledownloadInnerOutput putFiledownloadInner(PutFiledownloadInnerInput var1) {
        return new PutFiledownloadInnerOutput();
    }

    @Override
    public GetSysconfigInnerOutput getSysconfigInner(GetSysconfigInnerInput var1) {
        return new GetSysconfigInnerOutput();
    }
}
