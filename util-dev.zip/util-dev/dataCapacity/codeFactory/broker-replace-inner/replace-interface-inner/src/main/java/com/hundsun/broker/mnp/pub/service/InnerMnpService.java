//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.hundsun.broker.mnp.pub.service;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.hundsun.broker.base.PublicChecker.PublicParams;
import com.hundsun.broker.base.databind.CharacterJsonDeserializer;
import com.hundsun.jrescloud.rpc.annotation.CloudFunction;
import com.hundsun.jrescloud.rpc.annotation.CloudService;
import com.hundsun.jrescloud.rpc.def.validation.SinogramLength;
import java.io.Serializable;
import java.util.List;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

@CloudService(
        validation = true,
        validationNull = false,
        application = "hsbroker.mnp"
)
public interface InnerMnpService {
    @CloudFunction(
            value = "mnp.getNoticelogInner",
            apiUrl = "/getNoticelogInner"
    )
    InnerMnpService.GetNoticelogInnerOutput getNoticelogInner(InnerMnpService.GetNoticelogInnerInput var1);

    @CloudFunction(
            value = "mnp.deleteDayinitinfoDatainitInner",
            apiUrl = "/deleteDayinitinfoDatainitInner"
    )
    InnerMnpService.DeleteDayinitinfoDatainitInnerOutput deleteDayinitinfoDatainitInner(InnerMnpService.DeleteDayinitinfoDatainitInnerInput var1);

    @CloudFunction(
            value = "mnp.postNoticelogOneGenerateInner",
            apiUrl = "/postNoticelogOneGenerateInner"
    )
    InnerMnpService.PostNoticelogOneGenerateInnerOutput postNoticelogOneGenerateInner(InnerMnpService.PostNoticelogOneGenerateInnerInput var1);

    @CloudFunction(
            value = "mnp.postNoticelogToCopyAddressInner",
            apiUrl = "/postNoticelogToCopyAddressInner"
    )
    InnerMnpService.PostNoticelogToCopyAddressInnerOutput postNoticelogToCopyAddressInner(InnerMnpService.PostNoticelogToCopyAddressInnerInput var1);

    @CloudFunction(
            value = "mnp.putDayinitinfoDateChangeInner",
            apiUrl = "/putDayinitinfoDateChangeInner"
    )
    InnerMnpService.PutDayinitinfoDateChangeInnerOutput putDayinitinfoDateChangeInner(InnerMnpService.PutDayinitinfoDateChangeInnerInput var1);

    @CloudFunction(
            value = "mnp.postNoticelogOneSendInner",
            apiUrl = "/postNoticelogOneSendInner"
    )
    InnerMnpService.PostNoticelogOneSendInnerOutput postNoticelogOneSendInner(InnerMnpService.PostNoticelogOneSendInnerInput var1);

    @CloudFunction(
            value = "mnp.postNoticelogGenerateInner",
            apiUrl = "/postNoticelogGenerateInner"
    )
    InnerMnpService.PostNoticelogGenerateInnerOutput postNoticelogGenerateInner(InnerMnpService.PostNoticelogGenerateInnerInput var1);

    @CloudFunction(
            value = "mnp.getNoticeargInner",
            apiUrl = "/getNoticeargInner"
    )
    List<InnerMnpService.GetNoticeargInnerOutput> getNoticeargInner(InnerMnpService.GetNoticeargInnerInput var1);

    @CloudFunction(
            value = "mnp.postNoticelogBatchGenerateInner",
            apiUrl = "/postNoticelogBatchGenerateInner"
    )
    InnerMnpService.PostNoticelogBatchGenerateInnerOutput postNoticelogBatchGenerateInner(InnerMnpService.PostNoticelogBatchGenerateInnerInput var1);

    @CloudFunction(
            value = "mnp.getNoticelogPollingInner",
            apiUrl = "/getNoticelogPollingInner"
    )
    List<InnerMnpService.GetNoticelogPollingInnerOutput> getNoticelogPollingInner(InnerMnpService.GetNoticelogPollingInnerInput var1);

    @CloudFunction(
            value = "mnp.putNoticelogBatchAuditInner",
            apiUrl = "/putNoticelogBatchAuditInner"
    )
    InnerMnpService.PutNoticelogBatchAuditInnerOutput putNoticelogBatchAuditInner(InnerMnpService.PutNoticelogBatchAuditInnerInput var1);

    @CloudFunction(
            value = "mnp.putNoticelogWriteBackInner",
            apiUrl = "/putNoticelogWriteBackInner"
    )
    void putNoticelogWriteBackInner(InnerMnpService.PutNoticelogWriteBackInnerInput var1);

    @CloudFunction(
            value = "mnp.getNoticelogKindInner",
            apiUrl = "/getNoticelogKindInner"
    )
    List<InnerMnpService.GetNoticelogKindInnerOutput> getNoticelogKindInner(InnerMnpService.GetNoticelogKindInnerInput var1);

    @CloudFunction(
            value = "mnp.getNoticetemplateInner",
            apiUrl = "/getNoticetemplateInner"
    )
    List<InnerMnpService.GetNoticetemplateInnerOutput> getNoticetemplateInner(InnerMnpService.GetNoticetemplateInnerInput var1);

    public static class GetNoticetemplateInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer templateNo = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character tempfieldType = ' ';
        private String templateField = " ";
        private Integer dictEntry = 0;

        public GetNoticetemplateInnerOutput() {
        }

        public Integer getTemplateNo() {
            return this.templateNo != null ? this.templateNo : 0;
        }

        public Character getTempfieldType() {
            return this.tempfieldType != null ? this.tempfieldType : ' ';
        }

        public String getTemplateField() {
            if (this.templateField == null) {
                return " ";
            } else {
                return this.templateField.isEmpty() ? " " : this.templateField;
            }
        }

        public Integer getDictEntry() {
            return this.dictEntry != null ? this.dictEntry : 0;
        }

        public void setTemplateNo(Integer templateNo) {
            this.templateNo = templateNo;
        }

        public void setTempfieldType(Character tempfieldType) {
            this.tempfieldType = tempfieldType;
        }

        public void setTemplateField(String templateField) {
            this.templateField = templateField;
        }

        public void setDictEntry(Integer dictEntry) {
            this.dictEntry = dictEntry;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetNoticetemplateInnerOutput:(");
            buffer.append("templateNo:" + this.templateNo);
            buffer.append(",tempfieldType:" + this.tempfieldType);
            buffer.append(",templateField:" + this.templateField);
            buffer.append(",dictEntry:" + this.dictEntry);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.templateNo);
            builder.append(this.tempfieldType);
            builder.append(this.templateField);
            builder.append(this.dictEntry);
            return builder.toHashCode();
        }

        public boolean equals(InnerMnpService.GetNoticetemplateInnerOutput obj) {
            if (obj instanceof InnerMnpService.GetNoticetemplateInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.templateNo, obj.templateNo);
                builder.append(this.tempfieldType, obj.tempfieldType);
                builder.append(this.templateField, obj.templateField);
                builder.append(this.dictEntry, obj.dictEntry);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetNoticetemplateInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @NotNull(
                message = "不能为空"
        )
        private Integer opBranchNo;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String operatorNo;
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay;
        private Integer templateNo = 0;

        public GetNoticetemplateInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo;
        }

        public String getOperatorNo() {
            return this.operatorNo;
        }

        public String getOpStation() {
            return this.opStation;
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay;
        }

        public Integer getTemplateNo() {
            return this.templateNo != null ? this.templateNo : 0;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setTemplateNo(Integer templateNo) {
            this.templateNo = templateNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetNoticetemplateInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",templateNo:" + this.templateNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.templateNo);
            return builder.toHashCode();
        }

        public boolean equals(InnerMnpService.GetNoticetemplateInnerInput obj) {
            if (obj instanceof InnerMnpService.GetNoticetemplateInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.templateNo, obj.templateNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetNoticelogKindInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer noticeKind = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character pushFlag = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character chargeFlag = ' ';

        public GetNoticelogKindInnerOutput() {
        }

        public Integer getNoticeKind() {
            return this.noticeKind != null ? this.noticeKind : 0;
        }

        public Character getPushFlag() {
            return this.pushFlag != null ? this.pushFlag : ' ';
        }

        public Character getChargeFlag() {
            return this.chargeFlag != null ? this.chargeFlag : ' ';
        }

        public void setNoticeKind(Integer noticeKind) {
            this.noticeKind = noticeKind;
        }

        public void setPushFlag(Character pushFlag) {
            this.pushFlag = pushFlag;
        }

        public void setChargeFlag(Character chargeFlag) {
            this.chargeFlag = chargeFlag;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetNoticelogKindInnerOutput:(");
            buffer.append("noticeKind:" + this.noticeKind);
            buffer.append(",pushFlag:" + this.pushFlag);
            buffer.append(",chargeFlag:" + this.chargeFlag);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.noticeKind);
            builder.append(this.pushFlag);
            builder.append(this.chargeFlag);
            return builder.toHashCode();
        }

        public boolean equals(InnerMnpService.GetNoticelogKindInnerOutput obj) {
            if (obj instanceof InnerMnpService.GetNoticelogKindInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.noticeKind, obj.noticeKind);
                builder.append(this.pushFlag, obj.pushFlag);
                builder.append(this.chargeFlag, obj.chargeFlag);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetNoticelogKindInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @NotNull(
                message = "不能为空"
        )
        private Integer opBranchNo;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String operatorNo;
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay;

        public GetNoticelogKindInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo;
        }

        public String getOperatorNo() {
            return this.operatorNo;
        }

        public String getOpStation() {
            return this.opStation;
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetNoticelogKindInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            return builder.toHashCode();
        }

        public boolean equals(InnerMnpService.GetNoticelogKindInnerInput obj) {
            if (obj instanceof InnerMnpService.GetNoticelogKindInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutNoticelogWriteBackInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @NotNull(
                message = "不能为空"
        )
        private Integer opBranchNo;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String operatorNo;
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId;
        @NotNull(
                message = "不能为空"
        )
        private Integer initDate;
        @NotNull(
                message = "不能为空"
        )
        private Long serialNo;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character noticeStatus;
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String remark = " ";

        public PutNoticelogWriteBackInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo;
        }

        public String getOperatorNo() {
            return this.operatorNo;
        }

        public String getOpStation() {
            return this.opStation;
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay;
        }

        public String getClientId() {
            return this.clientId;
        }

        public Integer getInitDate() {
            return this.initDate;
        }

        public Long getSerialNo() {
            return this.serialNo;
        }

        public Character getNoticeStatus() {
            return this.noticeStatus;
        }

        public String getRemark() {
            if (this.remark == null) {
                return " ";
            } else {
                return this.remark.isEmpty() ? " " : this.remark;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public void setSerialNo(Long serialNo) {
            this.serialNo = serialNo;
        }

        public void setNoticeStatus(Character noticeStatus) {
            this.noticeStatus = noticeStatus;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutNoticelogWriteBackInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",initDate:" + this.initDate);
            buffer.append(",serialNo:" + this.serialNo);
            buffer.append(",noticeStatus:" + this.noticeStatus);
            buffer.append(",remark:" + this.remark);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.clientId);
            builder.append(this.initDate);
            builder.append(this.serialNo);
            builder.append(this.noticeStatus);
            builder.append(this.remark);
            return builder.toHashCode();
        }

        public boolean equals(InnerMnpService.PutNoticelogWriteBackInnerInput obj) {
            if (obj instanceof InnerMnpService.PutNoticelogWriteBackInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.clientId, obj.clientId);
                builder.append(this.initDate, obj.initDate);
                builder.append(this.serialNo, obj.serialNo);
                builder.append(this.noticeStatus, obj.noticeStatus);
                builder.append(this.remark, obj.remark);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutNoticelogBatchAuditInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String opRemark = " ";

        public PutNoticelogBatchAuditInnerOutput() {
        }

        public String getOpRemark() {
            if (this.opRemark == null) {
                return " ";
            } else {
                return this.opRemark.isEmpty() ? " " : this.opRemark;
            }
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutNoticelogBatchAuditInnerOutput:(");
            buffer.append("opRemark:" + this.opRemark);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opRemark);
            return builder.toHashCode();
        }

        public boolean equals(InnerMnpService.PutNoticelogBatchAuditInnerOutput obj) {
            if (obj instanceof InnerMnpService.PutNoticelogBatchAuditInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opRemark, obj.opRemark);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutNoticelogBatchAuditInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @NotNull(
                message = "不能为空"
        )
        private Integer opBranchNo;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String operatorNo;
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String clientId = " ";
        @SinogramLength(
                min = 1,
                max = 2000,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String enNoticeKind;
        @NotNull(
                message = "不能为空"
        )
        private Integer actionIn;

        public PutNoticelogBatchAuditInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo;
        }

        public String getOperatorNo() {
            return this.operatorNo;
        }

        public String getOpStation() {
            return this.opStation;
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay;
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getEnNoticeKind() {
            return this.enNoticeKind;
        }

        public Integer getActionIn() {
            return this.actionIn;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setEnNoticeKind(String enNoticeKind) {
            this.enNoticeKind = enNoticeKind;
        }

        public void setActionIn(Integer actionIn) {
            this.actionIn = actionIn;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutNoticelogBatchAuditInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",enNoticeKind:" + this.enNoticeKind);
            buffer.append(",actionIn:" + this.actionIn);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.clientId);
            builder.append(this.enNoticeKind);
            builder.append(this.actionIn);
            return builder.toHashCode();
        }

        public boolean equals(InnerMnpService.PutNoticelogBatchAuditInnerInput obj) {
            if (obj instanceof InnerMnpService.PutNoticelogBatchAuditInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.clientId, obj.clientId);
                builder.append(this.enNoticeKind, obj.enNoticeKind);
                builder.append(this.actionIn, obj.actionIn);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetNoticelogPollingInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer initDate = 0;
        private Long serialNo = 0L;
        private Integer noticeKind = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character noticeWay = ' ';
        private String noticeCaption = " ";
        private String noticeContent = " ";
        private String attachPath = " ";
        private String noticeCaddress = " ";
        private String serverAddress = " ";
        private String clientId = " ";
        private String clientName = " ";
        private String companyName = " ";
        private Integer branchNo = 0;
        private String emailDns = " ";

        public GetNoticelogPollingInnerOutput() {
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public Long getSerialNo() {
            return this.serialNo != null ? this.serialNo : 0L;
        }

        public Integer getNoticeKind() {
            return this.noticeKind != null ? this.noticeKind : 0;
        }

        public Character getNoticeWay() {
            return this.noticeWay != null ? this.noticeWay : ' ';
        }

        public String getNoticeCaption() {
            if (this.noticeCaption == null) {
                return " ";
            } else {
                return this.noticeCaption.isEmpty() ? " " : this.noticeCaption;
            }
        }

        public String getNoticeContent() {
            if (this.noticeContent == null) {
                return " ";
            } else {
                return this.noticeContent.isEmpty() ? " " : this.noticeContent;
            }
        }

        public String getAttachPath() {
            if (this.attachPath == null) {
                return " ";
            } else {
                return this.attachPath.isEmpty() ? " " : this.attachPath;
            }
        }

        public String getNoticeCaddress() {
            if (this.noticeCaddress == null) {
                return " ";
            } else {
                return this.noticeCaddress.isEmpty() ? " " : this.noticeCaddress;
            }
        }

        public String getServerAddress() {
            if (this.serverAddress == null) {
                return " ";
            } else {
                return this.serverAddress.isEmpty() ? " " : this.serverAddress;
            }
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getClientName() {
            if (this.clientName == null) {
                return " ";
            } else {
                return this.clientName.isEmpty() ? " " : this.clientName;
            }
        }

        public String getCompanyName() {
            if (this.companyName == null) {
                return " ";
            } else {
                return this.companyName.isEmpty() ? " " : this.companyName;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getEmailDns() {
            if (this.emailDns == null) {
                return " ";
            } else {
                return this.emailDns.isEmpty() ? " " : this.emailDns;
            }
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public void setSerialNo(Long serialNo) {
            this.serialNo = serialNo;
        }

        public void setNoticeKind(Integer noticeKind) {
            this.noticeKind = noticeKind;
        }

        public void setNoticeWay(Character noticeWay) {
            this.noticeWay = noticeWay;
        }

        public void setNoticeCaption(String noticeCaption) {
            this.noticeCaption = noticeCaption;
        }

        public void setNoticeContent(String noticeContent) {
            this.noticeContent = noticeContent;
        }

        public void setAttachPath(String attachPath) {
            this.attachPath = attachPath;
        }

        public void setNoticeCaddress(String noticeCaddress) {
            this.noticeCaddress = noticeCaddress;
        }

        public void setServerAddress(String serverAddress) {
            this.serverAddress = serverAddress;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setClientName(String clientName) {
            this.clientName = clientName;
        }

        public void setCompanyName(String companyName) {
            this.companyName = companyName;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setEmailDns(String emailDns) {
            this.emailDns = emailDns;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetNoticelogPollingInnerOutput:(");
            buffer.append("initDate:" + this.initDate);
            buffer.append(",serialNo:" + this.serialNo);
            buffer.append(",noticeKind:" + this.noticeKind);
            buffer.append(",noticeWay:" + this.noticeWay);
            buffer.append(",noticeCaption:" + this.noticeCaption);
            buffer.append(",noticeContent:" + this.noticeContent);
            buffer.append(",attachPath:" + this.attachPath);
            buffer.append(",noticeCaddress:" + this.noticeCaddress);
            buffer.append(",serverAddress:" + this.serverAddress);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",clientName:" + this.clientName);
            buffer.append(",companyName:" + this.companyName);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",emailDns:" + this.emailDns);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.initDate);
            builder.append(this.serialNo);
            builder.append(this.noticeKind);
            builder.append(this.noticeWay);
            builder.append(this.noticeCaption);
            builder.append(this.noticeContent);
            builder.append(this.attachPath);
            builder.append(this.noticeCaddress);
            builder.append(this.serverAddress);
            builder.append(this.clientId);
            builder.append(this.clientName);
            builder.append(this.companyName);
            builder.append(this.branchNo);
            builder.append(this.emailDns);
            return builder.toHashCode();
        }

        public boolean equals(InnerMnpService.GetNoticelogPollingInnerOutput obj) {
            if (obj instanceof InnerMnpService.GetNoticelogPollingInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.initDate, obj.initDate);
                builder.append(this.serialNo, obj.serialNo);
                builder.append(this.noticeKind, obj.noticeKind);
                builder.append(this.noticeWay, obj.noticeWay);
                builder.append(this.noticeCaption, obj.noticeCaption);
                builder.append(this.noticeContent, obj.noticeContent);
                builder.append(this.attachPath, obj.attachPath);
                builder.append(this.noticeCaddress, obj.noticeCaddress);
                builder.append(this.serverAddress, obj.serverAddress);
                builder.append(this.clientId, obj.clientId);
                builder.append(this.clientName, obj.clientName);
                builder.append(this.companyName, obj.companyName);
                builder.append(this.branchNo, obj.branchNo);
                builder.append(this.emailDns, obj.emailDns);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetNoticelogPollingInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @NotNull(
                message = "不能为空"
        )
        private Integer opBranchNo;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String operatorNo;
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String clientId = " ";
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String enNoticeKind = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character noticeWay;
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String enStatus = " ";
        private Integer resendTimes = 0;
        private Integer requestNum = 0;
        @SinogramLength(
                min = 0,
                max = 100,
                charset = "utf-8"
        )
        private String positionStr = " ";

        public GetNoticelogPollingInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo;
        }

        public String getOperatorNo() {
            return this.operatorNo;
        }

        public String getOpStation() {
            return this.opStation;
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay;
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getEnNoticeKind() {
            if (this.enNoticeKind == null) {
                return " ";
            } else {
                return this.enNoticeKind.isEmpty() ? " " : this.enNoticeKind;
            }
        }

        public Character getNoticeWay() {
            return this.noticeWay;
        }

        public String getEnStatus() {
            if (this.enStatus == null) {
                return " ";
            } else {
                return this.enStatus.isEmpty() ? " " : this.enStatus;
            }
        }

        public Integer getResendTimes() {
            return this.resendTimes != null ? this.resendTimes : 0;
        }

        public Integer getRequestNum() {
            return this.requestNum != null ? this.requestNum : 0;
        }

        public String getPositionStr() {
            if (this.positionStr == null) {
                return " ";
            } else {
                return this.positionStr.isEmpty() ? " " : this.positionStr;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setEnNoticeKind(String enNoticeKind) {
            this.enNoticeKind = enNoticeKind;
        }

        public void setNoticeWay(Character noticeWay) {
            this.noticeWay = noticeWay;
        }

        public void setEnStatus(String enStatus) {
            this.enStatus = enStatus;
        }

        public void setResendTimes(Integer resendTimes) {
            this.resendTimes = resendTimes;
        }

        public void setRequestNum(Integer requestNum) {
            this.requestNum = requestNum;
        }

        public void setPositionStr(String positionStr) {
            this.positionStr = positionStr;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetNoticelogPollingInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",enNoticeKind:" + this.enNoticeKind);
            buffer.append(",noticeWay:" + this.noticeWay);
            buffer.append(",enStatus:" + this.enStatus);
            buffer.append(",resendTimes:" + this.resendTimes);
            buffer.append(",requestNum:" + this.requestNum);
            buffer.append(",positionStr:" + this.positionStr);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.clientId);
            builder.append(this.enNoticeKind);
            builder.append(this.noticeWay);
            builder.append(this.enStatus);
            builder.append(this.resendTimes);
            builder.append(this.requestNum);
            builder.append(this.positionStr);
            return builder.toHashCode();
        }

        public boolean equals(InnerMnpService.GetNoticelogPollingInnerInput obj) {
            if (obj instanceof InnerMnpService.GetNoticelogPollingInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.clientId, obj.clientId);
                builder.append(this.enNoticeKind, obj.enNoticeKind);
                builder.append(this.noticeWay, obj.noticeWay);
                builder.append(this.enStatus, obj.enStatus);
                builder.append(this.resendTimes, obj.resendTimes);
                builder.append(this.requestNum, obj.requestNum);
                builder.append(this.positionStr, obj.positionStr);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostNoticelogBatchGenerateInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private List<Long> serialNo;

        public PostNoticelogBatchGenerateInnerOutput() {
        }

        public List<Long> getSerialNo() {
            return this.serialNo;
        }

        public void setSerialNo(List<Long> serialNo) {
            this.serialNo = serialNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostNoticelogBatchGenerateInnerOutput:(");
            buffer.append("serialNo:" + this.serialNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.serialNo);
            return builder.toHashCode();
        }

        public boolean equals(InnerMnpService.PostNoticelogBatchGenerateInnerOutput obj) {
            if (obj instanceof InnerMnpService.PostNoticelogBatchGenerateInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.serialNo, obj.serialNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostNoticelogBatchGenerateInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @NotNull(
                message = "不能为空"
        )
        private Integer opBranchNo;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String operatorNo;
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay;
        private String noticeClob = " ";

        public PostNoticelogBatchGenerateInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo;
        }

        public String getOperatorNo() {
            return this.operatorNo;
        }

        public String getOpStation() {
            return this.opStation;
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay;
        }

        public String getNoticeClob() {
            if (this.noticeClob == null) {
                return " ";
            } else {
                return this.noticeClob.isEmpty() ? " " : this.noticeClob;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setNoticeClob(String noticeClob) {
            this.noticeClob = noticeClob;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostNoticelogBatchGenerateInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",noticeClob:" + this.noticeClob);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.noticeClob);
            return builder.toHashCode();
        }

        public boolean equals(InnerMnpService.PostNoticelogBatchGenerateInnerInput obj) {
            if (obj instanceof InnerMnpService.PostNoticelogBatchGenerateInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.noticeClob, obj.noticeClob);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetNoticeargInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer noticeKind = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character noticeWay = ' ';
        private Integer updateDate = 0;
        private Integer updateTime = 0;
        private Integer remindDays = 0;
        private Integer issueKind = 0;
        private String noticeTemplate = " ";
        private String noticeCaption = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character chargeFlag = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character sendType = ' ';
        private Integer sendTime = 0;
        private Integer endTime = 0;
        private String groupField = " ";
        private String noticeCtrlstr = " ";
        private String remark = " ";

        public GetNoticeargInnerOutput() {
        }

        public Integer getNoticeKind() {
            return this.noticeKind != null ? this.noticeKind : 0;
        }

        public Character getNoticeWay() {
            return this.noticeWay != null ? this.noticeWay : ' ';
        }

        public Integer getUpdateDate() {
            return this.updateDate != null ? this.updateDate : 0;
        }

        public Integer getUpdateTime() {
            return this.updateTime != null ? this.updateTime : 0;
        }

        public Integer getRemindDays() {
            return this.remindDays != null ? this.remindDays : 0;
        }

        public Integer getIssueKind() {
            return this.issueKind != null ? this.issueKind : 0;
        }

        public String getNoticeTemplate() {
            if (this.noticeTemplate == null) {
                return " ";
            } else {
                return this.noticeTemplate.isEmpty() ? " " : this.noticeTemplate;
            }
        }

        public String getNoticeCaption() {
            if (this.noticeCaption == null) {
                return " ";
            } else {
                return this.noticeCaption.isEmpty() ? " " : this.noticeCaption;
            }
        }

        public Character getChargeFlag() {
            return this.chargeFlag != null ? this.chargeFlag : ' ';
        }

        public Character getSendType() {
            return this.sendType != null ? this.sendType : ' ';
        }

        public Integer getSendTime() {
            return this.sendTime != null ? this.sendTime : 0;
        }

        public Integer getEndTime() {
            return this.endTime != null ? this.endTime : 0;
        }

        public String getGroupField() {
            if (this.groupField == null) {
                return " ";
            } else {
                return this.groupField.isEmpty() ? " " : this.groupField;
            }
        }

        public String getNoticeCtrlstr() {
            if (this.noticeCtrlstr == null) {
                return " ";
            } else {
                return this.noticeCtrlstr.isEmpty() ? " " : this.noticeCtrlstr;
            }
        }

        public String getRemark() {
            if (this.remark == null) {
                return " ";
            } else {
                return this.remark.isEmpty() ? " " : this.remark;
            }
        }

        public void setNoticeKind(Integer noticeKind) {
            this.noticeKind = noticeKind;
        }

        public void setNoticeWay(Character noticeWay) {
            this.noticeWay = noticeWay;
        }

        public void setUpdateDate(Integer updateDate) {
            this.updateDate = updateDate;
        }

        public void setUpdateTime(Integer updateTime) {
            this.updateTime = updateTime;
        }

        public void setRemindDays(Integer remindDays) {
            this.remindDays = remindDays;
        }

        public void setIssueKind(Integer issueKind) {
            this.issueKind = issueKind;
        }

        public void setNoticeTemplate(String noticeTemplate) {
            this.noticeTemplate = noticeTemplate;
        }

        public void setNoticeCaption(String noticeCaption) {
            this.noticeCaption = noticeCaption;
        }

        public void setChargeFlag(Character chargeFlag) {
            this.chargeFlag = chargeFlag;
        }

        public void setSendType(Character sendType) {
            this.sendType = sendType;
        }

        public void setSendTime(Integer sendTime) {
            this.sendTime = sendTime;
        }

        public void setEndTime(Integer endTime) {
            this.endTime = endTime;
        }

        public void setGroupField(String groupField) {
            this.groupField = groupField;
        }

        public void setNoticeCtrlstr(String noticeCtrlstr) {
            this.noticeCtrlstr = noticeCtrlstr;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetNoticeargInnerOutput:(");
            buffer.append("noticeKind:" + this.noticeKind);
            buffer.append(",noticeWay:" + this.noticeWay);
            buffer.append(",updateDate:" + this.updateDate);
            buffer.append(",updateTime:" + this.updateTime);
            buffer.append(",remindDays:" + this.remindDays);
            buffer.append(",issueKind:" + this.issueKind);
            buffer.append(",noticeTemplate:" + this.noticeTemplate);
            buffer.append(",noticeCaption:" + this.noticeCaption);
            buffer.append(",chargeFlag:" + this.chargeFlag);
            buffer.append(",sendType:" + this.sendType);
            buffer.append(",sendTime:" + this.sendTime);
            buffer.append(",endTime:" + this.endTime);
            buffer.append(",groupField:" + this.groupField);
            buffer.append(",noticeCtrlstr:" + this.noticeCtrlstr);
            buffer.append(",remark:" + this.remark);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.noticeKind);
            builder.append(this.noticeWay);
            builder.append(this.updateDate);
            builder.append(this.updateTime);
            builder.append(this.remindDays);
            builder.append(this.issueKind);
            builder.append(this.noticeTemplate);
            builder.append(this.noticeCaption);
            builder.append(this.chargeFlag);
            builder.append(this.sendType);
            builder.append(this.sendTime);
            builder.append(this.endTime);
            builder.append(this.groupField);
            builder.append(this.noticeCtrlstr);
            builder.append(this.remark);
            return builder.toHashCode();
        }

        public boolean equals(InnerMnpService.GetNoticeargInnerOutput obj) {
            if (obj instanceof InnerMnpService.GetNoticeargInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.noticeKind, obj.noticeKind);
                builder.append(this.noticeWay, obj.noticeWay);
                builder.append(this.updateDate, obj.updateDate);
                builder.append(this.updateTime, obj.updateTime);
                builder.append(this.remindDays, obj.remindDays);
                builder.append(this.issueKind, obj.issueKind);
                builder.append(this.noticeTemplate, obj.noticeTemplate);
                builder.append(this.noticeCaption, obj.noticeCaption);
                builder.append(this.chargeFlag, obj.chargeFlag);
                builder.append(this.sendType, obj.sendType);
                builder.append(this.sendTime, obj.sendTime);
                builder.append(this.endTime, obj.endTime);
                builder.append(this.groupField, obj.groupField);
                builder.append(this.noticeCtrlstr, obj.noticeCtrlstr);
                builder.append(this.remark, obj.remark);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetNoticeargInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @NotNull(
                message = "不能为空"
        )
        private Integer opBranchNo;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String operatorNo;
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character chargeFlag = ' ';
        private Integer noticeKind = 0;

        public GetNoticeargInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo;
        }

        public String getOperatorNo() {
            return this.operatorNo;
        }

        public String getOpStation() {
            return this.opStation;
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay;
        }

        public Character getChargeFlag() {
            return this.chargeFlag != null ? this.chargeFlag : ' ';
        }

        public Integer getNoticeKind() {
            return this.noticeKind != null ? this.noticeKind : 0;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setChargeFlag(Character chargeFlag) {
            this.chargeFlag = chargeFlag;
        }

        public void setNoticeKind(Integer noticeKind) {
            this.noticeKind = noticeKind;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetNoticeargInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",chargeFlag:" + this.chargeFlag);
            buffer.append(",noticeKind:" + this.noticeKind);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.chargeFlag);
            builder.append(this.noticeKind);
            return builder.toHashCode();
        }

        public boolean equals(InnerMnpService.GetNoticeargInnerInput obj) {
            if (obj instanceof InnerMnpService.GetNoticeargInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.chargeFlag, obj.chargeFlag);
                builder.append(this.noticeKind, obj.noticeKind);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostNoticelogGenerateInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String opRemark = " ";

        public PostNoticelogGenerateInnerOutput() {
        }

        public String getOpRemark() {
            if (this.opRemark == null) {
                return " ";
            } else {
                return this.opRemark.isEmpty() ? " " : this.opRemark;
            }
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostNoticelogGenerateInnerOutput:(");
            buffer.append("opRemark:" + this.opRemark);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opRemark);
            return builder.toHashCode();
        }

        public boolean equals(InnerMnpService.PostNoticelogGenerateInnerOutput obj) {
            if (obj instanceof InnerMnpService.PostNoticelogGenerateInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opRemark, obj.opRemark);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostNoticelogGenerateInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @NotNull(
                message = "不能为空"
        )
        private Integer opBranchNo;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String operatorNo;
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay;
        @NotEmpty(
                message = "不能为空"
        )
        private String noticeClob;

        public PostNoticelogGenerateInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo;
        }

        public String getOperatorNo() {
            return this.operatorNo;
        }

        public String getOpStation() {
            return this.opStation;
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay;
        }

        public String getNoticeClob() {
            return this.noticeClob;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setNoticeClob(String noticeClob) {
            this.noticeClob = noticeClob;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostNoticelogGenerateInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",noticeClob:" + this.noticeClob);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.noticeClob);
            return builder.toHashCode();
        }

        public boolean equals(InnerMnpService.PostNoticelogGenerateInnerInput obj) {
            if (obj instanceof InnerMnpService.PostNoticelogGenerateInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.noticeClob, obj.noticeClob);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostNoticelogOneSendInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String opRemark = " ";
        private Long serialNo = 0L;

        public PostNoticelogOneSendInnerOutput() {
        }

        public String getOpRemark() {
            if (this.opRemark == null) {
                return " ";
            } else {
                return this.opRemark.isEmpty() ? " " : this.opRemark;
            }
        }

        public Long getSerialNo() {
            return this.serialNo != null ? this.serialNo : 0L;
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public void setSerialNo(Long serialNo) {
            this.serialNo = serialNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostNoticelogOneSendInnerOutput:(");
            buffer.append("opRemark:" + this.opRemark);
            buffer.append(",serialNo:" + this.serialNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opRemark);
            builder.append(this.serialNo);
            return builder.toHashCode();
        }

        public boolean equals(InnerMnpService.PostNoticelogOneSendInnerOutput obj) {
            if (obj instanceof InnerMnpService.PostNoticelogOneSendInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opRemark, obj.opRemark);
                builder.append(this.serialNo, obj.serialNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostNoticelogOneSendInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @NotNull(
                message = "不能为空"
        )
        private Integer opBranchNo;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String operatorNo;
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character noticeWay;
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String noticeCaption = " ";
        @SinogramLength(
                min = 0,
                max = 16000,
                charset = "utf-8"
        )
        private String noticeContent = " ";
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String noticeCaddress = " ";
        @SinogramLength(
                min = 1,
                max = 180,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String address;
        private Integer branchNo = 0;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId;
        @SinogramLength(
                min = 0,
                max = 90,
                charset = "utf-8"
        )
        private String clientName = " ";
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String remark = " ";
        private Integer noticeKind = 0;
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String attachPath = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String noticeCtrlstr = " ";

        public PostNoticelogOneSendInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo;
        }

        public String getOperatorNo() {
            return this.operatorNo;
        }

        public String getOpStation() {
            return this.opStation;
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay;
        }

        public Character getNoticeWay() {
            return this.noticeWay;
        }

        public String getNoticeCaption() {
            if (this.noticeCaption == null) {
                return " ";
            } else {
                return this.noticeCaption.isEmpty() ? " " : this.noticeCaption;
            }
        }

        public String getNoticeContent() {
            if (this.noticeContent == null) {
                return " ";
            } else {
                return this.noticeContent.isEmpty() ? " " : this.noticeContent;
            }
        }

        public String getNoticeCaddress() {
            if (this.noticeCaddress == null) {
                return " ";
            } else {
                return this.noticeCaddress.isEmpty() ? " " : this.noticeCaddress;
            }
        }

        public String getAddress() {
            return this.address;
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getClientId() {
            return this.clientId;
        }

        public String getClientName() {
            if (this.clientName == null) {
                return " ";
            } else {
                return this.clientName.isEmpty() ? " " : this.clientName;
            }
        }

        public String getRemark() {
            if (this.remark == null) {
                return " ";
            } else {
                return this.remark.isEmpty() ? " " : this.remark;
            }
        }

        public Integer getNoticeKind() {
            return this.noticeKind != null ? this.noticeKind : 0;
        }

        public String getAttachPath() {
            if (this.attachPath == null) {
                return " ";
            } else {
                return this.attachPath.isEmpty() ? " " : this.attachPath;
            }
        }

        public String getNoticeCtrlstr() {
            if (this.noticeCtrlstr == null) {
                return " ";
            } else {
                return this.noticeCtrlstr.isEmpty() ? " " : this.noticeCtrlstr;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setNoticeWay(Character noticeWay) {
            this.noticeWay = noticeWay;
        }

        public void setNoticeCaption(String noticeCaption) {
            this.noticeCaption = noticeCaption;
        }

        public void setNoticeContent(String noticeContent) {
            this.noticeContent = noticeContent;
        }

        public void setNoticeCaddress(String noticeCaddress) {
            this.noticeCaddress = noticeCaddress;
        }

        public void setAddress(String address) {
            this.address = address;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setClientName(String clientName) {
            this.clientName = clientName;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public void setNoticeKind(Integer noticeKind) {
            this.noticeKind = noticeKind;
        }

        public void setAttachPath(String attachPath) {
            this.attachPath = attachPath;
        }

        public void setNoticeCtrlstr(String noticeCtrlstr) {
            this.noticeCtrlstr = noticeCtrlstr;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostNoticelogOneSendInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",noticeWay:" + this.noticeWay);
            buffer.append(",noticeCaption:" + this.noticeCaption);
            buffer.append(",noticeContent:" + this.noticeContent);
            buffer.append(",noticeCaddress:" + this.noticeCaddress);
            buffer.append(",address:" + this.address);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",clientName:" + this.clientName);
            buffer.append(",remark:" + this.remark);
            buffer.append(",noticeKind:" + this.noticeKind);
            buffer.append(",attachPath:" + this.attachPath);
            buffer.append(",noticeCtrlstr:" + this.noticeCtrlstr);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.noticeWay);
            builder.append(this.noticeCaption);
            builder.append(this.noticeContent);
            builder.append(this.noticeCaddress);
            builder.append(this.address);
            builder.append(this.branchNo);
            builder.append(this.clientId);
            builder.append(this.clientName);
            builder.append(this.remark);
            builder.append(this.noticeKind);
            builder.append(this.attachPath);
            builder.append(this.noticeCtrlstr);
            return builder.toHashCode();
        }

        public boolean equals(InnerMnpService.PostNoticelogOneSendInnerInput obj) {
            if (obj instanceof InnerMnpService.PostNoticelogOneSendInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.noticeWay, obj.noticeWay);
                builder.append(this.noticeCaption, obj.noticeCaption);
                builder.append(this.noticeContent, obj.noticeContent);
                builder.append(this.noticeCaddress, obj.noticeCaddress);
                builder.append(this.address, obj.address);
                builder.append(this.branchNo, obj.branchNo);
                builder.append(this.clientId, obj.clientId);
                builder.append(this.clientName, obj.clientName);
                builder.append(this.remark, obj.remark);
                builder.append(this.noticeKind, obj.noticeKind);
                builder.append(this.attachPath, obj.attachPath);
                builder.append(this.noticeCtrlstr, obj.noticeCtrlstr);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutDayinitinfoDateChangeInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer initDate = 0;

        public PutDayinitinfoDateChangeInnerOutput() {
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutDayinitinfoDateChangeInnerOutput:(");
            buffer.append("initDate:" + this.initDate);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.initDate);
            return builder.toHashCode();
        }

        public boolean equals(InnerMnpService.PutDayinitinfoDateChangeInnerOutput obj) {
            if (obj instanceof InnerMnpService.PutDayinitinfoDateChangeInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.initDate, obj.initDate);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutDayinitinfoDateChangeInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @NotNull(
                message = "不能为空"
        )
        private Integer opBranchNo;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String operatorNo;
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay;

        public PutDayinitinfoDateChangeInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo;
        }

        public String getOperatorNo() {
            return this.operatorNo;
        }

        public String getOpStation() {
            return this.opStation;
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutDayinitinfoDateChangeInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            return builder.toHashCode();
        }

        public boolean equals(InnerMnpService.PutDayinitinfoDateChangeInnerInput obj) {
            if (obj instanceof InnerMnpService.PutDayinitinfoDateChangeInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostNoticelogToCopyAddressInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String remark = " ";

        public PostNoticelogToCopyAddressInnerOutput() {
        }

        public String getRemark() {
            if (this.remark == null) {
                return " ";
            } else {
                return this.remark.isEmpty() ? " " : this.remark;
            }
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostNoticelogToCopyAddressInnerOutput:(");
            buffer.append("remark:" + this.remark);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.remark);
            return builder.toHashCode();
        }

        public boolean equals(InnerMnpService.PostNoticelogToCopyAddressInnerOutput obj) {
            if (obj instanceof InnerMnpService.PostNoticelogToCopyAddressInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.remark, obj.remark);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostNoticelogToCopyAddressInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @NotNull(
                message = "不能为空"
        )
        private Integer opBranchNo;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String operatorNo;
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay;
        private String noticeClob = " ";

        public PostNoticelogToCopyAddressInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo;
        }

        public String getOperatorNo() {
            return this.operatorNo;
        }

        public String getOpStation() {
            return this.opStation;
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay;
        }

        public String getNoticeClob() {
            if (this.noticeClob == null) {
                return " ";
            } else {
                return this.noticeClob.isEmpty() ? " " : this.noticeClob;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setNoticeClob(String noticeClob) {
            this.noticeClob = noticeClob;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostNoticelogToCopyAddressInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",noticeClob:" + this.noticeClob);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.noticeClob);
            return builder.toHashCode();
        }

        public boolean equals(InnerMnpService.PostNoticelogToCopyAddressInnerInput obj) {
            if (obj instanceof InnerMnpService.PostNoticelogToCopyAddressInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.noticeClob, obj.noticeClob);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostNoticelogOneGenerateInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String opRemark = " ";

        public PostNoticelogOneGenerateInnerOutput() {
        }

        public String getOpRemark() {
            if (this.opRemark == null) {
                return " ";
            } else {
                return this.opRemark.isEmpty() ? " " : this.opRemark;
            }
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostNoticelogOneGenerateInnerOutput:(");
            buffer.append("opRemark:" + this.opRemark);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opRemark);
            return builder.toHashCode();
        }

        public boolean equals(InnerMnpService.PostNoticelogOneGenerateInnerOutput obj) {
            if (obj instanceof InnerMnpService.PostNoticelogOneGenerateInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opRemark, obj.opRemark);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostNoticelogOneGenerateInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @NotNull(
                message = "不能为空"
        )
        private Integer opBranchNo;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String operatorNo;
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay;
        @NotEmpty(
                message = "不能为空"
        )
        private String noticePubClob;
        @NotEmpty(
                message = "不能为空"
        )
        private String noticeBizClob;
        @NotEmpty(
                message = "不能为空"
        )
        private String noticeBizDetial;

        public PostNoticelogOneGenerateInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo;
        }

        public String getOperatorNo() {
            return this.operatorNo;
        }

        public String getOpStation() {
            return this.opStation;
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay;
        }

        public String getNoticePubClob() {
            return this.noticePubClob;
        }

        public String getNoticeBizClob() {
            return this.noticeBizClob;
        }

        public String getNoticeBizDetial() {
            return this.noticeBizDetial;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setNoticePubClob(String noticePubClob) {
            this.noticePubClob = noticePubClob;
        }

        public void setNoticeBizClob(String noticeBizClob) {
            this.noticeBizClob = noticeBizClob;
        }

        public void setNoticeBizDetial(String noticeBizDetial) {
            this.noticeBizDetial = noticeBizDetial;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostNoticelogOneGenerateInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",noticePubClob:" + this.noticePubClob);
            buffer.append(",noticeBizClob:" + this.noticeBizClob);
            buffer.append(",noticeBizDetial:" + this.noticeBizDetial);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.noticePubClob);
            builder.append(this.noticeBizClob);
            builder.append(this.noticeBizDetial);
            return builder.toHashCode();
        }

        public boolean equals(InnerMnpService.PostNoticelogOneGenerateInnerInput obj) {
            if (obj instanceof InnerMnpService.PostNoticelogOneGenerateInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.noticePubClob, obj.noticePubClob);
                builder.append(this.noticeBizClob, obj.noticeBizClob);
                builder.append(this.noticeBizDetial, obj.noticeBizDetial);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class DeleteDayinitinfoDatainitInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer initDate = 0;

        public DeleteDayinitinfoDatainitInnerOutput() {
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("DeleteDayinitinfoDatainitInnerOutput:(");
            buffer.append("initDate:" + this.initDate);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.initDate);
            return builder.toHashCode();
        }

        public boolean equals(InnerMnpService.DeleteDayinitinfoDatainitInnerOutput obj) {
            if (obj instanceof InnerMnpService.DeleteDayinitinfoDatainitInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.initDate, obj.initDate);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class DeleteDayinitinfoDatainitInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @NotNull(
                message = "不能为空"
        )
        private Integer opBranchNo;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String operatorNo;
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay;

        public DeleteDayinitinfoDatainitInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo;
        }

        public String getOperatorNo() {
            return this.operatorNo;
        }

        public String getOpStation() {
            return this.opStation;
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("DeleteDayinitinfoDatainitInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            return builder.toHashCode();
        }

        public boolean equals(InnerMnpService.DeleteDayinitinfoDatainitInnerInput obj) {
            if (obj instanceof InnerMnpService.DeleteDayinitinfoDatainitInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetNoticelogInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer initDate = 0;
        private Long serialNo = 0L;
        private Integer currDate = 0;
        private Integer currTime = 0;
        private String operatorNo = " ";
        private Integer opBranchNo = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private String opStation = " ";
        private Integer combNo = 0;
        private Integer branchNo = 0;
        private String clientId = " ";
        private String clientName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character noticeStatus = ' ';
        private Integer noticeKind = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character noticeWay = ' ';
        private String noticeCaption = " ";
        private String noticeContent = " ";
        private String noticeCaddress = " ";
        private String address = " ";
        private String attachPath = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character realAction = ' ';
        private Integer reportTime = 0;
        private Integer resendTimes = 0;
        private Integer dateClear = 0;
        private String remark = " ";
        private String entrustReference = " ";
        private String positionStr = " ";

        public GetNoticelogInnerOutput() {
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public Long getSerialNo() {
            return this.serialNo != null ? this.serialNo : 0L;
        }

        public Integer getCurrDate() {
            return this.currDate != null ? this.currDate : 0;
        }

        public Integer getCurrTime() {
            return this.currTime != null ? this.currTime : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Integer getCombNo() {
            return this.combNo != null ? this.combNo : 0;
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getClientName() {
            if (this.clientName == null) {
                return " ";
            } else {
                return this.clientName.isEmpty() ? " " : this.clientName;
            }
        }

        public Character getNoticeStatus() {
            return this.noticeStatus != null ? this.noticeStatus : ' ';
        }

        public Integer getNoticeKind() {
            return this.noticeKind != null ? this.noticeKind : 0;
        }

        public Character getNoticeWay() {
            return this.noticeWay != null ? this.noticeWay : ' ';
        }

        public String getNoticeCaption() {
            if (this.noticeCaption == null) {
                return " ";
            } else {
                return this.noticeCaption.isEmpty() ? " " : this.noticeCaption;
            }
        }

        public String getNoticeContent() {
            if (this.noticeContent == null) {
                return " ";
            } else {
                return this.noticeContent.isEmpty() ? " " : this.noticeContent;
            }
        }

        public String getNoticeCaddress() {
            if (this.noticeCaddress == null) {
                return " ";
            } else {
                return this.noticeCaddress.isEmpty() ? " " : this.noticeCaddress;
            }
        }

        public String getAddress() {
            if (this.address == null) {
                return " ";
            } else {
                return this.address.isEmpty() ? " " : this.address;
            }
        }

        public String getAttachPath() {
            if (this.attachPath == null) {
                return " ";
            } else {
                return this.attachPath.isEmpty() ? " " : this.attachPath;
            }
        }

        public Character getRealAction() {
            return this.realAction != null ? this.realAction : ' ';
        }

        public Integer getReportTime() {
            return this.reportTime != null ? this.reportTime : 0;
        }

        public Integer getResendTimes() {
            return this.resendTimes != null ? this.resendTimes : 0;
        }

        public Integer getDateClear() {
            return this.dateClear != null ? this.dateClear : 0;
        }

        public String getRemark() {
            if (this.remark == null) {
                return " ";
            } else {
                return this.remark.isEmpty() ? " " : this.remark;
            }
        }

        public String getEntrustReference() {
            if (this.entrustReference == null) {
                return " ";
            } else {
                return this.entrustReference.isEmpty() ? " " : this.entrustReference;
            }
        }

        public String getPositionStr() {
            if (this.positionStr == null) {
                return " ";
            } else {
                return this.positionStr.isEmpty() ? " " : this.positionStr;
            }
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public void setSerialNo(Long serialNo) {
            this.serialNo = serialNo;
        }

        public void setCurrDate(Integer currDate) {
            this.currDate = currDate;
        }

        public void setCurrTime(Integer currTime) {
            this.currTime = currTime;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setCombNo(Integer combNo) {
            this.combNo = combNo;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setClientName(String clientName) {
            this.clientName = clientName;
        }

        public void setNoticeStatus(Character noticeStatus) {
            this.noticeStatus = noticeStatus;
        }

        public void setNoticeKind(Integer noticeKind) {
            this.noticeKind = noticeKind;
        }

        public void setNoticeWay(Character noticeWay) {
            this.noticeWay = noticeWay;
        }

        public void setNoticeCaption(String noticeCaption) {
            this.noticeCaption = noticeCaption;
        }

        public void setNoticeContent(String noticeContent) {
            this.noticeContent = noticeContent;
        }

        public void setNoticeCaddress(String noticeCaddress) {
            this.noticeCaddress = noticeCaddress;
        }

        public void setAddress(String address) {
            this.address = address;
        }

        public void setAttachPath(String attachPath) {
            this.attachPath = attachPath;
        }

        public void setRealAction(Character realAction) {
            this.realAction = realAction;
        }

        public void setReportTime(Integer reportTime) {
            this.reportTime = reportTime;
        }

        public void setResendTimes(Integer resendTimes) {
            this.resendTimes = resendTimes;
        }

        public void setDateClear(Integer dateClear) {
            this.dateClear = dateClear;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public void setEntrustReference(String entrustReference) {
            this.entrustReference = entrustReference;
        }

        public void setPositionStr(String positionStr) {
            this.positionStr = positionStr;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetNoticelogInnerOutput:(");
            buffer.append("initDate:" + this.initDate);
            buffer.append(",serialNo:" + this.serialNo);
            buffer.append(",currDate:" + this.currDate);
            buffer.append(",currTime:" + this.currTime);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",combNo:" + this.combNo);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",clientName:" + this.clientName);
            buffer.append(",noticeStatus:" + this.noticeStatus);
            buffer.append(",noticeKind:" + this.noticeKind);
            buffer.append(",noticeWay:" + this.noticeWay);
            buffer.append(",noticeCaption:" + this.noticeCaption);
            buffer.append(",noticeContent:" + this.noticeContent);
            buffer.append(",noticeCaddress:" + this.noticeCaddress);
            buffer.append(",address:" + this.address);
            buffer.append(",attachPath:" + this.attachPath);
            buffer.append(",realAction:" + this.realAction);
            buffer.append(",reportTime:" + this.reportTime);
            buffer.append(",resendTimes:" + this.resendTimes);
            buffer.append(",dateClear:" + this.dateClear);
            buffer.append(",remark:" + this.remark);
            buffer.append(",entrustReference:" + this.entrustReference);
            buffer.append(",positionStr:" + this.positionStr);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.initDate);
            builder.append(this.serialNo);
            builder.append(this.currDate);
            builder.append(this.currTime);
            builder.append(this.operatorNo);
            builder.append(this.opBranchNo);
            builder.append(this.opEntrustWay);
            builder.append(this.opStation);
            builder.append(this.combNo);
            builder.append(this.branchNo);
            builder.append(this.clientId);
            builder.append(this.clientName);
            builder.append(this.noticeStatus);
            builder.append(this.noticeKind);
            builder.append(this.noticeWay);
            builder.append(this.noticeCaption);
            builder.append(this.noticeContent);
            builder.append(this.noticeCaddress);
            builder.append(this.address);
            builder.append(this.attachPath);
            builder.append(this.realAction);
            builder.append(this.reportTime);
            builder.append(this.resendTimes);
            builder.append(this.dateClear);
            builder.append(this.remark);
            builder.append(this.entrustReference);
            builder.append(this.positionStr);
            return builder.toHashCode();
        }

        public boolean equals(InnerMnpService.GetNoticelogInnerOutput obj) {
            if (obj instanceof InnerMnpService.GetNoticelogInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.initDate, obj.initDate);
                builder.append(this.serialNo, obj.serialNo);
                builder.append(this.currDate, obj.currDate);
                builder.append(this.currTime, obj.currTime);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.combNo, obj.combNo);
                builder.append(this.branchNo, obj.branchNo);
                builder.append(this.clientId, obj.clientId);
                builder.append(this.clientName, obj.clientName);
                builder.append(this.noticeStatus, obj.noticeStatus);
                builder.append(this.noticeKind, obj.noticeKind);
                builder.append(this.noticeWay, obj.noticeWay);
                builder.append(this.noticeCaption, obj.noticeCaption);
                builder.append(this.noticeContent, obj.noticeContent);
                builder.append(this.noticeCaddress, obj.noticeCaddress);
                builder.append(this.address, obj.address);
                builder.append(this.attachPath, obj.attachPath);
                builder.append(this.realAction, obj.realAction);
                builder.append(this.reportTime, obj.reportTime);
                builder.append(this.resendTimes, obj.resendTimes);
                builder.append(this.dateClear, obj.dateClear);
                builder.append(this.remark, obj.remark);
                builder.append(this.entrustReference, obj.entrustReference);
                builder.append(this.positionStr, obj.positionStr);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetNoticelogInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @NotNull(
                message = "不能为空"
        )
        private Integer opBranchNo;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String operatorNo;
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String clientId = " ";
        private Integer initDate = 0;
        private Long serialNo = 0L;
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String noticeReference = " ";

        public GetNoticelogInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo;
        }

        public String getOperatorNo() {
            return this.operatorNo;
        }

        public String getOpStation() {
            return this.opStation;
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay;
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public Long getSerialNo() {
            return this.serialNo != null ? this.serialNo : 0L;
        }

        public String getNoticeReference() {
            if (this.noticeReference == null) {
                return " ";
            } else {
                return this.noticeReference.isEmpty() ? " " : this.noticeReference;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public void setSerialNo(Long serialNo) {
            this.serialNo = serialNo;
        }

        public void setNoticeReference(String noticeReference) {
            this.noticeReference = noticeReference;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetNoticelogInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",initDate:" + this.initDate);
            buffer.append(",serialNo:" + this.serialNo);
            buffer.append(",noticeReference:" + this.noticeReference);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.clientId);
            builder.append(this.initDate);
            builder.append(this.serialNo);
            builder.append(this.noticeReference);
            return builder.toHashCode();
        }

        public boolean equals(InnerMnpService.GetNoticelogInnerInput obj) {
            if (obj instanceof InnerMnpService.GetNoticelogInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.clientId, obj.clientId);
                builder.append(this.initDate, obj.initDate);
                builder.append(this.serialNo, obj.serialNo);
                builder.append(this.noticeReference, obj.noticeReference);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }
}
