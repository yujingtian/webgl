//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.hundsun.jres.bizframe.cloud.api;

import com.hundsun.jres.bizframe.bean.ChangeUserOutSiteBean;
import com.hundsun.jres.bizframe.bean.GetCurrUserIdByTokenBean;
import com.hundsun.jres.bizframe.bean.IndexInfoBean;
import com.hundsun.jres.bizframe.bean.LoginBean;
import com.hundsun.jres.bizframe.bean.MenuTreeForGuofuBean;
import com.hundsun.jres.bizframe.bean.MenuTreeNode;
import com.hundsun.jres.bizframe.bean.MenuTreeNodeForMVC;
import com.hundsun.jres.bizframe.bean.RpcBean;
import com.hundsun.jres.bizframe.bean.TenantLogoInfoBean;
import com.hundsun.jres.bizframe.bean.UserAuthMenuSearchBean;
import com.hundsun.jres.bizframe.cloud.bean.ResultBean;
import com.hundsun.jres.bizframe.common.util.Key;
import com.hundsun.jres.bizframe.vo.LoginDto;
import com.hundsun.jres.bizframe.vo.ReturnDto;
import com.hundsun.jres.bizframe.vo.VeriyCodeResultDto;
import com.hundsun.jrescloud.rpc.annotation.CloudFunction;
import com.hundsun.jrescloud.rpc.annotation.CloudFunctionParam;
import com.hundsun.jrescloud.rpc.annotation.CloudService;
import java.util.List;
import java.util.Map;

@CloudService(
        validation = true,
        validationNull = false,
        application = "hsxone.omc"
)
public interface IUserLoginService {
    @CloudFunction(
            functionId = "110101",
            apiUrl = "login"
    )
    LoginDto login(LoginBean var1);

    @CloudFunction(
            functionId = "110125",
            apiUrl = "getEmailVerificationCode"
    )
    ReturnDto getEmailVerificationCode(LoginBean var1);

    @CloudFunction(
            functionId = "110111",
            apiUrl = "freePasswordLogin"
    )
    LoginDto freePasswordLogin(LoginBean var1);

    @CloudFunction(
            functionId = "110102",
            apiUrl = "relogin"
    )
    ReturnDto relogin(LoginBean var1);

    @CloudFunction(
            functionId = "110103",
            apiUrl = "logout"
    )
    ReturnDto logout(LoginBean var1);

    @CloudFunction(
            functionId = "110104",
            apiUrl = "getUserAuthMenus"
    )
    List<MenuTreeNode> getUserAuthMenus(UserAuthMenuSearchBean var1);

    @CloudFunction(
            functionId = "110105",
            apiUrl = "loginHasValidateCode"
    )
    boolean loginHasValidateCode();

    @CloudFunction(
            functionId = "110106",
            apiUrl = "getSecurityKey"
    )
    Key getSecurityKey(@CloudFunctionParam("key1") String var1, @CloudFunctionParam("key2") String var2);

    @CloudFunction(
            functionId = "110112",
            apiUrl = "getUserAuthMenusForGuoFu"
    )
    List<MenuTreeForGuofuBean> getUserAuthMenusForGuoFu(LoginBean var1);

    @CloudFunction(
            functionId = "110113",
            apiUrl = "checkPwdExpired"
    )
    boolean checkPwdExpired(LoginBean var1);

    @CloudFunction(
            functionId = "110114",
            apiUrl = "expiredDays"
    )
    Integer expiredDays(LoginBean var1);

    @CloudFunction(
            functionId = "110115",
            apiUrl = "createUserToken"
    )
    ReturnDto createUserToken(LoginBean var1);

    @CloudFunction(
            functionId = "110116",
            apiUrl = "checkUserPwd"
    )
    ReturnDto checkUserPwd(LoginBean var1);

    @CloudFunction(
            functionId = "110117",
            apiUrl = "getUserAuthMenusForMVC"
    )
    List<MenuTreeNodeForMVC> getUserAuthMenusForMVC(LoginBean var1);

    @CloudFunction(
            functionId = "110119",
            apiUrl = "getCheckedPwdStandard"
    )
    Map<String, Object> getCheckedPwdStandard(@CloudFunctionParam("operator_code") String var1);

    @CloudFunction(
            functionId = "110120",
            apiUrl = "kickout"
    )
    ReturnDto kickout(@CloudFunctionParam("key") String var1);

    @CloudFunction(
            functionId = "110121",
            apiUrl = "getIndexInfo"
    )
    IndexInfoBean getIndexInfo(LoginBean var1);

    @CloudFunction(
            functionId = "110122",
            apiUrl = "checkCurrUser"
    )
    ReturnDto checkCurrUser(LoginBean var1);

    @CloudFunction(
            functionId = "110123",
            apiUrl = "userTenantChange"
    )
    LoginDto userTenantChange(LoginBean var1);

    @CloudFunction(
            functionId = "110124",
            apiUrl = "languageChange"
    )
    ReturnDto languageChange(@CloudFunctionParam("lang") String var1, @CloudFunctionParam("operator_code") String var2);

    @CloudFunction(
            functionId = "110129",
            apiUrl = "getVerifyCode"
    )
    VeriyCodeResultDto getVerifyCode();

    @CloudFunction(
            functionId = "110130",
            apiUrl = "isMeetPwdStrength"
    )
    Boolean isMeetPwdStrength(@CloudFunctionParam("operator_code") String var1, @CloudFunctionParam("password") String var2);

    @CloudFunction(
            functionId = "110138",
            apiUrl = "isSessoinTimeout"
    )
    ResultBean isSessoinTimeout(@CloudFunctionParam("user_token") String var1);

    @CloudFunction(
            functionId = "110140",
            apiUrl = "getNewUserAuthMenus"
    )
    List<MenuTreeNode> getNewUserAuthMenus(UserAuthMenuSearchBean var1);

    @CloudFunction(
            functionId = "168888",
            apiUrl = "thirdLogin"
    )
    ReturnDto thirdLogin(RpcBean var1);

    @CloudFunction(
            functionId = "110141",
            apiUrl = "getTenantLogo"
    )
    TenantLogoInfoBean getTenantLogo(LoginBean var1);

    @CloudFunction(
            functionId = "110142",
            apiUrl = "isMatchUserNameAndPwd"
    )
    boolean isMatchUserNameAndPwd(LoginBean var1);

    @CloudFunction(
            functionId = "110144",
            apiUrl = "getUserAvatar"
    )
    String getUserAvatar(@CloudFunctionParam("user_token") String var1);

    @CloudFunction(
            functionId = "110145",
            apiUrl = "checkUserPwdForUF3"
    )
    ReturnDto checkUserPwdForUF3(LoginBean var1);

    @CloudFunction(
            functionId = "110146",
            apiUrl = "getCurrUserIdByToken"
    )
    ReturnDto getCurrUserIdByToken(GetCurrUserIdByTokenBean var1);

    @CloudFunction(
            functionId = "110149",
            apiUrl = "getUserSystems"
    )
    List<MenuTreeNode> getUserSystems(UserAuthMenuSearchBean var1);

    @CloudFunction(
            functionId = "110152",
            apiUrl = "initUserLoginRight"
    )
    ReturnDto initUserLoginRight(LoginBean var1);

    @CloudFunction(
            functionId = "110147",
            apiUrl = "changeUserOutSite"
    )
    ReturnDto changeUserOutSite(ChangeUserOutSiteBean var1);

    @CloudFunction(
            functionId = "110148",
            apiUrl = "getCurrUserInfoByToken"
    )
    LoginDto getCurrUserInfoByToken(LoginBean var1);
}
