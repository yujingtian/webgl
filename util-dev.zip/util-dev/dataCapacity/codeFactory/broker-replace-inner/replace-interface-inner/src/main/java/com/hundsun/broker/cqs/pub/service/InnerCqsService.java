//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.hundsun.broker.cqs.pub.service;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.hundsun.broker.base.PublicChecker.PublicParams;
import com.hundsun.broker.base.databind.CharacterJsonDeserializer;
import com.hundsun.jrescloud.rpc.annotation.CloudFunction;
import com.hundsun.jrescloud.rpc.annotation.CloudService;
import com.hundsun.jrescloud.rpc.def.json.DoubleJsonDeserializer;
import com.hundsun.jrescloud.rpc.def.json.SerializeDoubleDigit;
import com.hundsun.jrescloud.rpc.def.validation.SinogramLength;
import java.io.Serializable;
import java.util.List;
import javax.validation.constraints.NotNull;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

@CloudService(
        validation = true,
        validationNull = false,
        application = "hsbroker.cqs"
)
public interface InnerCqsService {
    @CloudFunction(
            value = "cqs.getAmsagreesignHisPageInner",
            desc = "电子协议签署历史分页查询",
            apiUrl = "/getAmsagreesignHisPageInner"
    )
    InnerCqsService.GetAmsagreesignHisPageInnerOutput getAmsagreesignHisPageInner(InnerCqsService.GetAmsagreesignHisPageInnerInput var1);

    @CloudFunction(
            value = "cqs.getAmsepapersignHisPageInner",
            desc = "无纸化协议签署历史分页查询",
            apiUrl = "/getAmsepapersignHisPageInner"
    )
    InnerCqsService.GetAmsepapersignHisPageInnerOutput getAmsepapersignHisPageInner(InnerCqsService.GetAmsepapersignHisPageInnerInput var1);

    @CloudFunction(
            value = "cqs.getCmstwentyassetInner",
            desc = "20日日均资产查询",
            apiUrl = "/getCmstwentyassetInner"
    )
    List<InnerCqsService.GetCmstwentyassetInnerOutput> getCmstwentyassetInner(InnerCqsService.GetCmstwentyassetInnerInput var1);

    @CloudFunction(
            value = "cqs.getCqsstatementrecordsInner",
            desc = "查询对账单记录",
            apiUrl = "/getCqsstatementrecordsInner"
    )
    InnerCqsService.GetCqsstatementrecordsInnerOutput getCqsstatementrecordsInner(InnerCqsService.GetCqsstatementrecordsInnerInput var1);

    @CloudFunction(
            value = "cqs.getCqssynctablestructureInner",
            desc = "cqs同步表结构信息表查询",
            apiUrl = "/getCqssynctablestructureInner"
    )
    List<InnerCqsService.GetCqssynctablestructureInnerOutput> getCqssynctablestructureInner(InnerCqsService.GetCqssynctablestructureInnerInput var1);

    @CloudFunction(
            value = "cqs.getElgbusinassetInner",
            desc = "适当性总资产获取",
            apiUrl = "/getElgbusinassetInner"
    )
    InnerCqsService.GetElgbusinassetInnerOutput getElgbusinassetInner(InnerCqsService.GetElgbusinassetInnerInput var1);

    @CloudFunction(
            value = "cqs.getElgclientpreferjourInner",
            desc = "历史客户适当性偏好流水查询",
            apiUrl = "/getElgclientpreferjourInner"
    )
    List<InnerCqsService.GetElgclientpreferjourInnerOutput> getElgclientpreferjourInner(InnerCqsService.GetElgclientpreferjourInnerInput var1);

    @CloudFunction(
            value = "cqs.getElghisassetInner",
            desc = "客户历史资产取值",
            apiUrl = "/getElghisassetInner"
    )
    List<InnerCqsService.GetElghisassetInnerOutput> getElghisassetInner(InnerCqsService.GetElghisassetInnerInput var1);

    @CloudFunction(
            value = "cqs.getElgstibclientassetsendInner",
            desc = "科创板报送客户资产信息查询",
            apiUrl = "/getElgstibclientassetsendInner"
    )
    List<InnerCqsService.GetElgstibclientassetsendInnerOutput> getElgstibclientassetsendInner(InnerCqsService.GetElgstibclientassetsendInnerInput var1);

    @CloudFunction(
            value = "cqs.getElgtestjourInner",
            desc = "历史风险测评流水查询",
            apiUrl = "/getElgtestjourInner"
    )
    List<InnerCqsService.GetElgtestjourInnerOutput> getElgtestjourInner(InnerCqsService.GetElgtestjourInnerInput var1);

    @CloudFunction(
            value = "cqs.getPrddataprodrealInner",
            desc = "产品历史持仓查询",
            apiUrl = "/getPrddataprodrealInner"
    )
    List<InnerCqsService.GetPrddataprodrealInnerOutput> getPrddataprodrealInner(InnerCqsService.GetPrddataprodrealInnerInput var1);

    @CloudFunction(
            value = "cqs.getSesblobfileDataInner",
            desc = "中登业务数据信息查询",
            apiUrl = "/getSesblobfileDataInner"
    )
    InnerCqsService.GetSesblobfileDataInnerOutput getSesblobfileDataInner(InnerCqsService.GetSesblobfileDataInnerInput var1);

    @CloudFunction(
            value = "cqs.getSesstkcodeInner",
            desc = "证券代码信息查询",
            apiUrl = "/getSesstkcodeInner"
    )
    InnerCqsService.GetSesstkcodeInnerOutput getSesstkcodeInner(InnerCqsService.GetSesstkcodeInnerInput var1);

    @CloudFunction(
            value = "cqs.postCqsdeliververifyInner",
            desc = "生成交割对账单并上传FTP",
            apiUrl = "/postCqsdeliververifyInner"
    )
    InnerCqsService.PostCqsdeliververifyInnerOutput postCqsdeliververifyInner(InnerCqsService.PostCqsdeliververifyInnerInput var1);

    @CloudFunction(
            value = "cqs.postCqsstatementInner",
            desc = "生成对账单",
            apiUrl = "/postCqsstatementInner"
    )
    InnerCqsService.PostCqsstatementInnerOutput postCqsstatementInner(InnerCqsService.PostCqsstatementInnerInput var1);

    @CloudFunction(
            value = "cqs.putArgInner",
            desc = "系统状态更新",
            apiUrl = "/putArgInner",
            partition = "1"
    )
    InnerCqsService.PutArgInnerOutput putArgInner(InnerCqsService.PutArgInnerInput var1);

    @CloudFunction(
            value = "cqs.putHsfunctionCacheInner",
            desc = "系统功能缓存更新",
            apiUrl = "/putHsfunctionCacheInner"
    )
    void putHsfunctionCacheInner(InnerCqsService.PutHsfunctionCacheInnerInput var1);

    public static class ResultInfoDTO implements Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String opRemark = " ";
        private Long serialNo = 0L;

        public ResultInfoDTO() {
        }

        public String getOpRemark() {
            if (this.opRemark == null) {
                return " ";
            } else {
                return this.opRemark.isEmpty() ? " " : this.opRemark;
            }
        }

        public Long getSerialNo() {
            return this.serialNo != null ? this.serialNo : 0L;
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public void setSerialNo(Long serialNo) {
            this.serialNo = serialNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("ResultInfoDTO:(");
            buffer.append("opRemark:" + this.opRemark);
            buffer.append(",serialNo:" + this.serialNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opRemark);
            builder.append(this.serialNo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerCqsService.ResultInfoDTO) {
                InnerCqsService.ResultInfoDTO test = (InnerCqsService.ResultInfoDTO)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opRemark, test.opRemark);
                builder.append(this.serialNo, test.serialNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class ActblobfileDTO implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer initDate = 0;
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String fileGuid = " ";
        private Long ordinal = 0L;
        private Integer blobNo = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character dealFlag = ' ';
        @SinogramLength(
                min = 0,
                max = 4000,
                charset = "utf-8"
        )
        private String fileObj = " ";
        private Integer dateClear = 0;
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String remark = " ";
        @SinogramLength(
                min = 0,
                max = 100,
                charset = "utf-8"
        )
        private String positionStr = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character reportFlag = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character replyFlag = ' ';

        public ActblobfileDTO() {
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public String getFileGuid() {
            if (this.fileGuid == null) {
                return " ";
            } else {
                return this.fileGuid.isEmpty() ? " " : this.fileGuid;
            }
        }

        public Long getOrdinal() {
            return this.ordinal != null ? this.ordinal : 0L;
        }

        public Integer getBlobNo() {
            return this.blobNo != null ? this.blobNo : 0;
        }

        public Character getDealFlag() {
            return this.dealFlag != null ? this.dealFlag : ' ';
        }

        public String getFileObj() {
            if (this.fileObj == null) {
                return " ";
            } else {
                return this.fileObj.isEmpty() ? " " : this.fileObj;
            }
        }

        public Integer getDateClear() {
            return this.dateClear != null ? this.dateClear : 0;
        }

        public String getRemark() {
            if (this.remark == null) {
                return " ";
            } else {
                return this.remark.isEmpty() ? " " : this.remark;
            }
        }

        public String getPositionStr() {
            if (this.positionStr == null) {
                return " ";
            } else {
                return this.positionStr.isEmpty() ? " " : this.positionStr;
            }
        }

        public Character getReportFlag() {
            return this.reportFlag != null ? this.reportFlag : ' ';
        }

        public Character getReplyFlag() {
            return this.replyFlag != null ? this.replyFlag : ' ';
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public void setFileGuid(String fileGuid) {
            this.fileGuid = fileGuid;
        }

        public void setOrdinal(Long ordinal) {
            this.ordinal = ordinal;
        }

        public void setBlobNo(Integer blobNo) {
            this.blobNo = blobNo;
        }

        public void setDealFlag(Character dealFlag) {
            this.dealFlag = dealFlag;
        }

        public void setFileObj(String fileObj) {
            this.fileObj = fileObj;
        }

        public void setDateClear(Integer dateClear) {
            this.dateClear = dateClear;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public void setPositionStr(String positionStr) {
            this.positionStr = positionStr;
        }

        public void setReportFlag(Character reportFlag) {
            this.reportFlag = reportFlag;
        }

        public void setReplyFlag(Character replyFlag) {
            this.replyFlag = replyFlag;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("ActblobfileDTO:(");
            buffer.append("initDate:" + this.initDate);
            buffer.append(",fileGuid:" + this.fileGuid);
            buffer.append(",ordinal:" + this.ordinal);
            buffer.append(",blobNo:" + this.blobNo);
            buffer.append(",dealFlag:" + this.dealFlag);
            buffer.append(",fileObj:" + this.fileObj);
            buffer.append(",dateClear:" + this.dateClear);
            buffer.append(",remark:" + this.remark);
            buffer.append(",positionStr:" + this.positionStr);
            buffer.append(",reportFlag:" + this.reportFlag);
            buffer.append(",replyFlag:" + this.replyFlag);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.initDate);
            builder.append(this.fileGuid);
            builder.append(this.ordinal);
            builder.append(this.blobNo);
            builder.append(this.dealFlag);
            builder.append(this.fileObj);
            builder.append(this.dateClear);
            builder.append(this.remark);
            builder.append(this.positionStr);
            builder.append(this.reportFlag);
            builder.append(this.replyFlag);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerCqsService.ActblobfileDTO) {
                InnerCqsService.ActblobfileDTO test = (InnerCqsService.ActblobfileDTO)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.initDate, test.initDate);
                builder.append(this.fileGuid, test.fileGuid);
                builder.append(this.ordinal, test.ordinal);
                builder.append(this.blobNo, test.blobNo);
                builder.append(this.dealFlag, test.dealFlag);
                builder.append(this.fileObj, test.fileObj);
                builder.append(this.dateClear, test.dateClear);
                builder.append(this.remark, test.remark);
                builder.append(this.positionStr, test.positionStr);
                builder.append(this.reportFlag, test.reportFlag);
                builder.append(this.replyFlag, test.replyFlag);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class StatementRecordsDTO implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer applyDate = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String clientId = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fundAccount = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character assetProp = ' ';
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String cqsId = " ";
        @SinogramLength(
                min = 0,
                max = 3,
                charset = "utf-8"
        )
        private String moneyType = " ";
        private Integer beginDate = 0;
        private Integer endDate = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character successFlag = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character statementKind = ' ';
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fileStorageId = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String filePath = " ";
        @SinogramLength(
                min = 0,
                max = 100,
                charset = "utf-8"
        )
        private String positionStr = " ";

        public StatementRecordsDTO() {
        }

        public Integer getApplyDate() {
            return this.applyDate != null ? this.applyDate : 0;
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public Character getAssetProp() {
            return this.assetProp != null ? this.assetProp : ' ';
        }

        public String getCqsId() {
            if (this.cqsId == null) {
                return " ";
            } else {
                return this.cqsId.isEmpty() ? " " : this.cqsId;
            }
        }

        public String getMoneyType() {
            if (this.moneyType == null) {
                return " ";
            } else {
                return this.moneyType.isEmpty() ? " " : this.moneyType;
            }
        }

        public Integer getBeginDate() {
            return this.beginDate != null ? this.beginDate : 0;
        }

        public Integer getEndDate() {
            return this.endDate != null ? this.endDate : 0;
        }

        public Character getSuccessFlag() {
            return this.successFlag != null ? this.successFlag : ' ';
        }

        public Character getStatementKind() {
            return this.statementKind != null ? this.statementKind : ' ';
        }

        public String getFileStorageId() {
            if (this.fileStorageId == null) {
                return " ";
            } else {
                return this.fileStorageId.isEmpty() ? " " : this.fileStorageId;
            }
        }

        public String getFilePath() {
            if (this.filePath == null) {
                return " ";
            } else {
                return this.filePath.isEmpty() ? " " : this.filePath;
            }
        }

        public String getPositionStr() {
            if (this.positionStr == null) {
                return " ";
            } else {
                return this.positionStr.isEmpty() ? " " : this.positionStr;
            }
        }

        public void setApplyDate(Integer applyDate) {
            this.applyDate = applyDate;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setAssetProp(Character assetProp) {
            this.assetProp = assetProp;
        }

        public void setCqsId(String cqsId) {
            this.cqsId = cqsId;
        }

        public void setMoneyType(String moneyType) {
            this.moneyType = moneyType;
        }

        public void setBeginDate(Integer beginDate) {
            this.beginDate = beginDate;
        }

        public void setEndDate(Integer endDate) {
            this.endDate = endDate;
        }

        public void setSuccessFlag(Character successFlag) {
            this.successFlag = successFlag;
        }

        public void setStatementKind(Character statementKind) {
            this.statementKind = statementKind;
        }

        public void setFileStorageId(String fileStorageId) {
            this.fileStorageId = fileStorageId;
        }

        public void setFilePath(String filePath) {
            this.filePath = filePath;
        }

        public void setPositionStr(String positionStr) {
            this.positionStr = positionStr;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("StatementRecordsDTO:(");
            buffer.append("applyDate:" + this.applyDate);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",assetProp:" + this.assetProp);
            buffer.append(",cqsId:" + this.cqsId);
            buffer.append(",moneyType:" + this.moneyType);
            buffer.append(",beginDate:" + this.beginDate);
            buffer.append(",endDate:" + this.endDate);
            buffer.append(",successFlag:" + this.successFlag);
            buffer.append(",statementKind:" + this.statementKind);
            buffer.append(",fileStorageId:" + this.fileStorageId);
            buffer.append(",filePath:" + this.filePath);
            buffer.append(",positionStr:" + this.positionStr);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.applyDate);
            builder.append(this.clientId);
            builder.append(this.fundAccount);
            builder.append(this.assetProp);
            builder.append(this.cqsId);
            builder.append(this.moneyType);
            builder.append(this.beginDate);
            builder.append(this.endDate);
            builder.append(this.successFlag);
            builder.append(this.statementKind);
            builder.append(this.fileStorageId);
            builder.append(this.filePath);
            builder.append(this.positionStr);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerCqsService.StatementRecordsDTO) {
                InnerCqsService.StatementRecordsDTO test = (InnerCqsService.StatementRecordsDTO)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.applyDate, test.applyDate);
                builder.append(this.clientId, test.clientId);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.assetProp, test.assetProp);
                builder.append(this.cqsId, test.cqsId);
                builder.append(this.moneyType, test.moneyType);
                builder.append(this.beginDate, test.beginDate);
                builder.append(this.endDate, test.endDate);
                builder.append(this.successFlag, test.successFlag);
                builder.append(this.statementKind, test.statementKind);
                builder.append(this.fileStorageId, test.fileStorageId);
                builder.append(this.filePath, test.filePath);
                builder.append(this.positionStr, test.positionStr);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class AmsepapersignDTO implements Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String agreementId = " ";
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String acptBusinKind = " ";
        @SinogramLength(
                min = 0,
                max = 10,
                charset = "utf-8"
        )
        private String acptBusinId = " ";
        private Integer createDate = 0;
        private Integer createTime = 0;
        private Integer signDate = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String clientId = " ";
        private Integer templateVersion = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fundAccount = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fileStorageId = " ";
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String exchangeType = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character entrustWay = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character certType = ' ';
        @SinogramLength(
                min = 0,
                max = 4000,
                charset = "utf-8"
        )
        private String certSign = " ";
        @SinogramLength(
                min = 0,
                max = 128,
                charset = "utf-8"
        )
        private String certOriginal = " ";
        @SinogramLength(
                min = 0,
                max = 16000,
                charset = "utf-8"
        )
        private String renderField = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character caStatus = ' ';
        private Integer csfcBeginDate = 0;
        private Integer csfcEndDate = 0;
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String agreeType = " ";
        @SinogramLength(
                min = 0,
                max = 10,
                charset = "utf-8"
        )
        private String businessCategoryCustom = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String remark = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String acptId = " ";
        private Long templateId = 0L;
        @SinogramLength(
                min = 0,
                max = 128,
                charset = "utf-8"
        )
        private String templateName = " ";
        @SinogramLength(
                min = 0,
                max = 16000,
                charset = "utf-8"
        )
        private String paramData = " ";

        public AmsepapersignDTO() {
        }

        public String getAgreementId() {
            if (this.agreementId == null) {
                return " ";
            } else {
                return this.agreementId.isEmpty() ? " " : this.agreementId;
            }
        }

        public String getAcptBusinKind() {
            if (this.acptBusinKind == null) {
                return " ";
            } else {
                return this.acptBusinKind.isEmpty() ? " " : this.acptBusinKind;
            }
        }

        public String getAcptBusinId() {
            if (this.acptBusinId == null) {
                return " ";
            } else {
                return this.acptBusinId.isEmpty() ? " " : this.acptBusinId;
            }
        }

        public Integer getCreateDate() {
            return this.createDate != null ? this.createDate : 0;
        }

        public Integer getCreateTime() {
            return this.createTime != null ? this.createTime : 0;
        }

        public Integer getSignDate() {
            return this.signDate != null ? this.signDate : 0;
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public Integer getTemplateVersion() {
            return this.templateVersion != null ? this.templateVersion : 0;
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getFileStorageId() {
            if (this.fileStorageId == null) {
                return " ";
            } else {
                return this.fileStorageId.isEmpty() ? " " : this.fileStorageId;
            }
        }

        public String getExchangeType() {
            if (this.exchangeType == null) {
                return " ";
            } else {
                return this.exchangeType.isEmpty() ? " " : this.exchangeType;
            }
        }

        public Character getEntrustWay() {
            return this.entrustWay != null ? this.entrustWay : ' ';
        }

        public Character getCertType() {
            return this.certType != null ? this.certType : ' ';
        }

        public String getCertSign() {
            if (this.certSign == null) {
                return " ";
            } else {
                return this.certSign.isEmpty() ? " " : this.certSign;
            }
        }

        public String getCertOriginal() {
            if (this.certOriginal == null) {
                return " ";
            } else {
                return this.certOriginal.isEmpty() ? " " : this.certOriginal;
            }
        }

        public String getRenderField() {
            if (this.renderField == null) {
                return " ";
            } else {
                return this.renderField.isEmpty() ? " " : this.renderField;
            }
        }

        public Character getCaStatus() {
            return this.caStatus != null ? this.caStatus : ' ';
        }

        public Integer getCsfcBeginDate() {
            return this.csfcBeginDate != null ? this.csfcBeginDate : 0;
        }

        public Integer getCsfcEndDate() {
            return this.csfcEndDate != null ? this.csfcEndDate : 0;
        }

        public String getAgreeType() {
            if (this.agreeType == null) {
                return " ";
            } else {
                return this.agreeType.isEmpty() ? " " : this.agreeType;
            }
        }

        public String getBusinessCategoryCustom() {
            if (this.businessCategoryCustom == null) {
                return " ";
            } else {
                return this.businessCategoryCustom.isEmpty() ? " " : this.businessCategoryCustom;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getRemark() {
            if (this.remark == null) {
                return " ";
            } else {
                return this.remark.isEmpty() ? " " : this.remark;
            }
        }

        public String getAcptId() {
            if (this.acptId == null) {
                return " ";
            } else {
                return this.acptId.isEmpty() ? " " : this.acptId;
            }
        }

        public Long getTemplateId() {
            return this.templateId != null ? this.templateId : 0L;
        }

        public String getTemplateName() {
            if (this.templateName == null) {
                return " ";
            } else {
                return this.templateName.isEmpty() ? " " : this.templateName;
            }
        }

        public String getParamData() {
            if (this.paramData == null) {
                return " ";
            } else {
                return this.paramData.isEmpty() ? " " : this.paramData;
            }
        }

        public void setAgreementId(String agreementId) {
            this.agreementId = agreementId;
        }

        public void setAcptBusinKind(String acptBusinKind) {
            this.acptBusinKind = acptBusinKind;
        }

        public void setAcptBusinId(String acptBusinId) {
            this.acptBusinId = acptBusinId;
        }

        public void setCreateDate(Integer createDate) {
            this.createDate = createDate;
        }

        public void setCreateTime(Integer createTime) {
            this.createTime = createTime;
        }

        public void setSignDate(Integer signDate) {
            this.signDate = signDate;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setTemplateVersion(Integer templateVersion) {
            this.templateVersion = templateVersion;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setFileStorageId(String fileStorageId) {
            this.fileStorageId = fileStorageId;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public void setEntrustWay(Character entrustWay) {
            this.entrustWay = entrustWay;
        }

        public void setCertType(Character certType) {
            this.certType = certType;
        }

        public void setCertSign(String certSign) {
            this.certSign = certSign;
        }

        public void setCertOriginal(String certOriginal) {
            this.certOriginal = certOriginal;
        }

        public void setRenderField(String renderField) {
            this.renderField = renderField;
        }

        public void setCaStatus(Character caStatus) {
            this.caStatus = caStatus;
        }

        public void setCsfcBeginDate(Integer csfcBeginDate) {
            this.csfcBeginDate = csfcBeginDate;
        }

        public void setCsfcEndDate(Integer csfcEndDate) {
            this.csfcEndDate = csfcEndDate;
        }

        public void setAgreeType(String agreeType) {
            this.agreeType = agreeType;
        }

        public void setBusinessCategoryCustom(String businessCategoryCustom) {
            this.businessCategoryCustom = businessCategoryCustom;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public void setAcptId(String acptId) {
            this.acptId = acptId;
        }

        public void setTemplateId(Long templateId) {
            this.templateId = templateId;
        }

        public void setTemplateName(String templateName) {
            this.templateName = templateName;
        }

        public void setParamData(String paramData) {
            this.paramData = paramData;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("AmsepapersignDTO:(");
            buffer.append("agreementId:" + this.agreementId);
            buffer.append(",acptBusinKind:" + this.acptBusinKind);
            buffer.append(",acptBusinId:" + this.acptBusinId);
            buffer.append(",createDate:" + this.createDate);
            buffer.append(",createTime:" + this.createTime);
            buffer.append(",signDate:" + this.signDate);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",templateVersion:" + this.templateVersion);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",fileStorageId:" + this.fileStorageId);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(",entrustWay:" + this.entrustWay);
            buffer.append(",certType:" + this.certType);
            buffer.append(",certSign:" + this.certSign);
            buffer.append(",certOriginal:" + this.certOriginal);
            buffer.append(",renderField:" + this.renderField);
            buffer.append(",caStatus:" + this.caStatus);
            buffer.append(",csfcBeginDate:" + this.csfcBeginDate);
            buffer.append(",csfcEndDate:" + this.csfcEndDate);
            buffer.append(",agreeType:" + this.agreeType);
            buffer.append(",businessCategoryCustom:" + this.businessCategoryCustom);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",remark:" + this.remark);
            buffer.append(",acptId:" + this.acptId);
            buffer.append(",templateId:" + this.templateId);
            buffer.append(",templateName:" + this.templateName);
            buffer.append(",paramData:" + this.paramData);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.agreementId);
            builder.append(this.acptBusinKind);
            builder.append(this.acptBusinId);
            builder.append(this.createDate);
            builder.append(this.createTime);
            builder.append(this.signDate);
            builder.append(this.clientId);
            builder.append(this.templateVersion);
            builder.append(this.fundAccount);
            builder.append(this.fileStorageId);
            builder.append(this.exchangeType);
            builder.append(this.entrustWay);
            builder.append(this.certType);
            builder.append(this.certSign);
            builder.append(this.certOriginal);
            builder.append(this.renderField);
            builder.append(this.caStatus);
            builder.append(this.csfcBeginDate);
            builder.append(this.csfcEndDate);
            builder.append(this.agreeType);
            builder.append(this.businessCategoryCustom);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.remark);
            builder.append(this.acptId);
            builder.append(this.templateId);
            builder.append(this.templateName);
            builder.append(this.paramData);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerCqsService.AmsepapersignDTO) {
                InnerCqsService.AmsepapersignDTO test = (InnerCqsService.AmsepapersignDTO)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.agreementId, test.agreementId);
                builder.append(this.acptBusinKind, test.acptBusinKind);
                builder.append(this.acptBusinId, test.acptBusinId);
                builder.append(this.createDate, test.createDate);
                builder.append(this.createTime, test.createTime);
                builder.append(this.signDate, test.signDate);
                builder.append(this.clientId, test.clientId);
                builder.append(this.templateVersion, test.templateVersion);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.fileStorageId, test.fileStorageId);
                builder.append(this.exchangeType, test.exchangeType);
                builder.append(this.entrustWay, test.entrustWay);
                builder.append(this.certType, test.certType);
                builder.append(this.certSign, test.certSign);
                builder.append(this.certOriginal, test.certOriginal);
                builder.append(this.renderField, test.renderField);
                builder.append(this.caStatus, test.caStatus);
                builder.append(this.csfcBeginDate, test.csfcBeginDate);
                builder.append(this.csfcEndDate, test.csfcEndDate);
                builder.append(this.agreeType, test.agreeType);
                builder.append(this.businessCategoryCustom, test.businessCategoryCustom);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.remark, test.remark);
                builder.append(this.acptId, test.acptId);
                builder.append(this.templateId, test.templateId);
                builder.append(this.templateName, test.templateName);
                builder.append(this.paramData, test.paramData);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class AmsagreesignDTO implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer createDate = 0;
        private Integer createTime = 0;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String agreementId = " ";
        private Integer branchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String clientId = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fundAccount = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String sdcAccount = " ";
        @SinogramLength(
                min = 0,
                max = 16,
                charset = "utf-8"
        )
        private String agreeModelNo = " ";
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String acctExchType = " ";
        @SinogramLength(
                min = 0,
                max = 24,
                charset = "utf-8"
        )
        private String prodtaNo = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String prodCode = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String transAccount = " ";
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String agreeType = " ";
        @SinogramLength(
                min = 0,
                max = 10,
                charset = "utf-8"
        )
        private String agencyNo = " ";
        private Integer signDate = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character caStatus = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character subRiskFlag = ' ';
        private Integer riskLevel = 0;
        private Integer csfcBeginDate = 0;
        private Integer csfcEndDate = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character certType = ' ';
        @SinogramLength(
                min = 0,
                max = 4000,
                charset = "utf-8"
        )
        private String certSign = " ";
        @SinogramLength(
                min = 0,
                max = 128,
                charset = "utf-8"
        )
        private String certOriginal = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fileStorageId = " ";
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String remark = " ";
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String agreementBusinessType = " ";
        @SinogramLength(
                min = 0,
                max = 16000,
                charset = "utf-8"
        )
        private String renderField = " ";
        private Integer templateVersion = 0;
        private Integer agreeDuration = 0;
        @SinogramLength(
                min = 0,
                max = 100,
                charset = "utf-8"
        )
        private String bullTitle = " ";
        @SinogramLength(
                min = 0,
                max = 10,
                charset = "utf-8"
        )
        private String businessCategoryCustom = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String acptId = " ";
        @SinogramLength(
                min = 0,
                max = 16000,
                charset = "utf-8"
        )
        private String paramData = " ";

        public AmsagreesignDTO() {
        }

        public Integer getCreateDate() {
            return this.createDate != null ? this.createDate : 0;
        }

        public Integer getCreateTime() {
            return this.createTime != null ? this.createTime : 0;
        }

        public String getAgreementId() {
            if (this.agreementId == null) {
                return " ";
            } else {
                return this.agreementId.isEmpty() ? " " : this.agreementId;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getSdcAccount() {
            if (this.sdcAccount == null) {
                return " ";
            } else {
                return this.sdcAccount.isEmpty() ? " " : this.sdcAccount;
            }
        }

        public String getAgreeModelNo() {
            if (this.agreeModelNo == null) {
                return " ";
            } else {
                return this.agreeModelNo.isEmpty() ? " " : this.agreeModelNo;
            }
        }

        public String getAcctExchType() {
            if (this.acctExchType == null) {
                return " ";
            } else {
                return this.acctExchType.isEmpty() ? " " : this.acctExchType;
            }
        }

        public String getProdtaNo() {
            if (this.prodtaNo == null) {
                return " ";
            } else {
                return this.prodtaNo.isEmpty() ? " " : this.prodtaNo;
            }
        }

        public String getProdCode() {
            if (this.prodCode == null) {
                return " ";
            } else {
                return this.prodCode.isEmpty() ? " " : this.prodCode;
            }
        }

        public String getTransAccount() {
            if (this.transAccount == null) {
                return " ";
            } else {
                return this.transAccount.isEmpty() ? " " : this.transAccount;
            }
        }

        public String getAgreeType() {
            if (this.agreeType == null) {
                return " ";
            } else {
                return this.agreeType.isEmpty() ? " " : this.agreeType;
            }
        }

        public String getAgencyNo() {
            if (this.agencyNo == null) {
                return " ";
            } else {
                return this.agencyNo.isEmpty() ? " " : this.agencyNo;
            }
        }

        public Integer getSignDate() {
            return this.signDate != null ? this.signDate : 0;
        }

        public Character getCaStatus() {
            return this.caStatus != null ? this.caStatus : ' ';
        }

        public Character getSubRiskFlag() {
            return this.subRiskFlag != null ? this.subRiskFlag : ' ';
        }

        public Integer getRiskLevel() {
            return this.riskLevel != null ? this.riskLevel : 0;
        }

        public Integer getCsfcBeginDate() {
            return this.csfcBeginDate != null ? this.csfcBeginDate : 0;
        }

        public Integer getCsfcEndDate() {
            return this.csfcEndDate != null ? this.csfcEndDate : 0;
        }

        public Character getCertType() {
            return this.certType != null ? this.certType : ' ';
        }

        public String getCertSign() {
            if (this.certSign == null) {
                return " ";
            } else {
                return this.certSign.isEmpty() ? " " : this.certSign;
            }
        }

        public String getCertOriginal() {
            if (this.certOriginal == null) {
                return " ";
            } else {
                return this.certOriginal.isEmpty() ? " " : this.certOriginal;
            }
        }

        public String getFileStorageId() {
            if (this.fileStorageId == null) {
                return " ";
            } else {
                return this.fileStorageId.isEmpty() ? " " : this.fileStorageId;
            }
        }

        public String getRemark() {
            if (this.remark == null) {
                return " ";
            } else {
                return this.remark.isEmpty() ? " " : this.remark;
            }
        }

        public String getAgreementBusinessType() {
            if (this.agreementBusinessType == null) {
                return " ";
            } else {
                return this.agreementBusinessType.isEmpty() ? " " : this.agreementBusinessType;
            }
        }

        public String getRenderField() {
            if (this.renderField == null) {
                return " ";
            } else {
                return this.renderField.isEmpty() ? " " : this.renderField;
            }
        }

        public Integer getTemplateVersion() {
            return this.templateVersion != null ? this.templateVersion : 0;
        }

        public Integer getAgreeDuration() {
            return this.agreeDuration != null ? this.agreeDuration : 0;
        }

        public String getBullTitle() {
            if (this.bullTitle == null) {
                return " ";
            } else {
                return this.bullTitle.isEmpty() ? " " : this.bullTitle;
            }
        }

        public String getBusinessCategoryCustom() {
            if (this.businessCategoryCustom == null) {
                return " ";
            } else {
                return this.businessCategoryCustom.isEmpty() ? " " : this.businessCategoryCustom;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getAcptId() {
            if (this.acptId == null) {
                return " ";
            } else {
                return this.acptId.isEmpty() ? " " : this.acptId;
            }
        }

        public String getParamData() {
            if (this.paramData == null) {
                return " ";
            } else {
                return this.paramData.isEmpty() ? " " : this.paramData;
            }
        }

        public void setCreateDate(Integer createDate) {
            this.createDate = createDate;
        }

        public void setCreateTime(Integer createTime) {
            this.createTime = createTime;
        }

        public void setAgreementId(String agreementId) {
            this.agreementId = agreementId;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setSdcAccount(String sdcAccount) {
            this.sdcAccount = sdcAccount;
        }

        public void setAgreeModelNo(String agreeModelNo) {
            this.agreeModelNo = agreeModelNo;
        }

        public void setAcctExchType(String acctExchType) {
            this.acctExchType = acctExchType;
        }

        public void setProdtaNo(String prodtaNo) {
            this.prodtaNo = prodtaNo;
        }

        public void setProdCode(String prodCode) {
            this.prodCode = prodCode;
        }

        public void setTransAccount(String transAccount) {
            this.transAccount = transAccount;
        }

        public void setAgreeType(String agreeType) {
            this.agreeType = agreeType;
        }

        public void setAgencyNo(String agencyNo) {
            this.agencyNo = agencyNo;
        }

        public void setSignDate(Integer signDate) {
            this.signDate = signDate;
        }

        public void setCaStatus(Character caStatus) {
            this.caStatus = caStatus;
        }

        public void setSubRiskFlag(Character subRiskFlag) {
            this.subRiskFlag = subRiskFlag;
        }

        public void setRiskLevel(Integer riskLevel) {
            this.riskLevel = riskLevel;
        }

        public void setCsfcBeginDate(Integer csfcBeginDate) {
            this.csfcBeginDate = csfcBeginDate;
        }

        public void setCsfcEndDate(Integer csfcEndDate) {
            this.csfcEndDate = csfcEndDate;
        }

        public void setCertType(Character certType) {
            this.certType = certType;
        }

        public void setCertSign(String certSign) {
            this.certSign = certSign;
        }

        public void setCertOriginal(String certOriginal) {
            this.certOriginal = certOriginal;
        }

        public void setFileStorageId(String fileStorageId) {
            this.fileStorageId = fileStorageId;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public void setAgreementBusinessType(String agreementBusinessType) {
            this.agreementBusinessType = agreementBusinessType;
        }

        public void setRenderField(String renderField) {
            this.renderField = renderField;
        }

        public void setTemplateVersion(Integer templateVersion) {
            this.templateVersion = templateVersion;
        }

        public void setAgreeDuration(Integer agreeDuration) {
            this.agreeDuration = agreeDuration;
        }

        public void setBullTitle(String bullTitle) {
            this.bullTitle = bullTitle;
        }

        public void setBusinessCategoryCustom(String businessCategoryCustom) {
            this.businessCategoryCustom = businessCategoryCustom;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setAcptId(String acptId) {
            this.acptId = acptId;
        }

        public void setParamData(String paramData) {
            this.paramData = paramData;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("AmsagreesignDTO:(");
            buffer.append("createDate:" + this.createDate);
            buffer.append(",createTime:" + this.createTime);
            buffer.append(",agreementId:" + this.agreementId);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",sdcAccount:" + this.sdcAccount);
            buffer.append(",agreeModelNo:" + this.agreeModelNo);
            buffer.append(",acctExchType:" + this.acctExchType);
            buffer.append(",prodtaNo:" + this.prodtaNo);
            buffer.append(",prodCode:" + this.prodCode);
            buffer.append(",transAccount:" + this.transAccount);
            buffer.append(",agreeType:" + this.agreeType);
            buffer.append(",agencyNo:" + this.agencyNo);
            buffer.append(",signDate:" + this.signDate);
            buffer.append(",caStatus:" + this.caStatus);
            buffer.append(",subRiskFlag:" + this.subRiskFlag);
            buffer.append(",riskLevel:" + this.riskLevel);
            buffer.append(",csfcBeginDate:" + this.csfcBeginDate);
            buffer.append(",csfcEndDate:" + this.csfcEndDate);
            buffer.append(",certType:" + this.certType);
            buffer.append(",certSign:" + this.certSign);
            buffer.append(",certOriginal:" + this.certOriginal);
            buffer.append(",fileStorageId:" + this.fileStorageId);
            buffer.append(",remark:" + this.remark);
            buffer.append(",agreementBusinessType:" + this.agreementBusinessType);
            buffer.append(",renderField:" + this.renderField);
            buffer.append(",templateVersion:" + this.templateVersion);
            buffer.append(",agreeDuration:" + this.agreeDuration);
            buffer.append(",bullTitle:" + this.bullTitle);
            buffer.append(",businessCategoryCustom:" + this.businessCategoryCustom);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",acptId:" + this.acptId);
            buffer.append(",paramData:" + this.paramData);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.createDate);
            builder.append(this.createTime);
            builder.append(this.agreementId);
            builder.append(this.branchNo);
            builder.append(this.clientId);
            builder.append(this.fundAccount);
            builder.append(this.sdcAccount);
            builder.append(this.agreeModelNo);
            builder.append(this.acctExchType);
            builder.append(this.prodtaNo);
            builder.append(this.prodCode);
            builder.append(this.transAccount);
            builder.append(this.agreeType);
            builder.append(this.agencyNo);
            builder.append(this.signDate);
            builder.append(this.caStatus);
            builder.append(this.subRiskFlag);
            builder.append(this.riskLevel);
            builder.append(this.csfcBeginDate);
            builder.append(this.csfcEndDate);
            builder.append(this.certType);
            builder.append(this.certSign);
            builder.append(this.certOriginal);
            builder.append(this.fileStorageId);
            builder.append(this.remark);
            builder.append(this.agreementBusinessType);
            builder.append(this.renderField);
            builder.append(this.templateVersion);
            builder.append(this.agreeDuration);
            builder.append(this.bullTitle);
            builder.append(this.businessCategoryCustom);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.acptId);
            builder.append(this.paramData);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerCqsService.AmsagreesignDTO) {
                InnerCqsService.AmsagreesignDTO test = (InnerCqsService.AmsagreesignDTO)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.createDate, test.createDate);
                builder.append(this.createTime, test.createTime);
                builder.append(this.agreementId, test.agreementId);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.clientId, test.clientId);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.sdcAccount, test.sdcAccount);
                builder.append(this.agreeModelNo, test.agreeModelNo);
                builder.append(this.acctExchType, test.acctExchType);
                builder.append(this.prodtaNo, test.prodtaNo);
                builder.append(this.prodCode, test.prodCode);
                builder.append(this.transAccount, test.transAccount);
                builder.append(this.agreeType, test.agreeType);
                builder.append(this.agencyNo, test.agencyNo);
                builder.append(this.signDate, test.signDate);
                builder.append(this.caStatus, test.caStatus);
                builder.append(this.subRiskFlag, test.subRiskFlag);
                builder.append(this.riskLevel, test.riskLevel);
                builder.append(this.csfcBeginDate, test.csfcBeginDate);
                builder.append(this.csfcEndDate, test.csfcEndDate);
                builder.append(this.certType, test.certType);
                builder.append(this.certSign, test.certSign);
                builder.append(this.certOriginal, test.certOriginal);
                builder.append(this.fileStorageId, test.fileStorageId);
                builder.append(this.remark, test.remark);
                builder.append(this.agreementBusinessType, test.agreementBusinessType);
                builder.append(this.renderField, test.renderField);
                builder.append(this.templateVersion, test.templateVersion);
                builder.append(this.agreeDuration, test.agreeDuration);
                builder.append(this.bullTitle, test.bullTitle);
                builder.append(this.businessCategoryCustom, test.businessCategoryCustom);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.acptId, test.acptId);
                builder.append(this.paramData, test.paramData);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutHsfunctionCacheInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @NotNull(
                message = "不能为空"
        )
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 64,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';

        public PutHsfunctionCacheInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutHsfunctionCacheInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerCqsService.PutHsfunctionCacheInnerInput) {
                InnerCqsService.PutHsfunctionCacheInnerInput test = (InnerCqsService.PutHsfunctionCacheInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutArgInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer nextInitDate = 0;

        public PutArgInnerOutput() {
        }

        public Integer getNextInitDate() {
            return this.nextInitDate != null ? this.nextInitDate : 0;
        }

        public void setNextInitDate(Integer nextInitDate) {
            this.nextInitDate = nextInitDate;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutArgInnerOutput:(");
            buffer.append("nextInitDate:" + this.nextInitDate);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.nextInitDate);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerCqsService.PutArgInnerOutput) {
                InnerCqsService.PutArgInnerOutput test = (InnerCqsService.PutArgInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.nextInitDate, test.nextInitDate);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutArgInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @NotNull(
                message = "不能为空"
        )
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 64,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @NotNull(
                message = "不能为空"
        )
        private Integer initDate = 0;

        public PutArgInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutArgInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",initDate:" + this.initDate);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.initDate);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerCqsService.PutArgInnerInput) {
                InnerCqsService.PutArgInnerInput test = (InnerCqsService.PutArgInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.initDate, test.initDate);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostCqsstatementInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private InnerCqsService.ResultInfoDTO resultinfo;

        public PostCqsstatementInnerOutput() {
        }

        public InnerCqsService.ResultInfoDTO getResultinfo() {
            return this.resultinfo;
        }

        public void setResultinfo(InnerCqsService.ResultInfoDTO resultinfo) {
            this.resultinfo = resultinfo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostCqsstatementInnerOutput:(");
            buffer.append("resultinfo:" + this.resultinfo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.resultinfo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerCqsService.PostCqsstatementInnerOutput) {
                InnerCqsService.PostCqsstatementInnerOutput test = (InnerCqsService.PostCqsstatementInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.resultinfo, test.resultinfo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostCqsstatementInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @NotNull(
                message = "不能为空"
        )
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 64,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 60,
                charset = "utf-8"
        )
        private String operatorName = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String clientId = " ";
        private List<String> singleClientQryCondition;

        public PostCqsstatementInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getOperatorName() {
            if (this.operatorName == null) {
                return " ";
            } else {
                return this.operatorName.isEmpty() ? " " : this.operatorName;
            }
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public List<String> getSingleClientQryCondition() {
            return this.singleClientQryCondition;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOperatorName(String operatorName) {
            this.operatorName = operatorName;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setSingleClientQryCondition(List<String> singleClientQryCondition) {
            this.singleClientQryCondition = singleClientQryCondition;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostCqsstatementInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",operatorName:" + this.operatorName);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",singleClientQryCondition:" + this.singleClientQryCondition);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.operatorName);
            builder.append(this.clientId);
            builder.append(this.singleClientQryCondition);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerCqsService.PostCqsstatementInnerInput) {
                InnerCqsService.PostCqsstatementInnerInput test = (InnerCqsService.PostCqsstatementInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.operatorName, test.operatorName);
                builder.append(this.clientId, test.clientId);
                builder.append(this.singleClientQryCondition, test.singleClientQryCondition);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostCqsdeliververifyInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String filePath = " ";
        private String fileName = " ";

        public PostCqsdeliververifyInnerOutput() {
        }

        public String getFilePath() {
            if (this.filePath == null) {
                return " ";
            } else {
                return this.filePath.isEmpty() ? " " : this.filePath;
            }
        }

        public String getFileName() {
            if (this.fileName == null) {
                return " ";
            } else {
                return this.fileName.isEmpty() ? " " : this.fileName;
            }
        }

        public void setFilePath(String filePath) {
            this.filePath = filePath;
        }

        public void setFileName(String fileName) {
            this.fileName = fileName;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostCqsdeliververifyInnerOutput:(");
            buffer.append("filePath:" + this.filePath);
            buffer.append(",fileName:" + this.fileName);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.filePath);
            builder.append(this.fileName);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerCqsService.PostCqsdeliververifyInnerOutput) {
                InnerCqsService.PostCqsdeliververifyInnerOutput test = (InnerCqsService.PostCqsdeliververifyInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.filePath, test.filePath);
                builder.append(this.fileName, test.fileName);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostCqsdeliververifyInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @NotNull(
                message = "不能为空"
        )
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 64,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String cqsId = " ";
        @SinogramLength(
                min = 0,
                max = 8000,
                charset = "utf-8"
        )
        private String singleClientQryCondition = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character expfileType = '0';
        @SinogramLength(
                min = 0,
                max = 60,
                charset = "utf-8"
        )
        private String operatorName = " ";

        public PostCqsdeliververifyInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getCqsId() {
            if (this.cqsId == null) {
                return " ";
            } else {
                return this.cqsId.isEmpty() ? " " : this.cqsId;
            }
        }

        public String getSingleClientQryCondition() {
            if (this.singleClientQryCondition == null) {
                return " ";
            } else {
                return this.singleClientQryCondition.isEmpty() ? " " : this.singleClientQryCondition;
            }
        }

        public Character getExpfileType() {
            return this.expfileType != null ? this.expfileType : '\u0000';
        }

        public String getOperatorName() {
            if (this.operatorName == null) {
                return " ";
            } else {
                return this.operatorName.isEmpty() ? " " : this.operatorName;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setCqsId(String cqsId) {
            this.cqsId = cqsId;
        }

        public void setSingleClientQryCondition(String singleClientQryCondition) {
            this.singleClientQryCondition = singleClientQryCondition;
        }

        public void setExpfileType(Character expfileType) {
            this.expfileType = expfileType;
        }

        public void setOperatorName(String operatorName) {
            this.operatorName = operatorName;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostCqsdeliververifyInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",cqsId:" + this.cqsId);
            buffer.append(",singleClientQryCondition:" + this.singleClientQryCondition);
            buffer.append(",expfileType:" + this.expfileType);
            buffer.append(",operatorName:" + this.operatorName);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.cqsId);
            builder.append(this.singleClientQryCondition);
            builder.append(this.expfileType);
            builder.append(this.operatorName);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerCqsService.PostCqsdeliververifyInnerInput) {
                InnerCqsService.PostCqsdeliververifyInnerInput test = (InnerCqsService.PostCqsdeliververifyInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.cqsId, test.cqsId);
                builder.append(this.singleClientQryCondition, test.singleClientQryCondition);
                builder.append(this.expfileType, test.expfileType);
                builder.append(this.operatorName, test.operatorName);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetSesstkcodeInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String exchangeType = " ";
        private String stockCode = " ";
        private Integer updateDate = 0;
        private Integer updateTime = 0;
        private String stockType = " ";
        private String subStockType = " ";
        private String frozenCode = " ";
        private String moneyType = " ";
        private String stockName = " ";
        private String spellCode = " ";
        private String relativeCode = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character stkcodeStatus = ' ';
        private Integer bondTerm = 0;
        @SerializeDoubleDigit(
                digit = 4
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double defaultPrice = 0.0D;
        @SerializeDoubleDigit(
                digit = 4
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double basePrice = 0.0D;
        @SerializeDoubleDigit(
                digit = 8
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double lastPrice = 0.0D;
        @SerializeDoubleDigit(
                digit = 8
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double closePrice = 0.0D;
        @SerializeDoubleDigit(
                digit = 8
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double netValue = 0.0D;
        @SerializeDoubleDigit(
                digit = 8
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double upPrice = 0.0D;
        @SerializeDoubleDigit(
                digit = 8
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double downPrice = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double highAmount = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double lowAmount = 0.0D;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character trustee = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character overdraw = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character assetFlag = ' ';
        private Integer amountPerHand = 0;
        private Integer storeUnit = 0;
        private Integer reportUnit = 0;
        private Integer buyUnit = 0;
        private Integer sellUnit = 0;
        private Integer priceStep = 0;
        private Integer priceGrade = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character reportDirection = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character fundDirection = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character stockDirection = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character fundFrozen = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character fundRealBack = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character stockRealBack = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character tnType = ' ';
        private Integer fundBackN = 0;
        private Integer stockBackN = 0;
        @SerializeDoubleDigit(
                digit = 8
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double parValue = 0.0D;
        private Integer marketDate = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character defaultpriceType = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character limitpriceType = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character basepriceType = ' ';
        private Integer limitValueUp = 0;
        private Integer limitValueLow = 0;
        private String buyClient = " ";
        private String sellClient = " ";
        private String buyHolder = " ";
        private String sellHolder = " ";
        private String enEntrustWay = " ";
        private Integer eligRiskLevel = 0;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double lowBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double highBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double cancelLowBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double cancelHighBalance = 0.0D;
        private Integer issueDate = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character bondinvFlag = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character delistFlag = ' ';
        private Integer delistDate = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character stbtransType = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character stbtransStatus = ' ';
        private String stkcodeCtrlstr = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character exdividendFlag = ' ';
        private Integer marketmakerAmount = 0;
        @SerializeDoubleDigit(
                digit = 8
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double transPrice = 0.0D;
        private String positionStr = " ";
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double marketHighAmount = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double marketLowAmount = 0.0D;

        public GetSesstkcodeInnerOutput() {
        }

        public String getExchangeType() {
            if (this.exchangeType == null) {
                return " ";
            } else {
                return this.exchangeType.isEmpty() ? " " : this.exchangeType;
            }
        }

        public String getStockCode() {
            if (this.stockCode == null) {
                return " ";
            } else {
                return this.stockCode.isEmpty() ? " " : this.stockCode;
            }
        }

        public Integer getUpdateDate() {
            return this.updateDate != null ? this.updateDate : 0;
        }

        public Integer getUpdateTime() {
            return this.updateTime != null ? this.updateTime : 0;
        }

        public String getStockType() {
            if (this.stockType == null) {
                return " ";
            } else {
                return this.stockType.isEmpty() ? " " : this.stockType;
            }
        }

        public String getSubStockType() {
            if (this.subStockType == null) {
                return " ";
            } else {
                return this.subStockType.isEmpty() ? " " : this.subStockType;
            }
        }

        public String getFrozenCode() {
            if (this.frozenCode == null) {
                return " ";
            } else {
                return this.frozenCode.isEmpty() ? " " : this.frozenCode;
            }
        }

        public String getMoneyType() {
            if (this.moneyType == null) {
                return " ";
            } else {
                return this.moneyType.isEmpty() ? " " : this.moneyType;
            }
        }

        public String getStockName() {
            if (this.stockName == null) {
                return " ";
            } else {
                return this.stockName.isEmpty() ? " " : this.stockName;
            }
        }

        public String getSpellCode() {
            if (this.spellCode == null) {
                return " ";
            } else {
                return this.spellCode.isEmpty() ? " " : this.spellCode;
            }
        }

        public String getRelativeCode() {
            if (this.relativeCode == null) {
                return " ";
            } else {
                return this.relativeCode.isEmpty() ? " " : this.relativeCode;
            }
        }

        public Character getStkcodeStatus() {
            return this.stkcodeStatus != null ? this.stkcodeStatus : ' ';
        }

        public Integer getBondTerm() {
            return this.bondTerm != null ? this.bondTerm : 0;
        }

        public Double getDefaultPrice() {
            return this.defaultPrice != null ? this.defaultPrice : 0.0D;
        }

        public Double getBasePrice() {
            return this.basePrice != null ? this.basePrice : 0.0D;
        }

        public Double getLastPrice() {
            return this.lastPrice != null ? this.lastPrice : 0.0D;
        }

        public Double getClosePrice() {
            return this.closePrice != null ? this.closePrice : 0.0D;
        }

        public Double getNetValue() {
            return this.netValue != null ? this.netValue : 0.0D;
        }

        public Double getUpPrice() {
            return this.upPrice != null ? this.upPrice : 0.0D;
        }

        public Double getDownPrice() {
            return this.downPrice != null ? this.downPrice : 0.0D;
        }

        public Double getHighAmount() {
            return this.highAmount != null ? this.highAmount : 0.0D;
        }

        public Double getLowAmount() {
            return this.lowAmount != null ? this.lowAmount : 0.0D;
        }

        public Character getTrustee() {
            return this.trustee != null ? this.trustee : ' ';
        }

        public Character getOverdraw() {
            return this.overdraw != null ? this.overdraw : ' ';
        }

        public Character getAssetFlag() {
            return this.assetFlag != null ? this.assetFlag : ' ';
        }

        public Integer getAmountPerHand() {
            return this.amountPerHand != null ? this.amountPerHand : 0;
        }

        public Integer getStoreUnit() {
            return this.storeUnit != null ? this.storeUnit : 0;
        }

        public Integer getReportUnit() {
            return this.reportUnit != null ? this.reportUnit : 0;
        }

        public Integer getBuyUnit() {
            return this.buyUnit != null ? this.buyUnit : 0;
        }

        public Integer getSellUnit() {
            return this.sellUnit != null ? this.sellUnit : 0;
        }

        public Integer getPriceStep() {
            return this.priceStep != null ? this.priceStep : 0;
        }

        public Integer getPriceGrade() {
            return this.priceGrade != null ? this.priceGrade : 0;
        }

        public Character getReportDirection() {
            return this.reportDirection != null ? this.reportDirection : ' ';
        }

        public Character getFundDirection() {
            return this.fundDirection != null ? this.fundDirection : ' ';
        }

        public Character getStockDirection() {
            return this.stockDirection != null ? this.stockDirection : ' ';
        }

        public Character getFundFrozen() {
            return this.fundFrozen != null ? this.fundFrozen : ' ';
        }

        public Character getFundRealBack() {
            return this.fundRealBack != null ? this.fundRealBack : ' ';
        }

        public Character getStockRealBack() {
            return this.stockRealBack != null ? this.stockRealBack : ' ';
        }

        public Character getTnType() {
            return this.tnType != null ? this.tnType : ' ';
        }

        public Integer getFundBackN() {
            return this.fundBackN != null ? this.fundBackN : 0;
        }

        public Integer getStockBackN() {
            return this.stockBackN != null ? this.stockBackN : 0;
        }

        public Double getParValue() {
            return this.parValue != null ? this.parValue : 0.0D;
        }

        public Integer getMarketDate() {
            return this.marketDate != null ? this.marketDate : 0;
        }

        public Character getDefaultpriceType() {
            return this.defaultpriceType != null ? this.defaultpriceType : ' ';
        }

        public Character getLimitpriceType() {
            return this.limitpriceType != null ? this.limitpriceType : ' ';
        }

        public Character getBasepriceType() {
            return this.basepriceType != null ? this.basepriceType : ' ';
        }

        public Integer getLimitValueUp() {
            return this.limitValueUp != null ? this.limitValueUp : 0;
        }

        public Integer getLimitValueLow() {
            return this.limitValueLow != null ? this.limitValueLow : 0;
        }

        public String getBuyClient() {
            if (this.buyClient == null) {
                return " ";
            } else {
                return this.buyClient.isEmpty() ? " " : this.buyClient;
            }
        }

        public String getSellClient() {
            if (this.sellClient == null) {
                return " ";
            } else {
                return this.sellClient.isEmpty() ? " " : this.sellClient;
            }
        }

        public String getBuyHolder() {
            if (this.buyHolder == null) {
                return " ";
            } else {
                return this.buyHolder.isEmpty() ? " " : this.buyHolder;
            }
        }

        public String getSellHolder() {
            if (this.sellHolder == null) {
                return " ";
            } else {
                return this.sellHolder.isEmpty() ? " " : this.sellHolder;
            }
        }

        public String getEnEntrustWay() {
            if (this.enEntrustWay == null) {
                return " ";
            } else {
                return this.enEntrustWay.isEmpty() ? " " : this.enEntrustWay;
            }
        }

        public Integer getEligRiskLevel() {
            return this.eligRiskLevel != null ? this.eligRiskLevel : 0;
        }

        public Double getLowBalance() {
            return this.lowBalance != null ? this.lowBalance : 0.0D;
        }

        public Double getHighBalance() {
            return this.highBalance != null ? this.highBalance : 0.0D;
        }

        public Double getCancelLowBalance() {
            return this.cancelLowBalance != null ? this.cancelLowBalance : 0.0D;
        }

        public Double getCancelHighBalance() {
            return this.cancelHighBalance != null ? this.cancelHighBalance : 0.0D;
        }

        public Integer getIssueDate() {
            return this.issueDate != null ? this.issueDate : 0;
        }

        public Character getBondinvFlag() {
            return this.bondinvFlag != null ? this.bondinvFlag : ' ';
        }

        public Character getDelistFlag() {
            return this.delistFlag != null ? this.delistFlag : ' ';
        }

        public Integer getDelistDate() {
            return this.delistDate != null ? this.delistDate : 0;
        }

        public Character getStbtransType() {
            return this.stbtransType != null ? this.stbtransType : ' ';
        }

        public Character getStbtransStatus() {
            return this.stbtransStatus != null ? this.stbtransStatus : ' ';
        }

        public String getStkcodeCtrlstr() {
            if (this.stkcodeCtrlstr == null) {
                return " ";
            } else {
                return this.stkcodeCtrlstr.isEmpty() ? " " : this.stkcodeCtrlstr;
            }
        }

        public Character getExdividendFlag() {
            return this.exdividendFlag != null ? this.exdividendFlag : ' ';
        }

        public Integer getMarketmakerAmount() {
            return this.marketmakerAmount != null ? this.marketmakerAmount : 0;
        }

        public Double getTransPrice() {
            return this.transPrice != null ? this.transPrice : 0.0D;
        }

        public String getPositionStr() {
            if (this.positionStr == null) {
                return " ";
            } else {
                return this.positionStr.isEmpty() ? " " : this.positionStr;
            }
        }

        public Double getMarketHighAmount() {
            return this.marketHighAmount != null ? this.marketHighAmount : 0.0D;
        }

        public Double getMarketLowAmount() {
            return this.marketLowAmount != null ? this.marketLowAmount : 0.0D;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public void setStockCode(String stockCode) {
            this.stockCode = stockCode;
        }

        public void setUpdateDate(Integer updateDate) {
            this.updateDate = updateDate;
        }

        public void setUpdateTime(Integer updateTime) {
            this.updateTime = updateTime;
        }

        public void setStockType(String stockType) {
            this.stockType = stockType;
        }

        public void setSubStockType(String subStockType) {
            this.subStockType = subStockType;
        }

        public void setFrozenCode(String frozenCode) {
            this.frozenCode = frozenCode;
        }

        public void setMoneyType(String moneyType) {
            this.moneyType = moneyType;
        }

        public void setStockName(String stockName) {
            this.stockName = stockName;
        }

        public void setSpellCode(String spellCode) {
            this.spellCode = spellCode;
        }

        public void setRelativeCode(String relativeCode) {
            this.relativeCode = relativeCode;
        }

        public void setStkcodeStatus(Character stkcodeStatus) {
            this.stkcodeStatus = stkcodeStatus;
        }

        public void setBondTerm(Integer bondTerm) {
            this.bondTerm = bondTerm;
        }

        public void setDefaultPrice(Double defaultPrice) {
            this.defaultPrice = defaultPrice;
        }

        public void setBasePrice(Double basePrice) {
            this.basePrice = basePrice;
        }

        public void setLastPrice(Double lastPrice) {
            this.lastPrice = lastPrice;
        }

        public void setClosePrice(Double closePrice) {
            this.closePrice = closePrice;
        }

        public void setNetValue(Double netValue) {
            this.netValue = netValue;
        }

        public void setUpPrice(Double upPrice) {
            this.upPrice = upPrice;
        }

        public void setDownPrice(Double downPrice) {
            this.downPrice = downPrice;
        }

        public void setHighAmount(Double highAmount) {
            this.highAmount = highAmount;
        }

        public void setLowAmount(Double lowAmount) {
            this.lowAmount = lowAmount;
        }

        public void setTrustee(Character trustee) {
            this.trustee = trustee;
        }

        public void setOverdraw(Character overdraw) {
            this.overdraw = overdraw;
        }

        public void setAssetFlag(Character assetFlag) {
            this.assetFlag = assetFlag;
        }

        public void setAmountPerHand(Integer amountPerHand) {
            this.amountPerHand = amountPerHand;
        }

        public void setStoreUnit(Integer storeUnit) {
            this.storeUnit = storeUnit;
        }

        public void setReportUnit(Integer reportUnit) {
            this.reportUnit = reportUnit;
        }

        public void setBuyUnit(Integer buyUnit) {
            this.buyUnit = buyUnit;
        }

        public void setSellUnit(Integer sellUnit) {
            this.sellUnit = sellUnit;
        }

        public void setPriceStep(Integer priceStep) {
            this.priceStep = priceStep;
        }

        public void setPriceGrade(Integer priceGrade) {
            this.priceGrade = priceGrade;
        }

        public void setReportDirection(Character reportDirection) {
            this.reportDirection = reportDirection;
        }

        public void setFundDirection(Character fundDirection) {
            this.fundDirection = fundDirection;
        }

        public void setStockDirection(Character stockDirection) {
            this.stockDirection = stockDirection;
        }

        public void setFundFrozen(Character fundFrozen) {
            this.fundFrozen = fundFrozen;
        }

        public void setFundRealBack(Character fundRealBack) {
            this.fundRealBack = fundRealBack;
        }

        public void setStockRealBack(Character stockRealBack) {
            this.stockRealBack = stockRealBack;
        }

        public void setTnType(Character tnType) {
            this.tnType = tnType;
        }

        public void setFundBackN(Integer fundBackN) {
            this.fundBackN = fundBackN;
        }

        public void setStockBackN(Integer stockBackN) {
            this.stockBackN = stockBackN;
        }

        public void setParValue(Double parValue) {
            this.parValue = parValue;
        }

        public void setMarketDate(Integer marketDate) {
            this.marketDate = marketDate;
        }

        public void setDefaultpriceType(Character defaultpriceType) {
            this.defaultpriceType = defaultpriceType;
        }

        public void setLimitpriceType(Character limitpriceType) {
            this.limitpriceType = limitpriceType;
        }

        public void setBasepriceType(Character basepriceType) {
            this.basepriceType = basepriceType;
        }

        public void setLimitValueUp(Integer limitValueUp) {
            this.limitValueUp = limitValueUp;
        }

        public void setLimitValueLow(Integer limitValueLow) {
            this.limitValueLow = limitValueLow;
        }

        public void setBuyClient(String buyClient) {
            this.buyClient = buyClient;
        }

        public void setSellClient(String sellClient) {
            this.sellClient = sellClient;
        }

        public void setBuyHolder(String buyHolder) {
            this.buyHolder = buyHolder;
        }

        public void setSellHolder(String sellHolder) {
            this.sellHolder = sellHolder;
        }

        public void setEnEntrustWay(String enEntrustWay) {
            this.enEntrustWay = enEntrustWay;
        }

        public void setEligRiskLevel(Integer eligRiskLevel) {
            this.eligRiskLevel = eligRiskLevel;
        }

        public void setLowBalance(Double lowBalance) {
            this.lowBalance = lowBalance;
        }

        public void setHighBalance(Double highBalance) {
            this.highBalance = highBalance;
        }

        public void setCancelLowBalance(Double cancelLowBalance) {
            this.cancelLowBalance = cancelLowBalance;
        }

        public void setCancelHighBalance(Double cancelHighBalance) {
            this.cancelHighBalance = cancelHighBalance;
        }

        public void setIssueDate(Integer issueDate) {
            this.issueDate = issueDate;
        }

        public void setBondinvFlag(Character bondinvFlag) {
            this.bondinvFlag = bondinvFlag;
        }

        public void setDelistFlag(Character delistFlag) {
            this.delistFlag = delistFlag;
        }

        public void setDelistDate(Integer delistDate) {
            this.delistDate = delistDate;
        }

        public void setStbtransType(Character stbtransType) {
            this.stbtransType = stbtransType;
        }

        public void setStbtransStatus(Character stbtransStatus) {
            this.stbtransStatus = stbtransStatus;
        }

        public void setStkcodeCtrlstr(String stkcodeCtrlstr) {
            this.stkcodeCtrlstr = stkcodeCtrlstr;
        }

        public void setExdividendFlag(Character exdividendFlag) {
            this.exdividendFlag = exdividendFlag;
        }

        public void setMarketmakerAmount(Integer marketmakerAmount) {
            this.marketmakerAmount = marketmakerAmount;
        }

        public void setTransPrice(Double transPrice) {
            this.transPrice = transPrice;
        }

        public void setPositionStr(String positionStr) {
            this.positionStr = positionStr;
        }

        public void setMarketHighAmount(Double marketHighAmount) {
            this.marketHighAmount = marketHighAmount;
        }

        public void setMarketLowAmount(Double marketLowAmount) {
            this.marketLowAmount = marketLowAmount;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetSesstkcodeInnerOutput:(");
            buffer.append("exchangeType:" + this.exchangeType);
            buffer.append(",stockCode:" + this.stockCode);
            buffer.append(",updateDate:" + this.updateDate);
            buffer.append(",updateTime:" + this.updateTime);
            buffer.append(",stockType:" + this.stockType);
            buffer.append(",subStockType:" + this.subStockType);
            buffer.append(",frozenCode:" + this.frozenCode);
            buffer.append(",moneyType:" + this.moneyType);
            buffer.append(",stockName:" + this.stockName);
            buffer.append(",spellCode:" + this.spellCode);
            buffer.append(",relativeCode:" + this.relativeCode);
            buffer.append(",stkcodeStatus:" + this.stkcodeStatus);
            buffer.append(",bondTerm:" + this.bondTerm);
            buffer.append(",defaultPrice:" + this.defaultPrice);
            buffer.append(",basePrice:" + this.basePrice);
            buffer.append(",lastPrice:" + this.lastPrice);
            buffer.append(",closePrice:" + this.closePrice);
            buffer.append(",netValue:" + this.netValue);
            buffer.append(",upPrice:" + this.upPrice);
            buffer.append(",downPrice:" + this.downPrice);
            buffer.append(",highAmount:" + this.highAmount);
            buffer.append(",lowAmount:" + this.lowAmount);
            buffer.append(",trustee:" + this.trustee);
            buffer.append(",overdraw:" + this.overdraw);
            buffer.append(",assetFlag:" + this.assetFlag);
            buffer.append(",amountPerHand:" + this.amountPerHand);
            buffer.append(",storeUnit:" + this.storeUnit);
            buffer.append(",reportUnit:" + this.reportUnit);
            buffer.append(",buyUnit:" + this.buyUnit);
            buffer.append(",sellUnit:" + this.sellUnit);
            buffer.append(",priceStep:" + this.priceStep);
            buffer.append(",priceGrade:" + this.priceGrade);
            buffer.append(",reportDirection:" + this.reportDirection);
            buffer.append(",fundDirection:" + this.fundDirection);
            buffer.append(",stockDirection:" + this.stockDirection);
            buffer.append(",fundFrozen:" + this.fundFrozen);
            buffer.append(",fundRealBack:" + this.fundRealBack);
            buffer.append(",stockRealBack:" + this.stockRealBack);
            buffer.append(",tnType:" + this.tnType);
            buffer.append(",fundBackN:" + this.fundBackN);
            buffer.append(",stockBackN:" + this.stockBackN);
            buffer.append(",parValue:" + this.parValue);
            buffer.append(",marketDate:" + this.marketDate);
            buffer.append(",defaultpriceType:" + this.defaultpriceType);
            buffer.append(",limitpriceType:" + this.limitpriceType);
            buffer.append(",basepriceType:" + this.basepriceType);
            buffer.append(",limitValueUp:" + this.limitValueUp);
            buffer.append(",limitValueLow:" + this.limitValueLow);
            buffer.append(",buyClient:" + this.buyClient);
            buffer.append(",sellClient:" + this.sellClient);
            buffer.append(",buyHolder:" + this.buyHolder);
            buffer.append(",sellHolder:" + this.sellHolder);
            buffer.append(",enEntrustWay:" + this.enEntrustWay);
            buffer.append(",eligRiskLevel:" + this.eligRiskLevel);
            buffer.append(",lowBalance:" + this.lowBalance);
            buffer.append(",highBalance:" + this.highBalance);
            buffer.append(",cancelLowBalance:" + this.cancelLowBalance);
            buffer.append(",cancelHighBalance:" + this.cancelHighBalance);
            buffer.append(",issueDate:" + this.issueDate);
            buffer.append(",bondinvFlag:" + this.bondinvFlag);
            buffer.append(",delistFlag:" + this.delistFlag);
            buffer.append(",delistDate:" + this.delistDate);
            buffer.append(",stbtransType:" + this.stbtransType);
            buffer.append(",stbtransStatus:" + this.stbtransStatus);
            buffer.append(",stkcodeCtrlstr:" + this.stkcodeCtrlstr);
            buffer.append(",exdividendFlag:" + this.exdividendFlag);
            buffer.append(",marketmakerAmount:" + this.marketmakerAmount);
            buffer.append(",transPrice:" + this.transPrice);
            buffer.append(",positionStr:" + this.positionStr);
            buffer.append(",marketHighAmount:" + this.marketHighAmount);
            buffer.append(",marketLowAmount:" + this.marketLowAmount);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.exchangeType);
            builder.append(this.stockCode);
            builder.append(this.updateDate);
            builder.append(this.updateTime);
            builder.append(this.stockType);
            builder.append(this.subStockType);
            builder.append(this.frozenCode);
            builder.append(this.moneyType);
            builder.append(this.stockName);
            builder.append(this.spellCode);
            builder.append(this.relativeCode);
            builder.append(this.stkcodeStatus);
            builder.append(this.bondTerm);
            builder.append(this.defaultPrice);
            builder.append(this.basePrice);
            builder.append(this.lastPrice);
            builder.append(this.closePrice);
            builder.append(this.netValue);
            builder.append(this.upPrice);
            builder.append(this.downPrice);
            builder.append(this.highAmount);
            builder.append(this.lowAmount);
            builder.append(this.trustee);
            builder.append(this.overdraw);
            builder.append(this.assetFlag);
            builder.append(this.amountPerHand);
            builder.append(this.storeUnit);
            builder.append(this.reportUnit);
            builder.append(this.buyUnit);
            builder.append(this.sellUnit);
            builder.append(this.priceStep);
            builder.append(this.priceGrade);
            builder.append(this.reportDirection);
            builder.append(this.fundDirection);
            builder.append(this.stockDirection);
            builder.append(this.fundFrozen);
            builder.append(this.fundRealBack);
            builder.append(this.stockRealBack);
            builder.append(this.tnType);
            builder.append(this.fundBackN);
            builder.append(this.stockBackN);
            builder.append(this.parValue);
            builder.append(this.marketDate);
            builder.append(this.defaultpriceType);
            builder.append(this.limitpriceType);
            builder.append(this.basepriceType);
            builder.append(this.limitValueUp);
            builder.append(this.limitValueLow);
            builder.append(this.buyClient);
            builder.append(this.sellClient);
            builder.append(this.buyHolder);
            builder.append(this.sellHolder);
            builder.append(this.enEntrustWay);
            builder.append(this.eligRiskLevel);
            builder.append(this.lowBalance);
            builder.append(this.highBalance);
            builder.append(this.cancelLowBalance);
            builder.append(this.cancelHighBalance);
            builder.append(this.issueDate);
            builder.append(this.bondinvFlag);
            builder.append(this.delistFlag);
            builder.append(this.delistDate);
            builder.append(this.stbtransType);
            builder.append(this.stbtransStatus);
            builder.append(this.stkcodeCtrlstr);
            builder.append(this.exdividendFlag);
            builder.append(this.marketmakerAmount);
            builder.append(this.transPrice);
            builder.append(this.positionStr);
            builder.append(this.marketHighAmount);
            builder.append(this.marketLowAmount);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerCqsService.GetSesstkcodeInnerOutput) {
                InnerCqsService.GetSesstkcodeInnerOutput test = (InnerCqsService.GetSesstkcodeInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.exchangeType, test.exchangeType);
                builder.append(this.stockCode, test.stockCode);
                builder.append(this.updateDate, test.updateDate);
                builder.append(this.updateTime, test.updateTime);
                builder.append(this.stockType, test.stockType);
                builder.append(this.subStockType, test.subStockType);
                builder.append(this.frozenCode, test.frozenCode);
                builder.append(this.moneyType, test.moneyType);
                builder.append(this.stockName, test.stockName);
                builder.append(this.spellCode, test.spellCode);
                builder.append(this.relativeCode, test.relativeCode);
                builder.append(this.stkcodeStatus, test.stkcodeStatus);
                builder.append(this.bondTerm, test.bondTerm);
                builder.append(this.defaultPrice, test.defaultPrice);
                builder.append(this.basePrice, test.basePrice);
                builder.append(this.lastPrice, test.lastPrice);
                builder.append(this.closePrice, test.closePrice);
                builder.append(this.netValue, test.netValue);
                builder.append(this.upPrice, test.upPrice);
                builder.append(this.downPrice, test.downPrice);
                builder.append(this.highAmount, test.highAmount);
                builder.append(this.lowAmount, test.lowAmount);
                builder.append(this.trustee, test.trustee);
                builder.append(this.overdraw, test.overdraw);
                builder.append(this.assetFlag, test.assetFlag);
                builder.append(this.amountPerHand, test.amountPerHand);
                builder.append(this.storeUnit, test.storeUnit);
                builder.append(this.reportUnit, test.reportUnit);
                builder.append(this.buyUnit, test.buyUnit);
                builder.append(this.sellUnit, test.sellUnit);
                builder.append(this.priceStep, test.priceStep);
                builder.append(this.priceGrade, test.priceGrade);
                builder.append(this.reportDirection, test.reportDirection);
                builder.append(this.fundDirection, test.fundDirection);
                builder.append(this.stockDirection, test.stockDirection);
                builder.append(this.fundFrozen, test.fundFrozen);
                builder.append(this.fundRealBack, test.fundRealBack);
                builder.append(this.stockRealBack, test.stockRealBack);
                builder.append(this.tnType, test.tnType);
                builder.append(this.fundBackN, test.fundBackN);
                builder.append(this.stockBackN, test.stockBackN);
                builder.append(this.parValue, test.parValue);
                builder.append(this.marketDate, test.marketDate);
                builder.append(this.defaultpriceType, test.defaultpriceType);
                builder.append(this.limitpriceType, test.limitpriceType);
                builder.append(this.basepriceType, test.basepriceType);
                builder.append(this.limitValueUp, test.limitValueUp);
                builder.append(this.limitValueLow, test.limitValueLow);
                builder.append(this.buyClient, test.buyClient);
                builder.append(this.sellClient, test.sellClient);
                builder.append(this.buyHolder, test.buyHolder);
                builder.append(this.sellHolder, test.sellHolder);
                builder.append(this.enEntrustWay, test.enEntrustWay);
                builder.append(this.eligRiskLevel, test.eligRiskLevel);
                builder.append(this.lowBalance, test.lowBalance);
                builder.append(this.highBalance, test.highBalance);
                builder.append(this.cancelLowBalance, test.cancelLowBalance);
                builder.append(this.cancelHighBalance, test.cancelHighBalance);
                builder.append(this.issueDate, test.issueDate);
                builder.append(this.bondinvFlag, test.bondinvFlag);
                builder.append(this.delistFlag, test.delistFlag);
                builder.append(this.delistDate, test.delistDate);
                builder.append(this.stbtransType, test.stbtransType);
                builder.append(this.stbtransStatus, test.stbtransStatus);
                builder.append(this.stkcodeCtrlstr, test.stkcodeCtrlstr);
                builder.append(this.exdividendFlag, test.exdividendFlag);
                builder.append(this.marketmakerAmount, test.marketmakerAmount);
                builder.append(this.transPrice, test.transPrice);
                builder.append(this.positionStr, test.positionStr);
                builder.append(this.marketHighAmount, test.marketHighAmount);
                builder.append(this.marketLowAmount, test.marketLowAmount);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetSesstkcodeInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @NotNull(
                message = "不能为空"
        )
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 64,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 1,
                max = 4,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String exchangeType = " ";
        @SinogramLength(
                min = 1,
                max = 8,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String stockCode = " ";

        public GetSesstkcodeInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getExchangeType() {
            if (this.exchangeType == null) {
                return " ";
            } else {
                return this.exchangeType.isEmpty() ? " " : this.exchangeType;
            }
        }

        public String getStockCode() {
            if (this.stockCode == null) {
                return " ";
            } else {
                return this.stockCode.isEmpty() ? " " : this.stockCode;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public void setStockCode(String stockCode) {
            this.stockCode = stockCode;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetSesstkcodeInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(",stockCode:" + this.stockCode);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.exchangeType);
            builder.append(this.stockCode);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerCqsService.GetSesstkcodeInnerInput) {
                InnerCqsService.GetSesstkcodeInnerInput test = (InnerCqsService.GetSesstkcodeInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.exchangeType, test.exchangeType);
                builder.append(this.stockCode, test.stockCode);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetSesblobfileDataInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private List<InnerCqsService.ActblobfileDTO> rows;
        private Integer total = 0;
        private Integer currentPage = 0;

        public GetSesblobfileDataInnerOutput() {
        }

        public List<InnerCqsService.ActblobfileDTO> getRows() {
            return this.rows;
        }

        public Integer getTotal() {
            return this.total != null ? this.total : 0;
        }

        public Integer getCurrentPage() {
            return this.currentPage != null ? this.currentPage : 0;
        }

        public void setRows(List<InnerCqsService.ActblobfileDTO> rows) {
            this.rows = rows;
        }

        public void setTotal(Integer total) {
            this.total = total;
        }

        public void setCurrentPage(Integer currentPage) {
            this.currentPage = currentPage;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetSesblobfileDataInnerOutput:(");
            buffer.append("rows:" + this.rows);
            buffer.append(",total:" + this.total);
            buffer.append(",currentPage:" + this.currentPage);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.rows);
            builder.append(this.total);
            builder.append(this.currentPage);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerCqsService.GetSesblobfileDataInnerOutput) {
                InnerCqsService.GetSesblobfileDataInnerOutput test = (InnerCqsService.GetSesblobfileDataInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.rows, test.rows);
                builder.append(this.total, test.total);
                builder.append(this.currentPage, test.currentPage);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetSesblobfileDataInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @NotNull(
                message = "不能为空"
        )
        private Integer initDate = 0;
        @SinogramLength(
                min = 1,
                max = 32,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String repContent = " ";
        @SinogramLength(
                min = 1,
                max = 32,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String reqContent = " ";
        private Integer pageNo = 0;
        private Integer pageSize = 0;
        private Integer requestNum = 0;

        public GetSesblobfileDataInnerInput() {
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public String getRepContent() {
            if (this.repContent == null) {
                return " ";
            } else {
                return this.repContent.isEmpty() ? " " : this.repContent;
            }
        }

        public String getReqContent() {
            if (this.reqContent == null) {
                return " ";
            } else {
                return this.reqContent.isEmpty() ? " " : this.reqContent;
            }
        }

        public Integer getPageNo() {
            return this.pageNo != null ? this.pageNo : 0;
        }

        public Integer getPageSize() {
            return this.pageSize != null ? this.pageSize : 0;
        }

        public Integer getRequestNum() {
            return this.requestNum != null ? this.requestNum : 0;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public void setRepContent(String repContent) {
            this.repContent = repContent;
        }

        public void setReqContent(String reqContent) {
            this.reqContent = reqContent;
        }

        public void setPageNo(Integer pageNo) {
            this.pageNo = pageNo;
        }

        public void setPageSize(Integer pageSize) {
            this.pageSize = pageSize;
        }

        public void setRequestNum(Integer requestNum) {
            this.requestNum = requestNum;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetSesblobfileDataInnerInput:(");
            buffer.append("initDate:" + this.initDate);
            buffer.append(",repContent:" + this.repContent);
            buffer.append(",reqContent:" + this.reqContent);
            buffer.append(",pageNo:" + this.pageNo);
            buffer.append(",pageSize:" + this.pageSize);
            buffer.append(",requestNum:" + this.requestNum);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.initDate);
            builder.append(this.repContent);
            builder.append(this.reqContent);
            builder.append(this.pageNo);
            builder.append(this.pageSize);
            builder.append(this.requestNum);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerCqsService.GetSesblobfileDataInnerInput) {
                InnerCqsService.GetSesblobfileDataInnerInput test = (InnerCqsService.GetSesblobfileDataInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.initDate, test.initDate);
                builder.append(this.repContent, test.repContent);
                builder.append(this.reqContent, test.reqContent);
                builder.append(this.pageNo, test.pageNo);
                builder.append(this.pageSize, test.pageSize);
                builder.append(this.requestNum, test.requestNum);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetPrddataprodrealInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer initDate = 0;
        private String fundAccount = " ";
        private String clientId = " ";
        private String clientName = " ";
        private Integer clientGroup = 0;
        private Integer roomCode = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character assetProp = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character taType = ' ';
        private String prodtaNo = " ";
        private String prodAccount = " ";
        private Integer buyDate = 0;
        private String prodCode = " ";
        private String prodName = " ";
        private String allotNo = " ";
        private String moneyType = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character chargeType = ' ';
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double beginAmount = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double currentAmount = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double enableAmount = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double frozenAmount = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double unfrozenAmount = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double correctAmount = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double realBuyAmount = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double realBuyBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double realSellAmount = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double realSellBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double entrustSellAmount = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double sumBuyAmount = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double sumBuyBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double sumSellAmount = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double sumSellBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double uncomeBuyAmount = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double uncomeSellAmount = 0.0D;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character dividendWay = ' ';
        private String checkStr = " ";
        private String positionStr = " ";
        @SerializeDoubleDigit(
                digit = 8
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double prodCostPrice = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double costBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double investAmount = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double unpaidIncome = 0.0D;
        private String transAccount = " ";
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double buyCostBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 8
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double buyCostPrice = 0.0D;
        private Integer changeDate = 0;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double avIncomeBalance = 0.0D;
        private Integer limitFlag = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character businCategory = ' ';

        public GetPrddataprodrealInnerOutput() {
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getClientName() {
            if (this.clientName == null) {
                return " ";
            } else {
                return this.clientName.isEmpty() ? " " : this.clientName;
            }
        }

        public Integer getClientGroup() {
            return this.clientGroup != null ? this.clientGroup : 0;
        }

        public Integer getRoomCode() {
            return this.roomCode != null ? this.roomCode : 0;
        }

        public Character getAssetProp() {
            return this.assetProp != null ? this.assetProp : ' ';
        }

        public Character getTaType() {
            return this.taType != null ? this.taType : ' ';
        }

        public String getProdtaNo() {
            if (this.prodtaNo == null) {
                return " ";
            } else {
                return this.prodtaNo.isEmpty() ? " " : this.prodtaNo;
            }
        }

        public String getProdAccount() {
            if (this.prodAccount == null) {
                return " ";
            } else {
                return this.prodAccount.isEmpty() ? " " : this.prodAccount;
            }
        }

        public Integer getBuyDate() {
            return this.buyDate != null ? this.buyDate : 0;
        }

        public String getProdCode() {
            if (this.prodCode == null) {
                return " ";
            } else {
                return this.prodCode.isEmpty() ? " " : this.prodCode;
            }
        }

        public String getProdName() {
            if (this.prodName == null) {
                return " ";
            } else {
                return this.prodName.isEmpty() ? " " : this.prodName;
            }
        }

        public String getAllotNo() {
            if (this.allotNo == null) {
                return " ";
            } else {
                return this.allotNo.isEmpty() ? " " : this.allotNo;
            }
        }

        public String getMoneyType() {
            if (this.moneyType == null) {
                return " ";
            } else {
                return this.moneyType.isEmpty() ? " " : this.moneyType;
            }
        }

        public Character getChargeType() {
            return this.chargeType != null ? this.chargeType : ' ';
        }

        public Double getBeginAmount() {
            return this.beginAmount != null ? this.beginAmount : 0.0D;
        }

        public Double getCurrentAmount() {
            return this.currentAmount != null ? this.currentAmount : 0.0D;
        }

        public Double getEnableAmount() {
            return this.enableAmount != null ? this.enableAmount : 0.0D;
        }

        public Double getFrozenAmount() {
            return this.frozenAmount != null ? this.frozenAmount : 0.0D;
        }

        public Double getUnfrozenAmount() {
            return this.unfrozenAmount != null ? this.unfrozenAmount : 0.0D;
        }

        public Double getCorrectAmount() {
            return this.correctAmount != null ? this.correctAmount : 0.0D;
        }

        public Double getRealBuyAmount() {
            return this.realBuyAmount != null ? this.realBuyAmount : 0.0D;
        }

        public Double getRealBuyBalance() {
            return this.realBuyBalance != null ? this.realBuyBalance : 0.0D;
        }

        public Double getRealSellAmount() {
            return this.realSellAmount != null ? this.realSellAmount : 0.0D;
        }

        public Double getRealSellBalance() {
            return this.realSellBalance != null ? this.realSellBalance : 0.0D;
        }

        public Double getEntrustSellAmount() {
            return this.entrustSellAmount != null ? this.entrustSellAmount : 0.0D;
        }

        public Double getSumBuyAmount() {
            return this.sumBuyAmount != null ? this.sumBuyAmount : 0.0D;
        }

        public Double getSumBuyBalance() {
            return this.sumBuyBalance != null ? this.sumBuyBalance : 0.0D;
        }

        public Double getSumSellAmount() {
            return this.sumSellAmount != null ? this.sumSellAmount : 0.0D;
        }

        public Double getSumSellBalance() {
            return this.sumSellBalance != null ? this.sumSellBalance : 0.0D;
        }

        public Double getUncomeBuyAmount() {
            return this.uncomeBuyAmount != null ? this.uncomeBuyAmount : 0.0D;
        }

        public Double getUncomeSellAmount() {
            return this.uncomeSellAmount != null ? this.uncomeSellAmount : 0.0D;
        }

        public Character getDividendWay() {
            return this.dividendWay != null ? this.dividendWay : ' ';
        }

        public String getCheckStr() {
            if (this.checkStr == null) {
                return " ";
            } else {
                return this.checkStr.isEmpty() ? " " : this.checkStr;
            }
        }

        public String getPositionStr() {
            if (this.positionStr == null) {
                return " ";
            } else {
                return this.positionStr.isEmpty() ? " " : this.positionStr;
            }
        }

        public Double getProdCostPrice() {
            return this.prodCostPrice != null ? this.prodCostPrice : 0.0D;
        }

        public Double getCostBalance() {
            return this.costBalance != null ? this.costBalance : 0.0D;
        }

        public Double getInvestAmount() {
            return this.investAmount != null ? this.investAmount : 0.0D;
        }

        public Double getUnpaidIncome() {
            return this.unpaidIncome != null ? this.unpaidIncome : 0.0D;
        }

        public String getTransAccount() {
            if (this.transAccount == null) {
                return " ";
            } else {
                return this.transAccount.isEmpty() ? " " : this.transAccount;
            }
        }

        public Double getBuyCostBalance() {
            return this.buyCostBalance != null ? this.buyCostBalance : 0.0D;
        }

        public Double getBuyCostPrice() {
            return this.buyCostPrice != null ? this.buyCostPrice : 0.0D;
        }

        public Integer getChangeDate() {
            return this.changeDate != null ? this.changeDate : 0;
        }

        public Double getAvIncomeBalance() {
            return this.avIncomeBalance != null ? this.avIncomeBalance : 0.0D;
        }

        public Integer getLimitFlag() {
            return this.limitFlag != null ? this.limitFlag : 0;
        }

        public Character getBusinCategory() {
            return this.businCategory != null ? this.businCategory : ' ';
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setClientName(String clientName) {
            this.clientName = clientName;
        }

        public void setClientGroup(Integer clientGroup) {
            this.clientGroup = clientGroup;
        }

        public void setRoomCode(Integer roomCode) {
            this.roomCode = roomCode;
        }

        public void setAssetProp(Character assetProp) {
            this.assetProp = assetProp;
        }

        public void setTaType(Character taType) {
            this.taType = taType;
        }

        public void setProdtaNo(String prodtaNo) {
            this.prodtaNo = prodtaNo;
        }

        public void setProdAccount(String prodAccount) {
            this.prodAccount = prodAccount;
        }

        public void setBuyDate(Integer buyDate) {
            this.buyDate = buyDate;
        }

        public void setProdCode(String prodCode) {
            this.prodCode = prodCode;
        }

        public void setProdName(String prodName) {
            this.prodName = prodName;
        }

        public void setAllotNo(String allotNo) {
            this.allotNo = allotNo;
        }

        public void setMoneyType(String moneyType) {
            this.moneyType = moneyType;
        }

        public void setChargeType(Character chargeType) {
            this.chargeType = chargeType;
        }

        public void setBeginAmount(Double beginAmount) {
            this.beginAmount = beginAmount;
        }

        public void setCurrentAmount(Double currentAmount) {
            this.currentAmount = currentAmount;
        }

        public void setEnableAmount(Double enableAmount) {
            this.enableAmount = enableAmount;
        }

        public void setFrozenAmount(Double frozenAmount) {
            this.frozenAmount = frozenAmount;
        }

        public void setUnfrozenAmount(Double unfrozenAmount) {
            this.unfrozenAmount = unfrozenAmount;
        }

        public void setCorrectAmount(Double correctAmount) {
            this.correctAmount = correctAmount;
        }

        public void setRealBuyAmount(Double realBuyAmount) {
            this.realBuyAmount = realBuyAmount;
        }

        public void setRealBuyBalance(Double realBuyBalance) {
            this.realBuyBalance = realBuyBalance;
        }

        public void setRealSellAmount(Double realSellAmount) {
            this.realSellAmount = realSellAmount;
        }

        public void setRealSellBalance(Double realSellBalance) {
            this.realSellBalance = realSellBalance;
        }

        public void setEntrustSellAmount(Double entrustSellAmount) {
            this.entrustSellAmount = entrustSellAmount;
        }

        public void setSumBuyAmount(Double sumBuyAmount) {
            this.sumBuyAmount = sumBuyAmount;
        }

        public void setSumBuyBalance(Double sumBuyBalance) {
            this.sumBuyBalance = sumBuyBalance;
        }

        public void setSumSellAmount(Double sumSellAmount) {
            this.sumSellAmount = sumSellAmount;
        }

        public void setSumSellBalance(Double sumSellBalance) {
            this.sumSellBalance = sumSellBalance;
        }

        public void setUncomeBuyAmount(Double uncomeBuyAmount) {
            this.uncomeBuyAmount = uncomeBuyAmount;
        }

        public void setUncomeSellAmount(Double uncomeSellAmount) {
            this.uncomeSellAmount = uncomeSellAmount;
        }

        public void setDividendWay(Character dividendWay) {
            this.dividendWay = dividendWay;
        }

        public void setCheckStr(String checkStr) {
            this.checkStr = checkStr;
        }

        public void setPositionStr(String positionStr) {
            this.positionStr = positionStr;
        }

        public void setProdCostPrice(Double prodCostPrice) {
            this.prodCostPrice = prodCostPrice;
        }

        public void setCostBalance(Double costBalance) {
            this.costBalance = costBalance;
        }

        public void setInvestAmount(Double investAmount) {
            this.investAmount = investAmount;
        }

        public void setUnpaidIncome(Double unpaidIncome) {
            this.unpaidIncome = unpaidIncome;
        }

        public void setTransAccount(String transAccount) {
            this.transAccount = transAccount;
        }

        public void setBuyCostBalance(Double buyCostBalance) {
            this.buyCostBalance = buyCostBalance;
        }

        public void setBuyCostPrice(Double buyCostPrice) {
            this.buyCostPrice = buyCostPrice;
        }

        public void setChangeDate(Integer changeDate) {
            this.changeDate = changeDate;
        }

        public void setAvIncomeBalance(Double avIncomeBalance) {
            this.avIncomeBalance = avIncomeBalance;
        }

        public void setLimitFlag(Integer limitFlag) {
            this.limitFlag = limitFlag;
        }

        public void setBusinCategory(Character businCategory) {
            this.businCategory = businCategory;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetPrddataprodrealInnerOutput:(");
            buffer.append("initDate:" + this.initDate);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",clientName:" + this.clientName);
            buffer.append(",clientGroup:" + this.clientGroup);
            buffer.append(",roomCode:" + this.roomCode);
            buffer.append(",assetProp:" + this.assetProp);
            buffer.append(",taType:" + this.taType);
            buffer.append(",prodtaNo:" + this.prodtaNo);
            buffer.append(",prodAccount:" + this.prodAccount);
            buffer.append(",buyDate:" + this.buyDate);
            buffer.append(",prodCode:" + this.prodCode);
            buffer.append(",prodName:" + this.prodName);
            buffer.append(",allotNo:" + this.allotNo);
            buffer.append(",moneyType:" + this.moneyType);
            buffer.append(",chargeType:" + this.chargeType);
            buffer.append(",beginAmount:" + this.beginAmount);
            buffer.append(",currentAmount:" + this.currentAmount);
            buffer.append(",enableAmount:" + this.enableAmount);
            buffer.append(",frozenAmount:" + this.frozenAmount);
            buffer.append(",unfrozenAmount:" + this.unfrozenAmount);
            buffer.append(",correctAmount:" + this.correctAmount);
            buffer.append(",realBuyAmount:" + this.realBuyAmount);
            buffer.append(",realBuyBalance:" + this.realBuyBalance);
            buffer.append(",realSellAmount:" + this.realSellAmount);
            buffer.append(",realSellBalance:" + this.realSellBalance);
            buffer.append(",entrustSellAmount:" + this.entrustSellAmount);
            buffer.append(",sumBuyAmount:" + this.sumBuyAmount);
            buffer.append(",sumBuyBalance:" + this.sumBuyBalance);
            buffer.append(",sumSellAmount:" + this.sumSellAmount);
            buffer.append(",sumSellBalance:" + this.sumSellBalance);
            buffer.append(",uncomeBuyAmount:" + this.uncomeBuyAmount);
            buffer.append(",uncomeSellAmount:" + this.uncomeSellAmount);
            buffer.append(",dividendWay:" + this.dividendWay);
            buffer.append(",checkStr:" + this.checkStr);
            buffer.append(",positionStr:" + this.positionStr);
            buffer.append(",prodCostPrice:" + this.prodCostPrice);
            buffer.append(",costBalance:" + this.costBalance);
            buffer.append(",investAmount:" + this.investAmount);
            buffer.append(",unpaidIncome:" + this.unpaidIncome);
            buffer.append(",transAccount:" + this.transAccount);
            buffer.append(",buyCostBalance:" + this.buyCostBalance);
            buffer.append(",buyCostPrice:" + this.buyCostPrice);
            buffer.append(",changeDate:" + this.changeDate);
            buffer.append(",avIncomeBalance:" + this.avIncomeBalance);
            buffer.append(",limitFlag:" + this.limitFlag);
            buffer.append(",businCategory:" + this.businCategory);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.initDate);
            builder.append(this.fundAccount);
            builder.append(this.clientId);
            builder.append(this.clientName);
            builder.append(this.clientGroup);
            builder.append(this.roomCode);
            builder.append(this.assetProp);
            builder.append(this.taType);
            builder.append(this.prodtaNo);
            builder.append(this.prodAccount);
            builder.append(this.buyDate);
            builder.append(this.prodCode);
            builder.append(this.prodName);
            builder.append(this.allotNo);
            builder.append(this.moneyType);
            builder.append(this.chargeType);
            builder.append(this.beginAmount);
            builder.append(this.currentAmount);
            builder.append(this.enableAmount);
            builder.append(this.frozenAmount);
            builder.append(this.unfrozenAmount);
            builder.append(this.correctAmount);
            builder.append(this.realBuyAmount);
            builder.append(this.realBuyBalance);
            builder.append(this.realSellAmount);
            builder.append(this.realSellBalance);
            builder.append(this.entrustSellAmount);
            builder.append(this.sumBuyAmount);
            builder.append(this.sumBuyBalance);
            builder.append(this.sumSellAmount);
            builder.append(this.sumSellBalance);
            builder.append(this.uncomeBuyAmount);
            builder.append(this.uncomeSellAmount);
            builder.append(this.dividendWay);
            builder.append(this.checkStr);
            builder.append(this.positionStr);
            builder.append(this.prodCostPrice);
            builder.append(this.costBalance);
            builder.append(this.investAmount);
            builder.append(this.unpaidIncome);
            builder.append(this.transAccount);
            builder.append(this.buyCostBalance);
            builder.append(this.buyCostPrice);
            builder.append(this.changeDate);
            builder.append(this.avIncomeBalance);
            builder.append(this.limitFlag);
            builder.append(this.businCategory);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerCqsService.GetPrddataprodrealInnerOutput) {
                InnerCqsService.GetPrddataprodrealInnerOutput test = (InnerCqsService.GetPrddataprodrealInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.initDate, test.initDate);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.clientId, test.clientId);
                builder.append(this.clientName, test.clientName);
                builder.append(this.clientGroup, test.clientGroup);
                builder.append(this.roomCode, test.roomCode);
                builder.append(this.assetProp, test.assetProp);
                builder.append(this.taType, test.taType);
                builder.append(this.prodtaNo, test.prodtaNo);
                builder.append(this.prodAccount, test.prodAccount);
                builder.append(this.buyDate, test.buyDate);
                builder.append(this.prodCode, test.prodCode);
                builder.append(this.prodName, test.prodName);
                builder.append(this.allotNo, test.allotNo);
                builder.append(this.moneyType, test.moneyType);
                builder.append(this.chargeType, test.chargeType);
                builder.append(this.beginAmount, test.beginAmount);
                builder.append(this.currentAmount, test.currentAmount);
                builder.append(this.enableAmount, test.enableAmount);
                builder.append(this.frozenAmount, test.frozenAmount);
                builder.append(this.unfrozenAmount, test.unfrozenAmount);
                builder.append(this.correctAmount, test.correctAmount);
                builder.append(this.realBuyAmount, test.realBuyAmount);
                builder.append(this.realBuyBalance, test.realBuyBalance);
                builder.append(this.realSellAmount, test.realSellAmount);
                builder.append(this.realSellBalance, test.realSellBalance);
                builder.append(this.entrustSellAmount, test.entrustSellAmount);
                builder.append(this.sumBuyAmount, test.sumBuyAmount);
                builder.append(this.sumBuyBalance, test.sumBuyBalance);
                builder.append(this.sumSellAmount, test.sumSellAmount);
                builder.append(this.sumSellBalance, test.sumSellBalance);
                builder.append(this.uncomeBuyAmount, test.uncomeBuyAmount);
                builder.append(this.uncomeSellAmount, test.uncomeSellAmount);
                builder.append(this.dividendWay, test.dividendWay);
                builder.append(this.checkStr, test.checkStr);
                builder.append(this.positionStr, test.positionStr);
                builder.append(this.prodCostPrice, test.prodCostPrice);
                builder.append(this.costBalance, test.costBalance);
                builder.append(this.investAmount, test.investAmount);
                builder.append(this.unpaidIncome, test.unpaidIncome);
                builder.append(this.transAccount, test.transAccount);
                builder.append(this.buyCostBalance, test.buyCostBalance);
                builder.append(this.buyCostPrice, test.buyCostPrice);
                builder.append(this.changeDate, test.changeDate);
                builder.append(this.avIncomeBalance, test.avIncomeBalance);
                builder.append(this.limitFlag, test.limitFlag);
                builder.append(this.businCategory, test.businCategory);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetPrddataprodrealInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @NotNull(
                message = "不能为空"
        )
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 64,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fundAccount = " ";
        @SinogramLength(
                min = 0,
                max = 24,
                charset = "utf-8"
        )
        private String prodtaNo = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String prodAccount = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String prodCode = " ";
        private Integer beginDate = 0;
        private Integer endDate = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character businCategory = ' ';

        public GetPrddataprodrealInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getProdtaNo() {
            if (this.prodtaNo == null) {
                return " ";
            } else {
                return this.prodtaNo.isEmpty() ? " " : this.prodtaNo;
            }
        }

        public String getProdAccount() {
            if (this.prodAccount == null) {
                return " ";
            } else {
                return this.prodAccount.isEmpty() ? " " : this.prodAccount;
            }
        }

        public String getProdCode() {
            if (this.prodCode == null) {
                return " ";
            } else {
                return this.prodCode.isEmpty() ? " " : this.prodCode;
            }
        }

        public Integer getBeginDate() {
            return this.beginDate != null ? this.beginDate : 0;
        }

        public Integer getEndDate() {
            return this.endDate != null ? this.endDate : 0;
        }

        public Character getBusinCategory() {
            return this.businCategory != null ? this.businCategory : ' ';
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setProdtaNo(String prodtaNo) {
            this.prodtaNo = prodtaNo;
        }

        public void setProdAccount(String prodAccount) {
            this.prodAccount = prodAccount;
        }

        public void setProdCode(String prodCode) {
            this.prodCode = prodCode;
        }

        public void setBeginDate(Integer beginDate) {
            this.beginDate = beginDate;
        }

        public void setEndDate(Integer endDate) {
            this.endDate = endDate;
        }

        public void setBusinCategory(Character businCategory) {
            this.businCategory = businCategory;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetPrddataprodrealInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",prodtaNo:" + this.prodtaNo);
            buffer.append(",prodAccount:" + this.prodAccount);
            buffer.append(",prodCode:" + this.prodCode);
            buffer.append(",beginDate:" + this.beginDate);
            buffer.append(",endDate:" + this.endDate);
            buffer.append(",businCategory:" + this.businCategory);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.clientId);
            builder.append(this.fundAccount);
            builder.append(this.prodtaNo);
            builder.append(this.prodAccount);
            builder.append(this.prodCode);
            builder.append(this.beginDate);
            builder.append(this.endDate);
            builder.append(this.businCategory);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerCqsService.GetPrddataprodrealInnerInput) {
                InnerCqsService.GetPrddataprodrealInnerInput test = (InnerCqsService.GetPrddataprodrealInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.clientId, test.clientId);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.prodtaNo, test.prodtaNo);
                builder.append(this.prodAccount, test.prodAccount);
                builder.append(this.prodCode, test.prodCode);
                builder.append(this.beginDate, test.beginDate);
                builder.append(this.endDate, test.endDate);
                builder.append(this.businCategory, test.businCategory);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetElgtestjourInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer initDate = 0;
        private Long serialNo = 0L;
        private Integer currDate = 0;
        private Integer currTime = 0;
        private String operatorNo = " ";
        private Integer opBranchNo = 0;
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private String clientId = " ";
        private String clientName = " ";
        private String fullName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character idKind = ' ';
        private String idNo = " ";
        private String paperType = " ";
        private String prodtaNo = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character organFlag = ' ';
        private String paperAnswer = " ";
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double paperScore = 0.0D;
        private Integer dateClear = 0;
        private String clearFlag = " ";
        private String remark = " ";
        private String positionStr = " ";
        private Integer corpRiskLevel = 0;
        private String eligpaperVersion = " ";
        private String enInvestKind = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character minRankFlag = ' ';
        private String enInvestTerm = " ";
        private String subPaperType = " ";
        private Integer autoeligtestDate = 0;
        private String prodCode = " ";

        public GetElgtestjourInnerOutput() {
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public Long getSerialNo() {
            return this.serialNo != null ? this.serialNo : 0L;
        }

        public Integer getCurrDate() {
            return this.currDate != null ? this.currDate : 0;
        }

        public Integer getCurrTime() {
            return this.currTime != null ? this.currTime : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getClientName() {
            if (this.clientName == null) {
                return " ";
            } else {
                return this.clientName.isEmpty() ? " " : this.clientName;
            }
        }

        public String getFullName() {
            if (this.fullName == null) {
                return " ";
            } else {
                return this.fullName.isEmpty() ? " " : this.fullName;
            }
        }

        public Character getIdKind() {
            return this.idKind != null ? this.idKind : ' ';
        }

        public String getIdNo() {
            if (this.idNo == null) {
                return " ";
            } else {
                return this.idNo.isEmpty() ? " " : this.idNo;
            }
        }

        public String getPaperType() {
            if (this.paperType == null) {
                return " ";
            } else {
                return this.paperType.isEmpty() ? " " : this.paperType;
            }
        }

        public String getProdtaNo() {
            if (this.prodtaNo == null) {
                return " ";
            } else {
                return this.prodtaNo.isEmpty() ? " " : this.prodtaNo;
            }
        }

        public Character getOrganFlag() {
            return this.organFlag != null ? this.organFlag : ' ';
        }

        public String getPaperAnswer() {
            if (this.paperAnswer == null) {
                return " ";
            } else {
                return this.paperAnswer.isEmpty() ? " " : this.paperAnswer;
            }
        }

        public Double getPaperScore() {
            return this.paperScore != null ? this.paperScore : 0.0D;
        }

        public Integer getDateClear() {
            return this.dateClear != null ? this.dateClear : 0;
        }

        public String getClearFlag() {
            if (this.clearFlag == null) {
                return " ";
            } else {
                return this.clearFlag.isEmpty() ? " " : this.clearFlag;
            }
        }

        public String getRemark() {
            if (this.remark == null) {
                return " ";
            } else {
                return this.remark.isEmpty() ? " " : this.remark;
            }
        }

        public String getPositionStr() {
            if (this.positionStr == null) {
                return " ";
            } else {
                return this.positionStr.isEmpty() ? " " : this.positionStr;
            }
        }

        public Integer getCorpRiskLevel() {
            return this.corpRiskLevel != null ? this.corpRiskLevel : 0;
        }

        public String getEligpaperVersion() {
            if (this.eligpaperVersion == null) {
                return " ";
            } else {
                return this.eligpaperVersion.isEmpty() ? " " : this.eligpaperVersion;
            }
        }

        public String getEnInvestKind() {
            if (this.enInvestKind == null) {
                return " ";
            } else {
                return this.enInvestKind.isEmpty() ? " " : this.enInvestKind;
            }
        }

        public Character getMinRankFlag() {
            return this.minRankFlag != null ? this.minRankFlag : ' ';
        }

        public String getEnInvestTerm() {
            if (this.enInvestTerm == null) {
                return " ";
            } else {
                return this.enInvestTerm.isEmpty() ? " " : this.enInvestTerm;
            }
        }

        public String getSubPaperType() {
            if (this.subPaperType == null) {
                return " ";
            } else {
                return this.subPaperType.isEmpty() ? " " : this.subPaperType;
            }
        }

        public Integer getAutoeligtestDate() {
            return this.autoeligtestDate != null ? this.autoeligtestDate : 0;
        }

        public String getProdCode() {
            if (this.prodCode == null) {
                return " ";
            } else {
                return this.prodCode.isEmpty() ? " " : this.prodCode;
            }
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public void setSerialNo(Long serialNo) {
            this.serialNo = serialNo;
        }

        public void setCurrDate(Integer currDate) {
            this.currDate = currDate;
        }

        public void setCurrTime(Integer currTime) {
            this.currTime = currTime;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setClientName(String clientName) {
            this.clientName = clientName;
        }

        public void setFullName(String fullName) {
            this.fullName = fullName;
        }

        public void setIdKind(Character idKind) {
            this.idKind = idKind;
        }

        public void setIdNo(String idNo) {
            this.idNo = idNo;
        }

        public void setPaperType(String paperType) {
            this.paperType = paperType;
        }

        public void setProdtaNo(String prodtaNo) {
            this.prodtaNo = prodtaNo;
        }

        public void setOrganFlag(Character organFlag) {
            this.organFlag = organFlag;
        }

        public void setPaperAnswer(String paperAnswer) {
            this.paperAnswer = paperAnswer;
        }

        public void setPaperScore(Double paperScore) {
            this.paperScore = paperScore;
        }

        public void setDateClear(Integer dateClear) {
            this.dateClear = dateClear;
        }

        public void setClearFlag(String clearFlag) {
            this.clearFlag = clearFlag;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public void setPositionStr(String positionStr) {
            this.positionStr = positionStr;
        }

        public void setCorpRiskLevel(Integer corpRiskLevel) {
            this.corpRiskLevel = corpRiskLevel;
        }

        public void setEligpaperVersion(String eligpaperVersion) {
            this.eligpaperVersion = eligpaperVersion;
        }

        public void setEnInvestKind(String enInvestKind) {
            this.enInvestKind = enInvestKind;
        }

        public void setMinRankFlag(Character minRankFlag) {
            this.minRankFlag = minRankFlag;
        }

        public void setEnInvestTerm(String enInvestTerm) {
            this.enInvestTerm = enInvestTerm;
        }

        public void setSubPaperType(String subPaperType) {
            this.subPaperType = subPaperType;
        }

        public void setAutoeligtestDate(Integer autoeligtestDate) {
            this.autoeligtestDate = autoeligtestDate;
        }

        public void setProdCode(String prodCode) {
            this.prodCode = prodCode;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetElgtestjourInnerOutput:(");
            buffer.append("initDate:" + this.initDate);
            buffer.append(",serialNo:" + this.serialNo);
            buffer.append(",currDate:" + this.currDate);
            buffer.append(",currTime:" + this.currTime);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",clientName:" + this.clientName);
            buffer.append(",fullName:" + this.fullName);
            buffer.append(",idKind:" + this.idKind);
            buffer.append(",idNo:" + this.idNo);
            buffer.append(",paperType:" + this.paperType);
            buffer.append(",prodtaNo:" + this.prodtaNo);
            buffer.append(",organFlag:" + this.organFlag);
            buffer.append(",paperAnswer:" + this.paperAnswer);
            buffer.append(",paperScore:" + this.paperScore);
            buffer.append(",dateClear:" + this.dateClear);
            buffer.append(",clearFlag:" + this.clearFlag);
            buffer.append(",remark:" + this.remark);
            buffer.append(",positionStr:" + this.positionStr);
            buffer.append(",corpRiskLevel:" + this.corpRiskLevel);
            buffer.append(",eligpaperVersion:" + this.eligpaperVersion);
            buffer.append(",enInvestKind:" + this.enInvestKind);
            buffer.append(",minRankFlag:" + this.minRankFlag);
            buffer.append(",enInvestTerm:" + this.enInvestTerm);
            buffer.append(",subPaperType:" + this.subPaperType);
            buffer.append(",autoeligtestDate:" + this.autoeligtestDate);
            buffer.append(",prodCode:" + this.prodCode);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.initDate);
            builder.append(this.serialNo);
            builder.append(this.currDate);
            builder.append(this.currTime);
            builder.append(this.operatorNo);
            builder.append(this.opBranchNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.clientId);
            builder.append(this.clientName);
            builder.append(this.fullName);
            builder.append(this.idKind);
            builder.append(this.idNo);
            builder.append(this.paperType);
            builder.append(this.prodtaNo);
            builder.append(this.organFlag);
            builder.append(this.paperAnswer);
            builder.append(this.paperScore);
            builder.append(this.dateClear);
            builder.append(this.clearFlag);
            builder.append(this.remark);
            builder.append(this.positionStr);
            builder.append(this.corpRiskLevel);
            builder.append(this.eligpaperVersion);
            builder.append(this.enInvestKind);
            builder.append(this.minRankFlag);
            builder.append(this.enInvestTerm);
            builder.append(this.subPaperType);
            builder.append(this.autoeligtestDate);
            builder.append(this.prodCode);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerCqsService.GetElgtestjourInnerOutput) {
                InnerCqsService.GetElgtestjourInnerOutput test = (InnerCqsService.GetElgtestjourInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.initDate, test.initDate);
                builder.append(this.serialNo, test.serialNo);
                builder.append(this.currDate, test.currDate);
                builder.append(this.currTime, test.currTime);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.clientId, test.clientId);
                builder.append(this.clientName, test.clientName);
                builder.append(this.fullName, test.fullName);
                builder.append(this.idKind, test.idKind);
                builder.append(this.idNo, test.idNo);
                builder.append(this.paperType, test.paperType);
                builder.append(this.prodtaNo, test.prodtaNo);
                builder.append(this.organFlag, test.organFlag);
                builder.append(this.paperAnswer, test.paperAnswer);
                builder.append(this.paperScore, test.paperScore);
                builder.append(this.dateClear, test.dateClear);
                builder.append(this.clearFlag, test.clearFlag);
                builder.append(this.remark, test.remark);
                builder.append(this.positionStr, test.positionStr);
                builder.append(this.corpRiskLevel, test.corpRiskLevel);
                builder.append(this.eligpaperVersion, test.eligpaperVersion);
                builder.append(this.enInvestKind, test.enInvestKind);
                builder.append(this.minRankFlag, test.minRankFlag);
                builder.append(this.enInvestTerm, test.enInvestTerm);
                builder.append(this.subPaperType, test.subPaperType);
                builder.append(this.autoeligtestDate, test.autoeligtestDate);
                builder.append(this.prodCode, test.prodCode);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetElgtestjourInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @NotNull(
                message = "不能为空"
        )
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 64,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String clientId = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character organFlag = ' ';
        @SinogramLength(
                min = 0,
                max = 2,
                charset = "utf-8"
        )
        private String paperType = " ";
        @SinogramLength(
                min = 0,
                max = 24,
                charset = "utf-8"
        )
        private String prodtaNo = " ";
        @SinogramLength(
                min = 0,
                max = 100,
                charset = "utf-8"
        )
        private String clientRiskEvalNo = " ";
        private Integer beginDate = 0;
        private Integer endDate = 0;
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String prodCode = " ";

        public GetElgtestjourInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public Character getOrganFlag() {
            return this.organFlag != null ? this.organFlag : ' ';
        }

        public String getPaperType() {
            if (this.paperType == null) {
                return " ";
            } else {
                return this.paperType.isEmpty() ? " " : this.paperType;
            }
        }

        public String getProdtaNo() {
            if (this.prodtaNo == null) {
                return " ";
            } else {
                return this.prodtaNo.isEmpty() ? " " : this.prodtaNo;
            }
        }

        public String getClientRiskEvalNo() {
            if (this.clientRiskEvalNo == null) {
                return " ";
            } else {
                return this.clientRiskEvalNo.isEmpty() ? " " : this.clientRiskEvalNo;
            }
        }

        public Integer getBeginDate() {
            return this.beginDate != null ? this.beginDate : 0;
        }

        public Integer getEndDate() {
            return this.endDate != null ? this.endDate : 0;
        }

        public String getProdCode() {
            if (this.prodCode == null) {
                return " ";
            } else {
                return this.prodCode.isEmpty() ? " " : this.prodCode;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setOrganFlag(Character organFlag) {
            this.organFlag = organFlag;
        }

        public void setPaperType(String paperType) {
            this.paperType = paperType;
        }

        public void setProdtaNo(String prodtaNo) {
            this.prodtaNo = prodtaNo;
        }

        public void setClientRiskEvalNo(String clientRiskEvalNo) {
            this.clientRiskEvalNo = clientRiskEvalNo;
        }

        public void setBeginDate(Integer beginDate) {
            this.beginDate = beginDate;
        }

        public void setEndDate(Integer endDate) {
            this.endDate = endDate;
        }

        public void setProdCode(String prodCode) {
            this.prodCode = prodCode;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetElgtestjourInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",organFlag:" + this.organFlag);
            buffer.append(",paperType:" + this.paperType);
            buffer.append(",prodtaNo:" + this.prodtaNo);
            buffer.append(",clientRiskEvalNo:" + this.clientRiskEvalNo);
            buffer.append(",beginDate:" + this.beginDate);
            buffer.append(",endDate:" + this.endDate);
            buffer.append(",prodCode:" + this.prodCode);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.clientId);
            builder.append(this.organFlag);
            builder.append(this.paperType);
            builder.append(this.prodtaNo);
            builder.append(this.clientRiskEvalNo);
            builder.append(this.beginDate);
            builder.append(this.endDate);
            builder.append(this.prodCode);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerCqsService.GetElgtestjourInnerInput) {
                InnerCqsService.GetElgtestjourInnerInput test = (InnerCqsService.GetElgtestjourInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.clientId, test.clientId);
                builder.append(this.organFlag, test.organFlag);
                builder.append(this.paperType, test.paperType);
                builder.append(this.prodtaNo, test.prodtaNo);
                builder.append(this.clientRiskEvalNo, test.clientRiskEvalNo);
                builder.append(this.beginDate, test.beginDate);
                builder.append(this.endDate, test.endDate);
                builder.append(this.prodCode, test.prodCode);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetElgstibclientassetsendInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer initDate = 0;
        private String clientId = " ";
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double fundAsset = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double payableBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double receivableBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double marketValue = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double payableMarketValue = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double receivableMarketValue = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double otherFairValue = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double otherPayableFairValue = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double otherReceivableFairValue = 0.0D;

        public GetElgstibclientassetsendInnerOutput() {
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public Double getFundAsset() {
            return this.fundAsset != null ? this.fundAsset : 0.0D;
        }

        public Double getPayableBalance() {
            return this.payableBalance != null ? this.payableBalance : 0.0D;
        }

        public Double getReceivableBalance() {
            return this.receivableBalance != null ? this.receivableBalance : 0.0D;
        }

        public Double getMarketValue() {
            return this.marketValue != null ? this.marketValue : 0.0D;
        }

        public Double getPayableMarketValue() {
            return this.payableMarketValue != null ? this.payableMarketValue : 0.0D;
        }

        public Double getReceivableMarketValue() {
            return this.receivableMarketValue != null ? this.receivableMarketValue : 0.0D;
        }

        public Double getOtherFairValue() {
            return this.otherFairValue != null ? this.otherFairValue : 0.0D;
        }

        public Double getOtherPayableFairValue() {
            return this.otherPayableFairValue != null ? this.otherPayableFairValue : 0.0D;
        }

        public Double getOtherReceivableFairValue() {
            return this.otherReceivableFairValue != null ? this.otherReceivableFairValue : 0.0D;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setFundAsset(Double fundAsset) {
            this.fundAsset = fundAsset;
        }

        public void setPayableBalance(Double payableBalance) {
            this.payableBalance = payableBalance;
        }

        public void setReceivableBalance(Double receivableBalance) {
            this.receivableBalance = receivableBalance;
        }

        public void setMarketValue(Double marketValue) {
            this.marketValue = marketValue;
        }

        public void setPayableMarketValue(Double payableMarketValue) {
            this.payableMarketValue = payableMarketValue;
        }

        public void setReceivableMarketValue(Double receivableMarketValue) {
            this.receivableMarketValue = receivableMarketValue;
        }

        public void setOtherFairValue(Double otherFairValue) {
            this.otherFairValue = otherFairValue;
        }

        public void setOtherPayableFairValue(Double otherPayableFairValue) {
            this.otherPayableFairValue = otherPayableFairValue;
        }

        public void setOtherReceivableFairValue(Double otherReceivableFairValue) {
            this.otherReceivableFairValue = otherReceivableFairValue;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetElgstibclientassetsendInnerOutput:(");
            buffer.append("initDate:" + this.initDate);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",fundAsset:" + this.fundAsset);
            buffer.append(",payableBalance:" + this.payableBalance);
            buffer.append(",receivableBalance:" + this.receivableBalance);
            buffer.append(",marketValue:" + this.marketValue);
            buffer.append(",payableMarketValue:" + this.payableMarketValue);
            buffer.append(",receivableMarketValue:" + this.receivableMarketValue);
            buffer.append(",otherFairValue:" + this.otherFairValue);
            buffer.append(",otherPayableFairValue:" + this.otherPayableFairValue);
            buffer.append(",otherReceivableFairValue:" + this.otherReceivableFairValue);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.initDate);
            builder.append(this.clientId);
            builder.append(this.fundAsset);
            builder.append(this.payableBalance);
            builder.append(this.receivableBalance);
            builder.append(this.marketValue);
            builder.append(this.payableMarketValue);
            builder.append(this.receivableMarketValue);
            builder.append(this.otherFairValue);
            builder.append(this.otherPayableFairValue);
            builder.append(this.otherReceivableFairValue);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerCqsService.GetElgstibclientassetsendInnerOutput) {
                InnerCqsService.GetElgstibclientassetsendInnerOutput test = (InnerCqsService.GetElgstibclientassetsendInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.initDate, test.initDate);
                builder.append(this.clientId, test.clientId);
                builder.append(this.fundAsset, test.fundAsset);
                builder.append(this.payableBalance, test.payableBalance);
                builder.append(this.receivableBalance, test.receivableBalance);
                builder.append(this.marketValue, test.marketValue);
                builder.append(this.payableMarketValue, test.payableMarketValue);
                builder.append(this.receivableMarketValue, test.receivableMarketValue);
                builder.append(this.otherFairValue, test.otherFairValue);
                builder.append(this.otherPayableFairValue, test.otherPayableFairValue);
                builder.append(this.otherReceivableFairValue, test.otherReceivableFairValue);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetElgstibclientassetsendInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @NotNull(
                message = "不能为空"
        )
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 64,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer initDate = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String clientId = " ";

        public GetElgstibclientassetsendInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetElgstibclientassetsendInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",initDate:" + this.initDate);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.initDate);
            builder.append(this.clientId);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerCqsService.GetElgstibclientassetsendInnerInput) {
                InnerCqsService.GetElgstibclientassetsendInnerInput test = (InnerCqsService.GetElgstibclientassetsendInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.initDate, test.initDate);
                builder.append(this.clientId, test.clientId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetElghisassetInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double assetBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double secuMarketValue = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double opfundMarketValue = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double prodMarketValue = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double optMarketValue = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double ofcashMarketValue = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double pfundMarketValue = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double totalDebit = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double fundAsset = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double totalAsset = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double hkfundMarketValue = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double secumMarketValue = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double prodSecuMarketValue = 0.0D;
        private Integer initDate = 0;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double assureCloseBalance = 0.0D;

        public GetElghisassetInnerOutput() {
        }

        public Double getAssetBalance() {
            return this.assetBalance != null ? this.assetBalance : 0.0D;
        }

        public Double getSecuMarketValue() {
            return this.secuMarketValue != null ? this.secuMarketValue : 0.0D;
        }

        public Double getOpfundMarketValue() {
            return this.opfundMarketValue != null ? this.opfundMarketValue : 0.0D;
        }

        public Double getProdMarketValue() {
            return this.prodMarketValue != null ? this.prodMarketValue : 0.0D;
        }

        public Double getOptMarketValue() {
            return this.optMarketValue != null ? this.optMarketValue : 0.0D;
        }

        public Double getOfcashMarketValue() {
            return this.ofcashMarketValue != null ? this.ofcashMarketValue : 0.0D;
        }

        public Double getPfundMarketValue() {
            return this.pfundMarketValue != null ? this.pfundMarketValue : 0.0D;
        }

        public Double getTotalDebit() {
            return this.totalDebit != null ? this.totalDebit : 0.0D;
        }

        public Double getFundAsset() {
            return this.fundAsset != null ? this.fundAsset : 0.0D;
        }

        public Double getTotalAsset() {
            return this.totalAsset != null ? this.totalAsset : 0.0D;
        }

        public Double getHkfundMarketValue() {
            return this.hkfundMarketValue != null ? this.hkfundMarketValue : 0.0D;
        }

        public Double getSecumMarketValue() {
            return this.secumMarketValue != null ? this.secumMarketValue : 0.0D;
        }

        public Double getProdSecuMarketValue() {
            return this.prodSecuMarketValue != null ? this.prodSecuMarketValue : 0.0D;
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public Double getAssureCloseBalance() {
            return this.assureCloseBalance != null ? this.assureCloseBalance : 0.0D;
        }

        public void setAssetBalance(Double assetBalance) {
            this.assetBalance = assetBalance;
        }

        public void setSecuMarketValue(Double secuMarketValue) {
            this.secuMarketValue = secuMarketValue;
        }

        public void setOpfundMarketValue(Double opfundMarketValue) {
            this.opfundMarketValue = opfundMarketValue;
        }

        public void setProdMarketValue(Double prodMarketValue) {
            this.prodMarketValue = prodMarketValue;
        }

        public void setOptMarketValue(Double optMarketValue) {
            this.optMarketValue = optMarketValue;
        }

        public void setOfcashMarketValue(Double ofcashMarketValue) {
            this.ofcashMarketValue = ofcashMarketValue;
        }

        public void setPfundMarketValue(Double pfundMarketValue) {
            this.pfundMarketValue = pfundMarketValue;
        }

        public void setTotalDebit(Double totalDebit) {
            this.totalDebit = totalDebit;
        }

        public void setFundAsset(Double fundAsset) {
            this.fundAsset = fundAsset;
        }

        public void setTotalAsset(Double totalAsset) {
            this.totalAsset = totalAsset;
        }

        public void setHkfundMarketValue(Double hkfundMarketValue) {
            this.hkfundMarketValue = hkfundMarketValue;
        }

        public void setSecumMarketValue(Double secumMarketValue) {
            this.secumMarketValue = secumMarketValue;
        }

        public void setProdSecuMarketValue(Double prodSecuMarketValue) {
            this.prodSecuMarketValue = prodSecuMarketValue;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public void setAssureCloseBalance(Double assureCloseBalance) {
            this.assureCloseBalance = assureCloseBalance;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetElghisassetInnerOutput:(");
            buffer.append("assetBalance:" + this.assetBalance);
            buffer.append(",secuMarketValue:" + this.secuMarketValue);
            buffer.append(",opfundMarketValue:" + this.opfundMarketValue);
            buffer.append(",prodMarketValue:" + this.prodMarketValue);
            buffer.append(",optMarketValue:" + this.optMarketValue);
            buffer.append(",ofcashMarketValue:" + this.ofcashMarketValue);
            buffer.append(",pfundMarketValue:" + this.pfundMarketValue);
            buffer.append(",totalDebit:" + this.totalDebit);
            buffer.append(",fundAsset:" + this.fundAsset);
            buffer.append(",totalAsset:" + this.totalAsset);
            buffer.append(",hkfundMarketValue:" + this.hkfundMarketValue);
            buffer.append(",secumMarketValue:" + this.secumMarketValue);
            buffer.append(",prodSecuMarketValue:" + this.prodSecuMarketValue);
            buffer.append(",initDate:" + this.initDate);
            buffer.append(",assureCloseBalance:" + this.assureCloseBalance);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.assetBalance);
            builder.append(this.secuMarketValue);
            builder.append(this.opfundMarketValue);
            builder.append(this.prodMarketValue);
            builder.append(this.optMarketValue);
            builder.append(this.ofcashMarketValue);
            builder.append(this.pfundMarketValue);
            builder.append(this.totalDebit);
            builder.append(this.fundAsset);
            builder.append(this.totalAsset);
            builder.append(this.hkfundMarketValue);
            builder.append(this.secumMarketValue);
            builder.append(this.prodSecuMarketValue);
            builder.append(this.initDate);
            builder.append(this.assureCloseBalance);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerCqsService.GetElghisassetInnerOutput) {
                InnerCqsService.GetElghisassetInnerOutput test = (InnerCqsService.GetElghisassetInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.assetBalance, test.assetBalance);
                builder.append(this.secuMarketValue, test.secuMarketValue);
                builder.append(this.opfundMarketValue, test.opfundMarketValue);
                builder.append(this.prodMarketValue, test.prodMarketValue);
                builder.append(this.optMarketValue, test.optMarketValue);
                builder.append(this.ofcashMarketValue, test.ofcashMarketValue);
                builder.append(this.pfundMarketValue, test.pfundMarketValue);
                builder.append(this.totalDebit, test.totalDebit);
                builder.append(this.fundAsset, test.fundAsset);
                builder.append(this.totalAsset, test.totalAsset);
                builder.append(this.hkfundMarketValue, test.hkfundMarketValue);
                builder.append(this.secumMarketValue, test.secumMarketValue);
                builder.append(this.prodSecuMarketValue, test.prodSecuMarketValue);
                builder.append(this.initDate, test.initDate);
                builder.append(this.assureCloseBalance, test.assureCloseBalance);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetElghisassetInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @NotNull(
                message = "不能为空"
        )
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 64,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId = " ";
        @NotNull(
                message = "不能为空"
        )
        private Integer beginDate = 0;
        @NotNull(
                message = "不能为空"
        )
        private Integer endDate = 0;
        @SinogramLength(
                min = 0,
                max = 3,
                charset = "utf-8"
        )
        private String moneyType = " ";

        public GetElghisassetInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public Integer getBeginDate() {
            return this.beginDate != null ? this.beginDate : 0;
        }

        public Integer getEndDate() {
            return this.endDate != null ? this.endDate : 0;
        }

        public String getMoneyType() {
            if (this.moneyType == null) {
                return " ";
            } else {
                return this.moneyType.isEmpty() ? " " : this.moneyType;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setBeginDate(Integer beginDate) {
            this.beginDate = beginDate;
        }

        public void setEndDate(Integer endDate) {
            this.endDate = endDate;
        }

        public void setMoneyType(String moneyType) {
            this.moneyType = moneyType;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetElghisassetInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",beginDate:" + this.beginDate);
            buffer.append(",endDate:" + this.endDate);
            buffer.append(",moneyType:" + this.moneyType);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.clientId);
            builder.append(this.beginDate);
            builder.append(this.endDate);
            builder.append(this.moneyType);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerCqsService.GetElghisassetInnerInput) {
                InnerCqsService.GetElghisassetInnerInput test = (InnerCqsService.GetElghisassetInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.clientId, test.clientId);
                builder.append(this.beginDate, test.beginDate);
                builder.append(this.endDate, test.endDate);
                builder.append(this.moneyType, test.moneyType);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetElgclientpreferjourInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer initDate = 0;
        private Long serialNo = 0L;
        private Integer currDate = 0;
        private Integer currTime = 0;
        private Integer opBranchNo = 0;
        private String operatorNo = " ";
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer businessFlag = 0;
        private String clientId = " ";
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double assetBalance = 0.0D;
        private String enInvestTerm = " ";
        private String enInvestKind = " ";
        private String remark = " ";
        private String positionStr = " ";
        private Integer profBeginDate = 0;
        private Integer profEndDate = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character profType = ' ';
        private Integer pfRiskLevel = 0;
        private String enPfInvestKind = " ";
        private String enPfInvestTerm = " ";
        private Integer corpRiskLevel = 0;
        private Integer corpBeginDate = 0;
        private Integer corpEndDate = 0;
        @SerializeDoubleDigit(
                digit = 8
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double enMaxdeficitRate = 0.0D;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character organFlag = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character minRankFlag = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character clientIncomeType = ' ';
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double threeYearsAvgIncom = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double lastYearNetAsset = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double otherAsset = 0.0D;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character idKind = ' ';
        private String idNo = " ";
        private String fullName = " ";
        private String clientName = " ";
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double lastThreeMonthsAsset = 0.0D;
        private Integer proveLtmaEnddate = 0;
        private Integer proveAbEnddate = 0;
        private Integer proveLynaEnddate = 0;
        private Integer proveOaEnddate = 0;
        private Integer proveTyaiEnddate = 0;
        private Integer pfRiskBeginDate = 0;
        private Integer pfRiskEndDate = 0;
        private String custId = " ";

        public GetElgclientpreferjourInnerOutput() {
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public Long getSerialNo() {
            return this.serialNo != null ? this.serialNo : 0L;
        }

        public Integer getCurrDate() {
            return this.currDate != null ? this.currDate : 0;
        }

        public Integer getCurrTime() {
            return this.currTime != null ? this.currTime : 0;
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getBusinessFlag() {
            return this.businessFlag != null ? this.businessFlag : 0;
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public Double getAssetBalance() {
            return this.assetBalance != null ? this.assetBalance : 0.0D;
        }

        public String getEnInvestTerm() {
            if (this.enInvestTerm == null) {
                return " ";
            } else {
                return this.enInvestTerm.isEmpty() ? " " : this.enInvestTerm;
            }
        }

        public String getEnInvestKind() {
            if (this.enInvestKind == null) {
                return " ";
            } else {
                return this.enInvestKind.isEmpty() ? " " : this.enInvestKind;
            }
        }

        public String getRemark() {
            if (this.remark == null) {
                return " ";
            } else {
                return this.remark.isEmpty() ? " " : this.remark;
            }
        }

        public String getPositionStr() {
            if (this.positionStr == null) {
                return " ";
            } else {
                return this.positionStr.isEmpty() ? " " : this.positionStr;
            }
        }

        public Integer getProfBeginDate() {
            return this.profBeginDate != null ? this.profBeginDate : 0;
        }

        public Integer getProfEndDate() {
            return this.profEndDate != null ? this.profEndDate : 0;
        }

        public Character getProfType() {
            return this.profType != null ? this.profType : ' ';
        }

        public Integer getPfRiskLevel() {
            return this.pfRiskLevel != null ? this.pfRiskLevel : 0;
        }

        public String getEnPfInvestKind() {
            if (this.enPfInvestKind == null) {
                return " ";
            } else {
                return this.enPfInvestKind.isEmpty() ? " " : this.enPfInvestKind;
            }
        }

        public String getEnPfInvestTerm() {
            if (this.enPfInvestTerm == null) {
                return " ";
            } else {
                return this.enPfInvestTerm.isEmpty() ? " " : this.enPfInvestTerm;
            }
        }

        public Integer getCorpRiskLevel() {
            return this.corpRiskLevel != null ? this.corpRiskLevel : 0;
        }

        public Integer getCorpBeginDate() {
            return this.corpBeginDate != null ? this.corpBeginDate : 0;
        }

        public Integer getCorpEndDate() {
            return this.corpEndDate != null ? this.corpEndDate : 0;
        }

        public Double getEnMaxdeficitRate() {
            return this.enMaxdeficitRate != null ? this.enMaxdeficitRate : 0.0D;
        }

        public Character getOrganFlag() {
            return this.organFlag != null ? this.organFlag : ' ';
        }

        public Character getMinRankFlag() {
            return this.minRankFlag != null ? this.minRankFlag : ' ';
        }

        public Character getClientIncomeType() {
            return this.clientIncomeType != null ? this.clientIncomeType : ' ';
        }

        public Double getThreeYearsAvgIncom() {
            return this.threeYearsAvgIncom != null ? this.threeYearsAvgIncom : 0.0D;
        }

        public Double getLastYearNetAsset() {
            return this.lastYearNetAsset != null ? this.lastYearNetAsset : 0.0D;
        }

        public Double getOtherAsset() {
            return this.otherAsset != null ? this.otherAsset : 0.0D;
        }

        public Character getIdKind() {
            return this.idKind != null ? this.idKind : ' ';
        }

        public String getIdNo() {
            if (this.idNo == null) {
                return " ";
            } else {
                return this.idNo.isEmpty() ? " " : this.idNo;
            }
        }

        public String getFullName() {
            if (this.fullName == null) {
                return " ";
            } else {
                return this.fullName.isEmpty() ? " " : this.fullName;
            }
        }

        public String getClientName() {
            if (this.clientName == null) {
                return " ";
            } else {
                return this.clientName.isEmpty() ? " " : this.clientName;
            }
        }

        public Double getLastThreeMonthsAsset() {
            return this.lastThreeMonthsAsset != null ? this.lastThreeMonthsAsset : 0.0D;
        }

        public Integer getProveLtmaEnddate() {
            return this.proveLtmaEnddate != null ? this.proveLtmaEnddate : 0;
        }

        public Integer getProveAbEnddate() {
            return this.proveAbEnddate != null ? this.proveAbEnddate : 0;
        }

        public Integer getProveLynaEnddate() {
            return this.proveLynaEnddate != null ? this.proveLynaEnddate : 0;
        }

        public Integer getProveOaEnddate() {
            return this.proveOaEnddate != null ? this.proveOaEnddate : 0;
        }

        public Integer getProveTyaiEnddate() {
            return this.proveTyaiEnddate != null ? this.proveTyaiEnddate : 0;
        }

        public Integer getPfRiskBeginDate() {
            return this.pfRiskBeginDate != null ? this.pfRiskBeginDate : 0;
        }

        public Integer getPfRiskEndDate() {
            return this.pfRiskEndDate != null ? this.pfRiskEndDate : 0;
        }

        public String getCustId() {
            if (this.custId == null) {
                return " ";
            } else {
                return this.custId.isEmpty() ? " " : this.custId;
            }
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public void setSerialNo(Long serialNo) {
            this.serialNo = serialNo;
        }

        public void setCurrDate(Integer currDate) {
            this.currDate = currDate;
        }

        public void setCurrTime(Integer currTime) {
            this.currTime = currTime;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setBusinessFlag(Integer businessFlag) {
            this.businessFlag = businessFlag;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setAssetBalance(Double assetBalance) {
            this.assetBalance = assetBalance;
        }

        public void setEnInvestTerm(String enInvestTerm) {
            this.enInvestTerm = enInvestTerm;
        }

        public void setEnInvestKind(String enInvestKind) {
            this.enInvestKind = enInvestKind;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public void setPositionStr(String positionStr) {
            this.positionStr = positionStr;
        }

        public void setProfBeginDate(Integer profBeginDate) {
            this.profBeginDate = profBeginDate;
        }

        public void setProfEndDate(Integer profEndDate) {
            this.profEndDate = profEndDate;
        }

        public void setProfType(Character profType) {
            this.profType = profType;
        }

        public void setPfRiskLevel(Integer pfRiskLevel) {
            this.pfRiskLevel = pfRiskLevel;
        }

        public void setEnPfInvestKind(String enPfInvestKind) {
            this.enPfInvestKind = enPfInvestKind;
        }

        public void setEnPfInvestTerm(String enPfInvestTerm) {
            this.enPfInvestTerm = enPfInvestTerm;
        }

        public void setCorpRiskLevel(Integer corpRiskLevel) {
            this.corpRiskLevel = corpRiskLevel;
        }

        public void setCorpBeginDate(Integer corpBeginDate) {
            this.corpBeginDate = corpBeginDate;
        }

        public void setCorpEndDate(Integer corpEndDate) {
            this.corpEndDate = corpEndDate;
        }

        public void setEnMaxdeficitRate(Double enMaxdeficitRate) {
            this.enMaxdeficitRate = enMaxdeficitRate;
        }

        public void setOrganFlag(Character organFlag) {
            this.organFlag = organFlag;
        }

        public void setMinRankFlag(Character minRankFlag) {
            this.minRankFlag = minRankFlag;
        }

        public void setClientIncomeType(Character clientIncomeType) {
            this.clientIncomeType = clientIncomeType;
        }

        public void setThreeYearsAvgIncom(Double threeYearsAvgIncom) {
            this.threeYearsAvgIncom = threeYearsAvgIncom;
        }

        public void setLastYearNetAsset(Double lastYearNetAsset) {
            this.lastYearNetAsset = lastYearNetAsset;
        }

        public void setOtherAsset(Double otherAsset) {
            this.otherAsset = otherAsset;
        }

        public void setIdKind(Character idKind) {
            this.idKind = idKind;
        }

        public void setIdNo(String idNo) {
            this.idNo = idNo;
        }

        public void setFullName(String fullName) {
            this.fullName = fullName;
        }

        public void setClientName(String clientName) {
            this.clientName = clientName;
        }

        public void setLastThreeMonthsAsset(Double lastThreeMonthsAsset) {
            this.lastThreeMonthsAsset = lastThreeMonthsAsset;
        }

        public void setProveLtmaEnddate(Integer proveLtmaEnddate) {
            this.proveLtmaEnddate = proveLtmaEnddate;
        }

        public void setProveAbEnddate(Integer proveAbEnddate) {
            this.proveAbEnddate = proveAbEnddate;
        }

        public void setProveLynaEnddate(Integer proveLynaEnddate) {
            this.proveLynaEnddate = proveLynaEnddate;
        }

        public void setProveOaEnddate(Integer proveOaEnddate) {
            this.proveOaEnddate = proveOaEnddate;
        }

        public void setProveTyaiEnddate(Integer proveTyaiEnddate) {
            this.proveTyaiEnddate = proveTyaiEnddate;
        }

        public void setPfRiskBeginDate(Integer pfRiskBeginDate) {
            this.pfRiskBeginDate = pfRiskBeginDate;
        }

        public void setPfRiskEndDate(Integer pfRiskEndDate) {
            this.pfRiskEndDate = pfRiskEndDate;
        }

        public void setCustId(String custId) {
            this.custId = custId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetElgclientpreferjourInnerOutput:(");
            buffer.append("initDate:" + this.initDate);
            buffer.append(",serialNo:" + this.serialNo);
            buffer.append(",currDate:" + this.currDate);
            buffer.append(",currTime:" + this.currTime);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",businessFlag:" + this.businessFlag);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",assetBalance:" + this.assetBalance);
            buffer.append(",enInvestTerm:" + this.enInvestTerm);
            buffer.append(",enInvestKind:" + this.enInvestKind);
            buffer.append(",remark:" + this.remark);
            buffer.append(",positionStr:" + this.positionStr);
            buffer.append(",profBeginDate:" + this.profBeginDate);
            buffer.append(",profEndDate:" + this.profEndDate);
            buffer.append(",profType:" + this.profType);
            buffer.append(",pfRiskLevel:" + this.pfRiskLevel);
            buffer.append(",enPfInvestKind:" + this.enPfInvestKind);
            buffer.append(",enPfInvestTerm:" + this.enPfInvestTerm);
            buffer.append(",corpRiskLevel:" + this.corpRiskLevel);
            buffer.append(",corpBeginDate:" + this.corpBeginDate);
            buffer.append(",corpEndDate:" + this.corpEndDate);
            buffer.append(",enMaxdeficitRate:" + this.enMaxdeficitRate);
            buffer.append(",organFlag:" + this.organFlag);
            buffer.append(",minRankFlag:" + this.minRankFlag);
            buffer.append(",clientIncomeType:" + this.clientIncomeType);
            buffer.append(",threeYearsAvgIncom:" + this.threeYearsAvgIncom);
            buffer.append(",lastYearNetAsset:" + this.lastYearNetAsset);
            buffer.append(",otherAsset:" + this.otherAsset);
            buffer.append(",idKind:" + this.idKind);
            buffer.append(",idNo:" + this.idNo);
            buffer.append(",fullName:" + this.fullName);
            buffer.append(",clientName:" + this.clientName);
            buffer.append(",lastThreeMonthsAsset:" + this.lastThreeMonthsAsset);
            buffer.append(",proveLtmaEnddate:" + this.proveLtmaEnddate);
            buffer.append(",proveAbEnddate:" + this.proveAbEnddate);
            buffer.append(",proveLynaEnddate:" + this.proveLynaEnddate);
            buffer.append(",proveOaEnddate:" + this.proveOaEnddate);
            buffer.append(",proveTyaiEnddate:" + this.proveTyaiEnddate);
            buffer.append(",pfRiskBeginDate:" + this.pfRiskBeginDate);
            buffer.append(",pfRiskEndDate:" + this.pfRiskEndDate);
            buffer.append(",custId:" + this.custId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.initDate);
            builder.append(this.serialNo);
            builder.append(this.currDate);
            builder.append(this.currTime);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.businessFlag);
            builder.append(this.clientId);
            builder.append(this.assetBalance);
            builder.append(this.enInvestTerm);
            builder.append(this.enInvestKind);
            builder.append(this.remark);
            builder.append(this.positionStr);
            builder.append(this.profBeginDate);
            builder.append(this.profEndDate);
            builder.append(this.profType);
            builder.append(this.pfRiskLevel);
            builder.append(this.enPfInvestKind);
            builder.append(this.enPfInvestTerm);
            builder.append(this.corpRiskLevel);
            builder.append(this.corpBeginDate);
            builder.append(this.corpEndDate);
            builder.append(this.enMaxdeficitRate);
            builder.append(this.organFlag);
            builder.append(this.minRankFlag);
            builder.append(this.clientIncomeType);
            builder.append(this.threeYearsAvgIncom);
            builder.append(this.lastYearNetAsset);
            builder.append(this.otherAsset);
            builder.append(this.idKind);
            builder.append(this.idNo);
            builder.append(this.fullName);
            builder.append(this.clientName);
            builder.append(this.lastThreeMonthsAsset);
            builder.append(this.proveLtmaEnddate);
            builder.append(this.proveAbEnddate);
            builder.append(this.proveLynaEnddate);
            builder.append(this.proveOaEnddate);
            builder.append(this.proveTyaiEnddate);
            builder.append(this.pfRiskBeginDate);
            builder.append(this.pfRiskEndDate);
            builder.append(this.custId);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerCqsService.GetElgclientpreferjourInnerOutput) {
                InnerCqsService.GetElgclientpreferjourInnerOutput test = (InnerCqsService.GetElgclientpreferjourInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.initDate, test.initDate);
                builder.append(this.serialNo, test.serialNo);
                builder.append(this.currDate, test.currDate);
                builder.append(this.currTime, test.currTime);
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.businessFlag, test.businessFlag);
                builder.append(this.clientId, test.clientId);
                builder.append(this.assetBalance, test.assetBalance);
                builder.append(this.enInvestTerm, test.enInvestTerm);
                builder.append(this.enInvestKind, test.enInvestKind);
                builder.append(this.remark, test.remark);
                builder.append(this.positionStr, test.positionStr);
                builder.append(this.profBeginDate, test.profBeginDate);
                builder.append(this.profEndDate, test.profEndDate);
                builder.append(this.profType, test.profType);
                builder.append(this.pfRiskLevel, test.pfRiskLevel);
                builder.append(this.enPfInvestKind, test.enPfInvestKind);
                builder.append(this.enPfInvestTerm, test.enPfInvestTerm);
                builder.append(this.corpRiskLevel, test.corpRiskLevel);
                builder.append(this.corpBeginDate, test.corpBeginDate);
                builder.append(this.corpEndDate, test.corpEndDate);
                builder.append(this.enMaxdeficitRate, test.enMaxdeficitRate);
                builder.append(this.organFlag, test.organFlag);
                builder.append(this.minRankFlag, test.minRankFlag);
                builder.append(this.clientIncomeType, test.clientIncomeType);
                builder.append(this.threeYearsAvgIncom, test.threeYearsAvgIncom);
                builder.append(this.lastYearNetAsset, test.lastYearNetAsset);
                builder.append(this.otherAsset, test.otherAsset);
                builder.append(this.idKind, test.idKind);
                builder.append(this.idNo, test.idNo);
                builder.append(this.fullName, test.fullName);
                builder.append(this.clientName, test.clientName);
                builder.append(this.lastThreeMonthsAsset, test.lastThreeMonthsAsset);
                builder.append(this.proveLtmaEnddate, test.proveLtmaEnddate);
                builder.append(this.proveAbEnddate, test.proveAbEnddate);
                builder.append(this.proveLynaEnddate, test.proveLynaEnddate);
                builder.append(this.proveOaEnddate, test.proveOaEnddate);
                builder.append(this.proveTyaiEnddate, test.proveTyaiEnddate);
                builder.append(this.pfRiskBeginDate, test.pfRiskBeginDate);
                builder.append(this.pfRiskEndDate, test.pfRiskEndDate);
                builder.append(this.custId, test.custId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetElgclientpreferjourInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @NotNull(
                message = "不能为空"
        )
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 64,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String clientId = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character idKind = ' ';
        @SinogramLength(
                min = 0,
                max = 40,
                charset = "utf-8"
        )
        private String idNo = " ";
        @SinogramLength(
                min = 0,
                max = 180,
                charset = "utf-8"
        )
        private String fullName = " ";
        private Integer beginDate = 0;
        private Integer endDate = 0;

        public GetElgclientpreferjourInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public Character getIdKind() {
            return this.idKind != null ? this.idKind : ' ';
        }

        public String getIdNo() {
            if (this.idNo == null) {
                return " ";
            } else {
                return this.idNo.isEmpty() ? " " : this.idNo;
            }
        }

        public String getFullName() {
            if (this.fullName == null) {
                return " ";
            } else {
                return this.fullName.isEmpty() ? " " : this.fullName;
            }
        }

        public Integer getBeginDate() {
            return this.beginDate != null ? this.beginDate : 0;
        }

        public Integer getEndDate() {
            return this.endDate != null ? this.endDate : 0;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setIdKind(Character idKind) {
            this.idKind = idKind;
        }

        public void setIdNo(String idNo) {
            this.idNo = idNo;
        }

        public void setFullName(String fullName) {
            this.fullName = fullName;
        }

        public void setBeginDate(Integer beginDate) {
            this.beginDate = beginDate;
        }

        public void setEndDate(Integer endDate) {
            this.endDate = endDate;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetElgclientpreferjourInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",idKind:" + this.idKind);
            buffer.append(",idNo:" + this.idNo);
            buffer.append(",fullName:" + this.fullName);
            buffer.append(",beginDate:" + this.beginDate);
            buffer.append(",endDate:" + this.endDate);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.clientId);
            builder.append(this.idKind);
            builder.append(this.idNo);
            builder.append(this.fullName);
            builder.append(this.beginDate);
            builder.append(this.endDate);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerCqsService.GetElgclientpreferjourInnerInput) {
                InnerCqsService.GetElgclientpreferjourInnerInput test = (InnerCqsService.GetElgclientpreferjourInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.clientId, test.clientId);
                builder.append(this.idKind, test.idKind);
                builder.append(this.idNo, test.idNo);
                builder.append(this.fullName, test.fullName);
                builder.append(this.beginDate, test.beginDate);
                builder.append(this.endDate, test.endDate);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetElgbusinassetInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer initDate = 0;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double totalAsset = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double avgAsset20 = 0.0D;

        public GetElgbusinassetInnerOutput() {
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public Double getTotalAsset() {
            return this.totalAsset != null ? this.totalAsset : 0.0D;
        }

        public Double getAvgAsset20() {
            return this.avgAsset20 != null ? this.avgAsset20 : 0.0D;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public void setTotalAsset(Double totalAsset) {
            this.totalAsset = totalAsset;
        }

        public void setAvgAsset20(Double avgAsset20) {
            this.avgAsset20 = avgAsset20;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetElgbusinassetInnerOutput:(");
            buffer.append("initDate:" + this.initDate);
            buffer.append(",totalAsset:" + this.totalAsset);
            buffer.append(",avgAsset20:" + this.avgAsset20);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.initDate);
            builder.append(this.totalAsset);
            builder.append(this.avgAsset20);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerCqsService.GetElgbusinassetInnerOutput) {
                InnerCqsService.GetElgbusinassetInnerOutput test = (InnerCqsService.GetElgbusinassetInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.initDate, test.initDate);
                builder.append(this.totalAsset, test.totalAsset);
                builder.append(this.avgAsset20, test.avgAsset20);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetElgbusinassetInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @NotNull(
                message = "不能为空"
        )
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 64,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @NotNull(
                message = "不能为空"
        )
        private Integer initDate = 0;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId = " ";
        @SinogramLength(
                min = 1,
                max = 32,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String eligBusiKind = " ";

        public GetElgbusinassetInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getEligBusiKind() {
            if (this.eligBusiKind == null) {
                return " ";
            } else {
                return this.eligBusiKind.isEmpty() ? " " : this.eligBusiKind;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setEligBusiKind(String eligBusiKind) {
            this.eligBusiKind = eligBusiKind;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetElgbusinassetInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",initDate:" + this.initDate);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",eligBusiKind:" + this.eligBusiKind);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.initDate);
            builder.append(this.clientId);
            builder.append(this.eligBusiKind);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerCqsService.GetElgbusinassetInnerInput) {
                InnerCqsService.GetElgbusinassetInnerInput test = (InnerCqsService.GetElgbusinassetInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.initDate, test.initDate);
                builder.append(this.clientId, test.clientId);
                builder.append(this.eligBusiKind, test.eligBusiKind);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetCqssynctablestructureInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String originalTableName = " ";
        private String targetTableName = " ";
        private String systemCode = " ";
        private String columns = " ";
        private String uniqueIndex = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character shardingFlag = ' ';
        private Integer updateDate = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character offlineStatus = ' ';

        public GetCqssynctablestructureInnerOutput() {
        }

        public String getOriginalTableName() {
            if (this.originalTableName == null) {
                return " ";
            } else {
                return this.originalTableName.isEmpty() ? " " : this.originalTableName;
            }
        }

        public String getTargetTableName() {
            if (this.targetTableName == null) {
                return " ";
            } else {
                return this.targetTableName.isEmpty() ? " " : this.targetTableName;
            }
        }

        public String getSystemCode() {
            if (this.systemCode == null) {
                return " ";
            } else {
                return this.systemCode.isEmpty() ? " " : this.systemCode;
            }
        }

        public String getColumns() {
            if (this.columns == null) {
                return " ";
            } else {
                return this.columns.isEmpty() ? " " : this.columns;
            }
        }

        public String getUniqueIndex() {
            if (this.uniqueIndex == null) {
                return " ";
            } else {
                return this.uniqueIndex.isEmpty() ? " " : this.uniqueIndex;
            }
        }

        public Character getShardingFlag() {
            return this.shardingFlag != null ? this.shardingFlag : ' ';
        }

        public Integer getUpdateDate() {
            return this.updateDate != null ? this.updateDate : 0;
        }

        public Character getOfflineStatus() {
            return this.offlineStatus != null ? this.offlineStatus : ' ';
        }

        public void setOriginalTableName(String originalTableName) {
            this.originalTableName = originalTableName;
        }

        public void setTargetTableName(String targetTableName) {
            this.targetTableName = targetTableName;
        }

        public void setSystemCode(String systemCode) {
            this.systemCode = systemCode;
        }

        public void setColumns(String columns) {
            this.columns = columns;
        }

        public void setUniqueIndex(String uniqueIndex) {
            this.uniqueIndex = uniqueIndex;
        }

        public void setShardingFlag(Character shardingFlag) {
            this.shardingFlag = shardingFlag;
        }

        public void setUpdateDate(Integer updateDate) {
            this.updateDate = updateDate;
        }

        public void setOfflineStatus(Character offlineStatus) {
            this.offlineStatus = offlineStatus;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetCqssynctablestructureInnerOutput:(");
            buffer.append("originalTableName:" + this.originalTableName);
            buffer.append(",targetTableName:" + this.targetTableName);
            buffer.append(",systemCode:" + this.systemCode);
            buffer.append(",columns:" + this.columns);
            buffer.append(",uniqueIndex:" + this.uniqueIndex);
            buffer.append(",shardingFlag:" + this.shardingFlag);
            buffer.append(",updateDate:" + this.updateDate);
            buffer.append(",offlineStatus:" + this.offlineStatus);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.originalTableName);
            builder.append(this.targetTableName);
            builder.append(this.systemCode);
            builder.append(this.columns);
            builder.append(this.uniqueIndex);
            builder.append(this.shardingFlag);
            builder.append(this.updateDate);
            builder.append(this.offlineStatus);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerCqsService.GetCqssynctablestructureInnerOutput) {
                InnerCqsService.GetCqssynctablestructureInnerOutput test = (InnerCqsService.GetCqssynctablestructureInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.originalTableName, test.originalTableName);
                builder.append(this.targetTableName, test.targetTableName);
                builder.append(this.systemCode, test.systemCode);
                builder.append(this.columns, test.columns);
                builder.append(this.uniqueIndex, test.uniqueIndex);
                builder.append(this.shardingFlag, test.shardingFlag);
                builder.append(this.updateDate, test.updateDate);
                builder.append(this.offlineStatus, test.offlineStatus);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetCqssynctablestructureInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @NotNull(
                message = "不能为空"
        )
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 64,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String originalTableName = " ";

        public GetCqssynctablestructureInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getOriginalTableName() {
            if (this.originalTableName == null) {
                return " ";
            } else {
                return this.originalTableName.isEmpty() ? " " : this.originalTableName;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOriginalTableName(String originalTableName) {
            this.originalTableName = originalTableName;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetCqssynctablestructureInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",originalTableName:" + this.originalTableName);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.originalTableName);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerCqsService.GetCqssynctablestructureInnerInput) {
                InnerCqsService.GetCqssynctablestructureInnerInput test = (InnerCqsService.GetCqssynctablestructureInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.originalTableName, test.originalTableName);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetCqsstatementrecordsInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer currentPage = 0;
        private Integer total = 0;
        private List<InnerCqsService.StatementRecordsDTO> rows;

        public GetCqsstatementrecordsInnerOutput() {
        }

        public Integer getCurrentPage() {
            return this.currentPage != null ? this.currentPage : 0;
        }

        public Integer getTotal() {
            return this.total != null ? this.total : 0;
        }

        public List<InnerCqsService.StatementRecordsDTO> getRows() {
            return this.rows;
        }

        public void setCurrentPage(Integer currentPage) {
            this.currentPage = currentPage;
        }

        public void setTotal(Integer total) {
            this.total = total;
        }

        public void setRows(List<InnerCqsService.StatementRecordsDTO> rows) {
            this.rows = rows;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetCqsstatementrecordsInnerOutput:(");
            buffer.append("currentPage:" + this.currentPage);
            buffer.append(",total:" + this.total);
            buffer.append(",rows:" + this.rows);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.currentPage);
            builder.append(this.total);
            builder.append(this.rows);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerCqsService.GetCqsstatementrecordsInnerOutput) {
                InnerCqsService.GetCqsstatementrecordsInnerOutput test = (InnerCqsService.GetCqsstatementrecordsInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.currentPage, test.currentPage);
                builder.append(this.total, test.total);
                builder.append(this.rows, test.rows);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetCqsstatementrecordsInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @NotNull(
                message = "不能为空"
        )
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 64,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId = " ";
        private Integer pageNo = 0;
        private Integer pageSize = 0;

        public GetCqsstatementrecordsInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public Integer getPageNo() {
            return this.pageNo != null ? this.pageNo : 0;
        }

        public Integer getPageSize() {
            return this.pageSize != null ? this.pageSize : 0;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setPageNo(Integer pageNo) {
            this.pageNo = pageNo;
        }

        public void setPageSize(Integer pageSize) {
            this.pageSize = pageSize;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetCqsstatementrecordsInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",pageNo:" + this.pageNo);
            buffer.append(",pageSize:" + this.pageSize);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.clientId);
            builder.append(this.pageNo);
            builder.append(this.pageSize);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerCqsService.GetCqsstatementrecordsInnerInput) {
                InnerCqsService.GetCqsstatementrecordsInnerInput test = (InnerCqsService.GetCqsstatementrecordsInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.clientId, test.clientId);
                builder.append(this.pageNo, test.pageNo);
                builder.append(this.pageSize, test.pageSize);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetCmstwentyassetInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer branchNo = 0;
        private String clientId = " ";
        private String fundAccount = " ";
        private String clientName = " ";
        private Integer updateDate = 0;
        private Integer updateTime = 0;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double avgAsset3 = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double avgAsset10 = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double avgAsset20 = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double optOpenAsset20 = 0.0D;
        private Integer assetMeetCondtitonDays1 = 0;
        private Integer assetMeetConditionDays2 = 0;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double stibTotalAsset = 0.0D;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character lastDataFlag = ' ';
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double preTenMinAsset = 0.0D;
        private Integer riskLevel = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character incomeOver50Flag = ' ';
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double minAvgAsset20 = 0.0D;
        private Integer minAvgAsset20Date = 0;
        private String positionStr = " ";

        public GetCmstwentyassetInnerOutput() {
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getClientName() {
            if (this.clientName == null) {
                return " ";
            } else {
                return this.clientName.isEmpty() ? " " : this.clientName;
            }
        }

        public Integer getUpdateDate() {
            return this.updateDate != null ? this.updateDate : 0;
        }

        public Integer getUpdateTime() {
            return this.updateTime != null ? this.updateTime : 0;
        }

        public Double getAvgAsset3() {
            return this.avgAsset3 != null ? this.avgAsset3 : 0.0D;
        }

        public Double getAvgAsset10() {
            return this.avgAsset10 != null ? this.avgAsset10 : 0.0D;
        }

        public Double getAvgAsset20() {
            return this.avgAsset20 != null ? this.avgAsset20 : 0.0D;
        }

        public Double getOptOpenAsset20() {
            return this.optOpenAsset20 != null ? this.optOpenAsset20 : 0.0D;
        }

        public Integer getAssetMeetCondtitonDays1() {
            return this.assetMeetCondtitonDays1 != null ? this.assetMeetCondtitonDays1 : 0;
        }

        public Integer getAssetMeetConditionDays2() {
            return this.assetMeetConditionDays2 != null ? this.assetMeetConditionDays2 : 0;
        }

        public Double getStibTotalAsset() {
            return this.stibTotalAsset != null ? this.stibTotalAsset : 0.0D;
        }

        public Character getLastDataFlag() {
            return this.lastDataFlag != null ? this.lastDataFlag : ' ';
        }

        public Double getPreTenMinAsset() {
            return this.preTenMinAsset != null ? this.preTenMinAsset : 0.0D;
        }

        public Integer getRiskLevel() {
            return this.riskLevel != null ? this.riskLevel : 0;
        }

        public Character getIncomeOver50Flag() {
            return this.incomeOver50Flag != null ? this.incomeOver50Flag : ' ';
        }

        public Double getMinAvgAsset20() {
            return this.minAvgAsset20 != null ? this.minAvgAsset20 : 0.0D;
        }

        public Integer getMinAvgAsset20Date() {
            return this.minAvgAsset20Date != null ? this.minAvgAsset20Date : 0;
        }

        public String getPositionStr() {
            if (this.positionStr == null) {
                return " ";
            } else {
                return this.positionStr.isEmpty() ? " " : this.positionStr;
            }
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setClientName(String clientName) {
            this.clientName = clientName;
        }

        public void setUpdateDate(Integer updateDate) {
            this.updateDate = updateDate;
        }

        public void setUpdateTime(Integer updateTime) {
            this.updateTime = updateTime;
        }

        public void setAvgAsset3(Double avgAsset3) {
            this.avgAsset3 = avgAsset3;
        }

        public void setAvgAsset10(Double avgAsset10) {
            this.avgAsset10 = avgAsset10;
        }

        public void setAvgAsset20(Double avgAsset20) {
            this.avgAsset20 = avgAsset20;
        }

        public void setOptOpenAsset20(Double optOpenAsset20) {
            this.optOpenAsset20 = optOpenAsset20;
        }

        public void setAssetMeetCondtitonDays1(Integer assetMeetCondtitonDays1) {
            this.assetMeetCondtitonDays1 = assetMeetCondtitonDays1;
        }

        public void setAssetMeetConditionDays2(Integer assetMeetConditionDays2) {
            this.assetMeetConditionDays2 = assetMeetConditionDays2;
        }

        public void setStibTotalAsset(Double stibTotalAsset) {
            this.stibTotalAsset = stibTotalAsset;
        }

        public void setLastDataFlag(Character lastDataFlag) {
            this.lastDataFlag = lastDataFlag;
        }

        public void setPreTenMinAsset(Double preTenMinAsset) {
            this.preTenMinAsset = preTenMinAsset;
        }

        public void setRiskLevel(Integer riskLevel) {
            this.riskLevel = riskLevel;
        }

        public void setIncomeOver50Flag(Character incomeOver50Flag) {
            this.incomeOver50Flag = incomeOver50Flag;
        }

        public void setMinAvgAsset20(Double minAvgAsset20) {
            this.minAvgAsset20 = minAvgAsset20;
        }

        public void setMinAvgAsset20Date(Integer minAvgAsset20Date) {
            this.minAvgAsset20Date = minAvgAsset20Date;
        }

        public void setPositionStr(String positionStr) {
            this.positionStr = positionStr;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetCmstwentyassetInnerOutput:(");
            buffer.append("branchNo:" + this.branchNo);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",clientName:" + this.clientName);
            buffer.append(",updateDate:" + this.updateDate);
            buffer.append(",updateTime:" + this.updateTime);
            buffer.append(",avgAsset3:" + this.avgAsset3);
            buffer.append(",avgAsset10:" + this.avgAsset10);
            buffer.append(",avgAsset20:" + this.avgAsset20);
            buffer.append(",optOpenAsset20:" + this.optOpenAsset20);
            buffer.append(",assetMeetCondtitonDays1:" + this.assetMeetCondtitonDays1);
            buffer.append(",assetMeetConditionDays2:" + this.assetMeetConditionDays2);
            buffer.append(",stibTotalAsset:" + this.stibTotalAsset);
            buffer.append(",lastDataFlag:" + this.lastDataFlag);
            buffer.append(",preTenMinAsset:" + this.preTenMinAsset);
            buffer.append(",riskLevel:" + this.riskLevel);
            buffer.append(",incomeOver50Flag:" + this.incomeOver50Flag);
            buffer.append(",minAvgAsset20:" + this.minAvgAsset20);
            buffer.append(",minAvgAsset20Date:" + this.minAvgAsset20Date);
            buffer.append(",positionStr:" + this.positionStr);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.branchNo);
            builder.append(this.clientId);
            builder.append(this.fundAccount);
            builder.append(this.clientName);
            builder.append(this.updateDate);
            builder.append(this.updateTime);
            builder.append(this.avgAsset3);
            builder.append(this.avgAsset10);
            builder.append(this.avgAsset20);
            builder.append(this.optOpenAsset20);
            builder.append(this.assetMeetCondtitonDays1);
            builder.append(this.assetMeetConditionDays2);
            builder.append(this.stibTotalAsset);
            builder.append(this.lastDataFlag);
            builder.append(this.preTenMinAsset);
            builder.append(this.riskLevel);
            builder.append(this.incomeOver50Flag);
            builder.append(this.minAvgAsset20);
            builder.append(this.minAvgAsset20Date);
            builder.append(this.positionStr);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerCqsService.GetCmstwentyassetInnerOutput) {
                InnerCqsService.GetCmstwentyassetInnerOutput test = (InnerCqsService.GetCmstwentyassetInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.clientId, test.clientId);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.clientName, test.clientName);
                builder.append(this.updateDate, test.updateDate);
                builder.append(this.updateTime, test.updateTime);
                builder.append(this.avgAsset3, test.avgAsset3);
                builder.append(this.avgAsset10, test.avgAsset10);
                builder.append(this.avgAsset20, test.avgAsset20);
                builder.append(this.optOpenAsset20, test.optOpenAsset20);
                builder.append(this.assetMeetCondtitonDays1, test.assetMeetCondtitonDays1);
                builder.append(this.assetMeetConditionDays2, test.assetMeetConditionDays2);
                builder.append(this.stibTotalAsset, test.stibTotalAsset);
                builder.append(this.lastDataFlag, test.lastDataFlag);
                builder.append(this.preTenMinAsset, test.preTenMinAsset);
                builder.append(this.riskLevel, test.riskLevel);
                builder.append(this.incomeOver50Flag, test.incomeOver50Flag);
                builder.append(this.minAvgAsset20, test.minAvgAsset20);
                builder.append(this.minAvgAsset20Date, test.minAvgAsset20Date);
                builder.append(this.positionStr, test.positionStr);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetCmstwentyassetInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @NotNull(
                message = "不能为空"
        )
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 64,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @NotNull(
                message = "不能为空"
        )
        private Integer branchNo = 0;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId = " ";
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String fundAccount = " ";
        private Integer stageNum = 20;
        @SinogramLength(
                min = 0,
                max = 100,
                charset = "utf-8"
        )
        private String positionStr = " ";
        private Integer requestNum = 0;

        public GetCmstwentyassetInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public Integer getStageNum() {
            return this.stageNum != null ? this.stageNum : 20;
        }

        public String getPositionStr() {
            if (this.positionStr == null) {
                return " ";
            } else {
                return this.positionStr.isEmpty() ? " " : this.positionStr;
            }
        }

        public Integer getRequestNum() {
            return this.requestNum != null ? this.requestNum : 0;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setStageNum(Integer stageNum) {
            this.stageNum = stageNum;
        }

        public void setPositionStr(String positionStr) {
            this.positionStr = positionStr;
        }

        public void setRequestNum(Integer requestNum) {
            this.requestNum = requestNum;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetCmstwentyassetInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",stageNum:" + this.stageNum);
            buffer.append(",positionStr:" + this.positionStr);
            buffer.append(",requestNum:" + this.requestNum);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.branchNo);
            builder.append(this.clientId);
            builder.append(this.fundAccount);
            builder.append(this.stageNum);
            builder.append(this.positionStr);
            builder.append(this.requestNum);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerCqsService.GetCmstwentyassetInnerInput) {
                InnerCqsService.GetCmstwentyassetInnerInput test = (InnerCqsService.GetCmstwentyassetInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.clientId, test.clientId);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.stageNum, test.stageNum);
                builder.append(this.positionStr, test.positionStr);
                builder.append(this.requestNum, test.requestNum);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetAmsepapersignHisPageInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer total = 0;
        private List<InnerCqsService.AmsepapersignDTO> rows;

        public GetAmsepapersignHisPageInnerOutput() {
        }

        public Integer getTotal() {
            return this.total != null ? this.total : 0;
        }

        public List<InnerCqsService.AmsepapersignDTO> getRows() {
            return this.rows;
        }

        public void setTotal(Integer total) {
            this.total = total;
        }

        public void setRows(List<InnerCqsService.AmsepapersignDTO> rows) {
            this.rows = rows;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetAmsepapersignHisPageInnerOutput:(");
            buffer.append("total:" + this.total);
            buffer.append(",rows:" + this.rows);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.total);
            builder.append(this.rows);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerCqsService.GetAmsepapersignHisPageInnerOutput) {
                InnerCqsService.GetAmsepapersignHisPageInnerOutput test = (InnerCqsService.GetAmsepapersignHisPageInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.total, test.total);
                builder.append(this.rows, test.rows);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetAmsepapersignHisPageInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @NotNull(
                message = "不能为空"
        )
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 64,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer beginDate = 0;
        private Integer endDate = 0;
        private Integer pageNo = 0;
        private Integer pageSize = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String clientId = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String agreementId = " ";
        @SinogramLength(
                min = 0,
                max = 10,
                charset = "utf-8"
        )
        private String acptBusinId = " ";
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String acptBusinKind = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fundAccount = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String acptId = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorCode = " ";
        private Long templateId = 0L;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character caStatus = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character userType = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String menuCode = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String functionStr = " ";
        private Integer branchNo = 0;

        public GetAmsepapersignHisPageInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getBeginDate() {
            return this.beginDate != null ? this.beginDate : 0;
        }

        public Integer getEndDate() {
            return this.endDate != null ? this.endDate : 0;
        }

        public Integer getPageNo() {
            return this.pageNo != null ? this.pageNo : 0;
        }

        public Integer getPageSize() {
            return this.pageSize != null ? this.pageSize : 0;
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getAgreementId() {
            if (this.agreementId == null) {
                return " ";
            } else {
                return this.agreementId.isEmpty() ? " " : this.agreementId;
            }
        }

        public String getAcptBusinId() {
            if (this.acptBusinId == null) {
                return " ";
            } else {
                return this.acptBusinId.isEmpty() ? " " : this.acptBusinId;
            }
        }

        public String getAcptBusinKind() {
            if (this.acptBusinKind == null) {
                return " ";
            } else {
                return this.acptBusinKind.isEmpty() ? " " : this.acptBusinKind;
            }
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getAcptId() {
            if (this.acptId == null) {
                return " ";
            } else {
                return this.acptId.isEmpty() ? " " : this.acptId;
            }
        }

        public String getOperatorCode() {
            if (this.operatorCode == null) {
                return " ";
            } else {
                return this.operatorCode.isEmpty() ? " " : this.operatorCode;
            }
        }

        public Long getTemplateId() {
            return this.templateId != null ? this.templateId : 0L;
        }

        public Character getCaStatus() {
            return this.caStatus != null ? this.caStatus : ' ';
        }

        public Character getUserType() {
            return this.userType != null ? this.userType : ' ';
        }

        public String getMenuCode() {
            if (this.menuCode == null) {
                return " ";
            } else {
                return this.menuCode.isEmpty() ? " " : this.menuCode;
            }
        }

        public String getFunctionStr() {
            if (this.functionStr == null) {
                return " ";
            } else {
                return this.functionStr.isEmpty() ? " " : this.functionStr;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setBeginDate(Integer beginDate) {
            this.beginDate = beginDate;
        }

        public void setEndDate(Integer endDate) {
            this.endDate = endDate;
        }

        public void setPageNo(Integer pageNo) {
            this.pageNo = pageNo;
        }

        public void setPageSize(Integer pageSize) {
            this.pageSize = pageSize;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setAgreementId(String agreementId) {
            this.agreementId = agreementId;
        }

        public void setAcptBusinId(String acptBusinId) {
            this.acptBusinId = acptBusinId;
        }

        public void setAcptBusinKind(String acptBusinKind) {
            this.acptBusinKind = acptBusinKind;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setAcptId(String acptId) {
            this.acptId = acptId;
        }

        public void setOperatorCode(String operatorCode) {
            this.operatorCode = operatorCode;
        }

        public void setTemplateId(Long templateId) {
            this.templateId = templateId;
        }

        public void setCaStatus(Character caStatus) {
            this.caStatus = caStatus;
        }

        public void setUserType(Character userType) {
            this.userType = userType;
        }

        public void setMenuCode(String menuCode) {
            this.menuCode = menuCode;
        }

        public void setFunctionStr(String functionStr) {
            this.functionStr = functionStr;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetAmsepapersignHisPageInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",beginDate:" + this.beginDate);
            buffer.append(",endDate:" + this.endDate);
            buffer.append(",pageNo:" + this.pageNo);
            buffer.append(",pageSize:" + this.pageSize);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",agreementId:" + this.agreementId);
            buffer.append(",acptBusinId:" + this.acptBusinId);
            buffer.append(",acptBusinKind:" + this.acptBusinKind);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",acptId:" + this.acptId);
            buffer.append(",operatorCode:" + this.operatorCode);
            buffer.append(",templateId:" + this.templateId);
            buffer.append(",caStatus:" + this.caStatus);
            buffer.append(",userType:" + this.userType);
            buffer.append(",menuCode:" + this.menuCode);
            buffer.append(",functionStr:" + this.functionStr);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.beginDate);
            builder.append(this.endDate);
            builder.append(this.pageNo);
            builder.append(this.pageSize);
            builder.append(this.clientId);
            builder.append(this.agreementId);
            builder.append(this.acptBusinId);
            builder.append(this.acptBusinKind);
            builder.append(this.fundAccount);
            builder.append(this.acptId);
            builder.append(this.operatorCode);
            builder.append(this.templateId);
            builder.append(this.caStatus);
            builder.append(this.userType);
            builder.append(this.menuCode);
            builder.append(this.functionStr);
            builder.append(this.branchNo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerCqsService.GetAmsepapersignHisPageInnerInput) {
                InnerCqsService.GetAmsepapersignHisPageInnerInput test = (InnerCqsService.GetAmsepapersignHisPageInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.beginDate, test.beginDate);
                builder.append(this.endDate, test.endDate);
                builder.append(this.pageNo, test.pageNo);
                builder.append(this.pageSize, test.pageSize);
                builder.append(this.clientId, test.clientId);
                builder.append(this.agreementId, test.agreementId);
                builder.append(this.acptBusinId, test.acptBusinId);
                builder.append(this.acptBusinKind, test.acptBusinKind);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.acptId, test.acptId);
                builder.append(this.operatorCode, test.operatorCode);
                builder.append(this.templateId, test.templateId);
                builder.append(this.caStatus, test.caStatus);
                builder.append(this.userType, test.userType);
                builder.append(this.menuCode, test.menuCode);
                builder.append(this.functionStr, test.functionStr);
                builder.append(this.branchNo, test.branchNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetAmsagreesignHisPageInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer total = 0;
        private List<InnerCqsService.AmsagreesignDTO> rows;

        public GetAmsagreesignHisPageInnerOutput() {
        }

        public Integer getTotal() {
            return this.total != null ? this.total : 0;
        }

        public List<InnerCqsService.AmsagreesignDTO> getRows() {
            return this.rows;
        }

        public void setTotal(Integer total) {
            this.total = total;
        }

        public void setRows(List<InnerCqsService.AmsagreesignDTO> rows) {
            this.rows = rows;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetAmsagreesignHisPageInnerOutput:(");
            buffer.append("total:" + this.total);
            buffer.append(",rows:" + this.rows);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.total);
            builder.append(this.rows);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerCqsService.GetAmsagreesignHisPageInnerOutput) {
                InnerCqsService.GetAmsagreesignHisPageInnerOutput test = (InnerCqsService.GetAmsagreesignHisPageInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.total, test.total);
                builder.append(this.rows, test.rows);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetAmsagreesignHisPageInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @NotNull(
                message = "不能为空"
        )
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 64,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer beginDate = 0;
        private Integer endDate = 0;
        private Integer pageNo = 0;
        private Integer pageSize = 0;
        @SinogramLength(
                min = 0,
                max = 4000,
                charset = "utf-8"
        )
        private String enBranchNo = " ";
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String agreementBusinessType = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String clientId = " ";
        @SinogramLength(
                min = 0,
                max = 24,
                charset = "utf-8"
        )
        private String prodtaNo = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String prodCode = " ";
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String agreeType = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorCode = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String agreementId = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character caStatus = ' ';
        @SinogramLength(
                min = 0,
                max = 16,
                charset = "utf-8"
        )
        private String agreeModelNo = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fundAccount = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String acptId = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character userType = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String menuCode = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String functionStr = " ";
        private Integer branchNo = 0;

        public GetAmsagreesignHisPageInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getBeginDate() {
            return this.beginDate != null ? this.beginDate : 0;
        }

        public Integer getEndDate() {
            return this.endDate != null ? this.endDate : 0;
        }

        public Integer getPageNo() {
            return this.pageNo != null ? this.pageNo : 0;
        }

        public Integer getPageSize() {
            return this.pageSize != null ? this.pageSize : 0;
        }

        public String getEnBranchNo() {
            if (this.enBranchNo == null) {
                return " ";
            } else {
                return this.enBranchNo.isEmpty() ? " " : this.enBranchNo;
            }
        }

        public String getAgreementBusinessType() {
            if (this.agreementBusinessType == null) {
                return " ";
            } else {
                return this.agreementBusinessType.isEmpty() ? " " : this.agreementBusinessType;
            }
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getProdtaNo() {
            if (this.prodtaNo == null) {
                return " ";
            } else {
                return this.prodtaNo.isEmpty() ? " " : this.prodtaNo;
            }
        }

        public String getProdCode() {
            if (this.prodCode == null) {
                return " ";
            } else {
                return this.prodCode.isEmpty() ? " " : this.prodCode;
            }
        }

        public String getAgreeType() {
            if (this.agreeType == null) {
                return " ";
            } else {
                return this.agreeType.isEmpty() ? " " : this.agreeType;
            }
        }

        public String getOperatorCode() {
            if (this.operatorCode == null) {
                return " ";
            } else {
                return this.operatorCode.isEmpty() ? " " : this.operatorCode;
            }
        }

        public String getAgreementId() {
            if (this.agreementId == null) {
                return " ";
            } else {
                return this.agreementId.isEmpty() ? " " : this.agreementId;
            }
        }

        public Character getCaStatus() {
            return this.caStatus != null ? this.caStatus : ' ';
        }

        public String getAgreeModelNo() {
            if (this.agreeModelNo == null) {
                return " ";
            } else {
                return this.agreeModelNo.isEmpty() ? " " : this.agreeModelNo;
            }
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getAcptId() {
            if (this.acptId == null) {
                return " ";
            } else {
                return this.acptId.isEmpty() ? " " : this.acptId;
            }
        }

        public Character getUserType() {
            return this.userType != null ? this.userType : ' ';
        }

        public String getMenuCode() {
            if (this.menuCode == null) {
                return " ";
            } else {
                return this.menuCode.isEmpty() ? " " : this.menuCode;
            }
        }

        public String getFunctionStr() {
            if (this.functionStr == null) {
                return " ";
            } else {
                return this.functionStr.isEmpty() ? " " : this.functionStr;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setBeginDate(Integer beginDate) {
            this.beginDate = beginDate;
        }

        public void setEndDate(Integer endDate) {
            this.endDate = endDate;
        }

        public void setPageNo(Integer pageNo) {
            this.pageNo = pageNo;
        }

        public void setPageSize(Integer pageSize) {
            this.pageSize = pageSize;
        }

        public void setEnBranchNo(String enBranchNo) {
            this.enBranchNo = enBranchNo;
        }

        public void setAgreementBusinessType(String agreementBusinessType) {
            this.agreementBusinessType = agreementBusinessType;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setProdtaNo(String prodtaNo) {
            this.prodtaNo = prodtaNo;
        }

        public void setProdCode(String prodCode) {
            this.prodCode = prodCode;
        }

        public void setAgreeType(String agreeType) {
            this.agreeType = agreeType;
        }

        public void setOperatorCode(String operatorCode) {
            this.operatorCode = operatorCode;
        }

        public void setAgreementId(String agreementId) {
            this.agreementId = agreementId;
        }

        public void setCaStatus(Character caStatus) {
            this.caStatus = caStatus;
        }

        public void setAgreeModelNo(String agreeModelNo) {
            this.agreeModelNo = agreeModelNo;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setAcptId(String acptId) {
            this.acptId = acptId;
        }

        public void setUserType(Character userType) {
            this.userType = userType;
        }

        public void setMenuCode(String menuCode) {
            this.menuCode = menuCode;
        }

        public void setFunctionStr(String functionStr) {
            this.functionStr = functionStr;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetAmsagreesignHisPageInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",beginDate:" + this.beginDate);
            buffer.append(",endDate:" + this.endDate);
            buffer.append(",pageNo:" + this.pageNo);
            buffer.append(",pageSize:" + this.pageSize);
            buffer.append(",enBranchNo:" + this.enBranchNo);
            buffer.append(",agreementBusinessType:" + this.agreementBusinessType);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",prodtaNo:" + this.prodtaNo);
            buffer.append(",prodCode:" + this.prodCode);
            buffer.append(",agreeType:" + this.agreeType);
            buffer.append(",operatorCode:" + this.operatorCode);
            buffer.append(",agreementId:" + this.agreementId);
            buffer.append(",caStatus:" + this.caStatus);
            buffer.append(",agreeModelNo:" + this.agreeModelNo);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",acptId:" + this.acptId);
            buffer.append(",userType:" + this.userType);
            buffer.append(",menuCode:" + this.menuCode);
            buffer.append(",functionStr:" + this.functionStr);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.beginDate);
            builder.append(this.endDate);
            builder.append(this.pageNo);
            builder.append(this.pageSize);
            builder.append(this.enBranchNo);
            builder.append(this.agreementBusinessType);
            builder.append(this.clientId);
            builder.append(this.prodtaNo);
            builder.append(this.prodCode);
            builder.append(this.agreeType);
            builder.append(this.operatorCode);
            builder.append(this.agreementId);
            builder.append(this.caStatus);
            builder.append(this.agreeModelNo);
            builder.append(this.fundAccount);
            builder.append(this.acptId);
            builder.append(this.userType);
            builder.append(this.menuCode);
            builder.append(this.functionStr);
            builder.append(this.branchNo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerCqsService.GetAmsagreesignHisPageInnerInput) {
                InnerCqsService.GetAmsagreesignHisPageInnerInput test = (InnerCqsService.GetAmsagreesignHisPageInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.beginDate, test.beginDate);
                builder.append(this.endDate, test.endDate);
                builder.append(this.pageNo, test.pageNo);
                builder.append(this.pageSize, test.pageSize);
                builder.append(this.enBranchNo, test.enBranchNo);
                builder.append(this.agreementBusinessType, test.agreementBusinessType);
                builder.append(this.clientId, test.clientId);
                builder.append(this.prodtaNo, test.prodtaNo);
                builder.append(this.prodCode, test.prodCode);
                builder.append(this.agreeType, test.agreeType);
                builder.append(this.operatorCode, test.operatorCode);
                builder.append(this.agreementId, test.agreementId);
                builder.append(this.caStatus, test.caStatus);
                builder.append(this.agreeModelNo, test.agreeModelNo);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.acptId, test.acptId);
                builder.append(this.userType, test.userType);
                builder.append(this.menuCode, test.menuCode);
                builder.append(this.functionStr, test.functionStr);
                builder.append(this.branchNo, test.branchNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }
}
