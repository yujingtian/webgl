//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.hundsun.broker.opt.pub.service;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.hundsun.broker.base.PublicChecker.PublicParams;
import com.hundsun.broker.base.databind.CharacterJsonDeserializer;
import com.hundsun.jrescloud.rpc.annotation.CloudFunction;
import com.hundsun.jrescloud.rpc.annotation.CloudService;
import com.hundsun.jrescloud.rpc.def.json.DoubleJsonDeserializer;
import com.hundsun.jrescloud.rpc.def.json.LongJsonDeserializer;
import com.hundsun.jrescloud.rpc.def.json.LongJsonSerializer;
import com.hundsun.jrescloud.rpc.def.json.SerializeDoubleDigit;
import com.hundsun.jrescloud.rpc.def.validation.SinogramLength;
import java.io.Serializable;
import java.util.List;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

@CloudService(
        validation = true,
        validationNull = false,
        application = "hsbroker.opt"
)
public interface InnerOptService {

    @CloudFunction(
            value = "opt.deleteExchangeclientinfoCancelInner",
            apiUrl = "/deleteExchangeclientinfoCancelInner"
    )
    void deleteExchangeclientinfoCancelInner(InnerOptService.DeleteExchangeclientinfoCancelInnerInput var1);

    @CloudFunction(
            value = "opt.getExchangeclientinfoCancelCheckInner",
            apiUrl = "/getExchangeclientinfoCancelCheckInner"
    )
    List<InnerOptService.GetExchangeclientinfoCancelCheckInnerOutput> getExchangeclientinfoCancelCheckInner(InnerOptService.GetExchangeclientinfoCancelCheckInnerInput var1);

    @CloudFunction(
            value = "opt.getFare2QryInner",
            apiUrl = "/getFare2QryInner"
    )
    InnerOptService.GetFare2QryInnerOutput getFare2QryInner(InnerOptService.GetFare2QryInnerInput var1);


    public static class EntrustDTO implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer initDate = 0;
        private Integer currDate = 0;
        private Integer currTime = 0;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonSerialize(
                using = LongJsonSerializer.class
        )
        @JsonDeserialize(
                using = LongJsonDeserializer.class
        )
        private Long batchNo = 0L;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String clientId = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fundAccount = " ";
        @SinogramLength(
                min = 0,
                max = 3,
                charset = "utf-8"
        )
        private String moneyType = " ";
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String exchangeType = " ";
        @SinogramLength(
                min = 0,
                max = 20,
                charset = "utf-8"
        )
        private String stockAccount = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character optionType = ' ';
        @SinogramLength(
                min = 0,
                max = 8,
                charset = "utf-8"
        )
        private String optionCode = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String optcombId = " ";
        @SinogramLength(
                min = 0,
                max = 8,
                charset = "utf-8"
        )
        private String stockCode = " ";
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String stockType = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character entrustBs = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character entrustOc = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character coveredFlag = ' ';
        @Digits(
                integer = 13,
                fraction = 2,
                message = "entrustAmount value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double entrustAmount = 0.0D;
        @Digits(
                integer = 15,
                fraction = 8,
                message = "entrustPrice value out of bounds, integer=15, fraction=8"
        )
        @SerializeDoubleDigit(
                digit = 8
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double entrustPrice = 0.0D;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character entrustType = ' ';
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String entrustProp = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character entrustSrc = ' ';
        @Digits(
                integer = 13,
                fraction = 2,
                message = "businessAmount value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double businessAmount = 0.0D;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "withdrawAmount value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double withdrawAmount = 0.0D;
        @Digits(
                integer = 15,
                fraction = 8,
                message = "businessPrice value out of bounds, integer=15, fraction=8"
        )
        @SerializeDoubleDigit(
                digit = 8
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double businessPrice = 0.0D;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "businessBalance value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double businessBalance = 0.0D;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "clearBalance value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double clearBalance = 0.0D;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "prevBalance value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double prevBalance = 0.0D;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character entrustStatus = ' ';
        @SinogramLength(
                min = 0,
                max = 8,
                charset = "utf-8"
        )
        private String seatNo = " ";
        @JsonSerialize(
                using = LongJsonSerializer.class
        )
        @JsonDeserialize(
                using = LongJsonDeserializer.class
        )
        private Long entrustNo = 0L;
        @SinogramLength(
                min = 0,
                max = 24,
                charset = "utf-8"
        )
        private String orderId = " ";
        @SinogramLength(
                min = 0,
                max = 100,
                charset = "utf-8"
        )
        private String positionStr = " ";

        public EntrustDTO() {
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public Integer getCurrDate() {
            return this.currDate != null ? this.currDate : 0;
        }

        public Integer getCurrTime() {
            return this.currTime != null ? this.currTime : 0;
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Long getBatchNo() {
            return this.batchNo != null ? this.batchNo : 0L;
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getMoneyType() {
            if (this.moneyType == null) {
                return " ";
            } else {
                return this.moneyType.isEmpty() ? " " : this.moneyType;
            }
        }

        public String getExchangeType() {
            if (this.exchangeType == null) {
                return " ";
            } else {
                return this.exchangeType.isEmpty() ? " " : this.exchangeType;
            }
        }

        public String getStockAccount() {
            if (this.stockAccount == null) {
                return " ";
            } else {
                return this.stockAccount.isEmpty() ? " " : this.stockAccount;
            }
        }

        public Character getOptionType() {
            return this.optionType != null ? this.optionType : ' ';
        }

        public String getOptionCode() {
            if (this.optionCode == null) {
                return " ";
            } else {
                return this.optionCode.isEmpty() ? " " : this.optionCode;
            }
        }

        public String getOptcombId() {
            if (this.optcombId == null) {
                return " ";
            } else {
                return this.optcombId.isEmpty() ? " " : this.optcombId;
            }
        }

        public String getStockCode() {
            if (this.stockCode == null) {
                return " ";
            } else {
                return this.stockCode.isEmpty() ? " " : this.stockCode;
            }
        }

        public String getStockType() {
            if (this.stockType == null) {
                return " ";
            } else {
                return this.stockType.isEmpty() ? " " : this.stockType;
            }
        }

        public Character getEntrustBs() {
            return this.entrustBs != null ? this.entrustBs : ' ';
        }

        public Character getEntrustOc() {
            return this.entrustOc != null ? this.entrustOc : ' ';
        }

        public Character getCoveredFlag() {
            return this.coveredFlag != null ? this.coveredFlag : ' ';
        }

        public Double getEntrustAmount() {
            return this.entrustAmount != null ? this.entrustAmount : 0.0D;
        }

        public Double getEntrustPrice() {
            return this.entrustPrice != null ? this.entrustPrice : 0.0D;
        }

        public Character getEntrustType() {
            return this.entrustType != null ? this.entrustType : ' ';
        }

        public String getEntrustProp() {
            if (this.entrustProp == null) {
                return " ";
            } else {
                return this.entrustProp.isEmpty() ? " " : this.entrustProp;
            }
        }

        public Character getEntrustSrc() {
            return this.entrustSrc != null ? this.entrustSrc : ' ';
        }

        public Double getBusinessAmount() {
            return this.businessAmount != null ? this.businessAmount : 0.0D;
        }

        public Double getWithdrawAmount() {
            return this.withdrawAmount != null ? this.withdrawAmount : 0.0D;
        }

        public Double getBusinessPrice() {
            return this.businessPrice != null ? this.businessPrice : 0.0D;
        }

        public Double getBusinessBalance() {
            return this.businessBalance != null ? this.businessBalance : 0.0D;
        }

        public Double getClearBalance() {
            return this.clearBalance != null ? this.clearBalance : 0.0D;
        }

        public Double getPrevBalance() {
            return this.prevBalance != null ? this.prevBalance : 0.0D;
        }

        public Character getEntrustStatus() {
            return this.entrustStatus != null ? this.entrustStatus : ' ';
        }

        public String getSeatNo() {
            if (this.seatNo == null) {
                return " ";
            } else {
                return this.seatNo.isEmpty() ? " " : this.seatNo;
            }
        }

        public Long getEntrustNo() {
            return this.entrustNo != null ? this.entrustNo : 0L;
        }

        public String getOrderId() {
            if (this.orderId == null) {
                return " ";
            } else {
                return this.orderId.isEmpty() ? " " : this.orderId;
            }
        }

        public String getPositionStr() {
            if (this.positionStr == null) {
                return " ";
            } else {
                return this.positionStr.isEmpty() ? " " : this.positionStr;
            }
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public void setCurrDate(Integer currDate) {
            this.currDate = currDate;
        }

        public void setCurrTime(Integer currTime) {
            this.currTime = currTime;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setBatchNo(Long batchNo) {
            this.batchNo = batchNo;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setMoneyType(String moneyType) {
            this.moneyType = moneyType;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public void setStockAccount(String stockAccount) {
            this.stockAccount = stockAccount;
        }

        public void setOptionType(Character optionType) {
            this.optionType = optionType;
        }

        public void setOptionCode(String optionCode) {
            this.optionCode = optionCode;
        }

        public void setOptcombId(String optcombId) {
            this.optcombId = optcombId;
        }

        public void setStockCode(String stockCode) {
            this.stockCode = stockCode;
        }

        public void setStockType(String stockType) {
            this.stockType = stockType;
        }

        public void setEntrustBs(Character entrustBs) {
            this.entrustBs = entrustBs;
        }

        public void setEntrustOc(Character entrustOc) {
            this.entrustOc = entrustOc;
        }

        public void setCoveredFlag(Character coveredFlag) {
            this.coveredFlag = coveredFlag;
        }

        public void setEntrustAmount(Double entrustAmount) {
            this.entrustAmount = entrustAmount;
        }

        public void setEntrustPrice(Double entrustPrice) {
            this.entrustPrice = entrustPrice;
        }

        public void setEntrustType(Character entrustType) {
            this.entrustType = entrustType;
        }

        public void setEntrustProp(String entrustProp) {
            this.entrustProp = entrustProp;
        }

        public void setEntrustSrc(Character entrustSrc) {
            this.entrustSrc = entrustSrc;
        }

        public void setBusinessAmount(Double businessAmount) {
            this.businessAmount = businessAmount;
        }

        public void setWithdrawAmount(Double withdrawAmount) {
            this.withdrawAmount = withdrawAmount;
        }

        public void setBusinessPrice(Double businessPrice) {
            this.businessPrice = businessPrice;
        }

        public void setBusinessBalance(Double businessBalance) {
            this.businessBalance = businessBalance;
        }

        public void setClearBalance(Double clearBalance) {
            this.clearBalance = clearBalance;
        }

        public void setPrevBalance(Double prevBalance) {
            this.prevBalance = prevBalance;
        }

        public void setEntrustStatus(Character entrustStatus) {
            this.entrustStatus = entrustStatus;
        }

        public void setSeatNo(String seatNo) {
            this.seatNo = seatNo;
        }

        public void setEntrustNo(Long entrustNo) {
            this.entrustNo = entrustNo;
        }

        public void setOrderId(String orderId) {
            this.orderId = orderId;
        }

        public void setPositionStr(String positionStr) {
            this.positionStr = positionStr;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("EntrustDTO:(");
            buffer.append("initDate:" + this.initDate);
            buffer.append(",currDate:" + this.currDate);
            buffer.append(",currTime:" + this.currTime);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",batchNo:" + this.batchNo);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",moneyType:" + this.moneyType);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(",stockAccount:" + this.stockAccount);
            buffer.append(",optionType:" + this.optionType);
            buffer.append(",optionCode:" + this.optionCode);
            buffer.append(",optcombId:" + this.optcombId);
            buffer.append(",stockCode:" + this.stockCode);
            buffer.append(",stockType:" + this.stockType);
            buffer.append(",entrustBs:" + this.entrustBs);
            buffer.append(",entrustOc:" + this.entrustOc);
            buffer.append(",coveredFlag:" + this.coveredFlag);
            buffer.append(",entrustAmount:" + this.entrustAmount);
            buffer.append(",entrustPrice:" + this.entrustPrice);
            buffer.append(",entrustType:" + this.entrustType);
            buffer.append(",entrustProp:" + this.entrustProp);
            buffer.append(",entrustSrc:" + this.entrustSrc);
            buffer.append(",businessAmount:" + this.businessAmount);
            buffer.append(",withdrawAmount:" + this.withdrawAmount);
            buffer.append(",businessPrice:" + this.businessPrice);
            buffer.append(",businessBalance:" + this.businessBalance);
            buffer.append(",clearBalance:" + this.clearBalance);
            buffer.append(",prevBalance:" + this.prevBalance);
            buffer.append(",entrustStatus:" + this.entrustStatus);
            buffer.append(",seatNo:" + this.seatNo);
            buffer.append(",entrustNo:" + this.entrustNo);
            buffer.append(",orderId:" + this.orderId);
            buffer.append(",positionStr:" + this.positionStr);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.initDate);
            builder.append(this.currDate);
            builder.append(this.currTime);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opEntrustWay);
            builder.append(this.opStation);
            builder.append(this.batchNo);
            builder.append(this.clientId);
            builder.append(this.fundAccount);
            builder.append(this.moneyType);
            builder.append(this.exchangeType);
            builder.append(this.stockAccount);
            builder.append(this.optionType);
            builder.append(this.optionCode);
            builder.append(this.optcombId);
            builder.append(this.stockCode);
            builder.append(this.stockType);
            builder.append(this.entrustBs);
            builder.append(this.entrustOc);
            builder.append(this.coveredFlag);
            builder.append(this.entrustAmount);
            builder.append(this.entrustPrice);
            builder.append(this.entrustType);
            builder.append(this.entrustProp);
            builder.append(this.entrustSrc);
            builder.append(this.businessAmount);
            builder.append(this.withdrawAmount);
            builder.append(this.businessPrice);
            builder.append(this.businessBalance);
            builder.append(this.clearBalance);
            builder.append(this.prevBalance);
            builder.append(this.entrustStatus);
            builder.append(this.seatNo);
            builder.append(this.entrustNo);
            builder.append(this.orderId);
            builder.append(this.positionStr);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.EntrustDTO obj) {
            if (obj instanceof InnerOptService.EntrustDTO) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.initDate, obj.initDate);
                builder.append(this.currDate, obj.currDate);
                builder.append(this.currTime, obj.currTime);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.batchNo, obj.batchNo);
                builder.append(this.clientId, obj.clientId);
                builder.append(this.fundAccount, obj.fundAccount);
                builder.append(this.moneyType, obj.moneyType);
                builder.append(this.exchangeType, obj.exchangeType);
                builder.append(this.stockAccount, obj.stockAccount);
                builder.append(this.optionType, obj.optionType);
                builder.append(this.optionCode, obj.optionCode);
                builder.append(this.optcombId, obj.optcombId);
                builder.append(this.stockCode, obj.stockCode);
                builder.append(this.stockType, obj.stockType);
                builder.append(this.entrustBs, obj.entrustBs);
                builder.append(this.entrustOc, obj.entrustOc);
                builder.append(this.coveredFlag, obj.coveredFlag);
                builder.append(this.entrustAmount, obj.entrustAmount);
                builder.append(this.entrustPrice, obj.entrustPrice);
                builder.append(this.entrustType, obj.entrustType);
                builder.append(this.entrustProp, obj.entrustProp);
                builder.append(this.entrustSrc, obj.entrustSrc);
                builder.append(this.businessAmount, obj.businessAmount);
                builder.append(this.withdrawAmount, obj.withdrawAmount);
                builder.append(this.businessPrice, obj.businessPrice);
                builder.append(this.businessBalance, obj.businessBalance);
                builder.append(this.clearBalance, obj.clearBalance);
                builder.append(this.prevBalance, obj.prevBalance);
                builder.append(this.entrustStatus, obj.entrustStatus);
                builder.append(this.seatNo, obj.seatNo);
                builder.append(this.entrustNo, obj.entrustNo);
                builder.append(this.orderId, obj.orderId);
                builder.append(this.positionStr, obj.positionStr);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class HoldrealDTO implements Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String clientId = " ";
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String exchangeType = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fundAccount = " ";
        @SinogramLength(
                min = 0,
                max = 20,
                charset = "utf-8"
        )
        private String stockAccount = " ";
        @SinogramLength(
                min = 0,
                max = 8,
                charset = "utf-8"
        )
        private String seatNo = " ";
        @SinogramLength(
                min = 0,
                max = 8,
                charset = "utf-8"
        )
        private String optionCode = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character optionType = ' ';
        @SinogramLength(
                min = 0,
                max = 8,
                charset = "utf-8"
        )
        private String stockCode = " ";
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String stockType = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character optholdType = ' ';
        @Digits(
                integer = 13,
                fraction = 2,
                message = "currentAmount value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double currentAmount = 0.0D;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "uncomeOpenAmount value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double uncomeOpenAmount = 0.0D;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "uncomeDropAmount value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double uncomeDropAmount = 0.0D;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "frozenAmount value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double frozenAmount = 0.0D;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "unfrozenAmount value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double unfrozenAmount = 0.0D;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "optcombUsedAmount value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double optcombUsedAmount = 0.0D;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "enableAmount value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double enableAmount = 0.0D;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "realOpenAmount value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double realOpenAmount = 0.0D;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "realDropAmount value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double realDropAmount = 0.0D;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "realBuyBalance value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double realBuyBalance = 0.0D;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "realSellBalance value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double realSellBalance = 0.0D;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "entrustDropAmount value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double entrustDropAmount = 0.0D;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "sumOpenAmount value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double sumOpenAmount = 0.0D;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "sumDropAmount value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double sumDropAmount = 0.0D;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "sumBuyBalance value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double sumBuyBalance = 0.0D;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "sumSellBalance value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double sumSellBalance = 0.0D;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "usedPurQuota value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double usedPurQuota = 0.0D;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "uncomePurQuota value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double uncomePurQuota = 0.0D;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "hedgeAmount value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double hedgeAmount = 0.0D;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "dutyUsedBail value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double dutyUsedBail = 0.0D;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "todayCurrentAmount value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double todayCurrentAmount = 0.0D;
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String optionName = " ";

        public HoldrealDTO() {
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getExchangeType() {
            if (this.exchangeType == null) {
                return " ";
            } else {
                return this.exchangeType.isEmpty() ? " " : this.exchangeType;
            }
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getStockAccount() {
            if (this.stockAccount == null) {
                return " ";
            } else {
                return this.stockAccount.isEmpty() ? " " : this.stockAccount;
            }
        }

        public String getSeatNo() {
            if (this.seatNo == null) {
                return " ";
            } else {
                return this.seatNo.isEmpty() ? " " : this.seatNo;
            }
        }

        public String getOptionCode() {
            if (this.optionCode == null) {
                return " ";
            } else {
                return this.optionCode.isEmpty() ? " " : this.optionCode;
            }
        }

        public Character getOptionType() {
            return this.optionType != null ? this.optionType : ' ';
        }

        public String getStockCode() {
            if (this.stockCode == null) {
                return " ";
            } else {
                return this.stockCode.isEmpty() ? " " : this.stockCode;
            }
        }

        public String getStockType() {
            if (this.stockType == null) {
                return " ";
            } else {
                return this.stockType.isEmpty() ? " " : this.stockType;
            }
        }

        public Character getOptholdType() {
            return this.optholdType != null ? this.optholdType : ' ';
        }

        public Double getCurrentAmount() {
            return this.currentAmount != null ? this.currentAmount : 0.0D;
        }

        public Double getUncomeOpenAmount() {
            return this.uncomeOpenAmount != null ? this.uncomeOpenAmount : 0.0D;
        }

        public Double getUncomeDropAmount() {
            return this.uncomeDropAmount != null ? this.uncomeDropAmount : 0.0D;
        }

        public Double getFrozenAmount() {
            return this.frozenAmount != null ? this.frozenAmount : 0.0D;
        }

        public Double getUnfrozenAmount() {
            return this.unfrozenAmount != null ? this.unfrozenAmount : 0.0D;
        }

        public Double getOptcombUsedAmount() {
            return this.optcombUsedAmount != null ? this.optcombUsedAmount : 0.0D;
        }

        public Double getEnableAmount() {
            return this.enableAmount != null ? this.enableAmount : 0.0D;
        }

        public Double getRealOpenAmount() {
            return this.realOpenAmount != null ? this.realOpenAmount : 0.0D;
        }

        public Double getRealDropAmount() {
            return this.realDropAmount != null ? this.realDropAmount : 0.0D;
        }

        public Double getRealBuyBalance() {
            return this.realBuyBalance != null ? this.realBuyBalance : 0.0D;
        }

        public Double getRealSellBalance() {
            return this.realSellBalance != null ? this.realSellBalance : 0.0D;
        }

        public Double getEntrustDropAmount() {
            return this.entrustDropAmount != null ? this.entrustDropAmount : 0.0D;
        }

        public Double getSumOpenAmount() {
            return this.sumOpenAmount != null ? this.sumOpenAmount : 0.0D;
        }

        public Double getSumDropAmount() {
            return this.sumDropAmount != null ? this.sumDropAmount : 0.0D;
        }

        public Double getSumBuyBalance() {
            return this.sumBuyBalance != null ? this.sumBuyBalance : 0.0D;
        }

        public Double getSumSellBalance() {
            return this.sumSellBalance != null ? this.sumSellBalance : 0.0D;
        }

        public Double getUsedPurQuota() {
            return this.usedPurQuota != null ? this.usedPurQuota : 0.0D;
        }

        public Double getUncomePurQuota() {
            return this.uncomePurQuota != null ? this.uncomePurQuota : 0.0D;
        }

        public Double getHedgeAmount() {
            return this.hedgeAmount != null ? this.hedgeAmount : 0.0D;
        }

        public Double getDutyUsedBail() {
            return this.dutyUsedBail != null ? this.dutyUsedBail : 0.0D;
        }

        public Double getTodayCurrentAmount() {
            return this.todayCurrentAmount != null ? this.todayCurrentAmount : 0.0D;
        }

        public String getOptionName() {
            if (this.optionName == null) {
                return " ";
            } else {
                return this.optionName.isEmpty() ? " " : this.optionName;
            }
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setStockAccount(String stockAccount) {
            this.stockAccount = stockAccount;
        }

        public void setSeatNo(String seatNo) {
            this.seatNo = seatNo;
        }

        public void setOptionCode(String optionCode) {
            this.optionCode = optionCode;
        }

        public void setOptionType(Character optionType) {
            this.optionType = optionType;
        }

        public void setStockCode(String stockCode) {
            this.stockCode = stockCode;
        }

        public void setStockType(String stockType) {
            this.stockType = stockType;
        }

        public void setOptholdType(Character optholdType) {
            this.optholdType = optholdType;
        }

        public void setCurrentAmount(Double currentAmount) {
            this.currentAmount = currentAmount;
        }

        public void setUncomeOpenAmount(Double uncomeOpenAmount) {
            this.uncomeOpenAmount = uncomeOpenAmount;
        }

        public void setUncomeDropAmount(Double uncomeDropAmount) {
            this.uncomeDropAmount = uncomeDropAmount;
        }

        public void setFrozenAmount(Double frozenAmount) {
            this.frozenAmount = frozenAmount;
        }

        public void setUnfrozenAmount(Double unfrozenAmount) {
            this.unfrozenAmount = unfrozenAmount;
        }

        public void setOptcombUsedAmount(Double optcombUsedAmount) {
            this.optcombUsedAmount = optcombUsedAmount;
        }

        public void setEnableAmount(Double enableAmount) {
            this.enableAmount = enableAmount;
        }

        public void setRealOpenAmount(Double realOpenAmount) {
            this.realOpenAmount = realOpenAmount;
        }

        public void setRealDropAmount(Double realDropAmount) {
            this.realDropAmount = realDropAmount;
        }

        public void setRealBuyBalance(Double realBuyBalance) {
            this.realBuyBalance = realBuyBalance;
        }

        public void setRealSellBalance(Double realSellBalance) {
            this.realSellBalance = realSellBalance;
        }

        public void setEntrustDropAmount(Double entrustDropAmount) {
            this.entrustDropAmount = entrustDropAmount;
        }

        public void setSumOpenAmount(Double sumOpenAmount) {
            this.sumOpenAmount = sumOpenAmount;
        }

        public void setSumDropAmount(Double sumDropAmount) {
            this.sumDropAmount = sumDropAmount;
        }

        public void setSumBuyBalance(Double sumBuyBalance) {
            this.sumBuyBalance = sumBuyBalance;
        }

        public void setSumSellBalance(Double sumSellBalance) {
            this.sumSellBalance = sumSellBalance;
        }

        public void setUsedPurQuota(Double usedPurQuota) {
            this.usedPurQuota = usedPurQuota;
        }

        public void setUncomePurQuota(Double uncomePurQuota) {
            this.uncomePurQuota = uncomePurQuota;
        }

        public void setHedgeAmount(Double hedgeAmount) {
            this.hedgeAmount = hedgeAmount;
        }

        public void setDutyUsedBail(Double dutyUsedBail) {
            this.dutyUsedBail = dutyUsedBail;
        }

        public void setTodayCurrentAmount(Double todayCurrentAmount) {
            this.todayCurrentAmount = todayCurrentAmount;
        }

        public void setOptionName(String optionName) {
            this.optionName = optionName;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("HoldrealDTO:(");
            buffer.append("clientId:" + this.clientId);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",stockAccount:" + this.stockAccount);
            buffer.append(",seatNo:" + this.seatNo);
            buffer.append(",optionCode:" + this.optionCode);
            buffer.append(",optionType:" + this.optionType);
            buffer.append(",stockCode:" + this.stockCode);
            buffer.append(",stockType:" + this.stockType);
            buffer.append(",optholdType:" + this.optholdType);
            buffer.append(",currentAmount:" + this.currentAmount);
            buffer.append(",uncomeOpenAmount:" + this.uncomeOpenAmount);
            buffer.append(",uncomeDropAmount:" + this.uncomeDropAmount);
            buffer.append(",frozenAmount:" + this.frozenAmount);
            buffer.append(",unfrozenAmount:" + this.unfrozenAmount);
            buffer.append(",optcombUsedAmount:" + this.optcombUsedAmount);
            buffer.append(",enableAmount:" + this.enableAmount);
            buffer.append(",realOpenAmount:" + this.realOpenAmount);
            buffer.append(",realDropAmount:" + this.realDropAmount);
            buffer.append(",realBuyBalance:" + this.realBuyBalance);
            buffer.append(",realSellBalance:" + this.realSellBalance);
            buffer.append(",entrustDropAmount:" + this.entrustDropAmount);
            buffer.append(",sumOpenAmount:" + this.sumOpenAmount);
            buffer.append(",sumDropAmount:" + this.sumDropAmount);
            buffer.append(",sumBuyBalance:" + this.sumBuyBalance);
            buffer.append(",sumSellBalance:" + this.sumSellBalance);
            buffer.append(",usedPurQuota:" + this.usedPurQuota);
            buffer.append(",uncomePurQuota:" + this.uncomePurQuota);
            buffer.append(",hedgeAmount:" + this.hedgeAmount);
            buffer.append(",dutyUsedBail:" + this.dutyUsedBail);
            buffer.append(",todayCurrentAmount:" + this.todayCurrentAmount);
            buffer.append(",optionName:" + this.optionName);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.clientId);
            builder.append(this.exchangeType);
            builder.append(this.fundAccount);
            builder.append(this.stockAccount);
            builder.append(this.seatNo);
            builder.append(this.optionCode);
            builder.append(this.optionType);
            builder.append(this.stockCode);
            builder.append(this.stockType);
            builder.append(this.optholdType);
            builder.append(this.currentAmount);
            builder.append(this.uncomeOpenAmount);
            builder.append(this.uncomeDropAmount);
            builder.append(this.frozenAmount);
            builder.append(this.unfrozenAmount);
            builder.append(this.optcombUsedAmount);
            builder.append(this.enableAmount);
            builder.append(this.realOpenAmount);
            builder.append(this.realDropAmount);
            builder.append(this.realBuyBalance);
            builder.append(this.realSellBalance);
            builder.append(this.entrustDropAmount);
            builder.append(this.sumOpenAmount);
            builder.append(this.sumDropAmount);
            builder.append(this.sumBuyBalance);
            builder.append(this.sumSellBalance);
            builder.append(this.usedPurQuota);
            builder.append(this.uncomePurQuota);
            builder.append(this.hedgeAmount);
            builder.append(this.dutyUsedBail);
            builder.append(this.todayCurrentAmount);
            builder.append(this.optionName);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.HoldrealDTO obj) {
            if (obj instanceof InnerOptService.HoldrealDTO) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.clientId, obj.clientId);
                builder.append(this.exchangeType, obj.exchangeType);
                builder.append(this.fundAccount, obj.fundAccount);
                builder.append(this.stockAccount, obj.stockAccount);
                builder.append(this.seatNo, obj.seatNo);
                builder.append(this.optionCode, obj.optionCode);
                builder.append(this.optionType, obj.optionType);
                builder.append(this.stockCode, obj.stockCode);
                builder.append(this.stockType, obj.stockType);
                builder.append(this.optholdType, obj.optholdType);
                builder.append(this.currentAmount, obj.currentAmount);
                builder.append(this.uncomeOpenAmount, obj.uncomeOpenAmount);
                builder.append(this.uncomeDropAmount, obj.uncomeDropAmount);
                builder.append(this.frozenAmount, obj.frozenAmount);
                builder.append(this.unfrozenAmount, obj.unfrozenAmount);
                builder.append(this.optcombUsedAmount, obj.optcombUsedAmount);
                builder.append(this.enableAmount, obj.enableAmount);
                builder.append(this.realOpenAmount, obj.realOpenAmount);
                builder.append(this.realDropAmount, obj.realDropAmount);
                builder.append(this.realBuyBalance, obj.realBuyBalance);
                builder.append(this.realSellBalance, obj.realSellBalance);
                builder.append(this.entrustDropAmount, obj.entrustDropAmount);
                builder.append(this.sumOpenAmount, obj.sumOpenAmount);
                builder.append(this.sumDropAmount, obj.sumDropAmount);
                builder.append(this.sumBuyBalance, obj.sumBuyBalance);
                builder.append(this.sumSellBalance, obj.sumSellBalance);
                builder.append(this.usedPurQuota, obj.usedPurQuota);
                builder.append(this.uncomePurQuota, obj.uncomePurQuota);
                builder.append(this.hedgeAmount, obj.hedgeAmount);
                builder.append(this.dutyUsedBail, obj.dutyUsedBail);
                builder.append(this.todayCurrentAmount, obj.todayCurrentAmount);
                builder.append(this.optionName, obj.optionName);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class Fare2DTO implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer optfareKind = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character fareType = ' ';
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String exchangeType = " ";
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String stockType = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character entrustBs = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character entrustOc = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character entrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 3,
                charset = "utf-8"
        )
        private String moneyType = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character entrustType = ' ';
        private Integer updateDate = 0;
        private Integer updateTime = 0;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "perFare value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double perFare = 0.0D;
        @Digits(
                integer = 1,
                fraction = 13,
                message = "parRatio value out of bounds, integer=1, fraction=13"
        )
        @SerializeDoubleDigit(
                digit = 13
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double parRatio = 0.0D;
        @Digits(
                integer = 1,
                fraction = 13,
                message = "balanceRatio value out of bounds, integer=1, fraction=13"
        )
        @SerializeDoubleDigit(
                digit = 13
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double balanceRatio = 0.0D;

        public Fare2DTO() {
        }

        public Integer getOptfareKind() {
            return this.optfareKind != null ? this.optfareKind : 0;
        }

        public Character getFareType() {
            return this.fareType != null ? this.fareType : ' ';
        }

        public String getExchangeType() {
            if (this.exchangeType == null) {
                return " ";
            } else {
                return this.exchangeType.isEmpty() ? " " : this.exchangeType;
            }
        }

        public String getStockType() {
            if (this.stockType == null) {
                return " ";
            } else {
                return this.stockType.isEmpty() ? " " : this.stockType;
            }
        }

        public Character getEntrustBs() {
            return this.entrustBs != null ? this.entrustBs : ' ';
        }

        public Character getEntrustOc() {
            return this.entrustOc != null ? this.entrustOc : ' ';
        }

        public Character getEntrustWay() {
            return this.entrustWay != null ? this.entrustWay : ' ';
        }

        public String getMoneyType() {
            if (this.moneyType == null) {
                return " ";
            } else {
                return this.moneyType.isEmpty() ? " " : this.moneyType;
            }
        }

        public Character getEntrustType() {
            return this.entrustType != null ? this.entrustType : ' ';
        }

        public Integer getUpdateDate() {
            return this.updateDate != null ? this.updateDate : 0;
        }

        public Integer getUpdateTime() {
            return this.updateTime != null ? this.updateTime : 0;
        }

        public Double getPerFare() {
            return this.perFare != null ? this.perFare : 0.0D;
        }

        public Double getParRatio() {
            return this.parRatio != null ? this.parRatio : 0.0D;
        }

        public Double getBalanceRatio() {
            return this.balanceRatio != null ? this.balanceRatio : 0.0D;
        }

        public void setOptfareKind(Integer optfareKind) {
            this.optfareKind = optfareKind;
        }

        public void setFareType(Character fareType) {
            this.fareType = fareType;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public void setStockType(String stockType) {
            this.stockType = stockType;
        }

        public void setEntrustBs(Character entrustBs) {
            this.entrustBs = entrustBs;
        }

        public void setEntrustOc(Character entrustOc) {
            this.entrustOc = entrustOc;
        }

        public void setEntrustWay(Character entrustWay) {
            this.entrustWay = entrustWay;
        }

        public void setMoneyType(String moneyType) {
            this.moneyType = moneyType;
        }

        public void setEntrustType(Character entrustType) {
            this.entrustType = entrustType;
        }

        public void setUpdateDate(Integer updateDate) {
            this.updateDate = updateDate;
        }

        public void setUpdateTime(Integer updateTime) {
            this.updateTime = updateTime;
        }

        public void setPerFare(Double perFare) {
            this.perFare = perFare;
        }

        public void setParRatio(Double parRatio) {
            this.parRatio = parRatio;
        }

        public void setBalanceRatio(Double balanceRatio) {
            this.balanceRatio = balanceRatio;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("Fare2DTO:(");
            buffer.append("optfareKind:" + this.optfareKind);
            buffer.append(",fareType:" + this.fareType);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(",stockType:" + this.stockType);
            buffer.append(",entrustBs:" + this.entrustBs);
            buffer.append(",entrustOc:" + this.entrustOc);
            buffer.append(",entrustWay:" + this.entrustWay);
            buffer.append(",moneyType:" + this.moneyType);
            buffer.append(",entrustType:" + this.entrustType);
            buffer.append(",updateDate:" + this.updateDate);
            buffer.append(",updateTime:" + this.updateTime);
            buffer.append(",perFare:" + this.perFare);
            buffer.append(",parRatio:" + this.parRatio);
            buffer.append(",balanceRatio:" + this.balanceRatio);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.optfareKind);
            builder.append(this.fareType);
            builder.append(this.exchangeType);
            builder.append(this.stockType);
            builder.append(this.entrustBs);
            builder.append(this.entrustOc);
            builder.append(this.entrustWay);
            builder.append(this.moneyType);
            builder.append(this.entrustType);
            builder.append(this.updateDate);
            builder.append(this.updateTime);
            builder.append(this.perFare);
            builder.append(this.parRatio);
            builder.append(this.balanceRatio);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.Fare2DTO obj) {
            if (obj instanceof InnerOptService.Fare2DTO) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.optfareKind, obj.optfareKind);
                builder.append(this.fareType, obj.fareType);
                builder.append(this.exchangeType, obj.exchangeType);
                builder.append(this.stockType, obj.stockType);
                builder.append(this.entrustBs, obj.entrustBs);
                builder.append(this.entrustOc, obj.entrustOc);
                builder.append(this.entrustWay, obj.entrustWay);
                builder.append(this.moneyType, obj.moneyType);
                builder.append(this.entrustType, obj.entrustType);
                builder.append(this.updateDate, obj.updateDate);
                builder.append(this.updateTime, obj.updateTime);
                builder.append(this.perFare, obj.perFare);
                builder.append(this.parRatio, obj.parRatio);
                builder.append(this.balanceRatio, obj.balanceRatio);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class CoveredstockDTO implements Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String clientId = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fundAccount = " ";
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String exchangeType = " ";
        @SinogramLength(
                min = 0,
                max = 20,
                charset = "utf-8"
        )
        private String stockAccount = " ";
        @SinogramLength(
                min = 0,
                max = 8,
                charset = "utf-8"
        )
        private String stockCode = " ";
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String stockType = " ";
        @Digits(
                integer = 13,
                fraction = 2,
                message = "currentAmount value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double currentAmount = 0.0D;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "enableAmount value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double enableAmount = 0.0D;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "entrustSellAmount value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double entrustSellAmount = 0.0D;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "realBuyAmount value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double realBuyAmount = 0.0D;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "realSellAmount value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double realSellAmount = 0.0D;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "cirCoveredLockAmount value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double cirCoveredLockAmount = 0.0D;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "uncirCoveredLockAmount value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double uncirCoveredLockAmount = 0.0D;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "coveredShortAmount value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double coveredShortAmount = 0.0D;

        public CoveredstockDTO() {
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getExchangeType() {
            if (this.exchangeType == null) {
                return " ";
            } else {
                return this.exchangeType.isEmpty() ? " " : this.exchangeType;
            }
        }

        public String getStockAccount() {
            if (this.stockAccount == null) {
                return " ";
            } else {
                return this.stockAccount.isEmpty() ? " " : this.stockAccount;
            }
        }

        public String getStockCode() {
            if (this.stockCode == null) {
                return " ";
            } else {
                return this.stockCode.isEmpty() ? " " : this.stockCode;
            }
        }

        public String getStockType() {
            if (this.stockType == null) {
                return " ";
            } else {
                return this.stockType.isEmpty() ? " " : this.stockType;
            }
        }

        public Double getCurrentAmount() {
            return this.currentAmount != null ? this.currentAmount : 0.0D;
        }

        public Double getEnableAmount() {
            return this.enableAmount != null ? this.enableAmount : 0.0D;
        }

        public Double getEntrustSellAmount() {
            return this.entrustSellAmount != null ? this.entrustSellAmount : 0.0D;
        }

        public Double getRealBuyAmount() {
            return this.realBuyAmount != null ? this.realBuyAmount : 0.0D;
        }

        public Double getRealSellAmount() {
            return this.realSellAmount != null ? this.realSellAmount : 0.0D;
        }

        public Double getCirCoveredLockAmount() {
            return this.cirCoveredLockAmount != null ? this.cirCoveredLockAmount : 0.0D;
        }

        public Double getUncirCoveredLockAmount() {
            return this.uncirCoveredLockAmount != null ? this.uncirCoveredLockAmount : 0.0D;
        }

        public Double getCoveredShortAmount() {
            return this.coveredShortAmount != null ? this.coveredShortAmount : 0.0D;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public void setStockAccount(String stockAccount) {
            this.stockAccount = stockAccount;
        }

        public void setStockCode(String stockCode) {
            this.stockCode = stockCode;
        }

        public void setStockType(String stockType) {
            this.stockType = stockType;
        }

        public void setCurrentAmount(Double currentAmount) {
            this.currentAmount = currentAmount;
        }

        public void setEnableAmount(Double enableAmount) {
            this.enableAmount = enableAmount;
        }

        public void setEntrustSellAmount(Double entrustSellAmount) {
            this.entrustSellAmount = entrustSellAmount;
        }

        public void setRealBuyAmount(Double realBuyAmount) {
            this.realBuyAmount = realBuyAmount;
        }

        public void setRealSellAmount(Double realSellAmount) {
            this.realSellAmount = realSellAmount;
        }

        public void setCirCoveredLockAmount(Double cirCoveredLockAmount) {
            this.cirCoveredLockAmount = cirCoveredLockAmount;
        }

        public void setUncirCoveredLockAmount(Double uncirCoveredLockAmount) {
            this.uncirCoveredLockAmount = uncirCoveredLockAmount;
        }

        public void setCoveredShortAmount(Double coveredShortAmount) {
            this.coveredShortAmount = coveredShortAmount;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("CoveredstockDTO:(");
            buffer.append("clientId:" + this.clientId);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(",stockAccount:" + this.stockAccount);
            buffer.append(",stockCode:" + this.stockCode);
            buffer.append(",stockType:" + this.stockType);
            buffer.append(",currentAmount:" + this.currentAmount);
            buffer.append(",enableAmount:" + this.enableAmount);
            buffer.append(",entrustSellAmount:" + this.entrustSellAmount);
            buffer.append(",realBuyAmount:" + this.realBuyAmount);
            buffer.append(",realSellAmount:" + this.realSellAmount);
            buffer.append(",cirCoveredLockAmount:" + this.cirCoveredLockAmount);
            buffer.append(",uncirCoveredLockAmount:" + this.uncirCoveredLockAmount);
            buffer.append(",coveredShortAmount:" + this.coveredShortAmount);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.clientId);
            builder.append(this.fundAccount);
            builder.append(this.exchangeType);
            builder.append(this.stockAccount);
            builder.append(this.stockCode);
            builder.append(this.stockType);
            builder.append(this.currentAmount);
            builder.append(this.enableAmount);
            builder.append(this.entrustSellAmount);
            builder.append(this.realBuyAmount);
            builder.append(this.realSellAmount);
            builder.append(this.cirCoveredLockAmount);
            builder.append(this.uncirCoveredLockAmount);
            builder.append(this.coveredShortAmount);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.CoveredstockDTO obj) {
            if (obj instanceof InnerOptService.CoveredstockDTO) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.clientId, obj.clientId);
                builder.append(this.fundAccount, obj.fundAccount);
                builder.append(this.exchangeType, obj.exchangeType);
                builder.append(this.stockAccount, obj.stockAccount);
                builder.append(this.stockCode, obj.stockCode);
                builder.append(this.stockType, obj.stockType);
                builder.append(this.currentAmount, obj.currentAmount);
                builder.append(this.enableAmount, obj.enableAmount);
                builder.append(this.entrustSellAmount, obj.entrustSellAmount);
                builder.append(this.realBuyAmount, obj.realBuyAmount);
                builder.append(this.realSellAmount, obj.realSellAmount);
                builder.append(this.cirCoveredLockAmount, obj.cirCoveredLockAmount);
                builder.append(this.uncirCoveredLockAmount, obj.uncirCoveredLockAmount);
                builder.append(this.coveredShortAmount, obj.coveredShortAmount);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class CodeDTO implements Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String exchangeType = " ";
        @SinogramLength(
                min = 0,
                max = 8,
                charset = "utf-8"
        )
        private String optionCode = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character optionType = ' ';
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String optcontractId = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String optionName = " ";
        @SinogramLength(
                min = 0,
                max = 8,
                charset = "utf-8"
        )
        private String stockCode = " ";
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String stockType = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String stockName = " ";
        @SinogramLength(
                min = 0,
                max = 3,
                charset = "utf-8"
        )
        private String moneyType = " ";
        @Digits(
                integer = 6,
                fraction = 6,
                message = "optPriceStep value out of bounds, integer=6, fraction=6"
        )
        @SerializeDoubleDigit(
                digit = 6
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double optPriceStep = 0.0D;
        private Integer amountPerHand = 0;
        private Integer storeUnit = 0;
        private Integer reportUnit = 0;
        private Integer openUnit = 0;
        private Integer dropUnit = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character optionMode = ' ';
        @Digits(
                integer = 6,
                fraction = 6,
                message = "optClosePrice value out of bounds, integer=6, fraction=6"
        )
        @SerializeDoubleDigit(
                digit = 6
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double optClosePrice = 0.0D;
        @Digits(
                integer = 6,
                fraction = 6,
                message = "preSquarePrice value out of bounds, integer=6, fraction=6"
        )
        @SerializeDoubleDigit(
                digit = 6
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double preSquarePrice = 0.0D;
        @Digits(
                integer = 15,
                fraction = 8,
                message = "closePrice value out of bounds, integer=15, fraction=8"
        )
        @SerializeDoubleDigit(
                digit = 8
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double closePrice = 0.0D;
        @Digits(
                integer = 6,
                fraction = 6,
                message = "optUpPrice value out of bounds, integer=6, fraction=6"
        )
        @SerializeDoubleDigit(
                digit = 6
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double optUpPrice = 0.0D;
        @Digits(
                integer = 6,
                fraction = 6,
                message = "optDownPrice value out of bounds, integer=6, fraction=6"
        )
        @SerializeDoubleDigit(
                digit = 6
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double optDownPrice = 0.0D;
        @Digits(
                integer = 6,
                fraction = 6,
                message = "exercisePrice value out of bounds, integer=6, fraction=6"
        )
        @SerializeDoubleDigit(
                digit = 6
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double exercisePrice = 0.0D;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "initperBalance value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double initperBalance = 0.0D;
        @Digits(
                integer = 11,
                fraction = 4,
                message = "marginRatio1 value out of bounds, integer=11, fraction=4"
        )
        @SerializeDoubleDigit(
                digit = 4
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double marginRatio1 = 0.0D;
        @Digits(
                integer = 11,
                fraction = 4,
                message = "marginRatio2 value out of bounds, integer=11, fraction=4"
        )
        @SerializeDoubleDigit(
                digit = 4
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double marginRatio2 = 0.0D;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "undropAmount value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double undropAmount = 0.0D;
        private Integer beginDate = 0;
        private Integer endDate = 0;
        private Integer exeBeginDate = 0;
        private Integer exeEndDate = 0;
        private Integer deliverDate = 0;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String enEntrustWay = " ";
        private Integer modifyDate = 0;
        private Integer optionVersion = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character priceLimitKind = ' ';
        @Digits(
                integer = 6,
                fraction = 6,
                message = "optFairPrice value out of bounds, integer=6, fraction=6"
        )
        @SerializeDoubleDigit(
                digit = 6
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double optFairPrice = 0.0D;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "limitHighAmount value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double limitHighAmount = 0.0D;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "limitLowAmount value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double limitLowAmount = 0.0D;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "mktHighAmount value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double mktHighAmount = 0.0D;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "mktLowAmount value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double mktLowAmount = 0.0D;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character optcodeStatus = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character optOpenStatus = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String optOpenRestriction = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character optFinalStatus = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character optUpdatedStatus = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character optionFlag = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character combLimitFlag = ' ';
        private Integer verticalSplitDate = 0;
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String optcombCodeStr = " ";
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String verticalSplitDateStr = " ";
        @Digits(
                integer = 6,
                fraction = 6,
                message = "squarePrice value out of bounds, integer=6, fraction=6"
        )
        @SerializeDoubleDigit(
                digit = 6
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double squarePrice = 0.0D;

        public CodeDTO() {
        }

        public String getExchangeType() {
            if (this.exchangeType == null) {
                return " ";
            } else {
                return this.exchangeType.isEmpty() ? " " : this.exchangeType;
            }
        }

        public String getOptionCode() {
            if (this.optionCode == null) {
                return " ";
            } else {
                return this.optionCode.isEmpty() ? " " : this.optionCode;
            }
        }

        public Character getOptionType() {
            return this.optionType != null ? this.optionType : ' ';
        }

        public String getOptcontractId() {
            if (this.optcontractId == null) {
                return " ";
            } else {
                return this.optcontractId.isEmpty() ? " " : this.optcontractId;
            }
        }

        public String getOptionName() {
            if (this.optionName == null) {
                return " ";
            } else {
                return this.optionName.isEmpty() ? " " : this.optionName;
            }
        }

        public String getStockCode() {
            if (this.stockCode == null) {
                return " ";
            } else {
                return this.stockCode.isEmpty() ? " " : this.stockCode;
            }
        }

        public String getStockType() {
            if (this.stockType == null) {
                return " ";
            } else {
                return this.stockType.isEmpty() ? " " : this.stockType;
            }
        }

        public String getStockName() {
            if (this.stockName == null) {
                return " ";
            } else {
                return this.stockName.isEmpty() ? " " : this.stockName;
            }
        }

        public String getMoneyType() {
            if (this.moneyType == null) {
                return " ";
            } else {
                return this.moneyType.isEmpty() ? " " : this.moneyType;
            }
        }

        public Double getOptPriceStep() {
            return this.optPriceStep != null ? this.optPriceStep : 0.0D;
        }

        public Integer getAmountPerHand() {
            return this.amountPerHand != null ? this.amountPerHand : 0;
        }

        public Integer getStoreUnit() {
            return this.storeUnit != null ? this.storeUnit : 0;
        }

        public Integer getReportUnit() {
            return this.reportUnit != null ? this.reportUnit : 0;
        }

        public Integer getOpenUnit() {
            return this.openUnit != null ? this.openUnit : 0;
        }

        public Integer getDropUnit() {
            return this.dropUnit != null ? this.dropUnit : 0;
        }

        public Character getOptionMode() {
            return this.optionMode != null ? this.optionMode : ' ';
        }

        public Double getOptClosePrice() {
            return this.optClosePrice != null ? this.optClosePrice : 0.0D;
        }

        public Double getPreSquarePrice() {
            return this.preSquarePrice != null ? this.preSquarePrice : 0.0D;
        }

        public Double getClosePrice() {
            return this.closePrice != null ? this.closePrice : 0.0D;
        }

        public Double getOptUpPrice() {
            return this.optUpPrice != null ? this.optUpPrice : 0.0D;
        }

        public Double getOptDownPrice() {
            return this.optDownPrice != null ? this.optDownPrice : 0.0D;
        }

        public Double getExercisePrice() {
            return this.exercisePrice != null ? this.exercisePrice : 0.0D;
        }

        public Double getInitperBalance() {
            return this.initperBalance != null ? this.initperBalance : 0.0D;
        }

        public Double getMarginRatio1() {
            return this.marginRatio1 != null ? this.marginRatio1 : 0.0D;
        }

        public Double getMarginRatio2() {
            return this.marginRatio2 != null ? this.marginRatio2 : 0.0D;
        }

        public Double getUndropAmount() {
            return this.undropAmount != null ? this.undropAmount : 0.0D;
        }

        public Integer getBeginDate() {
            return this.beginDate != null ? this.beginDate : 0;
        }

        public Integer getEndDate() {
            return this.endDate != null ? this.endDate : 0;
        }

        public Integer getExeBeginDate() {
            return this.exeBeginDate != null ? this.exeBeginDate : 0;
        }

        public Integer getExeEndDate() {
            return this.exeEndDate != null ? this.exeEndDate : 0;
        }

        public Integer getDeliverDate() {
            return this.deliverDate != null ? this.deliverDate : 0;
        }

        public String getEnEntrustWay() {
            if (this.enEntrustWay == null) {
                return " ";
            } else {
                return this.enEntrustWay.isEmpty() ? " " : this.enEntrustWay;
            }
        }

        public Integer getModifyDate() {
            return this.modifyDate != null ? this.modifyDate : 0;
        }

        public Integer getOptionVersion() {
            return this.optionVersion != null ? this.optionVersion : 0;
        }

        public Character getPriceLimitKind() {
            return this.priceLimitKind != null ? this.priceLimitKind : ' ';
        }

        public Double getOptFairPrice() {
            return this.optFairPrice != null ? this.optFairPrice : 0.0D;
        }

        public Double getLimitHighAmount() {
            return this.limitHighAmount != null ? this.limitHighAmount : 0.0D;
        }

        public Double getLimitLowAmount() {
            return this.limitLowAmount != null ? this.limitLowAmount : 0.0D;
        }

        public Double getMktHighAmount() {
            return this.mktHighAmount != null ? this.mktHighAmount : 0.0D;
        }

        public Double getMktLowAmount() {
            return this.mktLowAmount != null ? this.mktLowAmount : 0.0D;
        }

        public Character getOptcodeStatus() {
            return this.optcodeStatus != null ? this.optcodeStatus : ' ';
        }

        public Character getOptOpenStatus() {
            return this.optOpenStatus != null ? this.optOpenStatus : ' ';
        }

        public String getOptOpenRestriction() {
            if (this.optOpenRestriction == null) {
                return " ";
            } else {
                return this.optOpenRestriction.isEmpty() ? " " : this.optOpenRestriction;
            }
        }

        public Character getOptFinalStatus() {
            return this.optFinalStatus != null ? this.optFinalStatus : ' ';
        }

        public Character getOptUpdatedStatus() {
            return this.optUpdatedStatus != null ? this.optUpdatedStatus : ' ';
        }

        public Character getOptionFlag() {
            return this.optionFlag != null ? this.optionFlag : ' ';
        }

        public Character getCombLimitFlag() {
            return this.combLimitFlag != null ? this.combLimitFlag : ' ';
        }

        public Integer getVerticalSplitDate() {
            return this.verticalSplitDate != null ? this.verticalSplitDate : 0;
        }

        public String getOptcombCodeStr() {
            if (this.optcombCodeStr == null) {
                return " ";
            } else {
                return this.optcombCodeStr.isEmpty() ? " " : this.optcombCodeStr;
            }
        }

        public String getVerticalSplitDateStr() {
            if (this.verticalSplitDateStr == null) {
                return " ";
            } else {
                return this.verticalSplitDateStr.isEmpty() ? " " : this.verticalSplitDateStr;
            }
        }

        public Double getSquarePrice() {
            return this.squarePrice != null ? this.squarePrice : 0.0D;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public void setOptionCode(String optionCode) {
            this.optionCode = optionCode;
        }

        public void setOptionType(Character optionType) {
            this.optionType = optionType;
        }

        public void setOptcontractId(String optcontractId) {
            this.optcontractId = optcontractId;
        }

        public void setOptionName(String optionName) {
            this.optionName = optionName;
        }

        public void setStockCode(String stockCode) {
            this.stockCode = stockCode;
        }

        public void setStockType(String stockType) {
            this.stockType = stockType;
        }

        public void setStockName(String stockName) {
            this.stockName = stockName;
        }

        public void setMoneyType(String moneyType) {
            this.moneyType = moneyType;
        }

        public void setOptPriceStep(Double optPriceStep) {
            this.optPriceStep = optPriceStep;
        }

        public void setAmountPerHand(Integer amountPerHand) {
            this.amountPerHand = amountPerHand;
        }

        public void setStoreUnit(Integer storeUnit) {
            this.storeUnit = storeUnit;
        }

        public void setReportUnit(Integer reportUnit) {
            this.reportUnit = reportUnit;
        }

        public void setOpenUnit(Integer openUnit) {
            this.openUnit = openUnit;
        }

        public void setDropUnit(Integer dropUnit) {
            this.dropUnit = dropUnit;
        }

        public void setOptionMode(Character optionMode) {
            this.optionMode = optionMode;
        }

        public void setOptClosePrice(Double optClosePrice) {
            this.optClosePrice = optClosePrice;
        }

        public void setPreSquarePrice(Double preSquarePrice) {
            this.preSquarePrice = preSquarePrice;
        }

        public void setClosePrice(Double closePrice) {
            this.closePrice = closePrice;
        }

        public void setOptUpPrice(Double optUpPrice) {
            this.optUpPrice = optUpPrice;
        }

        public void setOptDownPrice(Double optDownPrice) {
            this.optDownPrice = optDownPrice;
        }

        public void setExercisePrice(Double exercisePrice) {
            this.exercisePrice = exercisePrice;
        }

        public void setInitperBalance(Double initperBalance) {
            this.initperBalance = initperBalance;
        }

        public void setMarginRatio1(Double marginRatio1) {
            this.marginRatio1 = marginRatio1;
        }

        public void setMarginRatio2(Double marginRatio2) {
            this.marginRatio2 = marginRatio2;
        }

        public void setUndropAmount(Double undropAmount) {
            this.undropAmount = undropAmount;
        }

        public void setBeginDate(Integer beginDate) {
            this.beginDate = beginDate;
        }

        public void setEndDate(Integer endDate) {
            this.endDate = endDate;
        }

        public void setExeBeginDate(Integer exeBeginDate) {
            this.exeBeginDate = exeBeginDate;
        }

        public void setExeEndDate(Integer exeEndDate) {
            this.exeEndDate = exeEndDate;
        }

        public void setDeliverDate(Integer deliverDate) {
            this.deliverDate = deliverDate;
        }

        public void setEnEntrustWay(String enEntrustWay) {
            this.enEntrustWay = enEntrustWay;
        }

        public void setModifyDate(Integer modifyDate) {
            this.modifyDate = modifyDate;
        }

        public void setOptionVersion(Integer optionVersion) {
            this.optionVersion = optionVersion;
        }

        public void setPriceLimitKind(Character priceLimitKind) {
            this.priceLimitKind = priceLimitKind;
        }

        public void setOptFairPrice(Double optFairPrice) {
            this.optFairPrice = optFairPrice;
        }

        public void setLimitHighAmount(Double limitHighAmount) {
            this.limitHighAmount = limitHighAmount;
        }

        public void setLimitLowAmount(Double limitLowAmount) {
            this.limitLowAmount = limitLowAmount;
        }

        public void setMktHighAmount(Double mktHighAmount) {
            this.mktHighAmount = mktHighAmount;
        }

        public void setMktLowAmount(Double mktLowAmount) {
            this.mktLowAmount = mktLowAmount;
        }

        public void setOptcodeStatus(Character optcodeStatus) {
            this.optcodeStatus = optcodeStatus;
        }

        public void setOptOpenStatus(Character optOpenStatus) {
            this.optOpenStatus = optOpenStatus;
        }

        public void setOptOpenRestriction(String optOpenRestriction) {
            this.optOpenRestriction = optOpenRestriction;
        }

        public void setOptFinalStatus(Character optFinalStatus) {
            this.optFinalStatus = optFinalStatus;
        }

        public void setOptUpdatedStatus(Character optUpdatedStatus) {
            this.optUpdatedStatus = optUpdatedStatus;
        }

        public void setOptionFlag(Character optionFlag) {
            this.optionFlag = optionFlag;
        }

        public void setCombLimitFlag(Character combLimitFlag) {
            this.combLimitFlag = combLimitFlag;
        }

        public void setVerticalSplitDate(Integer verticalSplitDate) {
            this.verticalSplitDate = verticalSplitDate;
        }

        public void setOptcombCodeStr(String optcombCodeStr) {
            this.optcombCodeStr = optcombCodeStr;
        }

        public void setVerticalSplitDateStr(String verticalSplitDateStr) {
            this.verticalSplitDateStr = verticalSplitDateStr;
        }

        public void setSquarePrice(Double squarePrice) {
            this.squarePrice = squarePrice;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("CodeDTO:(");
            buffer.append("exchangeType:" + this.exchangeType);
            buffer.append(",optionCode:" + this.optionCode);
            buffer.append(",optionType:" + this.optionType);
            buffer.append(",optcontractId:" + this.optcontractId);
            buffer.append(",optionName:" + this.optionName);
            buffer.append(",stockCode:" + this.stockCode);
            buffer.append(",stockType:" + this.stockType);
            buffer.append(",stockName:" + this.stockName);
            buffer.append(",moneyType:" + this.moneyType);
            buffer.append(",optPriceStep:" + this.optPriceStep);
            buffer.append(",amountPerHand:" + this.amountPerHand);
            buffer.append(",storeUnit:" + this.storeUnit);
            buffer.append(",reportUnit:" + this.reportUnit);
            buffer.append(",openUnit:" + this.openUnit);
            buffer.append(",dropUnit:" + this.dropUnit);
            buffer.append(",optionMode:" + this.optionMode);
            buffer.append(",optClosePrice:" + this.optClosePrice);
            buffer.append(",preSquarePrice:" + this.preSquarePrice);
            buffer.append(",closePrice:" + this.closePrice);
            buffer.append(",optUpPrice:" + this.optUpPrice);
            buffer.append(",optDownPrice:" + this.optDownPrice);
            buffer.append(",exercisePrice:" + this.exercisePrice);
            buffer.append(",initperBalance:" + this.initperBalance);
            buffer.append(",marginRatio1:" + this.marginRatio1);
            buffer.append(",marginRatio2:" + this.marginRatio2);
            buffer.append(",undropAmount:" + this.undropAmount);
            buffer.append(",beginDate:" + this.beginDate);
            buffer.append(",endDate:" + this.endDate);
            buffer.append(",exeBeginDate:" + this.exeBeginDate);
            buffer.append(",exeEndDate:" + this.exeEndDate);
            buffer.append(",deliverDate:" + this.deliverDate);
            buffer.append(",enEntrustWay:" + this.enEntrustWay);
            buffer.append(",modifyDate:" + this.modifyDate);
            buffer.append(",optionVersion:" + this.optionVersion);
            buffer.append(",priceLimitKind:" + this.priceLimitKind);
            buffer.append(",optFairPrice:" + this.optFairPrice);
            buffer.append(",limitHighAmount:" + this.limitHighAmount);
            buffer.append(",limitLowAmount:" + this.limitLowAmount);
            buffer.append(",mktHighAmount:" + this.mktHighAmount);
            buffer.append(",mktLowAmount:" + this.mktLowAmount);
            buffer.append(",optcodeStatus:" + this.optcodeStatus);
            buffer.append(",optOpenStatus:" + this.optOpenStatus);
            buffer.append(",optOpenRestriction:" + this.optOpenRestriction);
            buffer.append(",optFinalStatus:" + this.optFinalStatus);
            buffer.append(",optUpdatedStatus:" + this.optUpdatedStatus);
            buffer.append(",optionFlag:" + this.optionFlag);
            buffer.append(",combLimitFlag:" + this.combLimitFlag);
            buffer.append(",verticalSplitDate:" + this.verticalSplitDate);
            buffer.append(",optcombCodeStr:" + this.optcombCodeStr);
            buffer.append(",verticalSplitDateStr:" + this.verticalSplitDateStr);
            buffer.append(",squarePrice:" + this.squarePrice);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.exchangeType);
            builder.append(this.optionCode);
            builder.append(this.optionType);
            builder.append(this.optcontractId);
            builder.append(this.optionName);
            builder.append(this.stockCode);
            builder.append(this.stockType);
            builder.append(this.stockName);
            builder.append(this.moneyType);
            builder.append(this.optPriceStep);
            builder.append(this.amountPerHand);
            builder.append(this.storeUnit);
            builder.append(this.reportUnit);
            builder.append(this.openUnit);
            builder.append(this.dropUnit);
            builder.append(this.optionMode);
            builder.append(this.optClosePrice);
            builder.append(this.preSquarePrice);
            builder.append(this.closePrice);
            builder.append(this.optUpPrice);
            builder.append(this.optDownPrice);
            builder.append(this.exercisePrice);
            builder.append(this.initperBalance);
            builder.append(this.marginRatio1);
            builder.append(this.marginRatio2);
            builder.append(this.undropAmount);
            builder.append(this.beginDate);
            builder.append(this.endDate);
            builder.append(this.exeBeginDate);
            builder.append(this.exeEndDate);
            builder.append(this.deliverDate);
            builder.append(this.enEntrustWay);
            builder.append(this.modifyDate);
            builder.append(this.optionVersion);
            builder.append(this.priceLimitKind);
            builder.append(this.optFairPrice);
            builder.append(this.limitHighAmount);
            builder.append(this.limitLowAmount);
            builder.append(this.mktHighAmount);
            builder.append(this.mktLowAmount);
            builder.append(this.optcodeStatus);
            builder.append(this.optOpenStatus);
            builder.append(this.optOpenRestriction);
            builder.append(this.optFinalStatus);
            builder.append(this.optUpdatedStatus);
            builder.append(this.optionFlag);
            builder.append(this.combLimitFlag);
            builder.append(this.verticalSplitDate);
            builder.append(this.optcombCodeStr);
            builder.append(this.verticalSplitDateStr);
            builder.append(this.squarePrice);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.CodeDTO obj) {
            if (obj instanceof InnerOptService.CodeDTO) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.exchangeType, obj.exchangeType);
                builder.append(this.optionCode, obj.optionCode);
                builder.append(this.optionType, obj.optionType);
                builder.append(this.optcontractId, obj.optcontractId);
                builder.append(this.optionName, obj.optionName);
                builder.append(this.stockCode, obj.stockCode);
                builder.append(this.stockType, obj.stockType);
                builder.append(this.stockName, obj.stockName);
                builder.append(this.moneyType, obj.moneyType);
                builder.append(this.optPriceStep, obj.optPriceStep);
                builder.append(this.amountPerHand, obj.amountPerHand);
                builder.append(this.storeUnit, obj.storeUnit);
                builder.append(this.reportUnit, obj.reportUnit);
                builder.append(this.openUnit, obj.openUnit);
                builder.append(this.dropUnit, obj.dropUnit);
                builder.append(this.optionMode, obj.optionMode);
                builder.append(this.optClosePrice, obj.optClosePrice);
                builder.append(this.preSquarePrice, obj.preSquarePrice);
                builder.append(this.closePrice, obj.closePrice);
                builder.append(this.optUpPrice, obj.optUpPrice);
                builder.append(this.optDownPrice, obj.optDownPrice);
                builder.append(this.exercisePrice, obj.exercisePrice);
                builder.append(this.initperBalance, obj.initperBalance);
                builder.append(this.marginRatio1, obj.marginRatio1);
                builder.append(this.marginRatio2, obj.marginRatio2);
                builder.append(this.undropAmount, obj.undropAmount);
                builder.append(this.beginDate, obj.beginDate);
                builder.append(this.endDate, obj.endDate);
                builder.append(this.exeBeginDate, obj.exeBeginDate);
                builder.append(this.exeEndDate, obj.exeEndDate);
                builder.append(this.deliverDate, obj.deliverDate);
                builder.append(this.enEntrustWay, obj.enEntrustWay);
                builder.append(this.modifyDate, obj.modifyDate);
                builder.append(this.optionVersion, obj.optionVersion);
                builder.append(this.priceLimitKind, obj.priceLimitKind);
                builder.append(this.optFairPrice, obj.optFairPrice);
                builder.append(this.limitHighAmount, obj.limitHighAmount);
                builder.append(this.limitLowAmount, obj.limitLowAmount);
                builder.append(this.mktHighAmount, obj.mktHighAmount);
                builder.append(this.mktLowAmount, obj.mktLowAmount);
                builder.append(this.optcodeStatus, obj.optcodeStatus);
                builder.append(this.optOpenStatus, obj.optOpenStatus);
                builder.append(this.optOpenRestriction, obj.optOpenRestriction);
                builder.append(this.optFinalStatus, obj.optFinalStatus);
                builder.append(this.optUpdatedStatus, obj.optUpdatedStatus);
                builder.append(this.optionFlag, obj.optionFlag);
                builder.append(this.combLimitFlag, obj.combLimitFlag);
                builder.append(this.verticalSplitDate, obj.verticalSplitDate);
                builder.append(this.optcombCodeStr, obj.optcombCodeStr);
                builder.append(this.verticalSplitDateStr, obj.verticalSplitDateStr);
                builder.append(this.squarePrice, obj.squarePrice);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutPriceInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer errorNo;

        public PutPriceInnerOutput() {
        }

        public Integer getErrorNo() {
            return this.errorNo;
        }

        public void setErrorNo(Integer errorNo) {
            this.errorNo = errorNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutPriceInnerOutput:(");
            buffer.append("errorNo:" + this.errorNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.errorNo);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PutPriceInnerOutput obj) {
            if (obj instanceof InnerOptService.PutPriceInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.errorNo, obj.errorNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutPriceInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword;
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay;
        private Integer opBranchNo;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo;
        private Integer actionIn;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "businessAmount value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double businessAmount;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "businessBalance value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double businessBalance;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "buyAmount1 value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double buyAmount1;
        @Digits(
                integer = 5,
                fraction = 4,
                message = "buyPrice1 value out of bounds, integer=5, fraction=4"
        )
        @SerializeDoubleDigit(
                digit = 4
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double buyPrice1;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character closeFlag;
        @Digits(
                integer = 15,
                fraction = 8,
                message = "closePrice value out of bounds, integer=15, fraction=8"
        )
        @SerializeDoubleDigit(
                digit = 8
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double closePrice;
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String exchangeType;
        @Digits(
                integer = 5,
                fraction = 4,
                message = "highPrice value out of bounds, integer=5, fraction=4"
        )
        @SerializeDoubleDigit(
                digit = 4
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double highPrice;
        @Digits(
                integer = 5,
                fraction = 4,
                message = "lowPrice value out of bounds, integer=5, fraction=4"
        )
        @SerializeDoubleDigit(
                digit = 4
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double lowPrice;
        @Digits(
                integer = 5,
                fraction = 4,
                message = "openPrice value out of bounds, integer=5, fraction=4"
        )
        @SerializeDoubleDigit(
                digit = 4
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double openPrice;
        @Digits(
                integer = 6,
                fraction = 6,
                message = "optLastPrice value out of bounds, integer=6, fraction=6"
        )
        @SerializeDoubleDigit(
                digit = 6
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double optLastPrice;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String optOpenRestriction;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "optauctionAmount value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double optauctionAmount;
        @Digits(
                integer = 5,
                fraction = 4,
                message = "optauctionPrice value out of bounds, integer=5, fraction=4"
        )
        @SerializeDoubleDigit(
                digit = 4
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double optauctionPrice;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character optcodeStatus;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character optexchStatus;
        @SinogramLength(
                min = 0,
                max = 8,
                charset = "utf-8"
        )
        private String optionCode;
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String optionName;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character optphaseFlag;
        @Digits(
                integer = 6,
                fraction = 6,
                message = "preSquarePrice value out of bounds, integer=6, fraction=6"
        )
        @SerializeDoubleDigit(
                digit = 6
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double preSquarePrice;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "saleAmount1 value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double saleAmount1;
        @Digits(
                integer = 5,
                fraction = 4,
                message = "salePrice1 value out of bounds, integer=5, fraction=4"
        )
        @SerializeDoubleDigit(
                digit = 4
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double salePrice1;
        @Digits(
                integer = 6,
                fraction = 6,
                message = "squarePrice value out of bounds, integer=6, fraction=6"
        )
        @SerializeDoubleDigit(
                digit = 6
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double squarePrice;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "undropAmount value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double undropAmount;

        public PutPriceInnerInput() {
        }

        public String getOpPassword() {
            return this.opPassword;
        }

        public String getOpStation() {
            return this.opStation;
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay;
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo;
        }

        public String getOperatorNo() {
            return this.operatorNo;
        }

        public Integer getActionIn() {
            return this.actionIn;
        }

        public Double getBusinessAmount() {
            return this.businessAmount;
        }

        public Double getBusinessBalance() {
            return this.businessBalance;
        }

        public Double getBuyAmount1() {
            return this.buyAmount1;
        }

        public Double getBuyPrice1() {
            return this.buyPrice1;
        }

        public Character getCloseFlag() {
            return this.closeFlag;
        }

        public Double getClosePrice() {
            return this.closePrice;
        }

        public String getExchangeType() {
            return this.exchangeType;
        }

        public Double getHighPrice() {
            return this.highPrice;
        }

        public Double getLowPrice() {
            return this.lowPrice;
        }

        public Double getOpenPrice() {
            return this.openPrice;
        }

        public Double getOptLastPrice() {
            return this.optLastPrice;
        }

        public String getOptOpenRestriction() {
            return this.optOpenRestriction;
        }

        public Double getOptauctionAmount() {
            return this.optauctionAmount;
        }

        public Double getOptauctionPrice() {
            return this.optauctionPrice;
        }

        public Character getOptcodeStatus() {
            return this.optcodeStatus;
        }

        public Character getOptexchStatus() {
            return this.optexchStatus;
        }

        public String getOptionCode() {
            return this.optionCode;
        }

        public String getOptionName() {
            return this.optionName;
        }

        public Character getOptphaseFlag() {
            return this.optphaseFlag;
        }

        public Double getPreSquarePrice() {
            return this.preSquarePrice;
        }

        public Double getSaleAmount1() {
            return this.saleAmount1;
        }

        public Double getSalePrice1() {
            return this.salePrice1;
        }

        public Double getSquarePrice() {
            return this.squarePrice;
        }

        public Double getUndropAmount() {
            return this.undropAmount;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setActionIn(Integer actionIn) {
            this.actionIn = actionIn;
        }

        public void setBusinessAmount(Double businessAmount) {
            this.businessAmount = businessAmount;
        }

        public void setBusinessBalance(Double businessBalance) {
            this.businessBalance = businessBalance;
        }

        public void setBuyAmount1(Double buyAmount1) {
            this.buyAmount1 = buyAmount1;
        }

        public void setBuyPrice1(Double buyPrice1) {
            this.buyPrice1 = buyPrice1;
        }

        public void setCloseFlag(Character closeFlag) {
            this.closeFlag = closeFlag;
        }

        public void setClosePrice(Double closePrice) {
            this.closePrice = closePrice;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public void setHighPrice(Double highPrice) {
            this.highPrice = highPrice;
        }

        public void setLowPrice(Double lowPrice) {
            this.lowPrice = lowPrice;
        }

        public void setOpenPrice(Double openPrice) {
            this.openPrice = openPrice;
        }

        public void setOptLastPrice(Double optLastPrice) {
            this.optLastPrice = optLastPrice;
        }

        public void setOptOpenRestriction(String optOpenRestriction) {
            this.optOpenRestriction = optOpenRestriction;
        }

        public void setOptauctionAmount(Double optauctionAmount) {
            this.optauctionAmount = optauctionAmount;
        }

        public void setOptauctionPrice(Double optauctionPrice) {
            this.optauctionPrice = optauctionPrice;
        }

        public void setOptcodeStatus(Character optcodeStatus) {
            this.optcodeStatus = optcodeStatus;
        }

        public void setOptexchStatus(Character optexchStatus) {
            this.optexchStatus = optexchStatus;
        }

        public void setOptionCode(String optionCode) {
            this.optionCode = optionCode;
        }

        public void setOptionName(String optionName) {
            this.optionName = optionName;
        }

        public void setOptphaseFlag(Character optphaseFlag) {
            this.optphaseFlag = optphaseFlag;
        }

        public void setPreSquarePrice(Double preSquarePrice) {
            this.preSquarePrice = preSquarePrice;
        }

        public void setSaleAmount1(Double saleAmount1) {
            this.saleAmount1 = saleAmount1;
        }

        public void setSalePrice1(Double salePrice1) {
            this.salePrice1 = salePrice1;
        }

        public void setSquarePrice(Double squarePrice) {
            this.squarePrice = squarePrice;
        }

        public void setUndropAmount(Double undropAmount) {
            this.undropAmount = undropAmount;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutPriceInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",actionIn:" + this.actionIn);
            buffer.append(",businessAmount:" + this.businessAmount);
            buffer.append(",businessBalance:" + this.businessBalance);
            buffer.append(",buyAmount1:" + this.buyAmount1);
            buffer.append(",buyPrice1:" + this.buyPrice1);
            buffer.append(",closeFlag:" + this.closeFlag);
            buffer.append(",closePrice:" + this.closePrice);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(",highPrice:" + this.highPrice);
            buffer.append(",lowPrice:" + this.lowPrice);
            buffer.append(",openPrice:" + this.openPrice);
            buffer.append(",optLastPrice:" + this.optLastPrice);
            buffer.append(",optOpenRestriction:" + this.optOpenRestriction);
            buffer.append(",optauctionAmount:" + this.optauctionAmount);
            buffer.append(",optauctionPrice:" + this.optauctionPrice);
            buffer.append(",optcodeStatus:" + this.optcodeStatus);
            buffer.append(",optexchStatus:" + this.optexchStatus);
            buffer.append(",optionCode:" + this.optionCode);
            buffer.append(",optionName:" + this.optionName);
            buffer.append(",optphaseFlag:" + this.optphaseFlag);
            buffer.append(",preSquarePrice:" + this.preSquarePrice);
            buffer.append(",saleAmount1:" + this.saleAmount1);
            buffer.append(",salePrice1:" + this.salePrice1);
            buffer.append(",squarePrice:" + this.squarePrice);
            buffer.append(",undropAmount:" + this.undropAmount);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.actionIn);
            builder.append(this.businessAmount);
            builder.append(this.businessBalance);
            builder.append(this.buyAmount1);
            builder.append(this.buyPrice1);
            builder.append(this.closeFlag);
            builder.append(this.closePrice);
            builder.append(this.exchangeType);
            builder.append(this.highPrice);
            builder.append(this.lowPrice);
            builder.append(this.openPrice);
            builder.append(this.optLastPrice);
            builder.append(this.optOpenRestriction);
            builder.append(this.optauctionAmount);
            builder.append(this.optauctionPrice);
            builder.append(this.optcodeStatus);
            builder.append(this.optexchStatus);
            builder.append(this.optionCode);
            builder.append(this.optionName);
            builder.append(this.optphaseFlag);
            builder.append(this.preSquarePrice);
            builder.append(this.saleAmount1);
            builder.append(this.salePrice1);
            builder.append(this.squarePrice);
            builder.append(this.undropAmount);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PutPriceInnerInput obj) {
            if (obj instanceof InnerOptService.PutPriceInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, obj.opPassword);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.actionIn, obj.actionIn);
                builder.append(this.businessAmount, obj.businessAmount);
                builder.append(this.businessBalance, obj.businessBalance);
                builder.append(this.buyAmount1, obj.buyAmount1);
                builder.append(this.buyPrice1, obj.buyPrice1);
                builder.append(this.closeFlag, obj.closeFlag);
                builder.append(this.closePrice, obj.closePrice);
                builder.append(this.exchangeType, obj.exchangeType);
                builder.append(this.highPrice, obj.highPrice);
                builder.append(this.lowPrice, obj.lowPrice);
                builder.append(this.openPrice, obj.openPrice);
                builder.append(this.optLastPrice, obj.optLastPrice);
                builder.append(this.optOpenRestriction, obj.optOpenRestriction);
                builder.append(this.optauctionAmount, obj.optauctionAmount);
                builder.append(this.optauctionPrice, obj.optauctionPrice);
                builder.append(this.optcodeStatus, obj.optcodeStatus);
                builder.append(this.optexchStatus, obj.optexchStatus);
                builder.append(this.optionCode, obj.optionCode);
                builder.append(this.optionName, obj.optionName);
                builder.append(this.optphaseFlag, obj.optphaseFlag);
                builder.append(this.preSquarePrice, obj.preSquarePrice);
                builder.append(this.saleAmount1, obj.saleAmount1);
                builder.append(this.salePrice1, obj.salePrice1);
                builder.append(this.squarePrice, obj.squarePrice);
                builder.append(this.undropAmount, obj.undropAmount);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutLoancompactdailyReturnInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String opRemark = " ";

        public PutLoancompactdailyReturnInnerOutput() {
        }

        public String getOpRemark() {
            if (this.opRemark == null) {
                return " ";
            } else {
                return this.opRemark.isEmpty() ? " " : this.opRemark;
            }
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutLoancompactdailyReturnInnerOutput:(");
            buffer.append("opRemark:" + this.opRemark);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opRemark);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PutLoancompactdailyReturnInnerOutput obj) {
            if (obj instanceof InnerOptService.PutLoancompactdailyReturnInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opRemark, obj.opRemark);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutLoancompactdailyReturnInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String exchangeType = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fundAccount = " ";
        @SinogramLength(
                min = 0,
                max = 8,
                charset = "utf-8"
        )
        private String stockCode = " ";
        @Digits(
                integer = 13,
                fraction = 2,
                message = "treatAmount value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double treatAmount = 0.0D;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "returnBalance value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double returnBalance = 0.0D;
        private Integer initDate = 0;
        @SinogramLength(
                min = 0,
                max = 3,
                charset = "utf-8"
        )
        private String moneyType = " ";
        private Integer sysnodeId = 0;

        public PutLoancompactdailyReturnInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getExchangeType() {
            if (this.exchangeType == null) {
                return " ";
            } else {
                return this.exchangeType.isEmpty() ? " " : this.exchangeType;
            }
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getStockCode() {
            if (this.stockCode == null) {
                return " ";
            } else {
                return this.stockCode.isEmpty() ? " " : this.stockCode;
            }
        }

        public Double getTreatAmount() {
            return this.treatAmount != null ? this.treatAmount : 0.0D;
        }

        public Double getReturnBalance() {
            return this.returnBalance != null ? this.returnBalance : 0.0D;
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public String getMoneyType() {
            if (this.moneyType == null) {
                return " ";
            } else {
                return this.moneyType.isEmpty() ? " " : this.moneyType;
            }
        }

        public Integer getSysnodeId() {
            return this.sysnodeId != null ? this.sysnodeId : 0;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setStockCode(String stockCode) {
            this.stockCode = stockCode;
        }

        public void setTreatAmount(Double treatAmount) {
            this.treatAmount = treatAmount;
        }

        public void setReturnBalance(Double returnBalance) {
            this.returnBalance = returnBalance;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public void setMoneyType(String moneyType) {
            this.moneyType = moneyType;
        }

        public void setSysnodeId(Integer sysnodeId) {
            this.sysnodeId = sysnodeId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutLoancompactdailyReturnInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",stockCode:" + this.stockCode);
            buffer.append(",treatAmount:" + this.treatAmount);
            buffer.append(",returnBalance:" + this.returnBalance);
            buffer.append(",initDate:" + this.initDate);
            buffer.append(",moneyType:" + this.moneyType);
            buffer.append(",sysnodeId:" + this.sysnodeId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.exchangeType);
            builder.append(this.fundAccount);
            builder.append(this.stockCode);
            builder.append(this.treatAmount);
            builder.append(this.returnBalance);
            builder.append(this.initDate);
            builder.append(this.moneyType);
            builder.append(this.sysnodeId);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PutLoancompactdailyReturnInnerInput obj) {
            if (obj instanceof InnerOptService.PutLoancompactdailyReturnInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, obj.opPassword);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.exchangeType, obj.exchangeType);
                builder.append(this.fundAccount, obj.fundAccount);
                builder.append(this.stockCode, obj.stockCode);
                builder.append(this.treatAmount, obj.treatAmount);
                builder.append(this.returnBalance, obj.returnBalance);
                builder.append(this.initDate, obj.initDate);
                builder.append(this.moneyType, obj.moneyType);
                builder.append(this.sysnodeId, obj.sysnodeId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutHoldrealdayendSyncInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String fundAccount = " ";
        private String exchangeType = " ";
        private String clientId = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character flag = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character exchType = ' ';
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double beginEnableAmount = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double postEnableAmount = 0.0D;
        private String optionCode = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character optholdType = ' ';

        public PutHoldrealdayendSyncInnerOutput() {
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getExchangeType() {
            if (this.exchangeType == null) {
                return " ";
            } else {
                return this.exchangeType.isEmpty() ? " " : this.exchangeType;
            }
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public Character getFlag() {
            return this.flag != null ? this.flag : ' ';
        }

        public Character getExchType() {
            return this.exchType != null ? this.exchType : ' ';
        }

        public Double getBeginEnableAmount() {
            return this.beginEnableAmount != null ? this.beginEnableAmount : 0.0D;
        }

        public Double getPostEnableAmount() {
            return this.postEnableAmount != null ? this.postEnableAmount : 0.0D;
        }

        public String getOptionCode() {
            if (this.optionCode == null) {
                return " ";
            } else {
                return this.optionCode.isEmpty() ? " " : this.optionCode;
            }
        }

        public Character getOptholdType() {
            return this.optholdType != null ? this.optholdType : ' ';
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setFlag(Character flag) {
            this.flag = flag;
        }

        public void setExchType(Character exchType) {
            this.exchType = exchType;
        }

        public void setBeginEnableAmount(Double beginEnableAmount) {
            this.beginEnableAmount = beginEnableAmount;
        }

        public void setPostEnableAmount(Double postEnableAmount) {
            this.postEnableAmount = postEnableAmount;
        }

        public void setOptionCode(String optionCode) {
            this.optionCode = optionCode;
        }

        public void setOptholdType(Character optholdType) {
            this.optholdType = optholdType;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutHoldrealdayendSyncInnerOutput:(");
            buffer.append("fundAccount:" + this.fundAccount);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",flag:" + this.flag);
            buffer.append(",exchType:" + this.exchType);
            buffer.append(",beginEnableAmount:" + this.beginEnableAmount);
            buffer.append(",postEnableAmount:" + this.postEnableAmount);
            buffer.append(",optionCode:" + this.optionCode);
            buffer.append(",optholdType:" + this.optholdType);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.fundAccount);
            builder.append(this.exchangeType);
            builder.append(this.clientId);
            builder.append(this.flag);
            builder.append(this.exchType);
            builder.append(this.beginEnableAmount);
            builder.append(this.postEnableAmount);
            builder.append(this.optionCode);
            builder.append(this.optholdType);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PutHoldrealdayendSyncInnerOutput obj) {
            if (obj instanceof InnerOptService.PutHoldrealdayendSyncInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.fundAccount, obj.fundAccount);
                builder.append(this.exchangeType, obj.exchangeType);
                builder.append(this.clientId, obj.clientId);
                builder.append(this.flag, obj.flag);
                builder.append(this.exchType, obj.exchType);
                builder.append(this.beginEnableAmount, obj.beginEnableAmount);
                builder.append(this.postEnableAmount, obj.postEnableAmount);
                builder.append(this.optionCode, obj.optionCode);
                builder.append(this.optholdType, obj.optholdType);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutHoldrealdayendSyncInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        private Integer initDate = 0;
        private String settleClob = " ";
        private Integer settSysnodeId = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character totalType = ' ';
        @JsonSerialize(
                using = LongJsonSerializer.class
        )
        @JsonDeserialize(
                using = LongJsonDeserializer.class
        )
        private Long settBatchNo = 0L;
        @JsonSerialize(
                using = LongJsonSerializer.class
        )
        @JsonDeserialize(
                using = LongJsonDeserializer.class
        )
        private Long serialNo = 0L;

        public PutHoldrealdayendSyncInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public String getSettleClob() {
            if (this.settleClob == null) {
                return " ";
            } else {
                return this.settleClob.isEmpty() ? " " : this.settleClob;
            }
        }

        public Integer getSettSysnodeId() {
            return this.settSysnodeId != null ? this.settSysnodeId : 0;
        }

        public Character getTotalType() {
            return this.totalType != null ? this.totalType : ' ';
        }

        public Long getSettBatchNo() {
            return this.settBatchNo != null ? this.settBatchNo : 0L;
        }

        public Long getSerialNo() {
            return this.serialNo != null ? this.serialNo : 0L;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public void setSettleClob(String settleClob) {
            this.settleClob = settleClob;
        }

        public void setSettSysnodeId(Integer settSysnodeId) {
            this.settSysnodeId = settSysnodeId;
        }

        public void setTotalType(Character totalType) {
            this.totalType = totalType;
        }

        public void setSettBatchNo(Long settBatchNo) {
            this.settBatchNo = settBatchNo;
        }

        public void setSerialNo(Long serialNo) {
            this.serialNo = serialNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutHoldrealdayendSyncInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",initDate:" + this.initDate);
            buffer.append(",settleClob:" + this.settleClob);
            buffer.append(",settSysnodeId:" + this.settSysnodeId);
            buffer.append(",totalType:" + this.totalType);
            buffer.append(",settBatchNo:" + this.settBatchNo);
            buffer.append(",serialNo:" + this.serialNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.initDate);
            builder.append(this.settleClob);
            builder.append(this.settSysnodeId);
            builder.append(this.totalType);
            builder.append(this.settBatchNo);
            builder.append(this.serialNo);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PutHoldrealdayendSyncInnerInput obj) {
            if (obj instanceof InnerOptService.PutHoldrealdayendSyncInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, obj.opPassword);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.initDate, obj.initDate);
                builder.append(this.settleClob, obj.settleClob);
                builder.append(this.settSysnodeId, obj.settSysnodeId);
                builder.append(this.totalType, obj.totalType);
                builder.append(this.settBatchNo, obj.settBatchNo);
                builder.append(this.serialNo, obj.serialNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutFundrealdayendSyncInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String fundAccount = " ";
        private String moneyType = " ";
        private String clientId = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character flag = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character exchType = ' ';
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double beginEnableBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double postEnableBalance = 0.0D;

        public PutFundrealdayendSyncInnerOutput() {
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getMoneyType() {
            if (this.moneyType == null) {
                return " ";
            } else {
                return this.moneyType.isEmpty() ? " " : this.moneyType;
            }
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public Character getFlag() {
            return this.flag != null ? this.flag : ' ';
        }

        public Character getExchType() {
            return this.exchType != null ? this.exchType : ' ';
        }

        public Double getBeginEnableBalance() {
            return this.beginEnableBalance != null ? this.beginEnableBalance : 0.0D;
        }

        public Double getPostEnableBalance() {
            return this.postEnableBalance != null ? this.postEnableBalance : 0.0D;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setMoneyType(String moneyType) {
            this.moneyType = moneyType;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setFlag(Character flag) {
            this.flag = flag;
        }

        public void setExchType(Character exchType) {
            this.exchType = exchType;
        }

        public void setBeginEnableBalance(Double beginEnableBalance) {
            this.beginEnableBalance = beginEnableBalance;
        }

        public void setPostEnableBalance(Double postEnableBalance) {
            this.postEnableBalance = postEnableBalance;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutFundrealdayendSyncInnerOutput:(");
            buffer.append("fundAccount:" + this.fundAccount);
            buffer.append(",moneyType:" + this.moneyType);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",flag:" + this.flag);
            buffer.append(",exchType:" + this.exchType);
            buffer.append(",beginEnableBalance:" + this.beginEnableBalance);
            buffer.append(",postEnableBalance:" + this.postEnableBalance);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.fundAccount);
            builder.append(this.moneyType);
            builder.append(this.clientId);
            builder.append(this.flag);
            builder.append(this.exchType);
            builder.append(this.beginEnableBalance);
            builder.append(this.postEnableBalance);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PutFundrealdayendSyncInnerOutput obj) {
            if (obj instanceof InnerOptService.PutFundrealdayendSyncInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.fundAccount, obj.fundAccount);
                builder.append(this.moneyType, obj.moneyType);
                builder.append(this.clientId, obj.clientId);
                builder.append(this.flag, obj.flag);
                builder.append(this.exchType, obj.exchType);
                builder.append(this.beginEnableBalance, obj.beginEnableBalance);
                builder.append(this.postEnableBalance, obj.postEnableBalance);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutFundrealdayendSyncInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        private Integer initDate = 0;
        private String settleClob = " ";
        private Integer settSysnodeId = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character totalType = ' ';
        @JsonSerialize(
                using = LongJsonSerializer.class
        )
        @JsonDeserialize(
                using = LongJsonDeserializer.class
        )
        private Long settBatchNo = 0L;
        @JsonSerialize(
                using = LongJsonSerializer.class
        )
        @JsonDeserialize(
                using = LongJsonDeserializer.class
        )
        private Long serialNo = 0L;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character businessProp = ' ';

        public PutFundrealdayendSyncInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public String getSettleClob() {
            if (this.settleClob == null) {
                return " ";
            } else {
                return this.settleClob.isEmpty() ? " " : this.settleClob;
            }
        }

        public Integer getSettSysnodeId() {
            return this.settSysnodeId != null ? this.settSysnodeId : 0;
        }

        public Character getTotalType() {
            return this.totalType != null ? this.totalType : ' ';
        }

        public Long getSettBatchNo() {
            return this.settBatchNo != null ? this.settBatchNo : 0L;
        }

        public Long getSerialNo() {
            return this.serialNo != null ? this.serialNo : 0L;
        }

        public Character getBusinessProp() {
            return this.businessProp != null ? this.businessProp : ' ';
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public void setSettleClob(String settleClob) {
            this.settleClob = settleClob;
        }

        public void setSettSysnodeId(Integer settSysnodeId) {
            this.settSysnodeId = settSysnodeId;
        }

        public void setTotalType(Character totalType) {
            this.totalType = totalType;
        }

        public void setSettBatchNo(Long settBatchNo) {
            this.settBatchNo = settBatchNo;
        }

        public void setSerialNo(Long serialNo) {
            this.serialNo = serialNo;
        }

        public void setBusinessProp(Character businessProp) {
            this.businessProp = businessProp;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutFundrealdayendSyncInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",initDate:" + this.initDate);
            buffer.append(",settleClob:" + this.settleClob);
            buffer.append(",settSysnodeId:" + this.settSysnodeId);
            buffer.append(",totalType:" + this.totalType);
            buffer.append(",settBatchNo:" + this.settBatchNo);
            buffer.append(",serialNo:" + this.serialNo);
            buffer.append(",businessProp:" + this.businessProp);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.initDate);
            builder.append(this.settleClob);
            builder.append(this.settSysnodeId);
            builder.append(this.totalType);
            builder.append(this.settBatchNo);
            builder.append(this.serialNo);
            builder.append(this.businessProp);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PutFundrealdayendSyncInnerInput obj) {
            if (obj instanceof InnerOptService.PutFundrealdayendSyncInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, obj.opPassword);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.initDate, obj.initDate);
                builder.append(this.settleClob, obj.settleClob);
                builder.append(this.settSysnodeId, obj.settSysnodeId);
                builder.append(this.totalType, obj.totalType);
                builder.append(this.settBatchNo, obj.settBatchNo);
                builder.append(this.serialNo, obj.serialNo);
                builder.append(this.businessProp, obj.businessProp);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutFundrealdayendPayInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String fundAccount = " ";
        private String moneyType = " ";
        private Integer branchNo = 0;
        private Integer errorNo = 0;
        private String settserialNo = " ";
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double dealBalance = 0.0D;
        private String clientId = " ";

        public PutFundrealdayendPayInnerOutput() {
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getMoneyType() {
            if (this.moneyType == null) {
                return " ";
            } else {
                return this.moneyType.isEmpty() ? " " : this.moneyType;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Integer getErrorNo() {
            return this.errorNo != null ? this.errorNo : 0;
        }

        public String getSettserialNo() {
            if (this.settserialNo == null) {
                return " ";
            } else {
                return this.settserialNo.isEmpty() ? " " : this.settserialNo;
            }
        }

        public Double getDealBalance() {
            return this.dealBalance != null ? this.dealBalance : 0.0D;
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setMoneyType(String moneyType) {
            this.moneyType = moneyType;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setErrorNo(Integer errorNo) {
            this.errorNo = errorNo;
        }

        public void setSettserialNo(String settserialNo) {
            this.settserialNo = settserialNo;
        }

        public void setDealBalance(Double dealBalance) {
            this.dealBalance = dealBalance;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutFundrealdayendPayInnerOutput:(");
            buffer.append("fundAccount:" + this.fundAccount);
            buffer.append(",moneyType:" + this.moneyType);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",errorNo:" + this.errorNo);
            buffer.append(",settserialNo:" + this.settserialNo);
            buffer.append(",dealBalance:" + this.dealBalance);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.fundAccount);
            builder.append(this.moneyType);
            builder.append(this.branchNo);
            builder.append(this.errorNo);
            builder.append(this.settserialNo);
            builder.append(this.dealBalance);
            builder.append(this.clientId);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PutFundrealdayendPayInnerOutput obj) {
            if (obj instanceof InnerOptService.PutFundrealdayendPayInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.fundAccount, obj.fundAccount);
                builder.append(this.moneyType, obj.moneyType);
                builder.append(this.branchNo, obj.branchNo);
                builder.append(this.errorNo, obj.errorNo);
                builder.append(this.settserialNo, obj.settserialNo);
                builder.append(this.dealBalance, obj.dealBalance);
                builder.append(this.clientId, obj.clientId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutFundrealdayendPayInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        private Integer initDate = 0;
        private String settleClob = " ";

        public PutFundrealdayendPayInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public String getSettleClob() {
            if (this.settleClob == null) {
                return " ";
            } else {
                return this.settleClob.isEmpty() ? " " : this.settleClob;
            }
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public void setSettleClob(String settleClob) {
            this.settleClob = settleClob;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutFundrealdayendPayInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",initDate:" + this.initDate);
            buffer.append(",settleClob:" + this.settleClob);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.initDate);
            builder.append(this.settleClob);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PutFundrealdayendPayInnerInput obj) {
            if (obj instanceof InnerOptService.PutFundrealdayendPayInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, obj.opPassword);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.initDate, obj.initDate);
                builder.append(this.settleClob, obj.settleClob);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutFundrealdayendLoanInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String positionStr = " ";
        private String fundAccount = " ";
        private String stockCode = " ";
        private String exchangeType = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character loanCompactType = ' ';
        private Integer errorNo = 0;
        private String settserialNo = " ";
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double currentAmount = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double currentBalance = 0.0D;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character loanCompactStatus = ' ';
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double realRepaidBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double realRepaidAmount = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double realRepaidFine = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double realRepaidFare = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double realRepaidInterest = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double repaidCompactBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double repaidCompactAmount = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double repaidCompactFine = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double repaidCompactFare = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double repaidCompactInterest = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double integralBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double fineIntegral = 0.0D;
        @SerializeDoubleDigit(
                digit = 13
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double interestRate = 0.0D;
        @SerializeDoubleDigit(
                digit = 13
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double fineRate = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double settleInterest = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double settleFine = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double fare = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double interest = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double fine = 0.0D;
        private String moneyType = " ";
        private String clientId = " ";

        public PutFundrealdayendLoanInnerOutput() {
        }

        public String getPositionStr() {
            if (this.positionStr == null) {
                return " ";
            } else {
                return this.positionStr.isEmpty() ? " " : this.positionStr;
            }
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getStockCode() {
            if (this.stockCode == null) {
                return " ";
            } else {
                return this.stockCode.isEmpty() ? " " : this.stockCode;
            }
        }

        public String getExchangeType() {
            if (this.exchangeType == null) {
                return " ";
            } else {
                return this.exchangeType.isEmpty() ? " " : this.exchangeType;
            }
        }

        public Character getLoanCompactType() {
            return this.loanCompactType != null ? this.loanCompactType : ' ';
        }

        public Integer getErrorNo() {
            return this.errorNo != null ? this.errorNo : 0;
        }

        public String getSettserialNo() {
            if (this.settserialNo == null) {
                return " ";
            } else {
                return this.settserialNo.isEmpty() ? " " : this.settserialNo;
            }
        }

        public Double getCurrentAmount() {
            return this.currentAmount != null ? this.currentAmount : 0.0D;
        }

        public Double getCurrentBalance() {
            return this.currentBalance != null ? this.currentBalance : 0.0D;
        }

        public Character getLoanCompactStatus() {
            return this.loanCompactStatus != null ? this.loanCompactStatus : ' ';
        }

        public Double getRealRepaidBalance() {
            return this.realRepaidBalance != null ? this.realRepaidBalance : 0.0D;
        }

        public Double getRealRepaidAmount() {
            return this.realRepaidAmount != null ? this.realRepaidAmount : 0.0D;
        }

        public Double getRealRepaidFine() {
            return this.realRepaidFine != null ? this.realRepaidFine : 0.0D;
        }

        public Double getRealRepaidFare() {
            return this.realRepaidFare != null ? this.realRepaidFare : 0.0D;
        }

        public Double getRealRepaidInterest() {
            return this.realRepaidInterest != null ? this.realRepaidInterest : 0.0D;
        }

        public Double getRepaidCompactBalance() {
            return this.repaidCompactBalance != null ? this.repaidCompactBalance : 0.0D;
        }

        public Double getRepaidCompactAmount() {
            return this.repaidCompactAmount != null ? this.repaidCompactAmount : 0.0D;
        }

        public Double getRepaidCompactFine() {
            return this.repaidCompactFine != null ? this.repaidCompactFine : 0.0D;
        }

        public Double getRepaidCompactFare() {
            return this.repaidCompactFare != null ? this.repaidCompactFare : 0.0D;
        }

        public Double getRepaidCompactInterest() {
            return this.repaidCompactInterest != null ? this.repaidCompactInterest : 0.0D;
        }

        public Double getIntegralBalance() {
            return this.integralBalance != null ? this.integralBalance : 0.0D;
        }

        public Double getFineIntegral() {
            return this.fineIntegral != null ? this.fineIntegral : 0.0D;
        }

        public Double getInterestRate() {
            return this.interestRate != null ? this.interestRate : 0.0D;
        }

        public Double getFineRate() {
            return this.fineRate != null ? this.fineRate : 0.0D;
        }

        public Double getSettleInterest() {
            return this.settleInterest != null ? this.settleInterest : 0.0D;
        }

        public Double getSettleFine() {
            return this.settleFine != null ? this.settleFine : 0.0D;
        }

        public Double getFare() {
            return this.fare != null ? this.fare : 0.0D;
        }

        public Double getInterest() {
            return this.interest != null ? this.interest : 0.0D;
        }

        public Double getFine() {
            return this.fine != null ? this.fine : 0.0D;
        }

        public String getMoneyType() {
            if (this.moneyType == null) {
                return " ";
            } else {
                return this.moneyType.isEmpty() ? " " : this.moneyType;
            }
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public void setPositionStr(String positionStr) {
            this.positionStr = positionStr;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setStockCode(String stockCode) {
            this.stockCode = stockCode;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public void setLoanCompactType(Character loanCompactType) {
            this.loanCompactType = loanCompactType;
        }

        public void setErrorNo(Integer errorNo) {
            this.errorNo = errorNo;
        }

        public void setSettserialNo(String settserialNo) {
            this.settserialNo = settserialNo;
        }

        public void setCurrentAmount(Double currentAmount) {
            this.currentAmount = currentAmount;
        }

        public void setCurrentBalance(Double currentBalance) {
            this.currentBalance = currentBalance;
        }

        public void setLoanCompactStatus(Character loanCompactStatus) {
            this.loanCompactStatus = loanCompactStatus;
        }

        public void setRealRepaidBalance(Double realRepaidBalance) {
            this.realRepaidBalance = realRepaidBalance;
        }

        public void setRealRepaidAmount(Double realRepaidAmount) {
            this.realRepaidAmount = realRepaidAmount;
        }

        public void setRealRepaidFine(Double realRepaidFine) {
            this.realRepaidFine = realRepaidFine;
        }

        public void setRealRepaidFare(Double realRepaidFare) {
            this.realRepaidFare = realRepaidFare;
        }

        public void setRealRepaidInterest(Double realRepaidInterest) {
            this.realRepaidInterest = realRepaidInterest;
        }

        public void setRepaidCompactBalance(Double repaidCompactBalance) {
            this.repaidCompactBalance = repaidCompactBalance;
        }

        public void setRepaidCompactAmount(Double repaidCompactAmount) {
            this.repaidCompactAmount = repaidCompactAmount;
        }

        public void setRepaidCompactFine(Double repaidCompactFine) {
            this.repaidCompactFine = repaidCompactFine;
        }

        public void setRepaidCompactFare(Double repaidCompactFare) {
            this.repaidCompactFare = repaidCompactFare;
        }

        public void setRepaidCompactInterest(Double repaidCompactInterest) {
            this.repaidCompactInterest = repaidCompactInterest;
        }

        public void setIntegralBalance(Double integralBalance) {
            this.integralBalance = integralBalance;
        }

        public void setFineIntegral(Double fineIntegral) {
            this.fineIntegral = fineIntegral;
        }

        public void setInterestRate(Double interestRate) {
            this.interestRate = interestRate;
        }

        public void setFineRate(Double fineRate) {
            this.fineRate = fineRate;
        }

        public void setSettleInterest(Double settleInterest) {
            this.settleInterest = settleInterest;
        }

        public void setSettleFine(Double settleFine) {
            this.settleFine = settleFine;
        }

        public void setFare(Double fare) {
            this.fare = fare;
        }

        public void setInterest(Double interest) {
            this.interest = interest;
        }

        public void setFine(Double fine) {
            this.fine = fine;
        }

        public void setMoneyType(String moneyType) {
            this.moneyType = moneyType;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutFundrealdayendLoanInnerOutput:(");
            buffer.append("positionStr:" + this.positionStr);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",stockCode:" + this.stockCode);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(",loanCompactType:" + this.loanCompactType);
            buffer.append(",errorNo:" + this.errorNo);
            buffer.append(",settserialNo:" + this.settserialNo);
            buffer.append(",currentAmount:" + this.currentAmount);
            buffer.append(",currentBalance:" + this.currentBalance);
            buffer.append(",loanCompactStatus:" + this.loanCompactStatus);
            buffer.append(",realRepaidBalance:" + this.realRepaidBalance);
            buffer.append(",realRepaidAmount:" + this.realRepaidAmount);
            buffer.append(",realRepaidFine:" + this.realRepaidFine);
            buffer.append(",realRepaidFare:" + this.realRepaidFare);
            buffer.append(",realRepaidInterest:" + this.realRepaidInterest);
            buffer.append(",repaidCompactBalance:" + this.repaidCompactBalance);
            buffer.append(",repaidCompactAmount:" + this.repaidCompactAmount);
            buffer.append(",repaidCompactFine:" + this.repaidCompactFine);
            buffer.append(",repaidCompactFare:" + this.repaidCompactFare);
            buffer.append(",repaidCompactInterest:" + this.repaidCompactInterest);
            buffer.append(",integralBalance:" + this.integralBalance);
            buffer.append(",fineIntegral:" + this.fineIntegral);
            buffer.append(",interestRate:" + this.interestRate);
            buffer.append(",fineRate:" + this.fineRate);
            buffer.append(",settleInterest:" + this.settleInterest);
            buffer.append(",settleFine:" + this.settleFine);
            buffer.append(",fare:" + this.fare);
            buffer.append(",interest:" + this.interest);
            buffer.append(",fine:" + this.fine);
            buffer.append(",moneyType:" + this.moneyType);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.positionStr);
            builder.append(this.fundAccount);
            builder.append(this.stockCode);
            builder.append(this.exchangeType);
            builder.append(this.loanCompactType);
            builder.append(this.errorNo);
            builder.append(this.settserialNo);
            builder.append(this.currentAmount);
            builder.append(this.currentBalance);
            builder.append(this.loanCompactStatus);
            builder.append(this.realRepaidBalance);
            builder.append(this.realRepaidAmount);
            builder.append(this.realRepaidFine);
            builder.append(this.realRepaidFare);
            builder.append(this.realRepaidInterest);
            builder.append(this.repaidCompactBalance);
            builder.append(this.repaidCompactAmount);
            builder.append(this.repaidCompactFine);
            builder.append(this.repaidCompactFare);
            builder.append(this.repaidCompactInterest);
            builder.append(this.integralBalance);
            builder.append(this.fineIntegral);
            builder.append(this.interestRate);
            builder.append(this.fineRate);
            builder.append(this.settleInterest);
            builder.append(this.settleFine);
            builder.append(this.fare);
            builder.append(this.interest);
            builder.append(this.fine);
            builder.append(this.moneyType);
            builder.append(this.clientId);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PutFundrealdayendLoanInnerOutput obj) {
            if (obj instanceof InnerOptService.PutFundrealdayendLoanInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.positionStr, obj.positionStr);
                builder.append(this.fundAccount, obj.fundAccount);
                builder.append(this.stockCode, obj.stockCode);
                builder.append(this.exchangeType, obj.exchangeType);
                builder.append(this.loanCompactType, obj.loanCompactType);
                builder.append(this.errorNo, obj.errorNo);
                builder.append(this.settserialNo, obj.settserialNo);
                builder.append(this.currentAmount, obj.currentAmount);
                builder.append(this.currentBalance, obj.currentBalance);
                builder.append(this.loanCompactStatus, obj.loanCompactStatus);
                builder.append(this.realRepaidBalance, obj.realRepaidBalance);
                builder.append(this.realRepaidAmount, obj.realRepaidAmount);
                builder.append(this.realRepaidFine, obj.realRepaidFine);
                builder.append(this.realRepaidFare, obj.realRepaidFare);
                builder.append(this.realRepaidInterest, obj.realRepaidInterest);
                builder.append(this.repaidCompactBalance, obj.repaidCompactBalance);
                builder.append(this.repaidCompactAmount, obj.repaidCompactAmount);
                builder.append(this.repaidCompactFine, obj.repaidCompactFine);
                builder.append(this.repaidCompactFare, obj.repaidCompactFare);
                builder.append(this.repaidCompactInterest, obj.repaidCompactInterest);
                builder.append(this.integralBalance, obj.integralBalance);
                builder.append(this.fineIntegral, obj.fineIntegral);
                builder.append(this.interestRate, obj.interestRate);
                builder.append(this.fineRate, obj.fineRate);
                builder.append(this.settleInterest, obj.settleInterest);
                builder.append(this.settleFine, obj.settleFine);
                builder.append(this.fare, obj.fare);
                builder.append(this.interest, obj.interest);
                builder.append(this.fine, obj.fine);
                builder.append(this.moneyType, obj.moneyType);
                builder.append(this.clientId, obj.clientId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutFundrealdayendLoanInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        private Integer initDate = 0;
        private String settleClob = " ";

        public PutFundrealdayendLoanInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public String getSettleClob() {
            if (this.settleClob == null) {
                return " ";
            } else {
                return this.settleClob.isEmpty() ? " " : this.settleClob;
            }
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public void setSettleClob(String settleClob) {
            this.settleClob = settleClob;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutFundrealdayendLoanInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",initDate:" + this.initDate);
            buffer.append(",settleClob:" + this.settleClob);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.initDate);
            builder.append(this.settleClob);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PutFundrealdayendLoanInnerInput obj) {
            if (obj instanceof InnerOptService.PutFundrealdayendLoanInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, obj.opPassword);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.initDate, obj.initDate);
                builder.append(this.settleClob, obj.settleClob);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutFundrealInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double postBalance = 0.0D;
        @JsonSerialize(
                using = LongJsonSerializer.class
        )
        @JsonDeserialize(
                using = LongJsonDeserializer.class
        )
        private Long serialNo = 0L;

        public PutFundrealInnerOutput() {
        }

        public Double getPostBalance() {
            return this.postBalance != null ? this.postBalance : 0.0D;
        }

        public Long getSerialNo() {
            return this.serialNo != null ? this.serialNo : 0L;
        }

        public void setPostBalance(Double postBalance) {
            this.postBalance = postBalance;
        }

        public void setSerialNo(Long serialNo) {
            this.serialNo = serialNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutFundrealInnerOutput:(");
            buffer.append("postBalance:" + this.postBalance);
            buffer.append(",serialNo:" + this.serialNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.postBalance);
            builder.append(this.serialNo);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PutFundrealInnerOutput obj) {
            if (obj instanceof InnerOptService.PutFundrealInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.postBalance, obj.postBalance);
                builder.append(this.serialNo, obj.serialNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutFundrealInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 20,
                charset = "utf-8"
        )
        private String bkSerialNo = " ";
        private Integer branchNo = 0;
        private Integer businessFlag = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String clientId = " ";
        @NotNull(
                message = "不能为空"
        )
        @Digits(
                integer = 13,
                fraction = 2,
                message = "currentBalance value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double currentBalance;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "foregiftBalance value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double foregiftBalance = 0.0D;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "frozenBalance value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double frozenBalance = 0.0D;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String fundAccount;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character fundOverFlag = ' ';
        @NotNull(
                message = "不能为空"
        )
        private Integer initDate;
        @SinogramLength(
                min = 1,
                max = 3,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String moneyType;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "mortgageBalance value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double mortgageBalance = 0.0D;
        @NotNull(
                message = "不能为空"
        )
        @Digits(
                integer = 13,
                fraction = 2,
                message = "occurBalance value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double occurBalance;
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String remark = " ";
        @Digits(
                integer = 13,
                fraction = 2,
                message = "unfrozenBalance value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double unfrozenBalance = 0.0D;

        public PutFundrealInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getBkSerialNo() {
            if (this.bkSerialNo == null) {
                return " ";
            } else {
                return this.bkSerialNo.isEmpty() ? " " : this.bkSerialNo;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Integer getBusinessFlag() {
            return this.businessFlag != null ? this.businessFlag : 0;
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public Double getCurrentBalance() {
            return this.currentBalance;
        }

        public Double getForegiftBalance() {
            return this.foregiftBalance != null ? this.foregiftBalance : 0.0D;
        }

        public Double getFrozenBalance() {
            return this.frozenBalance != null ? this.frozenBalance : 0.0D;
        }

        public String getFundAccount() {
            return this.fundAccount;
        }

        public Character getFundOverFlag() {
            return this.fundOverFlag != null ? this.fundOverFlag : ' ';
        }

        public Integer getInitDate() {
            return this.initDate;
        }

        public String getMoneyType() {
            return this.moneyType;
        }

        public Double getMortgageBalance() {
            return this.mortgageBalance != null ? this.mortgageBalance : 0.0D;
        }

        public Double getOccurBalance() {
            return this.occurBalance;
        }

        public String getRemark() {
            if (this.remark == null) {
                return " ";
            } else {
                return this.remark.isEmpty() ? " " : this.remark;
            }
        }

        public Double getUnfrozenBalance() {
            return this.unfrozenBalance != null ? this.unfrozenBalance : 0.0D;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setBkSerialNo(String bkSerialNo) {
            this.bkSerialNo = bkSerialNo;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setBusinessFlag(Integer businessFlag) {
            this.businessFlag = businessFlag;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setCurrentBalance(Double currentBalance) {
            this.currentBalance = currentBalance;
        }

        public void setForegiftBalance(Double foregiftBalance) {
            this.foregiftBalance = foregiftBalance;
        }

        public void setFrozenBalance(Double frozenBalance) {
            this.frozenBalance = frozenBalance;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setFundOverFlag(Character fundOverFlag) {
            this.fundOverFlag = fundOverFlag;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public void setMoneyType(String moneyType) {
            this.moneyType = moneyType;
        }

        public void setMortgageBalance(Double mortgageBalance) {
            this.mortgageBalance = mortgageBalance;
        }

        public void setOccurBalance(Double occurBalance) {
            this.occurBalance = occurBalance;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public void setUnfrozenBalance(Double unfrozenBalance) {
            this.unfrozenBalance = unfrozenBalance;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutFundrealInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",bkSerialNo:" + this.bkSerialNo);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",businessFlag:" + this.businessFlag);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",currentBalance:" + this.currentBalance);
            buffer.append(",foregiftBalance:" + this.foregiftBalance);
            buffer.append(",frozenBalance:" + this.frozenBalance);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",fundOverFlag:" + this.fundOverFlag);
            buffer.append(",initDate:" + this.initDate);
            buffer.append(",moneyType:" + this.moneyType);
            buffer.append(",mortgageBalance:" + this.mortgageBalance);
            buffer.append(",occurBalance:" + this.occurBalance);
            buffer.append(",remark:" + this.remark);
            buffer.append(",unfrozenBalance:" + this.unfrozenBalance);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.bkSerialNo);
            builder.append(this.branchNo);
            builder.append(this.businessFlag);
            builder.append(this.clientId);
            builder.append(this.currentBalance);
            builder.append(this.foregiftBalance);
            builder.append(this.frozenBalance);
            builder.append(this.fundAccount);
            builder.append(this.fundOverFlag);
            builder.append(this.initDate);
            builder.append(this.moneyType);
            builder.append(this.mortgageBalance);
            builder.append(this.occurBalance);
            builder.append(this.remark);
            builder.append(this.unfrozenBalance);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PutFundrealInnerInput obj) {
            if (obj instanceof InnerOptService.PutFundrealInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, obj.opPassword);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.bkSerialNo, obj.bkSerialNo);
                builder.append(this.branchNo, obj.branchNo);
                builder.append(this.businessFlag, obj.businessFlag);
                builder.append(this.clientId, obj.clientId);
                builder.append(this.currentBalance, obj.currentBalance);
                builder.append(this.foregiftBalance, obj.foregiftBalance);
                builder.append(this.frozenBalance, obj.frozenBalance);
                builder.append(this.fundAccount, obj.fundAccount);
                builder.append(this.fundOverFlag, obj.fundOverFlag);
                builder.append(this.initDate, obj.initDate);
                builder.append(this.moneyType, obj.moneyType);
                builder.append(this.mortgageBalance, obj.mortgageBalance);
                builder.append(this.occurBalance, obj.occurBalance);
                builder.append(this.remark, obj.remark);
                builder.append(this.unfrozenBalance, obj.unfrozenBalance);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutFundaccountCancelInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String fundAccount;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId;

        public PutFundaccountCancelInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getFundAccount() {
            return this.fundAccount;
        }

        public String getClientId() {
            return this.clientId;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutFundaccountCancelInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.fundAccount);
            builder.append(this.clientId);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PutFundaccountCancelInnerInput obj) {
            if (obj instanceof InnerOptService.PutFundaccountCancelInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, obj.opPassword);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.fundAccount, obj.fundAccount);
                builder.append(this.clientId, obj.clientId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutEntrustStatusUpdateInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer dataId = 0;

        public PutEntrustStatusUpdateInnerOutput() {
        }

        public Integer getDataId() {
            return this.dataId != null ? this.dataId : 0;
        }

        public void setDataId(Integer dataId) {
            this.dataId = dataId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutEntrustStatusUpdateInnerOutput:(");
            buffer.append("dataId:" + this.dataId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.dataId);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PutEntrustStatusUpdateInnerOutput obj) {
            if (obj instanceof InnerOptService.PutEntrustStatusUpdateInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.dataId, obj.dataId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutEntrustStatusUpdateInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        private Integer initDate = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character writebackKind = ' ';
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String exchangeType = "";
        @SinogramLength(
                min = 0,
                max = 24,
                charset = "utf-8"
        )
        private String orderId = " ";
        @JsonSerialize(
                using = LongJsonSerializer.class
        )
        @JsonDeserialize(
                using = LongJsonDeserializer.class
        )
        private Long recordNo = 0L;
        private Integer dataId = 0;

        public PutEntrustStatusUpdateInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public Character getWritebackKind() {
            return this.writebackKind != null ? this.writebackKind : ' ';
        }

        public String getExchangeType() {
            if (this.exchangeType == null) {
                return "";
            } else {
                return this.exchangeType.isEmpty() ? "" : this.exchangeType;
            }
        }

        public String getOrderId() {
            if (this.orderId == null) {
                return " ";
            } else {
                return this.orderId.isEmpty() ? " " : this.orderId;
            }
        }

        public Long getRecordNo() {
            return this.recordNo != null ? this.recordNo : 0L;
        }

        public Integer getDataId() {
            return this.dataId != null ? this.dataId : 0;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public void setWritebackKind(Character writebackKind) {
            this.writebackKind = writebackKind;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public void setOrderId(String orderId) {
            this.orderId = orderId;
        }

        public void setRecordNo(Long recordNo) {
            this.recordNo = recordNo;
        }

        public void setDataId(Integer dataId) {
            this.dataId = dataId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutEntrustStatusUpdateInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",initDate:" + this.initDate);
            buffer.append(",writebackKind:" + this.writebackKind);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(",orderId:" + this.orderId);
            buffer.append(",recordNo:" + this.recordNo);
            buffer.append(",dataId:" + this.dataId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.initDate);
            builder.append(this.writebackKind);
            builder.append(this.exchangeType);
            builder.append(this.orderId);
            builder.append(this.recordNo);
            builder.append(this.dataId);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PutEntrustStatusUpdateInnerInput obj) {
            if (obj instanceof InnerOptService.PutEntrustStatusUpdateInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, obj.opPassword);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.initDate, obj.initDate);
                builder.append(this.writebackKind, obj.writebackKind);
                builder.append(this.exchangeType, obj.exchangeType);
                builder.append(this.orderId, obj.orderId);
                builder.append(this.recordNo, obj.recordNo);
                builder.append(this.dataId, obj.dataId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutDayinitinfoTradePrepareInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character showFlag = ' ';
        private Integer initDate = 0;

        public PutDayinitinfoTradePrepareInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public Character getShowFlag() {
            return this.showFlag != null ? this.showFlag : ' ';
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setShowFlag(Character showFlag) {
            this.showFlag = showFlag;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutDayinitinfoTradePrepareInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",showFlag:" + this.showFlag);
            buffer.append(",initDate:" + this.initDate);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.showFlag);
            builder.append(this.initDate);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PutDayinitinfoTradePrepareInnerInput obj) {
            if (obj instanceof InnerOptService.PutDayinitinfoTradePrepareInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, obj.opPassword);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.showFlag, obj.showFlag);
                builder.append(this.initDate, obj.initDate);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutDayinitinfoPayFundFrozenInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        private Integer initDate = 0;

        public PutDayinitinfoPayFundFrozenInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutDayinitinfoPayFundFrozenInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",initDate:" + this.initDate);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.initDate);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PutDayinitinfoPayFundFrozenInnerInput obj) {
            if (obj instanceof InnerOptService.PutDayinitinfoPayFundFrozenInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, obj.opPassword);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.initDate, obj.initDate);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutDayinitinfoExcutePrevInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";

        public PutDayinitinfoExcutePrevInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutDayinitinfoExcutePrevInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PutDayinitinfoExcutePrevInnerInput obj) {
            if (obj instanceof InnerOptService.PutDayinitinfoExcutePrevInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, obj.opPassword);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutDayinitinfoDateChangeInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer initDate = 0;

        public PutDayinitinfoDateChangeInnerOutput() {
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutDayinitinfoDateChangeInnerOutput:(");
            buffer.append("initDate:" + this.initDate);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.initDate);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PutDayinitinfoDateChangeInnerOutput obj) {
            if (obj instanceof InnerOptService.PutDayinitinfoDateChangeInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.initDate, obj.initDate);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutDayinitinfoDateChangeInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";

        public PutDayinitinfoDateChangeInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutDayinitinfoDateChangeInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PutDayinitinfoDateChangeInnerInput obj) {
            if (obj instanceof InnerOptService.PutDayinitinfoDateChangeInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, obj.opPassword);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutDayinitinfoDataInitInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer initDate = 0;

        public PutDayinitinfoDataInitInnerOutput() {
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutDayinitinfoDataInitInnerOutput:(");
            buffer.append("initDate:" + this.initDate);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.initDate);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PutDayinitinfoDataInitInnerOutput obj) {
            if (obj instanceof InnerOptService.PutDayinitinfoDataInitInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.initDate, obj.initDate);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutDayinitinfoDataInitInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";

        public PutDayinitinfoDataInitInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutDayinitinfoDataInitInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PutDayinitinfoDataInitInnerInput obj) {
            if (obj instanceof InnerOptService.PutDayinitinfoDataInitInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, obj.opPassword);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutDayinitinfoBatchDealInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer rowcount = 0;

        public PutDayinitinfoBatchDealInnerOutput() {
        }

        public Integer getRowcount() {
            return this.rowcount != null ? this.rowcount : 0;
        }

        public void setRowcount(Integer rowcount) {
            this.rowcount = rowcount;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutDayinitinfoBatchDealInnerOutput:(");
            buffer.append("rowcount:" + this.rowcount);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.rowcount);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PutDayinitinfoBatchDealInnerOutput obj) {
            if (obj instanceof InnerOptService.PutDayinitinfoBatchDealInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.rowcount, obj.rowcount);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutDayinitinfoBatchDealInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 180,
                charset = "utf-8"
        )
        private String tableName = " ";
        private Integer initDate = 0;
        @JsonSerialize(
                using = LongJsonSerializer.class
        )
        @JsonDeserialize(
                using = LongJsonDeserializer.class
        )
        private Long serialNo = 0L;
        private String settleClob = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String joinTableName = " ";

        public PutDayinitinfoBatchDealInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getTableName() {
            if (this.tableName == null) {
                return " ";
            } else {
                return this.tableName.isEmpty() ? " " : this.tableName;
            }
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public Long getSerialNo() {
            return this.serialNo != null ? this.serialNo : 0L;
        }

        public String getSettleClob() {
            if (this.settleClob == null) {
                return " ";
            } else {
                return this.settleClob.isEmpty() ? " " : this.settleClob;
            }
        }

        public String getJoinTableName() {
            if (this.joinTableName == null) {
                return " ";
            } else {
                return this.joinTableName.isEmpty() ? " " : this.joinTableName;
            }
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setTableName(String tableName) {
            this.tableName = tableName;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public void setSerialNo(Long serialNo) {
            this.serialNo = serialNo;
        }

        public void setSettleClob(String settleClob) {
            this.settleClob = settleClob;
        }

        public void setJoinTableName(String joinTableName) {
            this.joinTableName = joinTableName;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutDayinitinfoBatchDealInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",tableName:" + this.tableName);
            buffer.append(",initDate:" + this.initDate);
            buffer.append(",serialNo:" + this.serialNo);
            buffer.append(",settleClob:" + this.settleClob);
            buffer.append(",joinTableName:" + this.joinTableName);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.tableName);
            builder.append(this.initDate);
            builder.append(this.serialNo);
            builder.append(this.settleClob);
            builder.append(this.joinTableName);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PutDayinitinfoBatchDealInnerInput obj) {
            if (obj instanceof InnerOptService.PutDayinitinfoBatchDealInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, obj.opPassword);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.tableName, obj.tableName);
                builder.append(this.initDate, obj.initDate);
                builder.append(this.serialNo, obj.serialNo);
                builder.append(this.settleClob, obj.settleClob);
                builder.append(this.joinTableName, obj.joinTableName);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutCombholdrealdayendSyncInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String fundAccount = " ";
        private String exchangeType = " ";
        private String clientId = " ";
        private String optcombId = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character flag = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character exchType = ' ';
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double beginEnableAmount = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double postEnableAmount = 0.0D;
        private String optcombCode = " ";

        public PutCombholdrealdayendSyncInnerOutput() {
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getExchangeType() {
            if (this.exchangeType == null) {
                return " ";
            } else {
                return this.exchangeType.isEmpty() ? " " : this.exchangeType;
            }
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getOptcombId() {
            if (this.optcombId == null) {
                return " ";
            } else {
                return this.optcombId.isEmpty() ? " " : this.optcombId;
            }
        }

        public Character getFlag() {
            return this.flag != null ? this.flag : ' ';
        }

        public Character getExchType() {
            return this.exchType != null ? this.exchType : ' ';
        }

        public Double getBeginEnableAmount() {
            return this.beginEnableAmount != null ? this.beginEnableAmount : 0.0D;
        }

        public Double getPostEnableAmount() {
            return this.postEnableAmount != null ? this.postEnableAmount : 0.0D;
        }

        public String getOptcombCode() {
            if (this.optcombCode == null) {
                return " ";
            } else {
                return this.optcombCode.isEmpty() ? " " : this.optcombCode;
            }
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setOptcombId(String optcombId) {
            this.optcombId = optcombId;
        }

        public void setFlag(Character flag) {
            this.flag = flag;
        }

        public void setExchType(Character exchType) {
            this.exchType = exchType;
        }

        public void setBeginEnableAmount(Double beginEnableAmount) {
            this.beginEnableAmount = beginEnableAmount;
        }

        public void setPostEnableAmount(Double postEnableAmount) {
            this.postEnableAmount = postEnableAmount;
        }

        public void setOptcombCode(String optcombCode) {
            this.optcombCode = optcombCode;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutCombholdrealdayendSyncInnerOutput:(");
            buffer.append("fundAccount:" + this.fundAccount);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",optcombId:" + this.optcombId);
            buffer.append(",flag:" + this.flag);
            buffer.append(",exchType:" + this.exchType);
            buffer.append(",beginEnableAmount:" + this.beginEnableAmount);
            buffer.append(",postEnableAmount:" + this.postEnableAmount);
            buffer.append(",optcombCode:" + this.optcombCode);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.fundAccount);
            builder.append(this.exchangeType);
            builder.append(this.clientId);
            builder.append(this.optcombId);
            builder.append(this.flag);
            builder.append(this.exchType);
            builder.append(this.beginEnableAmount);
            builder.append(this.postEnableAmount);
            builder.append(this.optcombCode);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PutCombholdrealdayendSyncInnerOutput obj) {
            if (obj instanceof InnerOptService.PutCombholdrealdayendSyncInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.fundAccount, obj.fundAccount);
                builder.append(this.exchangeType, obj.exchangeType);
                builder.append(this.clientId, obj.clientId);
                builder.append(this.optcombId, obj.optcombId);
                builder.append(this.flag, obj.flag);
                builder.append(this.exchType, obj.exchType);
                builder.append(this.beginEnableAmount, obj.beginEnableAmount);
                builder.append(this.postEnableAmount, obj.postEnableAmount);
                builder.append(this.optcombCode, obj.optcombCode);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutCombholdrealdayendSyncInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        private Integer initDate = 0;
        private String settleClob = " ";
        private Integer settSysnodeId = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character totalType = ' ';
        @JsonSerialize(
                using = LongJsonSerializer.class
        )
        @JsonDeserialize(
                using = LongJsonDeserializer.class
        )
        private Long settBatchNo = 0L;
        @JsonSerialize(
                using = LongJsonSerializer.class
        )
        @JsonDeserialize(
                using = LongJsonDeserializer.class
        )
        private Long serialNo = 0L;

        public PutCombholdrealdayendSyncInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public String getSettleClob() {
            if (this.settleClob == null) {
                return " ";
            } else {
                return this.settleClob.isEmpty() ? " " : this.settleClob;
            }
        }

        public Integer getSettSysnodeId() {
            return this.settSysnodeId != null ? this.settSysnodeId : 0;
        }

        public Character getTotalType() {
            return this.totalType != null ? this.totalType : ' ';
        }

        public Long getSettBatchNo() {
            return this.settBatchNo != null ? this.settBatchNo : 0L;
        }

        public Long getSerialNo() {
            return this.serialNo != null ? this.serialNo : 0L;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public void setSettleClob(String settleClob) {
            this.settleClob = settleClob;
        }

        public void setSettSysnodeId(Integer settSysnodeId) {
            this.settSysnodeId = settSysnodeId;
        }

        public void setTotalType(Character totalType) {
            this.totalType = totalType;
        }

        public void setSettBatchNo(Long settBatchNo) {
            this.settBatchNo = settBatchNo;
        }

        public void setSerialNo(Long serialNo) {
            this.serialNo = serialNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutCombholdrealdayendSyncInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",initDate:" + this.initDate);
            buffer.append(",settleClob:" + this.settleClob);
            buffer.append(",settSysnodeId:" + this.settSysnodeId);
            buffer.append(",totalType:" + this.totalType);
            buffer.append(",settBatchNo:" + this.settBatchNo);
            buffer.append(",serialNo:" + this.serialNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.initDate);
            builder.append(this.settleClob);
            builder.append(this.settSysnodeId);
            builder.append(this.totalType);
            builder.append(this.settBatchNo);
            builder.append(this.serialNo);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PutCombholdrealdayendSyncInnerInput obj) {
            if (obj instanceof InnerOptService.PutCombholdrealdayendSyncInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, obj.opPassword);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.initDate, obj.initDate);
                builder.append(this.settleClob, obj.settleClob);
                builder.append(this.settSysnodeId, obj.settSysnodeId);
                builder.append(this.totalType, obj.totalType);
                builder.append(this.settBatchNo, obj.settBatchNo);
                builder.append(this.serialNo, obj.serialNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutCombargInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String errorInfo = " ";
        private Integer errorNo = 0;

        public PutCombargInnerOutput() {
        }

        public String getErrorInfo() {
            if (this.errorInfo == null) {
                return " ";
            } else {
                return this.errorInfo.isEmpty() ? " " : this.errorInfo;
            }
        }

        public Integer getErrorNo() {
            return this.errorNo != null ? this.errorNo : 0;
        }

        public void setErrorInfo(String errorInfo) {
            this.errorInfo = errorInfo;
        }

        public void setErrorNo(Integer errorNo) {
            this.errorNo = errorNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutCombargInnerOutput:(");
            buffer.append("errorInfo:" + this.errorInfo);
            buffer.append(",errorNo:" + this.errorNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.errorInfo);
            builder.append(this.errorNo);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PutCombargInnerOutput obj) {
            if (obj instanceof InnerOptService.PutCombargInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.errorInfo, obj.errorInfo);
                builder.append(this.errorNo, obj.errorNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutCombargInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String exchangeType = " ";
        @SinogramLength(
                min = 0,
                max = 8,
                charset = "utf-8"
        )
        private String optcombCode = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String optcombName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character enddateSameFlag = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character underlySameFlag = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character unitSameFlag = ' ';
        private Integer componentCount = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character firstOptionType = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character firstOptholdType = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character firstExepriceNum = ' ';
        private Integer firstPerOptamount = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character secondOptionType = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character secondOptholdType = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character secondExepriceNum = ' ';
        private Integer secondPerOptamount = 0;
        private Integer firstEnddateNum = 0;
        private Integer secondEnddateNum = 0;
        private Integer nearSplitDays = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character standardCodeFlag = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character coveredFlag = ' ';

        public PutCombargInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getExchangeType() {
            if (this.exchangeType == null) {
                return " ";
            } else {
                return this.exchangeType.isEmpty() ? " " : this.exchangeType;
            }
        }

        public String getOptcombCode() {
            if (this.optcombCode == null) {
                return " ";
            } else {
                return this.optcombCode.isEmpty() ? " " : this.optcombCode;
            }
        }

        public String getOptcombName() {
            if (this.optcombName == null) {
                return " ";
            } else {
                return this.optcombName.isEmpty() ? " " : this.optcombName;
            }
        }

        public Character getEnddateSameFlag() {
            return this.enddateSameFlag != null ? this.enddateSameFlag : ' ';
        }

        public Character getUnderlySameFlag() {
            return this.underlySameFlag != null ? this.underlySameFlag : ' ';
        }

        public Character getUnitSameFlag() {
            return this.unitSameFlag != null ? this.unitSameFlag : ' ';
        }

        public Integer getComponentCount() {
            return this.componentCount != null ? this.componentCount : 0;
        }

        public Character getFirstOptionType() {
            return this.firstOptionType != null ? this.firstOptionType : ' ';
        }

        public Character getFirstOptholdType() {
            return this.firstOptholdType != null ? this.firstOptholdType : ' ';
        }

        public Character getFirstExepriceNum() {
            return this.firstExepriceNum != null ? this.firstExepriceNum : ' ';
        }

        public Integer getFirstPerOptamount() {
            return this.firstPerOptamount != null ? this.firstPerOptamount : 0;
        }

        public Character getSecondOptionType() {
            return this.secondOptionType != null ? this.secondOptionType : ' ';
        }

        public Character getSecondOptholdType() {
            return this.secondOptholdType != null ? this.secondOptholdType : ' ';
        }

        public Character getSecondExepriceNum() {
            return this.secondExepriceNum != null ? this.secondExepriceNum : ' ';
        }

        public Integer getSecondPerOptamount() {
            return this.secondPerOptamount != null ? this.secondPerOptamount : 0;
        }

        public Integer getFirstEnddateNum() {
            return this.firstEnddateNum != null ? this.firstEnddateNum : 0;
        }

        public Integer getSecondEnddateNum() {
            return this.secondEnddateNum != null ? this.secondEnddateNum : 0;
        }

        public Integer getNearSplitDays() {
            return this.nearSplitDays != null ? this.nearSplitDays : 0;
        }

        public Character getStandardCodeFlag() {
            return this.standardCodeFlag != null ? this.standardCodeFlag : ' ';
        }

        public Character getCoveredFlag() {
            return this.coveredFlag != null ? this.coveredFlag : ' ';
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public void setOptcombCode(String optcombCode) {
            this.optcombCode = optcombCode;
        }

        public void setOptcombName(String optcombName) {
            this.optcombName = optcombName;
        }

        public void setEnddateSameFlag(Character enddateSameFlag) {
            this.enddateSameFlag = enddateSameFlag;
        }

        public void setUnderlySameFlag(Character underlySameFlag) {
            this.underlySameFlag = underlySameFlag;
        }

        public void setUnitSameFlag(Character unitSameFlag) {
            this.unitSameFlag = unitSameFlag;
        }

        public void setComponentCount(Integer componentCount) {
            this.componentCount = componentCount;
        }

        public void setFirstOptionType(Character firstOptionType) {
            this.firstOptionType = firstOptionType;
        }

        public void setFirstOptholdType(Character firstOptholdType) {
            this.firstOptholdType = firstOptholdType;
        }

        public void setFirstExepriceNum(Character firstExepriceNum) {
            this.firstExepriceNum = firstExepriceNum;
        }

        public void setFirstPerOptamount(Integer firstPerOptamount) {
            this.firstPerOptamount = firstPerOptamount;
        }

        public void setSecondOptionType(Character secondOptionType) {
            this.secondOptionType = secondOptionType;
        }

        public void setSecondOptholdType(Character secondOptholdType) {
            this.secondOptholdType = secondOptholdType;
        }

        public void setSecondExepriceNum(Character secondExepriceNum) {
            this.secondExepriceNum = secondExepriceNum;
        }

        public void setSecondPerOptamount(Integer secondPerOptamount) {
            this.secondPerOptamount = secondPerOptamount;
        }

        public void setFirstEnddateNum(Integer firstEnddateNum) {
            this.firstEnddateNum = firstEnddateNum;
        }

        public void setSecondEnddateNum(Integer secondEnddateNum) {
            this.secondEnddateNum = secondEnddateNum;
        }

        public void setNearSplitDays(Integer nearSplitDays) {
            this.nearSplitDays = nearSplitDays;
        }

        public void setStandardCodeFlag(Character standardCodeFlag) {
            this.standardCodeFlag = standardCodeFlag;
        }

        public void setCoveredFlag(Character coveredFlag) {
            this.coveredFlag = coveredFlag;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutCombargInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(",optcombCode:" + this.optcombCode);
            buffer.append(",optcombName:" + this.optcombName);
            buffer.append(",enddateSameFlag:" + this.enddateSameFlag);
            buffer.append(",underlySameFlag:" + this.underlySameFlag);
            buffer.append(",unitSameFlag:" + this.unitSameFlag);
            buffer.append(",componentCount:" + this.componentCount);
            buffer.append(",firstOptionType:" + this.firstOptionType);
            buffer.append(",firstOptholdType:" + this.firstOptholdType);
            buffer.append(",firstExepriceNum:" + this.firstExepriceNum);
            buffer.append(",firstPerOptamount:" + this.firstPerOptamount);
            buffer.append(",secondOptionType:" + this.secondOptionType);
            buffer.append(",secondOptholdType:" + this.secondOptholdType);
            buffer.append(",secondExepriceNum:" + this.secondExepriceNum);
            buffer.append(",secondPerOptamount:" + this.secondPerOptamount);
            buffer.append(",firstEnddateNum:" + this.firstEnddateNum);
            buffer.append(",secondEnddateNum:" + this.secondEnddateNum);
            buffer.append(",nearSplitDays:" + this.nearSplitDays);
            buffer.append(",standardCodeFlag:" + this.standardCodeFlag);
            buffer.append(",coveredFlag:" + this.coveredFlag);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.exchangeType);
            builder.append(this.optcombCode);
            builder.append(this.optcombName);
            builder.append(this.enddateSameFlag);
            builder.append(this.underlySameFlag);
            builder.append(this.unitSameFlag);
            builder.append(this.componentCount);
            builder.append(this.firstOptionType);
            builder.append(this.firstOptholdType);
            builder.append(this.firstExepriceNum);
            builder.append(this.firstPerOptamount);
            builder.append(this.secondOptionType);
            builder.append(this.secondOptholdType);
            builder.append(this.secondExepriceNum);
            builder.append(this.secondPerOptamount);
            builder.append(this.firstEnddateNum);
            builder.append(this.secondEnddateNum);
            builder.append(this.nearSplitDays);
            builder.append(this.standardCodeFlag);
            builder.append(this.coveredFlag);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PutCombargInnerInput obj) {
            if (obj instanceof InnerOptService.PutCombargInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, obj.opPassword);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.exchangeType, obj.exchangeType);
                builder.append(this.optcombCode, obj.optcombCode);
                builder.append(this.optcombName, obj.optcombName);
                builder.append(this.enddateSameFlag, obj.enddateSameFlag);
                builder.append(this.underlySameFlag, obj.underlySameFlag);
                builder.append(this.unitSameFlag, obj.unitSameFlag);
                builder.append(this.componentCount, obj.componentCount);
                builder.append(this.firstOptionType, obj.firstOptionType);
                builder.append(this.firstOptholdType, obj.firstOptholdType);
                builder.append(this.firstExepriceNum, obj.firstExepriceNum);
                builder.append(this.firstPerOptamount, obj.firstPerOptamount);
                builder.append(this.secondOptionType, obj.secondOptionType);
                builder.append(this.secondOptholdType, obj.secondOptholdType);
                builder.append(this.secondExepriceNum, obj.secondExepriceNum);
                builder.append(this.secondPerOptamount, obj.secondPerOptamount);
                builder.append(this.firstEnddateNum, obj.firstEnddateNum);
                builder.append(this.secondEnddateNum, obj.secondEnddateNum);
                builder.append(this.nearSplitDays, obj.nearSplitDays);
                builder.append(this.standardCodeFlag, obj.standardCodeFlag);
                builder.append(this.coveredFlag, obj.coveredFlag);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutCodeInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String errorInfo = " ";
        private Integer errorNo = 0;

        public PutCodeInnerOutput() {
        }

        public String getErrorInfo() {
            if (this.errorInfo == null) {
                return " ";
            } else {
                return this.errorInfo.isEmpty() ? " " : this.errorInfo;
            }
        }

        public Integer getErrorNo() {
            return this.errorNo != null ? this.errorNo : 0;
        }

        public void setErrorInfo(String errorInfo) {
            this.errorInfo = errorInfo;
        }

        public void setErrorNo(Integer errorNo) {
            this.errorNo = errorNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutCodeInnerOutput:(");
            buffer.append("errorInfo:" + this.errorInfo);
            buffer.append(",errorNo:" + this.errorNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.errorInfo);
            builder.append(this.errorNo);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PutCodeInnerOutput obj) {
            if (obj instanceof InnerOptService.PutCodeInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.errorInfo, obj.errorInfo);
                builder.append(this.errorNo, obj.errorNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutCodeInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        private Integer amountPerHand = 0;
        private Integer beginDate = 0;
        @Digits(
                integer = 15,
                fraction = 8,
                message = "closePrice value out of bounds, integer=15, fraction=8"
        )
        @SerializeDoubleDigit(
                digit = 8
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double closePrice = 0.0D;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character combLimitFlag = ' ';
        private Integer deliverDate = 0;
        private Integer dropUnit = 0;
        private Integer endDate = 0;
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String exchangeType = " ";
        private Integer exeBeginDate = 0;
        private Integer exeEndDate = 0;
        @Digits(
                integer = 6,
                fraction = 6,
                message = "exercisePrice value out of bounds, integer=6, fraction=6"
        )
        @SerializeDoubleDigit(
                digit = 6
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double exercisePrice = 0.0D;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "initperBalance value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double initperBalance = 0.0D;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "limitHighAmount value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double limitHighAmount = 0.0D;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "limitLowAmount value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double limitLowAmount = 0.0D;
        @Digits(
                integer = 11,
                fraction = 4,
                message = "marginRatio1 value out of bounds, integer=11, fraction=4"
        )
        @SerializeDoubleDigit(
                digit = 4
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double marginRatio1 = 0.0D;
        @Digits(
                integer = 11,
                fraction = 4,
                message = "marginRatio2 value out of bounds, integer=11, fraction=4"
        )
        @SerializeDoubleDigit(
                digit = 4
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double marginRatio2 = 0.0D;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "mktHighAmount value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double mktHighAmount = 0.0D;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "mktLowAmount value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double mktLowAmount = 0.0D;
        @SinogramLength(
                min = 0,
                max = 3,
                charset = "utf-8"
        )
        private String moneyType = " ";
        private Integer openUnit = 0;
        @Digits(
                integer = 6,
                fraction = 6,
                message = "optClosePrice value out of bounds, integer=6, fraction=6"
        )
        @SerializeDoubleDigit(
                digit = 6
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double optClosePrice = 0.0D;
        @Digits(
                integer = 6,
                fraction = 6,
                message = "optDownPrice value out of bounds, integer=6, fraction=6"
        )
        @SerializeDoubleDigit(
                digit = 6
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double optDownPrice = 0.0D;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character optFinalStatus = ' ';
        @Digits(
                integer = 6,
                fraction = 6,
                message = "optLastPrice value out of bounds, integer=6, fraction=6"
        )
        @SerializeDoubleDigit(
                digit = 6
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double optLastPrice = 0.0D;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String optOpenRestriction = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character optOpenStatus = ' ';
        @Digits(
                integer = 6,
                fraction = 6,
                message = "optPriceStep value out of bounds, integer=6, fraction=6"
        )
        @SerializeDoubleDigit(
                digit = 6
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double optPriceStep = 0.0D;
        @Digits(
                integer = 6,
                fraction = 6,
                message = "optUpPrice value out of bounds, integer=6, fraction=6"
        )
        @SerializeDoubleDigit(
                digit = 6
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double optUpPrice = 0.0D;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character optUpdatedStatus = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character optcodeStatus = ' ';
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String optcombCodeStr = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String optcontractId = " ";
        @SinogramLength(
                min = 0,
                max = 8,
                charset = "utf-8"
        )
        private String optionCode = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character optionFlag = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character optionMode = ' ';
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String optionName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character optionType = ' ';
        private Integer optionVersion = 0;
        @Digits(
                integer = 6,
                fraction = 6,
                message = "preSquarePrice value out of bounds, integer=6, fraction=6"
        )
        @SerializeDoubleDigit(
                digit = 6
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double preSquarePrice = 0.0D;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character priceLimitKind = ' ';
        @SinogramLength(
                min = 0,
                max = 8,
                charset = "utf-8"
        )
        private String stockCode = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String stockName = " ";
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String stockType = " ";
        private Integer storeUnit = 0;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "undropAmount value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double undropAmount = 0.0D;
        private Integer verticalSplitDate = 0;
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String verticalSplitDateStr = " ";

        public PutCodeInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public Integer getAmountPerHand() {
            return this.amountPerHand != null ? this.amountPerHand : 0;
        }

        public Integer getBeginDate() {
            return this.beginDate != null ? this.beginDate : 0;
        }

        public Double getClosePrice() {
            return this.closePrice != null ? this.closePrice : 0.0D;
        }

        public Character getCombLimitFlag() {
            return this.combLimitFlag != null ? this.combLimitFlag : ' ';
        }

        public Integer getDeliverDate() {
            return this.deliverDate != null ? this.deliverDate : 0;
        }

        public Integer getDropUnit() {
            return this.dropUnit != null ? this.dropUnit : 0;
        }

        public Integer getEndDate() {
            return this.endDate != null ? this.endDate : 0;
        }

        public String getExchangeType() {
            if (this.exchangeType == null) {
                return " ";
            } else {
                return this.exchangeType.isEmpty() ? " " : this.exchangeType;
            }
        }

        public Integer getExeBeginDate() {
            return this.exeBeginDate != null ? this.exeBeginDate : 0;
        }

        public Integer getExeEndDate() {
            return this.exeEndDate != null ? this.exeEndDate : 0;
        }

        public Double getExercisePrice() {
            return this.exercisePrice != null ? this.exercisePrice : 0.0D;
        }

        public Double getInitperBalance() {
            return this.initperBalance != null ? this.initperBalance : 0.0D;
        }

        public Double getLimitHighAmount() {
            return this.limitHighAmount != null ? this.limitHighAmount : 0.0D;
        }

        public Double getLimitLowAmount() {
            return this.limitLowAmount != null ? this.limitLowAmount : 0.0D;
        }

        public Double getMarginRatio1() {
            return this.marginRatio1 != null ? this.marginRatio1 : 0.0D;
        }

        public Double getMarginRatio2() {
            return this.marginRatio2 != null ? this.marginRatio2 : 0.0D;
        }

        public Double getMktHighAmount() {
            return this.mktHighAmount != null ? this.mktHighAmount : 0.0D;
        }

        public Double getMktLowAmount() {
            return this.mktLowAmount != null ? this.mktLowAmount : 0.0D;
        }

        public String getMoneyType() {
            if (this.moneyType == null) {
                return " ";
            } else {
                return this.moneyType.isEmpty() ? " " : this.moneyType;
            }
        }

        public Integer getOpenUnit() {
            return this.openUnit != null ? this.openUnit : 0;
        }

        public Double getOptClosePrice() {
            return this.optClosePrice != null ? this.optClosePrice : 0.0D;
        }

        public Double getOptDownPrice() {
            return this.optDownPrice != null ? this.optDownPrice : 0.0D;
        }

        public Character getOptFinalStatus() {
            return this.optFinalStatus != null ? this.optFinalStatus : ' ';
        }

        public Double getOptLastPrice() {
            return this.optLastPrice != null ? this.optLastPrice : 0.0D;
        }

        public String getOptOpenRestriction() {
            if (this.optOpenRestriction == null) {
                return " ";
            } else {
                return this.optOpenRestriction.isEmpty() ? " " : this.optOpenRestriction;
            }
        }

        public Character getOptOpenStatus() {
            return this.optOpenStatus != null ? this.optOpenStatus : ' ';
        }

        public Double getOptPriceStep() {
            return this.optPriceStep != null ? this.optPriceStep : 0.0D;
        }

        public Double getOptUpPrice() {
            return this.optUpPrice != null ? this.optUpPrice : 0.0D;
        }

        public Character getOptUpdatedStatus() {
            return this.optUpdatedStatus != null ? this.optUpdatedStatus : ' ';
        }

        public Character getOptcodeStatus() {
            return this.optcodeStatus != null ? this.optcodeStatus : ' ';
        }

        public String getOptcombCodeStr() {
            if (this.optcombCodeStr == null) {
                return " ";
            } else {
                return this.optcombCodeStr.isEmpty() ? " " : this.optcombCodeStr;
            }
        }

        public String getOptcontractId() {
            if (this.optcontractId == null) {
                return " ";
            } else {
                return this.optcontractId.isEmpty() ? " " : this.optcontractId;
            }
        }

        public String getOptionCode() {
            if (this.optionCode == null) {
                return " ";
            } else {
                return this.optionCode.isEmpty() ? " " : this.optionCode;
            }
        }

        public Character getOptionFlag() {
            return this.optionFlag != null ? this.optionFlag : ' ';
        }

        public Character getOptionMode() {
            return this.optionMode != null ? this.optionMode : ' ';
        }

        public String getOptionName() {
            if (this.optionName == null) {
                return " ";
            } else {
                return this.optionName.isEmpty() ? " " : this.optionName;
            }
        }

        public Character getOptionType() {
            return this.optionType != null ? this.optionType : ' ';
        }

        public Integer getOptionVersion() {
            return this.optionVersion != null ? this.optionVersion : 0;
        }

        public Double getPreSquarePrice() {
            return this.preSquarePrice != null ? this.preSquarePrice : 0.0D;
        }

        public Character getPriceLimitKind() {
            return this.priceLimitKind != null ? this.priceLimitKind : ' ';
        }

        public String getStockCode() {
            if (this.stockCode == null) {
                return " ";
            } else {
                return this.stockCode.isEmpty() ? " " : this.stockCode;
            }
        }

        public String getStockName() {
            if (this.stockName == null) {
                return " ";
            } else {
                return this.stockName.isEmpty() ? " " : this.stockName;
            }
        }

        public String getStockType() {
            if (this.stockType == null) {
                return " ";
            } else {
                return this.stockType.isEmpty() ? " " : this.stockType;
            }
        }

        public Integer getStoreUnit() {
            return this.storeUnit != null ? this.storeUnit : 0;
        }

        public Double getUndropAmount() {
            return this.undropAmount != null ? this.undropAmount : 0.0D;
        }

        public Integer getVerticalSplitDate() {
            return this.verticalSplitDate != null ? this.verticalSplitDate : 0;
        }

        public String getVerticalSplitDateStr() {
            if (this.verticalSplitDateStr == null) {
                return " ";
            } else {
                return this.verticalSplitDateStr.isEmpty() ? " " : this.verticalSplitDateStr;
            }
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setAmountPerHand(Integer amountPerHand) {
            this.amountPerHand = amountPerHand;
        }

        public void setBeginDate(Integer beginDate) {
            this.beginDate = beginDate;
        }

        public void setClosePrice(Double closePrice) {
            this.closePrice = closePrice;
        }

        public void setCombLimitFlag(Character combLimitFlag) {
            this.combLimitFlag = combLimitFlag;
        }

        public void setDeliverDate(Integer deliverDate) {
            this.deliverDate = deliverDate;
        }

        public void setDropUnit(Integer dropUnit) {
            this.dropUnit = dropUnit;
        }

        public void setEndDate(Integer endDate) {
            this.endDate = endDate;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public void setExeBeginDate(Integer exeBeginDate) {
            this.exeBeginDate = exeBeginDate;
        }

        public void setExeEndDate(Integer exeEndDate) {
            this.exeEndDate = exeEndDate;
        }

        public void setExercisePrice(Double exercisePrice) {
            this.exercisePrice = exercisePrice;
        }

        public void setInitperBalance(Double initperBalance) {
            this.initperBalance = initperBalance;
        }

        public void setLimitHighAmount(Double limitHighAmount) {
            this.limitHighAmount = limitHighAmount;
        }

        public void setLimitLowAmount(Double limitLowAmount) {
            this.limitLowAmount = limitLowAmount;
        }

        public void setMarginRatio1(Double marginRatio1) {
            this.marginRatio1 = marginRatio1;
        }

        public void setMarginRatio2(Double marginRatio2) {
            this.marginRatio2 = marginRatio2;
        }

        public void setMktHighAmount(Double mktHighAmount) {
            this.mktHighAmount = mktHighAmount;
        }

        public void setMktLowAmount(Double mktLowAmount) {
            this.mktLowAmount = mktLowAmount;
        }

        public void setMoneyType(String moneyType) {
            this.moneyType = moneyType;
        }

        public void setOpenUnit(Integer openUnit) {
            this.openUnit = openUnit;
        }

        public void setOptClosePrice(Double optClosePrice) {
            this.optClosePrice = optClosePrice;
        }

        public void setOptDownPrice(Double optDownPrice) {
            this.optDownPrice = optDownPrice;
        }

        public void setOptFinalStatus(Character optFinalStatus) {
            this.optFinalStatus = optFinalStatus;
        }

        public void setOptLastPrice(Double optLastPrice) {
            this.optLastPrice = optLastPrice;
        }

        public void setOptOpenRestriction(String optOpenRestriction) {
            this.optOpenRestriction = optOpenRestriction;
        }

        public void setOptOpenStatus(Character optOpenStatus) {
            this.optOpenStatus = optOpenStatus;
        }

        public void setOptPriceStep(Double optPriceStep) {
            this.optPriceStep = optPriceStep;
        }

        public void setOptUpPrice(Double optUpPrice) {
            this.optUpPrice = optUpPrice;
        }

        public void setOptUpdatedStatus(Character optUpdatedStatus) {
            this.optUpdatedStatus = optUpdatedStatus;
        }

        public void setOptcodeStatus(Character optcodeStatus) {
            this.optcodeStatus = optcodeStatus;
        }

        public void setOptcombCodeStr(String optcombCodeStr) {
            this.optcombCodeStr = optcombCodeStr;
        }

        public void setOptcontractId(String optcontractId) {
            this.optcontractId = optcontractId;
        }

        public void setOptionCode(String optionCode) {
            this.optionCode = optionCode;
        }

        public void setOptionFlag(Character optionFlag) {
            this.optionFlag = optionFlag;
        }

        public void setOptionMode(Character optionMode) {
            this.optionMode = optionMode;
        }

        public void setOptionName(String optionName) {
            this.optionName = optionName;
        }

        public void setOptionType(Character optionType) {
            this.optionType = optionType;
        }

        public void setOptionVersion(Integer optionVersion) {
            this.optionVersion = optionVersion;
        }

        public void setPreSquarePrice(Double preSquarePrice) {
            this.preSquarePrice = preSquarePrice;
        }

        public void setPriceLimitKind(Character priceLimitKind) {
            this.priceLimitKind = priceLimitKind;
        }

        public void setStockCode(String stockCode) {
            this.stockCode = stockCode;
        }

        public void setStockName(String stockName) {
            this.stockName = stockName;
        }

        public void setStockType(String stockType) {
            this.stockType = stockType;
        }

        public void setStoreUnit(Integer storeUnit) {
            this.storeUnit = storeUnit;
        }

        public void setUndropAmount(Double undropAmount) {
            this.undropAmount = undropAmount;
        }

        public void setVerticalSplitDate(Integer verticalSplitDate) {
            this.verticalSplitDate = verticalSplitDate;
        }

        public void setVerticalSplitDateStr(String verticalSplitDateStr) {
            this.verticalSplitDateStr = verticalSplitDateStr;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutCodeInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",amountPerHand:" + this.amountPerHand);
            buffer.append(",beginDate:" + this.beginDate);
            buffer.append(",closePrice:" + this.closePrice);
            buffer.append(",combLimitFlag:" + this.combLimitFlag);
            buffer.append(",deliverDate:" + this.deliverDate);
            buffer.append(",dropUnit:" + this.dropUnit);
            buffer.append(",endDate:" + this.endDate);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(",exeBeginDate:" + this.exeBeginDate);
            buffer.append(",exeEndDate:" + this.exeEndDate);
            buffer.append(",exercisePrice:" + this.exercisePrice);
            buffer.append(",initperBalance:" + this.initperBalance);
            buffer.append(",limitHighAmount:" + this.limitHighAmount);
            buffer.append(",limitLowAmount:" + this.limitLowAmount);
            buffer.append(",marginRatio1:" + this.marginRatio1);
            buffer.append(",marginRatio2:" + this.marginRatio2);
            buffer.append(",mktHighAmount:" + this.mktHighAmount);
            buffer.append(",mktLowAmount:" + this.mktLowAmount);
            buffer.append(",moneyType:" + this.moneyType);
            buffer.append(",openUnit:" + this.openUnit);
            buffer.append(",optClosePrice:" + this.optClosePrice);
            buffer.append(",optDownPrice:" + this.optDownPrice);
            buffer.append(",optFinalStatus:" + this.optFinalStatus);
            buffer.append(",optLastPrice:" + this.optLastPrice);
            buffer.append(",optOpenRestriction:" + this.optOpenRestriction);
            buffer.append(",optOpenStatus:" + this.optOpenStatus);
            buffer.append(",optPriceStep:" + this.optPriceStep);
            buffer.append(",optUpPrice:" + this.optUpPrice);
            buffer.append(",optUpdatedStatus:" + this.optUpdatedStatus);
            buffer.append(",optcodeStatus:" + this.optcodeStatus);
            buffer.append(",optcombCodeStr:" + this.optcombCodeStr);
            buffer.append(",optcontractId:" + this.optcontractId);
            buffer.append(",optionCode:" + this.optionCode);
            buffer.append(",optionFlag:" + this.optionFlag);
            buffer.append(",optionMode:" + this.optionMode);
            buffer.append(",optionName:" + this.optionName);
            buffer.append(",optionType:" + this.optionType);
            buffer.append(",optionVersion:" + this.optionVersion);
            buffer.append(",preSquarePrice:" + this.preSquarePrice);
            buffer.append(",priceLimitKind:" + this.priceLimitKind);
            buffer.append(",stockCode:" + this.stockCode);
            buffer.append(",stockName:" + this.stockName);
            buffer.append(",stockType:" + this.stockType);
            buffer.append(",storeUnit:" + this.storeUnit);
            buffer.append(",undropAmount:" + this.undropAmount);
            buffer.append(",verticalSplitDate:" + this.verticalSplitDate);
            buffer.append(",verticalSplitDateStr:" + this.verticalSplitDateStr);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.amountPerHand);
            builder.append(this.beginDate);
            builder.append(this.closePrice);
            builder.append(this.combLimitFlag);
            builder.append(this.deliverDate);
            builder.append(this.dropUnit);
            builder.append(this.endDate);
            builder.append(this.exchangeType);
            builder.append(this.exeBeginDate);
            builder.append(this.exeEndDate);
            builder.append(this.exercisePrice);
            builder.append(this.initperBalance);
            builder.append(this.limitHighAmount);
            builder.append(this.limitLowAmount);
            builder.append(this.marginRatio1);
            builder.append(this.marginRatio2);
            builder.append(this.mktHighAmount);
            builder.append(this.mktLowAmount);
            builder.append(this.moneyType);
            builder.append(this.openUnit);
            builder.append(this.optClosePrice);
            builder.append(this.optDownPrice);
            builder.append(this.optFinalStatus);
            builder.append(this.optLastPrice);
            builder.append(this.optOpenRestriction);
            builder.append(this.optOpenStatus);
            builder.append(this.optPriceStep);
            builder.append(this.optUpPrice);
            builder.append(this.optUpdatedStatus);
            builder.append(this.optcodeStatus);
            builder.append(this.optcombCodeStr);
            builder.append(this.optcontractId);
            builder.append(this.optionCode);
            builder.append(this.optionFlag);
            builder.append(this.optionMode);
            builder.append(this.optionName);
            builder.append(this.optionType);
            builder.append(this.optionVersion);
            builder.append(this.preSquarePrice);
            builder.append(this.priceLimitKind);
            builder.append(this.stockCode);
            builder.append(this.stockName);
            builder.append(this.stockType);
            builder.append(this.storeUnit);
            builder.append(this.undropAmount);
            builder.append(this.verticalSplitDate);
            builder.append(this.verticalSplitDateStr);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PutCodeInnerInput obj) {
            if (obj instanceof InnerOptService.PutCodeInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, obj.opPassword);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.amountPerHand, obj.amountPerHand);
                builder.append(this.beginDate, obj.beginDate);
                builder.append(this.closePrice, obj.closePrice);
                builder.append(this.combLimitFlag, obj.combLimitFlag);
                builder.append(this.deliverDate, obj.deliverDate);
                builder.append(this.dropUnit, obj.dropUnit);
                builder.append(this.endDate, obj.endDate);
                builder.append(this.exchangeType, obj.exchangeType);
                builder.append(this.exeBeginDate, obj.exeBeginDate);
                builder.append(this.exeEndDate, obj.exeEndDate);
                builder.append(this.exercisePrice, obj.exercisePrice);
                builder.append(this.initperBalance, obj.initperBalance);
                builder.append(this.limitHighAmount, obj.limitHighAmount);
                builder.append(this.limitLowAmount, obj.limitLowAmount);
                builder.append(this.marginRatio1, obj.marginRatio1);
                builder.append(this.marginRatio2, obj.marginRatio2);
                builder.append(this.mktHighAmount, obj.mktHighAmount);
                builder.append(this.mktLowAmount, obj.mktLowAmount);
                builder.append(this.moneyType, obj.moneyType);
                builder.append(this.openUnit, obj.openUnit);
                builder.append(this.optClosePrice, obj.optClosePrice);
                builder.append(this.optDownPrice, obj.optDownPrice);
                builder.append(this.optFinalStatus, obj.optFinalStatus);
                builder.append(this.optLastPrice, obj.optLastPrice);
                builder.append(this.optOpenRestriction, obj.optOpenRestriction);
                builder.append(this.optOpenStatus, obj.optOpenStatus);
                builder.append(this.optPriceStep, obj.optPriceStep);
                builder.append(this.optUpPrice, obj.optUpPrice);
                builder.append(this.optUpdatedStatus, obj.optUpdatedStatus);
                builder.append(this.optcodeStatus, obj.optcodeStatus);
                builder.append(this.optcombCodeStr, obj.optcombCodeStr);
                builder.append(this.optcontractId, obj.optcontractId);
                builder.append(this.optionCode, obj.optionCode);
                builder.append(this.optionFlag, obj.optionFlag);
                builder.append(this.optionMode, obj.optionMode);
                builder.append(this.optionName, obj.optionName);
                builder.append(this.optionType, obj.optionType);
                builder.append(this.optionVersion, obj.optionVersion);
                builder.append(this.preSquarePrice, obj.preSquarePrice);
                builder.append(this.priceLimitKind, obj.priceLimitKind);
                builder.append(this.stockCode, obj.stockCode);
                builder.append(this.stockName, obj.stockName);
                builder.append(this.stockType, obj.stockType);
                builder.append(this.storeUnit, obj.storeUnit);
                builder.append(this.undropAmount, obj.undropAmount);
                builder.append(this.verticalSplitDate, obj.verticalSplitDate);
                builder.append(this.verticalSplitDateStr, obj.verticalSplitDateStr);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostTransstatusInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String opRemark = " ";
        @JsonSerialize(
                using = LongJsonSerializer.class
        )
        @JsonDeserialize(
                using = LongJsonDeserializer.class
        )
        private Long serialNo = 0L;

        public PostTransstatusInnerOutput() {
        }

        public String getOpRemark() {
            if (this.opRemark == null) {
                return " ";
            } else {
                return this.opRemark.isEmpty() ? " " : this.opRemark;
            }
        }

        public Long getSerialNo() {
            return this.serialNo != null ? this.serialNo : 0L;
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public void setSerialNo(Long serialNo) {
            this.serialNo = serialNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostTransstatusInnerOutput:(");
            buffer.append("opRemark:" + this.opRemark);
            buffer.append(",serialNo:" + this.serialNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opRemark);
            builder.append(this.serialNo);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PostTransstatusInnerOutput obj) {
            if (obj instanceof InnerOptService.PostTransstatusInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opRemark, obj.opRemark);
                builder.append(this.serialNo, obj.serialNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostTransstatusInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String exchangeType = " ";
        @SinogramLength(
                min = 0,
                max = 60,
                charset = "utf-8"
        )
        private String transName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character reportStatus = ' ';
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String enSeatNo = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character openingStatus = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character transplatType = ' ';
        @SinogramLength(
                min = 0,
                max = 4000,
                charset = "utf-8"
        )
        private String enBranchNo = " ";
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String enEntrustProp = " ";

        public PostTransstatusInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getExchangeType() {
            if (this.exchangeType == null) {
                return " ";
            } else {
                return this.exchangeType.isEmpty() ? " " : this.exchangeType;
            }
        }

        public String getTransName() {
            if (this.transName == null) {
                return " ";
            } else {
                return this.transName.isEmpty() ? " " : this.transName;
            }
        }

        public Character getReportStatus() {
            return this.reportStatus != null ? this.reportStatus : ' ';
        }

        public String getEnSeatNo() {
            if (this.enSeatNo == null) {
                return " ";
            } else {
                return this.enSeatNo.isEmpty() ? " " : this.enSeatNo;
            }
        }

        public Character getOpeningStatus() {
            return this.openingStatus != null ? this.openingStatus : ' ';
        }

        public Character getTransplatType() {
            return this.transplatType != null ? this.transplatType : ' ';
        }

        public String getEnBranchNo() {
            if (this.enBranchNo == null) {
                return " ";
            } else {
                return this.enBranchNo.isEmpty() ? " " : this.enBranchNo;
            }
        }

        public String getEnEntrustProp() {
            if (this.enEntrustProp == null) {
                return " ";
            } else {
                return this.enEntrustProp.isEmpty() ? " " : this.enEntrustProp;
            }
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public void setTransName(String transName) {
            this.transName = transName;
        }

        public void setReportStatus(Character reportStatus) {
            this.reportStatus = reportStatus;
        }

        public void setEnSeatNo(String enSeatNo) {
            this.enSeatNo = enSeatNo;
        }

        public void setOpeningStatus(Character openingStatus) {
            this.openingStatus = openingStatus;
        }

        public void setTransplatType(Character transplatType) {
            this.transplatType = transplatType;
        }

        public void setEnBranchNo(String enBranchNo) {
            this.enBranchNo = enBranchNo;
        }

        public void setEnEntrustProp(String enEntrustProp) {
            this.enEntrustProp = enEntrustProp;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostTransstatusInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(",transName:" + this.transName);
            buffer.append(",reportStatus:" + this.reportStatus);
            buffer.append(",enSeatNo:" + this.enSeatNo);
            buffer.append(",openingStatus:" + this.openingStatus);
            buffer.append(",transplatType:" + this.transplatType);
            buffer.append(",enBranchNo:" + this.enBranchNo);
            buffer.append(",enEntrustProp:" + this.enEntrustProp);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.exchangeType);
            builder.append(this.transName);
            builder.append(this.reportStatus);
            builder.append(this.enSeatNo);
            builder.append(this.openingStatus);
            builder.append(this.transplatType);
            builder.append(this.enBranchNo);
            builder.append(this.enEntrustProp);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PostTransstatusInnerInput obj) {
            if (obj instanceof InnerOptService.PostTransstatusInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, obj.opPassword);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.exchangeType, obj.exchangeType);
                builder.append(this.transName, obj.transName);
                builder.append(this.reportStatus, obj.reportStatus);
                builder.append(this.enSeatNo, obj.enSeatNo);
                builder.append(this.openingStatus, obj.openingStatus);
                builder.append(this.transplatType, obj.transplatType);
                builder.append(this.enBranchNo, obj.enBranchNo);
                builder.append(this.enEntrustProp, obj.enEntrustProp);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostRealtimeWithdrawErrorFeedBackInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer dataId = 0;
        private Integer errorNo = 0;
        private String errorInfo = " ";

        public PostRealtimeWithdrawErrorFeedBackInnerOutput() {
        }

        public Integer getDataId() {
            return this.dataId != null ? this.dataId : 0;
        }

        public Integer getErrorNo() {
            return this.errorNo != null ? this.errorNo : 0;
        }

        public String getErrorInfo() {
            if (this.errorInfo == null) {
                return " ";
            } else {
                return this.errorInfo.isEmpty() ? " " : this.errorInfo;
            }
        }

        public void setDataId(Integer dataId) {
            this.dataId = dataId;
        }

        public void setErrorNo(Integer errorNo) {
            this.errorNo = errorNo;
        }

        public void setErrorInfo(String errorInfo) {
            this.errorInfo = errorInfo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostRealtimeWithdrawErrorFeedBackInnerOutput:(");
            buffer.append("dataId:" + this.dataId);
            buffer.append(",errorNo:" + this.errorNo);
            buffer.append(",errorInfo:" + this.errorInfo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.dataId);
            builder.append(this.errorNo);
            builder.append(this.errorInfo);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PostRealtimeWithdrawErrorFeedBackInnerOutput obj) {
            if (obj instanceof InnerOptService.PostRealtimeWithdrawErrorFeedBackInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.dataId, obj.dataId);
                builder.append(this.errorNo, obj.errorNo);
                builder.append(this.errorInfo, obj.errorInfo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostRealtimeWithdrawErrorFeedBackInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        private Integer initDate = 0;
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String exchangeType = " ";
        @SinogramLength(
                min = 0,
                max = 8,
                charset = "utf-8"
        )
        private String optionCode = " ";
        @SinogramLength(
                min = 0,
                max = 24,
                charset = "utf-8"
        )
        private String orderId = " ";
        @SinogramLength(
                min = 0,
                max = 24,
                charset = "utf-8"
        )
        private String origOrderId = " ";
        @JsonSerialize(
                using = LongJsonSerializer.class
        )
        @JsonDeserialize(
                using = LongJsonDeserializer.class
        )
        private Long joinReportNo = 0L;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character reportBs = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character coveredFlag = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character entrustOc = ' ';
        @SinogramLength(
                min = 0,
                max = 16,
                charset = "utf-8"
        )
        private String reportSeat = " ";
        @SinogramLength(
                min = 0,
                max = 20,
                charset = "utf-8"
        )
        private String reportAccount = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String businessId = " ";
        @Digits(
                integer = 13,
                fraction = 2,
                message = "businessAmount value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double businessAmount = 0.0D;
        @Digits(
                integer = 6,
                fraction = 6,
                message = "optBusinessPrice value out of bounds, integer=6, fraction=6"
        )
        @SerializeDoubleDigit(
                digit = 6
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double optBusinessPrice = 0.0D;
        private Integer businessTime = 0;
        private Integer reportTime = 0;
        @SinogramLength(
                min = 0,
                max = 8,
                charset = "utf-8"
        )
        private String externCode = " ";
        private Integer dataId = 0;
        @JsonSerialize(
                using = LongJsonSerializer.class
        )
        @JsonDeserialize(
                using = LongJsonDeserializer.class
        )
        private Long recordNo = 0L;
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String optcombId = " ";

        public PostRealtimeWithdrawErrorFeedBackInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public String getExchangeType() {
            if (this.exchangeType == null) {
                return " ";
            } else {
                return this.exchangeType.isEmpty() ? " " : this.exchangeType;
            }
        }

        public String getOptionCode() {
            if (this.optionCode == null) {
                return " ";
            } else {
                return this.optionCode.isEmpty() ? " " : this.optionCode;
            }
        }

        public String getOrderId() {
            if (this.orderId == null) {
                return " ";
            } else {
                return this.orderId.isEmpty() ? " " : this.orderId;
            }
        }

        public String getOrigOrderId() {
            if (this.origOrderId == null) {
                return " ";
            } else {
                return this.origOrderId.isEmpty() ? " " : this.origOrderId;
            }
        }

        public Long getJoinReportNo() {
            return this.joinReportNo != null ? this.joinReportNo : 0L;
        }

        public Character getReportBs() {
            return this.reportBs != null ? this.reportBs : ' ';
        }

        public Character getCoveredFlag() {
            return this.coveredFlag != null ? this.coveredFlag : ' ';
        }

        public Character getEntrustOc() {
            return this.entrustOc != null ? this.entrustOc : ' ';
        }

        public String getReportSeat() {
            if (this.reportSeat == null) {
                return " ";
            } else {
                return this.reportSeat.isEmpty() ? " " : this.reportSeat;
            }
        }

        public String getReportAccount() {
            if (this.reportAccount == null) {
                return " ";
            } else {
                return this.reportAccount.isEmpty() ? " " : this.reportAccount;
            }
        }

        public String getBusinessId() {
            if (this.businessId == null) {
                return " ";
            } else {
                return this.businessId.isEmpty() ? " " : this.businessId;
            }
        }

        public Double getBusinessAmount() {
            return this.businessAmount != null ? this.businessAmount : 0.0D;
        }

        public Double getOptBusinessPrice() {
            return this.optBusinessPrice != null ? this.optBusinessPrice : 0.0D;
        }

        public Integer getBusinessTime() {
            return this.businessTime != null ? this.businessTime : 0;
        }

        public Integer getReportTime() {
            return this.reportTime != null ? this.reportTime : 0;
        }

        public String getExternCode() {
            if (this.externCode == null) {
                return " ";
            } else {
                return this.externCode.isEmpty() ? " " : this.externCode;
            }
        }

        public Integer getDataId() {
            return this.dataId != null ? this.dataId : 0;
        }

        public Long getRecordNo() {
            return this.recordNo != null ? this.recordNo : 0L;
        }

        public String getOptcombId() {
            if (this.optcombId == null) {
                return " ";
            } else {
                return this.optcombId.isEmpty() ? " " : this.optcombId;
            }
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public void setOptionCode(String optionCode) {
            this.optionCode = optionCode;
        }

        public void setOrderId(String orderId) {
            this.orderId = orderId;
        }

        public void setOrigOrderId(String origOrderId) {
            this.origOrderId = origOrderId;
        }

        public void setJoinReportNo(Long joinReportNo) {
            this.joinReportNo = joinReportNo;
        }

        public void setReportBs(Character reportBs) {
            this.reportBs = reportBs;
        }

        public void setCoveredFlag(Character coveredFlag) {
            this.coveredFlag = coveredFlag;
        }

        public void setEntrustOc(Character entrustOc) {
            this.entrustOc = entrustOc;
        }

        public void setReportSeat(String reportSeat) {
            this.reportSeat = reportSeat;
        }

        public void setReportAccount(String reportAccount) {
            this.reportAccount = reportAccount;
        }

        public void setBusinessId(String businessId) {
            this.businessId = businessId;
        }

        public void setBusinessAmount(Double businessAmount) {
            this.businessAmount = businessAmount;
        }

        public void setOptBusinessPrice(Double optBusinessPrice) {
            this.optBusinessPrice = optBusinessPrice;
        }

        public void setBusinessTime(Integer businessTime) {
            this.businessTime = businessTime;
        }

        public void setReportTime(Integer reportTime) {
            this.reportTime = reportTime;
        }

        public void setExternCode(String externCode) {
            this.externCode = externCode;
        }

        public void setDataId(Integer dataId) {
            this.dataId = dataId;
        }

        public void setRecordNo(Long recordNo) {
            this.recordNo = recordNo;
        }

        public void setOptcombId(String optcombId) {
            this.optcombId = optcombId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostRealtimeWithdrawErrorFeedBackInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",initDate:" + this.initDate);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(",optionCode:" + this.optionCode);
            buffer.append(",orderId:" + this.orderId);
            buffer.append(",origOrderId:" + this.origOrderId);
            buffer.append(",joinReportNo:" + this.joinReportNo);
            buffer.append(",reportBs:" + this.reportBs);
            buffer.append(",coveredFlag:" + this.coveredFlag);
            buffer.append(",entrustOc:" + this.entrustOc);
            buffer.append(",reportSeat:" + this.reportSeat);
            buffer.append(",reportAccount:" + this.reportAccount);
            buffer.append(",businessId:" + this.businessId);
            buffer.append(",businessAmount:" + this.businessAmount);
            buffer.append(",optBusinessPrice:" + this.optBusinessPrice);
            buffer.append(",businessTime:" + this.businessTime);
            buffer.append(",reportTime:" + this.reportTime);
            buffer.append(",externCode:" + this.externCode);
            buffer.append(",dataId:" + this.dataId);
            buffer.append(",recordNo:" + this.recordNo);
            buffer.append(",optcombId:" + this.optcombId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.initDate);
            builder.append(this.exchangeType);
            builder.append(this.optionCode);
            builder.append(this.orderId);
            builder.append(this.origOrderId);
            builder.append(this.joinReportNo);
            builder.append(this.reportBs);
            builder.append(this.coveredFlag);
            builder.append(this.entrustOc);
            builder.append(this.reportSeat);
            builder.append(this.reportAccount);
            builder.append(this.businessId);
            builder.append(this.businessAmount);
            builder.append(this.optBusinessPrice);
            builder.append(this.businessTime);
            builder.append(this.reportTime);
            builder.append(this.externCode);
            builder.append(this.dataId);
            builder.append(this.recordNo);
            builder.append(this.optcombId);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PostRealtimeWithdrawErrorFeedBackInnerInput obj) {
            if (obj instanceof InnerOptService.PostRealtimeWithdrawErrorFeedBackInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, obj.opPassword);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.initDate, obj.initDate);
                builder.append(this.exchangeType, obj.exchangeType);
                builder.append(this.optionCode, obj.optionCode);
                builder.append(this.orderId, obj.orderId);
                builder.append(this.origOrderId, obj.origOrderId);
                builder.append(this.joinReportNo, obj.joinReportNo);
                builder.append(this.reportBs, obj.reportBs);
                builder.append(this.coveredFlag, obj.coveredFlag);
                builder.append(this.entrustOc, obj.entrustOc);
                builder.append(this.reportSeat, obj.reportSeat);
                builder.append(this.reportAccount, obj.reportAccount);
                builder.append(this.businessId, obj.businessId);
                builder.append(this.businessAmount, obj.businessAmount);
                builder.append(this.optBusinessPrice, obj.optBusinessPrice);
                builder.append(this.businessTime, obj.businessTime);
                builder.append(this.reportTime, obj.reportTime);
                builder.append(this.externCode, obj.externCode);
                builder.append(this.dataId, obj.dataId);
                builder.append(this.recordNo, obj.recordNo);
                builder.append(this.optcombId, obj.optcombId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostRealtimeWithdrawDealFeadBackInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer dataId = 0;
        private Integer errorNo = 0;
        private String errorInfo = " ";

        public PostRealtimeWithdrawDealFeadBackInnerOutput() {
        }

        public Integer getDataId() {
            return this.dataId != null ? this.dataId : 0;
        }

        public Integer getErrorNo() {
            return this.errorNo != null ? this.errorNo : 0;
        }

        public String getErrorInfo() {
            if (this.errorInfo == null) {
                return " ";
            } else {
                return this.errorInfo.isEmpty() ? " " : this.errorInfo;
            }
        }

        public void setDataId(Integer dataId) {
            this.dataId = dataId;
        }

        public void setErrorNo(Integer errorNo) {
            this.errorNo = errorNo;
        }

        public void setErrorInfo(String errorInfo) {
            this.errorInfo = errorInfo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostRealtimeWithdrawDealFeadBackInnerOutput:(");
            buffer.append("dataId:" + this.dataId);
            buffer.append(",errorNo:" + this.errorNo);
            buffer.append(",errorInfo:" + this.errorInfo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.dataId);
            builder.append(this.errorNo);
            builder.append(this.errorInfo);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PostRealtimeWithdrawDealFeadBackInnerOutput obj) {
            if (obj instanceof InnerOptService.PostRealtimeWithdrawDealFeadBackInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.dataId, obj.dataId);
                builder.append(this.errorNo, obj.errorNo);
                builder.append(this.errorInfo, obj.errorInfo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostRealtimeWithdrawDealFeadBackInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        private Integer initDate = 0;
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String exchangeType = " ";
        @SinogramLength(
                min = 0,
                max = 24,
                charset = "utf-8"
        )
        private String orderId = " ";
        @SinogramLength(
                min = 0,
                max = 8,
                charset = "utf-8"
        )
        private String optionCode = " ";
        @SinogramLength(
                min = 0,
                max = 24,
                charset = "utf-8"
        )
        private String origOrderId = " ";
        @JsonSerialize(
                using = LongJsonSerializer.class
        )
        @JsonDeserialize(
                using = LongJsonDeserializer.class
        )
        private Long joinReportNo = 0L;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character reportBs = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character entrustOc = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character coveredFlag = ' ';
        @SinogramLength(
                min = 0,
                max = 16,
                charset = "utf-8"
        )
        private String reportSeat = " ";
        @SinogramLength(
                min = 0,
                max = 20,
                charset = "utf-8"
        )
        private String reportAccount = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String businessId = " ";
        @Digits(
                integer = 13,
                fraction = 2,
                message = "businessAmount value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double businessAmount = 0.0D;
        @Digits(
                integer = 6,
                fraction = 6,
                message = "optBusinessPrice value out of bounds, integer=6, fraction=6"
        )
        @SerializeDoubleDigit(
                digit = 6
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double optBusinessPrice = 0.0D;
        private Integer businessTime = 0;
        private Integer reportTime = 0;
        @SinogramLength(
                min = 0,
                max = 8,
                charset = "utf-8"
        )
        private String externCode = " ";
        private Integer dataId = 0;
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String optcombId = " ";

        public PostRealtimeWithdrawDealFeadBackInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public String getExchangeType() {
            if (this.exchangeType == null) {
                return " ";
            } else {
                return this.exchangeType.isEmpty() ? " " : this.exchangeType;
            }
        }

        public String getOrderId() {
            if (this.orderId == null) {
                return " ";
            } else {
                return this.orderId.isEmpty() ? " " : this.orderId;
            }
        }

        public String getOptionCode() {
            if (this.optionCode == null) {
                return " ";
            } else {
                return this.optionCode.isEmpty() ? " " : this.optionCode;
            }
        }

        public String getOrigOrderId() {
            if (this.origOrderId == null) {
                return " ";
            } else {
                return this.origOrderId.isEmpty() ? " " : this.origOrderId;
            }
        }

        public Long getJoinReportNo() {
            return this.joinReportNo != null ? this.joinReportNo : 0L;
        }

        public Character getReportBs() {
            return this.reportBs != null ? this.reportBs : ' ';
        }

        public Character getEntrustOc() {
            return this.entrustOc != null ? this.entrustOc : ' ';
        }

        public Character getCoveredFlag() {
            return this.coveredFlag != null ? this.coveredFlag : ' ';
        }

        public String getReportSeat() {
            if (this.reportSeat == null) {
                return " ";
            } else {
                return this.reportSeat.isEmpty() ? " " : this.reportSeat;
            }
        }

        public String getReportAccount() {
            if (this.reportAccount == null) {
                return " ";
            } else {
                return this.reportAccount.isEmpty() ? " " : this.reportAccount;
            }
        }

        public String getBusinessId() {
            if (this.businessId == null) {
                return " ";
            } else {
                return this.businessId.isEmpty() ? " " : this.businessId;
            }
        }

        public Double getBusinessAmount() {
            return this.businessAmount != null ? this.businessAmount : 0.0D;
        }

        public Double getOptBusinessPrice() {
            return this.optBusinessPrice != null ? this.optBusinessPrice : 0.0D;
        }

        public Integer getBusinessTime() {
            return this.businessTime != null ? this.businessTime : 0;
        }

        public Integer getReportTime() {
            return this.reportTime != null ? this.reportTime : 0;
        }

        public String getExternCode() {
            if (this.externCode == null) {
                return " ";
            } else {
                return this.externCode.isEmpty() ? " " : this.externCode;
            }
        }

        public Integer getDataId() {
            return this.dataId != null ? this.dataId : 0;
        }

        public String getOptcombId() {
            if (this.optcombId == null) {
                return " ";
            } else {
                return this.optcombId.isEmpty() ? " " : this.optcombId;
            }
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public void setOrderId(String orderId) {
            this.orderId = orderId;
        }

        public void setOptionCode(String optionCode) {
            this.optionCode = optionCode;
        }

        public void setOrigOrderId(String origOrderId) {
            this.origOrderId = origOrderId;
        }

        public void setJoinReportNo(Long joinReportNo) {
            this.joinReportNo = joinReportNo;
        }

        public void setReportBs(Character reportBs) {
            this.reportBs = reportBs;
        }

        public void setEntrustOc(Character entrustOc) {
            this.entrustOc = entrustOc;
        }

        public void setCoveredFlag(Character coveredFlag) {
            this.coveredFlag = coveredFlag;
        }

        public void setReportSeat(String reportSeat) {
            this.reportSeat = reportSeat;
        }

        public void setReportAccount(String reportAccount) {
            this.reportAccount = reportAccount;
        }

        public void setBusinessId(String businessId) {
            this.businessId = businessId;
        }

        public void setBusinessAmount(Double businessAmount) {
            this.businessAmount = businessAmount;
        }

        public void setOptBusinessPrice(Double optBusinessPrice) {
            this.optBusinessPrice = optBusinessPrice;
        }

        public void setBusinessTime(Integer businessTime) {
            this.businessTime = businessTime;
        }

        public void setReportTime(Integer reportTime) {
            this.reportTime = reportTime;
        }

        public void setExternCode(String externCode) {
            this.externCode = externCode;
        }

        public void setDataId(Integer dataId) {
            this.dataId = dataId;
        }

        public void setOptcombId(String optcombId) {
            this.optcombId = optcombId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostRealtimeWithdrawDealFeadBackInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",initDate:" + this.initDate);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(",orderId:" + this.orderId);
            buffer.append(",optionCode:" + this.optionCode);
            buffer.append(",origOrderId:" + this.origOrderId);
            buffer.append(",joinReportNo:" + this.joinReportNo);
            buffer.append(",reportBs:" + this.reportBs);
            buffer.append(",entrustOc:" + this.entrustOc);
            buffer.append(",coveredFlag:" + this.coveredFlag);
            buffer.append(",reportSeat:" + this.reportSeat);
            buffer.append(",reportAccount:" + this.reportAccount);
            buffer.append(",businessId:" + this.businessId);
            buffer.append(",businessAmount:" + this.businessAmount);
            buffer.append(",optBusinessPrice:" + this.optBusinessPrice);
            buffer.append(",businessTime:" + this.businessTime);
            buffer.append(",reportTime:" + this.reportTime);
            buffer.append(",externCode:" + this.externCode);
            buffer.append(",dataId:" + this.dataId);
            buffer.append(",optcombId:" + this.optcombId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.initDate);
            builder.append(this.exchangeType);
            builder.append(this.orderId);
            builder.append(this.optionCode);
            builder.append(this.origOrderId);
            builder.append(this.joinReportNo);
            builder.append(this.reportBs);
            builder.append(this.entrustOc);
            builder.append(this.coveredFlag);
            builder.append(this.reportSeat);
            builder.append(this.reportAccount);
            builder.append(this.businessId);
            builder.append(this.businessAmount);
            builder.append(this.optBusinessPrice);
            builder.append(this.businessTime);
            builder.append(this.reportTime);
            builder.append(this.externCode);
            builder.append(this.dataId);
            builder.append(this.optcombId);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PostRealtimeWithdrawDealFeadBackInnerInput obj) {
            if (obj instanceof InnerOptService.PostRealtimeWithdrawDealFeadBackInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, obj.opPassword);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.initDate, obj.initDate);
                builder.append(this.exchangeType, obj.exchangeType);
                builder.append(this.orderId, obj.orderId);
                builder.append(this.optionCode, obj.optionCode);
                builder.append(this.origOrderId, obj.origOrderId);
                builder.append(this.joinReportNo, obj.joinReportNo);
                builder.append(this.reportBs, obj.reportBs);
                builder.append(this.entrustOc, obj.entrustOc);
                builder.append(this.coveredFlag, obj.coveredFlag);
                builder.append(this.reportSeat, obj.reportSeat);
                builder.append(this.reportAccount, obj.reportAccount);
                builder.append(this.businessId, obj.businessId);
                builder.append(this.businessAmount, obj.businessAmount);
                builder.append(this.optBusinessPrice, obj.optBusinessPrice);
                builder.append(this.businessTime, obj.businessTime);
                builder.append(this.reportTime, obj.reportTime);
                builder.append(this.externCode, obj.externCode);
                builder.append(this.dataId, obj.dataId);
                builder.append(this.optcombId, obj.optcombId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostRealtimeUntradeFeedBackInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer dataId = 0;
        private Integer errorNo = 0;
        private String errorInfo = " ";

        public PostRealtimeUntradeFeedBackInnerOutput() {
        }

        public Integer getDataId() {
            return this.dataId != null ? this.dataId : 0;
        }

        public Integer getErrorNo() {
            return this.errorNo != null ? this.errorNo : 0;
        }

        public String getErrorInfo() {
            if (this.errorInfo == null) {
                return " ";
            } else {
                return this.errorInfo.isEmpty() ? " " : this.errorInfo;
            }
        }

        public void setDataId(Integer dataId) {
            this.dataId = dataId;
        }

        public void setErrorNo(Integer errorNo) {
            this.errorNo = errorNo;
        }

        public void setErrorInfo(String errorInfo) {
            this.errorInfo = errorInfo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostRealtimeUntradeFeedBackInnerOutput:(");
            buffer.append("dataId:" + this.dataId);
            buffer.append(",errorNo:" + this.errorNo);
            buffer.append(",errorInfo:" + this.errorInfo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.dataId);
            builder.append(this.errorNo);
            builder.append(this.errorInfo);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PostRealtimeUntradeFeedBackInnerOutput obj) {
            if (obj instanceof InnerOptService.PostRealtimeUntradeFeedBackInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.dataId, obj.dataId);
                builder.append(this.errorNo, obj.errorNo);
                builder.append(this.errorInfo, obj.errorInfo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostRealtimeUntradeFeedBackInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 8,
                charset = "utf-8"
        )
        private String returnCode = " ";
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String exchangeType = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character writebackKind = ' ';
        @SinogramLength(
                min = 0,
                max = 24,
                charset = "utf-8"
        )
        private String orderId = " ";
        @JsonSerialize(
                using = LongJsonSerializer.class
        )
        @JsonDeserialize(
                using = LongJsonDeserializer.class
        )
        private Long recordNo = 0L;
        @SinogramLength(
                min = 0,
                max = 24,
                charset = "utf-8"
        )
        private String origOrderId = " ";
        private Integer dataId = 0;

        public PostRealtimeUntradeFeedBackInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getReturnCode() {
            if (this.returnCode == null) {
                return " ";
            } else {
                return this.returnCode.isEmpty() ? " " : this.returnCode;
            }
        }

        public String getExchangeType() {
            if (this.exchangeType == null) {
                return " ";
            } else {
                return this.exchangeType.isEmpty() ? " " : this.exchangeType;
            }
        }

        public Character getWritebackKind() {
            return this.writebackKind != null ? this.writebackKind : ' ';
        }

        public String getOrderId() {
            if (this.orderId == null) {
                return " ";
            } else {
                return this.orderId.isEmpty() ? " " : this.orderId;
            }
        }

        public Long getRecordNo() {
            return this.recordNo != null ? this.recordNo : 0L;
        }

        public String getOrigOrderId() {
            if (this.origOrderId == null) {
                return " ";
            } else {
                return this.origOrderId.isEmpty() ? " " : this.origOrderId;
            }
        }

        public Integer getDataId() {
            return this.dataId != null ? this.dataId : 0;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setReturnCode(String returnCode) {
            this.returnCode = returnCode;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public void setWritebackKind(Character writebackKind) {
            this.writebackKind = writebackKind;
        }

        public void setOrderId(String orderId) {
            this.orderId = orderId;
        }

        public void setRecordNo(Long recordNo) {
            this.recordNo = recordNo;
        }

        public void setOrigOrderId(String origOrderId) {
            this.origOrderId = origOrderId;
        }

        public void setDataId(Integer dataId) {
            this.dataId = dataId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostRealtimeUntradeFeedBackInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",returnCode:" + this.returnCode);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(",writebackKind:" + this.writebackKind);
            buffer.append(",orderId:" + this.orderId);
            buffer.append(",recordNo:" + this.recordNo);
            buffer.append(",origOrderId:" + this.origOrderId);
            buffer.append(",dataId:" + this.dataId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.returnCode);
            builder.append(this.exchangeType);
            builder.append(this.writebackKind);
            builder.append(this.orderId);
            builder.append(this.recordNo);
            builder.append(this.origOrderId);
            builder.append(this.dataId);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PostRealtimeUntradeFeedBackInnerInput obj) {
            if (obj instanceof InnerOptService.PostRealtimeUntradeFeedBackInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, obj.opPassword);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.returnCode, obj.returnCode);
                builder.append(this.exchangeType, obj.exchangeType);
                builder.append(this.writebackKind, obj.writebackKind);
                builder.append(this.orderId, obj.orderId);
                builder.append(this.recordNo, obj.recordNo);
                builder.append(this.origOrderId, obj.origOrderId);
                builder.append(this.dataId, obj.dataId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostRealtimeMarginQryFeedBackInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer dataId = 0;
        private Integer errorNo = 0;
        private String errorInfo = " ";

        public PostRealtimeMarginQryFeedBackInnerOutput() {
        }

        public Integer getDataId() {
            return this.dataId != null ? this.dataId : 0;
        }

        public Integer getErrorNo() {
            return this.errorNo != null ? this.errorNo : 0;
        }

        public String getErrorInfo() {
            if (this.errorInfo == null) {
                return " ";
            } else {
                return this.errorInfo.isEmpty() ? " " : this.errorInfo;
            }
        }

        public void setDataId(Integer dataId) {
            this.dataId = dataId;
        }

        public void setErrorNo(Integer errorNo) {
            this.errorNo = errorNo;
        }

        public void setErrorInfo(String errorInfo) {
            this.errorInfo = errorInfo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostRealtimeMarginQryFeedBackInnerOutput:(");
            buffer.append("dataId:" + this.dataId);
            buffer.append(",errorNo:" + this.errorNo);
            buffer.append(",errorInfo:" + this.errorInfo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.dataId);
            builder.append(this.errorNo);
            builder.append(this.errorInfo);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PostRealtimeMarginQryFeedBackInnerOutput obj) {
            if (obj instanceof InnerOptService.PostRealtimeMarginQryFeedBackInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.dataId, obj.dataId);
                builder.append(this.errorNo, obj.errorNo);
                builder.append(this.errorInfo, obj.errorInfo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostRealtimeMarginQryFeedBackInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        private Integer initDate = 0;
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String exchangeType = " ";
        @SinogramLength(
                min = 0,
                max = 24,
                charset = "utf-8"
        )
        private String orderId = " ";
        @SinogramLength(
                min = 0,
                max = 8,
                charset = "utf-8"
        )
        private String optionCode = " ";
        @JsonSerialize(
                using = LongJsonSerializer.class
        )
        @JsonDeserialize(
                using = LongJsonDeserializer.class
        )
        private Long reportNo = 0L;
        @SinogramLength(
                min = 0,
                max = 16,
                charset = "utf-8"
        )
        private String reportSeat = " ";
        @SinogramLength(
                min = 0,
                max = 20,
                charset = "utf-8"
        )
        private String reportAccount = " ";
        @Digits(
                integer = 13,
                fraction = 2,
                message = "fundBalance value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double fundBalance = 0.0D;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "enableBailBalance value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double enableBailBalance = 0.0D;
        @SinogramLength(
                min = 0,
                max = 8,
                charset = "utf-8"
        )
        private String externCode = " ";
        @SinogramLength(
                min = 0,
                max = 8,
                charset = "utf-8"
        )
        private String returnCode = " ";
        private Integer dataId = 0;

        public PostRealtimeMarginQryFeedBackInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public String getExchangeType() {
            if (this.exchangeType == null) {
                return " ";
            } else {
                return this.exchangeType.isEmpty() ? " " : this.exchangeType;
            }
        }

        public String getOrderId() {
            if (this.orderId == null) {
                return " ";
            } else {
                return this.orderId.isEmpty() ? " " : this.orderId;
            }
        }

        public String getOptionCode() {
            if (this.optionCode == null) {
                return " ";
            } else {
                return this.optionCode.isEmpty() ? " " : this.optionCode;
            }
        }

        public Long getReportNo() {
            return this.reportNo != null ? this.reportNo : 0L;
        }

        public String getReportSeat() {
            if (this.reportSeat == null) {
                return " ";
            } else {
                return this.reportSeat.isEmpty() ? " " : this.reportSeat;
            }
        }

        public String getReportAccount() {
            if (this.reportAccount == null) {
                return " ";
            } else {
                return this.reportAccount.isEmpty() ? " " : this.reportAccount;
            }
        }

        public Double getFundBalance() {
            return this.fundBalance != null ? this.fundBalance : 0.0D;
        }

        public Double getEnableBailBalance() {
            return this.enableBailBalance != null ? this.enableBailBalance : 0.0D;
        }

        public String getExternCode() {
            if (this.externCode == null) {
                return " ";
            } else {
                return this.externCode.isEmpty() ? " " : this.externCode;
            }
        }

        public String getReturnCode() {
            if (this.returnCode == null) {
                return " ";
            } else {
                return this.returnCode.isEmpty() ? " " : this.returnCode;
            }
        }

        public Integer getDataId() {
            return this.dataId != null ? this.dataId : 0;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public void setOrderId(String orderId) {
            this.orderId = orderId;
        }

        public void setOptionCode(String optionCode) {
            this.optionCode = optionCode;
        }

        public void setReportNo(Long reportNo) {
            this.reportNo = reportNo;
        }

        public void setReportSeat(String reportSeat) {
            this.reportSeat = reportSeat;
        }

        public void setReportAccount(String reportAccount) {
            this.reportAccount = reportAccount;
        }

        public void setFundBalance(Double fundBalance) {
            this.fundBalance = fundBalance;
        }

        public void setEnableBailBalance(Double enableBailBalance) {
            this.enableBailBalance = enableBailBalance;
        }

        public void setExternCode(String externCode) {
            this.externCode = externCode;
        }

        public void setReturnCode(String returnCode) {
            this.returnCode = returnCode;
        }

        public void setDataId(Integer dataId) {
            this.dataId = dataId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostRealtimeMarginQryFeedBackInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",initDate:" + this.initDate);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(",orderId:" + this.orderId);
            buffer.append(",optionCode:" + this.optionCode);
            buffer.append(",reportNo:" + this.reportNo);
            buffer.append(",reportSeat:" + this.reportSeat);
            buffer.append(",reportAccount:" + this.reportAccount);
            buffer.append(",fundBalance:" + this.fundBalance);
            buffer.append(",enableBailBalance:" + this.enableBailBalance);
            buffer.append(",externCode:" + this.externCode);
            buffer.append(",returnCode:" + this.returnCode);
            buffer.append(",dataId:" + this.dataId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.initDate);
            builder.append(this.exchangeType);
            builder.append(this.orderId);
            builder.append(this.optionCode);
            builder.append(this.reportNo);
            builder.append(this.reportSeat);
            builder.append(this.reportAccount);
            builder.append(this.fundBalance);
            builder.append(this.enableBailBalance);
            builder.append(this.externCode);
            builder.append(this.returnCode);
            builder.append(this.dataId);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PostRealtimeMarginQryFeedBackInnerInput obj) {
            if (obj instanceof InnerOptService.PostRealtimeMarginQryFeedBackInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, obj.opPassword);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.initDate, obj.initDate);
                builder.append(this.exchangeType, obj.exchangeType);
                builder.append(this.orderId, obj.orderId);
                builder.append(this.optionCode, obj.optionCode);
                builder.append(this.reportNo, obj.reportNo);
                builder.append(this.reportSeat, obj.reportSeat);
                builder.append(this.reportAccount, obj.reportAccount);
                builder.append(this.fundBalance, obj.fundBalance);
                builder.append(this.enableBailBalance, obj.enableBailBalance);
                builder.append(this.externCode, obj.externCode);
                builder.append(this.returnCode, obj.returnCode);
                builder.append(this.dataId, obj.dataId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostRealtimeFlowmodeErrorFeedBackInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer dataId = 0;
        private Integer errorNo = 0;
        private String errorInfo = " ";

        public PostRealtimeFlowmodeErrorFeedBackInnerOutput() {
        }

        public Integer getDataId() {
            return this.dataId != null ? this.dataId : 0;
        }

        public Integer getErrorNo() {
            return this.errorNo != null ? this.errorNo : 0;
        }

        public String getErrorInfo() {
            if (this.errorInfo == null) {
                return " ";
            } else {
                return this.errorInfo.isEmpty() ? " " : this.errorInfo;
            }
        }

        public void setDataId(Integer dataId) {
            this.dataId = dataId;
        }

        public void setErrorNo(Integer errorNo) {
            this.errorNo = errorNo;
        }

        public void setErrorInfo(String errorInfo) {
            this.errorInfo = errorInfo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostRealtimeFlowmodeErrorFeedBackInnerOutput:(");
            buffer.append("dataId:" + this.dataId);
            buffer.append(",errorNo:" + this.errorNo);
            buffer.append(",errorInfo:" + this.errorInfo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.dataId);
            builder.append(this.errorNo);
            builder.append(this.errorInfo);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PostRealtimeFlowmodeErrorFeedBackInnerOutput obj) {
            if (obj instanceof InnerOptService.PostRealtimeFlowmodeErrorFeedBackInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.dataId, obj.dataId);
                builder.append(this.errorNo, obj.errorNo);
                builder.append(this.errorInfo, obj.errorInfo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostRealtimeFlowmodeErrorFeedBackInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        private Integer branchNo = 0;
        private Integer initDate = 0;
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String exchangeType = " ";
        @SinogramLength(
                min = 0,
                max = 16,
                charset = "utf-8"
        )
        private String reportSeat = " ";
        @SinogramLength(
                min = 0,
                max = 24,
                charset = "utf-8"
        )
        private String orderId = " ";
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String entrustProp = " ";
        @SinogramLength(
                min = 0,
                max = 8,
                charset = "utf-8"
        )
        private String externCode = " ";
        @JsonSerialize(
                using = LongJsonSerializer.class
        )
        @JsonDeserialize(
                using = LongJsonDeserializer.class
        )
        private Long recordNo = 0L;
        private Integer dataId = 0;
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String optcombId = " ";

        public PostRealtimeFlowmodeErrorFeedBackInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public String getExchangeType() {
            if (this.exchangeType == null) {
                return " ";
            } else {
                return this.exchangeType.isEmpty() ? " " : this.exchangeType;
            }
        }

        public String getReportSeat() {
            if (this.reportSeat == null) {
                return " ";
            } else {
                return this.reportSeat.isEmpty() ? " " : this.reportSeat;
            }
        }

        public String getOrderId() {
            if (this.orderId == null) {
                return " ";
            } else {
                return this.orderId.isEmpty() ? " " : this.orderId;
            }
        }

        public String getEntrustProp() {
            if (this.entrustProp == null) {
                return " ";
            } else {
                return this.entrustProp.isEmpty() ? " " : this.entrustProp;
            }
        }

        public String getExternCode() {
            if (this.externCode == null) {
                return " ";
            } else {
                return this.externCode.isEmpty() ? " " : this.externCode;
            }
        }

        public Long getRecordNo() {
            return this.recordNo != null ? this.recordNo : 0L;
        }

        public Integer getDataId() {
            return this.dataId != null ? this.dataId : 0;
        }

        public String getOptcombId() {
            if (this.optcombId == null) {
                return " ";
            } else {
                return this.optcombId.isEmpty() ? " " : this.optcombId;
            }
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public void setReportSeat(String reportSeat) {
            this.reportSeat = reportSeat;
        }

        public void setOrderId(String orderId) {
            this.orderId = orderId;
        }

        public void setEntrustProp(String entrustProp) {
            this.entrustProp = entrustProp;
        }

        public void setExternCode(String externCode) {
            this.externCode = externCode;
        }

        public void setRecordNo(Long recordNo) {
            this.recordNo = recordNo;
        }

        public void setDataId(Integer dataId) {
            this.dataId = dataId;
        }

        public void setOptcombId(String optcombId) {
            this.optcombId = optcombId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostRealtimeFlowmodeErrorFeedBackInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",initDate:" + this.initDate);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(",reportSeat:" + this.reportSeat);
            buffer.append(",orderId:" + this.orderId);
            buffer.append(",entrustProp:" + this.entrustProp);
            buffer.append(",externCode:" + this.externCode);
            buffer.append(",recordNo:" + this.recordNo);
            buffer.append(",dataId:" + this.dataId);
            buffer.append(",optcombId:" + this.optcombId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.branchNo);
            builder.append(this.initDate);
            builder.append(this.exchangeType);
            builder.append(this.reportSeat);
            builder.append(this.orderId);
            builder.append(this.entrustProp);
            builder.append(this.externCode);
            builder.append(this.recordNo);
            builder.append(this.dataId);
            builder.append(this.optcombId);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PostRealtimeFlowmodeErrorFeedBackInnerInput obj) {
            if (obj instanceof InnerOptService.PostRealtimeFlowmodeErrorFeedBackInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, obj.opPassword);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.branchNo, obj.branchNo);
                builder.append(this.initDate, obj.initDate);
                builder.append(this.exchangeType, obj.exchangeType);
                builder.append(this.reportSeat, obj.reportSeat);
                builder.append(this.orderId, obj.orderId);
                builder.append(this.entrustProp, obj.entrustProp);
                builder.append(this.externCode, obj.externCode);
                builder.append(this.recordNo, obj.recordNo);
                builder.append(this.dataId, obj.dataId);
                builder.append(this.optcombId, obj.optcombId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostRealtimeErrorFeedBackInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer dataId = 0;
        private Integer errorNo = 0;
        private String errorInfo = " ";

        public PostRealtimeErrorFeedBackInnerOutput() {
        }

        public Integer getDataId() {
            return this.dataId != null ? this.dataId : 0;
        }

        public Integer getErrorNo() {
            return this.errorNo != null ? this.errorNo : 0;
        }

        public String getErrorInfo() {
            if (this.errorInfo == null) {
                return " ";
            } else {
                return this.errorInfo.isEmpty() ? " " : this.errorInfo;
            }
        }

        public void setDataId(Integer dataId) {
            this.dataId = dataId;
        }

        public void setErrorNo(Integer errorNo) {
            this.errorNo = errorNo;
        }

        public void setErrorInfo(String errorInfo) {
            this.errorInfo = errorInfo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostRealtimeErrorFeedBackInnerOutput:(");
            buffer.append("dataId:" + this.dataId);
            buffer.append(",errorNo:" + this.errorNo);
            buffer.append(",errorInfo:" + this.errorInfo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.dataId);
            builder.append(this.errorNo);
            builder.append(this.errorInfo);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PostRealtimeErrorFeedBackInnerOutput obj) {
            if (obj instanceof InnerOptService.PostRealtimeErrorFeedBackInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.dataId, obj.dataId);
                builder.append(this.errorNo, obj.errorNo);
                builder.append(this.errorInfo, obj.errorInfo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostRealtimeErrorFeedBackInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        private Integer initDate = 0;
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String exchangeType = " ";
        @SinogramLength(
                min = 0,
                max = 8,
                charset = "utf-8"
        )
        private String optionCode = " ";
        @SinogramLength(
                min = 0,
                max = 24,
                charset = "utf-8"
        )
        private String orderId = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character reportBs = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character coveredFlag = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character entrustOc = ' ';
        @SinogramLength(
                min = 0,
                max = 16,
                charset = "utf-8"
        )
        private String reportSeat = " ";
        @SinogramLength(
                min = 0,
                max = 20,
                charset = "utf-8"
        )
        private String reportAccount = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String businessId = " ";
        @Digits(
                integer = 13,
                fraction = 2,
                message = "businessAmount value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double businessAmount = 0.0D;
        @Digits(
                integer = 6,
                fraction = 6,
                message = "optBusinessPrice value out of bounds, integer=6, fraction=6"
        )
        @SerializeDoubleDigit(
                digit = 6
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double optBusinessPrice = 0.0D;
        private Integer businessTime = 0;
        private Integer reportTime = 0;
        @SinogramLength(
                min = 0,
                max = 8,
                charset = "utf-8"
        )
        private String externCode = " ";
        private Integer dataId = 0;
        @JsonSerialize(
                using = LongJsonSerializer.class
        )
        @JsonDeserialize(
                using = LongJsonDeserializer.class
        )
        private Long recordNo = 0L;
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String optcombId = " ";

        public PostRealtimeErrorFeedBackInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public String getExchangeType() {
            if (this.exchangeType == null) {
                return " ";
            } else {
                return this.exchangeType.isEmpty() ? " " : this.exchangeType;
            }
        }

        public String getOptionCode() {
            if (this.optionCode == null) {
                return " ";
            } else {
                return this.optionCode.isEmpty() ? " " : this.optionCode;
            }
        }

        public String getOrderId() {
            if (this.orderId == null) {
                return " ";
            } else {
                return this.orderId.isEmpty() ? " " : this.orderId;
            }
        }

        public Character getReportBs() {
            return this.reportBs != null ? this.reportBs : ' ';
        }

        public Character getCoveredFlag() {
            return this.coveredFlag != null ? this.coveredFlag : ' ';
        }

        public Character getEntrustOc() {
            return this.entrustOc != null ? this.entrustOc : ' ';
        }

        public String getReportSeat() {
            if (this.reportSeat == null) {
                return " ";
            } else {
                return this.reportSeat.isEmpty() ? " " : this.reportSeat;
            }
        }

        public String getReportAccount() {
            if (this.reportAccount == null) {
                return " ";
            } else {
                return this.reportAccount.isEmpty() ? " " : this.reportAccount;
            }
        }

        public String getBusinessId() {
            if (this.businessId == null) {
                return " ";
            } else {
                return this.businessId.isEmpty() ? " " : this.businessId;
            }
        }

        public Double getBusinessAmount() {
            return this.businessAmount != null ? this.businessAmount : 0.0D;
        }

        public Double getOptBusinessPrice() {
            return this.optBusinessPrice != null ? this.optBusinessPrice : 0.0D;
        }

        public Integer getBusinessTime() {
            return this.businessTime != null ? this.businessTime : 0;
        }

        public Integer getReportTime() {
            return this.reportTime != null ? this.reportTime : 0;
        }

        public String getExternCode() {
            if (this.externCode == null) {
                return " ";
            } else {
                return this.externCode.isEmpty() ? " " : this.externCode;
            }
        }

        public Integer getDataId() {
            return this.dataId != null ? this.dataId : 0;
        }

        public Long getRecordNo() {
            return this.recordNo != null ? this.recordNo : 0L;
        }

        public String getOptcombId() {
            if (this.optcombId == null) {
                return " ";
            } else {
                return this.optcombId.isEmpty() ? " " : this.optcombId;
            }
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public void setOptionCode(String optionCode) {
            this.optionCode = optionCode;
        }

        public void setOrderId(String orderId) {
            this.orderId = orderId;
        }

        public void setReportBs(Character reportBs) {
            this.reportBs = reportBs;
        }

        public void setCoveredFlag(Character coveredFlag) {
            this.coveredFlag = coveredFlag;
        }

        public void setEntrustOc(Character entrustOc) {
            this.entrustOc = entrustOc;
        }

        public void setReportSeat(String reportSeat) {
            this.reportSeat = reportSeat;
        }

        public void setReportAccount(String reportAccount) {
            this.reportAccount = reportAccount;
        }

        public void setBusinessId(String businessId) {
            this.businessId = businessId;
        }

        public void setBusinessAmount(Double businessAmount) {
            this.businessAmount = businessAmount;
        }

        public void setOptBusinessPrice(Double optBusinessPrice) {
            this.optBusinessPrice = optBusinessPrice;
        }

        public void setBusinessTime(Integer businessTime) {
            this.businessTime = businessTime;
        }

        public void setReportTime(Integer reportTime) {
            this.reportTime = reportTime;
        }

        public void setExternCode(String externCode) {
            this.externCode = externCode;
        }

        public void setDataId(Integer dataId) {
            this.dataId = dataId;
        }

        public void setRecordNo(Long recordNo) {
            this.recordNo = recordNo;
        }

        public void setOptcombId(String optcombId) {
            this.optcombId = optcombId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostRealtimeErrorFeedBackInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",initDate:" + this.initDate);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(",optionCode:" + this.optionCode);
            buffer.append(",orderId:" + this.orderId);
            buffer.append(",reportBs:" + this.reportBs);
            buffer.append(",coveredFlag:" + this.coveredFlag);
            buffer.append(",entrustOc:" + this.entrustOc);
            buffer.append(",reportSeat:" + this.reportSeat);
            buffer.append(",reportAccount:" + this.reportAccount);
            buffer.append(",businessId:" + this.businessId);
            buffer.append(",businessAmount:" + this.businessAmount);
            buffer.append(",optBusinessPrice:" + this.optBusinessPrice);
            buffer.append(",businessTime:" + this.businessTime);
            buffer.append(",reportTime:" + this.reportTime);
            buffer.append(",externCode:" + this.externCode);
            buffer.append(",dataId:" + this.dataId);
            buffer.append(",recordNo:" + this.recordNo);
            buffer.append(",optcombId:" + this.optcombId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.initDate);
            builder.append(this.exchangeType);
            builder.append(this.optionCode);
            builder.append(this.orderId);
            builder.append(this.reportBs);
            builder.append(this.coveredFlag);
            builder.append(this.entrustOc);
            builder.append(this.reportSeat);
            builder.append(this.reportAccount);
            builder.append(this.businessId);
            builder.append(this.businessAmount);
            builder.append(this.optBusinessPrice);
            builder.append(this.businessTime);
            builder.append(this.reportTime);
            builder.append(this.externCode);
            builder.append(this.dataId);
            builder.append(this.recordNo);
            builder.append(this.optcombId);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PostRealtimeErrorFeedBackInnerInput obj) {
            if (obj instanceof InnerOptService.PostRealtimeErrorFeedBackInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, obj.opPassword);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.initDate, obj.initDate);
                builder.append(this.exchangeType, obj.exchangeType);
                builder.append(this.optionCode, obj.optionCode);
                builder.append(this.orderId, obj.orderId);
                builder.append(this.reportBs, obj.reportBs);
                builder.append(this.coveredFlag, obj.coveredFlag);
                builder.append(this.entrustOc, obj.entrustOc);
                builder.append(this.reportSeat, obj.reportSeat);
                builder.append(this.reportAccount, obj.reportAccount);
                builder.append(this.businessId, obj.businessId);
                builder.append(this.businessAmount, obj.businessAmount);
                builder.append(this.optBusinessPrice, obj.optBusinessPrice);
                builder.append(this.businessTime, obj.businessTime);
                builder.append(this.reportTime, obj.reportTime);
                builder.append(this.externCode, obj.externCode);
                builder.append(this.dataId, obj.dataId);
                builder.append(this.recordNo, obj.recordNo);
                builder.append(this.optcombId, obj.optcombId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostRealtimeEnterFeedBackInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer dataId = 0;
        private Integer errorNo = 0;
        private String errorInfo = " ";

        public PostRealtimeEnterFeedBackInnerOutput() {
        }

        public Integer getDataId() {
            return this.dataId != null ? this.dataId : 0;
        }

        public Integer getErrorNo() {
            return this.errorNo != null ? this.errorNo : 0;
        }

        public String getErrorInfo() {
            if (this.errorInfo == null) {
                return " ";
            } else {
                return this.errorInfo.isEmpty() ? " " : this.errorInfo;
            }
        }

        public void setDataId(Integer dataId) {
            this.dataId = dataId;
        }

        public void setErrorNo(Integer errorNo) {
            this.errorNo = errorNo;
        }

        public void setErrorInfo(String errorInfo) {
            this.errorInfo = errorInfo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostRealtimeEnterFeedBackInnerOutput:(");
            buffer.append("dataId:" + this.dataId);
            buffer.append(",errorNo:" + this.errorNo);
            buffer.append(",errorInfo:" + this.errorInfo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.dataId);
            builder.append(this.errorNo);
            builder.append(this.errorInfo);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PostRealtimeEnterFeedBackInnerOutput obj) {
            if (obj instanceof InnerOptService.PostRealtimeEnterFeedBackInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.dataId, obj.dataId);
                builder.append(this.errorNo, obj.errorNo);
                builder.append(this.errorInfo, obj.errorInfo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostRealtimeEnterFeedBackInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        private Integer initDate = 0;
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String exchangeType = " ";
        @SinogramLength(
                min = 0,
                max = 24,
                charset = "utf-8"
        )
        private String orderId = " ";
        @SinogramLength(
                min = 0,
                max = 8,
                charset = "utf-8"
        )
        private String optionCode = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character reportBs = ' ';
        @SinogramLength(
                min = 0,
                max = 16,
                charset = "utf-8"
        )
        private String reportSeat = " ";
        @SinogramLength(
                min = 0,
                max = 20,
                charset = "utf-8"
        )
        private String reportAccount = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String businessId = " ";
        @Digits(
                integer = 13,
                fraction = 2,
                message = "businessAmount value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double businessAmount = 0.0D;
        @Digits(
                integer = 15,
                fraction = 8,
                message = "businessPrice value out of bounds, integer=15, fraction=8"
        )
        @SerializeDoubleDigit(
                digit = 8
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double businessPrice = 0.0D;
        private Integer businessTime = 0;
        private Integer reportTime = 0;
        @SinogramLength(
                min = 0,
                max = 8,
                charset = "utf-8"
        )
        private String externCode = " ";
        @JsonSerialize(
                using = LongJsonSerializer.class
        )
        @JsonDeserialize(
                using = LongJsonDeserializer.class
        )
        private Long recordNo = 0L;
        private Integer dataId = 0;

        public PostRealtimeEnterFeedBackInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public String getExchangeType() {
            if (this.exchangeType == null) {
                return " ";
            } else {
                return this.exchangeType.isEmpty() ? " " : this.exchangeType;
            }
        }

        public String getOrderId() {
            if (this.orderId == null) {
                return " ";
            } else {
                return this.orderId.isEmpty() ? " " : this.orderId;
            }
        }

        public String getOptionCode() {
            if (this.optionCode == null) {
                return " ";
            } else {
                return this.optionCode.isEmpty() ? " " : this.optionCode;
            }
        }

        public Character getReportBs() {
            return this.reportBs != null ? this.reportBs : ' ';
        }

        public String getReportSeat() {
            if (this.reportSeat == null) {
                return " ";
            } else {
                return this.reportSeat.isEmpty() ? " " : this.reportSeat;
            }
        }

        public String getReportAccount() {
            if (this.reportAccount == null) {
                return " ";
            } else {
                return this.reportAccount.isEmpty() ? " " : this.reportAccount;
            }
        }

        public String getBusinessId() {
            if (this.businessId == null) {
                return " ";
            } else {
                return this.businessId.isEmpty() ? " " : this.businessId;
            }
        }

        public Double getBusinessAmount() {
            return this.businessAmount != null ? this.businessAmount : 0.0D;
        }

        public Double getBusinessPrice() {
            return this.businessPrice != null ? this.businessPrice : 0.0D;
        }

        public Integer getBusinessTime() {
            return this.businessTime != null ? this.businessTime : 0;
        }

        public Integer getReportTime() {
            return this.reportTime != null ? this.reportTime : 0;
        }

        public String getExternCode() {
            if (this.externCode == null) {
                return " ";
            } else {
                return this.externCode.isEmpty() ? " " : this.externCode;
            }
        }

        public Long getRecordNo() {
            return this.recordNo != null ? this.recordNo : 0L;
        }

        public Integer getDataId() {
            return this.dataId != null ? this.dataId : 0;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public void setOrderId(String orderId) {
            this.orderId = orderId;
        }

        public void setOptionCode(String optionCode) {
            this.optionCode = optionCode;
        }

        public void setReportBs(Character reportBs) {
            this.reportBs = reportBs;
        }

        public void setReportSeat(String reportSeat) {
            this.reportSeat = reportSeat;
        }

        public void setReportAccount(String reportAccount) {
            this.reportAccount = reportAccount;
        }

        public void setBusinessId(String businessId) {
            this.businessId = businessId;
        }

        public void setBusinessAmount(Double businessAmount) {
            this.businessAmount = businessAmount;
        }

        public void setBusinessPrice(Double businessPrice) {
            this.businessPrice = businessPrice;
        }

        public void setBusinessTime(Integer businessTime) {
            this.businessTime = businessTime;
        }

        public void setReportTime(Integer reportTime) {
            this.reportTime = reportTime;
        }

        public void setExternCode(String externCode) {
            this.externCode = externCode;
        }

        public void setRecordNo(Long recordNo) {
            this.recordNo = recordNo;
        }

        public void setDataId(Integer dataId) {
            this.dataId = dataId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostRealtimeEnterFeedBackInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",initDate:" + this.initDate);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(",orderId:" + this.orderId);
            buffer.append(",optionCode:" + this.optionCode);
            buffer.append(",reportBs:" + this.reportBs);
            buffer.append(",reportSeat:" + this.reportSeat);
            buffer.append(",reportAccount:" + this.reportAccount);
            buffer.append(",businessId:" + this.businessId);
            buffer.append(",businessAmount:" + this.businessAmount);
            buffer.append(",businessPrice:" + this.businessPrice);
            buffer.append(",businessTime:" + this.businessTime);
            buffer.append(",reportTime:" + this.reportTime);
            buffer.append(",externCode:" + this.externCode);
            buffer.append(",recordNo:" + this.recordNo);
            buffer.append(",dataId:" + this.dataId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.initDate);
            builder.append(this.exchangeType);
            builder.append(this.orderId);
            builder.append(this.optionCode);
            builder.append(this.reportBs);
            builder.append(this.reportSeat);
            builder.append(this.reportAccount);
            builder.append(this.businessId);
            builder.append(this.businessAmount);
            builder.append(this.businessPrice);
            builder.append(this.businessTime);
            builder.append(this.reportTime);
            builder.append(this.externCode);
            builder.append(this.recordNo);
            builder.append(this.dataId);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PostRealtimeEnterFeedBackInnerInput obj) {
            if (obj instanceof InnerOptService.PostRealtimeEnterFeedBackInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, obj.opPassword);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.initDate, obj.initDate);
                builder.append(this.exchangeType, obj.exchangeType);
                builder.append(this.orderId, obj.orderId);
                builder.append(this.optionCode, obj.optionCode);
                builder.append(this.reportBs, obj.reportBs);
                builder.append(this.reportSeat, obj.reportSeat);
                builder.append(this.reportAccount, obj.reportAccount);
                builder.append(this.businessId, obj.businessId);
                builder.append(this.businessAmount, obj.businessAmount);
                builder.append(this.businessPrice, obj.businessPrice);
                builder.append(this.businessTime, obj.businessTime);
                builder.append(this.reportTime, obj.reportTime);
                builder.append(this.externCode, obj.externCode);
                builder.append(this.recordNo, obj.recordNo);
                builder.append(this.dataId, obj.dataId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostRealtimeDealFeedBackInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer dataId = 0;
        private Integer errorNo = 0;
        private String errorInfo = " ";

        public PostRealtimeDealFeedBackInnerOutput() {
        }

        public Integer getDataId() {
            return this.dataId != null ? this.dataId : 0;
        }

        public Integer getErrorNo() {
            return this.errorNo != null ? this.errorNo : 0;
        }

        public String getErrorInfo() {
            if (this.errorInfo == null) {
                return " ";
            } else {
                return this.errorInfo.isEmpty() ? " " : this.errorInfo;
            }
        }

        public void setDataId(Integer dataId) {
            this.dataId = dataId;
        }

        public void setErrorNo(Integer errorNo) {
            this.errorNo = errorNo;
        }

        public void setErrorInfo(String errorInfo) {
            this.errorInfo = errorInfo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostRealtimeDealFeedBackInnerOutput:(");
            buffer.append("dataId:" + this.dataId);
            buffer.append(",errorNo:" + this.errorNo);
            buffer.append(",errorInfo:" + this.errorInfo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.dataId);
            builder.append(this.errorNo);
            builder.append(this.errorInfo);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PostRealtimeDealFeedBackInnerOutput obj) {
            if (obj instanceof InnerOptService.PostRealtimeDealFeedBackInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.dataId, obj.dataId);
                builder.append(this.errorNo, obj.errorNo);
                builder.append(this.errorInfo, obj.errorInfo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostRealtimeDealFeedBackInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        private Integer initDate = 0;
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String exchangeType = "";
        @SinogramLength(
                min = 0,
                max = 24,
                charset = "utf-8"
        )
        private String orderId = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character reportBs = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character entrustOc = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character coveredFlag = ' ';
        @SinogramLength(
                min = 0,
                max = 16,
                charset = "utf-8"
        )
        private String reportSeat = "";
        @SinogramLength(
                min = 0,
                max = 8,
                charset = "utf-8"
        )
        private String optionCode = "";
        @SinogramLength(
                min = 0,
                max = 20,
                charset = "utf-8"
        )
        private String reportAccount = "";
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String businessNoStr = "";
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String businessAmountStr = "";
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String businessPriceStr = "";
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String businessTimeStr = "";
        private Integer reportTime = 0;
        @SinogramLength(
                min = 0,
                max = 8,
                charset = "utf-8"
        )
        private String externCode = "";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character entrustSrc = ' ';
        private Integer dataId = 0;

        public PostRealtimeDealFeedBackInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public String getExchangeType() {
            if (this.exchangeType == null) {
                return "";
            } else {
                return this.exchangeType.isEmpty() ? "" : this.exchangeType;
            }
        }

        public String getOrderId() {
            if (this.orderId == null) {
                return " ";
            } else {
                return this.orderId.isEmpty() ? " " : this.orderId;
            }
        }

        public Character getReportBs() {
            return this.reportBs != null ? this.reportBs : ' ';
        }

        public Character getEntrustOc() {
            return this.entrustOc != null ? this.entrustOc : ' ';
        }

        public Character getCoveredFlag() {
            return this.coveredFlag != null ? this.coveredFlag : ' ';
        }

        public String getReportSeat() {
            if (this.reportSeat == null) {
                return "";
            } else {
                return this.reportSeat.isEmpty() ? "" : this.reportSeat;
            }
        }

        public String getOptionCode() {
            if (this.optionCode == null) {
                return "";
            } else {
                return this.optionCode.isEmpty() ? "" : this.optionCode;
            }
        }

        public String getReportAccount() {
            if (this.reportAccount == null) {
                return "";
            } else {
                return this.reportAccount.isEmpty() ? "" : this.reportAccount;
            }
        }

        public String getBusinessNoStr() {
            if (this.businessNoStr == null) {
                return "";
            } else {
                return this.businessNoStr.isEmpty() ? "" : this.businessNoStr;
            }
        }

        public String getBusinessAmountStr() {
            if (this.businessAmountStr == null) {
                return "";
            } else {
                return this.businessAmountStr.isEmpty() ? "" : this.businessAmountStr;
            }
        }

        public String getBusinessPriceStr() {
            if (this.businessPriceStr == null) {
                return "";
            } else {
                return this.businessPriceStr.isEmpty() ? "" : this.businessPriceStr;
            }
        }

        public String getBusinessTimeStr() {
            if (this.businessTimeStr == null) {
                return "";
            } else {
                return this.businessTimeStr.isEmpty() ? "" : this.businessTimeStr;
            }
        }

        public Integer getReportTime() {
            return this.reportTime != null ? this.reportTime : 0;
        }

        public String getExternCode() {
            if (this.externCode == null) {
                return "";
            } else {
                return this.externCode.isEmpty() ? "" : this.externCode;
            }
        }

        public Character getEntrustSrc() {
            return this.entrustSrc != null ? this.entrustSrc : ' ';
        }

        public Integer getDataId() {
            return this.dataId != null ? this.dataId : 0;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public void setOrderId(String orderId) {
            this.orderId = orderId;
        }

        public void setReportBs(Character reportBs) {
            this.reportBs = reportBs;
        }

        public void setEntrustOc(Character entrustOc) {
            this.entrustOc = entrustOc;
        }

        public void setCoveredFlag(Character coveredFlag) {
            this.coveredFlag = coveredFlag;
        }

        public void setReportSeat(String reportSeat) {
            this.reportSeat = reportSeat;
        }

        public void setOptionCode(String optionCode) {
            this.optionCode = optionCode;
        }

        public void setReportAccount(String reportAccount) {
            this.reportAccount = reportAccount;
        }

        public void setBusinessNoStr(String businessNoStr) {
            this.businessNoStr = businessNoStr;
        }

        public void setBusinessAmountStr(String businessAmountStr) {
            this.businessAmountStr = businessAmountStr;
        }

        public void setBusinessPriceStr(String businessPriceStr) {
            this.businessPriceStr = businessPriceStr;
        }

        public void setBusinessTimeStr(String businessTimeStr) {
            this.businessTimeStr = businessTimeStr;
        }

        public void setReportTime(Integer reportTime) {
            this.reportTime = reportTime;
        }

        public void setExternCode(String externCode) {
            this.externCode = externCode;
        }

        public void setEntrustSrc(Character entrustSrc) {
            this.entrustSrc = entrustSrc;
        }

        public void setDataId(Integer dataId) {
            this.dataId = dataId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostRealtimeDealFeedBackInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",initDate:" + this.initDate);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(",orderId:" + this.orderId);
            buffer.append(",reportBs:" + this.reportBs);
            buffer.append(",entrustOc:" + this.entrustOc);
            buffer.append(",coveredFlag:" + this.coveredFlag);
            buffer.append(",reportSeat:" + this.reportSeat);
            buffer.append(",optionCode:" + this.optionCode);
            buffer.append(",reportAccount:" + this.reportAccount);
            buffer.append(",businessNoStr:" + this.businessNoStr);
            buffer.append(",businessAmountStr:" + this.businessAmountStr);
            buffer.append(",businessPriceStr:" + this.businessPriceStr);
            buffer.append(",businessTimeStr:" + this.businessTimeStr);
            buffer.append(",reportTime:" + this.reportTime);
            buffer.append(",externCode:" + this.externCode);
            buffer.append(",entrustSrc:" + this.entrustSrc);
            buffer.append(",dataId:" + this.dataId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.initDate);
            builder.append(this.exchangeType);
            builder.append(this.orderId);
            builder.append(this.reportBs);
            builder.append(this.entrustOc);
            builder.append(this.coveredFlag);
            builder.append(this.reportSeat);
            builder.append(this.optionCode);
            builder.append(this.reportAccount);
            builder.append(this.businessNoStr);
            builder.append(this.businessAmountStr);
            builder.append(this.businessPriceStr);
            builder.append(this.businessTimeStr);
            builder.append(this.reportTime);
            builder.append(this.externCode);
            builder.append(this.entrustSrc);
            builder.append(this.dataId);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PostRealtimeDealFeedBackInnerInput obj) {
            if (obj instanceof InnerOptService.PostRealtimeDealFeedBackInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, obj.opPassword);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.initDate, obj.initDate);
                builder.append(this.exchangeType, obj.exchangeType);
                builder.append(this.orderId, obj.orderId);
                builder.append(this.reportBs, obj.reportBs);
                builder.append(this.entrustOc, obj.entrustOc);
                builder.append(this.coveredFlag, obj.coveredFlag);
                builder.append(this.reportSeat, obj.reportSeat);
                builder.append(this.optionCode, obj.optionCode);
                builder.append(this.reportAccount, obj.reportAccount);
                builder.append(this.businessNoStr, obj.businessNoStr);
                builder.append(this.businessAmountStr, obj.businessAmountStr);
                builder.append(this.businessPriceStr, obj.businessPriceStr);
                builder.append(this.businessTimeStr, obj.businessTimeStr);
                builder.append(this.reportTime, obj.reportTime);
                builder.append(this.externCode, obj.externCode);
                builder.append(this.entrustSrc, obj.entrustSrc);
                builder.append(this.dataId, obj.dataId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostRealtimeCombErrorFeedBackInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer dataId = 0;
        private Integer errorNo = 0;
        private String errorInfo = " ";

        public PostRealtimeCombErrorFeedBackInnerOutput() {
        }

        public Integer getDataId() {
            return this.dataId != null ? this.dataId : 0;
        }

        public Integer getErrorNo() {
            return this.errorNo != null ? this.errorNo : 0;
        }

        public String getErrorInfo() {
            if (this.errorInfo == null) {
                return " ";
            } else {
                return this.errorInfo.isEmpty() ? " " : this.errorInfo;
            }
        }

        public void setDataId(Integer dataId) {
            this.dataId = dataId;
        }

        public void setErrorNo(Integer errorNo) {
            this.errorNo = errorNo;
        }

        public void setErrorInfo(String errorInfo) {
            this.errorInfo = errorInfo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostRealtimeCombErrorFeedBackInnerOutput:(");
            buffer.append("dataId:" + this.dataId);
            buffer.append(",errorNo:" + this.errorNo);
            buffer.append(",errorInfo:" + this.errorInfo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.dataId);
            builder.append(this.errorNo);
            builder.append(this.errorInfo);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PostRealtimeCombErrorFeedBackInnerOutput obj) {
            if (obj instanceof InnerOptService.PostRealtimeCombErrorFeedBackInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.dataId, obj.dataId);
                builder.append(this.errorNo, obj.errorNo);
                builder.append(this.errorInfo, obj.errorInfo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostRealtimeCombErrorFeedBackInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        private Integer initDate = 0;
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String exchangeType = " ";
        @SinogramLength(
                min = 0,
                max = 24,
                charset = "utf-8"
        )
        private String orderId = " ";
        @JsonSerialize(
                using = LongJsonSerializer.class
        )
        @JsonDeserialize(
                using = LongJsonDeserializer.class
        )
        private Long reportNo = 0L;
        @SinogramLength(
                min = 0,
                max = 8,
                charset = "utf-8"
        )
        private String optcombCode = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String optcombId = " ";
        private Integer componentCount = 0;
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String optionCodeStr = " ";
        @SinogramLength(
                min = 0,
                max = 20,
                charset = "utf-8"
        )
        private String optholdTypeStr = " ";
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String optcompAmountStr = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String businessId = " ";
        @Digits(
                integer = 13,
                fraction = 2,
                message = "businessAmount value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double businessAmount = 0.0D;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character reportBs = ' ';
        @SinogramLength(
                min = 0,
                max = 20,
                charset = "utf-8"
        )
        private String reportAccount = " ";
        @SinogramLength(
                min = 0,
                max = 16,
                charset = "utf-8"
        )
        private String reportSeat = " ";
        private Integer reportTime = 0;
        @SinogramLength(
                min = 0,
                max = 8,
                charset = "utf-8"
        )
        private String externCode = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character entrustSrc = ' ';
        private Integer businessTime = 0;
        private Integer dataId = 0;
        @JsonSerialize(
                using = LongJsonSerializer.class
        )
        @JsonDeserialize(
                using = LongJsonDeserializer.class
        )
        private Long recordNo = 0L;

        public PostRealtimeCombErrorFeedBackInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public String getExchangeType() {
            if (this.exchangeType == null) {
                return " ";
            } else {
                return this.exchangeType.isEmpty() ? " " : this.exchangeType;
            }
        }

        public String getOrderId() {
            if (this.orderId == null) {
                return " ";
            } else {
                return this.orderId.isEmpty() ? " " : this.orderId;
            }
        }

        public Long getReportNo() {
            return this.reportNo != null ? this.reportNo : 0L;
        }

        public String getOptcombCode() {
            if (this.optcombCode == null) {
                return " ";
            } else {
                return this.optcombCode.isEmpty() ? " " : this.optcombCode;
            }
        }

        public String getOptcombId() {
            if (this.optcombId == null) {
                return " ";
            } else {
                return this.optcombId.isEmpty() ? " " : this.optcombId;
            }
        }

        public Integer getComponentCount() {
            return this.componentCount != null ? this.componentCount : 0;
        }

        public String getOptionCodeStr() {
            if (this.optionCodeStr == null) {
                return " ";
            } else {
                return this.optionCodeStr.isEmpty() ? " " : this.optionCodeStr;
            }
        }

        public String getOptholdTypeStr() {
            if (this.optholdTypeStr == null) {
                return " ";
            } else {
                return this.optholdTypeStr.isEmpty() ? " " : this.optholdTypeStr;
            }
        }

        public String getOptcompAmountStr() {
            if (this.optcompAmountStr == null) {
                return " ";
            } else {
                return this.optcompAmountStr.isEmpty() ? " " : this.optcompAmountStr;
            }
        }

        public String getBusinessId() {
            if (this.businessId == null) {
                return " ";
            } else {
                return this.businessId.isEmpty() ? " " : this.businessId;
            }
        }

        public Double getBusinessAmount() {
            return this.businessAmount != null ? this.businessAmount : 0.0D;
        }

        public Character getReportBs() {
            return this.reportBs != null ? this.reportBs : ' ';
        }

        public String getReportAccount() {
            if (this.reportAccount == null) {
                return " ";
            } else {
                return this.reportAccount.isEmpty() ? " " : this.reportAccount;
            }
        }

        public String getReportSeat() {
            if (this.reportSeat == null) {
                return " ";
            } else {
                return this.reportSeat.isEmpty() ? " " : this.reportSeat;
            }
        }

        public Integer getReportTime() {
            return this.reportTime != null ? this.reportTime : 0;
        }

        public String getExternCode() {
            if (this.externCode == null) {
                return " ";
            } else {
                return this.externCode.isEmpty() ? " " : this.externCode;
            }
        }

        public Character getEntrustSrc() {
            return this.entrustSrc != null ? this.entrustSrc : ' ';
        }

        public Integer getBusinessTime() {
            return this.businessTime != null ? this.businessTime : 0;
        }

        public Integer getDataId() {
            return this.dataId != null ? this.dataId : 0;
        }

        public Long getRecordNo() {
            return this.recordNo != null ? this.recordNo : 0L;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public void setOrderId(String orderId) {
            this.orderId = orderId;
        }

        public void setReportNo(Long reportNo) {
            this.reportNo = reportNo;
        }

        public void setOptcombCode(String optcombCode) {
            this.optcombCode = optcombCode;
        }

        public void setOptcombId(String optcombId) {
            this.optcombId = optcombId;
        }

        public void setComponentCount(Integer componentCount) {
            this.componentCount = componentCount;
        }

        public void setOptionCodeStr(String optionCodeStr) {
            this.optionCodeStr = optionCodeStr;
        }

        public void setOptholdTypeStr(String optholdTypeStr) {
            this.optholdTypeStr = optholdTypeStr;
        }

        public void setOptcompAmountStr(String optcompAmountStr) {
            this.optcompAmountStr = optcompAmountStr;
        }

        public void setBusinessId(String businessId) {
            this.businessId = businessId;
        }

        public void setBusinessAmount(Double businessAmount) {
            this.businessAmount = businessAmount;
        }

        public void setReportBs(Character reportBs) {
            this.reportBs = reportBs;
        }

        public void setReportAccount(String reportAccount) {
            this.reportAccount = reportAccount;
        }

        public void setReportSeat(String reportSeat) {
            this.reportSeat = reportSeat;
        }

        public void setReportTime(Integer reportTime) {
            this.reportTime = reportTime;
        }

        public void setExternCode(String externCode) {
            this.externCode = externCode;
        }

        public void setEntrustSrc(Character entrustSrc) {
            this.entrustSrc = entrustSrc;
        }

        public void setBusinessTime(Integer businessTime) {
            this.businessTime = businessTime;
        }

        public void setDataId(Integer dataId) {
            this.dataId = dataId;
        }

        public void setRecordNo(Long recordNo) {
            this.recordNo = recordNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostRealtimeCombErrorFeedBackInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",initDate:" + this.initDate);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(",orderId:" + this.orderId);
            buffer.append(",reportNo:" + this.reportNo);
            buffer.append(",optcombCode:" + this.optcombCode);
            buffer.append(",optcombId:" + this.optcombId);
            buffer.append(",componentCount:" + this.componentCount);
            buffer.append(",optionCodeStr:" + this.optionCodeStr);
            buffer.append(",optholdTypeStr:" + this.optholdTypeStr);
            buffer.append(",optcompAmountStr:" + this.optcompAmountStr);
            buffer.append(",businessId:" + this.businessId);
            buffer.append(",businessAmount:" + this.businessAmount);
            buffer.append(",reportBs:" + this.reportBs);
            buffer.append(",reportAccount:" + this.reportAccount);
            buffer.append(",reportSeat:" + this.reportSeat);
            buffer.append(",reportTime:" + this.reportTime);
            buffer.append(",externCode:" + this.externCode);
            buffer.append(",entrustSrc:" + this.entrustSrc);
            buffer.append(",businessTime:" + this.businessTime);
            buffer.append(",dataId:" + this.dataId);
            buffer.append(",recordNo:" + this.recordNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.initDate);
            builder.append(this.exchangeType);
            builder.append(this.orderId);
            builder.append(this.reportNo);
            builder.append(this.optcombCode);
            builder.append(this.optcombId);
            builder.append(this.componentCount);
            builder.append(this.optionCodeStr);
            builder.append(this.optholdTypeStr);
            builder.append(this.optcompAmountStr);
            builder.append(this.businessId);
            builder.append(this.businessAmount);
            builder.append(this.reportBs);
            builder.append(this.reportAccount);
            builder.append(this.reportSeat);
            builder.append(this.reportTime);
            builder.append(this.externCode);
            builder.append(this.entrustSrc);
            builder.append(this.businessTime);
            builder.append(this.dataId);
            builder.append(this.recordNo);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PostRealtimeCombErrorFeedBackInnerInput obj) {
            if (obj instanceof InnerOptService.PostRealtimeCombErrorFeedBackInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, obj.opPassword);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.initDate, obj.initDate);
                builder.append(this.exchangeType, obj.exchangeType);
                builder.append(this.orderId, obj.orderId);
                builder.append(this.reportNo, obj.reportNo);
                builder.append(this.optcombCode, obj.optcombCode);
                builder.append(this.optcombId, obj.optcombId);
                builder.append(this.componentCount, obj.componentCount);
                builder.append(this.optionCodeStr, obj.optionCodeStr);
                builder.append(this.optholdTypeStr, obj.optholdTypeStr);
                builder.append(this.optcompAmountStr, obj.optcompAmountStr);
                builder.append(this.businessId, obj.businessId);
                builder.append(this.businessAmount, obj.businessAmount);
                builder.append(this.reportBs, obj.reportBs);
                builder.append(this.reportAccount, obj.reportAccount);
                builder.append(this.reportSeat, obj.reportSeat);
                builder.append(this.reportTime, obj.reportTime);
                builder.append(this.externCode, obj.externCode);
                builder.append(this.entrustSrc, obj.entrustSrc);
                builder.append(this.businessTime, obj.businessTime);
                builder.append(this.dataId, obj.dataId);
                builder.append(this.recordNo, obj.recordNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostRealtimeCombEnterFeedBackInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer dataId = 0;
        private Integer errorNo = 0;
        private String errorInfo = " ";

        public PostRealtimeCombEnterFeedBackInnerOutput() {
        }

        public Integer getDataId() {
            return this.dataId != null ? this.dataId : 0;
        }

        public Integer getErrorNo() {
            return this.errorNo != null ? this.errorNo : 0;
        }

        public String getErrorInfo() {
            if (this.errorInfo == null) {
                return " ";
            } else {
                return this.errorInfo.isEmpty() ? " " : this.errorInfo;
            }
        }

        public void setDataId(Integer dataId) {
            this.dataId = dataId;
        }

        public void setErrorNo(Integer errorNo) {
            this.errorNo = errorNo;
        }

        public void setErrorInfo(String errorInfo) {
            this.errorInfo = errorInfo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostRealtimeCombEnterFeedBackInnerOutput:(");
            buffer.append("dataId:" + this.dataId);
            buffer.append(",errorNo:" + this.errorNo);
            buffer.append(",errorInfo:" + this.errorInfo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.dataId);
            builder.append(this.errorNo);
            builder.append(this.errorInfo);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PostRealtimeCombEnterFeedBackInnerOutput obj) {
            if (obj instanceof InnerOptService.PostRealtimeCombEnterFeedBackInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.dataId, obj.dataId);
                builder.append(this.errorNo, obj.errorNo);
                builder.append(this.errorInfo, obj.errorInfo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostRealtimeCombEnterFeedBackInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        private Integer initDate = 0;
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String exchangeType = " ";
        @SinogramLength(
                min = 0,
                max = 24,
                charset = "utf-8"
        )
        private String orderId = " ";
        @JsonSerialize(
                using = LongJsonSerializer.class
        )
        @JsonDeserialize(
                using = LongJsonDeserializer.class
        )
        private Long reportNo = 0L;
        @SinogramLength(
                min = 0,
                max = 8,
                charset = "utf-8"
        )
        private String optcombCode = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String optcombId = " ";
        private Integer componentCount = 0;
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String optionCodeStr = " ";
        @SinogramLength(
                min = 0,
                max = 20,
                charset = "utf-8"
        )
        private String optholdTypeStr = " ";
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String optcompAmountStr = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String businessId = " ";
        @Digits(
                integer = 13,
                fraction = 2,
                message = "businessAmount value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double businessAmount = 0.0D;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character reportBs = ' ';
        @SinogramLength(
                min = 0,
                max = 20,
                charset = "utf-8"
        )
        private String reportAccount = " ";
        @SinogramLength(
                min = 0,
                max = 16,
                charset = "utf-8"
        )
        private String reportSeat = " ";
        private Integer reportTime = 0;
        @SinogramLength(
                min = 0,
                max = 8,
                charset = "utf-8"
        )
        private String externCode = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character entrustSrc = ' ';
        private Integer businessTime = 0;
        @JsonSerialize(
                using = LongJsonSerializer.class
        )
        @JsonDeserialize(
                using = LongJsonDeserializer.class
        )
        private Long recordNo = 0L;
        private Integer dataId = 0;

        public PostRealtimeCombEnterFeedBackInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public String getExchangeType() {
            if (this.exchangeType == null) {
                return " ";
            } else {
                return this.exchangeType.isEmpty() ? " " : this.exchangeType;
            }
        }

        public String getOrderId() {
            if (this.orderId == null) {
                return " ";
            } else {
                return this.orderId.isEmpty() ? " " : this.orderId;
            }
        }

        public Long getReportNo() {
            return this.reportNo != null ? this.reportNo : 0L;
        }

        public String getOptcombCode() {
            if (this.optcombCode == null) {
                return " ";
            } else {
                return this.optcombCode.isEmpty() ? " " : this.optcombCode;
            }
        }

        public String getOptcombId() {
            if (this.optcombId == null) {
                return " ";
            } else {
                return this.optcombId.isEmpty() ? " " : this.optcombId;
            }
        }

        public Integer getComponentCount() {
            return this.componentCount != null ? this.componentCount : 0;
        }

        public String getOptionCodeStr() {
            if (this.optionCodeStr == null) {
                return " ";
            } else {
                return this.optionCodeStr.isEmpty() ? " " : this.optionCodeStr;
            }
        }

        public String getOptholdTypeStr() {
            if (this.optholdTypeStr == null) {
                return " ";
            } else {
                return this.optholdTypeStr.isEmpty() ? " " : this.optholdTypeStr;
            }
        }

        public String getOptcompAmountStr() {
            if (this.optcompAmountStr == null) {
                return " ";
            } else {
                return this.optcompAmountStr.isEmpty() ? " " : this.optcompAmountStr;
            }
        }

        public String getBusinessId() {
            if (this.businessId == null) {
                return " ";
            } else {
                return this.businessId.isEmpty() ? " " : this.businessId;
            }
        }

        public Double getBusinessAmount() {
            return this.businessAmount != null ? this.businessAmount : 0.0D;
        }

        public Character getReportBs() {
            return this.reportBs != null ? this.reportBs : ' ';
        }

        public String getReportAccount() {
            if (this.reportAccount == null) {
                return " ";
            } else {
                return this.reportAccount.isEmpty() ? " " : this.reportAccount;
            }
        }

        public String getReportSeat() {
            if (this.reportSeat == null) {
                return " ";
            } else {
                return this.reportSeat.isEmpty() ? " " : this.reportSeat;
            }
        }

        public Integer getReportTime() {
            return this.reportTime != null ? this.reportTime : 0;
        }

        public String getExternCode() {
            if (this.externCode == null) {
                return " ";
            } else {
                return this.externCode.isEmpty() ? " " : this.externCode;
            }
        }

        public Character getEntrustSrc() {
            return this.entrustSrc != null ? this.entrustSrc : ' ';
        }

        public Integer getBusinessTime() {
            return this.businessTime != null ? this.businessTime : 0;
        }

        public Long getRecordNo() {
            return this.recordNo != null ? this.recordNo : 0L;
        }

        public Integer getDataId() {
            return this.dataId != null ? this.dataId : 0;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public void setOrderId(String orderId) {
            this.orderId = orderId;
        }

        public void setReportNo(Long reportNo) {
            this.reportNo = reportNo;
        }

        public void setOptcombCode(String optcombCode) {
            this.optcombCode = optcombCode;
        }

        public void setOptcombId(String optcombId) {
            this.optcombId = optcombId;
        }

        public void setComponentCount(Integer componentCount) {
            this.componentCount = componentCount;
        }

        public void setOptionCodeStr(String optionCodeStr) {
            this.optionCodeStr = optionCodeStr;
        }

        public void setOptholdTypeStr(String optholdTypeStr) {
            this.optholdTypeStr = optholdTypeStr;
        }

        public void setOptcompAmountStr(String optcompAmountStr) {
            this.optcompAmountStr = optcompAmountStr;
        }

        public void setBusinessId(String businessId) {
            this.businessId = businessId;
        }

        public void setBusinessAmount(Double businessAmount) {
            this.businessAmount = businessAmount;
        }

        public void setReportBs(Character reportBs) {
            this.reportBs = reportBs;
        }

        public void setReportAccount(String reportAccount) {
            this.reportAccount = reportAccount;
        }

        public void setReportSeat(String reportSeat) {
            this.reportSeat = reportSeat;
        }

        public void setReportTime(Integer reportTime) {
            this.reportTime = reportTime;
        }

        public void setExternCode(String externCode) {
            this.externCode = externCode;
        }

        public void setEntrustSrc(Character entrustSrc) {
            this.entrustSrc = entrustSrc;
        }

        public void setBusinessTime(Integer businessTime) {
            this.businessTime = businessTime;
        }

        public void setRecordNo(Long recordNo) {
            this.recordNo = recordNo;
        }

        public void setDataId(Integer dataId) {
            this.dataId = dataId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostRealtimeCombEnterFeedBackInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",initDate:" + this.initDate);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(",orderId:" + this.orderId);
            buffer.append(",reportNo:" + this.reportNo);
            buffer.append(",optcombCode:" + this.optcombCode);
            buffer.append(",optcombId:" + this.optcombId);
            buffer.append(",componentCount:" + this.componentCount);
            buffer.append(",optionCodeStr:" + this.optionCodeStr);
            buffer.append(",optholdTypeStr:" + this.optholdTypeStr);
            buffer.append(",optcompAmountStr:" + this.optcompAmountStr);
            buffer.append(",businessId:" + this.businessId);
            buffer.append(",businessAmount:" + this.businessAmount);
            buffer.append(",reportBs:" + this.reportBs);
            buffer.append(",reportAccount:" + this.reportAccount);
            buffer.append(",reportSeat:" + this.reportSeat);
            buffer.append(",reportTime:" + this.reportTime);
            buffer.append(",externCode:" + this.externCode);
            buffer.append(",entrustSrc:" + this.entrustSrc);
            buffer.append(",businessTime:" + this.businessTime);
            buffer.append(",recordNo:" + this.recordNo);
            buffer.append(",dataId:" + this.dataId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.initDate);
            builder.append(this.exchangeType);
            builder.append(this.orderId);
            builder.append(this.reportNo);
            builder.append(this.optcombCode);
            builder.append(this.optcombId);
            builder.append(this.componentCount);
            builder.append(this.optionCodeStr);
            builder.append(this.optholdTypeStr);
            builder.append(this.optcompAmountStr);
            builder.append(this.businessId);
            builder.append(this.businessAmount);
            builder.append(this.reportBs);
            builder.append(this.reportAccount);
            builder.append(this.reportSeat);
            builder.append(this.reportTime);
            builder.append(this.externCode);
            builder.append(this.entrustSrc);
            builder.append(this.businessTime);
            builder.append(this.recordNo);
            builder.append(this.dataId);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PostRealtimeCombEnterFeedBackInnerInput obj) {
            if (obj instanceof InnerOptService.PostRealtimeCombEnterFeedBackInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, obj.opPassword);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.initDate, obj.initDate);
                builder.append(this.exchangeType, obj.exchangeType);
                builder.append(this.orderId, obj.orderId);
                builder.append(this.reportNo, obj.reportNo);
                builder.append(this.optcombCode, obj.optcombCode);
                builder.append(this.optcombId, obj.optcombId);
                builder.append(this.componentCount, obj.componentCount);
                builder.append(this.optionCodeStr, obj.optionCodeStr);
                builder.append(this.optholdTypeStr, obj.optholdTypeStr);
                builder.append(this.optcompAmountStr, obj.optcompAmountStr);
                builder.append(this.businessId, obj.businessId);
                builder.append(this.businessAmount, obj.businessAmount);
                builder.append(this.reportBs, obj.reportBs);
                builder.append(this.reportAccount, obj.reportAccount);
                builder.append(this.reportSeat, obj.reportSeat);
                builder.append(this.reportTime, obj.reportTime);
                builder.append(this.externCode, obj.externCode);
                builder.append(this.entrustSrc, obj.entrustSrc);
                builder.append(this.businessTime, obj.businessTime);
                builder.append(this.recordNo, obj.recordNo);
                builder.append(this.dataId, obj.dataId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostRealtimeCombBuyCloseFeedBackInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer dataId = 0;
        private Integer errorNo = 0;
        private String errorInfo = " ";

        public PostRealtimeCombBuyCloseFeedBackInnerOutput() {
        }

        public Integer getDataId() {
            return this.dataId != null ? this.dataId : 0;
        }

        public Integer getErrorNo() {
            return this.errorNo != null ? this.errorNo : 0;
        }

        public String getErrorInfo() {
            if (this.errorInfo == null) {
                return " ";
            } else {
                return this.errorInfo.isEmpty() ? " " : this.errorInfo;
            }
        }

        public void setDataId(Integer dataId) {
            this.dataId = dataId;
        }

        public void setErrorNo(Integer errorNo) {
            this.errorNo = errorNo;
        }

        public void setErrorInfo(String errorInfo) {
            this.errorInfo = errorInfo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostRealtimeCombBuyCloseFeedBackInnerOutput:(");
            buffer.append("dataId:" + this.dataId);
            buffer.append(",errorNo:" + this.errorNo);
            buffer.append(",errorInfo:" + this.errorInfo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.dataId);
            builder.append(this.errorNo);
            builder.append(this.errorInfo);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PostRealtimeCombBuyCloseFeedBackInnerOutput obj) {
            if (obj instanceof InnerOptService.PostRealtimeCombBuyCloseFeedBackInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.dataId, obj.dataId);
                builder.append(this.errorNo, obj.errorNo);
                builder.append(this.errorInfo, obj.errorInfo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostRealtimeCombBuyCloseFeedBackInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        private Integer initDate = 0;
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String exchangeType = " ";
        @SinogramLength(
                min = 0,
                max = 24,
                charset = "utf-8"
        )
        private String orderId = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String optcombId = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character reportBs = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character entrustOc = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character coveredFlag = ' ';
        @SinogramLength(
                min = 0,
                max = 16,
                charset = "utf-8"
        )
        private String reportSeat = " ";
        @SinogramLength(
                min = 0,
                max = 8,
                charset = "utf-8"
        )
        private String optionCode = " ";
        @SinogramLength(
                min = 0,
                max = 20,
                charset = "utf-8"
        )
        private String reportAccount = " ";
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String businessNoStr = " ";
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String businessAmountStr = " ";
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String businessPriceStr = " ";
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String businessTimeStr = " ";
        private Integer reportTime = 0;
        @SinogramLength(
                min = 0,
                max = 8,
                charset = "utf-8"
        )
        private String externCode = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character entrustSrc = ' ';
        private Integer dataId = 0;
        @JsonSerialize(
                using = LongJsonSerializer.class
        )
        @JsonDeserialize(
                using = LongJsonDeserializer.class
        )
        private Long recordNo = 0L;

        public PostRealtimeCombBuyCloseFeedBackInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public String getExchangeType() {
            if (this.exchangeType == null) {
                return " ";
            } else {
                return this.exchangeType.isEmpty() ? " " : this.exchangeType;
            }
        }

        public String getOrderId() {
            if (this.orderId == null) {
                return " ";
            } else {
                return this.orderId.isEmpty() ? " " : this.orderId;
            }
        }

        public String getOptcombId() {
            if (this.optcombId == null) {
                return " ";
            } else {
                return this.optcombId.isEmpty() ? " " : this.optcombId;
            }
        }

        public Character getReportBs() {
            return this.reportBs != null ? this.reportBs : ' ';
        }

        public Character getEntrustOc() {
            return this.entrustOc != null ? this.entrustOc : ' ';
        }

        public Character getCoveredFlag() {
            return this.coveredFlag != null ? this.coveredFlag : ' ';
        }

        public String getReportSeat() {
            if (this.reportSeat == null) {
                return " ";
            } else {
                return this.reportSeat.isEmpty() ? " " : this.reportSeat;
            }
        }

        public String getOptionCode() {
            if (this.optionCode == null) {
                return " ";
            } else {
                return this.optionCode.isEmpty() ? " " : this.optionCode;
            }
        }

        public String getReportAccount() {
            if (this.reportAccount == null) {
                return " ";
            } else {
                return this.reportAccount.isEmpty() ? " " : this.reportAccount;
            }
        }

        public String getBusinessNoStr() {
            if (this.businessNoStr == null) {
                return " ";
            } else {
                return this.businessNoStr.isEmpty() ? " " : this.businessNoStr;
            }
        }

        public String getBusinessAmountStr() {
            if (this.businessAmountStr == null) {
                return " ";
            } else {
                return this.businessAmountStr.isEmpty() ? " " : this.businessAmountStr;
            }
        }

        public String getBusinessPriceStr() {
            if (this.businessPriceStr == null) {
                return " ";
            } else {
                return this.businessPriceStr.isEmpty() ? " " : this.businessPriceStr;
            }
        }

        public String getBusinessTimeStr() {
            if (this.businessTimeStr == null) {
                return " ";
            } else {
                return this.businessTimeStr.isEmpty() ? " " : this.businessTimeStr;
            }
        }

        public Integer getReportTime() {
            return this.reportTime != null ? this.reportTime : 0;
        }

        public String getExternCode() {
            if (this.externCode == null) {
                return " ";
            } else {
                return this.externCode.isEmpty() ? " " : this.externCode;
            }
        }

        public Character getEntrustSrc() {
            return this.entrustSrc != null ? this.entrustSrc : ' ';
        }

        public Integer getDataId() {
            return this.dataId != null ? this.dataId : 0;
        }

        public Long getRecordNo() {
            return this.recordNo != null ? this.recordNo : 0L;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public void setOrderId(String orderId) {
            this.orderId = orderId;
        }

        public void setOptcombId(String optcombId) {
            this.optcombId = optcombId;
        }

        public void setReportBs(Character reportBs) {
            this.reportBs = reportBs;
        }

        public void setEntrustOc(Character entrustOc) {
            this.entrustOc = entrustOc;
        }

        public void setCoveredFlag(Character coveredFlag) {
            this.coveredFlag = coveredFlag;
        }

        public void setReportSeat(String reportSeat) {
            this.reportSeat = reportSeat;
        }

        public void setOptionCode(String optionCode) {
            this.optionCode = optionCode;
        }

        public void setReportAccount(String reportAccount) {
            this.reportAccount = reportAccount;
        }

        public void setBusinessNoStr(String businessNoStr) {
            this.businessNoStr = businessNoStr;
        }

        public void setBusinessAmountStr(String businessAmountStr) {
            this.businessAmountStr = businessAmountStr;
        }

        public void setBusinessPriceStr(String businessPriceStr) {
            this.businessPriceStr = businessPriceStr;
        }

        public void setBusinessTimeStr(String businessTimeStr) {
            this.businessTimeStr = businessTimeStr;
        }

        public void setReportTime(Integer reportTime) {
            this.reportTime = reportTime;
        }

        public void setExternCode(String externCode) {
            this.externCode = externCode;
        }

        public void setEntrustSrc(Character entrustSrc) {
            this.entrustSrc = entrustSrc;
        }

        public void setDataId(Integer dataId) {
            this.dataId = dataId;
        }

        public void setRecordNo(Long recordNo) {
            this.recordNo = recordNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostRealtimeCombBuyCloseFeedBackInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",initDate:" + this.initDate);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(",orderId:" + this.orderId);
            buffer.append(",optcombId:" + this.optcombId);
            buffer.append(",reportBs:" + this.reportBs);
            buffer.append(",entrustOc:" + this.entrustOc);
            buffer.append(",coveredFlag:" + this.coveredFlag);
            buffer.append(",reportSeat:" + this.reportSeat);
            buffer.append(",optionCode:" + this.optionCode);
            buffer.append(",reportAccount:" + this.reportAccount);
            buffer.append(",businessNoStr:" + this.businessNoStr);
            buffer.append(",businessAmountStr:" + this.businessAmountStr);
            buffer.append(",businessPriceStr:" + this.businessPriceStr);
            buffer.append(",businessTimeStr:" + this.businessTimeStr);
            buffer.append(",reportTime:" + this.reportTime);
            buffer.append(",externCode:" + this.externCode);
            buffer.append(",entrustSrc:" + this.entrustSrc);
            buffer.append(",dataId:" + this.dataId);
            buffer.append(",recordNo:" + this.recordNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.initDate);
            builder.append(this.exchangeType);
            builder.append(this.orderId);
            builder.append(this.optcombId);
            builder.append(this.reportBs);
            builder.append(this.entrustOc);
            builder.append(this.coveredFlag);
            builder.append(this.reportSeat);
            builder.append(this.optionCode);
            builder.append(this.reportAccount);
            builder.append(this.businessNoStr);
            builder.append(this.businessAmountStr);
            builder.append(this.businessPriceStr);
            builder.append(this.businessTimeStr);
            builder.append(this.reportTime);
            builder.append(this.externCode);
            builder.append(this.entrustSrc);
            builder.append(this.dataId);
            builder.append(this.recordNo);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PostRealtimeCombBuyCloseFeedBackInnerInput obj) {
            if (obj instanceof InnerOptService.PostRealtimeCombBuyCloseFeedBackInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, obj.opPassword);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.initDate, obj.initDate);
                builder.append(this.exchangeType, obj.exchangeType);
                builder.append(this.orderId, obj.orderId);
                builder.append(this.optcombId, obj.optcombId);
                builder.append(this.reportBs, obj.reportBs);
                builder.append(this.entrustOc, obj.entrustOc);
                builder.append(this.coveredFlag, obj.coveredFlag);
                builder.append(this.reportSeat, obj.reportSeat);
                builder.append(this.optionCode, obj.optionCode);
                builder.append(this.reportAccount, obj.reportAccount);
                builder.append(this.businessNoStr, obj.businessNoStr);
                builder.append(this.businessAmountStr, obj.businessAmountStr);
                builder.append(this.businessPriceStr, obj.businessPriceStr);
                builder.append(this.businessTimeStr, obj.businessTimeStr);
                builder.append(this.reportTime, obj.reportTime);
                builder.append(this.externCode, obj.externCode);
                builder.append(this.entrustSrc, obj.entrustSrc);
                builder.append(this.dataId, obj.dataId);
                builder.append(this.recordNo, obj.recordNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostOptinnerwithdrawAfterhoursInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @JsonSerialize(
                using = LongJsonSerializer.class
        )
        @JsonDeserialize(
                using = LongJsonDeserializer.class
        )
        private Long entrustNo = 0L;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fundAccount = " ";
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String exchangeType = " ";

        public PostOptinnerwithdrawAfterhoursInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public Long getEntrustNo() {
            return this.entrustNo != null ? this.entrustNo : 0L;
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getExchangeType() {
            if (this.exchangeType == null) {
                return " ";
            } else {
                return this.exchangeType.isEmpty() ? " " : this.exchangeType;
            }
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setEntrustNo(Long entrustNo) {
            this.entrustNo = entrustNo;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostOptinnerwithdrawAfterhoursInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",entrustNo:" + this.entrustNo);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.entrustNo);
            builder.append(this.fundAccount);
            builder.append(this.exchangeType);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PostOptinnerwithdrawAfterhoursInnerInput obj) {
            if (obj instanceof InnerOptService.PostOptinnerwithdrawAfterhoursInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, obj.opPassword);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.entrustNo, obj.entrustNo);
                builder.append(this.fundAccount, obj.fundAccount);
                builder.append(this.exchangeType, obj.exchangeType);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostFundrealMoneyTypeOpenInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        @JsonSerialize(
                using = LongJsonSerializer.class
        )
        @JsonDeserialize(
                using = LongJsonDeserializer.class
        )
        private Long serialNo = 0L;

        public PostFundrealMoneyTypeOpenInnerOutput() {
        }

        public Long getSerialNo() {
            return this.serialNo != null ? this.serialNo : 0L;
        }

        public void setSerialNo(Long serialNo) {
            this.serialNo = serialNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostFundrealMoneyTypeOpenInnerOutput:(");
            buffer.append("serialNo:" + this.serialNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.serialNo);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PostFundrealMoneyTypeOpenInnerOutput obj) {
            if (obj instanceof InnerOptService.PostFundrealMoneyTypeOpenInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.serialNo, obj.serialNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostFundrealMoneyTypeOpenInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String clientId = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fundAccount = " ";
        @SinogramLength(
                min = 0,
                max = 3,
                charset = "utf-8"
        )
        private String moneyType = " ";

        public PostFundrealMoneyTypeOpenInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getMoneyType() {
            if (this.moneyType == null) {
                return " ";
            } else {
                return this.moneyType.isEmpty() ? " " : this.moneyType;
            }
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setMoneyType(String moneyType) {
            this.moneyType = moneyType;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostFundrealMoneyTypeOpenInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",moneyType:" + this.moneyType);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.clientId);
            builder.append(this.fundAccount);
            builder.append(this.moneyType);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PostFundrealMoneyTypeOpenInnerInput obj) {
            if (obj instanceof InnerOptService.PostFundrealMoneyTypeOpenInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, obj.opPassword);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.clientId, obj.clientId);
                builder.append(this.fundAccount, obj.fundAccount);
                builder.append(this.moneyType, obj.moneyType);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostFundrealMoneyTypeCloseInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        @JsonSerialize(
                using = LongJsonSerializer.class
        )
        @JsonDeserialize(
                using = LongJsonDeserializer.class
        )
        private Long serialNo = 0L;

        public PostFundrealMoneyTypeCloseInnerOutput() {
        }

        public Long getSerialNo() {
            return this.serialNo != null ? this.serialNo : 0L;
        }

        public void setSerialNo(Long serialNo) {
            this.serialNo = serialNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostFundrealMoneyTypeCloseInnerOutput:(");
            buffer.append("serialNo:" + this.serialNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.serialNo);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PostFundrealMoneyTypeCloseInnerOutput obj) {
            if (obj instanceof InnerOptService.PostFundrealMoneyTypeCloseInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.serialNo, obj.serialNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostFundrealMoneyTypeCloseInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String fundAccount;
        @SinogramLength(
                min = 1,
                max = 3,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String moneyType;

        public PostFundrealMoneyTypeCloseInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getClientId() {
            return this.clientId;
        }

        public String getFundAccount() {
            return this.fundAccount;
        }

        public String getMoneyType() {
            return this.moneyType;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setMoneyType(String moneyType) {
            this.moneyType = moneyType;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostFundrealMoneyTypeCloseInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",moneyType:" + this.moneyType);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.clientId);
            builder.append(this.fundAccount);
            builder.append(this.moneyType);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PostFundrealMoneyTypeCloseInnerInput obj) {
            if (obj instanceof InnerOptService.PostFundrealMoneyTypeCloseInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, obj.opPassword);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.clientId, obj.clientId);
                builder.append(this.fundAccount, obj.fundAccount);
                builder.append(this.moneyType, obj.moneyType);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostEntrustWithdrawInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        @JsonSerialize(
                using = LongJsonSerializer.class
        )
        @JsonDeserialize(
                using = LongJsonDeserializer.class
        )
        private Long entrustNo = 0L;
        @JsonSerialize(
                using = LongJsonSerializer.class
        )
        @JsonDeserialize(
                using = LongJsonDeserializer.class
        )
        private Long batchNo = 0L;
        private String exchangeType = " ";

        public PostEntrustWithdrawInnerOutput() {
        }

        public Long getEntrustNo() {
            return this.entrustNo != null ? this.entrustNo : 0L;
        }

        public Long getBatchNo() {
            return this.batchNo != null ? this.batchNo : 0L;
        }

        public String getExchangeType() {
            if (this.exchangeType == null) {
                return " ";
            } else {
                return this.exchangeType.isEmpty() ? " " : this.exchangeType;
            }
        }

        public void setEntrustNo(Long entrustNo) {
            this.entrustNo = entrustNo;
        }

        public void setBatchNo(Long batchNo) {
            this.batchNo = batchNo;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostEntrustWithdrawInnerOutput:(");
            buffer.append("entrustNo:" + this.entrustNo);
            buffer.append(",batchNo:" + this.batchNo);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.entrustNo);
            builder.append(this.batchNo);
            builder.append(this.exchangeType);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PostEntrustWithdrawInnerOutput obj) {
            if (obj instanceof InnerOptService.PostEntrustWithdrawInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.entrustNo, obj.entrustNo);
                builder.append(this.batchNo, obj.batchNo);
                builder.append(this.exchangeType, obj.exchangeType);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostEntrustWithdrawInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        private Integer actionIn = 0;
        @JsonSerialize(
                using = LongJsonSerializer.class
        )
        @JsonDeserialize(
                using = LongJsonDeserializer.class
        )
        private Long batchNo = 0L;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String clientId = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fundAccount = " ";
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String exchangeType = " ";
        @JsonSerialize(
                using = LongJsonSerializer.class
        )
        @JsonDeserialize(
                using = LongJsonDeserializer.class
        )
        private Long entrustNo = 0L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String password = " ";
        @SinogramLength(
                min = 0,
                max = 20,
                charset = "utf-8"
        )
        private String stockAccount = " ";

        public PostEntrustWithdrawInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public Integer getActionIn() {
            return this.actionIn != null ? this.actionIn : 0;
        }

        public Long getBatchNo() {
            return this.batchNo != null ? this.batchNo : 0L;
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getExchangeType() {
            if (this.exchangeType == null) {
                return " ";
            } else {
                return this.exchangeType.isEmpty() ? " " : this.exchangeType;
            }
        }

        public Long getEntrustNo() {
            return this.entrustNo != null ? this.entrustNo : 0L;
        }

        public String getPassword() {
            if (this.password == null) {
                return " ";
            } else {
                return this.password.isEmpty() ? " " : this.password;
            }
        }

        public String getStockAccount() {
            if (this.stockAccount == null) {
                return " ";
            } else {
                return this.stockAccount.isEmpty() ? " " : this.stockAccount;
            }
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setActionIn(Integer actionIn) {
            this.actionIn = actionIn;
        }

        public void setBatchNo(Long batchNo) {
            this.batchNo = batchNo;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public void setEntrustNo(Long entrustNo) {
            this.entrustNo = entrustNo;
        }

        public void setPassword(String password) {
            this.password = password;
        }

        public void setStockAccount(String stockAccount) {
            this.stockAccount = stockAccount;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostEntrustWithdrawInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",actionIn:" + this.actionIn);
            buffer.append(",batchNo:" + this.batchNo);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(",entrustNo:" + this.entrustNo);
            buffer.append(",password:" + this.password);
            buffer.append(",stockAccount:" + this.stockAccount);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.actionIn);
            builder.append(this.batchNo);
            builder.append(this.clientId);
            builder.append(this.fundAccount);
            builder.append(this.exchangeType);
            builder.append(this.entrustNo);
            builder.append(this.password);
            builder.append(this.stockAccount);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PostEntrustWithdrawInnerInput obj) {
            if (obj instanceof InnerOptService.PostEntrustWithdrawInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, obj.opPassword);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.actionIn, obj.actionIn);
                builder.append(this.batchNo, obj.batchNo);
                builder.append(this.clientId, obj.clientId);
                builder.append(this.fundAccount, obj.fundAccount);
                builder.append(this.exchangeType, obj.exchangeType);
                builder.append(this.entrustNo, obj.entrustNo);
                builder.append(this.password, obj.password);
                builder.append(this.stockAccount, obj.stockAccount);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostEntrustForcedcloseInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        @JsonSerialize(
                using = LongJsonSerializer.class
        )
        @JsonDeserialize(
                using = LongJsonDeserializer.class
        )
        private Long batchNo = 0L;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character coveredFlag = ' ';
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double enableBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double entrustAmount = 0.0D;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character entrustBs = ' ';
        @JsonSerialize(
                using = LongJsonSerializer.class
        )
        @JsonDeserialize(
                using = LongJsonDeserializer.class
        )
        private Long entrustNo = 0L;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character entrustOc = ' ';
        private String entrustProp = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character entrustStatus = ' ';
        private Integer entrustTime = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character entrustType = ' ';
        @SerializeDoubleDigit(
                digit = 6
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double optEntrustPrice = 0.0D;

        public PostEntrustForcedcloseInnerOutput() {
        }

        public Long getBatchNo() {
            return this.batchNo != null ? this.batchNo : 0L;
        }

        public Character getCoveredFlag() {
            return this.coveredFlag != null ? this.coveredFlag : ' ';
        }

        public Double getEnableBalance() {
            return this.enableBalance != null ? this.enableBalance : 0.0D;
        }

        public Double getEntrustAmount() {
            return this.entrustAmount != null ? this.entrustAmount : 0.0D;
        }

        public Character getEntrustBs() {
            return this.entrustBs != null ? this.entrustBs : ' ';
        }

        public Long getEntrustNo() {
            return this.entrustNo != null ? this.entrustNo : 0L;
        }

        public Character getEntrustOc() {
            return this.entrustOc != null ? this.entrustOc : ' ';
        }

        public String getEntrustProp() {
            if (this.entrustProp == null) {
                return " ";
            } else {
                return this.entrustProp.isEmpty() ? " " : this.entrustProp;
            }
        }

        public Character getEntrustStatus() {
            return this.entrustStatus != null ? this.entrustStatus : ' ';
        }

        public Integer getEntrustTime() {
            return this.entrustTime != null ? this.entrustTime : 0;
        }

        public Character getEntrustType() {
            return this.entrustType != null ? this.entrustType : ' ';
        }

        public Double getOptEntrustPrice() {
            return this.optEntrustPrice != null ? this.optEntrustPrice : 0.0D;
        }

        public void setBatchNo(Long batchNo) {
            this.batchNo = batchNo;
        }

        public void setCoveredFlag(Character coveredFlag) {
            this.coveredFlag = coveredFlag;
        }

        public void setEnableBalance(Double enableBalance) {
            this.enableBalance = enableBalance;
        }

        public void setEntrustAmount(Double entrustAmount) {
            this.entrustAmount = entrustAmount;
        }

        public void setEntrustBs(Character entrustBs) {
            this.entrustBs = entrustBs;
        }

        public void setEntrustNo(Long entrustNo) {
            this.entrustNo = entrustNo;
        }

        public void setEntrustOc(Character entrustOc) {
            this.entrustOc = entrustOc;
        }

        public void setEntrustProp(String entrustProp) {
            this.entrustProp = entrustProp;
        }

        public void setEntrustStatus(Character entrustStatus) {
            this.entrustStatus = entrustStatus;
        }

        public void setEntrustTime(Integer entrustTime) {
            this.entrustTime = entrustTime;
        }

        public void setEntrustType(Character entrustType) {
            this.entrustType = entrustType;
        }

        public void setOptEntrustPrice(Double optEntrustPrice) {
            this.optEntrustPrice = optEntrustPrice;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostEntrustForcedcloseInnerOutput:(");
            buffer.append("batchNo:" + this.batchNo);
            buffer.append(",coveredFlag:" + this.coveredFlag);
            buffer.append(",enableBalance:" + this.enableBalance);
            buffer.append(",entrustAmount:" + this.entrustAmount);
            buffer.append(",entrustBs:" + this.entrustBs);
            buffer.append(",entrustNo:" + this.entrustNo);
            buffer.append(",entrustOc:" + this.entrustOc);
            buffer.append(",entrustProp:" + this.entrustProp);
            buffer.append(",entrustStatus:" + this.entrustStatus);
            buffer.append(",entrustTime:" + this.entrustTime);
            buffer.append(",entrustType:" + this.entrustType);
            buffer.append(",optEntrustPrice:" + this.optEntrustPrice);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.batchNo);
            builder.append(this.coveredFlag);
            builder.append(this.enableBalance);
            builder.append(this.entrustAmount);
            builder.append(this.entrustBs);
            builder.append(this.entrustNo);
            builder.append(this.entrustOc);
            builder.append(this.entrustProp);
            builder.append(this.entrustStatus);
            builder.append(this.entrustTime);
            builder.append(this.entrustType);
            builder.append(this.optEntrustPrice);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PostEntrustForcedcloseInnerOutput obj) {
            if (obj instanceof InnerOptService.PostEntrustForcedcloseInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.batchNo, obj.batchNo);
                builder.append(this.coveredFlag, obj.coveredFlag);
                builder.append(this.enableBalance, obj.enableBalance);
                builder.append(this.entrustAmount, obj.entrustAmount);
                builder.append(this.entrustBs, obj.entrustBs);
                builder.append(this.entrustNo, obj.entrustNo);
                builder.append(this.entrustOc, obj.entrustOc);
                builder.append(this.entrustProp, obj.entrustProp);
                builder.append(this.entrustStatus, obj.entrustStatus);
                builder.append(this.entrustTime, obj.entrustTime);
                builder.append(this.entrustType, obj.entrustType);
                builder.append(this.optEntrustPrice, obj.optEntrustPrice);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostEntrustForcedcloseInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @JsonSerialize(
                using = LongJsonSerializer.class
        )
        @JsonDeserialize(
                using = LongJsonDeserializer.class
        )
        private Long batchNo = 0L;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character coveredFlag = ' ';
        @Digits(
                integer = 13,
                fraction = 2,
                message = "entrustAmount value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double entrustAmount = 0.0D;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character entrustBs = ' ';
        @JsonSerialize(
                using = LongJsonSerializer.class
        )
        @JsonDeserialize(
                using = LongJsonDeserializer.class
        )
        private Long entrustNo = 0L;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character entrustOc = ' ';
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String entrustProp = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character entrustType = ' ';
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String exchangeType = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fundAccount = " ";
        @JsonSerialize(
                using = LongJsonSerializer.class
        )
        @JsonDeserialize(
                using = LongJsonDeserializer.class
        )
        private Long joinReportNo = 0L;
        @Digits(
                integer = 6,
                fraction = 6,
                message = "optEntrustPrice value out of bounds, integer=6, fraction=6"
        )
        @SerializeDoubleDigit(
                digit = 6
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double optEntrustPrice = 0.0D;
        @SinogramLength(
                min = 1,
                max = 8,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String optionCode;
        @SinogramLength(
                min = 0,
                max = 20,
                charset = "utf-8"
        )
        private String stockAccount = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String optcombId = " ";

        public PostEntrustForcedcloseInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public Long getBatchNo() {
            return this.batchNo != null ? this.batchNo : 0L;
        }

        public String getClientId() {
            return this.clientId;
        }

        public Character getCoveredFlag() {
            return this.coveredFlag != null ? this.coveredFlag : ' ';
        }

        public Double getEntrustAmount() {
            return this.entrustAmount != null ? this.entrustAmount : 0.0D;
        }

        public Character getEntrustBs() {
            return this.entrustBs != null ? this.entrustBs : ' ';
        }

        public Long getEntrustNo() {
            return this.entrustNo != null ? this.entrustNo : 0L;
        }

        public Character getEntrustOc() {
            return this.entrustOc != null ? this.entrustOc : ' ';
        }

        public String getEntrustProp() {
            if (this.entrustProp == null) {
                return " ";
            } else {
                return this.entrustProp.isEmpty() ? " " : this.entrustProp;
            }
        }

        public Character getEntrustType() {
            return this.entrustType != null ? this.entrustType : ' ';
        }

        public String getExchangeType() {
            if (this.exchangeType == null) {
                return " ";
            } else {
                return this.exchangeType.isEmpty() ? " " : this.exchangeType;
            }
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public Long getJoinReportNo() {
            return this.joinReportNo != null ? this.joinReportNo : 0L;
        }

        public Double getOptEntrustPrice() {
            return this.optEntrustPrice != null ? this.optEntrustPrice : 0.0D;
        }

        public String getOptionCode() {
            return this.optionCode;
        }

        public String getStockAccount() {
            if (this.stockAccount == null) {
                return " ";
            } else {
                return this.stockAccount.isEmpty() ? " " : this.stockAccount;
            }
        }

        public String getOptcombId() {
            if (this.optcombId == null) {
                return " ";
            } else {
                return this.optcombId.isEmpty() ? " " : this.optcombId;
            }
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setBatchNo(Long batchNo) {
            this.batchNo = batchNo;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setCoveredFlag(Character coveredFlag) {
            this.coveredFlag = coveredFlag;
        }

        public void setEntrustAmount(Double entrustAmount) {
            this.entrustAmount = entrustAmount;
        }

        public void setEntrustBs(Character entrustBs) {
            this.entrustBs = entrustBs;
        }

        public void setEntrustNo(Long entrustNo) {
            this.entrustNo = entrustNo;
        }

        public void setEntrustOc(Character entrustOc) {
            this.entrustOc = entrustOc;
        }

        public void setEntrustProp(String entrustProp) {
            this.entrustProp = entrustProp;
        }

        public void setEntrustType(Character entrustType) {
            this.entrustType = entrustType;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setJoinReportNo(Long joinReportNo) {
            this.joinReportNo = joinReportNo;
        }

        public void setOptEntrustPrice(Double optEntrustPrice) {
            this.optEntrustPrice = optEntrustPrice;
        }

        public void setOptionCode(String optionCode) {
            this.optionCode = optionCode;
        }

        public void setStockAccount(String stockAccount) {
            this.stockAccount = stockAccount;
        }

        public void setOptcombId(String optcombId) {
            this.optcombId = optcombId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostEntrustForcedcloseInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",batchNo:" + this.batchNo);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",coveredFlag:" + this.coveredFlag);
            buffer.append(",entrustAmount:" + this.entrustAmount);
            buffer.append(",entrustBs:" + this.entrustBs);
            buffer.append(",entrustNo:" + this.entrustNo);
            buffer.append(",entrustOc:" + this.entrustOc);
            buffer.append(",entrustProp:" + this.entrustProp);
            buffer.append(",entrustType:" + this.entrustType);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",joinReportNo:" + this.joinReportNo);
            buffer.append(",optEntrustPrice:" + this.optEntrustPrice);
            buffer.append(",optionCode:" + this.optionCode);
            buffer.append(",stockAccount:" + this.stockAccount);
            buffer.append(",optcombId:" + this.optcombId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.batchNo);
            builder.append(this.clientId);
            builder.append(this.coveredFlag);
            builder.append(this.entrustAmount);
            builder.append(this.entrustBs);
            builder.append(this.entrustNo);
            builder.append(this.entrustOc);
            builder.append(this.entrustProp);
            builder.append(this.entrustType);
            builder.append(this.exchangeType);
            builder.append(this.fundAccount);
            builder.append(this.joinReportNo);
            builder.append(this.optEntrustPrice);
            builder.append(this.optionCode);
            builder.append(this.stockAccount);
            builder.append(this.optcombId);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PostEntrustForcedcloseInnerInput obj) {
            if (obj instanceof InnerOptService.PostEntrustForcedcloseInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, obj.opPassword);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.batchNo, obj.batchNo);
                builder.append(this.clientId, obj.clientId);
                builder.append(this.coveredFlag, obj.coveredFlag);
                builder.append(this.entrustAmount, obj.entrustAmount);
                builder.append(this.entrustBs, obj.entrustBs);
                builder.append(this.entrustNo, obj.entrustNo);
                builder.append(this.entrustOc, obj.entrustOc);
                builder.append(this.entrustProp, obj.entrustProp);
                builder.append(this.entrustType, obj.entrustType);
                builder.append(this.exchangeType, obj.exchangeType);
                builder.append(this.fundAccount, obj.fundAccount);
                builder.append(this.joinReportNo, obj.joinReportNo);
                builder.append(this.optEntrustPrice, obj.optEntrustPrice);
                builder.append(this.optionCode, obj.optionCode);
                builder.append(this.stockAccount, obj.stockAccount);
                builder.append(this.optcombId, obj.optcombId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostEntrustCoveredTransInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        @JsonSerialize(
                using = LongJsonSerializer.class
        )
        @JsonDeserialize(
                using = LongJsonDeserializer.class
        )
        private Long entrustNo = 0L;
        private Integer entrustTime = 0;
        private Integer initDate = 0;

        public PostEntrustCoveredTransInnerOutput() {
        }

        public Long getEntrustNo() {
            return this.entrustNo != null ? this.entrustNo : 0L;
        }

        public Integer getEntrustTime() {
            return this.entrustTime != null ? this.entrustTime : 0;
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public void setEntrustNo(Long entrustNo) {
            this.entrustNo = entrustNo;
        }

        public void setEntrustTime(Integer entrustTime) {
            this.entrustTime = entrustTime;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostEntrustCoveredTransInnerOutput:(");
            buffer.append("entrustNo:" + this.entrustNo);
            buffer.append(",entrustTime:" + this.entrustTime);
            buffer.append(",initDate:" + this.initDate);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.entrustNo);
            builder.append(this.entrustTime);
            builder.append(this.initDate);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PostEntrustCoveredTransInnerOutput obj) {
            if (obj instanceof InnerOptService.PostEntrustCoveredTransInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.entrustNo, obj.entrustNo);
                builder.append(this.entrustTime, obj.entrustTime);
                builder.append(this.initDate, obj.initDate);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostEntrustCoveredTransInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        private Integer actionIn = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String clientId = " ";
        @Digits(
                integer = 13,
                fraction = 2,
                message = "currentAmount value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double currentAmount = 0.0D;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "entrustAmount value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double entrustAmount = 0.0D;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character entrustBs = ' ';
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String entrustProp = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character entrustType = ' ';
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String exchangeType = " ";
        @JsonSerialize(
                using = LongJsonSerializer.class
        )
        @JsonDeserialize(
                using = LongJsonDeserializer.class
        )
        private Long frozenSerialNo = 0L;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fundAccount = " ";
        @SinogramLength(
                min = 0,
                max = 20,
                charset = "utf-8"
        )
        private String optionAccount = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fundAccountOpt = " ";
        @SinogramLength(
                min = 0,
                max = 8,
                charset = "utf-8"
        )
        private String seatNo = " ";
        @SinogramLength(
                min = 0,
                max = 20,
                charset = "utf-8"
        )
        private String stockAccount = " ";
        @SinogramLength(
                min = 0,
                max = 8,
                charset = "utf-8"
        )
        private String stockCode = " ";

        public PostEntrustCoveredTransInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public Integer getActionIn() {
            return this.actionIn != null ? this.actionIn : 0;
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public Double getCurrentAmount() {
            return this.currentAmount != null ? this.currentAmount : 0.0D;
        }

        public Double getEntrustAmount() {
            return this.entrustAmount != null ? this.entrustAmount : 0.0D;
        }

        public Character getEntrustBs() {
            return this.entrustBs != null ? this.entrustBs : ' ';
        }

        public String getEntrustProp() {
            if (this.entrustProp == null) {
                return " ";
            } else {
                return this.entrustProp.isEmpty() ? " " : this.entrustProp;
            }
        }

        public Character getEntrustType() {
            return this.entrustType != null ? this.entrustType : ' ';
        }

        public String getExchangeType() {
            if (this.exchangeType == null) {
                return " ";
            } else {
                return this.exchangeType.isEmpty() ? " " : this.exchangeType;
            }
        }

        public Long getFrozenSerialNo() {
            return this.frozenSerialNo != null ? this.frozenSerialNo : 0L;
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getOptionAccount() {
            if (this.optionAccount == null) {
                return " ";
            } else {
                return this.optionAccount.isEmpty() ? " " : this.optionAccount;
            }
        }

        public String getFundAccountOpt() {
            if (this.fundAccountOpt == null) {
                return " ";
            } else {
                return this.fundAccountOpt.isEmpty() ? " " : this.fundAccountOpt;
            }
        }

        public String getSeatNo() {
            if (this.seatNo == null) {
                return " ";
            } else {
                return this.seatNo.isEmpty() ? " " : this.seatNo;
            }
        }

        public String getStockAccount() {
            if (this.stockAccount == null) {
                return " ";
            } else {
                return this.stockAccount.isEmpty() ? " " : this.stockAccount;
            }
        }

        public String getStockCode() {
            if (this.stockCode == null) {
                return " ";
            } else {
                return this.stockCode.isEmpty() ? " " : this.stockCode;
            }
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setActionIn(Integer actionIn) {
            this.actionIn = actionIn;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setCurrentAmount(Double currentAmount) {
            this.currentAmount = currentAmount;
        }

        public void setEntrustAmount(Double entrustAmount) {
            this.entrustAmount = entrustAmount;
        }

        public void setEntrustBs(Character entrustBs) {
            this.entrustBs = entrustBs;
        }

        public void setEntrustProp(String entrustProp) {
            this.entrustProp = entrustProp;
        }

        public void setEntrustType(Character entrustType) {
            this.entrustType = entrustType;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public void setFrozenSerialNo(Long frozenSerialNo) {
            this.frozenSerialNo = frozenSerialNo;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setOptionAccount(String optionAccount) {
            this.optionAccount = optionAccount;
        }

        public void setFundAccountOpt(String fundAccountOpt) {
            this.fundAccountOpt = fundAccountOpt;
        }

        public void setSeatNo(String seatNo) {
            this.seatNo = seatNo;
        }

        public void setStockAccount(String stockAccount) {
            this.stockAccount = stockAccount;
        }

        public void setStockCode(String stockCode) {
            this.stockCode = stockCode;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostEntrustCoveredTransInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",actionIn:" + this.actionIn);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",currentAmount:" + this.currentAmount);
            buffer.append(",entrustAmount:" + this.entrustAmount);
            buffer.append(",entrustBs:" + this.entrustBs);
            buffer.append(",entrustProp:" + this.entrustProp);
            buffer.append(",entrustType:" + this.entrustType);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(",frozenSerialNo:" + this.frozenSerialNo);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",optionAccount:" + this.optionAccount);
            buffer.append(",fundAccountOpt:" + this.fundAccountOpt);
            buffer.append(",seatNo:" + this.seatNo);
            buffer.append(",stockAccount:" + this.stockAccount);
            buffer.append(",stockCode:" + this.stockCode);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.actionIn);
            builder.append(this.clientId);
            builder.append(this.currentAmount);
            builder.append(this.entrustAmount);
            builder.append(this.entrustBs);
            builder.append(this.entrustProp);
            builder.append(this.entrustType);
            builder.append(this.exchangeType);
            builder.append(this.frozenSerialNo);
            builder.append(this.fundAccount);
            builder.append(this.optionAccount);
            builder.append(this.fundAccountOpt);
            builder.append(this.seatNo);
            builder.append(this.stockAccount);
            builder.append(this.stockCode);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PostEntrustCoveredTransInnerInput obj) {
            if (obj instanceof InnerOptService.PostEntrustCoveredTransInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, obj.opPassword);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.actionIn, obj.actionIn);
                builder.append(this.clientId, obj.clientId);
                builder.append(this.currentAmount, obj.currentAmount);
                builder.append(this.entrustAmount, obj.entrustAmount);
                builder.append(this.entrustBs, obj.entrustBs);
                builder.append(this.entrustProp, obj.entrustProp);
                builder.append(this.entrustType, obj.entrustType);
                builder.append(this.exchangeType, obj.exchangeType);
                builder.append(this.frozenSerialNo, obj.frozenSerialNo);
                builder.append(this.fundAccount, obj.fundAccount);
                builder.append(this.optionAccount, obj.optionAccount);
                builder.append(this.fundAccountOpt, obj.fundAccountOpt);
                builder.append(this.seatNo, obj.seatNo);
                builder.append(this.stockAccount, obj.stockAccount);
                builder.append(this.stockCode, obj.stockCode);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostEntrustCombForcedcloseInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        @JsonSerialize(
                using = LongJsonSerializer.class
        )
        @JsonDeserialize(
                using = LongJsonDeserializer.class
        )
        private Long entrustNo = 0L;
        private Integer entrustTime = 0;
        private Integer initDate = 0;
        @JsonSerialize(
                using = LongJsonSerializer.class
        )
        @JsonDeserialize(
                using = LongJsonDeserializer.class
        )
        private Long reportNo = 0L;

        public PostEntrustCombForcedcloseInnerOutput() {
        }

        public Long getEntrustNo() {
            return this.entrustNo != null ? this.entrustNo : 0L;
        }

        public Integer getEntrustTime() {
            return this.entrustTime != null ? this.entrustTime : 0;
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public Long getReportNo() {
            return this.reportNo != null ? this.reportNo : 0L;
        }

        public void setEntrustNo(Long entrustNo) {
            this.entrustNo = entrustNo;
        }

        public void setEntrustTime(Integer entrustTime) {
            this.entrustTime = entrustTime;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public void setReportNo(Long reportNo) {
            this.reportNo = reportNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostEntrustCombForcedcloseInnerOutput:(");
            buffer.append("entrustNo:" + this.entrustNo);
            buffer.append(",entrustTime:" + this.entrustTime);
            buffer.append(",initDate:" + this.initDate);
            buffer.append(",reportNo:" + this.reportNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.entrustNo);
            builder.append(this.entrustTime);
            builder.append(this.initDate);
            builder.append(this.reportNo);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PostEntrustCombForcedcloseInnerOutput obj) {
            if (obj instanceof InnerOptService.PostEntrustCombForcedcloseInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.entrustNo, obj.entrustNo);
                builder.append(this.entrustTime, obj.entrustTime);
                builder.append(this.initDate, obj.initDate);
                builder.append(this.reportNo, obj.reportNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostEntrustCombForcedcloseInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String clientId = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character combBs = ' ';
        @Digits(
                integer = 13,
                fraction = 2,
                message = "entrustAmount value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double entrustAmount = 0.0D;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character entrustType = ' ';
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String exchangeType = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character firstOptholdType = ' ';
        @SinogramLength(
                min = 0,
                max = 8,
                charset = "utf-8"
        )
        private String firstOptionCode = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fundAccount = " ";
        @SinogramLength(
                min = 0,
                max = 8,
                charset = "utf-8"
        )
        private String optcombCode = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String optcombId = " ";
        @SinogramLength(
                min = 0,
                max = 20,
                charset = "utf-8"
        )
        private String optionAccount = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character secondOptholdType = ' ';
        @SinogramLength(
                min = 0,
                max = 8,
                charset = "utf-8"
        )
        private String secondOptionCode = " ";

        public PostEntrustCombForcedcloseInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public Character getCombBs() {
            return this.combBs != null ? this.combBs : ' ';
        }

        public Double getEntrustAmount() {
            return this.entrustAmount != null ? this.entrustAmount : 0.0D;
        }

        public Character getEntrustType() {
            return this.entrustType != null ? this.entrustType : ' ';
        }

        public String getExchangeType() {
            if (this.exchangeType == null) {
                return " ";
            } else {
                return this.exchangeType.isEmpty() ? " " : this.exchangeType;
            }
        }

        public Character getFirstOptholdType() {
            return this.firstOptholdType != null ? this.firstOptholdType : ' ';
        }

        public String getFirstOptionCode() {
            if (this.firstOptionCode == null) {
                return " ";
            } else {
                return this.firstOptionCode.isEmpty() ? " " : this.firstOptionCode;
            }
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getOptcombCode() {
            if (this.optcombCode == null) {
                return " ";
            } else {
                return this.optcombCode.isEmpty() ? " " : this.optcombCode;
            }
        }

        public String getOptcombId() {
            if (this.optcombId == null) {
                return " ";
            } else {
                return this.optcombId.isEmpty() ? " " : this.optcombId;
            }
        }

        public String getOptionAccount() {
            if (this.optionAccount == null) {
                return " ";
            } else {
                return this.optionAccount.isEmpty() ? " " : this.optionAccount;
            }
        }

        public Character getSecondOptholdType() {
            return this.secondOptholdType != null ? this.secondOptholdType : ' ';
        }

        public String getSecondOptionCode() {
            if (this.secondOptionCode == null) {
                return " ";
            } else {
                return this.secondOptionCode.isEmpty() ? " " : this.secondOptionCode;
            }
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setCombBs(Character combBs) {
            this.combBs = combBs;
        }

        public void setEntrustAmount(Double entrustAmount) {
            this.entrustAmount = entrustAmount;
        }

        public void setEntrustType(Character entrustType) {
            this.entrustType = entrustType;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public void setFirstOptholdType(Character firstOptholdType) {
            this.firstOptholdType = firstOptholdType;
        }

        public void setFirstOptionCode(String firstOptionCode) {
            this.firstOptionCode = firstOptionCode;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setOptcombCode(String optcombCode) {
            this.optcombCode = optcombCode;
        }

        public void setOptcombId(String optcombId) {
            this.optcombId = optcombId;
        }

        public void setOptionAccount(String optionAccount) {
            this.optionAccount = optionAccount;
        }

        public void setSecondOptholdType(Character secondOptholdType) {
            this.secondOptholdType = secondOptholdType;
        }

        public void setSecondOptionCode(String secondOptionCode) {
            this.secondOptionCode = secondOptionCode;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostEntrustCombForcedcloseInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",combBs:" + this.combBs);
            buffer.append(",entrustAmount:" + this.entrustAmount);
            buffer.append(",entrustType:" + this.entrustType);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(",firstOptholdType:" + this.firstOptholdType);
            buffer.append(",firstOptionCode:" + this.firstOptionCode);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",optcombCode:" + this.optcombCode);
            buffer.append(",optcombId:" + this.optcombId);
            buffer.append(",optionAccount:" + this.optionAccount);
            buffer.append(",secondOptholdType:" + this.secondOptholdType);
            buffer.append(",secondOptionCode:" + this.secondOptionCode);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.clientId);
            builder.append(this.combBs);
            builder.append(this.entrustAmount);
            builder.append(this.entrustType);
            builder.append(this.exchangeType);
            builder.append(this.firstOptholdType);
            builder.append(this.firstOptionCode);
            builder.append(this.fundAccount);
            builder.append(this.optcombCode);
            builder.append(this.optcombId);
            builder.append(this.optionAccount);
            builder.append(this.secondOptholdType);
            builder.append(this.secondOptionCode);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PostEntrustCombForcedcloseInnerInput obj) {
            if (obj instanceof InnerOptService.PostEntrustCombForcedcloseInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, obj.opPassword);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.clientId, obj.clientId);
                builder.append(this.combBs, obj.combBs);
                builder.append(this.entrustAmount, obj.entrustAmount);
                builder.append(this.entrustType, obj.entrustType);
                builder.append(this.exchangeType, obj.exchangeType);
                builder.append(this.firstOptholdType, obj.firstOptholdType);
                builder.append(this.firstOptionCode, obj.firstOptionCode);
                builder.append(this.fundAccount, obj.fundAccount);
                builder.append(this.optcombCode, obj.optcombCode);
                builder.append(this.optcombId, obj.optcombId);
                builder.append(this.optionAccount, obj.optionAccount);
                builder.append(this.secondOptholdType, obj.secondOptholdType);
                builder.append(this.secondOptionCode, obj.secondOptionCode);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostDayinitinfoSqlInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer rowcount = 0;
        private String settleClob = " ";

        public PostDayinitinfoSqlInnerOutput() {
        }

        public Integer getRowcount() {
            return this.rowcount != null ? this.rowcount : 0;
        }

        public String getSettleClob() {
            if (this.settleClob == null) {
                return " ";
            } else {
                return this.settleClob.isEmpty() ? " " : this.settleClob;
            }
        }

        public void setRowcount(Integer rowcount) {
            this.rowcount = rowcount;
        }

        public void setSettleClob(String settleClob) {
            this.settleClob = settleClob;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostDayinitinfoSqlInnerOutput:(");
            buffer.append("rowcount:" + this.rowcount);
            buffer.append(",settleClob:" + this.settleClob);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.rowcount);
            builder.append(this.settleClob);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PostDayinitinfoSqlInnerOutput obj) {
            if (obj instanceof InnerOptService.PostDayinitinfoSqlInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.rowcount, obj.rowcount);
                builder.append(this.settleClob, obj.settleClob);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostDayinitinfoSqlInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 16000,
                charset = "utf-8"
        )
        private String executeSql = " ";
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String tokenKey = " ";
        private Integer actionIn = 0;

        public PostDayinitinfoSqlInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getExecuteSql() {
            if (this.executeSql == null) {
                return " ";
            } else {
                return this.executeSql.isEmpty() ? " " : this.executeSql;
            }
        }

        public String getTokenKey() {
            if (this.tokenKey == null) {
                return " ";
            } else {
                return this.tokenKey.isEmpty() ? " " : this.tokenKey;
            }
        }

        public Integer getActionIn() {
            return this.actionIn != null ? this.actionIn : 0;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setExecuteSql(String executeSql) {
            this.executeSql = executeSql;
        }

        public void setTokenKey(String tokenKey) {
            this.tokenKey = tokenKey;
        }

        public void setActionIn(Integer actionIn) {
            this.actionIn = actionIn;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostDayinitinfoSqlInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",executeSql:" + this.executeSql);
            buffer.append(",tokenKey:" + this.tokenKey);
            buffer.append(",actionIn:" + this.actionIn);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.executeSql);
            builder.append(this.tokenKey);
            builder.append(this.actionIn);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.PostDayinitinfoSqlInnerInput obj) {
            if (obj instanceof InnerOptService.PostDayinitinfoSqlInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, obj.opPassword);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.executeSql, obj.executeSql);
                builder.append(this.tokenKey, obj.tokenKey);
                builder.append(this.actionIn, obj.actionIn);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetTransstatusInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String transName = " ";
        private String transConnectInfo = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character reportStatus = ' ';

        public GetTransstatusInnerOutput() {
        }

        public String getTransName() {
            if (this.transName == null) {
                return " ";
            } else {
                return this.transName.isEmpty() ? " " : this.transName;
            }
        }

        public String getTransConnectInfo() {
            if (this.transConnectInfo == null) {
                return " ";
            } else {
                return this.transConnectInfo.isEmpty() ? " " : this.transConnectInfo;
            }
        }

        public Character getReportStatus() {
            return this.reportStatus != null ? this.reportStatus : ' ';
        }

        public void setTransName(String transName) {
            this.transName = transName;
        }

        public void setTransConnectInfo(String transConnectInfo) {
            this.transConnectInfo = transConnectInfo;
        }

        public void setReportStatus(Character reportStatus) {
            this.reportStatus = reportStatus;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetTransstatusInnerOutput:(");
            buffer.append("transName:" + this.transName);
            buffer.append(",transConnectInfo:" + this.transConnectInfo);
            buffer.append(",reportStatus:" + this.reportStatus);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.transName);
            builder.append(this.transConnectInfo);
            builder.append(this.reportStatus);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.GetTransstatusInnerOutput obj) {
            if (obj instanceof InnerOptService.GetTransstatusInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.transName, obj.transName);
                builder.append(this.transConnectInfo, obj.transConnectInfo);
                builder.append(this.reportStatus, obj.reportStatus);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetTransstatusInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 60,
                charset = "utf-8"
        )
        private String transName = " ";

        public GetTransstatusInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getTransName() {
            if (this.transName == null) {
                return " ";
            } else {
                return this.transName.isEmpty() ? " " : this.transName;
            }
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setTransName(String transName) {
            this.transName = transName;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetTransstatusInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",transName:" + this.transName);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.transName);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.GetTransstatusInnerInput obj) {
            if (obj instanceof InnerOptService.GetTransstatusInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, obj.opPassword);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.transName, obj.transName);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetOptinnerwithdrawAfterhoursInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String optionName = " ";
        private String tradeName = " ";
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double treatAmount = 0.0D;
        private Integer branchNo = 0;
        private InnerOptService.EntrustDTO rows;

        public GetOptinnerwithdrawAfterhoursInnerOutput() {
        }

        public String getOptionName() {
            if (this.optionName == null) {
                return " ";
            } else {
                return this.optionName.isEmpty() ? " " : this.optionName;
            }
        }

        public String getTradeName() {
            if (this.tradeName == null) {
                return " ";
            } else {
                return this.tradeName.isEmpty() ? " " : this.tradeName;
            }
        }

        public Double getTreatAmount() {
            return this.treatAmount != null ? this.treatAmount : 0.0D;
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public InnerOptService.EntrustDTO getRows() {
            return this.rows;
        }

        public void setOptionName(String optionName) {
            this.optionName = optionName;
        }

        public void setTradeName(String tradeName) {
            this.tradeName = tradeName;
        }

        public void setTreatAmount(Double treatAmount) {
            this.treatAmount = treatAmount;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setRows(InnerOptService.EntrustDTO rows) {
            this.rows = rows;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetOptinnerwithdrawAfterhoursInnerOutput:(");
            buffer.append("optionName:" + this.optionName);
            buffer.append(",tradeName:" + this.tradeName);
            buffer.append(",treatAmount:" + this.treatAmount);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",rows:" + this.rows);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.optionName);
            builder.append(this.tradeName);
            builder.append(this.treatAmount);
            builder.append(this.branchNo);
            builder.append(this.rows);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.GetOptinnerwithdrawAfterhoursInnerOutput obj) {
            if (obj instanceof InnerOptService.GetOptinnerwithdrawAfterhoursInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.optionName, obj.optionName);
                builder.append(this.tradeName, obj.tradeName);
                builder.append(this.treatAmount, obj.treatAmount);
                builder.append(this.branchNo, obj.branchNo);
                builder.append(this.rows, obj.rows);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetOptinnerwithdrawAfterhoursInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 100,
                charset = "utf-8"
        )
        private String positionStr = " ";
        @SinogramLength(
                min = 0,
                max = 4000,
                charset = "utf-8"
        )
        private String enBranchNo = " ";
        private Integer requestNum = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fundAccount = " ";

        public GetOptinnerwithdrawAfterhoursInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getPositionStr() {
            if (this.positionStr == null) {
                return " ";
            } else {
                return this.positionStr.isEmpty() ? " " : this.positionStr;
            }
        }

        public String getEnBranchNo() {
            if (this.enBranchNo == null) {
                return " ";
            } else {
                return this.enBranchNo.isEmpty() ? " " : this.enBranchNo;
            }
        }

        public Integer getRequestNum() {
            return this.requestNum != null ? this.requestNum : 0;
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setPositionStr(String positionStr) {
            this.positionStr = positionStr;
        }

        public void setEnBranchNo(String enBranchNo) {
            this.enBranchNo = enBranchNo;
        }

        public void setRequestNum(Integer requestNum) {
            this.requestNum = requestNum;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetOptinnerwithdrawAfterhoursInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",positionStr:" + this.positionStr);
            buffer.append(",enBranchNo:" + this.enBranchNo);
            buffer.append(",requestNum:" + this.requestNum);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.positionStr);
            builder.append(this.enBranchNo);
            builder.append(this.requestNum);
            builder.append(this.fundAccount);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.GetOptinnerwithdrawAfterhoursInnerInput obj) {
            if (obj instanceof InnerOptService.GetOptinnerwithdrawAfterhoursInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, obj.opPassword);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.positionStr, obj.positionStr);
                builder.append(this.enBranchNo, obj.enBranchNo);
                builder.append(this.requestNum, obj.requestNum);
                builder.append(this.fundAccount, obj.fundAccount);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetHoldrealqueryInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer total = 0;
        private Integer currentPage = 0;
        private List<InnerOptService.HoldrealDTO> rows;

        public GetHoldrealqueryInnerOutput() {
        }

        public Integer getTotal() {
            return this.total != null ? this.total : 0;
        }

        public Integer getCurrentPage() {
            return this.currentPage != null ? this.currentPage : 0;
        }

        public List<InnerOptService.HoldrealDTO> getRows() {
            return this.rows;
        }

        public void setTotal(Integer total) {
            this.total = total;
        }

        public void setCurrentPage(Integer currentPage) {
            this.currentPage = currentPage;
        }

        public void setRows(List<InnerOptService.HoldrealDTO> rows) {
            this.rows = rows;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetHoldrealqueryInnerOutput:(");
            buffer.append("total:" + this.total);
            buffer.append(",currentPage:" + this.currentPage);
            buffer.append(",rows:" + this.rows);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.total);
            builder.append(this.currentPage);
            builder.append(this.rows);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.GetHoldrealqueryInnerOutput obj) {
            if (obj instanceof InnerOptService.GetHoldrealqueryInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.total, obj.total);
                builder.append(this.currentPage, obj.currentPage);
                builder.append(this.rows, obj.rows);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetHoldrealqueryInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String clientId = " ";
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String enStockType = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character entrustOc = ' ';
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String exchangeType = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fundAccount = " ";
        @SinogramLength(
                min = 0,
                max = 8,
                charset = "utf-8"
        )
        private String optionCode = " ";
        @SinogramLength(
                min = 0,
                max = 100,
                charset = "utf-8"
        )
        private String positionStr = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character queryMode = ' ';
        private Integer requestNum = 0;
        @SinogramLength(
                min = 0,
                max = 20,
                charset = "utf-8"
        )
        private String stockAccount = " ";
        private Integer pageNo = 0;
        private Integer pageSize = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character optholdType = ' ';

        public GetHoldrealqueryInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getEnStockType() {
            if (this.enStockType == null) {
                return " ";
            } else {
                return this.enStockType.isEmpty() ? " " : this.enStockType;
            }
        }

        public Character getEntrustOc() {
            return this.entrustOc != null ? this.entrustOc : ' ';
        }

        public String getExchangeType() {
            if (this.exchangeType == null) {
                return " ";
            } else {
                return this.exchangeType.isEmpty() ? " " : this.exchangeType;
            }
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getOptionCode() {
            if (this.optionCode == null) {
                return " ";
            } else {
                return this.optionCode.isEmpty() ? " " : this.optionCode;
            }
        }

        public String getPositionStr() {
            if (this.positionStr == null) {
                return " ";
            } else {
                return this.positionStr.isEmpty() ? " " : this.positionStr;
            }
        }

        public Character getQueryMode() {
            return this.queryMode != null ? this.queryMode : ' ';
        }

        public Integer getRequestNum() {
            return this.requestNum != null ? this.requestNum : 0;
        }

        public String getStockAccount() {
            if (this.stockAccount == null) {
                return " ";
            } else {
                return this.stockAccount.isEmpty() ? " " : this.stockAccount;
            }
        }

        public Integer getPageNo() {
            return this.pageNo != null ? this.pageNo : 0;
        }

        public Integer getPageSize() {
            return this.pageSize != null ? this.pageSize : 0;
        }

        public Character getOptholdType() {
            return this.optholdType != null ? this.optholdType : ' ';
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setEnStockType(String enStockType) {
            this.enStockType = enStockType;
        }

        public void setEntrustOc(Character entrustOc) {
            this.entrustOc = entrustOc;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setOptionCode(String optionCode) {
            this.optionCode = optionCode;
        }

        public void setPositionStr(String positionStr) {
            this.positionStr = positionStr;
        }

        public void setQueryMode(Character queryMode) {
            this.queryMode = queryMode;
        }

        public void setRequestNum(Integer requestNum) {
            this.requestNum = requestNum;
        }

        public void setStockAccount(String stockAccount) {
            this.stockAccount = stockAccount;
        }

        public void setPageNo(Integer pageNo) {
            this.pageNo = pageNo;
        }

        public void setPageSize(Integer pageSize) {
            this.pageSize = pageSize;
        }

        public void setOptholdType(Character optholdType) {
            this.optholdType = optholdType;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetHoldrealqueryInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",enStockType:" + this.enStockType);
            buffer.append(",entrustOc:" + this.entrustOc);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",optionCode:" + this.optionCode);
            buffer.append(",positionStr:" + this.positionStr);
            buffer.append(",queryMode:" + this.queryMode);
            buffer.append(",requestNum:" + this.requestNum);
            buffer.append(",stockAccount:" + this.stockAccount);
            buffer.append(",pageNo:" + this.pageNo);
            buffer.append(",pageSize:" + this.pageSize);
            buffer.append(",optholdType:" + this.optholdType);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.clientId);
            builder.append(this.enStockType);
            builder.append(this.entrustOc);
            builder.append(this.exchangeType);
            builder.append(this.fundAccount);
            builder.append(this.optionCode);
            builder.append(this.positionStr);
            builder.append(this.queryMode);
            builder.append(this.requestNum);
            builder.append(this.stockAccount);
            builder.append(this.pageNo);
            builder.append(this.pageSize);
            builder.append(this.optholdType);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.GetHoldrealqueryInnerInput obj) {
            if (obj instanceof InnerOptService.GetHoldrealqueryInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, obj.opPassword);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.clientId, obj.clientId);
                builder.append(this.enStockType, obj.enStockType);
                builder.append(this.entrustOc, obj.entrustOc);
                builder.append(this.exchangeType, obj.exchangeType);
                builder.append(this.fundAccount, obj.fundAccount);
                builder.append(this.optionCode, obj.optionCode);
                builder.append(this.positionStr, obj.positionStr);
                builder.append(this.queryMode, obj.queryMode);
                builder.append(this.requestNum, obj.requestNum);
                builder.append(this.stockAccount, obj.stockAccount);
                builder.append(this.pageNo, obj.pageNo);
                builder.append(this.pageSize, obj.pageSize);
                builder.append(this.optholdType, obj.optholdType);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetHoldrealjourdayendFundaccountInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String fundAccount = " ";

        public GetHoldrealjourdayendFundaccountInnerOutput() {
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetHoldrealjourdayendFundaccountInnerOutput:(");
            buffer.append("fundAccount:" + this.fundAccount);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.fundAccount);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.GetHoldrealjourdayendFundaccountInnerOutput obj) {
            if (obj instanceof InnerOptService.GetHoldrealjourdayendFundaccountInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.fundAccount, obj.fundAccount);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetHoldrealjourdayendFundaccountInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        private Integer businessFlag = 0;

        public GetHoldrealjourdayendFundaccountInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public Integer getBusinessFlag() {
            return this.businessFlag != null ? this.businessFlag : 0;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setBusinessFlag(Integer businessFlag) {
            this.businessFlag = businessFlag;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetHoldrealjourdayendFundaccountInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",businessFlag:" + this.businessFlag);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.businessFlag);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.GetHoldrealjourdayendFundaccountInnerInput obj) {
            if (obj instanceof InnerOptService.GetHoldrealjourdayendFundaccountInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, obj.opPassword);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.businessFlag, obj.businessFlag);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetHoldrealjourdayendDataInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String fundAccount = " ";
        private String stockAccount = " ";
        private String exchangeType = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character optholdType = ' ';
        private String optionCode = " ";
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double enableAmount = 0.0D;
        @JsonSerialize(
                using = LongJsonSerializer.class
        )
        @JsonDeserialize(
                using = LongJsonDeserializer.class
        )
        private Long serialNo = 0L;
        private Integer businessFlag = 0;

        public GetHoldrealjourdayendDataInnerOutput() {
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getStockAccount() {
            if (this.stockAccount == null) {
                return " ";
            } else {
                return this.stockAccount.isEmpty() ? " " : this.stockAccount;
            }
        }

        public String getExchangeType() {
            if (this.exchangeType == null) {
                return " ";
            } else {
                return this.exchangeType.isEmpty() ? " " : this.exchangeType;
            }
        }

        public Character getOptholdType() {
            return this.optholdType != null ? this.optholdType : ' ';
        }

        public String getOptionCode() {
            if (this.optionCode == null) {
                return " ";
            } else {
                return this.optionCode.isEmpty() ? " " : this.optionCode;
            }
        }

        public Double getEnableAmount() {
            return this.enableAmount != null ? this.enableAmount : 0.0D;
        }

        public Long getSerialNo() {
            return this.serialNo != null ? this.serialNo : 0L;
        }

        public Integer getBusinessFlag() {
            return this.businessFlag != null ? this.businessFlag : 0;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setStockAccount(String stockAccount) {
            this.stockAccount = stockAccount;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public void setOptholdType(Character optholdType) {
            this.optholdType = optholdType;
        }

        public void setOptionCode(String optionCode) {
            this.optionCode = optionCode;
        }

        public void setEnableAmount(Double enableAmount) {
            this.enableAmount = enableAmount;
        }

        public void setSerialNo(Long serialNo) {
            this.serialNo = serialNo;
        }

        public void setBusinessFlag(Integer businessFlag) {
            this.businessFlag = businessFlag;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetHoldrealjourdayendDataInnerOutput:(");
            buffer.append("fundAccount:" + this.fundAccount);
            buffer.append(",stockAccount:" + this.stockAccount);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(",optholdType:" + this.optholdType);
            buffer.append(",optionCode:" + this.optionCode);
            buffer.append(",enableAmount:" + this.enableAmount);
            buffer.append(",serialNo:" + this.serialNo);
            buffer.append(",businessFlag:" + this.businessFlag);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.fundAccount);
            builder.append(this.stockAccount);
            builder.append(this.exchangeType);
            builder.append(this.optholdType);
            builder.append(this.optionCode);
            builder.append(this.enableAmount);
            builder.append(this.serialNo);
            builder.append(this.businessFlag);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.GetHoldrealjourdayendDataInnerOutput obj) {
            if (obj instanceof InnerOptService.GetHoldrealjourdayendDataInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.fundAccount, obj.fundAccount);
                builder.append(this.stockAccount, obj.stockAccount);
                builder.append(this.exchangeType, obj.exchangeType);
                builder.append(this.optholdType, obj.optholdType);
                builder.append(this.optionCode, obj.optionCode);
                builder.append(this.enableAmount, obj.enableAmount);
                builder.append(this.serialNo, obj.serialNo);
                builder.append(this.businessFlag, obj.businessFlag);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetHoldrealjourdayendDataInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        private Integer businessFlag = 0;
        private Integer initDate = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fundAccountStart = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fundAccountEnd = " ";

        public GetHoldrealjourdayendDataInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public Integer getBusinessFlag() {
            return this.businessFlag != null ? this.businessFlag : 0;
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public String getFundAccountStart() {
            if (this.fundAccountStart == null) {
                return " ";
            } else {
                return this.fundAccountStart.isEmpty() ? " " : this.fundAccountStart;
            }
        }

        public String getFundAccountEnd() {
            if (this.fundAccountEnd == null) {
                return " ";
            } else {
                return this.fundAccountEnd.isEmpty() ? " " : this.fundAccountEnd;
            }
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setBusinessFlag(Integer businessFlag) {
            this.businessFlag = businessFlag;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public void setFundAccountStart(String fundAccountStart) {
            this.fundAccountStart = fundAccountStart;
        }

        public void setFundAccountEnd(String fundAccountEnd) {
            this.fundAccountEnd = fundAccountEnd;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetHoldrealjourdayendDataInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",businessFlag:" + this.businessFlag);
            buffer.append(",initDate:" + this.initDate);
            buffer.append(",fundAccountStart:" + this.fundAccountStart);
            buffer.append(",fundAccountEnd:" + this.fundAccountEnd);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.businessFlag);
            builder.append(this.initDate);
            builder.append(this.fundAccountStart);
            builder.append(this.fundAccountEnd);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.GetHoldrealjourdayendDataInnerInput obj) {
            if (obj instanceof InnerOptService.GetHoldrealjourdayendDataInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, obj.opPassword);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.businessFlag, obj.businessFlag);
                builder.append(this.initDate, obj.initDate);
                builder.append(this.fundAccountStart, obj.fundAccountStart);
                builder.append(this.fundAccountEnd, obj.fundAccountEnd);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetFundrealjourdayendFundaccountInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String fundAccount = " ";

        public GetFundrealjourdayendFundaccountInnerOutput() {
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetFundrealjourdayendFundaccountInnerOutput:(");
            buffer.append("fundAccount:" + this.fundAccount);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.fundAccount);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.GetFundrealjourdayendFundaccountInnerOutput obj) {
            if (obj instanceof InnerOptService.GetFundrealjourdayendFundaccountInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.fundAccount, obj.fundAccount);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetFundrealjourdayendFundaccountInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";

        public GetFundrealjourdayendFundaccountInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetFundrealjourdayendFundaccountInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.GetFundrealjourdayendFundaccountInnerInput obj) {
            if (obj instanceof InnerOptService.GetFundrealjourdayendFundaccountInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, obj.opPassword);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetFundrealjourdayendDataInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String fundAccount = " ";
        private String moneyType = " ";
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double enableBalance = 0.0D;
        @JsonSerialize(
                using = LongJsonSerializer.class
        )
        @JsonDeserialize(
                using = LongJsonDeserializer.class
        )
        private Long serialNo = 0L;

        public GetFundrealjourdayendDataInnerOutput() {
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getMoneyType() {
            if (this.moneyType == null) {
                return " ";
            } else {
                return this.moneyType.isEmpty() ? " " : this.moneyType;
            }
        }

        public Double getEnableBalance() {
            return this.enableBalance != null ? this.enableBalance : 0.0D;
        }

        public Long getSerialNo() {
            return this.serialNo != null ? this.serialNo : 0L;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setMoneyType(String moneyType) {
            this.moneyType = moneyType;
        }

        public void setEnableBalance(Double enableBalance) {
            this.enableBalance = enableBalance;
        }

        public void setSerialNo(Long serialNo) {
            this.serialNo = serialNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetFundrealjourdayendDataInnerOutput:(");
            buffer.append("fundAccount:" + this.fundAccount);
            buffer.append(",moneyType:" + this.moneyType);
            buffer.append(",enableBalance:" + this.enableBalance);
            buffer.append(",serialNo:" + this.serialNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.fundAccount);
            builder.append(this.moneyType);
            builder.append(this.enableBalance);
            builder.append(this.serialNo);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.GetFundrealjourdayendDataInnerOutput obj) {
            if (obj instanceof InnerOptService.GetFundrealjourdayendDataInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.fundAccount, obj.fundAccount);
                builder.append(this.moneyType, obj.moneyType);
                builder.append(this.enableBalance, obj.enableBalance);
                builder.append(this.serialNo, obj.serialNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetFundrealjourdayendDataInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        private Integer initDate = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fundAccountStart = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fundAccountEnd = " ";

        public GetFundrealjourdayendDataInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public String getFundAccountStart() {
            if (this.fundAccountStart == null) {
                return " ";
            } else {
                return this.fundAccountStart.isEmpty() ? " " : this.fundAccountStart;
            }
        }

        public String getFundAccountEnd() {
            if (this.fundAccountEnd == null) {
                return " ";
            } else {
                return this.fundAccountEnd.isEmpty() ? " " : this.fundAccountEnd;
            }
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public void setFundAccountStart(String fundAccountStart) {
            this.fundAccountStart = fundAccountStart;
        }

        public void setFundAccountEnd(String fundAccountEnd) {
            this.fundAccountEnd = fundAccountEnd;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetFundrealjourdayendDataInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",initDate:" + this.initDate);
            buffer.append(",fundAccountStart:" + this.fundAccountStart);
            buffer.append(",fundAccountEnd:" + this.fundAccountEnd);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.initDate);
            builder.append(this.fundAccountStart);
            builder.append(this.fundAccountEnd);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.GetFundrealjourdayendDataInnerInput obj) {
            if (obj instanceof InnerOptService.GetFundrealjourdayendDataInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, obj.opPassword);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.initDate, obj.initDate);
                builder.append(this.fundAccountStart, obj.fundAccountStart);
                builder.append(this.fundAccountEnd, obj.fundAccountEnd);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetFundrealMoneyTypeCloseCheckInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer noticeNo = 0;
        private String noticeInfo = " ";
        private String checkId = " ";

        public GetFundrealMoneyTypeCloseCheckInnerOutput() {
        }

        public Integer getNoticeNo() {
            return this.noticeNo != null ? this.noticeNo : 0;
        }

        public String getNoticeInfo() {
            if (this.noticeInfo == null) {
                return " ";
            } else {
                return this.noticeInfo.isEmpty() ? " " : this.noticeInfo;
            }
        }

        public String getCheckId() {
            if (this.checkId == null) {
                return " ";
            } else {
                return this.checkId.isEmpty() ? " " : this.checkId;
            }
        }

        public void setNoticeNo(Integer noticeNo) {
            this.noticeNo = noticeNo;
        }

        public void setNoticeInfo(String noticeInfo) {
            this.noticeInfo = noticeInfo;
        }

        public void setCheckId(String checkId) {
            this.checkId = checkId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetFundrealMoneyTypeCloseCheckInnerOutput:(");
            buffer.append("noticeNo:" + this.noticeNo);
            buffer.append(",noticeInfo:" + this.noticeInfo);
            buffer.append(",checkId:" + this.checkId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.noticeNo);
            builder.append(this.noticeInfo);
            builder.append(this.checkId);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.GetFundrealMoneyTypeCloseCheckInnerOutput obj) {
            if (obj instanceof InnerOptService.GetFundrealMoneyTypeCloseCheckInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.noticeNo, obj.noticeNo);
                builder.append(this.noticeInfo, obj.noticeInfo);
                builder.append(this.checkId, obj.checkId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetFundrealMoneyTypeCloseCheckInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String fundAccount;
        @SinogramLength(
                min = 1,
                max = 3,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String moneyType;

        public GetFundrealMoneyTypeCloseCheckInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getClientId() {
            return this.clientId;
        }

        public String getFundAccount() {
            return this.fundAccount;
        }

        public String getMoneyType() {
            return this.moneyType;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setMoneyType(String moneyType) {
            this.moneyType = moneyType;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetFundrealMoneyTypeCloseCheckInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",moneyType:" + this.moneyType);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.clientId);
            builder.append(this.fundAccount);
            builder.append(this.moneyType);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.GetFundrealMoneyTypeCloseCheckInnerInput obj) {
            if (obj instanceof InnerOptService.GetFundrealMoneyTypeCloseCheckInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, obj.opPassword);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.clientId, obj.clientId);
                builder.append(this.fundAccount, obj.fundAccount);
                builder.append(this.moneyType, obj.moneyType);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetFundrealBalanceInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double correctBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double currentBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double enableBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double fetchBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double dynaMarketValue = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double totalAsset = 0.0D;

        public GetFundrealBalanceInnerOutput() {
        }

        public Double getCorrectBalance() {
            return this.correctBalance != null ? this.correctBalance : 0.0D;
        }

        public Double getCurrentBalance() {
            return this.currentBalance != null ? this.currentBalance : 0.0D;
        }

        public Double getEnableBalance() {
            return this.enableBalance != null ? this.enableBalance : 0.0D;
        }

        public Double getFetchBalance() {
            return this.fetchBalance != null ? this.fetchBalance : 0.0D;
        }

        public Double getDynaMarketValue() {
            return this.dynaMarketValue != null ? this.dynaMarketValue : 0.0D;
        }

        public Double getTotalAsset() {
            return this.totalAsset != null ? this.totalAsset : 0.0D;
        }

        public void setCorrectBalance(Double correctBalance) {
            this.correctBalance = correctBalance;
        }

        public void setCurrentBalance(Double currentBalance) {
            this.currentBalance = currentBalance;
        }

        public void setEnableBalance(Double enableBalance) {
            this.enableBalance = enableBalance;
        }

        public void setFetchBalance(Double fetchBalance) {
            this.fetchBalance = fetchBalance;
        }

        public void setDynaMarketValue(Double dynaMarketValue) {
            this.dynaMarketValue = dynaMarketValue;
        }

        public void setTotalAsset(Double totalAsset) {
            this.totalAsset = totalAsset;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetFundrealBalanceInnerOutput:(");
            buffer.append("correctBalance:" + this.correctBalance);
            buffer.append(",currentBalance:" + this.currentBalance);
            buffer.append(",enableBalance:" + this.enableBalance);
            buffer.append(",fetchBalance:" + this.fetchBalance);
            buffer.append(",dynaMarketValue:" + this.dynaMarketValue);
            buffer.append(",totalAsset:" + this.totalAsset);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.correctBalance);
            builder.append(this.currentBalance);
            builder.append(this.enableBalance);
            builder.append(this.fetchBalance);
            builder.append(this.dynaMarketValue);
            builder.append(this.totalAsset);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.GetFundrealBalanceInnerOutput obj) {
            if (obj instanceof InnerOptService.GetFundrealBalanceInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.correctBalance, obj.correctBalance);
                builder.append(this.currentBalance, obj.currentBalance);
                builder.append(this.enableBalance, obj.enableBalance);
                builder.append(this.fetchBalance, obj.fetchBalance);
                builder.append(this.dynaMarketValue, obj.dynaMarketValue);
                builder.append(this.totalAsset, obj.totalAsset);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetFundrealBalanceInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character assetProp = ' ';
        private Integer branchNo = 0;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String fundAccount;
        @SinogramLength(
                min = 1,
                max = 3,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String moneyType;

        public GetFundrealBalanceInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public Character getAssetProp() {
            return this.assetProp != null ? this.assetProp : ' ';
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getFundAccount() {
            return this.fundAccount;
        }

        public String getMoneyType() {
            return this.moneyType;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setAssetProp(Character assetProp) {
            this.assetProp = assetProp;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setMoneyType(String moneyType) {
            this.moneyType = moneyType;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetFundrealBalanceInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",assetProp:" + this.assetProp);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",moneyType:" + this.moneyType);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.assetProp);
            builder.append(this.branchNo);
            builder.append(this.fundAccount);
            builder.append(this.moneyType);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.GetFundrealBalanceInnerInput obj) {
            if (obj instanceof InnerOptService.GetFundrealBalanceInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, obj.opPassword);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.assetProp, obj.assetProp);
                builder.append(this.branchNo, obj.branchNo);
                builder.append(this.fundAccount, obj.fundAccount);
                builder.append(this.moneyType, obj.moneyType);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetFundrealAssetInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double optMarketValueSh = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double optMarketValueSz = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double optMarketValue = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double totalAsset = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double coveredAmount = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double dutyAmount = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double rightAmount = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double rightAmountSh = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double coveredAmountSh = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double dutyAmountSh = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double rightAmountSz = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double dutyAmountSz = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double coveredAmountSz = 0.0D;

        public GetFundrealAssetInnerOutput() {
        }

        public Double getOptMarketValueSh() {
            return this.optMarketValueSh != null ? this.optMarketValueSh : 0.0D;
        }

        public Double getOptMarketValueSz() {
            return this.optMarketValueSz != null ? this.optMarketValueSz : 0.0D;
        }

        public Double getOptMarketValue() {
            return this.optMarketValue != null ? this.optMarketValue : 0.0D;
        }

        public Double getTotalAsset() {
            return this.totalAsset != null ? this.totalAsset : 0.0D;
        }

        public Double getCoveredAmount() {
            return this.coveredAmount != null ? this.coveredAmount : 0.0D;
        }

        public Double getDutyAmount() {
            return this.dutyAmount != null ? this.dutyAmount : 0.0D;
        }

        public Double getRightAmount() {
            return this.rightAmount != null ? this.rightAmount : 0.0D;
        }

        public Double getRightAmountSh() {
            return this.rightAmountSh != null ? this.rightAmountSh : 0.0D;
        }

        public Double getCoveredAmountSh() {
            return this.coveredAmountSh != null ? this.coveredAmountSh : 0.0D;
        }

        public Double getDutyAmountSh() {
            return this.dutyAmountSh != null ? this.dutyAmountSh : 0.0D;
        }

        public Double getRightAmountSz() {
            return this.rightAmountSz != null ? this.rightAmountSz : 0.0D;
        }

        public Double getDutyAmountSz() {
            return this.dutyAmountSz != null ? this.dutyAmountSz : 0.0D;
        }

        public Double getCoveredAmountSz() {
            return this.coveredAmountSz != null ? this.coveredAmountSz : 0.0D;
        }

        public void setOptMarketValueSh(Double optMarketValueSh) {
            this.optMarketValueSh = optMarketValueSh;
        }

        public void setOptMarketValueSz(Double optMarketValueSz) {
            this.optMarketValueSz = optMarketValueSz;
        }

        public void setOptMarketValue(Double optMarketValue) {
            this.optMarketValue = optMarketValue;
        }

        public void setTotalAsset(Double totalAsset) {
            this.totalAsset = totalAsset;
        }

        public void setCoveredAmount(Double coveredAmount) {
            this.coveredAmount = coveredAmount;
        }

        public void setDutyAmount(Double dutyAmount) {
            this.dutyAmount = dutyAmount;
        }

        public void setRightAmount(Double rightAmount) {
            this.rightAmount = rightAmount;
        }

        public void setRightAmountSh(Double rightAmountSh) {
            this.rightAmountSh = rightAmountSh;
        }

        public void setCoveredAmountSh(Double coveredAmountSh) {
            this.coveredAmountSh = coveredAmountSh;
        }

        public void setDutyAmountSh(Double dutyAmountSh) {
            this.dutyAmountSh = dutyAmountSh;
        }

        public void setRightAmountSz(Double rightAmountSz) {
            this.rightAmountSz = rightAmountSz;
        }

        public void setDutyAmountSz(Double dutyAmountSz) {
            this.dutyAmountSz = dutyAmountSz;
        }

        public void setCoveredAmountSz(Double coveredAmountSz) {
            this.coveredAmountSz = coveredAmountSz;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetFundrealAssetInnerOutput:(");
            buffer.append("optMarketValueSh:" + this.optMarketValueSh);
            buffer.append(",optMarketValueSz:" + this.optMarketValueSz);
            buffer.append(",optMarketValue:" + this.optMarketValue);
            buffer.append(",totalAsset:" + this.totalAsset);
            buffer.append(",coveredAmount:" + this.coveredAmount);
            buffer.append(",dutyAmount:" + this.dutyAmount);
            buffer.append(",rightAmount:" + this.rightAmount);
            buffer.append(",rightAmountSh:" + this.rightAmountSh);
            buffer.append(",coveredAmountSh:" + this.coveredAmountSh);
            buffer.append(",dutyAmountSh:" + this.dutyAmountSh);
            buffer.append(",rightAmountSz:" + this.rightAmountSz);
            buffer.append(",dutyAmountSz:" + this.dutyAmountSz);
            buffer.append(",coveredAmountSz:" + this.coveredAmountSz);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.optMarketValueSh);
            builder.append(this.optMarketValueSz);
            builder.append(this.optMarketValue);
            builder.append(this.totalAsset);
            builder.append(this.coveredAmount);
            builder.append(this.dutyAmount);
            builder.append(this.rightAmount);
            builder.append(this.rightAmountSh);
            builder.append(this.coveredAmountSh);
            builder.append(this.dutyAmountSh);
            builder.append(this.rightAmountSz);
            builder.append(this.dutyAmountSz);
            builder.append(this.coveredAmountSz);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.GetFundrealAssetInnerOutput obj) {
            if (obj instanceof InnerOptService.GetFundrealAssetInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.optMarketValueSh, obj.optMarketValueSh);
                builder.append(this.optMarketValueSz, obj.optMarketValueSz);
                builder.append(this.optMarketValue, obj.optMarketValue);
                builder.append(this.totalAsset, obj.totalAsset);
                builder.append(this.coveredAmount, obj.coveredAmount);
                builder.append(this.dutyAmount, obj.dutyAmount);
                builder.append(this.rightAmount, obj.rightAmount);
                builder.append(this.rightAmountSh, obj.rightAmountSh);
                builder.append(this.coveredAmountSh, obj.coveredAmountSh);
                builder.append(this.dutyAmountSh, obj.dutyAmountSh);
                builder.append(this.rightAmountSz, obj.rightAmountSz);
                builder.append(this.dutyAmountSz, obj.dutyAmountSz);
                builder.append(this.coveredAmountSz, obj.coveredAmountSz);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetFundrealAssetInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String clientId = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fundAccount = " ";

        public GetFundrealAssetInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetFundrealAssetInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.clientId);
            builder.append(this.fundAccount);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.GetFundrealAssetInnerInput obj) {
            if (obj instanceof InnerOptService.GetFundrealAssetInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, obj.opPassword);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.clientId, obj.clientId);
                builder.append(this.fundAccount, obj.fundAccount);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetFundaccountCancelCheckInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer noticeNo = 0;
        private String noticeInfo = " ";
        private String checkId = " ";

        public GetFundaccountCancelCheckInnerOutput() {
        }

        public Integer getNoticeNo() {
            return this.noticeNo != null ? this.noticeNo : 0;
        }

        public String getNoticeInfo() {
            if (this.noticeInfo == null) {
                return " ";
            } else {
                return this.noticeInfo.isEmpty() ? " " : this.noticeInfo;
            }
        }

        public String getCheckId() {
            if (this.checkId == null) {
                return " ";
            } else {
                return this.checkId.isEmpty() ? " " : this.checkId;
            }
        }

        public void setNoticeNo(Integer noticeNo) {
            this.noticeNo = noticeNo;
        }

        public void setNoticeInfo(String noticeInfo) {
            this.noticeInfo = noticeInfo;
        }

        public void setCheckId(String checkId) {
            this.checkId = checkId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetFundaccountCancelCheckInnerOutput:(");
            buffer.append("noticeNo:" + this.noticeNo);
            buffer.append(",noticeInfo:" + this.noticeInfo);
            buffer.append(",checkId:" + this.checkId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.noticeNo);
            builder.append(this.noticeInfo);
            builder.append(this.checkId);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.GetFundaccountCancelCheckInnerOutput obj) {
            if (obj instanceof InnerOptService.GetFundaccountCancelCheckInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.noticeNo, obj.noticeNo);
                builder.append(this.noticeInfo, obj.noticeInfo);
                builder.append(this.checkId, obj.checkId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetFundaccountCancelCheckInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String fundAccount;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId;

        public GetFundaccountCancelCheckInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getFundAccount() {
            return this.fundAccount;
        }

        public String getClientId() {
            return this.clientId;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetFundaccountCancelCheckInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.fundAccount);
            builder.append(this.clientId);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.GetFundaccountCancelCheckInnerInput obj) {
            if (obj instanceof InnerOptService.GetFundaccountCancelCheckInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, obj.opPassword);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.fundAccount, obj.fundAccount);
                builder.append(this.clientId, obj.clientId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetFundaccountBranchTransCheckInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character checkFlag = ' ';
        private String errorMessage = " ";

        public GetFundaccountBranchTransCheckInnerOutput() {
        }

        public Character getCheckFlag() {
            return this.checkFlag != null ? this.checkFlag : ' ';
        }

        public String getErrorMessage() {
            if (this.errorMessage == null) {
                return " ";
            } else {
                return this.errorMessage.isEmpty() ? " " : this.errorMessage;
            }
        }

        public void setCheckFlag(Character checkFlag) {
            this.checkFlag = checkFlag;
        }

        public void setErrorMessage(String errorMessage) {
            this.errorMessage = errorMessage;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetFundaccountBranchTransCheckInnerOutput:(");
            buffer.append("checkFlag:" + this.checkFlag);
            buffer.append(",errorMessage:" + this.errorMessage);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.checkFlag);
            builder.append(this.errorMessage);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.GetFundaccountBranchTransCheckInnerOutput obj) {
            if (obj instanceof InnerOptService.GetFundaccountBranchTransCheckInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.checkFlag, obj.checkFlag);
                builder.append(this.errorMessage, obj.errorMessage);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetFundaccountBranchTransCheckInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String fundAccount;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId;

        public GetFundaccountBranchTransCheckInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getFundAccount() {
            return this.fundAccount;
        }

        public String getClientId() {
            return this.clientId;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetFundaccountBranchTransCheckInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.fundAccount);
            builder.append(this.clientId);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.GetFundaccountBranchTransCheckInnerInput obj) {
            if (obj instanceof InnerOptService.GetFundaccountBranchTransCheckInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, obj.opPassword);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.fundAccount, obj.fundAccount);
                builder.append(this.clientId, obj.clientId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetFundaccountBankCancelcheckInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer noticeNo = 0;
        private String noticeInfo = " ";
        private String checkId = " ";

        public GetFundaccountBankCancelcheckInnerOutput() {
        }

        public Integer getNoticeNo() {
            return this.noticeNo != null ? this.noticeNo : 0;
        }

        public String getNoticeInfo() {
            if (this.noticeInfo == null) {
                return " ";
            } else {
                return this.noticeInfo.isEmpty() ? " " : this.noticeInfo;
            }
        }

        public String getCheckId() {
            if (this.checkId == null) {
                return " ";
            } else {
                return this.checkId.isEmpty() ? " " : this.checkId;
            }
        }

        public void setNoticeNo(Integer noticeNo) {
            this.noticeNo = noticeNo;
        }

        public void setNoticeInfo(String noticeInfo) {
            this.noticeInfo = noticeInfo;
        }

        public void setCheckId(String checkId) {
            this.checkId = checkId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetFundaccountBankCancelcheckInnerOutput:(");
            buffer.append("noticeNo:" + this.noticeNo);
            buffer.append(",noticeInfo:" + this.noticeInfo);
            buffer.append(",checkId:" + this.checkId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.noticeNo);
            builder.append(this.noticeInfo);
            builder.append(this.checkId);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.GetFundaccountBankCancelcheckInnerOutput obj) {
            if (obj instanceof InnerOptService.GetFundaccountBankCancelcheckInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.noticeNo, obj.noticeNo);
                builder.append(this.noticeInfo, obj.noticeInfo);
                builder.append(this.checkId, obj.checkId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetFundaccountBankCancelcheckInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String clientId = " ";
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String fundAccount;
        @SinogramLength(
                min = 0,
                max = 3,
                charset = "utf-8"
        )
        private String moneyType = " ";

        public GetFundaccountBankCancelcheckInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getFundAccount() {
            return this.fundAccount;
        }

        public String getMoneyType() {
            if (this.moneyType == null) {
                return " ";
            } else {
                return this.moneyType.isEmpty() ? " " : this.moneyType;
            }
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setMoneyType(String moneyType) {
            this.moneyType = moneyType;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetFundaccountBankCancelcheckInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",moneyType:" + this.moneyType);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.clientId);
            builder.append(this.fundAccount);
            builder.append(this.moneyType);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.GetFundaccountBankCancelcheckInnerInput obj) {
            if (obj instanceof InnerOptService.GetFundaccountBankCancelcheckInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, obj.opPassword);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.clientId, obj.clientId);
                builder.append(this.fundAccount, obj.fundAccount);
                builder.append(this.moneyType, obj.moneyType);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetFare2QryInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer total = 0;
        private Integer currentPage = 0;
        private List<InnerOptService.Fare2DTO> rows;

        public GetFare2QryInnerOutput() {
        }

        public Integer getTotal() {
            return this.total != null ? this.total : 0;
        }

        public Integer getCurrentPage() {
            return this.currentPage != null ? this.currentPage : 0;
        }

        public List<InnerOptService.Fare2DTO> getRows() {
            return this.rows;
        }

        public void setTotal(Integer total) {
            this.total = total;
        }

        public void setCurrentPage(Integer currentPage) {
            this.currentPage = currentPage;
        }

        public void setRows(List<InnerOptService.Fare2DTO> rows) {
            this.rows = rows;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetFare2QryInnerOutput:(");
            buffer.append("total:" + this.total);
            buffer.append(",currentPage:" + this.currentPage);
            buffer.append(",rows:" + this.rows);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.total);
            builder.append(this.currentPage);
            builder.append(this.rows);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.GetFare2QryInnerOutput obj) {
            if (obj instanceof InnerOptService.GetFare2QryInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.total, obj.total);
                builder.append(this.currentPage, obj.currentPage);
                builder.append(this.rows, obj.rows);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetFare2QryInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        private Integer fareKind = 0;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String enFareType = " ";
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String enExchangeType = " ";
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String enStockType = " ";
        @SinogramLength(
                min = 0,
                max = 20,
                charset = "utf-8"
        )
        private String enMoneyType = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String enEntrustBs = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String enEntrustWay = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String enEntrustType = " ";
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String enEntrustOc = " ";
        private Integer pageNo = 0;
        private Integer pageSize = 0;

        public GetFare2QryInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public Integer getFareKind() {
            return this.fareKind != null ? this.fareKind : 0;
        }

        public String getEnFareType() {
            if (this.enFareType == null) {
                return " ";
            } else {
                return this.enFareType.isEmpty() ? " " : this.enFareType;
            }
        }

        public String getEnExchangeType() {
            if (this.enExchangeType == null) {
                return " ";
            } else {
                return this.enExchangeType.isEmpty() ? " " : this.enExchangeType;
            }
        }

        public String getEnStockType() {
            if (this.enStockType == null) {
                return " ";
            } else {
                return this.enStockType.isEmpty() ? " " : this.enStockType;
            }
        }

        public String getEnMoneyType() {
            if (this.enMoneyType == null) {
                return " ";
            } else {
                return this.enMoneyType.isEmpty() ? " " : this.enMoneyType;
            }
        }

        public String getEnEntrustBs() {
            if (this.enEntrustBs == null) {
                return " ";
            } else {
                return this.enEntrustBs.isEmpty() ? " " : this.enEntrustBs;
            }
        }

        public String getEnEntrustWay() {
            if (this.enEntrustWay == null) {
                return " ";
            } else {
                return this.enEntrustWay.isEmpty() ? " " : this.enEntrustWay;
            }
        }

        public String getEnEntrustType() {
            if (this.enEntrustType == null) {
                return " ";
            } else {
                return this.enEntrustType.isEmpty() ? " " : this.enEntrustType;
            }
        }

        public String getEnEntrustOc() {
            if (this.enEntrustOc == null) {
                return " ";
            } else {
                return this.enEntrustOc.isEmpty() ? " " : this.enEntrustOc;
            }
        }

        public Integer getPageNo() {
            return this.pageNo != null ? this.pageNo : 0;
        }

        public Integer getPageSize() {
            return this.pageSize != null ? this.pageSize : 0;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setFareKind(Integer fareKind) {
            this.fareKind = fareKind;
        }

        public void setEnFareType(String enFareType) {
            this.enFareType = enFareType;
        }

        public void setEnExchangeType(String enExchangeType) {
            this.enExchangeType = enExchangeType;
        }

        public void setEnStockType(String enStockType) {
            this.enStockType = enStockType;
        }

        public void setEnMoneyType(String enMoneyType) {
            this.enMoneyType = enMoneyType;
        }

        public void setEnEntrustBs(String enEntrustBs) {
            this.enEntrustBs = enEntrustBs;
        }

        public void setEnEntrustWay(String enEntrustWay) {
            this.enEntrustWay = enEntrustWay;
        }

        public void setEnEntrustType(String enEntrustType) {
            this.enEntrustType = enEntrustType;
        }

        public void setEnEntrustOc(String enEntrustOc) {
            this.enEntrustOc = enEntrustOc;
        }

        public void setPageNo(Integer pageNo) {
            this.pageNo = pageNo;
        }

        public void setPageSize(Integer pageSize) {
            this.pageSize = pageSize;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetFare2QryInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",fareKind:" + this.fareKind);
            buffer.append(",enFareType:" + this.enFareType);
            buffer.append(",enExchangeType:" + this.enExchangeType);
            buffer.append(",enStockType:" + this.enStockType);
            buffer.append(",enMoneyType:" + this.enMoneyType);
            buffer.append(",enEntrustBs:" + this.enEntrustBs);
            buffer.append(",enEntrustWay:" + this.enEntrustWay);
            buffer.append(",enEntrustType:" + this.enEntrustType);
            buffer.append(",enEntrustOc:" + this.enEntrustOc);
            buffer.append(",pageNo:" + this.pageNo);
            buffer.append(",pageSize:" + this.pageSize);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.fareKind);
            builder.append(this.enFareType);
            builder.append(this.enExchangeType);
            builder.append(this.enStockType);
            builder.append(this.enMoneyType);
            builder.append(this.enEntrustBs);
            builder.append(this.enEntrustWay);
            builder.append(this.enEntrustType);
            builder.append(this.enEntrustOc);
            builder.append(this.pageNo);
            builder.append(this.pageSize);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.GetFare2QryInnerInput obj) {
            if (obj instanceof InnerOptService.GetFare2QryInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, obj.opPassword);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.fareKind, obj.fareKind);
                builder.append(this.enFareType, obj.enFareType);
                builder.append(this.enExchangeType, obj.enExchangeType);
                builder.append(this.enStockType, obj.enStockType);
                builder.append(this.enMoneyType, obj.enMoneyType);
                builder.append(this.enEntrustBs, obj.enEntrustBs);
                builder.append(this.enEntrustWay, obj.enEntrustWay);
                builder.append(this.enEntrustType, obj.enEntrustType);
                builder.append(this.enEntrustOc, obj.enEntrustOc);
                builder.append(this.pageNo, obj.pageNo);
                builder.append(this.pageSize, obj.pageSize);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetExeagreementInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer initDate = 0;
        private String agreementId = " ";
        private Integer branchNo = 0;
        private String acctId = " ";
        private String fundAccount = " ";
        private String exchangeType = " ";
        private String optionCode = " ";
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double agreeAmount = 0.0D;
        private Integer endDate = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character optexeStgKind = ' ';
        @SerializeDoubleDigit(
                digit = 8
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double optexeStgValue = 0.0D;
        private String optionName = " ";
        private String stockName = " ";
        private String stockCode = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character controlFlag = ' ';
        private String remark = " ";
        private String positionStr = " ";

        public GetExeagreementInnerOutput() {
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public String getAgreementId() {
            if (this.agreementId == null) {
                return " ";
            } else {
                return this.agreementId.isEmpty() ? " " : this.agreementId;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getAcctId() {
            if (this.acctId == null) {
                return " ";
            } else {
                return this.acctId.isEmpty() ? " " : this.acctId;
            }
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getExchangeType() {
            if (this.exchangeType == null) {
                return " ";
            } else {
                return this.exchangeType.isEmpty() ? " " : this.exchangeType;
            }
        }

        public String getOptionCode() {
            if (this.optionCode == null) {
                return " ";
            } else {
                return this.optionCode.isEmpty() ? " " : this.optionCode;
            }
        }

        public Double getAgreeAmount() {
            return this.agreeAmount != null ? this.agreeAmount : 0.0D;
        }

        public Integer getEndDate() {
            return this.endDate != null ? this.endDate : 0;
        }

        public Character getOptexeStgKind() {
            return this.optexeStgKind != null ? this.optexeStgKind : ' ';
        }

        public Double getOptexeStgValue() {
            return this.optexeStgValue != null ? this.optexeStgValue : 0.0D;
        }

        public String getOptionName() {
            if (this.optionName == null) {
                return " ";
            } else {
                return this.optionName.isEmpty() ? " " : this.optionName;
            }
        }

        public String getStockName() {
            if (this.stockName == null) {
                return " ";
            } else {
                return this.stockName.isEmpty() ? " " : this.stockName;
            }
        }

        public String getStockCode() {
            if (this.stockCode == null) {
                return " ";
            } else {
                return this.stockCode.isEmpty() ? " " : this.stockCode;
            }
        }

        public Character getControlFlag() {
            return this.controlFlag != null ? this.controlFlag : ' ';
        }

        public String getRemark() {
            if (this.remark == null) {
                return " ";
            } else {
                return this.remark.isEmpty() ? " " : this.remark;
            }
        }

        public String getPositionStr() {
            if (this.positionStr == null) {
                return " ";
            } else {
                return this.positionStr.isEmpty() ? " " : this.positionStr;
            }
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public void setAgreementId(String agreementId) {
            this.agreementId = agreementId;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setAcctId(String acctId) {
            this.acctId = acctId;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public void setOptionCode(String optionCode) {
            this.optionCode = optionCode;
        }

        public void setAgreeAmount(Double agreeAmount) {
            this.agreeAmount = agreeAmount;
        }

        public void setEndDate(Integer endDate) {
            this.endDate = endDate;
        }

        public void setOptexeStgKind(Character optexeStgKind) {
            this.optexeStgKind = optexeStgKind;
        }

        public void setOptexeStgValue(Double optexeStgValue) {
            this.optexeStgValue = optexeStgValue;
        }

        public void setOptionName(String optionName) {
            this.optionName = optionName;
        }

        public void setStockName(String stockName) {
            this.stockName = stockName;
        }

        public void setStockCode(String stockCode) {
            this.stockCode = stockCode;
        }

        public void setControlFlag(Character controlFlag) {
            this.controlFlag = controlFlag;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public void setPositionStr(String positionStr) {
            this.positionStr = positionStr;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetExeagreementInnerOutput:(");
            buffer.append("initDate:" + this.initDate);
            buffer.append(",agreementId:" + this.agreementId);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",acctId:" + this.acctId);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(",optionCode:" + this.optionCode);
            buffer.append(",agreeAmount:" + this.agreeAmount);
            buffer.append(",endDate:" + this.endDate);
            buffer.append(",optexeStgKind:" + this.optexeStgKind);
            buffer.append(",optexeStgValue:" + this.optexeStgValue);
            buffer.append(",optionName:" + this.optionName);
            buffer.append(",stockName:" + this.stockName);
            buffer.append(",stockCode:" + this.stockCode);
            buffer.append(",controlFlag:" + this.controlFlag);
            buffer.append(",remark:" + this.remark);
            buffer.append(",positionStr:" + this.positionStr);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.initDate);
            builder.append(this.agreementId);
            builder.append(this.branchNo);
            builder.append(this.acctId);
            builder.append(this.fundAccount);
            builder.append(this.exchangeType);
            builder.append(this.optionCode);
            builder.append(this.agreeAmount);
            builder.append(this.endDate);
            builder.append(this.optexeStgKind);
            builder.append(this.optexeStgValue);
            builder.append(this.optionName);
            builder.append(this.stockName);
            builder.append(this.stockCode);
            builder.append(this.controlFlag);
            builder.append(this.remark);
            builder.append(this.positionStr);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.GetExeagreementInnerOutput obj) {
            if (obj instanceof InnerOptService.GetExeagreementInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.initDate, obj.initDate);
                builder.append(this.agreementId, obj.agreementId);
                builder.append(this.branchNo, obj.branchNo);
                builder.append(this.acctId, obj.acctId);
                builder.append(this.fundAccount, obj.fundAccount);
                builder.append(this.exchangeType, obj.exchangeType);
                builder.append(this.optionCode, obj.optionCode);
                builder.append(this.agreeAmount, obj.agreeAmount);
                builder.append(this.endDate, obj.endDate);
                builder.append(this.optexeStgKind, obj.optexeStgKind);
                builder.append(this.optexeStgValue, obj.optexeStgValue);
                builder.append(this.optionName, obj.optionName);
                builder.append(this.stockName, obj.stockName);
                builder.append(this.stockCode, obj.stockCode);
                builder.append(this.controlFlag, obj.controlFlag);
                builder.append(this.remark, obj.remark);
                builder.append(this.positionStr, obj.positionStr);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetExeagreementInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 4000,
                charset = "utf-8"
        )
        private String enBranchNo = " ";
        @SinogramLength(
                min = 0,
                max = 100,
                charset = "utf-8"
        )
        private String positionStr = " ";
        private Integer requestNum = 0;

        public GetExeagreementInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getEnBranchNo() {
            if (this.enBranchNo == null) {
                return " ";
            } else {
                return this.enBranchNo.isEmpty() ? " " : this.enBranchNo;
            }
        }

        public String getPositionStr() {
            if (this.positionStr == null) {
                return " ";
            } else {
                return this.positionStr.isEmpty() ? " " : this.positionStr;
            }
        }

        public Integer getRequestNum() {
            return this.requestNum != null ? this.requestNum : 0;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setEnBranchNo(String enBranchNo) {
            this.enBranchNo = enBranchNo;
        }

        public void setPositionStr(String positionStr) {
            this.positionStr = positionStr;
        }

        public void setRequestNum(Integer requestNum) {
            this.requestNum = requestNum;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetExeagreementInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",enBranchNo:" + this.enBranchNo);
            buffer.append(",positionStr:" + this.positionStr);
            buffer.append(",requestNum:" + this.requestNum);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.enBranchNo);
            builder.append(this.positionStr);
            builder.append(this.requestNum);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.GetExeagreementInnerInput obj) {
            if (obj instanceof InnerOptService.GetExeagreementInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, obj.opPassword);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.enBranchNo, obj.enBranchNo);
                builder.append(this.positionStr, obj.positionStr);
                builder.append(this.requestNum, obj.requestNum);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetExchtimeReportStatusInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character reportFlag = ' ';

        public GetExchtimeReportStatusInnerOutput() {
        }

        public Character getReportFlag() {
            return this.reportFlag != null ? this.reportFlag : ' ';
        }

        public void setReportFlag(Character reportFlag) {
            this.reportFlag = reportFlag;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetExchtimeReportStatusInnerOutput:(");
            buffer.append("reportFlag:" + this.reportFlag);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.reportFlag);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.GetExchtimeReportStatusInnerOutput obj) {
            if (obj instanceof InnerOptService.GetExchtimeReportStatusInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.reportFlag, obj.reportFlag);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetExchtimeReportStatusInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String exchangeType = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character transplatType = ' ';
        private Integer pollingAheadTime = 0;

        public GetExchtimeReportStatusInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getExchangeType() {
            if (this.exchangeType == null) {
                return " ";
            } else {
                return this.exchangeType.isEmpty() ? " " : this.exchangeType;
            }
        }

        public Character getTransplatType() {
            return this.transplatType != null ? this.transplatType : ' ';
        }

        public Integer getPollingAheadTime() {
            return this.pollingAheadTime != null ? this.pollingAheadTime : 0;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public void setTransplatType(Character transplatType) {
            this.transplatType = transplatType;
        }

        public void setPollingAheadTime(Integer pollingAheadTime) {
            this.pollingAheadTime = pollingAheadTime;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetExchtimeReportStatusInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(",transplatType:" + this.transplatType);
            buffer.append(",pollingAheadTime:" + this.pollingAheadTime);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.exchangeType);
            builder.append(this.transplatType);
            builder.append(this.pollingAheadTime);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.GetExchtimeReportStatusInnerInput obj) {
            if (obj instanceof InnerOptService.GetExchtimeReportStatusInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, obj.opPassword);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.exchangeType, obj.exchangeType);
                builder.append(this.transplatType, obj.transplatType);
                builder.append(this.pollingAheadTime, obj.pollingAheadTime);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetExchargInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer accountLen = 0;
        private String bailResopenCompany = " ";
        private Integer bbackDate = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character coveredTransMode = ' ';
        private String exchangeName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character exchangeStatus = ' ';
        private String exchangeType = " ";
        private Integer fbackDate = 0;
        private String holdResopenCompany = " ";
        private Integer initDate = 0;
        private Integer interceptLen = 0;
        private Integer internalLen = 0;
        private String moneyType = " ";
        private String prefix = " ";
        private Integer seatPrefixLen = 0;
        private String treatFlag = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character withdraw = ' ';

        public GetExchargInnerOutput() {
        }

        public Integer getAccountLen() {
            return this.accountLen != null ? this.accountLen : 0;
        }

        public String getBailResopenCompany() {
            if (this.bailResopenCompany == null) {
                return " ";
            } else {
                return this.bailResopenCompany.isEmpty() ? " " : this.bailResopenCompany;
            }
        }

        public Integer getBbackDate() {
            return this.bbackDate != null ? this.bbackDate : 0;
        }

        public Character getCoveredTransMode() {
            return this.coveredTransMode != null ? this.coveredTransMode : ' ';
        }

        public String getExchangeName() {
            if (this.exchangeName == null) {
                return " ";
            } else {
                return this.exchangeName.isEmpty() ? " " : this.exchangeName;
            }
        }

        public Character getExchangeStatus() {
            return this.exchangeStatus != null ? this.exchangeStatus : ' ';
        }

        public String getExchangeType() {
            if (this.exchangeType == null) {
                return " ";
            } else {
                return this.exchangeType.isEmpty() ? " " : this.exchangeType;
            }
        }

        public Integer getFbackDate() {
            return this.fbackDate != null ? this.fbackDate : 0;
        }

        public String getHoldResopenCompany() {
            if (this.holdResopenCompany == null) {
                return " ";
            } else {
                return this.holdResopenCompany.isEmpty() ? " " : this.holdResopenCompany;
            }
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public Integer getInterceptLen() {
            return this.interceptLen != null ? this.interceptLen : 0;
        }

        public Integer getInternalLen() {
            return this.internalLen != null ? this.internalLen : 0;
        }

        public String getMoneyType() {
            if (this.moneyType == null) {
                return " ";
            } else {
                return this.moneyType.isEmpty() ? " " : this.moneyType;
            }
        }

        public String getPrefix() {
            if (this.prefix == null) {
                return " ";
            } else {
                return this.prefix.isEmpty() ? " " : this.prefix;
            }
        }

        public Integer getSeatPrefixLen() {
            return this.seatPrefixLen != null ? this.seatPrefixLen : 0;
        }

        public String getTreatFlag() {
            if (this.treatFlag == null) {
                return " ";
            } else {
                return this.treatFlag.isEmpty() ? " " : this.treatFlag;
            }
        }

        public Character getWithdraw() {
            return this.withdraw != null ? this.withdraw : ' ';
        }

        public void setAccountLen(Integer accountLen) {
            this.accountLen = accountLen;
        }

        public void setBailResopenCompany(String bailResopenCompany) {
            this.bailResopenCompany = bailResopenCompany;
        }

        public void setBbackDate(Integer bbackDate) {
            this.bbackDate = bbackDate;
        }

        public void setCoveredTransMode(Character coveredTransMode) {
            this.coveredTransMode = coveredTransMode;
        }

        public void setExchangeName(String exchangeName) {
            this.exchangeName = exchangeName;
        }

        public void setExchangeStatus(Character exchangeStatus) {
            this.exchangeStatus = exchangeStatus;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public void setFbackDate(Integer fbackDate) {
            this.fbackDate = fbackDate;
        }

        public void setHoldResopenCompany(String holdResopenCompany) {
            this.holdResopenCompany = holdResopenCompany;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public void setInterceptLen(Integer interceptLen) {
            this.interceptLen = interceptLen;
        }

        public void setInternalLen(Integer internalLen) {
            this.internalLen = internalLen;
        }

        public void setMoneyType(String moneyType) {
            this.moneyType = moneyType;
        }

        public void setPrefix(String prefix) {
            this.prefix = prefix;
        }

        public void setSeatPrefixLen(Integer seatPrefixLen) {
            this.seatPrefixLen = seatPrefixLen;
        }

        public void setTreatFlag(String treatFlag) {
            this.treatFlag = treatFlag;
        }

        public void setWithdraw(Character withdraw) {
            this.withdraw = withdraw;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetExchargInnerOutput:(");
            buffer.append("accountLen:" + this.accountLen);
            buffer.append(",bailResopenCompany:" + this.bailResopenCompany);
            buffer.append(",bbackDate:" + this.bbackDate);
            buffer.append(",coveredTransMode:" + this.coveredTransMode);
            buffer.append(",exchangeName:" + this.exchangeName);
            buffer.append(",exchangeStatus:" + this.exchangeStatus);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(",fbackDate:" + this.fbackDate);
            buffer.append(",holdResopenCompany:" + this.holdResopenCompany);
            buffer.append(",initDate:" + this.initDate);
            buffer.append(",interceptLen:" + this.interceptLen);
            buffer.append(",internalLen:" + this.internalLen);
            buffer.append(",moneyType:" + this.moneyType);
            buffer.append(",prefix:" + this.prefix);
            buffer.append(",seatPrefixLen:" + this.seatPrefixLen);
            buffer.append(",treatFlag:" + this.treatFlag);
            buffer.append(",withdraw:" + this.withdraw);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.accountLen);
            builder.append(this.bailResopenCompany);
            builder.append(this.bbackDate);
            builder.append(this.coveredTransMode);
            builder.append(this.exchangeName);
            builder.append(this.exchangeStatus);
            builder.append(this.exchangeType);
            builder.append(this.fbackDate);
            builder.append(this.holdResopenCompany);
            builder.append(this.initDate);
            builder.append(this.interceptLen);
            builder.append(this.internalLen);
            builder.append(this.moneyType);
            builder.append(this.prefix);
            builder.append(this.seatPrefixLen);
            builder.append(this.treatFlag);
            builder.append(this.withdraw);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.GetExchargInnerOutput obj) {
            if (obj instanceof InnerOptService.GetExchargInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.accountLen, obj.accountLen);
                builder.append(this.bailResopenCompany, obj.bailResopenCompany);
                builder.append(this.bbackDate, obj.bbackDate);
                builder.append(this.coveredTransMode, obj.coveredTransMode);
                builder.append(this.exchangeName, obj.exchangeName);
                builder.append(this.exchangeStatus, obj.exchangeStatus);
                builder.append(this.exchangeType, obj.exchangeType);
                builder.append(this.fbackDate, obj.fbackDate);
                builder.append(this.holdResopenCompany, obj.holdResopenCompany);
                builder.append(this.initDate, obj.initDate);
                builder.append(this.interceptLen, obj.interceptLen);
                builder.append(this.internalLen, obj.internalLen);
                builder.append(this.moneyType, obj.moneyType);
                builder.append(this.prefix, obj.prefix);
                builder.append(this.seatPrefixLen, obj.seatPrefixLen);
                builder.append(this.treatFlag, obj.treatFlag);
                builder.append(this.withdraw, obj.withdraw);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetExchargInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String exchangeType = " ";

        public GetExchargInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getExchangeType() {
            if (this.exchangeType == null) {
                return " ";
            } else {
                return this.exchangeType.isEmpty() ? " " : this.exchangeType;
            }
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetExchargInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.exchangeType);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.GetExchargInnerInput obj) {
            if (obj instanceof InnerOptService.GetExchargInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, obj.opPassword);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.exchangeType, obj.exchangeType);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetExchangeclientinfoCancelCheckInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer noticeNo = 0;
        private String noticeInfo = " ";
        private String checkId = " ";

        public GetExchangeclientinfoCancelCheckInnerOutput() {
        }

        public Integer getNoticeNo() {
            return this.noticeNo != null ? this.noticeNo : 0;
        }

        public String getNoticeInfo() {
            if (this.noticeInfo == null) {
                return " ";
            } else {
                return this.noticeInfo.isEmpty() ? " " : this.noticeInfo;
            }
        }

        public String getCheckId() {
            if (this.checkId == null) {
                return " ";
            } else {
                return this.checkId.isEmpty() ? " " : this.checkId;
            }
        }

        public void setNoticeNo(Integer noticeNo) {
            this.noticeNo = noticeNo;
        }

        public void setNoticeInfo(String noticeInfo) {
            this.noticeInfo = noticeInfo;
        }

        public void setCheckId(String checkId) {
            this.checkId = checkId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetExchangeclientinfoCancelCheckInnerOutput:(");
            buffer.append("noticeNo:" + this.noticeNo);
            buffer.append(",noticeInfo:" + this.noticeInfo);
            buffer.append(",checkId:" + this.checkId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.noticeNo);
            builder.append(this.noticeInfo);
            builder.append(this.checkId);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.GetExchangeclientinfoCancelCheckInnerOutput obj) {
            if (obj instanceof InnerOptService.GetExchangeclientinfoCancelCheckInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.noticeNo, obj.noticeNo);
                builder.append(this.noticeInfo, obj.noticeInfo);
                builder.append(this.checkId, obj.checkId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetExchangeclientinfoCancelCheckInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String fundAccount;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId;
        @SinogramLength(
                min = 1,
                max = 4,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String exchangeType;
        @SinogramLength(
                min = 1,
                max = 20,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String stockAccount;

        public GetExchangeclientinfoCancelCheckInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getFundAccount() {
            return this.fundAccount;
        }

        public String getClientId() {
            return this.clientId;
        }

        public String getExchangeType() {
            return this.exchangeType;
        }

        public String getStockAccount() {
            return this.stockAccount;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public void setStockAccount(String stockAccount) {
            this.stockAccount = stockAccount;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetExchangeclientinfoCancelCheckInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(",stockAccount:" + this.stockAccount);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.fundAccount);
            builder.append(this.clientId);
            builder.append(this.exchangeType);
            builder.append(this.stockAccount);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.GetExchangeclientinfoCancelCheckInnerInput obj) {
            if (obj instanceof InnerOptService.GetExchangeclientinfoCancelCheckInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, obj.opPassword);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.fundAccount, obj.fundAccount);
                builder.append(this.clientId, obj.clientId);
                builder.append(this.exchangeType, obj.exchangeType);
                builder.append(this.stockAccount, obj.stockAccount);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetEntrustPollingInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer branchNo = 0;
        private String componentAmountStr = " ";
        private Integer componentCount = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character coveredFlag = ' ';
        private Integer currTime = 0;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double entrustAmount = 0.0D;
        @JsonSerialize(
                using = LongJsonSerializer.class
        )
        @JsonDeserialize(
                using = LongJsonDeserializer.class
        )
        private Long entrustNo = 0L;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character entrustOc = ' ';
        private String entrustProp = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character entrustSrc = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character entrustType = ' ';
        private String exchangeType = " ";
        private Integer initDate = 0;
        @JsonSerialize(
                using = LongJsonSerializer.class
        )
        @JsonDeserialize(
                using = LongJsonDeserializer.class
        )
        private Long joinReportNo = 0L;
        @SerializeDoubleDigit(
                digit = 6
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double optEntrustPrice = 0.0D;
        private String optcombId = " ";
        private String optholdTypeStr = " ";
        private String optionCode = " ";
        private String optionCodeStr = " ";
        private String orderId = " ";
        private String positionStr = " ";
        private String reportAccount = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character reportBs = ' ';
        private String reportCode = " ";
        @JsonSerialize(
                using = LongJsonSerializer.class
        )
        @JsonDeserialize(
                using = LongJsonDeserializer.class
        )
        private Long reportNo = 0L;
        private String seatNo = " ";
        private String selfReportAccount = " ";
        private String selfSeatNo = " ";
        private String stockCode = " ";
        private String origOrderId = " ";

        public GetEntrustPollingInnerOutput() {
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getComponentAmountStr() {
            if (this.componentAmountStr == null) {
                return " ";
            } else {
                return this.componentAmountStr.isEmpty() ? " " : this.componentAmountStr;
            }
        }

        public Integer getComponentCount() {
            return this.componentCount != null ? this.componentCount : 0;
        }

        public Character getCoveredFlag() {
            return this.coveredFlag != null ? this.coveredFlag : ' ';
        }

        public Integer getCurrTime() {
            return this.currTime != null ? this.currTime : 0;
        }

        public Double getEntrustAmount() {
            return this.entrustAmount != null ? this.entrustAmount : 0.0D;
        }

        public Long getEntrustNo() {
            return this.entrustNo != null ? this.entrustNo : 0L;
        }

        public Character getEntrustOc() {
            return this.entrustOc != null ? this.entrustOc : ' ';
        }

        public String getEntrustProp() {
            if (this.entrustProp == null) {
                return " ";
            } else {
                return this.entrustProp.isEmpty() ? " " : this.entrustProp;
            }
        }

        public Character getEntrustSrc() {
            return this.entrustSrc != null ? this.entrustSrc : ' ';
        }

        public Character getEntrustType() {
            return this.entrustType != null ? this.entrustType : ' ';
        }

        public String getExchangeType() {
            if (this.exchangeType == null) {
                return " ";
            } else {
                return this.exchangeType.isEmpty() ? " " : this.exchangeType;
            }
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public Long getJoinReportNo() {
            return this.joinReportNo != null ? this.joinReportNo : 0L;
        }

        public Double getOptEntrustPrice() {
            return this.optEntrustPrice != null ? this.optEntrustPrice : 0.0D;
        }

        public String getOptcombId() {
            if (this.optcombId == null) {
                return " ";
            } else {
                return this.optcombId.isEmpty() ? " " : this.optcombId;
            }
        }

        public String getOptholdTypeStr() {
            if (this.optholdTypeStr == null) {
                return " ";
            } else {
                return this.optholdTypeStr.isEmpty() ? " " : this.optholdTypeStr;
            }
        }

        public String getOptionCode() {
            if (this.optionCode == null) {
                return " ";
            } else {
                return this.optionCode.isEmpty() ? " " : this.optionCode;
            }
        }

        public String getOptionCodeStr() {
            if (this.optionCodeStr == null) {
                return " ";
            } else {
                return this.optionCodeStr.isEmpty() ? " " : this.optionCodeStr;
            }
        }

        public String getOrderId() {
            if (this.orderId == null) {
                return " ";
            } else {
                return this.orderId.isEmpty() ? " " : this.orderId;
            }
        }

        public String getPositionStr() {
            if (this.positionStr == null) {
                return " ";
            } else {
                return this.positionStr.isEmpty() ? " " : this.positionStr;
            }
        }

        public String getReportAccount() {
            if (this.reportAccount == null) {
                return " ";
            } else {
                return this.reportAccount.isEmpty() ? " " : this.reportAccount;
            }
        }

        public Character getReportBs() {
            return this.reportBs != null ? this.reportBs : ' ';
        }

        public String getReportCode() {
            if (this.reportCode == null) {
                return " ";
            } else {
                return this.reportCode.isEmpty() ? " " : this.reportCode;
            }
        }

        public Long getReportNo() {
            return this.reportNo != null ? this.reportNo : 0L;
        }

        public String getSeatNo() {
            if (this.seatNo == null) {
                return " ";
            } else {
                return this.seatNo.isEmpty() ? " " : this.seatNo;
            }
        }

        public String getSelfReportAccount() {
            if (this.selfReportAccount == null) {
                return " ";
            } else {
                return this.selfReportAccount.isEmpty() ? " " : this.selfReportAccount;
            }
        }

        public String getSelfSeatNo() {
            if (this.selfSeatNo == null) {
                return " ";
            } else {
                return this.selfSeatNo.isEmpty() ? " " : this.selfSeatNo;
            }
        }

        public String getStockCode() {
            if (this.stockCode == null) {
                return " ";
            } else {
                return this.stockCode.isEmpty() ? " " : this.stockCode;
            }
        }

        public String getOrigOrderId() {
            if (this.origOrderId == null) {
                return " ";
            } else {
                return this.origOrderId.isEmpty() ? " " : this.origOrderId;
            }
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setComponentAmountStr(String componentAmountStr) {
            this.componentAmountStr = componentAmountStr;
        }

        public void setComponentCount(Integer componentCount) {
            this.componentCount = componentCount;
        }

        public void setCoveredFlag(Character coveredFlag) {
            this.coveredFlag = coveredFlag;
        }

        public void setCurrTime(Integer currTime) {
            this.currTime = currTime;
        }

        public void setEntrustAmount(Double entrustAmount) {
            this.entrustAmount = entrustAmount;
        }

        public void setEntrustNo(Long entrustNo) {
            this.entrustNo = entrustNo;
        }

        public void setEntrustOc(Character entrustOc) {
            this.entrustOc = entrustOc;
        }

        public void setEntrustProp(String entrustProp) {
            this.entrustProp = entrustProp;
        }

        public void setEntrustSrc(Character entrustSrc) {
            this.entrustSrc = entrustSrc;
        }

        public void setEntrustType(Character entrustType) {
            this.entrustType = entrustType;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public void setJoinReportNo(Long joinReportNo) {
            this.joinReportNo = joinReportNo;
        }

        public void setOptEntrustPrice(Double optEntrustPrice) {
            this.optEntrustPrice = optEntrustPrice;
        }

        public void setOptcombId(String optcombId) {
            this.optcombId = optcombId;
        }

        public void setOptholdTypeStr(String optholdTypeStr) {
            this.optholdTypeStr = optholdTypeStr;
        }

        public void setOptionCode(String optionCode) {
            this.optionCode = optionCode;
        }

        public void setOptionCodeStr(String optionCodeStr) {
            this.optionCodeStr = optionCodeStr;
        }

        public void setOrderId(String orderId) {
            this.orderId = orderId;
        }

        public void setPositionStr(String positionStr) {
            this.positionStr = positionStr;
        }

        public void setReportAccount(String reportAccount) {
            this.reportAccount = reportAccount;
        }

        public void setReportBs(Character reportBs) {
            this.reportBs = reportBs;
        }

        public void setReportCode(String reportCode) {
            this.reportCode = reportCode;
        }

        public void setReportNo(Long reportNo) {
            this.reportNo = reportNo;
        }

        public void setSeatNo(String seatNo) {
            this.seatNo = seatNo;
        }

        public void setSelfReportAccount(String selfReportAccount) {
            this.selfReportAccount = selfReportAccount;
        }

        public void setSelfSeatNo(String selfSeatNo) {
            this.selfSeatNo = selfSeatNo;
        }

        public void setStockCode(String stockCode) {
            this.stockCode = stockCode;
        }

        public void setOrigOrderId(String origOrderId) {
            this.origOrderId = origOrderId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetEntrustPollingInnerOutput:(");
            buffer.append("branchNo:" + this.branchNo);
            buffer.append(",componentAmountStr:" + this.componentAmountStr);
            buffer.append(",componentCount:" + this.componentCount);
            buffer.append(",coveredFlag:" + this.coveredFlag);
            buffer.append(",currTime:" + this.currTime);
            buffer.append(",entrustAmount:" + this.entrustAmount);
            buffer.append(",entrustNo:" + this.entrustNo);
            buffer.append(",entrustOc:" + this.entrustOc);
            buffer.append(",entrustProp:" + this.entrustProp);
            buffer.append(",entrustSrc:" + this.entrustSrc);
            buffer.append(",entrustType:" + this.entrustType);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(",initDate:" + this.initDate);
            buffer.append(",joinReportNo:" + this.joinReportNo);
            buffer.append(",optEntrustPrice:" + this.optEntrustPrice);
            buffer.append(",optcombId:" + this.optcombId);
            buffer.append(",optholdTypeStr:" + this.optholdTypeStr);
            buffer.append(",optionCode:" + this.optionCode);
            buffer.append(",optionCodeStr:" + this.optionCodeStr);
            buffer.append(",orderId:" + this.orderId);
            buffer.append(",positionStr:" + this.positionStr);
            buffer.append(",reportAccount:" + this.reportAccount);
            buffer.append(",reportBs:" + this.reportBs);
            buffer.append(",reportCode:" + this.reportCode);
            buffer.append(",reportNo:" + this.reportNo);
            buffer.append(",seatNo:" + this.seatNo);
            buffer.append(",selfReportAccount:" + this.selfReportAccount);
            buffer.append(",selfSeatNo:" + this.selfSeatNo);
            buffer.append(",stockCode:" + this.stockCode);
            buffer.append(",origOrderId:" + this.origOrderId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.branchNo);
            builder.append(this.componentAmountStr);
            builder.append(this.componentCount);
            builder.append(this.coveredFlag);
            builder.append(this.currTime);
            builder.append(this.entrustAmount);
            builder.append(this.entrustNo);
            builder.append(this.entrustOc);
            builder.append(this.entrustProp);
            builder.append(this.entrustSrc);
            builder.append(this.entrustType);
            builder.append(this.exchangeType);
            builder.append(this.initDate);
            builder.append(this.joinReportNo);
            builder.append(this.optEntrustPrice);
            builder.append(this.optcombId);
            builder.append(this.optholdTypeStr);
            builder.append(this.optionCode);
            builder.append(this.optionCodeStr);
            builder.append(this.orderId);
            builder.append(this.positionStr);
            builder.append(this.reportAccount);
            builder.append(this.reportBs);
            builder.append(this.reportCode);
            builder.append(this.reportNo);
            builder.append(this.seatNo);
            builder.append(this.selfReportAccount);
            builder.append(this.selfSeatNo);
            builder.append(this.stockCode);
            builder.append(this.origOrderId);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.GetEntrustPollingInnerOutput obj) {
            if (obj instanceof InnerOptService.GetEntrustPollingInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.branchNo, obj.branchNo);
                builder.append(this.componentAmountStr, obj.componentAmountStr);
                builder.append(this.componentCount, obj.componentCount);
                builder.append(this.coveredFlag, obj.coveredFlag);
                builder.append(this.currTime, obj.currTime);
                builder.append(this.entrustAmount, obj.entrustAmount);
                builder.append(this.entrustNo, obj.entrustNo);
                builder.append(this.entrustOc, obj.entrustOc);
                builder.append(this.entrustProp, obj.entrustProp);
                builder.append(this.entrustSrc, obj.entrustSrc);
                builder.append(this.entrustType, obj.entrustType);
                builder.append(this.exchangeType, obj.exchangeType);
                builder.append(this.initDate, obj.initDate);
                builder.append(this.joinReportNo, obj.joinReportNo);
                builder.append(this.optEntrustPrice, obj.optEntrustPrice);
                builder.append(this.optcombId, obj.optcombId);
                builder.append(this.optholdTypeStr, obj.optholdTypeStr);
                builder.append(this.optionCode, obj.optionCode);
                builder.append(this.optionCodeStr, obj.optionCodeStr);
                builder.append(this.orderId, obj.orderId);
                builder.append(this.positionStr, obj.positionStr);
                builder.append(this.reportAccount, obj.reportAccount);
                builder.append(this.reportBs, obj.reportBs);
                builder.append(this.reportCode, obj.reportCode);
                builder.append(this.reportNo, obj.reportNo);
                builder.append(this.seatNo, obj.seatNo);
                builder.append(this.selfReportAccount, obj.selfReportAccount);
                builder.append(this.selfSeatNo, obj.selfSeatNo);
                builder.append(this.stockCode, obj.stockCode);
                builder.append(this.origOrderId, obj.origOrderId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetEntrustPollingInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String enSeatNo = " ";
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String exchangeType = " ";
        @SinogramLength(
                min = 0,
                max = 100,
                charset = "utf-8"
        )
        private String positionStr = " ";
        private Integer requestNum = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character transplatType = ' ';
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String enEntrustProp = " ";
        @SinogramLength(
                min = 0,
                max = 4000,
                charset = "utf-8"
        )
        private String enBranchNo = " ";
        private Integer delayTime = 0;
        private Integer pollingAheadTime = 0;

        public GetEntrustPollingInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getEnSeatNo() {
            if (this.enSeatNo == null) {
                return " ";
            } else {
                return this.enSeatNo.isEmpty() ? " " : this.enSeatNo;
            }
        }

        public String getExchangeType() {
            if (this.exchangeType == null) {
                return " ";
            } else {
                return this.exchangeType.isEmpty() ? " " : this.exchangeType;
            }
        }

        public String getPositionStr() {
            if (this.positionStr == null) {
                return " ";
            } else {
                return this.positionStr.isEmpty() ? " " : this.positionStr;
            }
        }

        public Integer getRequestNum() {
            return this.requestNum != null ? this.requestNum : 0;
        }

        public Character getTransplatType() {
            return this.transplatType != null ? this.transplatType : ' ';
        }

        public String getEnEntrustProp() {
            if (this.enEntrustProp == null) {
                return " ";
            } else {
                return this.enEntrustProp.isEmpty() ? " " : this.enEntrustProp;
            }
        }

        public String getEnBranchNo() {
            if (this.enBranchNo == null) {
                return " ";
            } else {
                return this.enBranchNo.isEmpty() ? " " : this.enBranchNo;
            }
        }

        public Integer getDelayTime() {
            return this.delayTime != null ? this.delayTime : 0;
        }

        public Integer getPollingAheadTime() {
            return this.pollingAheadTime != null ? this.pollingAheadTime : 0;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setEnSeatNo(String enSeatNo) {
            this.enSeatNo = enSeatNo;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public void setPositionStr(String positionStr) {
            this.positionStr = positionStr;
        }

        public void setRequestNum(Integer requestNum) {
            this.requestNum = requestNum;
        }

        public void setTransplatType(Character transplatType) {
            this.transplatType = transplatType;
        }

        public void setEnEntrustProp(String enEntrustProp) {
            this.enEntrustProp = enEntrustProp;
        }

        public void setEnBranchNo(String enBranchNo) {
            this.enBranchNo = enBranchNo;
        }

        public void setDelayTime(Integer delayTime) {
            this.delayTime = delayTime;
        }

        public void setPollingAheadTime(Integer pollingAheadTime) {
            this.pollingAheadTime = pollingAheadTime;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetEntrustPollingInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",enSeatNo:" + this.enSeatNo);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(",positionStr:" + this.positionStr);
            buffer.append(",requestNum:" + this.requestNum);
            buffer.append(",transplatType:" + this.transplatType);
            buffer.append(",enEntrustProp:" + this.enEntrustProp);
            buffer.append(",enBranchNo:" + this.enBranchNo);
            buffer.append(",delayTime:" + this.delayTime);
            buffer.append(",pollingAheadTime:" + this.pollingAheadTime);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.enSeatNo);
            builder.append(this.exchangeType);
            builder.append(this.positionStr);
            builder.append(this.requestNum);
            builder.append(this.transplatType);
            builder.append(this.enEntrustProp);
            builder.append(this.enBranchNo);
            builder.append(this.delayTime);
            builder.append(this.pollingAheadTime);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.GetEntrustPollingInnerInput obj) {
            if (obj instanceof InnerOptService.GetEntrustPollingInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, obj.opPassword);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.enSeatNo, obj.enSeatNo);
                builder.append(this.exchangeType, obj.exchangeType);
                builder.append(this.positionStr, obj.positionStr);
                builder.append(this.requestNum, obj.requestNum);
                builder.append(this.transplatType, obj.transplatType);
                builder.append(this.enEntrustProp, obj.enEntrustProp);
                builder.append(this.enBranchNo, obj.enBranchNo);
                builder.append(this.delayTime, obj.delayTime);
                builder.append(this.pollingAheadTime, obj.pollingAheadTime);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetDcfundrealAccountInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String fundAccount = " ";

        public GetDcfundrealAccountInnerOutput() {
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetDcfundrealAccountInnerOutput:(");
            buffer.append("fundAccount:" + this.fundAccount);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.fundAccount);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.GetDcfundrealAccountInnerOutput obj) {
            if (obj instanceof InnerOptService.GetDcfundrealAccountInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.fundAccount, obj.fundAccount);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetDcfundrealAccountInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";

        public GetDcfundrealAccountInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetDcfundrealAccountInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.GetDcfundrealAccountInnerInput obj) {
            if (obj instanceof InnerOptService.GetDcfundrealAccountInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, obj.opPassword);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetDayinitinfoOptArgInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer initDate = 0;
        private Integer initModel = 0;

        public GetDayinitinfoOptArgInnerOutput() {
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public Integer getInitModel() {
            return this.initModel != null ? this.initModel : 0;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public void setInitModel(Integer initModel) {
            this.initModel = initModel;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetDayinitinfoOptArgInnerOutput:(");
            buffer.append("initDate:" + this.initDate);
            buffer.append(",initModel:" + this.initModel);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.initDate);
            builder.append(this.initModel);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.GetDayinitinfoOptArgInnerOutput obj) {
            if (obj instanceof InnerOptService.GetDayinitinfoOptArgInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.initDate, obj.initDate);
                builder.append(this.initModel, obj.initModel);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetDayinitinfoOptArgInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";

        public GetDayinitinfoOptArgInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetDayinitinfoOptArgInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.GetDayinitinfoOptArgInnerInput obj) {
            if (obj instanceof InnerOptService.GetDayinitinfoOptArgInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, obj.opPassword);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetCoveredstockInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer total = 0;
        private Integer currentPage = 0;
        private List<InnerOptService.CoveredstockDTO> coverstockClob;

        public GetCoveredstockInnerOutput() {
        }

        public Integer getTotal() {
            return this.total != null ? this.total : 0;
        }

        public Integer getCurrentPage() {
            return this.currentPage != null ? this.currentPage : 0;
        }

        public List<InnerOptService.CoveredstockDTO> getCoverstockClob() {
            return this.coverstockClob;
        }

        public void setTotal(Integer total) {
            this.total = total;
        }

        public void setCurrentPage(Integer currentPage) {
            this.currentPage = currentPage;
        }

        public void setCoverstockClob(List<InnerOptService.CoveredstockDTO> coverstockClob) {
            this.coverstockClob = coverstockClob;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetCoveredstockInnerOutput:(");
            buffer.append("total:" + this.total);
            buffer.append(",currentPage:" + this.currentPage);
            buffer.append(",coverstockClob:" + this.coverstockClob);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.total);
            builder.append(this.currentPage);
            builder.append(this.coverstockClob);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.GetCoveredstockInnerOutput obj) {
            if (obj instanceof InnerOptService.GetCoveredstockInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.total, obj.total);
                builder.append(this.currentPage, obj.currentPage);
                builder.append(this.coverstockClob, obj.coverstockClob);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetCoveredstockInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fundAccount = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String clientId = " ";
        @SinogramLength(
                min = 0,
                max = 20,
                charset = "utf-8"
        )
        private String stockAccount = " ";
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String enExchangeType = " ";
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String enStockType = " ";
        @SinogramLength(
                min = 0,
                max = 8,
                charset = "utf-8"
        )
        private String stockCode = " ";
        private Integer pageNo = 0;
        private Integer pageSize = 0;

        public GetCoveredstockInnerInput() {
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getStockAccount() {
            if (this.stockAccount == null) {
                return " ";
            } else {
                return this.stockAccount.isEmpty() ? " " : this.stockAccount;
            }
        }

        public String getEnExchangeType() {
            if (this.enExchangeType == null) {
                return " ";
            } else {
                return this.enExchangeType.isEmpty() ? " " : this.enExchangeType;
            }
        }

        public String getEnStockType() {
            if (this.enStockType == null) {
                return " ";
            } else {
                return this.enStockType.isEmpty() ? " " : this.enStockType;
            }
        }

        public String getStockCode() {
            if (this.stockCode == null) {
                return " ";
            } else {
                return this.stockCode.isEmpty() ? " " : this.stockCode;
            }
        }

        public Integer getPageNo() {
            return this.pageNo != null ? this.pageNo : 0;
        }

        public Integer getPageSize() {
            return this.pageSize != null ? this.pageSize : 0;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setStockAccount(String stockAccount) {
            this.stockAccount = stockAccount;
        }

        public void setEnExchangeType(String enExchangeType) {
            this.enExchangeType = enExchangeType;
        }

        public void setEnStockType(String enStockType) {
            this.enStockType = enStockType;
        }

        public void setStockCode(String stockCode) {
            this.stockCode = stockCode;
        }

        public void setPageNo(Integer pageNo) {
            this.pageNo = pageNo;
        }

        public void setPageSize(Integer pageSize) {
            this.pageSize = pageSize;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetCoveredstockInnerInput:(");
            buffer.append("fundAccount:" + this.fundAccount);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",stockAccount:" + this.stockAccount);
            buffer.append(",enExchangeType:" + this.enExchangeType);
            buffer.append(",enStockType:" + this.enStockType);
            buffer.append(",stockCode:" + this.stockCode);
            buffer.append(",pageNo:" + this.pageNo);
            buffer.append(",pageSize:" + this.pageSize);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.fundAccount);
            builder.append(this.clientId);
            builder.append(this.stockAccount);
            builder.append(this.enExchangeType);
            builder.append(this.enStockType);
            builder.append(this.stockCode);
            builder.append(this.pageNo);
            builder.append(this.pageSize);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.GetCoveredstockInnerInput obj) {
            if (obj instanceof InnerOptService.GetCoveredstockInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.fundAccount, obj.fundAccount);
                builder.append(this.clientId, obj.clientId);
                builder.append(this.stockAccount, obj.stockAccount);
                builder.append(this.enExchangeType, obj.enExchangeType);
                builder.append(this.enStockType, obj.enStockType);
                builder.append(this.stockCode, obj.stockCode);
                builder.append(this.pageNo, obj.pageNo);
                builder.append(this.pageSize, obj.pageSize);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetCombholdrealjourdayendFundaccountInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String fundAccount = " ";

        public GetCombholdrealjourdayendFundaccountInnerOutput() {
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetCombholdrealjourdayendFundaccountInnerOutput:(");
            buffer.append("fundAccount:" + this.fundAccount);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.fundAccount);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.GetCombholdrealjourdayendFundaccountInnerOutput obj) {
            if (obj instanceof InnerOptService.GetCombholdrealjourdayendFundaccountInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.fundAccount, obj.fundAccount);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetCombholdrealjourdayendFundaccountInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";

        public GetCombholdrealjourdayendFundaccountInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetCombholdrealjourdayendFundaccountInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.GetCombholdrealjourdayendFundaccountInnerInput obj) {
            if (obj instanceof InnerOptService.GetCombholdrealjourdayendFundaccountInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, obj.opPassword);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetCombholdrealjourdayendDataInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String clientId = " ";
        private String fundAccount = " ";
        private String stockAccount = " ";
        private String exchangeType = " ";
        private String optcombId = " ";
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double enableAmount = 0.0D;
        @JsonSerialize(
                using = LongJsonSerializer.class
        )
        @JsonDeserialize(
                using = LongJsonDeserializer.class
        )
        private Long serialNo = 0L;

        public GetCombholdrealjourdayendDataInnerOutput() {
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getStockAccount() {
            if (this.stockAccount == null) {
                return " ";
            } else {
                return this.stockAccount.isEmpty() ? " " : this.stockAccount;
            }
        }

        public String getExchangeType() {
            if (this.exchangeType == null) {
                return " ";
            } else {
                return this.exchangeType.isEmpty() ? " " : this.exchangeType;
            }
        }

        public String getOptcombId() {
            if (this.optcombId == null) {
                return " ";
            } else {
                return this.optcombId.isEmpty() ? " " : this.optcombId;
            }
        }

        public Double getEnableAmount() {
            return this.enableAmount != null ? this.enableAmount : 0.0D;
        }

        public Long getSerialNo() {
            return this.serialNo != null ? this.serialNo : 0L;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setStockAccount(String stockAccount) {
            this.stockAccount = stockAccount;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public void setOptcombId(String optcombId) {
            this.optcombId = optcombId;
        }

        public void setEnableAmount(Double enableAmount) {
            this.enableAmount = enableAmount;
        }

        public void setSerialNo(Long serialNo) {
            this.serialNo = serialNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetCombholdrealjourdayendDataInnerOutput:(");
            buffer.append("clientId:" + this.clientId);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",stockAccount:" + this.stockAccount);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(",optcombId:" + this.optcombId);
            buffer.append(",enableAmount:" + this.enableAmount);
            buffer.append(",serialNo:" + this.serialNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.clientId);
            builder.append(this.fundAccount);
            builder.append(this.stockAccount);
            builder.append(this.exchangeType);
            builder.append(this.optcombId);
            builder.append(this.enableAmount);
            builder.append(this.serialNo);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.GetCombholdrealjourdayendDataInnerOutput obj) {
            if (obj instanceof InnerOptService.GetCombholdrealjourdayendDataInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.clientId, obj.clientId);
                builder.append(this.fundAccount, obj.fundAccount);
                builder.append(this.stockAccount, obj.stockAccount);
                builder.append(this.exchangeType, obj.exchangeType);
                builder.append(this.optcombId, obj.optcombId);
                builder.append(this.enableAmount, obj.enableAmount);
                builder.append(this.serialNo, obj.serialNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetCombholdrealjourdayendDataInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        private Integer initDate = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fundAccountStart = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fundAccountEnd = " ";

        public GetCombholdrealjourdayendDataInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public String getFundAccountStart() {
            if (this.fundAccountStart == null) {
                return " ";
            } else {
                return this.fundAccountStart.isEmpty() ? " " : this.fundAccountStart;
            }
        }

        public String getFundAccountEnd() {
            if (this.fundAccountEnd == null) {
                return " ";
            } else {
                return this.fundAccountEnd.isEmpty() ? " " : this.fundAccountEnd;
            }
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public void setFundAccountStart(String fundAccountStart) {
            this.fundAccountStart = fundAccountStart;
        }

        public void setFundAccountEnd(String fundAccountEnd) {
            this.fundAccountEnd = fundAccountEnd;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetCombholdrealjourdayendDataInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",initDate:" + this.initDate);
            buffer.append(",fundAccountStart:" + this.fundAccountStart);
            buffer.append(",fundAccountEnd:" + this.fundAccountEnd);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.initDate);
            builder.append(this.fundAccountStart);
            builder.append(this.fundAccountEnd);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.GetCombholdrealjourdayendDataInnerInput obj) {
            if (obj instanceof InnerOptService.GetCombholdrealjourdayendDataInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, obj.opPassword);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.initDate, obj.initDate);
                builder.append(this.fundAccountStart, obj.fundAccountStart);
                builder.append(this.fundAccountEnd, obj.fundAccountEnd);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetCodeInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer total = 0;
        private Integer currentPage = 0;
        private List<InnerOptService.CodeDTO> rows;

        public GetCodeInnerOutput() {
        }

        public Integer getTotal() {
            return this.total != null ? this.total : 0;
        }

        public Integer getCurrentPage() {
            return this.currentPage != null ? this.currentPage : 0;
        }

        public List<InnerOptService.CodeDTO> getRows() {
            return this.rows;
        }

        public void setTotal(Integer total) {
            this.total = total;
        }

        public void setCurrentPage(Integer currentPage) {
            this.currentPage = currentPage;
        }

        public void setRows(List<InnerOptService.CodeDTO> rows) {
            this.rows = rows;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetCodeInnerOutput:(");
            buffer.append("total:" + this.total);
            buffer.append(",currentPage:" + this.currentPage);
            buffer.append(",rows:" + this.rows);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.total);
            builder.append(this.currentPage);
            builder.append(this.rows);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.GetCodeInnerOutput obj) {
            if (obj instanceof InnerOptService.GetCodeInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.total, obj.total);
                builder.append(this.currentPage, obj.currentPage);
                builder.append(this.rows, obj.rows);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetCodeInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String exchangeType = " ";
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String stockType = " ";
        @SinogramLength(
                min = 0,
                max = 8,
                charset = "utf-8"
        )
        private String stockCode = " ";
        @SinogramLength(
                min = 0,
                max = 8,
                charset = "utf-8"
        )
        private String optionCode = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character optionType = ' ';
        private Integer requestNum = 0;
        private Integer pageNo = 0;
        private Integer pageSize = 0;

        public GetCodeInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getExchangeType() {
            if (this.exchangeType == null) {
                return " ";
            } else {
                return this.exchangeType.isEmpty() ? " " : this.exchangeType;
            }
        }

        public String getStockType() {
            if (this.stockType == null) {
                return " ";
            } else {
                return this.stockType.isEmpty() ? " " : this.stockType;
            }
        }

        public String getStockCode() {
            if (this.stockCode == null) {
                return " ";
            } else {
                return this.stockCode.isEmpty() ? " " : this.stockCode;
            }
        }

        public String getOptionCode() {
            if (this.optionCode == null) {
                return " ";
            } else {
                return this.optionCode.isEmpty() ? " " : this.optionCode;
            }
        }

        public Character getOptionType() {
            return this.optionType != null ? this.optionType : ' ';
        }

        public Integer getRequestNum() {
            return this.requestNum != null ? this.requestNum : 0;
        }

        public Integer getPageNo() {
            return this.pageNo != null ? this.pageNo : 0;
        }

        public Integer getPageSize() {
            return this.pageSize != null ? this.pageSize : 0;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public void setStockType(String stockType) {
            this.stockType = stockType;
        }

        public void setStockCode(String stockCode) {
            this.stockCode = stockCode;
        }

        public void setOptionCode(String optionCode) {
            this.optionCode = optionCode;
        }

        public void setOptionType(Character optionType) {
            this.optionType = optionType;
        }

        public void setRequestNum(Integer requestNum) {
            this.requestNum = requestNum;
        }

        public void setPageNo(Integer pageNo) {
            this.pageNo = pageNo;
        }

        public void setPageSize(Integer pageSize) {
            this.pageSize = pageSize;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetCodeInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(",stockType:" + this.stockType);
            buffer.append(",stockCode:" + this.stockCode);
            buffer.append(",optionCode:" + this.optionCode);
            buffer.append(",optionType:" + this.optionType);
            buffer.append(",requestNum:" + this.requestNum);
            buffer.append(",pageNo:" + this.pageNo);
            buffer.append(",pageSize:" + this.pageSize);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.exchangeType);
            builder.append(this.stockType);
            builder.append(this.stockCode);
            builder.append(this.optionCode);
            builder.append(this.optionType);
            builder.append(this.requestNum);
            builder.append(this.pageNo);
            builder.append(this.pageSize);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.GetCodeInnerInput obj) {
            if (obj instanceof InnerOptService.GetCodeInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, obj.opPassword);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.exchangeType, obj.exchangeType);
                builder.append(this.stockType, obj.stockType);
                builder.append(this.stockCode, obj.stockCode);
                builder.append(this.optionCode, obj.optionCode);
                builder.append(this.optionType, obj.optionType);
                builder.append(this.requestNum, obj.requestNum);
                builder.append(this.pageNo, obj.pageNo);
                builder.append(this.pageSize, obj.pageSize);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetArgInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer initDate = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character sysStatus = ' ';
        private String sysName = " ";

        public GetArgInnerOutput() {
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public Character getSysStatus() {
            return this.sysStatus != null ? this.sysStatus : ' ';
        }

        public String getSysName() {
            if (this.sysName == null) {
                return " ";
            } else {
                return this.sysName.isEmpty() ? " " : this.sysName;
            }
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public void setSysStatus(Character sysStatus) {
            this.sysStatus = sysStatus;
        }

        public void setSysName(String sysName) {
            this.sysName = sysName;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetArgInnerOutput:(");
            buffer.append("initDate:" + this.initDate);
            buffer.append(",sysStatus:" + this.sysStatus);
            buffer.append(",sysName:" + this.sysName);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.initDate);
            builder.append(this.sysStatus);
            builder.append(this.sysName);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.GetArgInnerOutput obj) {
            if (obj instanceof InnerOptService.GetArgInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.initDate, obj.initDate);
                builder.append(this.sysStatus, obj.sysStatus);
                builder.append(this.sysName, obj.sysName);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetArgInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";

        public GetArgInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetArgInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.GetArgInnerInput obj) {
            if (obj instanceof InnerOptService.GetArgInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, obj.opPassword);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class DeleteExchangeclientinfoCancelInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String fundAccount;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId;
        @SinogramLength(
                min = 1,
                max = 4,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String exchangeType;
        @SinogramLength(
                min = 1,
                max = 20,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String stockAccount;

        public DeleteExchangeclientinfoCancelInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getFundAccount() {
            return this.fundAccount;
        }

        public String getClientId() {
            return this.clientId;
        }

        public String getExchangeType() {
            return this.exchangeType;
        }

        public String getStockAccount() {
            return this.stockAccount;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public void setStockAccount(String stockAccount) {
            this.stockAccount = stockAccount;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("DeleteExchangeclientinfoCancelInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(",stockAccount:" + this.stockAccount);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.fundAccount);
            builder.append(this.clientId);
            builder.append(this.exchangeType);
            builder.append(this.stockAccount);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.DeleteExchangeclientinfoCancelInnerInput obj) {
            if (obj instanceof InnerOptService.DeleteExchangeclientinfoCancelInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, obj.opPassword);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.fundAccount, obj.fundAccount);
                builder.append(this.clientId, obj.clientId);
                builder.append(this.exchangeType, obj.exchangeType);
                builder.append(this.stockAccount, obj.stockAccount);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class DeleteDcfundrealRollbackInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        private Integer initDate = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fundAccountStart = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fundAccountEnd = " ";

        public DeleteDcfundrealRollbackInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public String getFundAccountStart() {
            if (this.fundAccountStart == null) {
                return " ";
            } else {
                return this.fundAccountStart.isEmpty() ? " " : this.fundAccountStart;
            }
        }

        public String getFundAccountEnd() {
            if (this.fundAccountEnd == null) {
                return " ";
            } else {
                return this.fundAccountEnd.isEmpty() ? " " : this.fundAccountEnd;
            }
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public void setFundAccountStart(String fundAccountStart) {
            this.fundAccountStart = fundAccountStart;
        }

        public void setFundAccountEnd(String fundAccountEnd) {
            this.fundAccountEnd = fundAccountEnd;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("DeleteDcfundrealRollbackInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",initDate:" + this.initDate);
            buffer.append(",fundAccountStart:" + this.fundAccountStart);
            buffer.append(",fundAccountEnd:" + this.fundAccountEnd);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.initDate);
            builder.append(this.fundAccountStart);
            builder.append(this.fundAccountEnd);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.DeleteDcfundrealRollbackInnerInput obj) {
            if (obj instanceof InnerOptService.DeleteDcfundrealRollbackInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, obj.opPassword);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.initDate, obj.initDate);
                builder.append(this.fundAccountStart, obj.fundAccountStart);
                builder.append(this.fundAccountEnd, obj.fundAccountEnd);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class DeleteDayinitinfoDataholdInitInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer initDate = 0;

        public DeleteDayinitinfoDataholdInitInnerOutput() {
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("DeleteDayinitinfoDataholdInitInnerOutput:(");
            buffer.append("initDate:" + this.initDate);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.initDate);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.DeleteDayinitinfoDataholdInitInnerOutput obj) {
            if (obj instanceof InnerOptService.DeleteDayinitinfoDataholdInitInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.initDate, obj.initDate);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class DeleteDayinitinfoDataholdInitInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";

        public DeleteDayinitinfoDataholdInitInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("DeleteDayinitinfoDataholdInitInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.DeleteDayinitinfoDataholdInitInnerInput obj) {
            if (obj instanceof InnerOptService.DeleteDayinitinfoDataholdInitInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, obj.opPassword);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class DeleteDayinitinfoDataInitInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer initDate = 0;

        public DeleteDayinitinfoDataInitInnerOutput() {
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("DeleteDayinitinfoDataInitInnerOutput:(");
            buffer.append("initDate:" + this.initDate);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.initDate);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.DeleteDayinitinfoDataInitInnerOutput obj) {
            if (obj instanceof InnerOptService.DeleteDayinitinfoDataInitInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.initDate, obj.initDate);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class DeleteDayinitinfoDataInitInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";

        public DeleteDayinitinfoDataInitInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("DeleteDayinitinfoDataInitInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            return builder.toHashCode();
        }

        public boolean equals(InnerOptService.DeleteDayinitinfoDataInitInnerInput obj) {
            if (obj instanceof InnerOptService.DeleteDayinitinfoDataInitInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, obj.opPassword);
                builder.append(this.opStation, obj.opStation);
                builder.append(this.opEntrustWay, obj.opEntrustWay);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.operatorNo, obj.operatorNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }
}
