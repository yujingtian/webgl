//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.hundsun.xone.iic.pub.service;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.hundsun.broker.base.PublicChecker.PublicParams;
import com.hundsun.broker.base.databind.CharacterJsonDeserializer;
import com.hundsun.jrescloud.rpc.annotation.CloudFunction;
import com.hundsun.jrescloud.rpc.annotation.CloudService;
import com.hundsun.jrescloud.rpc.def.validation.SinogramLength;
import java.io.Serializable;
import java.util.List;
import javax.validation.constraints.NotNull;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

@CloudService(
        validation = true,
        validationNull = false,
        application = "hsxone.iic"
)
public interface InnerIicService {
    @CloudFunction(
            value = "iic.deleteActAlreadyExistMapperInner",
            desc = "删除映射账户关系数据",
            apiUrl = "/deleteActAlreadyExistMapperInner"
    )
    void deleteActAlreadyExistMapperInner(InnerIicService.DeleteActAlreadyExistMapperInnerInput var1);

    @CloudFunction(
            value = "iic.deleteAuthuserctrlAutoUnlockInner",
            desc = "认证用户自动解锁",
            apiUrl = "/deleteAuthuserctrlAutoUnlockInner"
    )
    void deleteAuthuserctrlAutoUnlockInner(InnerIicService.DeleteAuthuserctrlAutoUnlockInnerInput var1);

    @CloudFunction(
            value = "iic.deleteAuthusertransInner",
            desc = "认证用户关联信息删除",
            apiUrl = "/deleteAuthusertransInner"
    )
    InnerIicService.DeleteAuthusertransInnerOutput deleteAuthusertransInner(InnerIicService.DeleteAuthusertransInnerInput var1);

    @CloudFunction(
            value = "iic.deleteAuthvaskeyInner",
            desc = "认证共享密钥过期删除",
            apiUrl = "/deleteAuthvaskeyInner"
    )
    void deleteAuthvaskeyInner(InnerIicService.DeleteAuthvaskeyInnerInput var1);

    @CloudFunction(
            value = "iic.deleteCachedAuthuserMapperInner",
            desc = "删除认证用户信息",
            apiUrl = "/deleteCachedAuthuserMapperInner"
    )
    InnerIicService.DeleteCachedAuthuserMapperInnerOutput deleteCachedAuthuserMapperInner(InnerIicService.DeleteCachedAuthuserMapperInnerInput var1);

    @CloudFunction(
            value = "iic.deleteDayinitinfoDataInitInner",
            desc = "认证中心初始化表",
            apiUrl = "/deleteDayinitinfoDataInitInner"
    )
    InnerIicService.DeleteDayinitinfoDataInitInnerOutput deleteDayinitinfoDataInitInner(InnerIicService.DeleteDayinitinfoDataInitInnerInput var1);

    @CloudFunction(
            value = "iic.deleteHistoryLogJourInner",
            desc = "日志流水归档",
            apiUrl = "/deleteHistoryLogJourInner"
    )
    InnerIicService.DeleteHistoryLogJourInnerOutput deleteHistoryLogJourInner(InnerIicService.DeleteHistoryLogJourInnerInput var1);

    @CloudFunction(
            value = "iic.getAuthuserCheckPasswordInner",
            desc = "认证用户密码校验",
            apiUrl = "/getAuthuserCheckPasswordInner"
    )
    void getAuthuserCheckPasswordInner(InnerIicService.GetAuthuserCheckPasswordInnerInput var1);

    @CloudFunction(
            value = "iic.getAuthuserCustIdInner",
            desc = "获取客户标识",
            apiUrl = "/getAuthuserCustIdInner"
    )
    InnerIicService.GetAuthuserCustIdInnerOutput getAuthuserCustIdInner(InnerIicService.GetAuthuserCustIdInnerInput var1);

    @CloudFunction(
            value = "iic.getAuthuserctrlPasswordErrorsInner",
            desc = "认证用户密码错误次数查询",
            apiUrl = "/getAuthuserctrlPasswordErrorsInner"
    )
    List<InnerIicService.GetAuthuserctrlPasswordErrorsInnerOutput> getAuthuserctrlPasswordErrorsInner(InnerIicService.GetAuthuserctrlPasswordErrorsInnerInput var1);

    @CloudFunction(
            value = "iic.getAuthvaskeyInner",
            desc = "认证共享密钥查询",
            apiUrl = "/getAuthvaskeyInner"
    )
    InnerIicService.GetAuthvaskeyInnerOutput getAuthvaskeyInner(InnerIicService.GetAuthvaskeyInnerInput var1);

    @CloudFunction(
            value = "iic.postAuthuserOpenInner",
            desc = "认证用户开户",
            apiUrl = "/postAuthuserOpenInner"
    )
    InnerIicService.PostAuthuserOpenInnerOutput postAuthuserOpenInner(InnerIicService.PostAuthuserOpenInnerInput var1);

    @CloudFunction(
            value = "iic.postAuthusertransInner",
            desc = "认证用户关联信息增加",
            apiUrl = "/postAuthusertransInner"
    )
    InnerIicService.PostAuthusertransInnerOutput postAuthusertransInner(InnerIicService.PostAuthusertransInnerInput var1);

    @CloudFunction(
            value = "iic.postAuthvaskeyInner",
            desc = "认证共享密钥生成",
            apiUrl = "/postAuthvaskeyInner"
    )
    void postAuthvaskeyInner(InnerIicService.PostAuthvaskeyInnerInput var1);

    @CloudFunction(
            value = "iic.postFullAuthuserActInfoSyncInner",
            desc = "全量同步认证用户账号信息",
            apiUrl = "/postFullAuthuserActInfoSyncInner"
    )
    InnerIicService.PostFullAuthuserActInfoSyncInnerOutput postFullAuthuserActInfoSyncInner(InnerIicService.PostFullAuthuserActInfoSyncInnerInput var1);

    @CloudFunction(
            value = "iic.postUfAuthuserOpenInner",
            desc = "2.0认证用户开户",
            apiUrl = "/postUfAuthuserOpenInner"
    )
    InnerIicService.PostUfAuthuserOpenInnerOutput postUfAuthuserOpenInner(InnerIicService.PostUfAuthuserOpenInnerInput var1);

    @CloudFunction(
            value = "iic.putAuthuserClientSignInner",
            desc = "认证用户一户通签约",
            apiUrl = "/putAuthuserClientSignInner"
    )
    InnerIicService.PutAuthuserClientSignInnerOutput putAuthuserClientSignInner(InnerIicService.PutAuthuserClientSignInnerInput var1);

    @CloudFunction(
            value = "iic.putAuthuserDoubleFactorInner",
            desc = "修改认证用户双因子类型",
            apiUrl = "/putAuthuserDoubleFactorInner"
    )
    InnerIicService.PutAuthuserDoubleFactorInnerOutput putAuthuserDoubleFactorInner(InnerIicService.PutAuthuserDoubleFactorInnerInput var1);

    @CloudFunction(
            value = "iic.putAuthuserInner",
            desc = "认证用户修改",
            apiUrl = "/putAuthuserInner"
    )
    InnerIicService.PutAuthuserInnerOutput putAuthuserInner(InnerIicService.PutAuthuserInnerInput var1);

    @CloudFunction(
            value = "iic.putAuthuserModifyPasswordInner",
            desc = "认证密码修改",
            apiUrl = "/putAuthuserModifyPasswordInner"
    )
    InnerIicService.PutAuthuserModifyPasswordInnerOutput putAuthuserModifyPasswordInner(InnerIicService.PutAuthuserModifyPasswordInnerInput var1);

    @CloudFunction(
            value = "iic.putAuthuserResetPasswordInner",
            desc = "认证密码重置",
            apiUrl = "/putAuthuserResetPasswordInner"
    )
    InnerIicService.PutAuthuserResetPasswordInnerOutput putAuthuserResetPasswordInner(InnerIicService.PutAuthuserResetPasswordInnerInput var1);

    @CloudFunction(
            value = "iic.putAuthuserctrlClearInner",
            desc = "认证用户密码错误次数清空",
            apiUrl = "/putAuthuserctrlClearInner"
    )
    void putAuthuserctrlClearInner(InnerIicService.PutAuthuserctrlClearInnerInput var1);

    @CloudFunction(
            value = "iic.putAuthusertransInner",
            desc = "认证用户关联信息修改",
            apiUrl = "/putAuthusertransInner"
    )
    InnerIicService.PutAuthusertransInnerOutput putAuthusertransInner(InnerIicService.PutAuthusertransInnerInput var1);

    @CloudFunction(
            value = "iic.putDayinitinfoDateChangeInner",
            desc = "认证中心初始化日期",
            apiUrl = "/putDayinitinfoDateChangeInner"
    )
    InnerIicService.PutDayinitinfoDateChangeInnerOutput putDayinitinfoDateChangeInner(InnerIicService.PutDayinitinfoDateChangeInnerInput var1);

    @CloudFunction(
            value = "iic.deleteAuthuserCacheInner",
            desc = "删除认证用户缓存",
            apiUrl = "/deleteAuthuserCacheInner"
    )
    InnerIicService.DeleteAuthuserCacheInnerOutput deleteAuthuserCacheInner(InnerIicService.DeleteAuthuserCacheInnerInput var1);

    @CloudFunction(
            value = "iic.getAuthuserTokenInner",
            desc = "构建认证用户票据",
            apiUrl = "/getAuthuserTokenInner"
    )
    InnerIicService.GetAuthuserTokenInnerOutput getAuthuserTokenInner(InnerIicService.GetAuthuserTokenInnerInput var1);

    public static class GetAuthuserTokenInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String tokenInfo;

        public GetAuthuserTokenInnerOutput() {
        }

        public String getTokenInfo() {
            return this.tokenInfo;
        }

        public void setTokenInfo(String tokenInfo) {
            this.tokenInfo = tokenInfo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetAuthuserTokenInnerOutput:(");
            buffer.append("tokenInfo:" + this.tokenInfo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.tokenInfo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerIicService.GetAuthuserTokenInnerOutput) {
                InnerIicService.GetAuthuserTokenInnerOutput test = (InnerIicService.GetAuthuserTokenInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.tokenInfo, test.tokenInfo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetAuthuserTokenInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @NotNull(
                message = "不能为空"
        )
        private Integer opBranchNo;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String operatorNo;
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay;
        @SinogramLength(
                min = 1,
                max = 32,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId;
        @SinogramLength(
                min = 1,
                max = 32,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String authId;
        @SinogramLength(
                min = 1,
                max = 32,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String ctKey;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character authType;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character encodeType;

        public GetAuthuserTokenInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo;
        }

        public String getOperatorNo() {
            return this.operatorNo;
        }

        public String getOpStation() {
            return this.opStation;
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay;
        }

        public String getClientId() {
            return this.clientId;
        }

        public String getAuthId() {
            return this.authId;
        }

        public String getCtKey() {
            return this.ctKey;
        }

        public Character getAuthType() {
            return this.authType;
        }

        public Character getEncodeType() {
            return this.encodeType;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setAuthId(String authId) {
            this.authId = authId;
        }

        public void setCtKey(String ctKey) {
            this.ctKey = ctKey;
        }

        public void setAuthType(Character authType) {
            this.authType = authType;
        }

        public void setEncodeType(Character encodeType) {
            this.encodeType = encodeType;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetAuthuserTokenInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",authId:" + this.authId);
            buffer.append(",ctKey:" + this.ctKey);
            buffer.append(",authType:" + this.authType);
            buffer.append(",encodeType:" + this.encodeType);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.clientId);
            builder.append(this.authId);
            builder.append(this.ctKey);
            builder.append(this.authType);
            builder.append(this.encodeType);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerIicService.GetAuthuserTokenInnerInput) {
                InnerIicService.GetAuthuserTokenInnerInput test = (InnerIicService.GetAuthuserTokenInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.clientId, test.clientId);
                builder.append(this.authId, test.authId);
                builder.append(this.ctKey, test.ctKey);
                builder.append(this.authType, test.authType);
                builder.append(this.encodeType, test.encodeType);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class DeleteAuthuserCacheInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Long serialNo;

        public DeleteAuthuserCacheInnerOutput() {
        }

        public Long getSerialNo() {
            return this.serialNo;
        }

        public void setSerialNo(Long serialNo) {
            this.serialNo = serialNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("DeleteAuthuserCacheInnerOutput:(");
            buffer.append("serialNo:" + this.serialNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.serialNo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerIicService.DeleteAuthuserCacheInnerOutput) {
                InnerIicService.DeleteAuthuserCacheInnerOutput test = (InnerIicService.DeleteAuthuserCacheInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.serialNo, test.serialNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class DeleteAuthuserCacheInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @NotNull(
                message = "不能为空"
        )
        private Integer opBranchNo;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String operatorNo;
        @SinogramLength(
                min = 1,
                max = 1024,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay;
        @NotNull(
                message = "不能为空"
        )
        private List<String> clientIdSrc;

        public DeleteAuthuserCacheInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo;
        }

        public String getOperatorNo() {
            return this.operatorNo;
        }

        public String getOpStation() {
            return this.opStation;
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay;
        }

        public List<String> getClientIdSrc() {
            return this.clientIdSrc;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setClientIdSrc(List<String> clientIdSrc) {
            this.clientIdSrc = clientIdSrc;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("DeleteAuthuserCacheInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",clientIdSrc:" + this.clientIdSrc);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.clientIdSrc);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerIicService.DeleteAuthuserCacheInnerInput) {
                InnerIicService.DeleteAuthuserCacheInnerInput test = (InnerIicService.DeleteAuthuserCacheInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.clientIdSrc, test.clientIdSrc);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class TransferDataDTO implements Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 180,
                charset = "utf-8"
        )
        private String tableName = " ";
        @SinogramLength(
                min = 0,
                max = 1,
                charset = "utf-8"
        )
        private String successFlag = " ";
        @SinogramLength(
                min = 0,
                max = 1,
                charset = "utf-8"
        )
        private String deleteFlag = " ";

        public TransferDataDTO() {
        }

        public String getTableName() {
            if (this.tableName == null) {
                return " ";
            } else {
                return this.tableName.isEmpty() ? " " : this.tableName;
            }
        }

        public String getSuccessFlag() {
            if (this.successFlag == null) {
                return " ";
            } else {
                return this.successFlag.isEmpty() ? " " : this.successFlag;
            }
        }

        public String getDeleteFlag() {
            if (this.deleteFlag == null) {
                return " ";
            } else {
                return this.deleteFlag.isEmpty() ? " " : this.deleteFlag;
            }
        }

        public void setTableName(String tableName) {
            this.tableName = tableName;
        }

        public void setSuccessFlag(String successFlag) {
            this.successFlag = successFlag;
        }

        public void setDeleteFlag(String deleteFlag) {
            this.deleteFlag = deleteFlag;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("TransferDataDTO:(");
            buffer.append("tableName:" + this.tableName);
            buffer.append(",successFlag:" + this.successFlag);
            buffer.append(",deleteFlag:" + this.deleteFlag);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.tableName);
            builder.append(this.successFlag);
            builder.append(this.deleteFlag);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerIicService.TransferDataDTO) {
                InnerIicService.TransferDataDTO test = (InnerIicService.TransferDataDTO)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.tableName, test.tableName);
                builder.append(this.successFlag, test.successFlag);
                builder.append(this.deleteFlag, test.deleteFlag);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutDayinitinfoDateChangeInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer initDate;

        public PutDayinitinfoDateChangeInnerOutput() {
        }

        public Integer getInitDate() {
            return this.initDate;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutDayinitinfoDateChangeInnerOutput:(");
            buffer.append("initDate:" + this.initDate);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.initDate);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerIicService.PutDayinitinfoDateChangeInnerOutput) {
                InnerIicService.PutDayinitinfoDateChangeInnerOutput test = (InnerIicService.PutDayinitinfoDateChangeInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.initDate, test.initDate);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutDayinitinfoDateChangeInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @NotNull(
                message = "不能为空"
        )
        private Integer opBranchNo;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String operatorNo;
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay;

        public PutDayinitinfoDateChangeInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo;
        }

        public String getOperatorNo() {
            return this.operatorNo;
        }

        public String getOpStation() {
            return this.opStation;
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutDayinitinfoDateChangeInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerIicService.PutDayinitinfoDateChangeInnerInput) {
                InnerIicService.PutDayinitinfoDateChangeInnerInput test = (InnerIicService.PutDayinitinfoDateChangeInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutAuthusertransInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String opRemark;
        private Long serialNo;

        public PutAuthusertransInnerOutput() {
        }

        public String getOpRemark() {
            return this.opRemark;
        }

        public Long getSerialNo() {
            return this.serialNo;
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public void setSerialNo(Long serialNo) {
            this.serialNo = serialNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutAuthusertransInnerOutput:(");
            buffer.append("opRemark:" + this.opRemark);
            buffer.append(",serialNo:" + this.serialNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opRemark);
            builder.append(this.serialNo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerIicService.PutAuthusertransInnerOutput) {
                InnerIicService.PutAuthusertransInnerOutput test = (InnerIicService.PutAuthusertransInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opRemark, test.opRemark);
                builder.append(this.serialNo, test.serialNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutAuthusertransInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @NotNull(
                message = "不能为空"
        )
        private Integer opBranchNo;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String operatorNo;
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay;
        @SinogramLength(
                min = 1,
                max = 32,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String authId;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character authType;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character auxiAcctType;
        @SinogramLength(
                min = 1,
                max = 64,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String auxiLoginAcct;
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String remark;
        @SinogramLength(
                min = 1,
                max = 100,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String tradePassword;
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String auxiAcctAssistant;

        public PutAuthusertransInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo;
        }

        public String getOperatorNo() {
            return this.operatorNo;
        }

        public String getOpStation() {
            return this.opStation;
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay;
        }

        public String getAuthId() {
            return this.authId;
        }

        public Character getAuthType() {
            return this.authType;
        }

        public Character getAuxiAcctType() {
            return this.auxiAcctType;
        }

        public String getAuxiLoginAcct() {
            return this.auxiLoginAcct;
        }

        public String getRemark() {
            return this.remark;
        }

        public String getTradePassword() {
            return this.tradePassword;
        }

        public String getAuxiAcctAssistant() {
            return this.auxiAcctAssistant;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setAuthId(String authId) {
            this.authId = authId;
        }

        public void setAuthType(Character authType) {
            this.authType = authType;
        }

        public void setAuxiAcctType(Character auxiAcctType) {
            this.auxiAcctType = auxiAcctType;
        }

        public void setAuxiLoginAcct(String auxiLoginAcct) {
            this.auxiLoginAcct = auxiLoginAcct;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public void setTradePassword(String tradePassword) {
            this.tradePassword = tradePassword;
        }

        public void setAuxiAcctAssistant(String auxiAcctAssistant) {
            this.auxiAcctAssistant = auxiAcctAssistant;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutAuthusertransInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",authId:" + this.authId);
            buffer.append(",authType:" + this.authType);
            buffer.append(",auxiAcctType:" + this.auxiAcctType);
            buffer.append(",auxiLoginAcct:" + this.auxiLoginAcct);
            buffer.append(",remark:" + this.remark);
            buffer.append(",tradePassword:" + this.tradePassword);
            buffer.append(",auxiAcctAssistant:" + this.auxiAcctAssistant);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.authId);
            builder.append(this.authType);
            builder.append(this.auxiAcctType);
            builder.append(this.auxiLoginAcct);
            builder.append(this.remark);
            builder.append(this.tradePassword);
            builder.append(this.auxiAcctAssistant);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerIicService.PutAuthusertransInnerInput) {
                InnerIicService.PutAuthusertransInnerInput test = (InnerIicService.PutAuthusertransInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.authId, test.authId);
                builder.append(this.authType, test.authType);
                builder.append(this.auxiAcctType, test.auxiAcctType);
                builder.append(this.auxiLoginAcct, test.auxiLoginAcct);
                builder.append(this.remark, test.remark);
                builder.append(this.tradePassword, test.tradePassword);
                builder.append(this.auxiAcctAssistant, test.auxiAcctAssistant);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutAuthuserctrlClearInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @NotNull(
                message = "不能为空"
        )
        private Integer opBranchNo;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String operatorNo;
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay;
        @SinogramLength(
                min = 1,
                max = 32,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String authId;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character authType;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character unlockSyncFlag;

        public PutAuthuserctrlClearInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo;
        }

        public String getOperatorNo() {
            return this.operatorNo;
        }

        public String getOpStation() {
            return this.opStation;
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay;
        }

        public String getAuthId() {
            return this.authId;
        }

        public Character getAuthType() {
            return this.authType;
        }

        public Character getUnlockSyncFlag() {
            return this.unlockSyncFlag;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setAuthId(String authId) {
            this.authId = authId;
        }

        public void setAuthType(Character authType) {
            this.authType = authType;
        }

        public void setUnlockSyncFlag(Character unlockSyncFlag) {
            this.unlockSyncFlag = unlockSyncFlag;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutAuthuserctrlClearInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",authId:" + this.authId);
            buffer.append(",authType:" + this.authType);
            buffer.append(",unlockSyncFlag:" + this.unlockSyncFlag);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.authId);
            builder.append(this.authType);
            builder.append(this.unlockSyncFlag);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerIicService.PutAuthuserctrlClearInnerInput) {
                InnerIicService.PutAuthuserctrlClearInnerInput test = (InnerIicService.PutAuthuserctrlClearInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.authId, test.authId);
                builder.append(this.authType, test.authType);
                builder.append(this.unlockSyncFlag, test.unlockSyncFlag);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutAuthuserResetPasswordInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String opRemark;
        private Long serialNo;

        public PutAuthuserResetPasswordInnerOutput() {
        }

        public String getOpRemark() {
            return this.opRemark;
        }

        public Long getSerialNo() {
            return this.serialNo;
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public void setSerialNo(Long serialNo) {
            this.serialNo = serialNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutAuthuserResetPasswordInnerOutput:(");
            buffer.append("opRemark:" + this.opRemark);
            buffer.append(",serialNo:" + this.serialNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opRemark);
            builder.append(this.serialNo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerIicService.PutAuthuserResetPasswordInnerOutput) {
                InnerIicService.PutAuthuserResetPasswordInnerOutput test = (InnerIicService.PutAuthuserResetPasswordInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opRemark, test.opRemark);
                builder.append(this.serialNo, test.serialNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutAuthuserResetPasswordInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @NotNull(
                message = "不能为空"
        )
        private Integer opBranchNo;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String operatorNo;
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay;
        @SinogramLength(
                min = 1,
                max = 32,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String authId;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character authType;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId;
        @SinogramLength(
                min = 1,
                max = 64,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String newPassword;
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String remark;

        public PutAuthuserResetPasswordInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo;
        }

        public String getOperatorNo() {
            return this.operatorNo;
        }

        public String getOpStation() {
            return this.opStation;
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay;
        }

        public String getAuthId() {
            return this.authId;
        }

        public Character getAuthType() {
            return this.authType;
        }

        public String getClientId() {
            return this.clientId;
        }

        public String getNewPassword() {
            return this.newPassword;
        }

        public String getRemark() {
            return this.remark;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setAuthId(String authId) {
            this.authId = authId;
        }

        public void setAuthType(Character authType) {
            this.authType = authType;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setNewPassword(String newPassword) {
            this.newPassword = newPassword;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutAuthuserResetPasswordInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",authId:" + this.authId);
            buffer.append(",authType:" + this.authType);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",newPassword:" + this.newPassword);
            buffer.append(",remark:" + this.remark);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.authId);
            builder.append(this.authType);
            builder.append(this.clientId);
            builder.append(this.newPassword);
            builder.append(this.remark);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerIicService.PutAuthuserResetPasswordInnerInput) {
                InnerIicService.PutAuthuserResetPasswordInnerInput test = (InnerIicService.PutAuthuserResetPasswordInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.authId, test.authId);
                builder.append(this.authType, test.authType);
                builder.append(this.clientId, test.clientId);
                builder.append(this.newPassword, test.newPassword);
                builder.append(this.remark, test.remark);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutAuthuserModifyPasswordInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String opRemark;
        private Long serialNo;

        public PutAuthuserModifyPasswordInnerOutput() {
        }

        public String getOpRemark() {
            return this.opRemark;
        }

        public Long getSerialNo() {
            return this.serialNo;
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public void setSerialNo(Long serialNo) {
            this.serialNo = serialNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutAuthuserModifyPasswordInnerOutput:(");
            buffer.append("opRemark:" + this.opRemark);
            buffer.append(",serialNo:" + this.serialNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opRemark);
            builder.append(this.serialNo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerIicService.PutAuthuserModifyPasswordInnerOutput) {
                InnerIicService.PutAuthuserModifyPasswordInnerOutput test = (InnerIicService.PutAuthuserModifyPasswordInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opRemark, test.opRemark);
                builder.append(this.serialNo, test.serialNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutAuthuserModifyPasswordInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @NotNull(
                message = "不能为空"
        )
        private Integer opBranchNo;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String operatorNo;
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay;
        @SinogramLength(
                min = 1,
                max = 32,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String authId;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character authType;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId;
        @SinogramLength(
                min = 1,
                max = 64,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String newPassword;
        @SinogramLength(
                min = 1,
                max = 1024,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String oldPassword;
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String remark;

        public PutAuthuserModifyPasswordInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo;
        }

        public String getOperatorNo() {
            return this.operatorNo;
        }

        public String getOpStation() {
            return this.opStation;
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay;
        }

        public String getAuthId() {
            return this.authId;
        }

        public Character getAuthType() {
            return this.authType;
        }

        public String getClientId() {
            return this.clientId;
        }

        public String getNewPassword() {
            return this.newPassword;
        }

        public String getOldPassword() {
            return this.oldPassword;
        }

        public String getRemark() {
            return this.remark;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setAuthId(String authId) {
            this.authId = authId;
        }

        public void setAuthType(Character authType) {
            this.authType = authType;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setNewPassword(String newPassword) {
            this.newPassword = newPassword;
        }

        public void setOldPassword(String oldPassword) {
            this.oldPassword = oldPassword;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutAuthuserModifyPasswordInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",authId:" + this.authId);
            buffer.append(",authType:" + this.authType);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",newPassword:" + this.newPassword);
            buffer.append(",oldPassword:" + this.oldPassword);
            buffer.append(",remark:" + this.remark);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.authId);
            builder.append(this.authType);
            builder.append(this.clientId);
            builder.append(this.newPassword);
            builder.append(this.oldPassword);
            builder.append(this.remark);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerIicService.PutAuthuserModifyPasswordInnerInput) {
                InnerIicService.PutAuthuserModifyPasswordInnerInput test = (InnerIicService.PutAuthuserModifyPasswordInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.authId, test.authId);
                builder.append(this.authType, test.authType);
                builder.append(this.clientId, test.clientId);
                builder.append(this.newPassword, test.newPassword);
                builder.append(this.oldPassword, test.oldPassword);
                builder.append(this.remark, test.remark);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutAuthuserInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String opRemark;
        private Long serialNo;

        public PutAuthuserInnerOutput() {
        }

        public String getOpRemark() {
            return this.opRemark;
        }

        public Long getSerialNo() {
            return this.serialNo;
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public void setSerialNo(Long serialNo) {
            this.serialNo = serialNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutAuthuserInnerOutput:(");
            buffer.append("opRemark:" + this.opRemark);
            buffer.append(",serialNo:" + this.serialNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opRemark);
            builder.append(this.serialNo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerIicService.PutAuthuserInnerOutput) {
                InnerIicService.PutAuthuserInnerOutput test = (InnerIicService.PutAuthuserInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opRemark, test.opRemark);
                builder.append(this.serialNo, test.serialNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutAuthuserInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @NotNull(
                message = "不能为空"
        )
        private Integer opBranchNo;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String operatorNo;
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character assetProp;
        @SinogramLength(
                min = 1,
                max = 32,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String authId;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character authType;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String enEntrustWay;
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String remark;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character userStatus;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character mainFlag;
        @SinogramLength(
                min = 0,
                max = 1,
                charset = "utf-8"
        )
        private String flagDelete;

        public PutAuthuserInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo;
        }

        public String getOperatorNo() {
            return this.operatorNo;
        }

        public String getOpStation() {
            return this.opStation;
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay;
        }

        public Character getAssetProp() {
            return this.assetProp;
        }

        public String getAuthId() {
            return this.authId;
        }

        public Character getAuthType() {
            return this.authType;
        }

        public String getClientId() {
            return this.clientId;
        }

        public String getEnEntrustWay() {
            return this.enEntrustWay;
        }

        public String getRemark() {
            return this.remark;
        }

        public Character getUserStatus() {
            return this.userStatus;
        }

        public Character getMainFlag() {
            return this.mainFlag;
        }

        public String getFlagDelete() {
            return this.flagDelete;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setAssetProp(Character assetProp) {
            this.assetProp = assetProp;
        }

        public void setAuthId(String authId) {
            this.authId = authId;
        }

        public void setAuthType(Character authType) {
            this.authType = authType;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setEnEntrustWay(String enEntrustWay) {
            this.enEntrustWay = enEntrustWay;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public void setUserStatus(Character userStatus) {
            this.userStatus = userStatus;
        }

        public void setMainFlag(Character mainFlag) {
            this.mainFlag = mainFlag;
        }

        public void setFlagDelete(String flagDelete) {
            this.flagDelete = flagDelete;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutAuthuserInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",assetProp:" + this.assetProp);
            buffer.append(",authId:" + this.authId);
            buffer.append(",authType:" + this.authType);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",enEntrustWay:" + this.enEntrustWay);
            buffer.append(",remark:" + this.remark);
            buffer.append(",userStatus:" + this.userStatus);
            buffer.append(",mainFlag:" + this.mainFlag);
            buffer.append(",flagDelete:" + this.flagDelete);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.assetProp);
            builder.append(this.authId);
            builder.append(this.authType);
            builder.append(this.clientId);
            builder.append(this.enEntrustWay);
            builder.append(this.remark);
            builder.append(this.userStatus);
            builder.append(this.mainFlag);
            builder.append(this.flagDelete);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerIicService.PutAuthuserInnerInput) {
                InnerIicService.PutAuthuserInnerInput test = (InnerIicService.PutAuthuserInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.assetProp, test.assetProp);
                builder.append(this.authId, test.authId);
                builder.append(this.authType, test.authType);
                builder.append(this.clientId, test.clientId);
                builder.append(this.enEntrustWay, test.enEntrustWay);
                builder.append(this.remark, test.remark);
                builder.append(this.userStatus, test.userStatus);
                builder.append(this.mainFlag, test.mainFlag);
                builder.append(this.flagDelete, test.flagDelete);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutAuthuserDoubleFactorInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Long serialNo;
        private String opRemark;

        public PutAuthuserDoubleFactorInnerOutput() {
        }

        public Long getSerialNo() {
            return this.serialNo;
        }

        public String getOpRemark() {
            return this.opRemark;
        }

        public void setSerialNo(Long serialNo) {
            this.serialNo = serialNo;
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutAuthuserDoubleFactorInnerOutput:(");
            buffer.append("serialNo:" + this.serialNo);
            buffer.append(",opRemark:" + this.opRemark);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.serialNo);
            builder.append(this.opRemark);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerIicService.PutAuthuserDoubleFactorInnerOutput) {
                InnerIicService.PutAuthuserDoubleFactorInnerOutput test = (InnerIicService.PutAuthuserDoubleFactorInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.serialNo, test.serialNo);
                builder.append(this.opRemark, test.opRemark);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutAuthuserDoubleFactorInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @NotNull(
                message = "不能为空"
        )
        private Integer opBranchNo;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String operatorNo;
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay;
        @SinogramLength(
                min = 1,
                max = 32,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String authId;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character authType;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character dyntokenType;

        public PutAuthuserDoubleFactorInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo;
        }

        public String getOperatorNo() {
            return this.operatorNo;
        }

        public String getOpStation() {
            return this.opStation;
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay;
        }

        public String getAuthId() {
            return this.authId;
        }

        public Character getAuthType() {
            return this.authType;
        }

        public Character getDyntokenType() {
            return this.dyntokenType;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setAuthId(String authId) {
            this.authId = authId;
        }

        public void setAuthType(Character authType) {
            this.authType = authType;
        }

        public void setDyntokenType(Character dyntokenType) {
            this.dyntokenType = dyntokenType;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutAuthuserDoubleFactorInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",authId:" + this.authId);
            buffer.append(",authType:" + this.authType);
            buffer.append(",dyntokenType:" + this.dyntokenType);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.authId);
            builder.append(this.authType);
            builder.append(this.dyntokenType);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerIicService.PutAuthuserDoubleFactorInnerInput) {
                InnerIicService.PutAuthuserDoubleFactorInnerInput test = (InnerIicService.PutAuthuserDoubleFactorInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.authId, test.authId);
                builder.append(this.authType, test.authType);
                builder.append(this.dyntokenType, test.dyntokenType);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutAuthuserClientSignInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String opRemark;
        private Long serialNo;

        public PutAuthuserClientSignInnerOutput() {
        }

        public String getOpRemark() {
            return this.opRemark;
        }

        public Long getSerialNo() {
            return this.serialNo;
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public void setSerialNo(Long serialNo) {
            this.serialNo = serialNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutAuthuserClientSignInnerOutput:(");
            buffer.append("opRemark:" + this.opRemark);
            buffer.append(",serialNo:" + this.serialNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opRemark);
            builder.append(this.serialNo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerIicService.PutAuthuserClientSignInnerOutput) {
                InnerIicService.PutAuthuserClientSignInnerOutput test = (InnerIicService.PutAuthuserClientSignInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opRemark, test.opRemark);
                builder.append(this.serialNo, test.serialNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutAuthuserClientSignInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @NotNull(
                message = "不能为空"
        )
        private Integer opBranchNo;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String operatorNo;
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientIdDest;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientIdSrc;
        @SinogramLength(
                min = 1,
                max = 20,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String fundAccount;

        public PutAuthuserClientSignInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo;
        }

        public String getOperatorNo() {
            return this.operatorNo;
        }

        public String getOpStation() {
            return this.opStation;
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay;
        }

        public String getClientIdDest() {
            return this.clientIdDest;
        }

        public String getClientIdSrc() {
            return this.clientIdSrc;
        }

        public String getFundAccount() {
            return this.fundAccount;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setClientIdDest(String clientIdDest) {
            this.clientIdDest = clientIdDest;
        }

        public void setClientIdSrc(String clientIdSrc) {
            this.clientIdSrc = clientIdSrc;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutAuthuserClientSignInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",clientIdDest:" + this.clientIdDest);
            buffer.append(",clientIdSrc:" + this.clientIdSrc);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.clientIdDest);
            builder.append(this.clientIdSrc);
            builder.append(this.fundAccount);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerIicService.PutAuthuserClientSignInnerInput) {
                InnerIicService.PutAuthuserClientSignInnerInput test = (InnerIicService.PutAuthuserClientSignInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.clientIdDest, test.clientIdDest);
                builder.append(this.clientIdSrc, test.clientIdSrc);
                builder.append(this.fundAccount, test.fundAccount);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostUfAuthuserOpenInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String opRemark;
        private Long serialNo;

        public PostUfAuthuserOpenInnerOutput() {
        }

        public String getOpRemark() {
            return this.opRemark;
        }

        public Long getSerialNo() {
            return this.serialNo;
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public void setSerialNo(Long serialNo) {
            this.serialNo = serialNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostUfAuthuserOpenInnerOutput:(");
            buffer.append("opRemark:" + this.opRemark);
            buffer.append(",serialNo:" + this.serialNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opRemark);
            builder.append(this.serialNo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerIicService.PostUfAuthuserOpenInnerOutput) {
                InnerIicService.PostUfAuthuserOpenInnerOutput test = (InnerIicService.PostUfAuthuserOpenInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opRemark, test.opRemark);
                builder.append(this.serialNo, test.serialNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostUfAuthuserOpenInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @NotNull(
                message = "不能为空"
        )
        private Integer opBranchNo;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String operatorNo;
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character assetProp;
        @SinogramLength(
                min = 1,
                max = 32,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String authId;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character authType;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId;
        @SinogramLength(
                min = 1,
                max = 32,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String custId;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String enEntrustWay;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String idNo;
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String remark;
        @SinogramLength(
                min = 1,
                max = 100,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String tradePassword;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character userStatus;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character mainFlag;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character loginFlag;

        public PostUfAuthuserOpenInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo;
        }

        public String getOperatorNo() {
            return this.operatorNo;
        }

        public String getOpStation() {
            return this.opStation;
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay;
        }

        public Character getAssetProp() {
            return this.assetProp;
        }

        public String getAuthId() {
            return this.authId;
        }

        public Character getAuthType() {
            return this.authType;
        }

        public String getClientId() {
            return this.clientId;
        }

        public String getCustId() {
            return this.custId;
        }

        public String getEnEntrustWay() {
            return this.enEntrustWay;
        }

        public String getIdNo() {
            return this.idNo;
        }

        public String getRemark() {
            return this.remark;
        }

        public String getTradePassword() {
            return this.tradePassword;
        }

        public Character getUserStatus() {
            return this.userStatus;
        }

        public Character getMainFlag() {
            return this.mainFlag;
        }

        public Character getLoginFlag() {
            return this.loginFlag;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setAssetProp(Character assetProp) {
            this.assetProp = assetProp;
        }

        public void setAuthId(String authId) {
            this.authId = authId;
        }

        public void setAuthType(Character authType) {
            this.authType = authType;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setCustId(String custId) {
            this.custId = custId;
        }

        public void setEnEntrustWay(String enEntrustWay) {
            this.enEntrustWay = enEntrustWay;
        }

        public void setIdNo(String idNo) {
            this.idNo = idNo;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public void setTradePassword(String tradePassword) {
            this.tradePassword = tradePassword;
        }

        public void setUserStatus(Character userStatus) {
            this.userStatus = userStatus;
        }

        public void setMainFlag(Character mainFlag) {
            this.mainFlag = mainFlag;
        }

        public void setLoginFlag(Character loginFlag) {
            this.loginFlag = loginFlag;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostUfAuthuserOpenInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",assetProp:" + this.assetProp);
            buffer.append(",authId:" + this.authId);
            buffer.append(",authType:" + this.authType);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",custId:" + this.custId);
            buffer.append(",enEntrustWay:" + this.enEntrustWay);
            buffer.append(",idNo:" + this.idNo);
            buffer.append(",remark:" + this.remark);
            buffer.append(",tradePassword:" + this.tradePassword);
            buffer.append(",userStatus:" + this.userStatus);
            buffer.append(",mainFlag:" + this.mainFlag);
            buffer.append(",loginFlag:" + this.loginFlag);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.assetProp);
            builder.append(this.authId);
            builder.append(this.authType);
            builder.append(this.clientId);
            builder.append(this.custId);
            builder.append(this.enEntrustWay);
            builder.append(this.idNo);
            builder.append(this.remark);
            builder.append(this.tradePassword);
            builder.append(this.userStatus);
            builder.append(this.mainFlag);
            builder.append(this.loginFlag);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerIicService.PostUfAuthuserOpenInnerInput) {
                InnerIicService.PostUfAuthuserOpenInnerInput test = (InnerIicService.PostUfAuthuserOpenInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.assetProp, test.assetProp);
                builder.append(this.authId, test.authId);
                builder.append(this.authType, test.authType);
                builder.append(this.clientId, test.clientId);
                builder.append(this.custId, test.custId);
                builder.append(this.enEntrustWay, test.enEntrustWay);
                builder.append(this.idNo, test.idNo);
                builder.append(this.remark, test.remark);
                builder.append(this.tradePassword, test.tradePassword);
                builder.append(this.userStatus, test.userStatus);
                builder.append(this.mainFlag, test.mainFlag);
                builder.append(this.loginFlag, test.loginFlag);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostFullAuthuserActInfoSyncInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String opRemark;
        private Long serialNo;

        public PostFullAuthuserActInfoSyncInnerOutput() {
        }

        public String getOpRemark() {
            return this.opRemark;
        }

        public Long getSerialNo() {
            return this.serialNo;
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public void setSerialNo(Long serialNo) {
            this.serialNo = serialNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostFullAuthuserActInfoSyncInnerOutput:(");
            buffer.append("opRemark:" + this.opRemark);
            buffer.append(",serialNo:" + this.serialNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opRemark);
            builder.append(this.serialNo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerIicService.PostFullAuthuserActInfoSyncInnerOutput) {
                InnerIicService.PostFullAuthuserActInfoSyncInnerOutput test = (InnerIicService.PostFullAuthuserActInfoSyncInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opRemark, test.opRemark);
                builder.append(this.serialNo, test.serialNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostFullAuthuserActInfoSyncInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @NotNull(
                message = "不能为空"
        )
        private Integer opBranchNo;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String operatorNo;
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay;
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String authId;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character authType;

        public PostFullAuthuserActInfoSyncInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo;
        }

        public String getOperatorNo() {
            return this.operatorNo;
        }

        public String getOpStation() {
            return this.opStation;
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay;
        }

        public String getAuthId() {
            return this.authId;
        }

        public Character getAuthType() {
            return this.authType;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setAuthId(String authId) {
            this.authId = authId;
        }

        public void setAuthType(Character authType) {
            this.authType = authType;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostFullAuthuserActInfoSyncInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",authId:" + this.authId);
            buffer.append(",authType:" + this.authType);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.authId);
            builder.append(this.authType);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerIicService.PostFullAuthuserActInfoSyncInnerInput) {
                InnerIicService.PostFullAuthuserActInfoSyncInnerInput test = (InnerIicService.PostFullAuthuserActInfoSyncInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.authId, test.authId);
                builder.append(this.authType, test.authType);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostAuthvaskeyInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @NotNull(
                message = "不能为空"
        )
        private Integer opBranchNo;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String operatorNo;
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay;

        public PostAuthvaskeyInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo;
        }

        public String getOperatorNo() {
            return this.operatorNo;
        }

        public String getOpStation() {
            return this.opStation;
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostAuthvaskeyInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerIicService.PostAuthvaskeyInnerInput) {
                InnerIicService.PostAuthvaskeyInnerInput test = (InnerIicService.PostAuthvaskeyInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostAuthusertransInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String opRemark;
        private Long serialNo;

        public PostAuthusertransInnerOutput() {
        }

        public String getOpRemark() {
            return this.opRemark;
        }

        public Long getSerialNo() {
            return this.serialNo;
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public void setSerialNo(Long serialNo) {
            this.serialNo = serialNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostAuthusertransInnerOutput:(");
            buffer.append("opRemark:" + this.opRemark);
            buffer.append(",serialNo:" + this.serialNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opRemark);
            builder.append(this.serialNo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerIicService.PostAuthusertransInnerOutput) {
                InnerIicService.PostAuthusertransInnerOutput test = (InnerIicService.PostAuthusertransInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opRemark, test.opRemark);
                builder.append(this.serialNo, test.serialNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostAuthusertransInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @NotNull(
                message = "不能为空"
        )
        private Integer opBranchNo;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String operatorNo;
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay;
        @SinogramLength(
                min = 1,
                max = 32,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String authId;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character authType;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character auxiAcctType;
        @SinogramLength(
                min = 1,
                max = 64,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String auxiLoginAcct;
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String remark;
        @SinogramLength(
                min = 1,
                max = 100,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String tradePassword;
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String auxiAcctAssistant;

        public PostAuthusertransInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo;
        }

        public String getOperatorNo() {
            return this.operatorNo;
        }

        public String getOpStation() {
            return this.opStation;
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay;
        }

        public String getAuthId() {
            return this.authId;
        }

        public Character getAuthType() {
            return this.authType;
        }

        public Character getAuxiAcctType() {
            return this.auxiAcctType;
        }

        public String getAuxiLoginAcct() {
            return this.auxiLoginAcct;
        }

        public String getRemark() {
            return this.remark;
        }

        public String getTradePassword() {
            return this.tradePassword;
        }

        public String getAuxiAcctAssistant() {
            return this.auxiAcctAssistant;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setAuthId(String authId) {
            this.authId = authId;
        }

        public void setAuthType(Character authType) {
            this.authType = authType;
        }

        public void setAuxiAcctType(Character auxiAcctType) {
            this.auxiAcctType = auxiAcctType;
        }

        public void setAuxiLoginAcct(String auxiLoginAcct) {
            this.auxiLoginAcct = auxiLoginAcct;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public void setTradePassword(String tradePassword) {
            this.tradePassword = tradePassword;
        }

        public void setAuxiAcctAssistant(String auxiAcctAssistant) {
            this.auxiAcctAssistant = auxiAcctAssistant;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostAuthusertransInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",authId:" + this.authId);
            buffer.append(",authType:" + this.authType);
            buffer.append(",auxiAcctType:" + this.auxiAcctType);
            buffer.append(",auxiLoginAcct:" + this.auxiLoginAcct);
            buffer.append(",remark:" + this.remark);
            buffer.append(",tradePassword:" + this.tradePassword);
            buffer.append(",auxiAcctAssistant:" + this.auxiAcctAssistant);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.authId);
            builder.append(this.authType);
            builder.append(this.auxiAcctType);
            builder.append(this.auxiLoginAcct);
            builder.append(this.remark);
            builder.append(this.tradePassword);
            builder.append(this.auxiAcctAssistant);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerIicService.PostAuthusertransInnerInput) {
                InnerIicService.PostAuthusertransInnerInput test = (InnerIicService.PostAuthusertransInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.authId, test.authId);
                builder.append(this.authType, test.authType);
                builder.append(this.auxiAcctType, test.auxiAcctType);
                builder.append(this.auxiLoginAcct, test.auxiLoginAcct);
                builder.append(this.remark, test.remark);
                builder.append(this.tradePassword, test.tradePassword);
                builder.append(this.auxiAcctAssistant, test.auxiAcctAssistant);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostAuthuserOpenInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String opRemark;
        private Long serialNo;

        public PostAuthuserOpenInnerOutput() {
        }

        public String getOpRemark() {
            return this.opRemark;
        }

        public Long getSerialNo() {
            return this.serialNo;
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public void setSerialNo(Long serialNo) {
            this.serialNo = serialNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostAuthuserOpenInnerOutput:(");
            buffer.append("opRemark:" + this.opRemark);
            buffer.append(",serialNo:" + this.serialNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opRemark);
            builder.append(this.serialNo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerIicService.PostAuthuserOpenInnerOutput) {
                InnerIicService.PostAuthuserOpenInnerOutput test = (InnerIicService.PostAuthuserOpenInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opRemark, test.opRemark);
                builder.append(this.serialNo, test.serialNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostAuthuserOpenInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @NotNull(
                message = "不能为空"
        )
        private Integer opBranchNo;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String operatorNo;
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character assetProp;
        @SinogramLength(
                min = 1,
                max = 32,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String authId;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character authType;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId;
        @SinogramLength(
                min = 1,
                max = 32,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String custId;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String enEntrustWay;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String idNo;
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String remark;
        @SinogramLength(
                min = 1,
                max = 100,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String tradePassword;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character userStatus;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character mainFlag;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character loginFlag;

        public PostAuthuserOpenInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo;
        }

        public String getOperatorNo() {
            return this.operatorNo;
        }

        public String getOpStation() {
            return this.opStation;
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay;
        }

        public Character getAssetProp() {
            return this.assetProp;
        }

        public String getAuthId() {
            return this.authId;
        }

        public Character getAuthType() {
            return this.authType;
        }

        public String getClientId() {
            return this.clientId;
        }

        public String getCustId() {
            return this.custId;
        }

        public String getEnEntrustWay() {
            return this.enEntrustWay;
        }

        public String getIdNo() {
            return this.idNo;
        }

        public String getRemark() {
            return this.remark;
        }

        public String getTradePassword() {
            return this.tradePassword;
        }

        public Character getUserStatus() {
            return this.userStatus;
        }

        public Character getMainFlag() {
            return this.mainFlag;
        }

        public Character getLoginFlag() {
            return this.loginFlag;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setAssetProp(Character assetProp) {
            this.assetProp = assetProp;
        }

        public void setAuthId(String authId) {
            this.authId = authId;
        }

        public void setAuthType(Character authType) {
            this.authType = authType;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setCustId(String custId) {
            this.custId = custId;
        }

        public void setEnEntrustWay(String enEntrustWay) {
            this.enEntrustWay = enEntrustWay;
        }

        public void setIdNo(String idNo) {
            this.idNo = idNo;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public void setTradePassword(String tradePassword) {
            this.tradePassword = tradePassword;
        }

        public void setUserStatus(Character userStatus) {
            this.userStatus = userStatus;
        }

        public void setMainFlag(Character mainFlag) {
            this.mainFlag = mainFlag;
        }

        public void setLoginFlag(Character loginFlag) {
            this.loginFlag = loginFlag;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostAuthuserOpenInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",assetProp:" + this.assetProp);
            buffer.append(",authId:" + this.authId);
            buffer.append(",authType:" + this.authType);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",custId:" + this.custId);
            buffer.append(",enEntrustWay:" + this.enEntrustWay);
            buffer.append(",idNo:" + this.idNo);
            buffer.append(",remark:" + this.remark);
            buffer.append(",tradePassword:" + this.tradePassword);
            buffer.append(",userStatus:" + this.userStatus);
            buffer.append(",mainFlag:" + this.mainFlag);
            buffer.append(",loginFlag:" + this.loginFlag);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.assetProp);
            builder.append(this.authId);
            builder.append(this.authType);
            builder.append(this.clientId);
            builder.append(this.custId);
            builder.append(this.enEntrustWay);
            builder.append(this.idNo);
            builder.append(this.remark);
            builder.append(this.tradePassword);
            builder.append(this.userStatus);
            builder.append(this.mainFlag);
            builder.append(this.loginFlag);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerIicService.PostAuthuserOpenInnerInput) {
                InnerIicService.PostAuthuserOpenInnerInput test = (InnerIicService.PostAuthuserOpenInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.assetProp, test.assetProp);
                builder.append(this.authId, test.authId);
                builder.append(this.authType, test.authType);
                builder.append(this.clientId, test.clientId);
                builder.append(this.custId, test.custId);
                builder.append(this.enEntrustWay, test.enEntrustWay);
                builder.append(this.idNo, test.idNo);
                builder.append(this.remark, test.remark);
                builder.append(this.tradePassword, test.tradePassword);
                builder.append(this.userStatus, test.userStatus);
                builder.append(this.mainFlag, test.mainFlag);
                builder.append(this.loginFlag, test.loginFlag);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetAuthvaskeyInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String vasKey;

        public GetAuthvaskeyInnerOutput() {
        }

        public String getVasKey() {
            return this.vasKey;
        }

        public void setVasKey(String vasKey) {
            this.vasKey = vasKey;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetAuthvaskeyInnerOutput:(");
            buffer.append("vasKey:" + this.vasKey);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.vasKey);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerIicService.GetAuthvaskeyInnerOutput) {
                InnerIicService.GetAuthvaskeyInnerOutput test = (InnerIicService.GetAuthvaskeyInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.vasKey, test.vasKey);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetAuthvaskeyInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @NotNull(
                message = "不能为空"
        )
        private Integer opBranchNo;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String operatorNo;
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay;
        @SinogramLength(
                min = 1,
                max = 4,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String vaskeyNo;

        public GetAuthvaskeyInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo;
        }

        public String getOperatorNo() {
            return this.operatorNo;
        }

        public String getOpStation() {
            return this.opStation;
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay;
        }

        public String getVaskeyNo() {
            return this.vaskeyNo;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setVaskeyNo(String vaskeyNo) {
            this.vaskeyNo = vaskeyNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetAuthvaskeyInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",vaskeyNo:" + this.vaskeyNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.vaskeyNo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerIicService.GetAuthvaskeyInnerInput) {
                InnerIicService.GetAuthvaskeyInnerInput test = (InnerIicService.GetAuthvaskeyInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.vaskeyNo, test.vaskeyNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetAuthuserctrlPasswordErrorsInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer passwordErrors;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character entrustWay;

        public GetAuthuserctrlPasswordErrorsInnerOutput() {
        }

        public Integer getPasswordErrors() {
            return this.passwordErrors;
        }

        public Character getEntrustWay() {
            return this.entrustWay;
        }

        public void setPasswordErrors(Integer passwordErrors) {
            this.passwordErrors = passwordErrors;
        }

        public void setEntrustWay(Character entrustWay) {
            this.entrustWay = entrustWay;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetAuthuserctrlPasswordErrorsInnerOutput:(");
            buffer.append("passwordErrors:" + this.passwordErrors);
            buffer.append(",entrustWay:" + this.entrustWay);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.passwordErrors);
            builder.append(this.entrustWay);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerIicService.GetAuthuserctrlPasswordErrorsInnerOutput) {
                InnerIicService.GetAuthuserctrlPasswordErrorsInnerOutput test = (InnerIicService.GetAuthuserctrlPasswordErrorsInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.passwordErrors, test.passwordErrors);
                builder.append(this.entrustWay, test.entrustWay);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetAuthuserctrlPasswordErrorsInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @NotNull(
                message = "不能为空"
        )
        private Integer opBranchNo;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String operatorNo;
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay;
        @SinogramLength(
                min = 1,
                max = 32,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String authId;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character authType;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String enEntrustWay;

        public GetAuthuserctrlPasswordErrorsInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo;
        }

        public String getOperatorNo() {
            return this.operatorNo;
        }

        public String getOpStation() {
            return this.opStation;
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay;
        }

        public String getAuthId() {
            return this.authId;
        }

        public Character getAuthType() {
            return this.authType;
        }

        public String getEnEntrustWay() {
            return this.enEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setAuthId(String authId) {
            this.authId = authId;
        }

        public void setAuthType(Character authType) {
            this.authType = authType;
        }

        public void setEnEntrustWay(String enEntrustWay) {
            this.enEntrustWay = enEntrustWay;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetAuthuserctrlPasswordErrorsInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",authId:" + this.authId);
            buffer.append(",authType:" + this.authType);
            buffer.append(",enEntrustWay:" + this.enEntrustWay);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.authId);
            builder.append(this.authType);
            builder.append(this.enEntrustWay);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerIicService.GetAuthuserctrlPasswordErrorsInnerInput) {
                InnerIicService.GetAuthuserctrlPasswordErrorsInnerInput test = (InnerIicService.GetAuthuserctrlPasswordErrorsInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.authId, test.authId);
                builder.append(this.authType, test.authType);
                builder.append(this.enEntrustWay, test.enEntrustWay);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetAuthuserCustIdInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String custId;

        public GetAuthuserCustIdInnerOutput() {
        }

        public String getCustId() {
            return this.custId;
        }

        public void setCustId(String custId) {
            this.custId = custId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetAuthuserCustIdInnerOutput:(");
            buffer.append("custId:" + this.custId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.custId);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerIicService.GetAuthuserCustIdInnerOutput) {
                InnerIicService.GetAuthuserCustIdInnerOutput test = (InnerIicService.GetAuthuserCustIdInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.custId, test.custId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetAuthuserCustIdInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @NotNull(
                message = "不能为空"
        )
        private Integer opBranchNo;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String operatorNo;
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String clientId;
        @SinogramLength(
                min = 0,
                max = 20,
                charset = "utf-8"
        )
        private String fundAccount;

        public GetAuthuserCustIdInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo;
        }

        public String getOperatorNo() {
            return this.operatorNo;
        }

        public String getOpStation() {
            return this.opStation;
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay;
        }

        public String getClientId() {
            return this.clientId;
        }

        public String getFundAccount() {
            return this.fundAccount;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetAuthuserCustIdInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.clientId);
            builder.append(this.fundAccount);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerIicService.GetAuthuserCustIdInnerInput) {
                InnerIicService.GetAuthuserCustIdInnerInput test = (InnerIicService.GetAuthuserCustIdInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.clientId, test.clientId);
                builder.append(this.fundAccount, test.fundAccount);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetAuthuserCheckPasswordInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @NotNull(
                message = "不能为空"
        )
        private Integer opBranchNo;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String operatorNo;
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId;
        @SinogramLength(
                min = 1,
                max = 100,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String tradePassword;

        public GetAuthuserCheckPasswordInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo;
        }

        public String getOperatorNo() {
            return this.operatorNo;
        }

        public String getOpStation() {
            return this.opStation;
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay;
        }

        public String getClientId() {
            return this.clientId;
        }

        public String getTradePassword() {
            return this.tradePassword;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setTradePassword(String tradePassword) {
            this.tradePassword = tradePassword;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetAuthuserCheckPasswordInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",tradePassword:" + this.tradePassword);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.clientId);
            builder.append(this.tradePassword);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerIicService.GetAuthuserCheckPasswordInnerInput) {
                InnerIicService.GetAuthuserCheckPasswordInnerInput test = (InnerIicService.GetAuthuserCheckPasswordInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.clientId, test.clientId);
                builder.append(this.tradePassword, test.tradePassword);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class DeleteHistoryLogJourInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private List<InnerIicService.TransferDataDTO> transResult;

        public DeleteHistoryLogJourInnerOutput() {
        }

        public List<InnerIicService.TransferDataDTO> getTransResult() {
            return this.transResult;
        }

        public void setTransResult(List<InnerIicService.TransferDataDTO> transResult) {
            this.transResult = transResult;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("DeleteHistoryLogJourInnerOutput:(");
            buffer.append("transResult:" + this.transResult);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.transResult);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerIicService.DeleteHistoryLogJourInnerOutput) {
                InnerIicService.DeleteHistoryLogJourInnerOutput test = (InnerIicService.DeleteHistoryLogJourInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.transResult, test.transResult);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class DeleteHistoryLogJourInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @NotNull(
                message = "不能为空"
        )
        private Integer opBranchNo;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String operatorNo;
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay;
        private Integer initDate;

        public DeleteHistoryLogJourInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo;
        }

        public String getOperatorNo() {
            return this.operatorNo;
        }

        public String getOpStation() {
            return this.opStation;
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay;
        }

        public Integer getInitDate() {
            return this.initDate;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("DeleteHistoryLogJourInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",initDate:" + this.initDate);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.initDate);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerIicService.DeleteHistoryLogJourInnerInput) {
                InnerIicService.DeleteHistoryLogJourInnerInput test = (InnerIicService.DeleteHistoryLogJourInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.initDate, test.initDate);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class DeleteDayinitinfoDataInitInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer initDate;

        public DeleteDayinitinfoDataInitInnerOutput() {
        }

        public Integer getInitDate() {
            return this.initDate;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("DeleteDayinitinfoDataInitInnerOutput:(");
            buffer.append("initDate:" + this.initDate);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.initDate);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerIicService.DeleteDayinitinfoDataInitInnerOutput) {
                InnerIicService.DeleteDayinitinfoDataInitInnerOutput test = (InnerIicService.DeleteDayinitinfoDataInitInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.initDate, test.initDate);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class DeleteDayinitinfoDataInitInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @NotNull(
                message = "不能为空"
        )
        private Integer opBranchNo;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String operatorNo;
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay;
        @NotNull(
                message = "不能为空"
        )
        private Integer initDate;

        public DeleteDayinitinfoDataInitInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo;
        }

        public String getOperatorNo() {
            return this.operatorNo;
        }

        public String getOpStation() {
            return this.opStation;
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay;
        }

        public Integer getInitDate() {
            return this.initDate;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("DeleteDayinitinfoDataInitInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",initDate:" + this.initDate);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.initDate);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerIicService.DeleteDayinitinfoDataInitInnerInput) {
                InnerIicService.DeleteDayinitinfoDataInitInnerInput test = (InnerIicService.DeleteDayinitinfoDataInitInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.initDate, test.initDate);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class DeleteCachedAuthuserMapperInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String opRemark;
        private Long serialNo;

        public DeleteCachedAuthuserMapperInnerOutput() {
        }

        public String getOpRemark() {
            return this.opRemark;
        }

        public Long getSerialNo() {
            return this.serialNo;
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public void setSerialNo(Long serialNo) {
            this.serialNo = serialNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("DeleteCachedAuthuserMapperInnerOutput:(");
            buffer.append("opRemark:" + this.opRemark);
            buffer.append(",serialNo:" + this.serialNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opRemark);
            builder.append(this.serialNo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerIicService.DeleteCachedAuthuserMapperInnerOutput) {
                InnerIicService.DeleteCachedAuthuserMapperInnerOutput test = (InnerIicService.DeleteCachedAuthuserMapperInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opRemark, test.opRemark);
                builder.append(this.serialNo, test.serialNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class DeleteCachedAuthuserMapperInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @NotNull(
                message = "不能为空"
        )
        private Integer opBranchNo;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String operatorNo;
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay;
        @SinogramLength(
                min = 1,
                max = 4000,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String dataIds;

        public DeleteCachedAuthuserMapperInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo;
        }

        public String getOperatorNo() {
            return this.operatorNo;
        }

        public String getOpStation() {
            return this.opStation;
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay;
        }

        public String getDataIds() {
            return this.dataIds;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setDataIds(String dataIds) {
            this.dataIds = dataIds;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("DeleteCachedAuthuserMapperInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",dataIds:" + this.dataIds);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.dataIds);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerIicService.DeleteCachedAuthuserMapperInnerInput) {
                InnerIicService.DeleteCachedAuthuserMapperInnerInput test = (InnerIicService.DeleteCachedAuthuserMapperInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.dataIds, test.dataIds);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class DeleteAuthvaskeyInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @NotNull(
                message = "不能为空"
        )
        private Integer opBranchNo;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String operatorNo;
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay;

        public DeleteAuthvaskeyInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo;
        }

        public String getOperatorNo() {
            return this.operatorNo;
        }

        public String getOpStation() {
            return this.opStation;
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("DeleteAuthvaskeyInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerIicService.DeleteAuthvaskeyInnerInput) {
                InnerIicService.DeleteAuthvaskeyInnerInput test = (InnerIicService.DeleteAuthvaskeyInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class DeleteAuthusertransInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String opRemark;
        private Long serialNo;

        public DeleteAuthusertransInnerOutput() {
        }

        public String getOpRemark() {
            return this.opRemark;
        }

        public Long getSerialNo() {
            return this.serialNo;
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public void setSerialNo(Long serialNo) {
            this.serialNo = serialNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("DeleteAuthusertransInnerOutput:(");
            buffer.append("opRemark:" + this.opRemark);
            buffer.append(",serialNo:" + this.serialNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opRemark);
            builder.append(this.serialNo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerIicService.DeleteAuthusertransInnerOutput) {
                InnerIicService.DeleteAuthusertransInnerOutput test = (InnerIicService.DeleteAuthusertransInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opRemark, test.opRemark);
                builder.append(this.serialNo, test.serialNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class DeleteAuthusertransInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @NotNull(
                message = "不能为空"
        )
        private Integer opBranchNo;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String operatorNo;
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay;
        @SinogramLength(
                min = 1,
                max = 32,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String authId;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character authType;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character auxiAcctType;
        @SinogramLength(
                min = 1,
                max = 64,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String auxiLoginAcct;
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String remark;

        public DeleteAuthusertransInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo;
        }

        public String getOperatorNo() {
            return this.operatorNo;
        }

        public String getOpStation() {
            return this.opStation;
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay;
        }

        public String getAuthId() {
            return this.authId;
        }

        public Character getAuthType() {
            return this.authType;
        }

        public Character getAuxiAcctType() {
            return this.auxiAcctType;
        }

        public String getAuxiLoginAcct() {
            return this.auxiLoginAcct;
        }

        public String getRemark() {
            return this.remark;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setAuthId(String authId) {
            this.authId = authId;
        }

        public void setAuthType(Character authType) {
            this.authType = authType;
        }

        public void setAuxiAcctType(Character auxiAcctType) {
            this.auxiAcctType = auxiAcctType;
        }

        public void setAuxiLoginAcct(String auxiLoginAcct) {
            this.auxiLoginAcct = auxiLoginAcct;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("DeleteAuthusertransInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",authId:" + this.authId);
            buffer.append(",authType:" + this.authType);
            buffer.append(",auxiAcctType:" + this.auxiAcctType);
            buffer.append(",auxiLoginAcct:" + this.auxiLoginAcct);
            buffer.append(",remark:" + this.remark);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.authId);
            builder.append(this.authType);
            builder.append(this.auxiAcctType);
            builder.append(this.auxiLoginAcct);
            builder.append(this.remark);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerIicService.DeleteAuthusertransInnerInput) {
                InnerIicService.DeleteAuthusertransInnerInput test = (InnerIicService.DeleteAuthusertransInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.authId, test.authId);
                builder.append(this.authType, test.authType);
                builder.append(this.auxiAcctType, test.auxiAcctType);
                builder.append(this.auxiLoginAcct, test.auxiLoginAcct);
                builder.append(this.remark, test.remark);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class DeleteAuthuserctrlAutoUnlockInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @NotNull(
                message = "不能为空"
        )
        private Integer opBranchNo;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String operatorNo;
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay;

        public DeleteAuthuserctrlAutoUnlockInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo;
        }

        public String getOperatorNo() {
            return this.operatorNo;
        }

        public String getOpStation() {
            return this.opStation;
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("DeleteAuthuserctrlAutoUnlockInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerIicService.DeleteAuthuserctrlAutoUnlockInnerInput) {
                InnerIicService.DeleteAuthuserctrlAutoUnlockInnerInput test = (InnerIicService.DeleteAuthuserctrlAutoUnlockInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class DeleteActAlreadyExistMapperInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @NotNull(
                message = "不能为空"
        )
        private Integer opBranchNo;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String operatorNo;
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay;

        public DeleteActAlreadyExistMapperInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo;
        }

        public String getOperatorNo() {
            return this.operatorNo;
        }

        public String getOpStation() {
            return this.opStation;
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("DeleteActAlreadyExistMapperInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerIicService.DeleteActAlreadyExistMapperInnerInput) {
                InnerIicService.DeleteActAlreadyExistMapperInnerInput test = (InnerIicService.DeleteActAlreadyExistMapperInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }
}
