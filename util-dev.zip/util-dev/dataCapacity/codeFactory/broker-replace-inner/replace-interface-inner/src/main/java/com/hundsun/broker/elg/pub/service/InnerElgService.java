//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.hundsun.broker.elg.pub.service;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.hundsun.broker.base.PublicChecker.PublicParams;
import com.hundsun.broker.base.databind.CharacterJsonDeserializer;
import com.hundsun.jrescloud.rpc.annotation.CloudFunction;
import com.hundsun.jrescloud.rpc.annotation.CloudService;
import com.hundsun.jrescloud.rpc.def.json.DoubleJsonDeserializer;
import com.hundsun.jrescloud.rpc.def.json.SerializeDoubleDigit;
import com.hundsun.jrescloud.rpc.def.validation.SinogramLength;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

@CloudService(
        validation = true,
        validationNull = false,
        application = "hsbroker.elg"
)
public interface InnerElgService {
    @CloudFunction(
            value = "elg.deleteClientpreferByIdInner",
            desc = "客户投资偏好表删除",
            apiUrl = "/deleteClientpreferByIdInner"
    )
    InnerElgService.DeleteClientpreferByIdInnerOutput deleteClientpreferByIdInner(InnerElgService.DeleteClientpreferByIdInnerInput var1);

    @CloudFunction(
            value = "elg.deleteDayinitinfoDataInitInner",
            desc = "适当性中心历史数据删除",
            apiUrl = "/deleteDayinitinfoDataInitInner"
    )
    InnerElgService.DeleteDayinitinfoDataInitInnerOutput deleteDayinitinfoDataInitInner(InnerElgService.DeleteDayinitinfoDataInitInnerInput var1);

    @CloudFunction(
            value = "elg.deleteOpenRightDetailInner",
            desc = "权限开通记录表信息删除",
            apiUrl = "/deleteOpenRightDetailInner"
    )
    InnerElgService.DeleteOpenRightDetailInnerOutput deleteOpenRightDetailInner(InnerElgService.DeleteOpenRightDetailInnerInput var1);

    @CloudFunction(
            value = "elg.deleteStockholderElginfoInner",
            desc = "证券账户销户适当性信息删除",
            apiUrl = "/deleteStockholderElginfoInner"
    )
    InnerElgService.DeleteStockholderElginfoInnerOutput deleteStockholderElginfoInner(InnerElgService.DeleteStockholderElginfoInnerInput var1);

    @CloudFunction(
            value = "elg.getBusinAgreementInner",
            desc = "适当性协议获取",
            apiUrl = "/getBusinAgreementInner"
    )
    List<InnerElgService.GetBusinAgreementInnerOutput> getBusinAgreementInner(InnerElgService.GetBusinAgreementInnerInput var1);

    @CloudFunction(
            value = "elg.getBusinQualiargInner",
            desc = "业务资质审核查询",
            apiUrl = "/getBusinQualiargInner"
    )
    InnerElgService.GetBusinQualiargInnerOutput getBusinQualiargInner(InnerElgService.GetBusinQualiargInnerInput var1);

    @CloudFunction(
            value = "elg.getClientpreferByIdInner",
            desc = "适当性客户投资偏好查询",
            apiUrl = "/getClientpreferByIdInner"
    )
    InnerElgService.GetClientpreferByIdInnerOutput getClientpreferByIdInner(InnerElgService.GetClientpreferByIdInnerInput var1);

    @CloudFunction(
            value = "elg.getCusQualiResultInner",
            desc = "业务准入条件校验",
            apiUrl = "/getCusQualiResultInner"
    )
    InnerElgService.GetCusQualiResultInnerOutput getCusQualiResultInner(InnerElgService.GetCusQualiResultInnerInput var1);

    @CloudFunction(
            value = "elg.getElgTestJourAndPaperInner",
            desc = "测评记录和试卷查询",
            apiUrl = "/getElgTestJourAndPaperInner"
    )
    InnerElgService.GetElgTestJourAndPaperInnerOutput getElgTestJourAndPaperInner(InnerElgService.GetElgTestJourAndPaperInnerInput var1);

    @CloudFunction(
            value = "elg.getOptAcctLimitListInner",
            desc = "限仓模板信息查询",
            apiUrl = "/getOptAcctLimitListInner"
    )
    InnerElgService.GetOptAcctLimitListInnerOutput getOptAcctLimitListInner(InnerElgService.GetOptAcctLimitListInnerInput var1);

    @CloudFunction(
            value = "elg.getOptClientInfoListInner",
            desc = "客户期权信息获取",
            apiUrl = "/getOptClientInfoListInner"
    )
    InnerElgService.GetOptClientInfoListInnerOutput getOptClientInfoListInner(InnerElgService.GetOptClientInfoListInnerInput var1);

    @CloudFunction(
            value = "elg.getProductInner",
            desc = "产品适当性属性查询",
            apiUrl = "/getProductInner"
    )
    List<InnerElgService.GetProductInnerOutput> getProductInner(InnerElgService.GetProductInnerInput var1);

    @CloudFunction(
            value = "elg.deleteProductInner",
            desc = "产品适当性属性删除",
            apiUrl = "/deleteProductInner"
    )
    InnerElgService.DeleteProductInnerOutput deleteProductInner(InnerElgService.DeleteProductInnerInput var1);

    @CloudFunction(
            value = "elg.getQueryIsTradingDayInner",
            desc = "判断是否是交易日",
            apiUrl = "/getQueryIsTradingDayInner"
    )
    InnerElgService.GetQueryIsTradingDayInnerOutput getQueryIsTradingDayInner(InnerElgService.GetQueryIsTradingDayInnerInput var1);

    @CloudFunction(
            value = "elg.getSstaccountInner",
            desc = "股份转让投资者账户查询",
            apiUrl = "/getSstaccountInner"
    )
    List<InnerElgService.GetSstaccountInnerOutput> getSstaccountInner(InnerElgService.GetSstaccountInnerInput var1);

    @CloudFunction(
            value = "elg.getStockAcctCancelValidateInner",
            desc = "适当性证券账户销户检查",
            apiUrl = "/getStockAcctCancelValidateInner"
    )
    List<InnerElgService.GetStockAcctCancelValidateInnerOutput> getStockAcctCancelValidateInner(InnerElgService.GetStockAcctCancelValidateInnerInput var1);

    @CloudFunction(
            value = "elg.postAgreementSignInner",
            desc = "适当性协议签署",
            apiUrl = "/postAgreementSignInner"
    )
    InnerElgService.PostAgreementSignInnerOutput postAgreementSignInner(InnerElgService.PostAgreementSignInnerInput var1);

    @CloudFunction(
            value = "elg.postAutoBondExportInner",
            desc = "债券自动申报导出",
            apiUrl = "/postAutoBondExportInner"
    )
    void postAutoBondExportInner(InnerElgService.PostAutoBondExportInnerInput var1);

    @CloudFunction(
            value = "elg.postCreditQuotaUpdateInner",
            desc = "融资融券额度到期更新",
            apiUrl = "/postCreditQuotaUpdateInner"
    )
    void postCreditQuotaUpdateInner(InnerElgService.PostCreditQuotaUpdateInnerInput var1);

    @CloudFunction(
            value = "elg.postCusPreCheckInner",
            desc = "客户业务准入条件校验",
            apiUrl = "/postCusPreCheckInner"
    )
    List<InnerElgService.PostCusPreCheckInnerOutput> postCusPreCheckInner(InnerElgService.PostCusPreCheckInnerInput var1);

    @CloudFunction(
            value = "elg.postDayinitinfoDataToprevInner",
            desc = "数据归上日",
            apiUrl = "/postDayinitinfoDataToprevInner"
    )
    InnerElgService.PostDayinitinfoDataToprevInnerOutput postDayinitinfoDataToprevInner(InnerElgService.PostDayinitinfoDataToprevInnerInput var1);

    @CloudFunction(
            value = "elg.postDayinitinfoSqlInner",
            desc = "适当性指定sql执行",
            apiUrl = "/postDayinitinfoSqlInner"
    )
    InnerElgService.PostDayinitinfoSqlInnerOutput postDayinitinfoSqlInner(InnerElgService.PostDayinitinfoSqlInnerInput var1);

    @CloudFunction(
            value = "elg.postElgAccountOpenSyncInner",
            desc = "账户开户信息同步",
            apiUrl = "/postElgAccountOpenSyncInner"
    )
    InnerElgService.PostElgAccountOpenSyncInnerOutput postElgAccountOpenSyncInner(InnerElgService.PostElgAccountOpenSyncInnerInput var1);

    @CloudFunction(
            value = "elg.postElgsstrestradeacctInner",
            desc = "受限投资者可交易信息库新增",
            apiUrl = "/postElgsstrestradeacctInner"
    )
    InnerElgService.PostElgsstrestradeacctInnerOutput postElgsstrestradeacctInner(InnerElgService.PostElgsstrestradeacctInnerInput var1);

    @CloudFunction(
            value = "elg.postOpenRightDetailInner",
            desc = "权限开通记录表信息新增",
            apiUrl = "/postOpenRightDetailInner"
    )
    InnerElgService.PostOpenRightDetailInnerOutput postOpenRightDetailInner(InnerElgService.PostOpenRightDetailInnerInput var1);

    @CloudFunction(
            value = "elg.postOptclientinfoQuotaInner",
            desc = "客户期权买入额度取消",
            apiUrl = "/postOptclientinfoQuotaInner"
    )
    InnerElgService.PostOptclientinfoQuotaInnerOutput postOptclientinfoQuotaInner(InnerElgService.PostOptclientinfoQuotaInnerInput var1);

    @CloudFunction(
            value = "elg.postProductInner",
            desc = "产品适当性属性设置",
            apiUrl = "/postProductInner"
    )
    InnerElgService.PostProductInnerOutput postProductInner(InnerElgService.PostProductInnerInput var1);

    @CloudFunction(
            value = "elg.postProductRulesCheckInner",
            desc = "产品适当性校验",
            apiUrl = "/postProductRulesCheckInner"
    )
    List<InnerElgService.PostProductRulesCheckInnerOutput> postProductRulesCheckInner(InnerElgService.PostProductRulesCheckInnerInput var1);

    @CloudFunction(
            value = "elg.postProductRulesConfirmInner",
            desc = "适当性校验未确定项确认",
            apiUrl = "/postProductRulesConfirmInner"
    )
    InnerElgService.PostProductRulesConfirmInnerOutput postProductRulesConfirmInner(InnerElgService.PostProductRulesConfirmInnerInput var1);

    @CloudFunction(
            value = "elg.postProductcheckOutInner",
            desc = "产品适当性兜底校验",
            apiUrl = "/postProductcheckOutInner"
    )
    List<InnerElgService.PostProductcheckOutInnerOutput> postProductcheckOutInner(InnerElgService.PostProductcheckOutInnerInput var1);

    @CloudFunction(
            value = "elg.postRefacctreportInner",
            desc = "出借人回报处理",
            apiUrl = "/postRefacctreportInner"
    )
    InnerElgService.PostRefacctreportInnerOutput postRefacctreportInner(InnerElgService.PostRefacctreportInnerInput var1);

    @CloudFunction(
            value = "elg.postSzOptSyncShDataInner",
            desc = "深圳期权同步沪市数据",
            apiUrl = "/postSzOptSyncShDataInner"
    )
    InnerElgService.PostSzOptSyncShDataInnerOutput postSzOptSyncShDataInner(InnerElgService.PostSzOptSyncShDataInnerInput var1);

    @CloudFunction(
            value = "elg.putClientPreferPushInner",
            desc = "客户投资偏好推送",
            apiUrl = "/putClientPreferPushInner"
    )
    InnerElgService.PutClientPreferPushInnerOutput putClientPreferPushInner(InnerElgService.PutClientPreferPushInnerInput var1);

    @CloudFunction(
            value = "elg.putDayinitinfoBatchDealInner",
            desc = "日终清算后处理批量处理",
            apiUrl = "/putDayinitinfoBatchDealInner"
    )
    InnerElgService.PutDayinitinfoBatchDealInnerOutput putDayinitinfoBatchDealInner(InnerElgService.PutDayinitinfoBatchDealInnerInput var1);

    @CloudFunction(
            value = "elg.putDayinitinfoDateChangeInner",
            desc = "适当性中心日终日切",
            apiUrl = "/putDayinitinfoDateChangeInner"
    )
    InnerElgService.PutDayinitinfoDateChangeInnerOutput putDayinitinfoDateChangeInner(InnerElgService.PutDayinitinfoDateChangeInnerInput var1);

    @CloudFunction(
            value = "elg.putRightsExpireInner",
            desc = "权限到期处理",
            apiUrl = "/putRightsExpireInner"
    )
    InnerElgService.PutRightsExpireInnerOutput putRightsExpireInner(InnerElgService.PutRightsExpireInnerInput var1);

    @CloudFunction(
            value = "elg.putRiskLevelCreditCheckInner",
            desc = "风险等级变更融资融券检查",
            apiUrl = "/putRiskLevelCreditCheckInner"
    )
    InnerElgService.PutRiskLevelCreditCheckInnerOutput putRiskLevelCreditCheckInner(InnerElgService.PutRiskLevelCreditCheckInnerInput var1);

    @CloudFunction(
            value = "elg.postProdAgreementInner",
            desc = "产品协议签署",
            apiUrl = "/postProdAgreementInner"
    )
    InnerElgService.PostProdAgreementInnerOutput postProdAgreementInner(InnerElgService.PostProdAgreementInnerInput var1);

    @CloudFunction(
            value = "elg.getProdAgreementInner",
            desc = "产品协议查询",
            apiUrl = "/getProdAgreementInner"
    )
    List<InnerElgService.GetProdAgreementInnerOutput> getProdAgreementInner(InnerElgService.GetProdAgreementInnerInput var1);

    @CloudFunction(
            value = "elg.getUnitycreditClientcrdtInner",
            desc = "客户征信信息查询",
            apiUrl = "/getUnitycreditClientcrdtInner"
    )
    List<InnerElgService.GetUnitycreditClientcrdtInnerOutput> getUnitycreditClientcrdtInner(InnerElgService.GetUnitycreditClientcrdtInnerInput var1);

    @CloudFunction(
            value = "elg.putUnityCreditCrdtLevelSyncInner",
            desc = "融资融券征信信用等级同步",
            apiUrl = "/putUnityCreditCrdtLevelSyncInner"
    )
    InnerElgService.PutUnityCreditCrdtLevelSyncInnerOutput putUnityCreditCrdtLevelSyncInner(InnerElgService.PutUnityCreditCrdtLevelSyncInnerInput var1);

    @CloudFunction(
            value = "elg.deleteGemacctinfoCancelInner",
            desc = "创业板注册制适当性取消",
            apiUrl = "/deleteGemacctinfoCancelInner"
    )
    InnerElgService.DeleteGemacctinfoCancelInnerOutput deleteGemacctinfoCancelInner(InnerElgService.DeleteGemacctinfoCancelInnerInput var1);

    @CloudFunction(
            value = "elg.postStbstdholderSstaccountInner",
            desc = "信用北交所账户开户信息同步",
            apiUrl = "/postStbstdholderSstaccountInner"
    )
    InnerElgService.PostStbstdholderSstaccountInnerOutput postStbstdholderSstaccountInner(InnerElgService.PostStbstdholderSstaccountInnerInput var1);

    public static class PostStbstdholderSstaccountInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String opRemark = " ";

        public PostStbstdholderSstaccountInnerOutput() {
        }

        public String getOpRemark() {
            if (this.opRemark == null) {
                return " ";
            } else {
                return this.opRemark.isEmpty() ? " " : this.opRemark;
            }
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostStbstdholderSstaccountInnerOutput:(");
            buffer.append("opRemark:" + this.opRemark);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opRemark);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.PostStbstdholderSstaccountInnerOutput) {
                InnerElgService.PostStbstdholderSstaccountInnerOutput test = (InnerElgService.PostStbstdholderSstaccountInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opRemark, test.opRemark);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostStbstdholderSstaccountInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer branchNo = 0;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId = " ";
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String fundAccount = " ";
        @SinogramLength(
                min = 1,
                max = 20,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String stockAccount = " ";
        @SinogramLength(
                min = 0,
                max = 8,
                charset = "utf-8"
        )
        private String stockCode = " ";
        @SinogramLength(
                min = 1,
                max = 40,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String idNo = " ";
        @SinogramLength(
                min = 0,
                max = 8,
                charset = "utf-8"
        )
        private String seatNo = " ";
        @SinogramLength(
                min = 1,
                max = 2000,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String holderRights = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fundAccountSes = " ";
        @SinogramLength(
                min = 0,
                max = 20,
                charset = "utf-8"
        )
        private String stockAccountSes = " ";

        public PostStbstdholderSstaccountInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getStockAccount() {
            if (this.stockAccount == null) {
                return " ";
            } else {
                return this.stockAccount.isEmpty() ? " " : this.stockAccount;
            }
        }

        public String getStockCode() {
            if (this.stockCode == null) {
                return " ";
            } else {
                return this.stockCode.isEmpty() ? " " : this.stockCode;
            }
        }

        public String getIdNo() {
            if (this.idNo == null) {
                return " ";
            } else {
                return this.idNo.isEmpty() ? " " : this.idNo;
            }
        }

        public String getSeatNo() {
            if (this.seatNo == null) {
                return " ";
            } else {
                return this.seatNo.isEmpty() ? " " : this.seatNo;
            }
        }

        public String getHolderRights() {
            if (this.holderRights == null) {
                return " ";
            } else {
                return this.holderRights.isEmpty() ? " " : this.holderRights;
            }
        }

        public String getFundAccountSes() {
            if (this.fundAccountSes == null) {
                return " ";
            } else {
                return this.fundAccountSes.isEmpty() ? " " : this.fundAccountSes;
            }
        }

        public String getStockAccountSes() {
            if (this.stockAccountSes == null) {
                return " ";
            } else {
                return this.stockAccountSes.isEmpty() ? " " : this.stockAccountSes;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setStockAccount(String stockAccount) {
            this.stockAccount = stockAccount;
        }

        public void setStockCode(String stockCode) {
            this.stockCode = stockCode;
        }

        public void setIdNo(String idNo) {
            this.idNo = idNo;
        }

        public void setSeatNo(String seatNo) {
            this.seatNo = seatNo;
        }

        public void setHolderRights(String holderRights) {
            this.holderRights = holderRights;
        }

        public void setFundAccountSes(String fundAccountSes) {
            this.fundAccountSes = fundAccountSes;
        }

        public void setStockAccountSes(String stockAccountSes) {
            this.stockAccountSes = stockAccountSes;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostStbstdholderSstaccountInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",stockAccount:" + this.stockAccount);
            buffer.append(",stockCode:" + this.stockCode);
            buffer.append(",idNo:" + this.idNo);
            buffer.append(",seatNo:" + this.seatNo);
            buffer.append(",holderRights:" + this.holderRights);
            buffer.append(",fundAccountSes:" + this.fundAccountSes);
            buffer.append(",stockAccountSes:" + this.stockAccountSes);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.branchNo);
            builder.append(this.clientId);
            builder.append(this.fundAccount);
            builder.append(this.stockAccount);
            builder.append(this.stockCode);
            builder.append(this.idNo);
            builder.append(this.seatNo);
            builder.append(this.holderRights);
            builder.append(this.fundAccountSes);
            builder.append(this.stockAccountSes);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.PostStbstdholderSstaccountInnerInput) {
                InnerElgService.PostStbstdholderSstaccountInnerInput test = (InnerElgService.PostStbstdholderSstaccountInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.clientId, test.clientId);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.stockAccount, test.stockAccount);
                builder.append(this.stockCode, test.stockCode);
                builder.append(this.idNo, test.idNo);
                builder.append(this.seatNo, test.seatNo);
                builder.append(this.holderRights, test.holderRights);
                builder.append(this.fundAccountSes, test.fundAccountSes);
                builder.append(this.stockAccountSes, test.stockAccountSes);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class DeleteGemacctinfoCancelInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Long serialNo = 0L;
        private String opRemark = " ";

        public DeleteGemacctinfoCancelInnerOutput() {
        }

        public Long getSerialNo() {
            return this.serialNo != null ? this.serialNo : 0L;
        }

        public String getOpRemark() {
            if (this.opRemark == null) {
                return " ";
            } else {
                return this.opRemark.isEmpty() ? " " : this.opRemark;
            }
        }

        public void setSerialNo(Long serialNo) {
            this.serialNo = serialNo;
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("DeleteGemacctinfoCancelInnerOutput:(");
            buffer.append("serialNo:" + this.serialNo);
            buffer.append(",opRemark:" + this.opRemark);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.serialNo);
            builder.append(this.opRemark);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.DeleteGemacctinfoCancelInnerOutput) {
                InnerElgService.DeleteGemacctinfoCancelInnerOutput test = (InnerElgService.DeleteGemacctinfoCancelInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.serialNo, test.serialNo);
                builder.append(this.opRemark, test.opRemark);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class DeleteGemacctinfoCancelInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer branchNo = 0;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId = " ";
        @SinogramLength(
                min = 1,
                max = 20,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String stockAccount = " ";
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String fundAccount = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String checkStr = " ";

        public DeleteGemacctinfoCancelInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getStockAccount() {
            if (this.stockAccount == null) {
                return " ";
            } else {
                return this.stockAccount.isEmpty() ? " " : this.stockAccount;
            }
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getCheckStr() {
            if (this.checkStr == null) {
                return " ";
            } else {
                return this.checkStr.isEmpty() ? " " : this.checkStr;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setStockAccount(String stockAccount) {
            this.stockAccount = stockAccount;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setCheckStr(String checkStr) {
            this.checkStr = checkStr;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("DeleteGemacctinfoCancelInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",stockAccount:" + this.stockAccount);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",checkStr:" + this.checkStr);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.branchNo);
            builder.append(this.clientId);
            builder.append(this.stockAccount);
            builder.append(this.fundAccount);
            builder.append(this.checkStr);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.DeleteGemacctinfoCancelInnerInput) {
                InnerElgService.DeleteGemacctinfoCancelInnerInput test = (InnerElgService.DeleteGemacctinfoCancelInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.clientId, test.clientId);
                builder.append(this.stockAccount, test.stockAccount);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.checkStr, test.checkStr);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutUnityCreditCrdtLevelSyncInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String opRemark = " ";

        public PutUnityCreditCrdtLevelSyncInnerOutput() {
        }

        public String getOpRemark() {
            if (this.opRemark == null) {
                return " ";
            } else {
                return this.opRemark.isEmpty() ? " " : this.opRemark;
            }
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutUnityCreditCrdtLevelSyncInnerOutput:(");
            buffer.append("opRemark:" + this.opRemark);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opRemark);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.PutUnityCreditCrdtLevelSyncInnerOutput) {
                InnerElgService.PutUnityCreditCrdtLevelSyncInnerOutput test = (InnerElgService.PutUnityCreditCrdtLevelSyncInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opRemark, test.opRemark);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutUnityCreditCrdtLevelSyncInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer branchNo = 0;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId = " ";
        @SinogramLength(
                min = 1,
                max = 10,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String crdtLevel = " ";

        public PutUnityCreditCrdtLevelSyncInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getCrdtLevel() {
            if (this.crdtLevel == null) {
                return " ";
            } else {
                return this.crdtLevel.isEmpty() ? " " : this.crdtLevel;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setCrdtLevel(String crdtLevel) {
            this.crdtLevel = crdtLevel;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutUnityCreditCrdtLevelSyncInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",crdtLevel:" + this.crdtLevel);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.branchNo);
            builder.append(this.clientId);
            builder.append(this.crdtLevel);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.PutUnityCreditCrdtLevelSyncInnerInput) {
                InnerElgService.PutUnityCreditCrdtLevelSyncInnerInput test = (InnerElgService.PutUnityCreditCrdtLevelSyncInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.clientId, test.clientId);
                builder.append(this.crdtLevel, test.crdtLevel);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetUnitycreditClientcrdtInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        private Integer initDate = 0;
        private Long serialNo = 0L;
        private String clientcrId = " ";
        private Integer currDate = 0;
        private Integer currTime = 0;
        private String operatorNo = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private String clientId = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character unitycreditType = ' ';
        private String paperType = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character organFlag = ' ';
        private String paperAnswer = " ";
        private String eligContent = " ";
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double paperScore = 0.0D;
        private String crdtLevel = " ";
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double crdtScore = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double crdtexScore = 0.0D;
        private String crdtexRemark = " ";
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double creditQuota = 0.0D;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character crdtStatus = ' ';
        private Integer beginDate = 0;
        private Integer endDate = 0;
        private Integer dateClear = 0;
        private String remark = " ";
        private String positionStr = " ";
        private Integer tmpDateClear = 0;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double totalApplyQuota = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double tmpCreditQuota = 0.0D;
        private String referee = " ";
        private Integer tmpBeginDate = 0;
        @SerializeDoubleDigit(
                digit = 8
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double integralRate = 0.0D;
        private Integer tmpEndDate = 0;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double asset = 0.0D;
        private String tmpCrdtLevel = " ";
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double diffBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double tmpCrdtScore = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double finMaxQuota = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double creditQuotaOld = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double sloMaxQuota = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double accmdiffBalance = 0.0D;
        private String opStation = " ";

        public GetUnitycreditClientcrdtInnerOutput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public Long getSerialNo() {
            return this.serialNo != null ? this.serialNo : 0L;
        }

        public String getClientcrId() {
            if (this.clientcrId == null) {
                return " ";
            } else {
                return this.clientcrId.isEmpty() ? " " : this.clientcrId;
            }
        }

        public Integer getCurrDate() {
            return this.currDate != null ? this.currDate : 0;
        }

        public Integer getCurrTime() {
            return this.currTime != null ? this.currTime : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public Character getUnitycreditType() {
            return this.unitycreditType != null ? this.unitycreditType : ' ';
        }

        public String getPaperType() {
            if (this.paperType == null) {
                return " ";
            } else {
                return this.paperType.isEmpty() ? " " : this.paperType;
            }
        }

        public Character getOrganFlag() {
            return this.organFlag != null ? this.organFlag : ' ';
        }

        public String getPaperAnswer() {
            if (this.paperAnswer == null) {
                return " ";
            } else {
                return this.paperAnswer.isEmpty() ? " " : this.paperAnswer;
            }
        }

        public String getEligContent() {
            if (this.eligContent == null) {
                return " ";
            } else {
                return this.eligContent.isEmpty() ? " " : this.eligContent;
            }
        }

        public Double getPaperScore() {
            return this.paperScore != null ? this.paperScore : 0.0D;
        }

        public String getCrdtLevel() {
            if (this.crdtLevel == null) {
                return " ";
            } else {
                return this.crdtLevel.isEmpty() ? " " : this.crdtLevel;
            }
        }

        public Double getCrdtScore() {
            return this.crdtScore != null ? this.crdtScore : 0.0D;
        }

        public Double getCrdtexScore() {
            return this.crdtexScore != null ? this.crdtexScore : 0.0D;
        }

        public String getCrdtexRemark() {
            if (this.crdtexRemark == null) {
                return " ";
            } else {
                return this.crdtexRemark.isEmpty() ? " " : this.crdtexRemark;
            }
        }

        public Double getCreditQuota() {
            return this.creditQuota != null ? this.creditQuota : 0.0D;
        }

        public Character getCrdtStatus() {
            return this.crdtStatus != null ? this.crdtStatus : ' ';
        }

        public Integer getBeginDate() {
            return this.beginDate != null ? this.beginDate : 0;
        }

        public Integer getEndDate() {
            return this.endDate != null ? this.endDate : 0;
        }

        public Integer getDateClear() {
            return this.dateClear != null ? this.dateClear : 0;
        }

        public String getRemark() {
            if (this.remark == null) {
                return " ";
            } else {
                return this.remark.isEmpty() ? " " : this.remark;
            }
        }

        public String getPositionStr() {
            if (this.positionStr == null) {
                return " ";
            } else {
                return this.positionStr.isEmpty() ? " " : this.positionStr;
            }
        }

        public Integer getTmpDateClear() {
            return this.tmpDateClear != null ? this.tmpDateClear : 0;
        }

        public Double getTotalApplyQuota() {
            return this.totalApplyQuota != null ? this.totalApplyQuota : 0.0D;
        }

        public Double getTmpCreditQuota() {
            return this.tmpCreditQuota != null ? this.tmpCreditQuota : 0.0D;
        }

        public String getReferee() {
            if (this.referee == null) {
                return " ";
            } else {
                return this.referee.isEmpty() ? " " : this.referee;
            }
        }

        public Integer getTmpBeginDate() {
            return this.tmpBeginDate != null ? this.tmpBeginDate : 0;
        }

        public Double getIntegralRate() {
            return this.integralRate != null ? this.integralRate : 0.0D;
        }

        public Integer getTmpEndDate() {
            return this.tmpEndDate != null ? this.tmpEndDate : 0;
        }

        public Double getAsset() {
            return this.asset != null ? this.asset : 0.0D;
        }

        public String getTmpCrdtLevel() {
            if (this.tmpCrdtLevel == null) {
                return " ";
            } else {
                return this.tmpCrdtLevel.isEmpty() ? " " : this.tmpCrdtLevel;
            }
        }

        public Double getDiffBalance() {
            return this.diffBalance != null ? this.diffBalance : 0.0D;
        }

        public Double getTmpCrdtScore() {
            return this.tmpCrdtScore != null ? this.tmpCrdtScore : 0.0D;
        }

        public Double getFinMaxQuota() {
            return this.finMaxQuota != null ? this.finMaxQuota : 0.0D;
        }

        public Double getCreditQuotaOld() {
            return this.creditQuotaOld != null ? this.creditQuotaOld : 0.0D;
        }

        public Double getSloMaxQuota() {
            return this.sloMaxQuota != null ? this.sloMaxQuota : 0.0D;
        }

        public Double getAccmdiffBalance() {
            return this.accmdiffBalance != null ? this.accmdiffBalance : 0.0D;
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public void setSerialNo(Long serialNo) {
            this.serialNo = serialNo;
        }

        public void setClientcrId(String clientcrId) {
            this.clientcrId = clientcrId;
        }

        public void setCurrDate(Integer currDate) {
            this.currDate = currDate;
        }

        public void setCurrTime(Integer currTime) {
            this.currTime = currTime;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setUnitycreditType(Character unitycreditType) {
            this.unitycreditType = unitycreditType;
        }

        public void setPaperType(String paperType) {
            this.paperType = paperType;
        }

        public void setOrganFlag(Character organFlag) {
            this.organFlag = organFlag;
        }

        public void setPaperAnswer(String paperAnswer) {
            this.paperAnswer = paperAnswer;
        }

        public void setEligContent(String eligContent) {
            this.eligContent = eligContent;
        }

        public void setPaperScore(Double paperScore) {
            this.paperScore = paperScore;
        }

        public void setCrdtLevel(String crdtLevel) {
            this.crdtLevel = crdtLevel;
        }

        public void setCrdtScore(Double crdtScore) {
            this.crdtScore = crdtScore;
        }

        public void setCrdtexScore(Double crdtexScore) {
            this.crdtexScore = crdtexScore;
        }

        public void setCrdtexRemark(String crdtexRemark) {
            this.crdtexRemark = crdtexRemark;
        }

        public void setCreditQuota(Double creditQuota) {
            this.creditQuota = creditQuota;
        }

        public void setCrdtStatus(Character crdtStatus) {
            this.crdtStatus = crdtStatus;
        }

        public void setBeginDate(Integer beginDate) {
            this.beginDate = beginDate;
        }

        public void setEndDate(Integer endDate) {
            this.endDate = endDate;
        }

        public void setDateClear(Integer dateClear) {
            this.dateClear = dateClear;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public void setPositionStr(String positionStr) {
            this.positionStr = positionStr;
        }

        public void setTmpDateClear(Integer tmpDateClear) {
            this.tmpDateClear = tmpDateClear;
        }

        public void setTotalApplyQuota(Double totalApplyQuota) {
            this.totalApplyQuota = totalApplyQuota;
        }

        public void setTmpCreditQuota(Double tmpCreditQuota) {
            this.tmpCreditQuota = tmpCreditQuota;
        }

        public void setReferee(String referee) {
            this.referee = referee;
        }

        public void setTmpBeginDate(Integer tmpBeginDate) {
            this.tmpBeginDate = tmpBeginDate;
        }

        public void setIntegralRate(Double integralRate) {
            this.integralRate = integralRate;
        }

        public void setTmpEndDate(Integer tmpEndDate) {
            this.tmpEndDate = tmpEndDate;
        }

        public void setAsset(Double asset) {
            this.asset = asset;
        }

        public void setTmpCrdtLevel(String tmpCrdtLevel) {
            this.tmpCrdtLevel = tmpCrdtLevel;
        }

        public void setDiffBalance(Double diffBalance) {
            this.diffBalance = diffBalance;
        }

        public void setTmpCrdtScore(Double tmpCrdtScore) {
            this.tmpCrdtScore = tmpCrdtScore;
        }

        public void setFinMaxQuota(Double finMaxQuota) {
            this.finMaxQuota = finMaxQuota;
        }

        public void setCreditQuotaOld(Double creditQuotaOld) {
            this.creditQuotaOld = creditQuotaOld;
        }

        public void setSloMaxQuota(Double sloMaxQuota) {
            this.sloMaxQuota = sloMaxQuota;
        }

        public void setAccmdiffBalance(Double accmdiffBalance) {
            this.accmdiffBalance = accmdiffBalance;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetUnitycreditClientcrdtInnerOutput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",initDate:" + this.initDate);
            buffer.append(",serialNo:" + this.serialNo);
            buffer.append(",clientcrId:" + this.clientcrId);
            buffer.append(",currDate:" + this.currDate);
            buffer.append(",currTime:" + this.currTime);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",unitycreditType:" + this.unitycreditType);
            buffer.append(",paperType:" + this.paperType);
            buffer.append(",organFlag:" + this.organFlag);
            buffer.append(",paperAnswer:" + this.paperAnswer);
            buffer.append(",eligContent:" + this.eligContent);
            buffer.append(",paperScore:" + this.paperScore);
            buffer.append(",crdtLevel:" + this.crdtLevel);
            buffer.append(",crdtScore:" + this.crdtScore);
            buffer.append(",crdtexScore:" + this.crdtexScore);
            buffer.append(",crdtexRemark:" + this.crdtexRemark);
            buffer.append(",creditQuota:" + this.creditQuota);
            buffer.append(",crdtStatus:" + this.crdtStatus);
            buffer.append(",beginDate:" + this.beginDate);
            buffer.append(",endDate:" + this.endDate);
            buffer.append(",dateClear:" + this.dateClear);
            buffer.append(",remark:" + this.remark);
            buffer.append(",positionStr:" + this.positionStr);
            buffer.append(",tmpDateClear:" + this.tmpDateClear);
            buffer.append(",totalApplyQuota:" + this.totalApplyQuota);
            buffer.append(",tmpCreditQuota:" + this.tmpCreditQuota);
            buffer.append(",referee:" + this.referee);
            buffer.append(",tmpBeginDate:" + this.tmpBeginDate);
            buffer.append(",integralRate:" + this.integralRate);
            buffer.append(",tmpEndDate:" + this.tmpEndDate);
            buffer.append(",asset:" + this.asset);
            buffer.append(",tmpCrdtLevel:" + this.tmpCrdtLevel);
            buffer.append(",diffBalance:" + this.diffBalance);
            buffer.append(",tmpCrdtScore:" + this.tmpCrdtScore);
            buffer.append(",finMaxQuota:" + this.finMaxQuota);
            buffer.append(",creditQuotaOld:" + this.creditQuotaOld);
            buffer.append(",sloMaxQuota:" + this.sloMaxQuota);
            buffer.append(",accmdiffBalance:" + this.accmdiffBalance);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.initDate);
            builder.append(this.serialNo);
            builder.append(this.clientcrId);
            builder.append(this.currDate);
            builder.append(this.currTime);
            builder.append(this.operatorNo);
            builder.append(this.opEntrustWay);
            builder.append(this.clientId);
            builder.append(this.unitycreditType);
            builder.append(this.paperType);
            builder.append(this.organFlag);
            builder.append(this.paperAnswer);
            builder.append(this.eligContent);
            builder.append(this.paperScore);
            builder.append(this.crdtLevel);
            builder.append(this.crdtScore);
            builder.append(this.crdtexScore);
            builder.append(this.crdtexRemark);
            builder.append(this.creditQuota);
            builder.append(this.crdtStatus);
            builder.append(this.beginDate);
            builder.append(this.endDate);
            builder.append(this.dateClear);
            builder.append(this.remark);
            builder.append(this.positionStr);
            builder.append(this.tmpDateClear);
            builder.append(this.totalApplyQuota);
            builder.append(this.tmpCreditQuota);
            builder.append(this.referee);
            builder.append(this.tmpBeginDate);
            builder.append(this.integralRate);
            builder.append(this.tmpEndDate);
            builder.append(this.asset);
            builder.append(this.tmpCrdtLevel);
            builder.append(this.diffBalance);
            builder.append(this.tmpCrdtScore);
            builder.append(this.finMaxQuota);
            builder.append(this.creditQuotaOld);
            builder.append(this.sloMaxQuota);
            builder.append(this.accmdiffBalance);
            builder.append(this.opStation);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.GetUnitycreditClientcrdtInnerOutput) {
                InnerElgService.GetUnitycreditClientcrdtInnerOutput test = (InnerElgService.GetUnitycreditClientcrdtInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.initDate, test.initDate);
                builder.append(this.serialNo, test.serialNo);
                builder.append(this.clientcrId, test.clientcrId);
                builder.append(this.currDate, test.currDate);
                builder.append(this.currTime, test.currTime);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.clientId, test.clientId);
                builder.append(this.unitycreditType, test.unitycreditType);
                builder.append(this.paperType, test.paperType);
                builder.append(this.organFlag, test.organFlag);
                builder.append(this.paperAnswer, test.paperAnswer);
                builder.append(this.eligContent, test.eligContent);
                builder.append(this.paperScore, test.paperScore);
                builder.append(this.crdtLevel, test.crdtLevel);
                builder.append(this.crdtScore, test.crdtScore);
                builder.append(this.crdtexScore, test.crdtexScore);
                builder.append(this.crdtexRemark, test.crdtexRemark);
                builder.append(this.creditQuota, test.creditQuota);
                builder.append(this.crdtStatus, test.crdtStatus);
                builder.append(this.beginDate, test.beginDate);
                builder.append(this.endDate, test.endDate);
                builder.append(this.dateClear, test.dateClear);
                builder.append(this.remark, test.remark);
                builder.append(this.positionStr, test.positionStr);
                builder.append(this.tmpDateClear, test.tmpDateClear);
                builder.append(this.totalApplyQuota, test.totalApplyQuota);
                builder.append(this.tmpCreditQuota, test.tmpCreditQuota);
                builder.append(this.referee, test.referee);
                builder.append(this.tmpBeginDate, test.tmpBeginDate);
                builder.append(this.integralRate, test.integralRate);
                builder.append(this.tmpEndDate, test.tmpEndDate);
                builder.append(this.asset, test.asset);
                builder.append(this.tmpCrdtLevel, test.tmpCrdtLevel);
                builder.append(this.diffBalance, test.diffBalance);
                builder.append(this.tmpCrdtScore, test.tmpCrdtScore);
                builder.append(this.finMaxQuota, test.finMaxQuota);
                builder.append(this.creditQuotaOld, test.creditQuotaOld);
                builder.append(this.sloMaxQuota, test.sloMaxQuota);
                builder.append(this.accmdiffBalance, test.accmdiffBalance);
                builder.append(this.opStation, test.opStation);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetUnitycreditClientcrdtInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer branchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String clientId = " ";
        @SinogramLength(
                min = 0,
                max = 500,
                charset = "utf-8"
        )
        private String enPaperType = " ";
        @SinogramLength(
                min = 0,
                max = 100,
                charset = "utf-8"
        )
        private String positionStr = " ";
        private Integer requestNum = 0;
        private Integer beginDate = 0;
        private Integer endDate = 0;
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String enCrdtStatus = " ";
        private Integer actionIn = 0;
        @SinogramLength(
                min = 0,
                max = 4000,
                charset = "utf-8"
        )
        private String enBranchNo = " ";
        @SinogramLength(
                min = 0,
                max = 20,
                charset = "utf-8"
        )
        private String enOrganFlag = " ";

        public GetUnitycreditClientcrdtInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getEnPaperType() {
            if (this.enPaperType == null) {
                return " ";
            } else {
                return this.enPaperType.isEmpty() ? " " : this.enPaperType;
            }
        }

        public String getPositionStr() {
            if (this.positionStr == null) {
                return " ";
            } else {
                return this.positionStr.isEmpty() ? " " : this.positionStr;
            }
        }

        public Integer getRequestNum() {
            return this.requestNum != null ? this.requestNum : 0;
        }

        public Integer getBeginDate() {
            return this.beginDate != null ? this.beginDate : 0;
        }

        public Integer getEndDate() {
            return this.endDate != null ? this.endDate : 0;
        }

        public String getEnCrdtStatus() {
            if (this.enCrdtStatus == null) {
                return " ";
            } else {
                return this.enCrdtStatus.isEmpty() ? " " : this.enCrdtStatus;
            }
        }

        public Integer getActionIn() {
            return this.actionIn != null ? this.actionIn : 0;
        }

        public String getEnBranchNo() {
            if (this.enBranchNo == null) {
                return " ";
            } else {
                return this.enBranchNo.isEmpty() ? " " : this.enBranchNo;
            }
        }

        public String getEnOrganFlag() {
            if (this.enOrganFlag == null) {
                return " ";
            } else {
                return this.enOrganFlag.isEmpty() ? " " : this.enOrganFlag;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setEnPaperType(String enPaperType) {
            this.enPaperType = enPaperType;
        }

        public void setPositionStr(String positionStr) {
            this.positionStr = positionStr;
        }

        public void setRequestNum(Integer requestNum) {
            this.requestNum = requestNum;
        }

        public void setBeginDate(Integer beginDate) {
            this.beginDate = beginDate;
        }

        public void setEndDate(Integer endDate) {
            this.endDate = endDate;
        }

        public void setEnCrdtStatus(String enCrdtStatus) {
            this.enCrdtStatus = enCrdtStatus;
        }

        public void setActionIn(Integer actionIn) {
            this.actionIn = actionIn;
        }

        public void setEnBranchNo(String enBranchNo) {
            this.enBranchNo = enBranchNo;
        }

        public void setEnOrganFlag(String enOrganFlag) {
            this.enOrganFlag = enOrganFlag;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetUnitycreditClientcrdtInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",enPaperType:" + this.enPaperType);
            buffer.append(",positionStr:" + this.positionStr);
            buffer.append(",requestNum:" + this.requestNum);
            buffer.append(",beginDate:" + this.beginDate);
            buffer.append(",endDate:" + this.endDate);
            buffer.append(",enCrdtStatus:" + this.enCrdtStatus);
            buffer.append(",actionIn:" + this.actionIn);
            buffer.append(",enBranchNo:" + this.enBranchNo);
            buffer.append(",enOrganFlag:" + this.enOrganFlag);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.branchNo);
            builder.append(this.clientId);
            builder.append(this.enPaperType);
            builder.append(this.positionStr);
            builder.append(this.requestNum);
            builder.append(this.beginDate);
            builder.append(this.endDate);
            builder.append(this.enCrdtStatus);
            builder.append(this.actionIn);
            builder.append(this.enBranchNo);
            builder.append(this.enOrganFlag);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.GetUnitycreditClientcrdtInnerInput) {
                InnerElgService.GetUnitycreditClientcrdtInnerInput test = (InnerElgService.GetUnitycreditClientcrdtInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.clientId, test.clientId);
                builder.append(this.enPaperType, test.enPaperType);
                builder.append(this.positionStr, test.positionStr);
                builder.append(this.requestNum, test.requestNum);
                builder.append(this.beginDate, test.beginDate);
                builder.append(this.endDate, test.endDate);
                builder.append(this.enCrdtStatus, test.enCrdtStatus);
                builder.append(this.actionIn, test.actionIn);
                builder.append(this.enBranchNo, test.enBranchNo);
                builder.append(this.enOrganFlag, test.enOrganFlag);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetProdAgreementInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer initDate = 0;
        private Integer signDate = 0;
        private String clientId = " ";
        private String fundAccount = " ";
        private String agreeType = " ";
        private String agreementId = " ";
        private String agreementVersion = " ";
        private String templateDir = " ";
        private String registerContent = " ";
        private Integer csfcEndDate = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character financeType = ' ';
        private String prodtaNo = " ";
        private String prodCode = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character prodcodeType = ' ';
        private String prodcodeSubType = " ";
        private String acptId = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character certType = ' ';
        private String certSign = " ";
        private String certOriginal = " ";
        private String remark = " ";
        private String positionStr = " ";
        private Integer signTime = 0;
        private Integer csfcBeginDate = 0;

        public GetProdAgreementInnerOutput() {
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public Integer getSignDate() {
            return this.signDate != null ? this.signDate : 0;
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getAgreeType() {
            if (this.agreeType == null) {
                return " ";
            } else {
                return this.agreeType.isEmpty() ? " " : this.agreeType;
            }
        }

        public String getAgreementId() {
            if (this.agreementId == null) {
                return " ";
            } else {
                return this.agreementId.isEmpty() ? " " : this.agreementId;
            }
        }

        public String getAgreementVersion() {
            if (this.agreementVersion == null) {
                return " ";
            } else {
                return this.agreementVersion.isEmpty() ? " " : this.agreementVersion;
            }
        }

        public String getTemplateDir() {
            if (this.templateDir == null) {
                return " ";
            } else {
                return this.templateDir.isEmpty() ? " " : this.templateDir;
            }
        }

        public String getRegisterContent() {
            if (this.registerContent == null) {
                return " ";
            } else {
                return this.registerContent.isEmpty() ? " " : this.registerContent;
            }
        }

        public Integer getCsfcEndDate() {
            return this.csfcEndDate != null ? this.csfcEndDate : 0;
        }

        public Character getFinanceType() {
            return this.financeType != null ? this.financeType : ' ';
        }

        public String getProdtaNo() {
            if (this.prodtaNo == null) {
                return " ";
            } else {
                return this.prodtaNo.isEmpty() ? " " : this.prodtaNo;
            }
        }

        public String getProdCode() {
            if (this.prodCode == null) {
                return " ";
            } else {
                return this.prodCode.isEmpty() ? " " : this.prodCode;
            }
        }

        public Character getProdcodeType() {
            return this.prodcodeType != null ? this.prodcodeType : ' ';
        }

        public String getProdcodeSubType() {
            if (this.prodcodeSubType == null) {
                return " ";
            } else {
                return this.prodcodeSubType.isEmpty() ? " " : this.prodcodeSubType;
            }
        }

        public String getAcptId() {
            if (this.acptId == null) {
                return " ";
            } else {
                return this.acptId.isEmpty() ? " " : this.acptId;
            }
        }

        public Character getCertType() {
            return this.certType != null ? this.certType : ' ';
        }

        public String getCertSign() {
            if (this.certSign == null) {
                return " ";
            } else {
                return this.certSign.isEmpty() ? " " : this.certSign;
            }
        }

        public String getCertOriginal() {
            if (this.certOriginal == null) {
                return " ";
            } else {
                return this.certOriginal.isEmpty() ? " " : this.certOriginal;
            }
        }

        public String getRemark() {
            if (this.remark == null) {
                return " ";
            } else {
                return this.remark.isEmpty() ? " " : this.remark;
            }
        }

        public String getPositionStr() {
            if (this.positionStr == null) {
                return " ";
            } else {
                return this.positionStr.isEmpty() ? " " : this.positionStr;
            }
        }

        public Integer getSignTime() {
            return this.signTime != null ? this.signTime : 0;
        }

        public Integer getCsfcBeginDate() {
            return this.csfcBeginDate != null ? this.csfcBeginDate : 0;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public void setSignDate(Integer signDate) {
            this.signDate = signDate;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setAgreeType(String agreeType) {
            this.agreeType = agreeType;
        }

        public void setAgreementId(String agreementId) {
            this.agreementId = agreementId;
        }

        public void setAgreementVersion(String agreementVersion) {
            this.agreementVersion = agreementVersion;
        }

        public void setTemplateDir(String templateDir) {
            this.templateDir = templateDir;
        }

        public void setRegisterContent(String registerContent) {
            this.registerContent = registerContent;
        }

        public void setCsfcEndDate(Integer csfcEndDate) {
            this.csfcEndDate = csfcEndDate;
        }

        public void setFinanceType(Character financeType) {
            this.financeType = financeType;
        }

        public void setProdtaNo(String prodtaNo) {
            this.prodtaNo = prodtaNo;
        }

        public void setProdCode(String prodCode) {
            this.prodCode = prodCode;
        }

        public void setProdcodeType(Character prodcodeType) {
            this.prodcodeType = prodcodeType;
        }

        public void setProdcodeSubType(String prodcodeSubType) {
            this.prodcodeSubType = prodcodeSubType;
        }

        public void setAcptId(String acptId) {
            this.acptId = acptId;
        }

        public void setCertType(Character certType) {
            this.certType = certType;
        }

        public void setCertSign(String certSign) {
            this.certSign = certSign;
        }

        public void setCertOriginal(String certOriginal) {
            this.certOriginal = certOriginal;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public void setPositionStr(String positionStr) {
            this.positionStr = positionStr;
        }

        public void setSignTime(Integer signTime) {
            this.signTime = signTime;
        }

        public void setCsfcBeginDate(Integer csfcBeginDate) {
            this.csfcBeginDate = csfcBeginDate;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetProdAgreementInnerOutput:(");
            buffer.append("initDate:" + this.initDate);
            buffer.append(",signDate:" + this.signDate);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",agreeType:" + this.agreeType);
            buffer.append(",agreementId:" + this.agreementId);
            buffer.append(",agreementVersion:" + this.agreementVersion);
            buffer.append(",templateDir:" + this.templateDir);
            buffer.append(",registerContent:" + this.registerContent);
            buffer.append(",csfcEndDate:" + this.csfcEndDate);
            buffer.append(",financeType:" + this.financeType);
            buffer.append(",prodtaNo:" + this.prodtaNo);
            buffer.append(",prodCode:" + this.prodCode);
            buffer.append(",prodcodeType:" + this.prodcodeType);
            buffer.append(",prodcodeSubType:" + this.prodcodeSubType);
            buffer.append(",acptId:" + this.acptId);
            buffer.append(",certType:" + this.certType);
            buffer.append(",certSign:" + this.certSign);
            buffer.append(",certOriginal:" + this.certOriginal);
            buffer.append(",remark:" + this.remark);
            buffer.append(",positionStr:" + this.positionStr);
            buffer.append(",signTime:" + this.signTime);
            buffer.append(",csfcBeginDate:" + this.csfcBeginDate);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.initDate);
            builder.append(this.signDate);
            builder.append(this.clientId);
            builder.append(this.fundAccount);
            builder.append(this.agreeType);
            builder.append(this.agreementId);
            builder.append(this.agreementVersion);
            builder.append(this.templateDir);
            builder.append(this.registerContent);
            builder.append(this.csfcEndDate);
            builder.append(this.financeType);
            builder.append(this.prodtaNo);
            builder.append(this.prodCode);
            builder.append(this.prodcodeType);
            builder.append(this.prodcodeSubType);
            builder.append(this.acptId);
            builder.append(this.certType);
            builder.append(this.certSign);
            builder.append(this.certOriginal);
            builder.append(this.remark);
            builder.append(this.positionStr);
            builder.append(this.signTime);
            builder.append(this.csfcBeginDate);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.GetProdAgreementInnerOutput) {
                InnerElgService.GetProdAgreementInnerOutput test = (InnerElgService.GetProdAgreementInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.initDate, test.initDate);
                builder.append(this.signDate, test.signDate);
                builder.append(this.clientId, test.clientId);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.agreeType, test.agreeType);
                builder.append(this.agreementId, test.agreementId);
                builder.append(this.agreementVersion, test.agreementVersion);
                builder.append(this.templateDir, test.templateDir);
                builder.append(this.registerContent, test.registerContent);
                builder.append(this.csfcEndDate, test.csfcEndDate);
                builder.append(this.financeType, test.financeType);
                builder.append(this.prodtaNo, test.prodtaNo);
                builder.append(this.prodCode, test.prodCode);
                builder.append(this.prodcodeType, test.prodcodeType);
                builder.append(this.prodcodeSubType, test.prodcodeSubType);
                builder.append(this.acptId, test.acptId);
                builder.append(this.certType, test.certType);
                builder.append(this.certSign, test.certSign);
                builder.append(this.certOriginal, test.certOriginal);
                builder.append(this.remark, test.remark);
                builder.append(this.positionStr, test.positionStr);
                builder.append(this.signTime, test.signTime);
                builder.append(this.csfcBeginDate, test.csfcBeginDate);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetProdAgreementInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer branchNo = 0;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fundAccount = " ";
        @SinogramLength(
                min = 0,
                max = 24,
                charset = "utf-8"
        )
        private String prodtaNo = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String prodCode = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character prodcodeType = ' ';
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String prodcodeSubType = " ";
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String agreeType = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String agreementId = " ";
        private Integer pageNo = 0;
        private Integer pageSize = 0;
        private Integer requestNum = 0;

        public GetProdAgreementInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getProdtaNo() {
            if (this.prodtaNo == null) {
                return " ";
            } else {
                return this.prodtaNo.isEmpty() ? " " : this.prodtaNo;
            }
        }

        public String getProdCode() {
            if (this.prodCode == null) {
                return " ";
            } else {
                return this.prodCode.isEmpty() ? " " : this.prodCode;
            }
        }

        public Character getProdcodeType() {
            return this.prodcodeType != null ? this.prodcodeType : ' ';
        }

        public String getProdcodeSubType() {
            if (this.prodcodeSubType == null) {
                return " ";
            } else {
                return this.prodcodeSubType.isEmpty() ? " " : this.prodcodeSubType;
            }
        }

        public String getAgreeType() {
            if (this.agreeType == null) {
                return " ";
            } else {
                return this.agreeType.isEmpty() ? " " : this.agreeType;
            }
        }

        public String getAgreementId() {
            if (this.agreementId == null) {
                return " ";
            } else {
                return this.agreementId.isEmpty() ? " " : this.agreementId;
            }
        }

        public Integer getPageNo() {
            return this.pageNo != null ? this.pageNo : 0;
        }

        public Integer getPageSize() {
            return this.pageSize != null ? this.pageSize : 0;
        }

        public Integer getRequestNum() {
            return this.requestNum != null ? this.requestNum : 0;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setProdtaNo(String prodtaNo) {
            this.prodtaNo = prodtaNo;
        }

        public void setProdCode(String prodCode) {
            this.prodCode = prodCode;
        }

        public void setProdcodeType(Character prodcodeType) {
            this.prodcodeType = prodcodeType;
        }

        public void setProdcodeSubType(String prodcodeSubType) {
            this.prodcodeSubType = prodcodeSubType;
        }

        public void setAgreeType(String agreeType) {
            this.agreeType = agreeType;
        }

        public void setAgreementId(String agreementId) {
            this.agreementId = agreementId;
        }

        public void setPageNo(Integer pageNo) {
            this.pageNo = pageNo;
        }

        public void setPageSize(Integer pageSize) {
            this.pageSize = pageSize;
        }

        public void setRequestNum(Integer requestNum) {
            this.requestNum = requestNum;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetProdAgreementInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",prodtaNo:" + this.prodtaNo);
            buffer.append(",prodCode:" + this.prodCode);
            buffer.append(",prodcodeType:" + this.prodcodeType);
            buffer.append(",prodcodeSubType:" + this.prodcodeSubType);
            buffer.append(",agreeType:" + this.agreeType);
            buffer.append(",agreementId:" + this.agreementId);
            buffer.append(",pageNo:" + this.pageNo);
            buffer.append(",pageSize:" + this.pageSize);
            buffer.append(",requestNum:" + this.requestNum);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.branchNo);
            builder.append(this.clientId);
            builder.append(this.fundAccount);
            builder.append(this.prodtaNo);
            builder.append(this.prodCode);
            builder.append(this.prodcodeType);
            builder.append(this.prodcodeSubType);
            builder.append(this.agreeType);
            builder.append(this.agreementId);
            builder.append(this.pageNo);
            builder.append(this.pageSize);
            builder.append(this.requestNum);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.GetProdAgreementInnerInput) {
                InnerElgService.GetProdAgreementInnerInput test = (InnerElgService.GetProdAgreementInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.clientId, test.clientId);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.prodtaNo, test.prodtaNo);
                builder.append(this.prodCode, test.prodCode);
                builder.append(this.prodcodeType, test.prodcodeType);
                builder.append(this.prodcodeSubType, test.prodcodeSubType);
                builder.append(this.agreeType, test.agreeType);
                builder.append(this.agreementId, test.agreementId);
                builder.append(this.pageNo, test.pageNo);
                builder.append(this.pageSize, test.pageSize);
                builder.append(this.requestNum, test.requestNum);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostProdAgreementInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String agreementId = " ";

        public PostProdAgreementInnerOutput() {
        }

        public String getAgreementId() {
            if (this.agreementId == null) {
                return " ";
            } else {
                return this.agreementId.isEmpty() ? " " : this.agreementId;
            }
        }

        public void setAgreementId(String agreementId) {
            this.agreementId = agreementId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostProdAgreementInnerOutput:(");
            buffer.append("agreementId:" + this.agreementId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.agreementId);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.PostProdAgreementInnerOutput) {
                InnerElgService.PostProdAgreementInnerOutput test = (InnerElgService.PostProdAgreementInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.agreementId, test.agreementId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostProdAgreementInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer branchNo = 0;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId = " ";
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String fundAccount = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character financeType = ' ';
        @SinogramLength(
                min = 1,
                max = 24,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String prodtaNo = " ";
        @SinogramLength(
                min = 1,
                max = 32,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String prodCode = " ";
        @SinogramLength(
                min = 1,
                max = 4,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String prodcodeSubType = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character prodcodeType = ' ';
        @SinogramLength(
                min = 1,
                max = 4,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String agreeType = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String registerContent = " ";
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String entrustProp = " ";

        public PostProdAgreementInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public Character getFinanceType() {
            return this.financeType != null ? this.financeType : ' ';
        }

        public String getProdtaNo() {
            if (this.prodtaNo == null) {
                return " ";
            } else {
                return this.prodtaNo.isEmpty() ? " " : this.prodtaNo;
            }
        }

        public String getProdCode() {
            if (this.prodCode == null) {
                return " ";
            } else {
                return this.prodCode.isEmpty() ? " " : this.prodCode;
            }
        }

        public String getProdcodeSubType() {
            if (this.prodcodeSubType == null) {
                return " ";
            } else {
                return this.prodcodeSubType.isEmpty() ? " " : this.prodcodeSubType;
            }
        }

        public Character getProdcodeType() {
            return this.prodcodeType != null ? this.prodcodeType : ' ';
        }

        public String getAgreeType() {
            if (this.agreeType == null) {
                return " ";
            } else {
                return this.agreeType.isEmpty() ? " " : this.agreeType;
            }
        }

        public String getRegisterContent() {
            if (this.registerContent == null) {
                return " ";
            } else {
                return this.registerContent.isEmpty() ? " " : this.registerContent;
            }
        }

        public String getEntrustProp() {
            if (this.entrustProp == null) {
                return " ";
            } else {
                return this.entrustProp.isEmpty() ? " " : this.entrustProp;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setFinanceType(Character financeType) {
            this.financeType = financeType;
        }

        public void setProdtaNo(String prodtaNo) {
            this.prodtaNo = prodtaNo;
        }

        public void setProdCode(String prodCode) {
            this.prodCode = prodCode;
        }

        public void setProdcodeSubType(String prodcodeSubType) {
            this.prodcodeSubType = prodcodeSubType;
        }

        public void setProdcodeType(Character prodcodeType) {
            this.prodcodeType = prodcodeType;
        }

        public void setAgreeType(String agreeType) {
            this.agreeType = agreeType;
        }

        public void setRegisterContent(String registerContent) {
            this.registerContent = registerContent;
        }

        public void setEntrustProp(String entrustProp) {
            this.entrustProp = entrustProp;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostProdAgreementInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",financeType:" + this.financeType);
            buffer.append(",prodtaNo:" + this.prodtaNo);
            buffer.append(",prodCode:" + this.prodCode);
            buffer.append(",prodcodeSubType:" + this.prodcodeSubType);
            buffer.append(",prodcodeType:" + this.prodcodeType);
            buffer.append(",agreeType:" + this.agreeType);
            buffer.append(",registerContent:" + this.registerContent);
            buffer.append(",entrustProp:" + this.entrustProp);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.branchNo);
            builder.append(this.clientId);
            builder.append(this.fundAccount);
            builder.append(this.financeType);
            builder.append(this.prodtaNo);
            builder.append(this.prodCode);
            builder.append(this.prodcodeSubType);
            builder.append(this.prodcodeType);
            builder.append(this.agreeType);
            builder.append(this.registerContent);
            builder.append(this.entrustProp);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.PostProdAgreementInnerInput) {
                InnerElgService.PostProdAgreementInnerInput test = (InnerElgService.PostProdAgreementInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.clientId, test.clientId);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.financeType, test.financeType);
                builder.append(this.prodtaNo, test.prodtaNo);
                builder.append(this.prodCode, test.prodCode);
                builder.append(this.prodcodeSubType, test.prodcodeSubType);
                builder.append(this.prodcodeType, test.prodcodeType);
                builder.append(this.agreeType, test.agreeType);
                builder.append(this.registerContent, test.registerContent);
                builder.append(this.entrustProp, test.entrustProp);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class OptclientinfoDTO implements Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String clientId = " ";
        @SinogramLength(
                min = 0,
                max = 90,
                charset = "utf-8"
        )
        private String clientName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character organFlag = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character optLevel = ' ';
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String remark = " ";
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String exchangeType = " ";
        @Digits(
                integer = 13,
                fraction = 2,
                message = "firstLevelScore value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double firstLevelScore = 0.0D;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "secondLevelScore value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double secondLevelScore = 0.0D;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "thirdLevelScore value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double thirdLevelScore = 0.0D;
        private Integer firstLevelDate = 0;
        private Integer secondLevelDate = 0;
        private Integer thirdLevelDate = 0;
        private Integer regDate = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character crdtExistsFlag = ' ';
        private Integer spifFirstExchdate = 0;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "marketValue value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double marketValue = 0.0D;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "bailBalance value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double bailBalance = 0.0D;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character simulateTradeFlag = ' ';
        private Integer subRiskDate = 0;
        private Integer honestPromiseDate = 0;
        private Integer riskBeginDate = 0;
        private Integer riskEndDate = 0;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "purApplyQuota value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double purApplyQuota = 0.0D;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "totalAsset value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double totalAsset = 0.0D;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "avgMarketValue value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double avgMarketValue = 0.0D;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "compositeScore value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double compositeScore = 0.0D;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character financialTradeFlag = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character firstSimulateTradeFlag = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character secondSimulateTradeFlag = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character thirdSimulateTradeFlag = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character optFirstopenFlag = ' ';
        @Digits(
                integer = 13,
                fraction = 2,
                message = "avgAsset value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double avgAsset = 0.0D;
        @SinogramLength(
                min = 0,
                max = 10,
                charset = "utf-8"
        )
        private String optholdLimitNo = " ";
        private Integer branchNo = 0;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "限购审批额度【purAuditQuota】 超出精度范围, 最大整数位为【13】, 小数位为【2】"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double purAuditQuota = 0.0D;

        public OptclientinfoDTO() {
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getClientName() {
            if (this.clientName == null) {
                return " ";
            } else {
                return this.clientName.isEmpty() ? " " : this.clientName;
            }
        }

        public Character getOrganFlag() {
            return this.organFlag != null ? this.organFlag : ' ';
        }

        public Character getOptLevel() {
            return this.optLevel != null ? this.optLevel : ' ';
        }

        public String getRemark() {
            if (this.remark == null) {
                return " ";
            } else {
                return this.remark.isEmpty() ? " " : this.remark;
            }
        }

        public String getExchangeType() {
            if (this.exchangeType == null) {
                return " ";
            } else {
                return this.exchangeType.isEmpty() ? " " : this.exchangeType;
            }
        }

        public Double getFirstLevelScore() {
            return this.firstLevelScore != null ? this.firstLevelScore : 0.0D;
        }

        public Double getSecondLevelScore() {
            return this.secondLevelScore != null ? this.secondLevelScore : 0.0D;
        }

        public Double getThirdLevelScore() {
            return this.thirdLevelScore != null ? this.thirdLevelScore : 0.0D;
        }

        public Integer getFirstLevelDate() {
            return this.firstLevelDate != null ? this.firstLevelDate : 0;
        }

        public Integer getSecondLevelDate() {
            return this.secondLevelDate != null ? this.secondLevelDate : 0;
        }

        public Integer getThirdLevelDate() {
            return this.thirdLevelDate != null ? this.thirdLevelDate : 0;
        }

        public Integer getRegDate() {
            return this.regDate != null ? this.regDate : 0;
        }

        public Character getCrdtExistsFlag() {
            return this.crdtExistsFlag != null ? this.crdtExistsFlag : ' ';
        }

        public Integer getSpifFirstExchdate() {
            return this.spifFirstExchdate != null ? this.spifFirstExchdate : 0;
        }

        public Double getMarketValue() {
            return this.marketValue != null ? this.marketValue : 0.0D;
        }

        public Double getBailBalance() {
            return this.bailBalance != null ? this.bailBalance : 0.0D;
        }

        public Character getSimulateTradeFlag() {
            return this.simulateTradeFlag != null ? this.simulateTradeFlag : ' ';
        }

        public Integer getSubRiskDate() {
            return this.subRiskDate != null ? this.subRiskDate : 0;
        }

        public Integer getHonestPromiseDate() {
            return this.honestPromiseDate != null ? this.honestPromiseDate : 0;
        }

        public Integer getRiskBeginDate() {
            return this.riskBeginDate != null ? this.riskBeginDate : 0;
        }

        public Integer getRiskEndDate() {
            return this.riskEndDate != null ? this.riskEndDate : 0;
        }

        public Double getPurApplyQuota() {
            return this.purApplyQuota != null ? this.purApplyQuota : 0.0D;
        }

        public Double getTotalAsset() {
            return this.totalAsset != null ? this.totalAsset : 0.0D;
        }

        public Double getAvgMarketValue() {
            return this.avgMarketValue != null ? this.avgMarketValue : 0.0D;
        }

        public Double getCompositeScore() {
            return this.compositeScore != null ? this.compositeScore : 0.0D;
        }

        public Character getFinancialTradeFlag() {
            return this.financialTradeFlag != null ? this.financialTradeFlag : ' ';
        }

        public Character getFirstSimulateTradeFlag() {
            return this.firstSimulateTradeFlag != null ? this.firstSimulateTradeFlag : ' ';
        }

        public Character getSecondSimulateTradeFlag() {
            return this.secondSimulateTradeFlag != null ? this.secondSimulateTradeFlag : ' ';
        }

        public Character getThirdSimulateTradeFlag() {
            return this.thirdSimulateTradeFlag != null ? this.thirdSimulateTradeFlag : ' ';
        }

        public Character getOptFirstopenFlag() {
            return this.optFirstopenFlag != null ? this.optFirstopenFlag : ' ';
        }

        public Double getAvgAsset() {
            return this.avgAsset != null ? this.avgAsset : 0.0D;
        }

        public String getOptholdLimitNo() {
            if (this.optholdLimitNo == null) {
                return " ";
            } else {
                return this.optholdLimitNo.isEmpty() ? " " : this.optholdLimitNo;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Double getPurAuditQuota() {
            return this.purAuditQuota != null ? this.purAuditQuota : 0.0D;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setClientName(String clientName) {
            this.clientName = clientName;
        }

        public void setOrganFlag(Character organFlag) {
            this.organFlag = organFlag;
        }

        public void setOptLevel(Character optLevel) {
            this.optLevel = optLevel;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public void setFirstLevelScore(Double firstLevelScore) {
            this.firstLevelScore = firstLevelScore;
        }

        public void setSecondLevelScore(Double secondLevelScore) {
            this.secondLevelScore = secondLevelScore;
        }

        public void setThirdLevelScore(Double thirdLevelScore) {
            this.thirdLevelScore = thirdLevelScore;
        }

        public void setFirstLevelDate(Integer firstLevelDate) {
            this.firstLevelDate = firstLevelDate;
        }

        public void setSecondLevelDate(Integer secondLevelDate) {
            this.secondLevelDate = secondLevelDate;
        }

        public void setThirdLevelDate(Integer thirdLevelDate) {
            this.thirdLevelDate = thirdLevelDate;
        }

        public void setRegDate(Integer regDate) {
            this.regDate = regDate;
        }

        public void setCrdtExistsFlag(Character crdtExistsFlag) {
            this.crdtExistsFlag = crdtExistsFlag;
        }

        public void setSpifFirstExchdate(Integer spifFirstExchdate) {
            this.spifFirstExchdate = spifFirstExchdate;
        }

        public void setMarketValue(Double marketValue) {
            this.marketValue = marketValue;
        }

        public void setBailBalance(Double bailBalance) {
            this.bailBalance = bailBalance;
        }

        public void setSimulateTradeFlag(Character simulateTradeFlag) {
            this.simulateTradeFlag = simulateTradeFlag;
        }

        public void setSubRiskDate(Integer subRiskDate) {
            this.subRiskDate = subRiskDate;
        }

        public void setHonestPromiseDate(Integer honestPromiseDate) {
            this.honestPromiseDate = honestPromiseDate;
        }

        public void setRiskBeginDate(Integer riskBeginDate) {
            this.riskBeginDate = riskBeginDate;
        }

        public void setRiskEndDate(Integer riskEndDate) {
            this.riskEndDate = riskEndDate;
        }

        public void setPurApplyQuota(Double purApplyQuota) {
            this.purApplyQuota = purApplyQuota;
        }

        public void setTotalAsset(Double totalAsset) {
            this.totalAsset = totalAsset;
        }

        public void setAvgMarketValue(Double avgMarketValue) {
            this.avgMarketValue = avgMarketValue;
        }

        public void setCompositeScore(Double compositeScore) {
            this.compositeScore = compositeScore;
        }

        public void setFinancialTradeFlag(Character financialTradeFlag) {
            this.financialTradeFlag = financialTradeFlag;
        }

        public void setFirstSimulateTradeFlag(Character firstSimulateTradeFlag) {
            this.firstSimulateTradeFlag = firstSimulateTradeFlag;
        }

        public void setSecondSimulateTradeFlag(Character secondSimulateTradeFlag) {
            this.secondSimulateTradeFlag = secondSimulateTradeFlag;
        }

        public void setThirdSimulateTradeFlag(Character thirdSimulateTradeFlag) {
            this.thirdSimulateTradeFlag = thirdSimulateTradeFlag;
        }

        public void setOptFirstopenFlag(Character optFirstopenFlag) {
            this.optFirstopenFlag = optFirstopenFlag;
        }

        public void setAvgAsset(Double avgAsset) {
            this.avgAsset = avgAsset;
        }

        public void setOptholdLimitNo(String optholdLimitNo) {
            this.optholdLimitNo = optholdLimitNo;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setPurAuditQuota(Double purAuditQuota) {
            this.purAuditQuota = purAuditQuota;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("OptclientinfoDTO:(");
            buffer.append("clientId:" + this.clientId);
            buffer.append(",clientName:" + this.clientName);
            buffer.append(",organFlag:" + this.organFlag);
            buffer.append(",optLevel:" + this.optLevel);
            buffer.append(",remark:" + this.remark);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(",firstLevelScore:" + this.firstLevelScore);
            buffer.append(",secondLevelScore:" + this.secondLevelScore);
            buffer.append(",thirdLevelScore:" + this.thirdLevelScore);
            buffer.append(",firstLevelDate:" + this.firstLevelDate);
            buffer.append(",secondLevelDate:" + this.secondLevelDate);
            buffer.append(",thirdLevelDate:" + this.thirdLevelDate);
            buffer.append(",regDate:" + this.regDate);
            buffer.append(",crdtExistsFlag:" + this.crdtExistsFlag);
            buffer.append(",spifFirstExchdate:" + this.spifFirstExchdate);
            buffer.append(",marketValue:" + this.marketValue);
            buffer.append(",bailBalance:" + this.bailBalance);
            buffer.append(",simulateTradeFlag:" + this.simulateTradeFlag);
            buffer.append(",subRiskDate:" + this.subRiskDate);
            buffer.append(",honestPromiseDate:" + this.honestPromiseDate);
            buffer.append(",riskBeginDate:" + this.riskBeginDate);
            buffer.append(",riskEndDate:" + this.riskEndDate);
            buffer.append(",purApplyQuota:" + this.purApplyQuota);
            buffer.append(",totalAsset:" + this.totalAsset);
            buffer.append(",avgMarketValue:" + this.avgMarketValue);
            buffer.append(",compositeScore:" + this.compositeScore);
            buffer.append(",financialTradeFlag:" + this.financialTradeFlag);
            buffer.append(",firstSimulateTradeFlag:" + this.firstSimulateTradeFlag);
            buffer.append(",secondSimulateTradeFlag:" + this.secondSimulateTradeFlag);
            buffer.append(",thirdSimulateTradeFlag:" + this.thirdSimulateTradeFlag);
            buffer.append(",optFirstopenFlag:" + this.optFirstopenFlag);
            buffer.append(",avgAsset:" + this.avgAsset);
            buffer.append(",optholdLimitNo:" + this.optholdLimitNo);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",purAuditQuota:" + this.purAuditQuota);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.clientId);
            builder.append(this.clientName);
            builder.append(this.organFlag);
            builder.append(this.optLevel);
            builder.append(this.remark);
            builder.append(this.exchangeType);
            builder.append(this.firstLevelScore);
            builder.append(this.secondLevelScore);
            builder.append(this.thirdLevelScore);
            builder.append(this.firstLevelDate);
            builder.append(this.secondLevelDate);
            builder.append(this.thirdLevelDate);
            builder.append(this.regDate);
            builder.append(this.crdtExistsFlag);
            builder.append(this.spifFirstExchdate);
            builder.append(this.marketValue);
            builder.append(this.bailBalance);
            builder.append(this.simulateTradeFlag);
            builder.append(this.subRiskDate);
            builder.append(this.honestPromiseDate);
            builder.append(this.riskBeginDate);
            builder.append(this.riskEndDate);
            builder.append(this.purApplyQuota);
            builder.append(this.totalAsset);
            builder.append(this.avgMarketValue);
            builder.append(this.compositeScore);
            builder.append(this.financialTradeFlag);
            builder.append(this.firstSimulateTradeFlag);
            builder.append(this.secondSimulateTradeFlag);
            builder.append(this.thirdSimulateTradeFlag);
            builder.append(this.optFirstopenFlag);
            builder.append(this.avgAsset);
            builder.append(this.optholdLimitNo);
            builder.append(this.branchNo);
            builder.append(this.purAuditQuota);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.OptclientinfoDTO) {
                InnerElgService.OptclientinfoDTO test = (InnerElgService.OptclientinfoDTO)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.clientId, test.clientId);
                builder.append(this.clientName, test.clientName);
                builder.append(this.organFlag, test.organFlag);
                builder.append(this.optLevel, test.optLevel);
                builder.append(this.remark, test.remark);
                builder.append(this.exchangeType, test.exchangeType);
                builder.append(this.firstLevelScore, test.firstLevelScore);
                builder.append(this.secondLevelScore, test.secondLevelScore);
                builder.append(this.thirdLevelScore, test.thirdLevelScore);
                builder.append(this.firstLevelDate, test.firstLevelDate);
                builder.append(this.secondLevelDate, test.secondLevelDate);
                builder.append(this.thirdLevelDate, test.thirdLevelDate);
                builder.append(this.regDate, test.regDate);
                builder.append(this.crdtExistsFlag, test.crdtExistsFlag);
                builder.append(this.spifFirstExchdate, test.spifFirstExchdate);
                builder.append(this.marketValue, test.marketValue);
                builder.append(this.bailBalance, test.bailBalance);
                builder.append(this.simulateTradeFlag, test.simulateTradeFlag);
                builder.append(this.subRiskDate, test.subRiskDate);
                builder.append(this.honestPromiseDate, test.honestPromiseDate);
                builder.append(this.riskBeginDate, test.riskBeginDate);
                builder.append(this.riskEndDate, test.riskEndDate);
                builder.append(this.purApplyQuota, test.purApplyQuota);
                builder.append(this.totalAsset, test.totalAsset);
                builder.append(this.avgMarketValue, test.avgMarketValue);
                builder.append(this.compositeScore, test.compositeScore);
                builder.append(this.financialTradeFlag, test.financialTradeFlag);
                builder.append(this.firstSimulateTradeFlag, test.firstSimulateTradeFlag);
                builder.append(this.secondSimulateTradeFlag, test.secondSimulateTradeFlag);
                builder.append(this.thirdSimulateTradeFlag, test.thirdSimulateTradeFlag);
                builder.append(this.optFirstopenFlag, test.optFirstopenFlag);
                builder.append(this.avgAsset, test.avgAsset);
                builder.append(this.optholdLimitNo, test.optholdLimitNo);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.purAuditQuota, test.purAuditQuota);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class OptacctlimitDTO implements Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String clientId = " ";
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String exchangeType = " ";
        @SinogramLength(
                min = 0,
                max = 8,
                charset = "utf-8"
        )
        private String stockCode = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character hedgeApplyMode = ' ';
        @Digits(
                integer = 13,
                fraction = 2,
                message = "rightHoldQuota value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double rightHoldQuota = 0.0D;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "totalHoldQuota value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double totalHoldQuota = 0.0D;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "todayBuyQuota value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double todayBuyQuota = 0.0D;
        private Integer beginDate = 0;
        private Integer endDate = 0;
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String stockType = " ";
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String optHoldlimitModelStr = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fundAccount = " ";
        private Integer branchNo = 0;
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String remark = " ";

        public OptacctlimitDTO() {
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getExchangeType() {
            if (this.exchangeType == null) {
                return " ";
            } else {
                return this.exchangeType.isEmpty() ? " " : this.exchangeType;
            }
        }

        public String getStockCode() {
            if (this.stockCode == null) {
                return " ";
            } else {
                return this.stockCode.isEmpty() ? " " : this.stockCode;
            }
        }

        public Character getHedgeApplyMode() {
            return this.hedgeApplyMode != null ? this.hedgeApplyMode : ' ';
        }

        public Double getRightHoldQuota() {
            return this.rightHoldQuota != null ? this.rightHoldQuota : 0.0D;
        }

        public Double getTotalHoldQuota() {
            return this.totalHoldQuota != null ? this.totalHoldQuota : 0.0D;
        }

        public Double getTodayBuyQuota() {
            return this.todayBuyQuota != null ? this.todayBuyQuota : 0.0D;
        }

        public Integer getBeginDate() {
            return this.beginDate != null ? this.beginDate : 0;
        }

        public Integer getEndDate() {
            return this.endDate != null ? this.endDate : 0;
        }

        public String getStockType() {
            if (this.stockType == null) {
                return " ";
            } else {
                return this.stockType.isEmpty() ? " " : this.stockType;
            }
        }

        public String getOptHoldlimitModelStr() {
            if (this.optHoldlimitModelStr == null) {
                return " ";
            } else {
                return this.optHoldlimitModelStr.isEmpty() ? " " : this.optHoldlimitModelStr;
            }
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getRemark() {
            if (this.remark == null) {
                return " ";
            } else {
                return this.remark.isEmpty() ? " " : this.remark;
            }
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public void setStockCode(String stockCode) {
            this.stockCode = stockCode;
        }

        public void setHedgeApplyMode(Character hedgeApplyMode) {
            this.hedgeApplyMode = hedgeApplyMode;
        }

        public void setRightHoldQuota(Double rightHoldQuota) {
            this.rightHoldQuota = rightHoldQuota;
        }

        public void setTotalHoldQuota(Double totalHoldQuota) {
            this.totalHoldQuota = totalHoldQuota;
        }

        public void setTodayBuyQuota(Double todayBuyQuota) {
            this.todayBuyQuota = todayBuyQuota;
        }

        public void setBeginDate(Integer beginDate) {
            this.beginDate = beginDate;
        }

        public void setEndDate(Integer endDate) {
            this.endDate = endDate;
        }

        public void setStockType(String stockType) {
            this.stockType = stockType;
        }

        public void setOptHoldlimitModelStr(String optHoldlimitModelStr) {
            this.optHoldlimitModelStr = optHoldlimitModelStr;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("OptacctlimitDTO:(");
            buffer.append("clientId:" + this.clientId);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(",stockCode:" + this.stockCode);
            buffer.append(",hedgeApplyMode:" + this.hedgeApplyMode);
            buffer.append(",rightHoldQuota:" + this.rightHoldQuota);
            buffer.append(",totalHoldQuota:" + this.totalHoldQuota);
            buffer.append(",todayBuyQuota:" + this.todayBuyQuota);
            buffer.append(",beginDate:" + this.beginDate);
            buffer.append(",endDate:" + this.endDate);
            buffer.append(",stockType:" + this.stockType);
            buffer.append(",optHoldlimitModelStr:" + this.optHoldlimitModelStr);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",remark:" + this.remark);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.clientId);
            builder.append(this.exchangeType);
            builder.append(this.stockCode);
            builder.append(this.hedgeApplyMode);
            builder.append(this.rightHoldQuota);
            builder.append(this.totalHoldQuota);
            builder.append(this.todayBuyQuota);
            builder.append(this.beginDate);
            builder.append(this.endDate);
            builder.append(this.stockType);
            builder.append(this.optHoldlimitModelStr);
            builder.append(this.fundAccount);
            builder.append(this.branchNo);
            builder.append(this.remark);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.OptacctlimitDTO) {
                InnerElgService.OptacctlimitDTO test = (InnerElgService.OptacctlimitDTO)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.clientId, test.clientId);
                builder.append(this.exchangeType, test.exchangeType);
                builder.append(this.stockCode, test.stockCode);
                builder.append(this.hedgeApplyMode, test.hedgeApplyMode);
                builder.append(this.rightHoldQuota, test.rightHoldQuota);
                builder.append(this.totalHoldQuota, test.totalHoldQuota);
                builder.append(this.todayBuyQuota, test.todayBuyQuota);
                builder.append(this.beginDate, test.beginDate);
                builder.append(this.endDate, test.endDate);
                builder.append(this.stockType, test.stockType);
                builder.append(this.optHoldlimitModelStr, test.optHoldlimitModelStr);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.remark, test.remark);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PaperDTO implements Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 2,
                charset = "utf-8"
        )
        private String paperType = " ";
        @SinogramLength(
                min = 0,
                max = 24,
                charset = "utf-8"
        )
        private String prodtaNo = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character organFlag = ' ';
        @SinogramLength(
                min = 0,
                max = 180,
                charset = "utf-8"
        )
        private String paperName = " ";
        @Digits(
                integer = 13,
                fraction = 2,
                message = "baseScore value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double baseScore = 0.0D;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "minScore value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double minScore = 0.0D;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character enableFlag = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character useFlag = ' ';
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String remark = " ";
        private Integer openDays = 0;
        private Integer secondInterval = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String eligpaperVersion = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character deleteFlag = ' ';
        private Integer nearFinalDays = 0;
        private Integer confirmDays = 0;
        private Integer dailyPermitTimes = 0;
        private Integer dateClear = 0;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String eligpaperCtrlstr = " ";
        @SinogramLength(
                min = 0,
                max = 100,
                charset = "utf-8"
        )
        private String positionStr = " ";
        @SinogramLength(
                min = 0,
                max = 100,
                charset = "utf-8"
        )
        private String questionRandomCtrl = " ";

        public PaperDTO() {
        }

        public String getPaperType() {
            if (this.paperType == null) {
                return " ";
            } else {
                return this.paperType.isEmpty() ? " " : this.paperType;
            }
        }

        public String getProdtaNo() {
            if (this.prodtaNo == null) {
                return " ";
            } else {
                return this.prodtaNo.isEmpty() ? " " : this.prodtaNo;
            }
        }

        public Character getOrganFlag() {
            return this.organFlag != null ? this.organFlag : ' ';
        }

        public String getPaperName() {
            if (this.paperName == null) {
                return " ";
            } else {
                return this.paperName.isEmpty() ? " " : this.paperName;
            }
        }

        public Double getBaseScore() {
            return this.baseScore != null ? this.baseScore : 0.0D;
        }

        public Double getMinScore() {
            return this.minScore != null ? this.minScore : 0.0D;
        }

        public Character getEnableFlag() {
            return this.enableFlag != null ? this.enableFlag : ' ';
        }

        public Character getUseFlag() {
            return this.useFlag != null ? this.useFlag : ' ';
        }

        public String getRemark() {
            if (this.remark == null) {
                return " ";
            } else {
                return this.remark.isEmpty() ? " " : this.remark;
            }
        }

        public Integer getOpenDays() {
            return this.openDays != null ? this.openDays : 0;
        }

        public Integer getSecondInterval() {
            return this.secondInterval != null ? this.secondInterval : 0;
        }

        public String getEligpaperVersion() {
            if (this.eligpaperVersion == null) {
                return " ";
            } else {
                return this.eligpaperVersion.isEmpty() ? " " : this.eligpaperVersion;
            }
        }

        public Character getDeleteFlag() {
            return this.deleteFlag != null ? this.deleteFlag : ' ';
        }

        public Integer getNearFinalDays() {
            return this.nearFinalDays != null ? this.nearFinalDays : 0;
        }

        public Integer getConfirmDays() {
            return this.confirmDays != null ? this.confirmDays : 0;
        }

        public Integer getDailyPermitTimes() {
            return this.dailyPermitTimes != null ? this.dailyPermitTimes : 0;
        }

        public Integer getDateClear() {
            return this.dateClear != null ? this.dateClear : 0;
        }

        public String getEligpaperCtrlstr() {
            if (this.eligpaperCtrlstr == null) {
                return " ";
            } else {
                return this.eligpaperCtrlstr.isEmpty() ? " " : this.eligpaperCtrlstr;
            }
        }

        public String getPositionStr() {
            if (this.positionStr == null) {
                return " ";
            } else {
                return this.positionStr.isEmpty() ? " " : this.positionStr;
            }
        }

        public String getQuestionRandomCtrl() {
            if (this.questionRandomCtrl == null) {
                return " ";
            } else {
                return this.questionRandomCtrl.isEmpty() ? " " : this.questionRandomCtrl;
            }
        }

        public void setPaperType(String paperType) {
            this.paperType = paperType;
        }

        public void setProdtaNo(String prodtaNo) {
            this.prodtaNo = prodtaNo;
        }

        public void setOrganFlag(Character organFlag) {
            this.organFlag = organFlag;
        }

        public void setPaperName(String paperName) {
            this.paperName = paperName;
        }

        public void setBaseScore(Double baseScore) {
            this.baseScore = baseScore;
        }

        public void setMinScore(Double minScore) {
            this.minScore = minScore;
        }

        public void setEnableFlag(Character enableFlag) {
            this.enableFlag = enableFlag;
        }

        public void setUseFlag(Character useFlag) {
            this.useFlag = useFlag;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public void setOpenDays(Integer openDays) {
            this.openDays = openDays;
        }

        public void setSecondInterval(Integer secondInterval) {
            this.secondInterval = secondInterval;
        }

        public void setEligpaperVersion(String eligpaperVersion) {
            this.eligpaperVersion = eligpaperVersion;
        }

        public void setDeleteFlag(Character deleteFlag) {
            this.deleteFlag = deleteFlag;
        }

        public void setNearFinalDays(Integer nearFinalDays) {
            this.nearFinalDays = nearFinalDays;
        }

        public void setConfirmDays(Integer confirmDays) {
            this.confirmDays = confirmDays;
        }

        public void setDailyPermitTimes(Integer dailyPermitTimes) {
            this.dailyPermitTimes = dailyPermitTimes;
        }

        public void setDateClear(Integer dateClear) {
            this.dateClear = dateClear;
        }

        public void setEligpaperCtrlstr(String eligpaperCtrlstr) {
            this.eligpaperCtrlstr = eligpaperCtrlstr;
        }

        public void setPositionStr(String positionStr) {
            this.positionStr = positionStr;
        }

        public void setQuestionRandomCtrl(String questionRandomCtrl) {
            this.questionRandomCtrl = questionRandomCtrl;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PaperDTO:(");
            buffer.append("paperType:" + this.paperType);
            buffer.append(",prodtaNo:" + this.prodtaNo);
            buffer.append(",organFlag:" + this.organFlag);
            buffer.append(",paperName:" + this.paperName);
            buffer.append(",baseScore:" + this.baseScore);
            buffer.append(",minScore:" + this.minScore);
            buffer.append(",enableFlag:" + this.enableFlag);
            buffer.append(",useFlag:" + this.useFlag);
            buffer.append(",remark:" + this.remark);
            buffer.append(",openDays:" + this.openDays);
            buffer.append(",secondInterval:" + this.secondInterval);
            buffer.append(",eligpaperVersion:" + this.eligpaperVersion);
            buffer.append(",deleteFlag:" + this.deleteFlag);
            buffer.append(",nearFinalDays:" + this.nearFinalDays);
            buffer.append(",confirmDays:" + this.confirmDays);
            buffer.append(",dailyPermitTimes:" + this.dailyPermitTimes);
            buffer.append(",dateClear:" + this.dateClear);
            buffer.append(",eligpaperCtrlstr:" + this.eligpaperCtrlstr);
            buffer.append(",positionStr:" + this.positionStr);
            buffer.append(",questionRandomCtrl:" + this.questionRandomCtrl);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.paperType);
            builder.append(this.prodtaNo);
            builder.append(this.organFlag);
            builder.append(this.paperName);
            builder.append(this.baseScore);
            builder.append(this.minScore);
            builder.append(this.enableFlag);
            builder.append(this.useFlag);
            builder.append(this.remark);
            builder.append(this.openDays);
            builder.append(this.secondInterval);
            builder.append(this.eligpaperVersion);
            builder.append(this.deleteFlag);
            builder.append(this.nearFinalDays);
            builder.append(this.confirmDays);
            builder.append(this.dailyPermitTimes);
            builder.append(this.dateClear);
            builder.append(this.eligpaperCtrlstr);
            builder.append(this.positionStr);
            builder.append(this.questionRandomCtrl);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.PaperDTO) {
                InnerElgService.PaperDTO test = (InnerElgService.PaperDTO)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.paperType, test.paperType);
                builder.append(this.prodtaNo, test.prodtaNo);
                builder.append(this.organFlag, test.organFlag);
                builder.append(this.paperName, test.paperName);
                builder.append(this.baseScore, test.baseScore);
                builder.append(this.minScore, test.minScore);
                builder.append(this.enableFlag, test.enableFlag);
                builder.append(this.useFlag, test.useFlag);
                builder.append(this.remark, test.remark);
                builder.append(this.openDays, test.openDays);
                builder.append(this.secondInterval, test.secondInterval);
                builder.append(this.eligpaperVersion, test.eligpaperVersion);
                builder.append(this.deleteFlag, test.deleteFlag);
                builder.append(this.nearFinalDays, test.nearFinalDays);
                builder.append(this.confirmDays, test.confirmDays);
                builder.append(this.dailyPermitTimes, test.dailyPermitTimes);
                builder.append(this.dateClear, test.dateClear);
                builder.append(this.eligpaperCtrlstr, test.eligpaperCtrlstr);
                builder.append(this.positionStr, test.positionStr);
                builder.append(this.questionRandomCtrl, test.questionRandomCtrl);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class TestjourDTO implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer initDate = 0;
        private Long serialNo = 0L;
        private Integer currDate = 0;
        private Integer currTime = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String clientId = " ";
        @SinogramLength(
                min = 0,
                max = 180,
                charset = "utf-8"
        )
        private String fullName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character idKind = ' ';
        @SinogramLength(
                min = 0,
                max = 40,
                charset = "utf-8"
        )
        private String idNo = " ";
        @SinogramLength(
                min = 0,
                max = 2,
                charset = "utf-8"
        )
        private String paperType = " ";
        @SinogramLength(
                min = 0,
                max = 24,
                charset = "utf-8"
        )
        private String prodtaNo = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character organFlag = ' ';
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String paperAnswer = " ";
        @Digits(
                integer = 13,
                fraction = 2,
                message = "paperScore value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double paperScore = 0.0D;
        private Integer dateClear = 0;
        @SinogramLength(
                min = 0,
                max = 3,
                charset = "utf-8"
        )
        private String clearFlag = " ";
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String remark = " ";
        @SinogramLength(
                min = 0,
                max = 100,
                charset = "utf-8"
        )
        private String positionStr = " ";
        private Integer corpRiskLevel = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String eligpaperVersion = " ";
        private Integer autoeligtestDate = 0;
        @SinogramLength(
                min = 0,
                max = 2,
                charset = "utf-8"
        )
        private String subPaperType = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String enInvestKind = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String enInvestTerm = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character minRankFlag = ' ';

        public TestjourDTO() {
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public Long getSerialNo() {
            return this.serialNo != null ? this.serialNo : 0L;
        }

        public Integer getCurrDate() {
            return this.currDate != null ? this.currDate : 0;
        }

        public Integer getCurrTime() {
            return this.currTime != null ? this.currTime : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getFullName() {
            if (this.fullName == null) {
                return " ";
            } else {
                return this.fullName.isEmpty() ? " " : this.fullName;
            }
        }

        public Character getIdKind() {
            return this.idKind != null ? this.idKind : ' ';
        }

        public String getIdNo() {
            if (this.idNo == null) {
                return " ";
            } else {
                return this.idNo.isEmpty() ? " " : this.idNo;
            }
        }

        public String getPaperType() {
            if (this.paperType == null) {
                return " ";
            } else {
                return this.paperType.isEmpty() ? " " : this.paperType;
            }
        }

        public String getProdtaNo() {
            if (this.prodtaNo == null) {
                return " ";
            } else {
                return this.prodtaNo.isEmpty() ? " " : this.prodtaNo;
            }
        }

        public Character getOrganFlag() {
            return this.organFlag != null ? this.organFlag : ' ';
        }

        public String getPaperAnswer() {
            if (this.paperAnswer == null) {
                return " ";
            } else {
                return this.paperAnswer.isEmpty() ? " " : this.paperAnswer;
            }
        }

        public Double getPaperScore() {
            return this.paperScore != null ? this.paperScore : 0.0D;
        }

        public Integer getDateClear() {
            return this.dateClear != null ? this.dateClear : 0;
        }

        public String getClearFlag() {
            if (this.clearFlag == null) {
                return " ";
            } else {
                return this.clearFlag.isEmpty() ? " " : this.clearFlag;
            }
        }

        public String getRemark() {
            if (this.remark == null) {
                return " ";
            } else {
                return this.remark.isEmpty() ? " " : this.remark;
            }
        }

        public String getPositionStr() {
            if (this.positionStr == null) {
                return " ";
            } else {
                return this.positionStr.isEmpty() ? " " : this.positionStr;
            }
        }

        public Integer getCorpRiskLevel() {
            return this.corpRiskLevel != null ? this.corpRiskLevel : 0;
        }

        public String getEligpaperVersion() {
            if (this.eligpaperVersion == null) {
                return " ";
            } else {
                return this.eligpaperVersion.isEmpty() ? " " : this.eligpaperVersion;
            }
        }

        public Integer getAutoeligtestDate() {
            return this.autoeligtestDate != null ? this.autoeligtestDate : 0;
        }

        public String getSubPaperType() {
            if (this.subPaperType == null) {
                return " ";
            } else {
                return this.subPaperType.isEmpty() ? " " : this.subPaperType;
            }
        }

        public String getEnInvestKind() {
            if (this.enInvestKind == null) {
                return " ";
            } else {
                return this.enInvestKind.isEmpty() ? " " : this.enInvestKind;
            }
        }

        public String getEnInvestTerm() {
            if (this.enInvestTerm == null) {
                return " ";
            } else {
                return this.enInvestTerm.isEmpty() ? " " : this.enInvestTerm;
            }
        }

        public Character getMinRankFlag() {
            return this.minRankFlag != null ? this.minRankFlag : ' ';
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public void setSerialNo(Long serialNo) {
            this.serialNo = serialNo;
        }

        public void setCurrDate(Integer currDate) {
            this.currDate = currDate;
        }

        public void setCurrTime(Integer currTime) {
            this.currTime = currTime;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setFullName(String fullName) {
            this.fullName = fullName;
        }

        public void setIdKind(Character idKind) {
            this.idKind = idKind;
        }

        public void setIdNo(String idNo) {
            this.idNo = idNo;
        }

        public void setPaperType(String paperType) {
            this.paperType = paperType;
        }

        public void setProdtaNo(String prodtaNo) {
            this.prodtaNo = prodtaNo;
        }

        public void setOrganFlag(Character organFlag) {
            this.organFlag = organFlag;
        }

        public void setPaperAnswer(String paperAnswer) {
            this.paperAnswer = paperAnswer;
        }

        public void setPaperScore(Double paperScore) {
            this.paperScore = paperScore;
        }

        public void setDateClear(Integer dateClear) {
            this.dateClear = dateClear;
        }

        public void setClearFlag(String clearFlag) {
            this.clearFlag = clearFlag;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public void setPositionStr(String positionStr) {
            this.positionStr = positionStr;
        }

        public void setCorpRiskLevel(Integer corpRiskLevel) {
            this.corpRiskLevel = corpRiskLevel;
        }

        public void setEligpaperVersion(String eligpaperVersion) {
            this.eligpaperVersion = eligpaperVersion;
        }

        public void setAutoeligtestDate(Integer autoeligtestDate) {
            this.autoeligtestDate = autoeligtestDate;
        }

        public void setSubPaperType(String subPaperType) {
            this.subPaperType = subPaperType;
        }

        public void setEnInvestKind(String enInvestKind) {
            this.enInvestKind = enInvestKind;
        }

        public void setEnInvestTerm(String enInvestTerm) {
            this.enInvestTerm = enInvestTerm;
        }

        public void setMinRankFlag(Character minRankFlag) {
            this.minRankFlag = minRankFlag;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("TestjourDTO:(");
            buffer.append("initDate:" + this.initDate);
            buffer.append(",serialNo:" + this.serialNo);
            buffer.append(",currDate:" + this.currDate);
            buffer.append(",currTime:" + this.currTime);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",fullName:" + this.fullName);
            buffer.append(",idKind:" + this.idKind);
            buffer.append(",idNo:" + this.idNo);
            buffer.append(",paperType:" + this.paperType);
            buffer.append(",prodtaNo:" + this.prodtaNo);
            buffer.append(",organFlag:" + this.organFlag);
            buffer.append(",paperAnswer:" + this.paperAnswer);
            buffer.append(",paperScore:" + this.paperScore);
            buffer.append(",dateClear:" + this.dateClear);
            buffer.append(",clearFlag:" + this.clearFlag);
            buffer.append(",remark:" + this.remark);
            buffer.append(",positionStr:" + this.positionStr);
            buffer.append(",corpRiskLevel:" + this.corpRiskLevel);
            buffer.append(",eligpaperVersion:" + this.eligpaperVersion);
            buffer.append(",autoeligtestDate:" + this.autoeligtestDate);
            buffer.append(",subPaperType:" + this.subPaperType);
            buffer.append(",enInvestKind:" + this.enInvestKind);
            buffer.append(",enInvestTerm:" + this.enInvestTerm);
            buffer.append(",minRankFlag:" + this.minRankFlag);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.initDate);
            builder.append(this.serialNo);
            builder.append(this.currDate);
            builder.append(this.currTime);
            builder.append(this.operatorNo);
            builder.append(this.opBranchNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.clientId);
            builder.append(this.fullName);
            builder.append(this.idKind);
            builder.append(this.idNo);
            builder.append(this.paperType);
            builder.append(this.prodtaNo);
            builder.append(this.organFlag);
            builder.append(this.paperAnswer);
            builder.append(this.paperScore);
            builder.append(this.dateClear);
            builder.append(this.clearFlag);
            builder.append(this.remark);
            builder.append(this.positionStr);
            builder.append(this.corpRiskLevel);
            builder.append(this.eligpaperVersion);
            builder.append(this.autoeligtestDate);
            builder.append(this.subPaperType);
            builder.append(this.enInvestKind);
            builder.append(this.enInvestTerm);
            builder.append(this.minRankFlag);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.TestjourDTO) {
                InnerElgService.TestjourDTO test = (InnerElgService.TestjourDTO)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.initDate, test.initDate);
                builder.append(this.serialNo, test.serialNo);
                builder.append(this.currDate, test.currDate);
                builder.append(this.currTime, test.currTime);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.clientId, test.clientId);
                builder.append(this.fullName, test.fullName);
                builder.append(this.idKind, test.idKind);
                builder.append(this.idNo, test.idNo);
                builder.append(this.paperType, test.paperType);
                builder.append(this.prodtaNo, test.prodtaNo);
                builder.append(this.organFlag, test.organFlag);
                builder.append(this.paperAnswer, test.paperAnswer);
                builder.append(this.paperScore, test.paperScore);
                builder.append(this.dateClear, test.dateClear);
                builder.append(this.clearFlag, test.clearFlag);
                builder.append(this.remark, test.remark);
                builder.append(this.positionStr, test.positionStr);
                builder.append(this.corpRiskLevel, test.corpRiskLevel);
                builder.append(this.eligpaperVersion, test.eligpaperVersion);
                builder.append(this.autoeligtestDate, test.autoeligtestDate);
                builder.append(this.subPaperType, test.subPaperType);
                builder.append(this.enInvestKind, test.enInvestKind);
                builder.append(this.enInvestTerm, test.enInvestTerm);
                builder.append(this.minRankFlag, test.minRankFlag);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutRiskLevelCreditCheckInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String opRemark = " ";
        private Integer initDate = 0;

        public PutRiskLevelCreditCheckInnerOutput() {
        }

        public String getOpRemark() {
            if (this.opRemark == null) {
                return " ";
            } else {
                return this.opRemark.isEmpty() ? " " : this.opRemark;
            }
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutRiskLevelCreditCheckInnerOutput:(");
            buffer.append("opRemark:" + this.opRemark);
            buffer.append(",initDate:" + this.initDate);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opRemark);
            builder.append(this.initDate);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.PutRiskLevelCreditCheckInnerOutput) {
                InnerElgService.PutRiskLevelCreditCheckInnerOutput test = (InnerElgService.PutRiskLevelCreditCheckInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opRemark, test.opRemark);
                builder.append(this.initDate, test.initDate);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutRiskLevelCreditCheckInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer branchNo = 0;
        private Integer initDate = 0;

        public PutRiskLevelCreditCheckInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutRiskLevelCreditCheckInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",initDate:" + this.initDate);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.branchNo);
            builder.append(this.initDate);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.PutRiskLevelCreditCheckInnerInput) {
                InnerElgService.PutRiskLevelCreditCheckInnerInput test = (InnerElgService.PutRiskLevelCreditCheckInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.initDate, test.initDate);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutRightsExpireInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer initDate = 0;

        public PutRightsExpireInnerOutput() {
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutRightsExpireInnerOutput:(");
            buffer.append("initDate:" + this.initDate);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.initDate);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.PutRightsExpireInnerOutput) {
                InnerElgService.PutRightsExpireInnerOutput test = (InnerElgService.PutRightsExpireInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.initDate, test.initDate);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutRightsExpireInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer branchNo = 0;

        public PutRightsExpireInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutRightsExpireInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.branchNo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.PutRightsExpireInnerInput) {
                InnerElgService.PutRightsExpireInnerInput test = (InnerElgService.PutRightsExpireInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.branchNo, test.branchNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutDayinitinfoDateChangeInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer initDate = 0;
        private Integer preInitDate = 0;

        public PutDayinitinfoDateChangeInnerOutput() {
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public Integer getPreInitDate() {
            return this.preInitDate != null ? this.preInitDate : 0;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public void setPreInitDate(Integer preInitDate) {
            this.preInitDate = preInitDate;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutDayinitinfoDateChangeInnerOutput:(");
            buffer.append("initDate:" + this.initDate);
            buffer.append(",preInitDate:" + this.preInitDate);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.initDate);
            builder.append(this.preInitDate);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.PutDayinitinfoDateChangeInnerOutput) {
                InnerElgService.PutDayinitinfoDateChangeInnerOutput test = (InnerElgService.PutDayinitinfoDateChangeInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.initDate, test.initDate);
                builder.append(this.preInitDate, test.preInitDate);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutDayinitinfoDateChangeInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer branchNo = 0;
        private Integer initDate = 0;

        public PutDayinitinfoDateChangeInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutDayinitinfoDateChangeInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",initDate:" + this.initDate);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.branchNo);
            builder.append(this.initDate);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.PutDayinitinfoDateChangeInnerInput) {
                InnerElgService.PutDayinitinfoDateChangeInnerInput test = (InnerElgService.PutDayinitinfoDateChangeInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.initDate, test.initDate);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutDayinitinfoBatchDealInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer rowcount = 0;

        public PutDayinitinfoBatchDealInnerOutput() {
        }

        public Integer getRowcount() {
            return this.rowcount != null ? this.rowcount : 0;
        }

        public void setRowcount(Integer rowcount) {
            this.rowcount = rowcount;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutDayinitinfoBatchDealInnerOutput:(");
            buffer.append("rowcount:" + this.rowcount);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.rowcount);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.PutDayinitinfoBatchDealInnerOutput) {
                InnerElgService.PutDayinitinfoBatchDealInnerOutput test = (InnerElgService.PutDayinitinfoBatchDealInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.rowcount, test.rowcount);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutDayinitinfoBatchDealInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer branchNo = 0;
        @SinogramLength(
                min = 0,
                max = 180,
                charset = "utf-8"
        )
        private String tableName = " ";
        private Integer initDate = 0;
        private Long serialNo = 0L;
        private String settleClob = " ";

        public PutDayinitinfoBatchDealInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getTableName() {
            if (this.tableName == null) {
                return " ";
            } else {
                return this.tableName.isEmpty() ? " " : this.tableName;
            }
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public Long getSerialNo() {
            return this.serialNo != null ? this.serialNo : 0L;
        }

        public String getSettleClob() {
            if (this.settleClob == null) {
                return " ";
            } else {
                return this.settleClob.isEmpty() ? " " : this.settleClob;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setTableName(String tableName) {
            this.tableName = tableName;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public void setSerialNo(Long serialNo) {
            this.serialNo = serialNo;
        }

        public void setSettleClob(String settleClob) {
            this.settleClob = settleClob;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutDayinitinfoBatchDealInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",tableName:" + this.tableName);
            buffer.append(",initDate:" + this.initDate);
            buffer.append(",serialNo:" + this.serialNo);
            buffer.append(",settleClob:" + this.settleClob);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.branchNo);
            builder.append(this.tableName);
            builder.append(this.initDate);
            builder.append(this.serialNo);
            builder.append(this.settleClob);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.PutDayinitinfoBatchDealInnerInput) {
                InnerElgService.PutDayinitinfoBatchDealInnerInput test = (InnerElgService.PutDayinitinfoBatchDealInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.tableName, test.tableName);
                builder.append(this.initDate, test.initDate);
                builder.append(this.serialNo, test.serialNo);
                builder.append(this.settleClob, test.settleClob);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutClientPreferPushInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer initDate = 0;

        public PutClientPreferPushInnerOutput() {
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutClientPreferPushInnerOutput:(");
            buffer.append("initDate:" + this.initDate);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.initDate);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.PutClientPreferPushInnerOutput) {
                InnerElgService.PutClientPreferPushInnerOutput test = (InnerElgService.PutClientPreferPushInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.initDate, test.initDate);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutClientPreferPushInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer branchNo = 0;

        public PutClientPreferPushInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutClientPreferPushInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.branchNo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.PutClientPreferPushInnerInput) {
                InnerElgService.PutClientPreferPushInnerInput test = (InnerElgService.PutClientPreferPushInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.branchNo, test.branchNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostSzOptSyncShDataInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Long serialNo = 0L;
        private String opRemark = " ";

        public PostSzOptSyncShDataInnerOutput() {
        }

        public Long getSerialNo() {
            return this.serialNo != null ? this.serialNo : 0L;
        }

        public String getOpRemark() {
            if (this.opRemark == null) {
                return " ";
            } else {
                return this.opRemark.isEmpty() ? " " : this.opRemark;
            }
        }

        public void setSerialNo(Long serialNo) {
            this.serialNo = serialNo;
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostSzOptSyncShDataInnerOutput:(");
            buffer.append("serialNo:" + this.serialNo);
            buffer.append(",opRemark:" + this.opRemark);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.serialNo);
            builder.append(this.opRemark);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.PostSzOptSyncShDataInnerOutput) {
                InnerElgService.PostSzOptSyncShDataInnerOutput test = (InnerElgService.PostSzOptSyncShDataInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.serialNo, test.serialNo);
                builder.append(this.opRemark, test.opRemark);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostSzOptSyncShDataInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer branchNo = 0;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId = " ";
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String exchangeType = " ";

        public PostSzOptSyncShDataInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getExchangeType() {
            if (this.exchangeType == null) {
                return " ";
            } else {
                return this.exchangeType.isEmpty() ? " " : this.exchangeType;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostSzOptSyncShDataInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.branchNo);
            builder.append(this.clientId);
            builder.append(this.exchangeType);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.PostSzOptSyncShDataInnerInput) {
                InnerElgService.PostSzOptSyncShDataInnerInput test = (InnerElgService.PostSzOptSyncShDataInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.clientId, test.clientId);
                builder.append(this.exchangeType, test.exchangeType);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostRefacctreportInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String opRemark = " ";

        public PostRefacctreportInnerOutput() {
        }

        public String getOpRemark() {
            if (this.opRemark == null) {
                return " ";
            } else {
                return this.opRemark.isEmpty() ? " " : this.opRemark;
            }
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostRefacctreportInnerOutput:(");
            buffer.append("opRemark:" + this.opRemark);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opRemark);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.PostRefacctreportInnerOutput) {
                InnerElgService.PostRefacctreportInnerOutput test = (InnerElgService.PostRefacctreportInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opRemark, test.opRemark);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostRefacctreportInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer branchNo = 0;
        private Long reportNo = 0L;
        private Integer initDate = 0;
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String remark = " ";

        public PostRefacctreportInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Long getReportNo() {
            return this.reportNo != null ? this.reportNo : 0L;
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public String getRemark() {
            if (this.remark == null) {
                return " ";
            } else {
                return this.remark.isEmpty() ? " " : this.remark;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setReportNo(Long reportNo) {
            this.reportNo = reportNo;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostRefacctreportInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",reportNo:" + this.reportNo);
            buffer.append(",initDate:" + this.initDate);
            buffer.append(",remark:" + this.remark);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.branchNo);
            builder.append(this.reportNo);
            builder.append(this.initDate);
            builder.append(this.remark);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.PostRefacctreportInnerInput) {
                InnerElgService.PostRefacctreportInnerInput test = (InnerElgService.PostRefacctreportInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.reportNo, test.reportNo);
                builder.append(this.initDate, test.initDate);
                builder.append(this.remark, test.remark);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostProductcheckOutInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer initDate = 0;
        private Integer currDate = 0;
        private Integer currTime = 0;
        private String traceNo = " ";
        private String acptBusinId = " ";
        private String paramId = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character factorCheckResult = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character adjustFlag = ' ';
        private String showTitle = " ";
        private String tipsDetail = " ";

        public PostProductcheckOutInnerOutput() {
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public Integer getCurrDate() {
            return this.currDate != null ? this.currDate : 0;
        }

        public Integer getCurrTime() {
            return this.currTime != null ? this.currTime : 0;
        }

        public String getTraceNo() {
            if (this.traceNo == null) {
                return " ";
            } else {
                return this.traceNo.isEmpty() ? " " : this.traceNo;
            }
        }

        public String getAcptBusinId() {
            if (this.acptBusinId == null) {
                return " ";
            } else {
                return this.acptBusinId.isEmpty() ? " " : this.acptBusinId;
            }
        }

        public String getParamId() {
            if (this.paramId == null) {
                return " ";
            } else {
                return this.paramId.isEmpty() ? " " : this.paramId;
            }
        }

        public Character getFactorCheckResult() {
            return this.factorCheckResult != null ? this.factorCheckResult : ' ';
        }

        public Character getAdjustFlag() {
            return this.adjustFlag != null ? this.adjustFlag : ' ';
        }

        public String getShowTitle() {
            if (this.showTitle == null) {
                return " ";
            } else {
                return this.showTitle.isEmpty() ? " " : this.showTitle;
            }
        }

        public String getTipsDetail() {
            if (this.tipsDetail == null) {
                return " ";
            } else {
                return this.tipsDetail.isEmpty() ? " " : this.tipsDetail;
            }
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public void setCurrDate(Integer currDate) {
            this.currDate = currDate;
        }

        public void setCurrTime(Integer currTime) {
            this.currTime = currTime;
        }

        public void setTraceNo(String traceNo) {
            this.traceNo = traceNo;
        }

        public void setAcptBusinId(String acptBusinId) {
            this.acptBusinId = acptBusinId;
        }

        public void setParamId(String paramId) {
            this.paramId = paramId;
        }

        public void setFactorCheckResult(Character factorCheckResult) {
            this.factorCheckResult = factorCheckResult;
        }

        public void setAdjustFlag(Character adjustFlag) {
            this.adjustFlag = adjustFlag;
        }

        public void setShowTitle(String showTitle) {
            this.showTitle = showTitle;
        }

        public void setTipsDetail(String tipsDetail) {
            this.tipsDetail = tipsDetail;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostProductcheckOutInnerOutput:(");
            buffer.append("initDate:" + this.initDate);
            buffer.append(",currDate:" + this.currDate);
            buffer.append(",currTime:" + this.currTime);
            buffer.append(",traceNo:" + this.traceNo);
            buffer.append(",acptBusinId:" + this.acptBusinId);
            buffer.append(",paramId:" + this.paramId);
            buffer.append(",factorCheckResult:" + this.factorCheckResult);
            buffer.append(",adjustFlag:" + this.adjustFlag);
            buffer.append(",showTitle:" + this.showTitle);
            buffer.append(",tipsDetail:" + this.tipsDetail);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.initDate);
            builder.append(this.currDate);
            builder.append(this.currTime);
            builder.append(this.traceNo);
            builder.append(this.acptBusinId);
            builder.append(this.paramId);
            builder.append(this.factorCheckResult);
            builder.append(this.adjustFlag);
            builder.append(this.showTitle);
            builder.append(this.tipsDetail);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.PostProductcheckOutInnerOutput) {
                InnerElgService.PostProductcheckOutInnerOutput test = (InnerElgService.PostProductcheckOutInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.initDate, test.initDate);
                builder.append(this.currDate, test.currDate);
                builder.append(this.currTime, test.currTime);
                builder.append(this.traceNo, test.traceNo);
                builder.append(this.acptBusinId, test.acptBusinId);
                builder.append(this.paramId, test.paramId);
                builder.append(this.factorCheckResult, test.factorCheckResult);
                builder.append(this.adjustFlag, test.adjustFlag);
                builder.append(this.showTitle, test.showTitle);
                builder.append(this.tipsDetail, test.tipsDetail);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostProductcheckOutInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer branchNo = 0;
        @SinogramLength(
                min = 1,
                max = 64,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String traceNo = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String clientId = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String prodCode = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String prodrelativeCode = " ";

        public PostProductcheckOutInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getTraceNo() {
            if (this.traceNo == null) {
                return " ";
            } else {
                return this.traceNo.isEmpty() ? " " : this.traceNo;
            }
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getProdCode() {
            if (this.prodCode == null) {
                return " ";
            } else {
                return this.prodCode.isEmpty() ? " " : this.prodCode;
            }
        }

        public String getProdrelativeCode() {
            if (this.prodrelativeCode == null) {
                return " ";
            } else {
                return this.prodrelativeCode.isEmpty() ? " " : this.prodrelativeCode;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setTraceNo(String traceNo) {
            this.traceNo = traceNo;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setProdCode(String prodCode) {
            this.prodCode = prodCode;
        }

        public void setProdrelativeCode(String prodrelativeCode) {
            this.prodrelativeCode = prodrelativeCode;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostProductcheckOutInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",traceNo:" + this.traceNo);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",prodCode:" + this.prodCode);
            buffer.append(",prodrelativeCode:" + this.prodrelativeCode);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.branchNo);
            builder.append(this.traceNo);
            builder.append(this.clientId);
            builder.append(this.prodCode);
            builder.append(this.prodrelativeCode);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.PostProductcheckOutInnerInput) {
                InnerElgService.PostProductcheckOutInnerInput test = (InnerElgService.PostProductcheckOutInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.traceNo, test.traceNo);
                builder.append(this.clientId, test.clientId);
                builder.append(this.prodCode, test.prodCode);
                builder.append(this.prodrelativeCode, test.prodrelativeCode);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostProductRulesConfirmInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer errorNo = 0;
        private String errorInfo = " ";

        public PostProductRulesConfirmInnerOutput() {
        }

        public Integer getErrorNo() {
            return this.errorNo != null ? this.errorNo : 0;
        }

        public String getErrorInfo() {
            if (this.errorInfo == null) {
                return " ";
            } else {
                return this.errorInfo.isEmpty() ? " " : this.errorInfo;
            }
        }

        public void setErrorNo(Integer errorNo) {
            this.errorNo = errorNo;
        }

        public void setErrorInfo(String errorInfo) {
            this.errorInfo = errorInfo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostProductRulesConfirmInnerOutput:(");
            buffer.append("errorNo:" + this.errorNo);
            buffer.append(",errorInfo:" + this.errorInfo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.errorNo);
            builder.append(this.errorInfo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.PostProductRulesConfirmInnerOutput) {
                InnerElgService.PostProductRulesConfirmInnerOutput test = (InnerElgService.PostProductRulesConfirmInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.errorNo, test.errorNo);
                builder.append(this.errorInfo, test.errorInfo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostProductRulesConfirmInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer branchNo = 0;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fundAccount = " ";
        @SinogramLength(
                min = 1,
                max = 64,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String traceNo = " ";
        @SinogramLength(
                min = 1,
                max = 2000,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String factorStr = " ";

        public PostProductRulesConfirmInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getTraceNo() {
            if (this.traceNo == null) {
                return " ";
            } else {
                return this.traceNo.isEmpty() ? " " : this.traceNo;
            }
        }

        public String getFactorStr() {
            if (this.factorStr == null) {
                return " ";
            } else {
                return this.factorStr.isEmpty() ? " " : this.factorStr;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setTraceNo(String traceNo) {
            this.traceNo = traceNo;
        }

        public void setFactorStr(String factorStr) {
            this.factorStr = factorStr;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostProductRulesConfirmInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",traceNo:" + this.traceNo);
            buffer.append(",factorStr:" + this.factorStr);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.branchNo);
            builder.append(this.clientId);
            builder.append(this.fundAccount);
            builder.append(this.traceNo);
            builder.append(this.factorStr);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.PostProductRulesConfirmInnerInput) {
                InnerElgService.PostProductRulesConfirmInnerInput test = (InnerElgService.PostProductRulesConfirmInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.clientId, test.clientId);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.traceNo, test.traceNo);
                builder.append(this.factorStr, test.factorStr);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostProductRulesCheckInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer initDate = 0;
        private Integer currDate = 0;
        private Integer currTime = 0;
        private String traceNo = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character totalCheckResult = ' ';
        private String acptBusinId = " ";
        private String paramId = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character factorCheckResult = ' ';
        private String showTitle = " ";
        private String tipsDetail = " ";
        private String nextAcptBusinId = " ";

        public PostProductRulesCheckInnerOutput() {
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public Integer getCurrDate() {
            return this.currDate != null ? this.currDate : 0;
        }

        public Integer getCurrTime() {
            return this.currTime != null ? this.currTime : 0;
        }

        public String getTraceNo() {
            if (this.traceNo == null) {
                return " ";
            } else {
                return this.traceNo.isEmpty() ? " " : this.traceNo;
            }
        }

        public Character getTotalCheckResult() {
            return this.totalCheckResult != null ? this.totalCheckResult : ' ';
        }

        public String getAcptBusinId() {
            if (this.acptBusinId == null) {
                return " ";
            } else {
                return this.acptBusinId.isEmpty() ? " " : this.acptBusinId;
            }
        }

        public String getParamId() {
            if (this.paramId == null) {
                return " ";
            } else {
                return this.paramId.isEmpty() ? " " : this.paramId;
            }
        }

        public Character getFactorCheckResult() {
            return this.factorCheckResult != null ? this.factorCheckResult : ' ';
        }

        public String getShowTitle() {
            if (this.showTitle == null) {
                return " ";
            } else {
                return this.showTitle.isEmpty() ? " " : this.showTitle;
            }
        }

        public String getTipsDetail() {
            if (this.tipsDetail == null) {
                return " ";
            } else {
                return this.tipsDetail.isEmpty() ? " " : this.tipsDetail;
            }
        }

        public String getNextAcptBusinId() {
            if (this.nextAcptBusinId == null) {
                return " ";
            } else {
                return this.nextAcptBusinId.isEmpty() ? " " : this.nextAcptBusinId;
            }
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public void setCurrDate(Integer currDate) {
            this.currDate = currDate;
        }

        public void setCurrTime(Integer currTime) {
            this.currTime = currTime;
        }

        public void setTraceNo(String traceNo) {
            this.traceNo = traceNo;
        }

        public void setTotalCheckResult(Character totalCheckResult) {
            this.totalCheckResult = totalCheckResult;
        }

        public void setAcptBusinId(String acptBusinId) {
            this.acptBusinId = acptBusinId;
        }

        public void setParamId(String paramId) {
            this.paramId = paramId;
        }

        public void setFactorCheckResult(Character factorCheckResult) {
            this.factorCheckResult = factorCheckResult;
        }

        public void setShowTitle(String showTitle) {
            this.showTitle = showTitle;
        }

        public void setTipsDetail(String tipsDetail) {
            this.tipsDetail = tipsDetail;
        }

        public void setNextAcptBusinId(String nextAcptBusinId) {
            this.nextAcptBusinId = nextAcptBusinId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostProductRulesCheckInnerOutput:(");
            buffer.append("initDate:" + this.initDate);
            buffer.append(",currDate:" + this.currDate);
            buffer.append(",currTime:" + this.currTime);
            buffer.append(",traceNo:" + this.traceNo);
            buffer.append(",totalCheckResult:" + this.totalCheckResult);
            buffer.append(",acptBusinId:" + this.acptBusinId);
            buffer.append(",paramId:" + this.paramId);
            buffer.append(",factorCheckResult:" + this.factorCheckResult);
            buffer.append(",showTitle:" + this.showTitle);
            buffer.append(",tipsDetail:" + this.tipsDetail);
            buffer.append(",nextAcptBusinId:" + this.nextAcptBusinId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.initDate);
            builder.append(this.currDate);
            builder.append(this.currTime);
            builder.append(this.traceNo);
            builder.append(this.totalCheckResult);
            builder.append(this.acptBusinId);
            builder.append(this.paramId);
            builder.append(this.factorCheckResult);
            builder.append(this.showTitle);
            builder.append(this.tipsDetail);
            builder.append(this.nextAcptBusinId);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.PostProductRulesCheckInnerOutput) {
                InnerElgService.PostProductRulesCheckInnerOutput test = (InnerElgService.PostProductRulesCheckInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.initDate, test.initDate);
                builder.append(this.currDate, test.currDate);
                builder.append(this.currTime, test.currTime);
                builder.append(this.traceNo, test.traceNo);
                builder.append(this.totalCheckResult, test.totalCheckResult);
                builder.append(this.acptBusinId, test.acptBusinId);
                builder.append(this.paramId, test.paramId);
                builder.append(this.factorCheckResult, test.factorCheckResult);
                builder.append(this.showTitle, test.showTitle);
                builder.append(this.tipsDetail, test.tipsDetail);
                builder.append(this.nextAcptBusinId, test.nextAcptBusinId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostProductRulesCheckInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer branchNo = 0;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fundAccount = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character prodcodeType = ' ';
        @SinogramLength(
                min = 0,
                max = 24,
                charset = "utf-8"
        )
        private String prodtaNo = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String prodCode = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String prodrelativeCode = " ";
        @Digits(
                integer = 13,
                fraction = 2,
                message = "entrustBalance value out of bounds, integer=13, fraction=2"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double entrustBalance = 0.0D;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String traceNo = " ";
        @SinogramLength(
                min = 0,
                max = 10,
                charset = "utf-8"
        )
        private String acptBusinId = " ";

        public PostProductRulesCheckInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public Character getProdcodeType() {
            return this.prodcodeType != null ? this.prodcodeType : ' ';
        }

        public String getProdtaNo() {
            if (this.prodtaNo == null) {
                return " ";
            } else {
                return this.prodtaNo.isEmpty() ? " " : this.prodtaNo;
            }
        }

        public String getProdCode() {
            if (this.prodCode == null) {
                return " ";
            } else {
                return this.prodCode.isEmpty() ? " " : this.prodCode;
            }
        }

        public String getProdrelativeCode() {
            if (this.prodrelativeCode == null) {
                return " ";
            } else {
                return this.prodrelativeCode.isEmpty() ? " " : this.prodrelativeCode;
            }
        }

        public Double getEntrustBalance() {
            return this.entrustBalance != null ? this.entrustBalance : 0.0D;
        }

        public String getTraceNo() {
            if (this.traceNo == null) {
                return " ";
            } else {
                return this.traceNo.isEmpty() ? " " : this.traceNo;
            }
        }

        public String getAcptBusinId() {
            if (this.acptBusinId == null) {
                return " ";
            } else {
                return this.acptBusinId.isEmpty() ? " " : this.acptBusinId;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setProdcodeType(Character prodcodeType) {
            this.prodcodeType = prodcodeType;
        }

        public void setProdtaNo(String prodtaNo) {
            this.prodtaNo = prodtaNo;
        }

        public void setProdCode(String prodCode) {
            this.prodCode = prodCode;
        }

        public void setProdrelativeCode(String prodrelativeCode) {
            this.prodrelativeCode = prodrelativeCode;
        }

        public void setEntrustBalance(Double entrustBalance) {
            this.entrustBalance = entrustBalance;
        }

        public void setTraceNo(String traceNo) {
            this.traceNo = traceNo;
        }

        public void setAcptBusinId(String acptBusinId) {
            this.acptBusinId = acptBusinId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostProductRulesCheckInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",prodcodeType:" + this.prodcodeType);
            buffer.append(",prodtaNo:" + this.prodtaNo);
            buffer.append(",prodCode:" + this.prodCode);
            buffer.append(",prodrelativeCode:" + this.prodrelativeCode);
            buffer.append(",entrustBalance:" + this.entrustBalance);
            buffer.append(",traceNo:" + this.traceNo);
            buffer.append(",acptBusinId:" + this.acptBusinId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.branchNo);
            builder.append(this.clientId);
            builder.append(this.fundAccount);
            builder.append(this.prodcodeType);
            builder.append(this.prodtaNo);
            builder.append(this.prodCode);
            builder.append(this.prodrelativeCode);
            builder.append(this.entrustBalance);
            builder.append(this.traceNo);
            builder.append(this.acptBusinId);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.PostProductRulesCheckInnerInput) {
                InnerElgService.PostProductRulesCheckInnerInput test = (InnerElgService.PostProductRulesCheckInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.clientId, test.clientId);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.prodcodeType, test.prodcodeType);
                builder.append(this.prodtaNo, test.prodtaNo);
                builder.append(this.prodCode, test.prodCode);
                builder.append(this.prodrelativeCode, test.prodrelativeCode);
                builder.append(this.entrustBalance, test.entrustBalance);
                builder.append(this.traceNo, test.traceNo);
                builder.append(this.acptBusinId, test.acptBusinId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostProductInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Long serialNo;

        public PostProductInnerOutput() {
        }

        public Long getSerialNo() {
            return this.serialNo;
        }

        public void setSerialNo(Long serialNo) {
            this.serialNo = serialNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostProductInnerOutput:(");
            buffer.append("serialNo:" + this.serialNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.serialNo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.PostProductInnerOutput) {
                InnerElgService.PostProductInnerOutput test = (InnerElgService.PostProductInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.serialNo, test.serialNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostProductInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword;
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay;
        private Integer branchNo;
        @SinogramLength(
                min = 0,
                max = 24,
                charset = "utf-8"
        )
        private String prodtaNo;
        @SinogramLength(
                min = 1,
                max = 32,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String prodCode;
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String prodrelativeCode;
        @SinogramLength(
                min = 0,
                max = 180,
                charset = "utf-8"
        )
        private String prodName;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character prodcodeType;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character incomeType;
        private Integer prodriskLevel;
        @Digits(
                integer = 1,
                fraction = 8,
                message = "最大亏损率【maxDeficitRate】 超出精度范围, 最大整数位为【1】, 小数位为【8】"
        )
        @SerializeDoubleDigit(
                digit = 8
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double maxDeficitRate;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "最低资产要求【minAssetNeed】 超出精度范围, 最大整数位为【13】, 小数位为【2】"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double minAssetNeed;
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String eligCtrlstr;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character financeType;
        private Integer validDays;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character investTerm;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String enEntrustWay;
        private Integer bankRiskLevel;
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String prodcodeSubType;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character investKind;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character operFlag;
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String studyId;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character investTarget;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character abroadInvestTerm;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character complexProdFlag;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character maxLossType;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character clientTypeApply;
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String promotionDateStr;
        @SinogramLength(
                min = 0,
                max = 3,
                charset = "utf-8"
        )
        private String moneyType;

        public PostProductInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo;
        }

        public String getOperatorNo() {
            return this.operatorNo;
        }

        public String getOpPassword() {
            return this.opPassword;
        }

        public String getOpStation() {
            return this.opStation;
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay;
        }

        public Integer getBranchNo() {
            return this.branchNo;
        }

        public String getProdtaNo() {
            return this.prodtaNo;
        }

        public String getProdCode() {
            return this.prodCode;
        }

        public String getProdrelativeCode() {
            return this.prodrelativeCode;
        }

        public String getProdName() {
            return this.prodName;
        }

        public Character getProdcodeType() {
            return this.prodcodeType;
        }

        public Character getIncomeType() {
            return this.incomeType;
        }

        public Integer getProdriskLevel() {
            return this.prodriskLevel;
        }

        public Double getMaxDeficitRate() {
            return this.maxDeficitRate;
        }

        public Double getMinAssetNeed() {
            return this.minAssetNeed;
        }

        public String getEligCtrlstr() {
            return this.eligCtrlstr;
        }

        public Character getFinanceType() {
            return this.financeType;
        }

        public Integer getValidDays() {
            return this.validDays;
        }

        public Character getInvestTerm() {
            return this.investTerm;
        }

        public String getEnEntrustWay() {
            return this.enEntrustWay;
        }

        public Integer getBankRiskLevel() {
            return this.bankRiskLevel;
        }

        public String getProdcodeSubType() {
            return this.prodcodeSubType;
        }

        public Character getInvestKind() {
            return this.investKind;
        }

        public Character getOperFlag() {
            return this.operFlag;
        }

        public String getStudyId() {
            return this.studyId;
        }

        public Character getInvestTarget() {
            return this.investTarget;
        }

        public Character getAbroadInvestTerm() {
            return this.abroadInvestTerm;
        }

        public Character getComplexProdFlag() {
            return this.complexProdFlag;
        }

        public Character getMaxLossType() {
            return this.maxLossType;
        }

        public Character getClientTypeApply() {
            return this.clientTypeApply;
        }

        public String getPromotionDateStr() {
            return this.promotionDateStr;
        }

        public String getMoneyType() {
            return this.moneyType;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setProdtaNo(String prodtaNo) {
            this.prodtaNo = prodtaNo;
        }

        public void setProdCode(String prodCode) {
            this.prodCode = prodCode;
        }

        public void setProdrelativeCode(String prodrelativeCode) {
            this.prodrelativeCode = prodrelativeCode;
        }

        public void setProdName(String prodName) {
            this.prodName = prodName;
        }

        public void setProdcodeType(Character prodcodeType) {
            this.prodcodeType = prodcodeType;
        }

        public void setIncomeType(Character incomeType) {
            this.incomeType = incomeType;
        }

        public void setProdriskLevel(Integer prodriskLevel) {
            this.prodriskLevel = prodriskLevel;
        }

        public void setMaxDeficitRate(Double maxDeficitRate) {
            this.maxDeficitRate = maxDeficitRate;
        }

        public void setMinAssetNeed(Double minAssetNeed) {
            this.minAssetNeed = minAssetNeed;
        }

        public void setEligCtrlstr(String eligCtrlstr) {
            this.eligCtrlstr = eligCtrlstr;
        }

        public void setFinanceType(Character financeType) {
            this.financeType = financeType;
        }

        public void setValidDays(Integer validDays) {
            this.validDays = validDays;
        }

        public void setInvestTerm(Character investTerm) {
            this.investTerm = investTerm;
        }

        public void setEnEntrustWay(String enEntrustWay) {
            this.enEntrustWay = enEntrustWay;
        }

        public void setBankRiskLevel(Integer bankRiskLevel) {
            this.bankRiskLevel = bankRiskLevel;
        }

        public void setProdcodeSubType(String prodcodeSubType) {
            this.prodcodeSubType = prodcodeSubType;
        }

        public void setInvestKind(Character investKind) {
            this.investKind = investKind;
        }

        public void setOperFlag(Character operFlag) {
            this.operFlag = operFlag;
        }

        public void setStudyId(String studyId) {
            this.studyId = studyId;
        }

        public void setInvestTarget(Character investTarget) {
            this.investTarget = investTarget;
        }

        public void setAbroadInvestTerm(Character abroadInvestTerm) {
            this.abroadInvestTerm = abroadInvestTerm;
        }

        public void setComplexProdFlag(Character complexProdFlag) {
            this.complexProdFlag = complexProdFlag;
        }

        public void setMaxLossType(Character maxLossType) {
            this.maxLossType = maxLossType;
        }

        public void setClientTypeApply(Character clientTypeApply) {
            this.clientTypeApply = clientTypeApply;
        }

        public void setPromotionDateStr(String promotionDateStr) {
            this.promotionDateStr = promotionDateStr;
        }

        public void setMoneyType(String moneyType) {
            this.moneyType = moneyType;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostProductInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",prodtaNo:" + this.prodtaNo);
            buffer.append(",prodCode:" + this.prodCode);
            buffer.append(",prodrelativeCode:" + this.prodrelativeCode);
            buffer.append(",prodName:" + this.prodName);
            buffer.append(",prodcodeType:" + this.prodcodeType);
            buffer.append(",incomeType:" + this.incomeType);
            buffer.append(",prodriskLevel:" + this.prodriskLevel);
            buffer.append(",maxDeficitRate:" + this.maxDeficitRate);
            buffer.append(",minAssetNeed:" + this.minAssetNeed);
            buffer.append(",eligCtrlstr:" + this.eligCtrlstr);
            buffer.append(",financeType:" + this.financeType);
            buffer.append(",validDays:" + this.validDays);
            buffer.append(",investTerm:" + this.investTerm);
            buffer.append(",enEntrustWay:" + this.enEntrustWay);
            buffer.append(",bankRiskLevel:" + this.bankRiskLevel);
            buffer.append(",prodcodeSubType:" + this.prodcodeSubType);
            buffer.append(",investKind:" + this.investKind);
            buffer.append(",operFlag:" + this.operFlag);
            buffer.append(",studyId:" + this.studyId);
            buffer.append(",investTarget:" + this.investTarget);
            buffer.append(",abroadInvestTerm:" + this.abroadInvestTerm);
            buffer.append(",complexProdFlag:" + this.complexProdFlag);
            buffer.append(",maxLossType:" + this.maxLossType);
            buffer.append(",clientTypeApply:" + this.clientTypeApply);
            buffer.append(",promotionDateStr:" + this.promotionDateStr);
            buffer.append(",moneyType:" + this.moneyType);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.branchNo);
            builder.append(this.prodtaNo);
            builder.append(this.prodCode);
            builder.append(this.prodrelativeCode);
            builder.append(this.prodName);
            builder.append(this.prodcodeType);
            builder.append(this.incomeType);
            builder.append(this.prodriskLevel);
            builder.append(this.maxDeficitRate);
            builder.append(this.minAssetNeed);
            builder.append(this.eligCtrlstr);
            builder.append(this.financeType);
            builder.append(this.validDays);
            builder.append(this.investTerm);
            builder.append(this.enEntrustWay);
            builder.append(this.bankRiskLevel);
            builder.append(this.prodcodeSubType);
            builder.append(this.investKind);
            builder.append(this.operFlag);
            builder.append(this.studyId);
            builder.append(this.investTarget);
            builder.append(this.abroadInvestTerm);
            builder.append(this.complexProdFlag);
            builder.append(this.maxLossType);
            builder.append(this.clientTypeApply);
            builder.append(this.promotionDateStr);
            builder.append(this.moneyType);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.PostProductInnerInput) {
                InnerElgService.PostProductInnerInput test = (InnerElgService.PostProductInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.prodtaNo, test.prodtaNo);
                builder.append(this.prodCode, test.prodCode);
                builder.append(this.prodrelativeCode, test.prodrelativeCode);
                builder.append(this.prodName, test.prodName);
                builder.append(this.prodcodeType, test.prodcodeType);
                builder.append(this.incomeType, test.incomeType);
                builder.append(this.prodriskLevel, test.prodriskLevel);
                builder.append(this.maxDeficitRate, test.maxDeficitRate);
                builder.append(this.minAssetNeed, test.minAssetNeed);
                builder.append(this.eligCtrlstr, test.eligCtrlstr);
                builder.append(this.financeType, test.financeType);
                builder.append(this.validDays, test.validDays);
                builder.append(this.investTerm, test.investTerm);
                builder.append(this.enEntrustWay, test.enEntrustWay);
                builder.append(this.bankRiskLevel, test.bankRiskLevel);
                builder.append(this.prodcodeSubType, test.prodcodeSubType);
                builder.append(this.investKind, test.investKind);
                builder.append(this.operFlag, test.operFlag);
                builder.append(this.studyId, test.studyId);
                builder.append(this.investTarget, test.investTarget);
                builder.append(this.abroadInvestTerm, test.abroadInvestTerm);
                builder.append(this.complexProdFlag, test.complexProdFlag);
                builder.append(this.maxLossType, test.maxLossType);
                builder.append(this.clientTypeApply, test.clientTypeApply);
                builder.append(this.promotionDateStr, test.promotionDateStr);
                builder.append(this.moneyType, test.moneyType);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostOptclientinfoQuotaInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Long serialNo = 0L;
        private String opRemark = " ";

        public PostOptclientinfoQuotaInnerOutput() {
        }

        public Long getSerialNo() {
            return this.serialNo != null ? this.serialNo : 0L;
        }

        public String getOpRemark() {
            if (this.opRemark == null) {
                return " ";
            } else {
                return this.opRemark.isEmpty() ? " " : this.opRemark;
            }
        }

        public void setSerialNo(Long serialNo) {
            this.serialNo = serialNo;
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostOptclientinfoQuotaInnerOutput:(");
            buffer.append("serialNo:" + this.serialNo);
            buffer.append(",opRemark:" + this.opRemark);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.serialNo);
            builder.append(this.opRemark);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.PostOptclientinfoQuotaInnerOutput) {
                InnerElgService.PostOptclientinfoQuotaInnerOutput test = (InnerElgService.PostOptclientinfoQuotaInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.serialNo, test.serialNo);
                builder.append(this.opRemark, test.opRemark);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostOptclientinfoQuotaInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer branchNo = 0;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId = " ";
        @SinogramLength(
                min = 1,
                max = 4,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String exchangeType = " ";

        public PostOptclientinfoQuotaInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getExchangeType() {
            if (this.exchangeType == null) {
                return " ";
            } else {
                return this.exchangeType.isEmpty() ? " " : this.exchangeType;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostOptclientinfoQuotaInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.branchNo);
            builder.append(this.clientId);
            builder.append(this.exchangeType);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.PostOptclientinfoQuotaInnerInput) {
                InnerElgService.PostOptclientinfoQuotaInnerInput test = (InnerElgService.PostOptclientinfoQuotaInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.clientId, test.clientId);
                builder.append(this.exchangeType, test.exchangeType);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostOpenRightDetailInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Long serialNo = 0L;

        public PostOpenRightDetailInnerOutput() {
        }

        public Long getSerialNo() {
            return this.serialNo != null ? this.serialNo : 0L;
        }

        public void setSerialNo(Long serialNo) {
            this.serialNo = serialNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostOpenRightDetailInnerOutput:(");
            buffer.append("serialNo:" + this.serialNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.serialNo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.PostOpenRightDetailInnerOutput) {
                InnerElgService.PostOpenRightDetailInnerOutput test = (InnerElgService.PostOpenRightDetailInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.serialNo, test.serialNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostOpenRightDetailInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer branchNo = 0;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId = " ";
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String fundAccount = " ";
        @SinogramLength(
                min = 1,
                max = 20,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String stockAccount = " ";
        @SinogramLength(
                min = 1,
                max = 4,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String exchangeType = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character assetProp = ' ';
        @NotNull(
                message = "不能为空"
        )
        private Integer businessFlag = 0;
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String holderRight = " ";
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String remark = " ";

        public PostOpenRightDetailInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getStockAccount() {
            if (this.stockAccount == null) {
                return " ";
            } else {
                return this.stockAccount.isEmpty() ? " " : this.stockAccount;
            }
        }

        public String getExchangeType() {
            if (this.exchangeType == null) {
                return " ";
            } else {
                return this.exchangeType.isEmpty() ? " " : this.exchangeType;
            }
        }

        public Character getAssetProp() {
            return this.assetProp != null ? this.assetProp : ' ';
        }

        public Integer getBusinessFlag() {
            return this.businessFlag != null ? this.businessFlag : 0;
        }

        public String getHolderRight() {
            if (this.holderRight == null) {
                return " ";
            } else {
                return this.holderRight.isEmpty() ? " " : this.holderRight;
            }
        }

        public String getRemark() {
            if (this.remark == null) {
                return " ";
            } else {
                return this.remark.isEmpty() ? " " : this.remark;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setStockAccount(String stockAccount) {
            this.stockAccount = stockAccount;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public void setAssetProp(Character assetProp) {
            this.assetProp = assetProp;
        }

        public void setBusinessFlag(Integer businessFlag) {
            this.businessFlag = businessFlag;
        }

        public void setHolderRight(String holderRight) {
            this.holderRight = holderRight;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostOpenRightDetailInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",stockAccount:" + this.stockAccount);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(",assetProp:" + this.assetProp);
            buffer.append(",businessFlag:" + this.businessFlag);
            buffer.append(",holderRight:" + this.holderRight);
            buffer.append(",remark:" + this.remark);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.branchNo);
            builder.append(this.clientId);
            builder.append(this.fundAccount);
            builder.append(this.stockAccount);
            builder.append(this.exchangeType);
            builder.append(this.assetProp);
            builder.append(this.businessFlag);
            builder.append(this.holderRight);
            builder.append(this.remark);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.PostOpenRightDetailInnerInput) {
                InnerElgService.PostOpenRightDetailInnerInput test = (InnerElgService.PostOpenRightDetailInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.clientId, test.clientId);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.stockAccount, test.stockAccount);
                builder.append(this.exchangeType, test.exchangeType);
                builder.append(this.assetProp, test.assetProp);
                builder.append(this.businessFlag, test.businessFlag);
                builder.append(this.holderRight, test.holderRight);
                builder.append(this.remark, test.remark);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostElgsstrestradeacctInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Long serialNo = 0L;
        private String opRemark = " ";

        public PostElgsstrestradeacctInnerOutput() {
        }

        public Long getSerialNo() {
            return this.serialNo != null ? this.serialNo : 0L;
        }

        public String getOpRemark() {
            if (this.opRemark == null) {
                return " ";
            } else {
                return this.opRemark.isEmpty() ? " " : this.opRemark;
            }
        }

        public void setSerialNo(Long serialNo) {
            this.serialNo = serialNo;
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostElgsstrestradeacctInnerOutput:(");
            buffer.append("serialNo:" + this.serialNo);
            buffer.append(",opRemark:" + this.opRemark);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.serialNo);
            builder.append(this.opRemark);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.PostElgsstrestradeacctInnerOutput) {
                InnerElgService.PostElgsstrestradeacctInnerOutput test = (InnerElgService.PostElgsstrestradeacctInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.serialNo, test.serialNo);
                builder.append(this.opRemark, test.opRemark);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostElgsstrestradeacctInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer branchNo = 0;
        @SinogramLength(
                min = 1,
                max = 8,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String stockCode = " ";
        @SinogramLength(
                min = 1,
                max = 20,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String stockAccount = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String clientId = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fundAccount = " ";

        public PostElgsstrestradeacctInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getStockCode() {
            if (this.stockCode == null) {
                return " ";
            } else {
                return this.stockCode.isEmpty() ? " " : this.stockCode;
            }
        }

        public String getStockAccount() {
            if (this.stockAccount == null) {
                return " ";
            } else {
                return this.stockAccount.isEmpty() ? " " : this.stockAccount;
            }
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setStockCode(String stockCode) {
            this.stockCode = stockCode;
        }

        public void setStockAccount(String stockAccount) {
            this.stockAccount = stockAccount;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostElgsstrestradeacctInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",stockCode:" + this.stockCode);
            buffer.append(",stockAccount:" + this.stockAccount);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.branchNo);
            builder.append(this.stockCode);
            builder.append(this.stockAccount);
            builder.append(this.clientId);
            builder.append(this.fundAccount);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.PostElgsstrestradeacctInnerInput) {
                InnerElgService.PostElgsstrestradeacctInnerInput test = (InnerElgService.PostElgsstrestradeacctInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.stockCode, test.stockCode);
                builder.append(this.stockAccount, test.stockAccount);
                builder.append(this.clientId, test.clientId);
                builder.append(this.fundAccount, test.fundAccount);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostElgAccountOpenSyncInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String opRemark = " ";

        public PostElgAccountOpenSyncInnerOutput() {
        }

        public String getOpRemark() {
            if (this.opRemark == null) {
                return " ";
            } else {
                return this.opRemark.isEmpty() ? " " : this.opRemark;
            }
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostElgAccountOpenSyncInnerOutput:(");
            buffer.append("opRemark:" + this.opRemark);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opRemark);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.PostElgAccountOpenSyncInnerOutput) {
                InnerElgService.PostElgAccountOpenSyncInnerOutput test = (InnerElgService.PostElgAccountOpenSyncInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opRemark, test.opRemark);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostElgAccountOpenSyncInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer branchNo = 0;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fundAccount = " ";
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String exchangeType = " ";
        @SinogramLength(
                min = 0,
                max = 20,
                charset = "utf-8"
        )
        private String stockAccount = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character assetProp = ' ';

        public PostElgAccountOpenSyncInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getExchangeType() {
            if (this.exchangeType == null) {
                return " ";
            } else {
                return this.exchangeType.isEmpty() ? " " : this.exchangeType;
            }
        }

        public String getStockAccount() {
            if (this.stockAccount == null) {
                return " ";
            } else {
                return this.stockAccount.isEmpty() ? " " : this.stockAccount;
            }
        }

        public Character getAssetProp() {
            return this.assetProp != null ? this.assetProp : ' ';
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public void setStockAccount(String stockAccount) {
            this.stockAccount = stockAccount;
        }

        public void setAssetProp(Character assetProp) {
            this.assetProp = assetProp;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostElgAccountOpenSyncInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(",stockAccount:" + this.stockAccount);
            buffer.append(",assetProp:" + this.assetProp);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.branchNo);
            builder.append(this.clientId);
            builder.append(this.fundAccount);
            builder.append(this.exchangeType);
            builder.append(this.stockAccount);
            builder.append(this.assetProp);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.PostElgAccountOpenSyncInnerInput) {
                InnerElgService.PostElgAccountOpenSyncInnerInput test = (InnerElgService.PostElgAccountOpenSyncInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.clientId, test.clientId);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.exchangeType, test.exchangeType);
                builder.append(this.stockAccount, test.stockAccount);
                builder.append(this.assetProp, test.assetProp);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostDayinitinfoSqlInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer rowCount = 0;
        private String settleClob = " ";

        public PostDayinitinfoSqlInnerOutput() {
        }

        public Integer getRowCount() {
            return this.rowCount != null ? this.rowCount : 0;
        }

        public String getSettleClob() {
            if (this.settleClob == null) {
                return " ";
            } else {
                return this.settleClob.isEmpty() ? " " : this.settleClob;
            }
        }

        public void setRowCount(Integer rowCount) {
            this.rowCount = rowCount;
        }

        public void setSettleClob(String settleClob) {
            this.settleClob = settleClob;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostDayinitinfoSqlInnerOutput:(");
            buffer.append("rowCount:" + this.rowCount);
            buffer.append(",settleClob:" + this.settleClob);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.rowCount);
            builder.append(this.settleClob);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.PostDayinitinfoSqlInnerOutput) {
                InnerElgService.PostDayinitinfoSqlInnerOutput test = (InnerElgService.PostDayinitinfoSqlInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.rowCount, test.rowCount);
                builder.append(this.settleClob, test.settleClob);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostDayinitinfoSqlInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer branchNo = 0;
        @SinogramLength(
                min = 0,
                max = 16000,
                charset = "utf-8"
        )
        private String executeSql = " ";
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String tokenKey = " ";
        private Integer actionIn = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character dealMode = ' ';

        public PostDayinitinfoSqlInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getExecuteSql() {
            if (this.executeSql == null) {
                return " ";
            } else {
                return this.executeSql.isEmpty() ? " " : this.executeSql;
            }
        }

        public String getTokenKey() {
            if (this.tokenKey == null) {
                return " ";
            } else {
                return this.tokenKey.isEmpty() ? " " : this.tokenKey;
            }
        }

        public Integer getActionIn() {
            return this.actionIn != null ? this.actionIn : 0;
        }

        public Character getDealMode() {
            return this.dealMode != null ? this.dealMode : ' ';
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setExecuteSql(String executeSql) {
            this.executeSql = executeSql;
        }

        public void setTokenKey(String tokenKey) {
            this.tokenKey = tokenKey;
        }

        public void setActionIn(Integer actionIn) {
            this.actionIn = actionIn;
        }

        public void setDealMode(Character dealMode) {
            this.dealMode = dealMode;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostDayinitinfoSqlInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",executeSql:" + this.executeSql);
            buffer.append(",tokenKey:" + this.tokenKey);
            buffer.append(",actionIn:" + this.actionIn);
            buffer.append(",dealMode:" + this.dealMode);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.branchNo);
            builder.append(this.executeSql);
            builder.append(this.tokenKey);
            builder.append(this.actionIn);
            builder.append(this.dealMode);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.PostDayinitinfoSqlInnerInput) {
                InnerElgService.PostDayinitinfoSqlInnerInput test = (InnerElgService.PostDayinitinfoSqlInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.executeSql, test.executeSql);
                builder.append(this.tokenKey, test.tokenKey);
                builder.append(this.actionIn, test.actionIn);
                builder.append(this.dealMode, test.dealMode);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostDayinitinfoDataToprevInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer initDate = 0;

        public PostDayinitinfoDataToprevInnerOutput() {
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostDayinitinfoDataToprevInnerOutput:(");
            buffer.append("initDate:" + this.initDate);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.initDate);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.PostDayinitinfoDataToprevInnerOutput) {
                InnerElgService.PostDayinitinfoDataToprevInnerOutput test = (InnerElgService.PostDayinitinfoDataToprevInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.initDate, test.initDate);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostDayinitinfoDataToprevInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer branchNo = 0;
        private Integer initDate = 0;

        public PostDayinitinfoDataToprevInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostDayinitinfoDataToprevInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",initDate:" + this.initDate);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.branchNo);
            builder.append(this.initDate);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.PostDayinitinfoDataToprevInnerInput) {
                InnerElgService.PostDayinitinfoDataToprevInnerInput test = (InnerElgService.PostDayinitinfoDataToprevInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.initDate, test.initDate);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostCusPreCheckInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String paramId = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character needFlag = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character modifyAble = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character passFlag = ' ';
        private String showTitle = " ";
        private String tipsDetail = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character weakRiskFlag = ' ';
        private String groupCode = " ";

        public PostCusPreCheckInnerOutput() {
        }

        public String getParamId() {
            if (this.paramId == null) {
                return " ";
            } else {
                return this.paramId.isEmpty() ? " " : this.paramId;
            }
        }

        public Character getNeedFlag() {
            return this.needFlag != null ? this.needFlag : ' ';
        }

        public Character getModifyAble() {
            return this.modifyAble != null ? this.modifyAble : ' ';
        }

        public Character getPassFlag() {
            return this.passFlag != null ? this.passFlag : ' ';
        }

        public String getShowTitle() {
            if (this.showTitle == null) {
                return " ";
            } else {
                return this.showTitle.isEmpty() ? " " : this.showTitle;
            }
        }

        public String getTipsDetail() {
            if (this.tipsDetail == null) {
                return " ";
            } else {
                return this.tipsDetail.isEmpty() ? " " : this.tipsDetail;
            }
        }

        public Character getWeakRiskFlag() {
            return this.weakRiskFlag != null ? this.weakRiskFlag : ' ';
        }

        public String getGroupCode() {
            if (this.groupCode == null) {
                return " ";
            } else {
                return this.groupCode.isEmpty() ? " " : this.groupCode;
            }
        }

        public void setParamId(String paramId) {
            this.paramId = paramId;
        }

        public void setNeedFlag(Character needFlag) {
            this.needFlag = needFlag;
        }

        public void setModifyAble(Character modifyAble) {
            this.modifyAble = modifyAble;
        }

        public void setPassFlag(Character passFlag) {
            this.passFlag = passFlag;
        }

        public void setShowTitle(String showTitle) {
            this.showTitle = showTitle;
        }

        public void setTipsDetail(String tipsDetail) {
            this.tipsDetail = tipsDetail;
        }

        public void setWeakRiskFlag(Character weakRiskFlag) {
            this.weakRiskFlag = weakRiskFlag;
        }

        public void setGroupCode(String groupCode) {
            this.groupCode = groupCode;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostCusPreCheckInnerOutput:(");
            buffer.append("paramId:" + this.paramId);
            buffer.append(",needFlag:" + this.needFlag);
            buffer.append(",modifyAble:" + this.modifyAble);
            buffer.append(",passFlag:" + this.passFlag);
            buffer.append(",showTitle:" + this.showTitle);
            buffer.append(",tipsDetail:" + this.tipsDetail);
            buffer.append(",weakRiskFlag:" + this.weakRiskFlag);
            buffer.append(",groupCode:" + this.groupCode);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.paramId);
            builder.append(this.needFlag);
            builder.append(this.modifyAble);
            builder.append(this.passFlag);
            builder.append(this.showTitle);
            builder.append(this.tipsDetail);
            builder.append(this.weakRiskFlag);
            builder.append(this.groupCode);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.PostCusPreCheckInnerOutput) {
                InnerElgService.PostCusPreCheckInnerOutput test = (InnerElgService.PostCusPreCheckInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.paramId, test.paramId);
                builder.append(this.needFlag, test.needFlag);
                builder.append(this.modifyAble, test.modifyAble);
                builder.append(this.passFlag, test.passFlag);
                builder.append(this.showTitle, test.showTitle);
                builder.append(this.tipsDetail, test.tipsDetail);
                builder.append(this.weakRiskFlag, test.weakRiskFlag);
                builder.append(this.groupCode, test.groupCode);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostCusPreCheckInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer branchNo = 0;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId = " ";
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String acptBusinKind = " ";
        @SinogramLength(
                min = 1,
                max = 10,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String acptBusinId = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String enParamId = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fundAccount = " ";
        @SinogramLength(
                min = 0,
                max = 20,
                charset = "utf-8"
        )
        private String stockAccount = " ";

        public PostCusPreCheckInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getAcptBusinKind() {
            if (this.acptBusinKind == null) {
                return " ";
            } else {
                return this.acptBusinKind.isEmpty() ? " " : this.acptBusinKind;
            }
        }

        public String getAcptBusinId() {
            if (this.acptBusinId == null) {
                return " ";
            } else {
                return this.acptBusinId.isEmpty() ? " " : this.acptBusinId;
            }
        }

        public String getEnParamId() {
            if (this.enParamId == null) {
                return " ";
            } else {
                return this.enParamId.isEmpty() ? " " : this.enParamId;
            }
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getStockAccount() {
            if (this.stockAccount == null) {
                return " ";
            } else {
                return this.stockAccount.isEmpty() ? " " : this.stockAccount;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setAcptBusinKind(String acptBusinKind) {
            this.acptBusinKind = acptBusinKind;
        }

        public void setAcptBusinId(String acptBusinId) {
            this.acptBusinId = acptBusinId;
        }

        public void setEnParamId(String enParamId) {
            this.enParamId = enParamId;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setStockAccount(String stockAccount) {
            this.stockAccount = stockAccount;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostCusPreCheckInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",acptBusinKind:" + this.acptBusinKind);
            buffer.append(",acptBusinId:" + this.acptBusinId);
            buffer.append(",enParamId:" + this.enParamId);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",stockAccount:" + this.stockAccount);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.branchNo);
            builder.append(this.clientId);
            builder.append(this.acptBusinKind);
            builder.append(this.acptBusinId);
            builder.append(this.enParamId);
            builder.append(this.fundAccount);
            builder.append(this.stockAccount);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.PostCusPreCheckInnerInput) {
                InnerElgService.PostCusPreCheckInnerInput test = (InnerElgService.PostCusPreCheckInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.clientId, test.clientId);
                builder.append(this.acptBusinKind, test.acptBusinKind);
                builder.append(this.acptBusinId, test.acptBusinId);
                builder.append(this.enParamId, test.enParamId);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.stockAccount, test.stockAccount);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostCreditQuotaUpdateInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer branchNo = 0;
        private Integer initDate = 0;

        public PostCreditQuotaUpdateInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostCreditQuotaUpdateInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",initDate:" + this.initDate);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.branchNo);
            builder.append(this.initDate);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.PostCreditQuotaUpdateInnerInput) {
                InnerElgService.PostCreditQuotaUpdateInnerInput test = (InnerElgService.PostCreditQuotaUpdateInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.initDate, test.initDate);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostAutoBondExportInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer branchNo = 0;
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String filePath = " ";
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String attachPath = " ";
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String exchangeType = " ";

        public PostAutoBondExportInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getFilePath() {
            if (this.filePath == null) {
                return " ";
            } else {
                return this.filePath.isEmpty() ? " " : this.filePath;
            }
        }

        public String getAttachPath() {
            if (this.attachPath == null) {
                return " ";
            } else {
                return this.attachPath.isEmpty() ? " " : this.attachPath;
            }
        }

        public String getExchangeType() {
            if (this.exchangeType == null) {
                return " ";
            } else {
                return this.exchangeType.isEmpty() ? " " : this.exchangeType;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setFilePath(String filePath) {
            this.filePath = filePath;
        }

        public void setAttachPath(String attachPath) {
            this.attachPath = attachPath;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostAutoBondExportInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",filePath:" + this.filePath);
            buffer.append(",attachPath:" + this.attachPath);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.branchNo);
            builder.append(this.filePath);
            builder.append(this.attachPath);
            builder.append(this.exchangeType);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.PostAutoBondExportInnerInput) {
                InnerElgService.PostAutoBondExportInnerInput test = (InnerElgService.PostAutoBondExportInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.filePath, test.filePath);
                builder.append(this.attachPath, test.attachPath);
                builder.append(this.exchangeType, test.exchangeType);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostAgreementSignInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String agreementId = " ";

        public PostAgreementSignInnerOutput() {
        }

        public String getAgreementId() {
            if (this.agreementId == null) {
                return " ";
            } else {
                return this.agreementId.isEmpty() ? " " : this.agreementId;
            }
        }

        public void setAgreementId(String agreementId) {
            this.agreementId = agreementId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostAgreementSignInnerOutput:(");
            buffer.append("agreementId:" + this.agreementId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.agreementId);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.PostAgreementSignInnerOutput) {
                InnerElgService.PostAgreementSignInnerOutput test = (InnerElgService.PostAgreementSignInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.agreementId, test.agreementId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostAgreementSignInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer branchNo = 0;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fundAccount = " ";
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String exchangeType = " ";
        @SinogramLength(
                min = 1,
                max = 10,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String acptBusinId = " ";
        @SinogramLength(
                min = 1,
                max = 4,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String acptBusinKind = " ";
        @SinogramLength(
                min = 1,
                max = 2000,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String enAgreeType = " ";
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String remark = " ";

        public PostAgreementSignInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getExchangeType() {
            if (this.exchangeType == null) {
                return " ";
            } else {
                return this.exchangeType.isEmpty() ? " " : this.exchangeType;
            }
        }

        public String getAcptBusinId() {
            if (this.acptBusinId == null) {
                return " ";
            } else {
                return this.acptBusinId.isEmpty() ? " " : this.acptBusinId;
            }
        }

        public String getAcptBusinKind() {
            if (this.acptBusinKind == null) {
                return " ";
            } else {
                return this.acptBusinKind.isEmpty() ? " " : this.acptBusinKind;
            }
        }

        public String getEnAgreeType() {
            if (this.enAgreeType == null) {
                return " ";
            } else {
                return this.enAgreeType.isEmpty() ? " " : this.enAgreeType;
            }
        }

        public String getRemark() {
            if (this.remark == null) {
                return " ";
            } else {
                return this.remark.isEmpty() ? " " : this.remark;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public void setAcptBusinId(String acptBusinId) {
            this.acptBusinId = acptBusinId;
        }

        public void setAcptBusinKind(String acptBusinKind) {
            this.acptBusinKind = acptBusinKind;
        }

        public void setEnAgreeType(String enAgreeType) {
            this.enAgreeType = enAgreeType;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostAgreementSignInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(",acptBusinId:" + this.acptBusinId);
            buffer.append(",acptBusinKind:" + this.acptBusinKind);
            buffer.append(",enAgreeType:" + this.enAgreeType);
            buffer.append(",remark:" + this.remark);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.branchNo);
            builder.append(this.clientId);
            builder.append(this.fundAccount);
            builder.append(this.exchangeType);
            builder.append(this.acptBusinId);
            builder.append(this.acptBusinKind);
            builder.append(this.enAgreeType);
            builder.append(this.remark);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.PostAgreementSignInnerInput) {
                InnerElgService.PostAgreementSignInnerInput test = (InnerElgService.PostAgreementSignInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.clientId, test.clientId);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.exchangeType, test.exchangeType);
                builder.append(this.acptBusinId, test.acptBusinId);
                builder.append(this.acptBusinKind, test.acptBusinKind);
                builder.append(this.enAgreeType, test.enAgreeType);
                builder.append(this.remark, test.remark);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetStockAcctCancelValidateInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String checkId = " ";
        private Integer noticeNo = 0;
        private String noticeInfo = " ";

        public GetStockAcctCancelValidateInnerOutput() {
        }

        public String getCheckId() {
            if (this.checkId == null) {
                return " ";
            } else {
                return this.checkId.isEmpty() ? " " : this.checkId;
            }
        }

        public Integer getNoticeNo() {
            return this.noticeNo != null ? this.noticeNo : 0;
        }

        public String getNoticeInfo() {
            if (this.noticeInfo == null) {
                return " ";
            } else {
                return this.noticeInfo.isEmpty() ? " " : this.noticeInfo;
            }
        }

        public void setCheckId(String checkId) {
            this.checkId = checkId;
        }

        public void setNoticeNo(Integer noticeNo) {
            this.noticeNo = noticeNo;
        }

        public void setNoticeInfo(String noticeInfo) {
            this.noticeInfo = noticeInfo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetStockAcctCancelValidateInnerOutput:(");
            buffer.append("checkId:" + this.checkId);
            buffer.append(",noticeNo:" + this.noticeNo);
            buffer.append(",noticeInfo:" + this.noticeInfo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.checkId);
            builder.append(this.noticeNo);
            builder.append(this.noticeInfo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.GetStockAcctCancelValidateInnerOutput) {
                InnerElgService.GetStockAcctCancelValidateInnerOutput test = (InnerElgService.GetStockAcctCancelValidateInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.checkId, test.checkId);
                builder.append(this.noticeNo, test.noticeNo);
                builder.append(this.noticeInfo, test.noticeInfo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetStockAcctCancelValidateInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer branchNo = 0;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId = " ";
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String fundAccount = " ";
        @SinogramLength(
                min = 1,
                max = 4,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String exchangeType = " ";
        @SinogramLength(
                min = 1,
                max = 20,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String stockAccount = " ";

        public GetStockAcctCancelValidateInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getExchangeType() {
            if (this.exchangeType == null) {
                return " ";
            } else {
                return this.exchangeType.isEmpty() ? " " : this.exchangeType;
            }
        }

        public String getStockAccount() {
            if (this.stockAccount == null) {
                return " ";
            } else {
                return this.stockAccount.isEmpty() ? " " : this.stockAccount;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public void setStockAccount(String stockAccount) {
            this.stockAccount = stockAccount;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetStockAcctCancelValidateInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(",stockAccount:" + this.stockAccount);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.branchNo);
            builder.append(this.clientId);
            builder.append(this.fundAccount);
            builder.append(this.exchangeType);
            builder.append(this.stockAccount);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.GetStockAcctCancelValidateInnerInput) {
                InnerElgService.GetStockAcctCancelValidateInnerInput test = (InnerElgService.GetStockAcctCancelValidateInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.clientId, test.clientId);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.exchangeType, test.exchangeType);
                builder.append(this.stockAccount, test.stockAccount);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetSstaccountInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String clientId = " ";
        private String fundAccount = " ";
        private String exchangeType = " ";
        private String stockAccount = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character organFlag = ' ';
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double assetBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 4
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double registerFund = 0.0D;
        private Integer firstExchdate = 0;
        private Integer subRiskDate = 0;
        private Integer registerDate = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character sstacctStatus = ' ';
        private Integer rightOpenDate = 0;
        private Integer reportDate = 0;
        private String remark = " ";
        private String positionStr = " ";
        private Integer opBranchNo = 0;
        private String operatorNo = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character sstReportType = ' ';

        public GetSstaccountInnerOutput() {
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getExchangeType() {
            if (this.exchangeType == null) {
                return " ";
            } else {
                return this.exchangeType.isEmpty() ? " " : this.exchangeType;
            }
        }

        public String getStockAccount() {
            if (this.stockAccount == null) {
                return " ";
            } else {
                return this.stockAccount.isEmpty() ? " " : this.stockAccount;
            }
        }

        public Character getOrganFlag() {
            return this.organFlag != null ? this.organFlag : ' ';
        }

        public Double getAssetBalance() {
            return this.assetBalance != null ? this.assetBalance : 0.0D;
        }

        public Double getRegisterFund() {
            return this.registerFund != null ? this.registerFund : 0.0D;
        }

        public Integer getFirstExchdate() {
            return this.firstExchdate != null ? this.firstExchdate : 0;
        }

        public Integer getSubRiskDate() {
            return this.subRiskDate != null ? this.subRiskDate : 0;
        }

        public Integer getRegisterDate() {
            return this.registerDate != null ? this.registerDate : 0;
        }

        public Character getSstacctStatus() {
            return this.sstacctStatus != null ? this.sstacctStatus : ' ';
        }

        public Integer getRightOpenDate() {
            return this.rightOpenDate != null ? this.rightOpenDate : 0;
        }

        public Integer getReportDate() {
            return this.reportDate != null ? this.reportDate : 0;
        }

        public String getRemark() {
            if (this.remark == null) {
                return " ";
            } else {
                return this.remark.isEmpty() ? " " : this.remark;
            }
        }

        public String getPositionStr() {
            if (this.positionStr == null) {
                return " ";
            } else {
                return this.positionStr.isEmpty() ? " " : this.positionStr;
            }
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public Character getSstReportType() {
            return this.sstReportType != null ? this.sstReportType : ' ';
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public void setStockAccount(String stockAccount) {
            this.stockAccount = stockAccount;
        }

        public void setOrganFlag(Character organFlag) {
            this.organFlag = organFlag;
        }

        public void setAssetBalance(Double assetBalance) {
            this.assetBalance = assetBalance;
        }

        public void setRegisterFund(Double registerFund) {
            this.registerFund = registerFund;
        }

        public void setFirstExchdate(Integer firstExchdate) {
            this.firstExchdate = firstExchdate;
        }

        public void setSubRiskDate(Integer subRiskDate) {
            this.subRiskDate = subRiskDate;
        }

        public void setRegisterDate(Integer registerDate) {
            this.registerDate = registerDate;
        }

        public void setSstacctStatus(Character sstacctStatus) {
            this.sstacctStatus = sstacctStatus;
        }

        public void setRightOpenDate(Integer rightOpenDate) {
            this.rightOpenDate = rightOpenDate;
        }

        public void setReportDate(Integer reportDate) {
            this.reportDate = reportDate;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public void setPositionStr(String positionStr) {
            this.positionStr = positionStr;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setSstReportType(Character sstReportType) {
            this.sstReportType = sstReportType;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetSstaccountInnerOutput:(");
            buffer.append("clientId:" + this.clientId);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(",stockAccount:" + this.stockAccount);
            buffer.append(",organFlag:" + this.organFlag);
            buffer.append(",assetBalance:" + this.assetBalance);
            buffer.append(",registerFund:" + this.registerFund);
            buffer.append(",firstExchdate:" + this.firstExchdate);
            buffer.append(",subRiskDate:" + this.subRiskDate);
            buffer.append(",registerDate:" + this.registerDate);
            buffer.append(",sstacctStatus:" + this.sstacctStatus);
            buffer.append(",rightOpenDate:" + this.rightOpenDate);
            buffer.append(",reportDate:" + this.reportDate);
            buffer.append(",remark:" + this.remark);
            buffer.append(",positionStr:" + this.positionStr);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",sstReportType:" + this.sstReportType);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.clientId);
            builder.append(this.fundAccount);
            builder.append(this.exchangeType);
            builder.append(this.stockAccount);
            builder.append(this.organFlag);
            builder.append(this.assetBalance);
            builder.append(this.registerFund);
            builder.append(this.firstExchdate);
            builder.append(this.subRiskDate);
            builder.append(this.registerDate);
            builder.append(this.sstacctStatus);
            builder.append(this.rightOpenDate);
            builder.append(this.reportDate);
            builder.append(this.remark);
            builder.append(this.positionStr);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.sstReportType);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.GetSstaccountInnerOutput) {
                InnerElgService.GetSstaccountInnerOutput test = (InnerElgService.GetSstaccountInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.clientId, test.clientId);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.exchangeType, test.exchangeType);
                builder.append(this.stockAccount, test.stockAccount);
                builder.append(this.organFlag, test.organFlag);
                builder.append(this.assetBalance, test.assetBalance);
                builder.append(this.registerFund, test.registerFund);
                builder.append(this.firstExchdate, test.firstExchdate);
                builder.append(this.subRiskDate, test.subRiskDate);
                builder.append(this.registerDate, test.registerDate);
                builder.append(this.sstacctStatus, test.sstacctStatus);
                builder.append(this.rightOpenDate, test.rightOpenDate);
                builder.append(this.reportDate, test.reportDate);
                builder.append(this.remark, test.remark);
                builder.append(this.positionStr, test.positionStr);
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.sstReportType, test.sstReportType);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetSstaccountInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer branchNo = 0;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fundAccount = " ";
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String exchangeType = " ";
        @SinogramLength(
                min = 0,
                max = 20,
                charset = "utf-8"
        )
        private String stockAccount = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character sstReportType = ' ';

        public GetSstaccountInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getExchangeType() {
            if (this.exchangeType == null) {
                return " ";
            } else {
                return this.exchangeType.isEmpty() ? " " : this.exchangeType;
            }
        }

        public String getStockAccount() {
            if (this.stockAccount == null) {
                return " ";
            } else {
                return this.stockAccount.isEmpty() ? " " : this.stockAccount;
            }
        }

        public Character getSstReportType() {
            return this.sstReportType != null ? this.sstReportType : ' ';
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public void setStockAccount(String stockAccount) {
            this.stockAccount = stockAccount;
        }

        public void setSstReportType(Character sstReportType) {
            this.sstReportType = sstReportType;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetSstaccountInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(",stockAccount:" + this.stockAccount);
            buffer.append(",sstReportType:" + this.sstReportType);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.branchNo);
            builder.append(this.clientId);
            builder.append(this.fundAccount);
            builder.append(this.exchangeType);
            builder.append(this.stockAccount);
            builder.append(this.sstReportType);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.GetSstaccountInnerInput) {
                InnerElgService.GetSstaccountInnerInput test = (InnerElgService.GetSstaccountInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.clientId, test.clientId);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.exchangeType, test.exchangeType);
                builder.append(this.stockAccount, test.stockAccount);
                builder.append(this.sstReportType, test.sstReportType);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetQueryIsTradingDayInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character successFlag = ' ';

        public GetQueryIsTradingDayInnerOutput() {
        }

        public Character getSuccessFlag() {
            return this.successFlag != null ? this.successFlag : ' ';
        }

        public void setSuccessFlag(Character successFlag) {
            this.successFlag = successFlag;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetQueryIsTradingDayInnerOutput:(");
            buffer.append("successFlag:" + this.successFlag);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.successFlag);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.GetQueryIsTradingDayInnerOutput) {
                InnerElgService.GetQueryIsTradingDayInnerOutput test = (InnerElgService.GetQueryIsTradingDayInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.successFlag, test.successFlag);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetQueryIsTradingDayInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer branchNo = 0;
        private Integer initDate = 0;

        public GetQueryIsTradingDayInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetQueryIsTradingDayInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",initDate:" + this.initDate);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.branchNo);
            builder.append(this.initDate);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.GetQueryIsTradingDayInnerInput) {
                InnerElgService.GetQueryIsTradingDayInnerInput test = (InnerElgService.GetQueryIsTradingDayInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.initDate, test.initDate);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class DeleteProductInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Long serialNo = 0L;
        private String opRemark = " ";

        public DeleteProductInnerOutput() {
        }

        public Long getSerialNo() {
            return this.serialNo != null ? this.serialNo : 0L;
        }

        public String getOpRemark() {
            if (this.opRemark == null) {
                return " ";
            } else {
                return this.opRemark.isEmpty() ? " " : this.opRemark;
            }
        }

        public void setSerialNo(Long serialNo) {
            this.serialNo = serialNo;
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("DeleteProductInnerOutput:(");
            buffer.append("serialNo:" + this.serialNo);
            buffer.append(",opRemark:" + this.opRemark);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.serialNo);
            builder.append(this.opRemark);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.DeleteProductInnerOutput) {
                InnerElgService.DeleteProductInnerOutput test = (InnerElgService.DeleteProductInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.serialNo, test.serialNo);
                builder.append(this.opRemark, test.opRemark);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class DeleteProductInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer branchNo = 0;
        @SinogramLength(
                min = 0,
                max = 24,
                charset = "utf-8"
        )
        private String prodtaNo = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String prodCode = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String prodrelativeCode = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character financeType = ' ';
        @NotNull(
                message = "不能为空"
        )
        private Integer updateDate = 0;
        @NotNull(
                message = "不能为空"
        )
        private Integer updateTime = 0;

        public DeleteProductInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getProdtaNo() {
            if (this.prodtaNo == null) {
                return " ";
            } else {
                return this.prodtaNo.isEmpty() ? " " : this.prodtaNo;
            }
        }

        public String getProdCode() {
            if (this.prodCode == null) {
                return " ";
            } else {
                return this.prodCode.isEmpty() ? " " : this.prodCode;
            }
        }

        public String getProdrelativeCode() {
            if (this.prodrelativeCode == null) {
                return " ";
            } else {
                return this.prodrelativeCode.isEmpty() ? " " : this.prodrelativeCode;
            }
        }

        public Character getFinanceType() {
            return this.financeType != null ? this.financeType : ' ';
        }

        public Integer getUpdateDate() {
            return this.updateDate != null ? this.updateDate : 0;
        }

        public Integer getUpdateTime() {
            return this.updateTime != null ? this.updateTime : 0;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setProdtaNo(String prodtaNo) {
            this.prodtaNo = prodtaNo;
        }

        public void setProdCode(String prodCode) {
            this.prodCode = prodCode;
        }

        public void setProdrelativeCode(String prodrelativeCode) {
            this.prodrelativeCode = prodrelativeCode;
        }

        public void setFinanceType(Character financeType) {
            this.financeType = financeType;
        }

        public void setUpdateDate(Integer updateDate) {
            this.updateDate = updateDate;
        }

        public void setUpdateTime(Integer updateTime) {
            this.updateTime = updateTime;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("DeleteProductInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",prodtaNo:" + this.prodtaNo);
            buffer.append(",prodCode:" + this.prodCode);
            buffer.append(",prodrelativeCode:" + this.prodrelativeCode);
            buffer.append(",financeType:" + this.financeType);
            buffer.append(",updateDate:" + this.updateDate);
            buffer.append(",updateTime:" + this.updateTime);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.branchNo);
            builder.append(this.prodtaNo);
            builder.append(this.prodCode);
            builder.append(this.prodrelativeCode);
            builder.append(this.financeType);
            builder.append(this.updateDate);
            builder.append(this.updateTime);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.DeleteProductInnerInput) {
                InnerElgService.DeleteProductInnerInput test = (InnerElgService.DeleteProductInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.prodtaNo, test.prodtaNo);
                builder.append(this.prodCode, test.prodCode);
                builder.append(this.prodrelativeCode, test.prodrelativeCode);
                builder.append(this.financeType, test.financeType);
                builder.append(this.updateDate, test.updateDate);
                builder.append(this.updateTime, test.updateTime);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetProductInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String prodtaNo = " ";
        private String prodCode = " ";
        private String prodName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character prodcodeType = ' ';
        private String prodcodeSubType = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character investKind = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character incomeType = ' ';
        private Integer prodriskLevel = 0;
        @SerializeDoubleDigit(
                digit = 8
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double maxDeficitRate = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double minAssetNeed = 0.0D;
        private String eligCtrlstr = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character financeType = ' ';
        private Integer validDays = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character investTerm = ' ';
        private String enEntrustWay = " ";
        private Integer bankRiskLevel = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character investTarget = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character abroadInvestTerm = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character maxLossType = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character complexProdFlag = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character clientTypeApply = ' ';
        private String studyId = " ";
        private String promotionDateStr = " ";
        private Integer modifyTimes = 0;
        private Integer updateDate = 0;
        private Integer updateTime = 0;
        private String moneyType = " ";

        public GetProductInnerOutput() {
        }

        public String getProdtaNo() {
            if (this.prodtaNo == null) {
                return " ";
            } else {
                return this.prodtaNo.isEmpty() ? " " : this.prodtaNo;
            }
        }

        public String getProdCode() {
            if (this.prodCode == null) {
                return " ";
            } else {
                return this.prodCode.isEmpty() ? " " : this.prodCode;
            }
        }

        public String getProdName() {
            if (this.prodName == null) {
                return " ";
            } else {
                return this.prodName.isEmpty() ? " " : this.prodName;
            }
        }

        public Character getProdcodeType() {
            return this.prodcodeType != null ? this.prodcodeType : ' ';
        }

        public String getProdcodeSubType() {
            if (this.prodcodeSubType == null) {
                return " ";
            } else {
                return this.prodcodeSubType.isEmpty() ? " " : this.prodcodeSubType;
            }
        }

        public Character getInvestKind() {
            return this.investKind != null ? this.investKind : ' ';
        }

        public Character getIncomeType() {
            return this.incomeType != null ? this.incomeType : ' ';
        }

        public Integer getProdriskLevel() {
            return this.prodriskLevel != null ? this.prodriskLevel : 0;
        }

        public Double getMaxDeficitRate() {
            return this.maxDeficitRate != null ? this.maxDeficitRate : 0.0D;
        }

        public Double getMinAssetNeed() {
            return this.minAssetNeed != null ? this.minAssetNeed : 0.0D;
        }

        public String getEligCtrlstr() {
            if (this.eligCtrlstr == null) {
                return " ";
            } else {
                return this.eligCtrlstr.isEmpty() ? " " : this.eligCtrlstr;
            }
        }

        public Character getFinanceType() {
            return this.financeType != null ? this.financeType : ' ';
        }

        public Integer getValidDays() {
            return this.validDays != null ? this.validDays : 0;
        }

        public Character getInvestTerm() {
            return this.investTerm != null ? this.investTerm : ' ';
        }

        public String getEnEntrustWay() {
            if (this.enEntrustWay == null) {
                return " ";
            } else {
                return this.enEntrustWay.isEmpty() ? " " : this.enEntrustWay;
            }
        }

        public Integer getBankRiskLevel() {
            return this.bankRiskLevel != null ? this.bankRiskLevel : 0;
        }

        public Character getInvestTarget() {
            return this.investTarget != null ? this.investTarget : ' ';
        }

        public Character getAbroadInvestTerm() {
            return this.abroadInvestTerm != null ? this.abroadInvestTerm : ' ';
        }

        public Character getMaxLossType() {
            return this.maxLossType != null ? this.maxLossType : ' ';
        }

        public Character getComplexProdFlag() {
            return this.complexProdFlag != null ? this.complexProdFlag : ' ';
        }

        public Character getClientTypeApply() {
            return this.clientTypeApply != null ? this.clientTypeApply : ' ';
        }

        public String getStudyId() {
            if (this.studyId == null) {
                return " ";
            } else {
                return this.studyId.isEmpty() ? " " : this.studyId;
            }
        }

        public String getPromotionDateStr() {
            if (this.promotionDateStr == null) {
                return " ";
            } else {
                return this.promotionDateStr.isEmpty() ? " " : this.promotionDateStr;
            }
        }

        public Integer getModifyTimes() {
            return this.modifyTimes != null ? this.modifyTimes : 0;
        }

        public Integer getUpdateDate() {
            return this.updateDate != null ? this.updateDate : 0;
        }

        public Integer getUpdateTime() {
            return this.updateTime != null ? this.updateTime : 0;
        }

        public String getMoneyType() {
            if (this.moneyType == null) {
                return " ";
            } else {
                return this.moneyType.isEmpty() ? " " : this.moneyType;
            }
        }

        public void setProdtaNo(String prodtaNo) {
            this.prodtaNo = prodtaNo;
        }

        public void setProdCode(String prodCode) {
            this.prodCode = prodCode;
        }

        public void setProdName(String prodName) {
            this.prodName = prodName;
        }

        public void setProdcodeType(Character prodcodeType) {
            this.prodcodeType = prodcodeType;
        }

        public void setProdcodeSubType(String prodcodeSubType) {
            this.prodcodeSubType = prodcodeSubType;
        }

        public void setInvestKind(Character investKind) {
            this.investKind = investKind;
        }

        public void setIncomeType(Character incomeType) {
            this.incomeType = incomeType;
        }

        public void setProdriskLevel(Integer prodriskLevel) {
            this.prodriskLevel = prodriskLevel;
        }

        public void setMaxDeficitRate(Double maxDeficitRate) {
            this.maxDeficitRate = maxDeficitRate;
        }

        public void setMinAssetNeed(Double minAssetNeed) {
            this.minAssetNeed = minAssetNeed;
        }

        public void setEligCtrlstr(String eligCtrlstr) {
            this.eligCtrlstr = eligCtrlstr;
        }

        public void setFinanceType(Character financeType) {
            this.financeType = financeType;
        }

        public void setValidDays(Integer validDays) {
            this.validDays = validDays;
        }

        public void setInvestTerm(Character investTerm) {
            this.investTerm = investTerm;
        }

        public void setEnEntrustWay(String enEntrustWay) {
            this.enEntrustWay = enEntrustWay;
        }

        public void setBankRiskLevel(Integer bankRiskLevel) {
            this.bankRiskLevel = bankRiskLevel;
        }

        public void setInvestTarget(Character investTarget) {
            this.investTarget = investTarget;
        }

        public void setAbroadInvestTerm(Character abroadInvestTerm) {
            this.abroadInvestTerm = abroadInvestTerm;
        }

        public void setMaxLossType(Character maxLossType) {
            this.maxLossType = maxLossType;
        }

        public void setComplexProdFlag(Character complexProdFlag) {
            this.complexProdFlag = complexProdFlag;
        }

        public void setClientTypeApply(Character clientTypeApply) {
            this.clientTypeApply = clientTypeApply;
        }

        public void setStudyId(String studyId) {
            this.studyId = studyId;
        }

        public void setPromotionDateStr(String promotionDateStr) {
            this.promotionDateStr = promotionDateStr;
        }

        public void setModifyTimes(Integer modifyTimes) {
            this.modifyTimes = modifyTimes;
        }

        public void setUpdateDate(Integer updateDate) {
            this.updateDate = updateDate;
        }

        public void setUpdateTime(Integer updateTime) {
            this.updateTime = updateTime;
        }

        public void setMoneyType(String moneyType) {
            this.moneyType = moneyType;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetProductInnerOutput:(");
            buffer.append("prodtaNo:" + this.prodtaNo);
            buffer.append(",prodCode:" + this.prodCode);
            buffer.append(",prodName:" + this.prodName);
            buffer.append(",prodcodeType:" + this.prodcodeType);
            buffer.append(",prodcodeSubType:" + this.prodcodeSubType);
            buffer.append(",investKind:" + this.investKind);
            buffer.append(",incomeType:" + this.incomeType);
            buffer.append(",prodriskLevel:" + this.prodriskLevel);
            buffer.append(",maxDeficitRate:" + this.maxDeficitRate);
            buffer.append(",minAssetNeed:" + this.minAssetNeed);
            buffer.append(",eligCtrlstr:" + this.eligCtrlstr);
            buffer.append(",financeType:" + this.financeType);
            buffer.append(",validDays:" + this.validDays);
            buffer.append(",investTerm:" + this.investTerm);
            buffer.append(",enEntrustWay:" + this.enEntrustWay);
            buffer.append(",bankRiskLevel:" + this.bankRiskLevel);
            buffer.append(",investTarget:" + this.investTarget);
            buffer.append(",abroadInvestTerm:" + this.abroadInvestTerm);
            buffer.append(",maxLossType:" + this.maxLossType);
            buffer.append(",complexProdFlag:" + this.complexProdFlag);
            buffer.append(",clientTypeApply:" + this.clientTypeApply);
            buffer.append(",studyId:" + this.studyId);
            buffer.append(",promotionDateStr:" + this.promotionDateStr);
            buffer.append(",modifyTimes:" + this.modifyTimes);
            buffer.append(",updateDate:" + this.updateDate);
            buffer.append(",updateTime:" + this.updateTime);
            buffer.append(",moneyType:" + this.moneyType);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.prodtaNo);
            builder.append(this.prodCode);
            builder.append(this.prodName);
            builder.append(this.prodcodeType);
            builder.append(this.prodcodeSubType);
            builder.append(this.investKind);
            builder.append(this.incomeType);
            builder.append(this.prodriskLevel);
            builder.append(this.maxDeficitRate);
            builder.append(this.minAssetNeed);
            builder.append(this.eligCtrlstr);
            builder.append(this.financeType);
            builder.append(this.validDays);
            builder.append(this.investTerm);
            builder.append(this.enEntrustWay);
            builder.append(this.bankRiskLevel);
            builder.append(this.investTarget);
            builder.append(this.abroadInvestTerm);
            builder.append(this.maxLossType);
            builder.append(this.complexProdFlag);
            builder.append(this.clientTypeApply);
            builder.append(this.studyId);
            builder.append(this.promotionDateStr);
            builder.append(this.modifyTimes);
            builder.append(this.updateDate);
            builder.append(this.updateTime);
            builder.append(this.moneyType);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.GetProductInnerOutput) {
                InnerElgService.GetProductInnerOutput test = (InnerElgService.GetProductInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.prodtaNo, test.prodtaNo);
                builder.append(this.prodCode, test.prodCode);
                builder.append(this.prodName, test.prodName);
                builder.append(this.prodcodeType, test.prodcodeType);
                builder.append(this.prodcodeSubType, test.prodcodeSubType);
                builder.append(this.investKind, test.investKind);
                builder.append(this.incomeType, test.incomeType);
                builder.append(this.prodriskLevel, test.prodriskLevel);
                builder.append(this.maxDeficitRate, test.maxDeficitRate);
                builder.append(this.minAssetNeed, test.minAssetNeed);
                builder.append(this.eligCtrlstr, test.eligCtrlstr);
                builder.append(this.financeType, test.financeType);
                builder.append(this.validDays, test.validDays);
                builder.append(this.investTerm, test.investTerm);
                builder.append(this.enEntrustWay, test.enEntrustWay);
                builder.append(this.bankRiskLevel, test.bankRiskLevel);
                builder.append(this.investTarget, test.investTarget);
                builder.append(this.abroadInvestTerm, test.abroadInvestTerm);
                builder.append(this.maxLossType, test.maxLossType);
                builder.append(this.complexProdFlag, test.complexProdFlag);
                builder.append(this.clientTypeApply, test.clientTypeApply);
                builder.append(this.studyId, test.studyId);
                builder.append(this.promotionDateStr, test.promotionDateStr);
                builder.append(this.modifyTimes, test.modifyTimes);
                builder.append(this.updateDate, test.updateDate);
                builder.append(this.updateTime, test.updateTime);
                builder.append(this.moneyType, test.moneyType);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetProductInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer branchNo = 0;
        @SinogramLength(
                min = 0,
                max = 24,
                charset = "utf-8"
        )
        private String prodtaNo = " ";
        @SinogramLength(
                min = 1,
                max = 32,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String prodCode = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character financeType = ' ';
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String prodrelativeCode = " ";

        public GetProductInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getProdtaNo() {
            if (this.prodtaNo == null) {
                return " ";
            } else {
                return this.prodtaNo.isEmpty() ? " " : this.prodtaNo;
            }
        }

        public String getProdCode() {
            if (this.prodCode == null) {
                return " ";
            } else {
                return this.prodCode.isEmpty() ? " " : this.prodCode;
            }
        }

        public Character getFinanceType() {
            return this.financeType != null ? this.financeType : ' ';
        }

        public String getProdrelativeCode() {
            if (this.prodrelativeCode == null) {
                return " ";
            } else {
                return this.prodrelativeCode.isEmpty() ? " " : this.prodrelativeCode;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setProdtaNo(String prodtaNo) {
            this.prodtaNo = prodtaNo;
        }

        public void setProdCode(String prodCode) {
            this.prodCode = prodCode;
        }

        public void setFinanceType(Character financeType) {
            this.financeType = financeType;
        }

        public void setProdrelativeCode(String prodrelativeCode) {
            this.prodrelativeCode = prodrelativeCode;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetProductInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",prodtaNo:" + this.prodtaNo);
            buffer.append(",prodCode:" + this.prodCode);
            buffer.append(",financeType:" + this.financeType);
            buffer.append(",prodrelativeCode:" + this.prodrelativeCode);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.branchNo);
            builder.append(this.prodtaNo);
            builder.append(this.prodCode);
            builder.append(this.financeType);
            builder.append(this.prodrelativeCode);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.GetProductInnerInput) {
                InnerElgService.GetProductInnerInput test = (InnerElgService.GetProductInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.prodtaNo, test.prodtaNo);
                builder.append(this.prodCode, test.prodCode);
                builder.append(this.financeType, test.financeType);
                builder.append(this.prodrelativeCode, test.prodrelativeCode);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetOptClientInfoListInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private List<InnerElgService.OptclientinfoDTO> rows;

        public GetOptClientInfoListInnerOutput() {
        }

        public List<InnerElgService.OptclientinfoDTO> getRows() {
            return this.rows;
        }

        public void setRows(List<InnerElgService.OptclientinfoDTO> rows) {
            this.rows = rows;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetOptClientInfoListInnerOutput:(");
            buffer.append("rows:" + this.rows);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.rows);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.GetOptClientInfoListInnerOutput) {
                InnerElgService.GetOptClientInfoListInnerOutput test = (InnerElgService.GetOptClientInfoListInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.rows, test.rows);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetOptClientInfoListInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer branchNo = 0;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId = " ";
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String exchangeType = " ";

        public GetOptClientInfoListInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getExchangeType() {
            if (this.exchangeType == null) {
                return " ";
            } else {
                return this.exchangeType.isEmpty() ? " " : this.exchangeType;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetOptClientInfoListInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.branchNo);
            builder.append(this.clientId);
            builder.append(this.exchangeType);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.GetOptClientInfoListInnerInput) {
                InnerElgService.GetOptClientInfoListInnerInput test = (InnerElgService.GetOptClientInfoListInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.clientId, test.clientId);
                builder.append(this.exchangeType, test.exchangeType);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetOptAcctLimitListInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private List<InnerElgService.OptacctlimitDTO> rows;

        public GetOptAcctLimitListInnerOutput() {
        }

        public List<InnerElgService.OptacctlimitDTO> getRows() {
            return this.rows;
        }

        public void setRows(List<InnerElgService.OptacctlimitDTO> rows) {
            this.rows = rows;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetOptAcctLimitListInnerOutput:(");
            buffer.append("rows:" + this.rows);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.rows);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.GetOptAcctLimitListInnerOutput) {
                InnerElgService.GetOptAcctLimitListInnerOutput test = (InnerElgService.GetOptAcctLimitListInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.rows, test.rows);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetOptAcctLimitListInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer branchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String clientId = " ";
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String exchangeType = " ";

        public GetOptAcctLimitListInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getExchangeType() {
            if (this.exchangeType == null) {
                return " ";
            } else {
                return this.exchangeType.isEmpty() ? " " : this.exchangeType;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetOptAcctLimitListInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.branchNo);
            builder.append(this.clientId);
            builder.append(this.exchangeType);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.GetOptAcctLimitListInnerInput) {
                InnerElgService.GetOptAcctLimitListInnerInput test = (InnerElgService.GetOptAcctLimitListInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.clientId, test.clientId);
                builder.append(this.exchangeType, test.exchangeType);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetElgTestJourAndPaperInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private List<InnerElgService.TestjourDTO> testjours = new ArrayList();
        private InnerElgService.PaperDTO paper;

        public GetElgTestJourAndPaperInnerOutput() {
        }

        public List<InnerElgService.TestjourDTO> getTestjours() {
            return (List)(this.testjours != null ? this.testjours : new ArrayList());
        }

        public InnerElgService.PaperDTO getPaper() {
            return this.paper;
        }

        public void setTestjours(List<InnerElgService.TestjourDTO> testjours) {
            this.testjours = testjours;
        }

        public void setPaper(InnerElgService.PaperDTO paper) {
            this.paper = paper;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetElgTestJourAndPaperInnerOutput:(");
            buffer.append("testjours:" + this.testjours);
            buffer.append(",paper:" + this.paper);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.testjours);
            builder.append(this.paper);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.GetElgTestJourAndPaperInnerOutput) {
                InnerElgService.GetElgTestJourAndPaperInnerOutput test = (InnerElgService.GetElgTestJourAndPaperInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.testjours, test.testjours);
                builder.append(this.paper, test.paper);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetElgTestJourAndPaperInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer branchNo = 0;
        @SinogramLength(
                min = 1,
                max = 2,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String paperType = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String clientId = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character organFlag = ' ';
        @SinogramLength(
                min = 0,
                max = 24,
                charset = "utf-8"
        )
        private String prodtaNo = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character enableFlag = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character useFlag = ' ';
        @SinogramLength(
                min = 0,
                max = 180,
                charset = "utf-8"
        )
        private String fullName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character idKind = ' ';
        @SinogramLength(
                min = 0,
                max = 40,
                charset = "utf-8"
        )
        private String idNo = " ";
        @SinogramLength(
                min = 0,
                max = 100,
                charset = "utf-8"
        )
        private String positionStr = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String prodCode = " ";

        public GetElgTestJourAndPaperInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getPaperType() {
            if (this.paperType == null) {
                return " ";
            } else {
                return this.paperType.isEmpty() ? " " : this.paperType;
            }
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public Character getOrganFlag() {
            return this.organFlag != null ? this.organFlag : ' ';
        }

        public String getProdtaNo() {
            if (this.prodtaNo == null) {
                return " ";
            } else {
                return this.prodtaNo.isEmpty() ? " " : this.prodtaNo;
            }
        }

        public Character getEnableFlag() {
            return this.enableFlag != null ? this.enableFlag : ' ';
        }

        public Character getUseFlag() {
            return this.useFlag != null ? this.useFlag : ' ';
        }

        public String getFullName() {
            if (this.fullName == null) {
                return " ";
            } else {
                return this.fullName.isEmpty() ? " " : this.fullName;
            }
        }

        public Character getIdKind() {
            return this.idKind != null ? this.idKind : ' ';
        }

        public String getIdNo() {
            if (this.idNo == null) {
                return " ";
            } else {
                return this.idNo.isEmpty() ? " " : this.idNo;
            }
        }

        public String getPositionStr() {
            if (this.positionStr == null) {
                return " ";
            } else {
                return this.positionStr.isEmpty() ? " " : this.positionStr;
            }
        }

        public String getProdCode() {
            if (this.prodCode == null) {
                return " ";
            } else {
                return this.prodCode.isEmpty() ? " " : this.prodCode;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setPaperType(String paperType) {
            this.paperType = paperType;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setOrganFlag(Character organFlag) {
            this.organFlag = organFlag;
        }

        public void setProdtaNo(String prodtaNo) {
            this.prodtaNo = prodtaNo;
        }

        public void setEnableFlag(Character enableFlag) {
            this.enableFlag = enableFlag;
        }

        public void setUseFlag(Character useFlag) {
            this.useFlag = useFlag;
        }

        public void setFullName(String fullName) {
            this.fullName = fullName;
        }

        public void setIdKind(Character idKind) {
            this.idKind = idKind;
        }

        public void setIdNo(String idNo) {
            this.idNo = idNo;
        }

        public void setPositionStr(String positionStr) {
            this.positionStr = positionStr;
        }

        public void setProdCode(String prodCode) {
            this.prodCode = prodCode;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetElgTestJourAndPaperInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",paperType:" + this.paperType);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",organFlag:" + this.organFlag);
            buffer.append(",prodtaNo:" + this.prodtaNo);
            buffer.append(",enableFlag:" + this.enableFlag);
            buffer.append(",useFlag:" + this.useFlag);
            buffer.append(",fullName:" + this.fullName);
            buffer.append(",idKind:" + this.idKind);
            buffer.append(",idNo:" + this.idNo);
            buffer.append(",positionStr:" + this.positionStr);
            buffer.append(",prodCode:" + this.prodCode);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.branchNo);
            builder.append(this.paperType);
            builder.append(this.clientId);
            builder.append(this.organFlag);
            builder.append(this.prodtaNo);
            builder.append(this.enableFlag);
            builder.append(this.useFlag);
            builder.append(this.fullName);
            builder.append(this.idKind);
            builder.append(this.idNo);
            builder.append(this.positionStr);
            builder.append(this.prodCode);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.GetElgTestJourAndPaperInnerInput) {
                InnerElgService.GetElgTestJourAndPaperInnerInput test = (InnerElgService.GetElgTestJourAndPaperInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.paperType, test.paperType);
                builder.append(this.clientId, test.clientId);
                builder.append(this.organFlag, test.organFlag);
                builder.append(this.prodtaNo, test.prodtaNo);
                builder.append(this.enableFlag, test.enableFlag);
                builder.append(this.useFlag, test.useFlag);
                builder.append(this.fullName, test.fullName);
                builder.append(this.idKind, test.idKind);
                builder.append(this.idNo, test.idNo);
                builder.append(this.positionStr, test.positionStr);
                builder.append(this.prodCode, test.prodCode);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetCusQualiResultInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String traceNo = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character clientBusiMatchFlag = ' ';
        private Integer corpRiskLevel = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character eligRiskFlag = ' ';
        private String businRiskLevel = " ";
        private String enInvestKind = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character eligInvestkindFlag = ' ';
        private String busiInvestKind = " ";
        private String enInvestTerm = " ";
        private String busiInvestTerm = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character eligTermFlag = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character clientIncomeType = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character incomeType = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character eligIncomeFlag = ' ';
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double assetBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double minAssetNeed = 0.0D;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character minRankFlag = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character needAdaptiveFlag = ' ';
        private Integer corpBeginDate = 0;
        private Integer corpEndDate = 0;
        private Integer initDate = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character weakRiskFlag = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character preferRiskMatchFlag = ' ';
        private String acptId = " ";

        public GetCusQualiResultInnerOutput() {
        }

        public String getTraceNo() {
            if (this.traceNo == null) {
                return " ";
            } else {
                return this.traceNo.isEmpty() ? " " : this.traceNo;
            }
        }

        public Character getClientBusiMatchFlag() {
            return this.clientBusiMatchFlag != null ? this.clientBusiMatchFlag : ' ';
        }

        public Integer getCorpRiskLevel() {
            return this.corpRiskLevel != null ? this.corpRiskLevel : 0;
        }

        public Character getEligRiskFlag() {
            return this.eligRiskFlag != null ? this.eligRiskFlag : ' ';
        }

        public String getBusinRiskLevel() {
            if (this.businRiskLevel == null) {
                return " ";
            } else {
                return this.businRiskLevel.isEmpty() ? " " : this.businRiskLevel;
            }
        }

        public String getEnInvestKind() {
            if (this.enInvestKind == null) {
                return " ";
            } else {
                return this.enInvestKind.isEmpty() ? " " : this.enInvestKind;
            }
        }

        public Character getEligInvestkindFlag() {
            return this.eligInvestkindFlag != null ? this.eligInvestkindFlag : ' ';
        }

        public String getBusiInvestKind() {
            if (this.busiInvestKind == null) {
                return " ";
            } else {
                return this.busiInvestKind.isEmpty() ? " " : this.busiInvestKind;
            }
        }

        public String getEnInvestTerm() {
            if (this.enInvestTerm == null) {
                return " ";
            } else {
                return this.enInvestTerm.isEmpty() ? " " : this.enInvestTerm;
            }
        }

        public String getBusiInvestTerm() {
            if (this.busiInvestTerm == null) {
                return " ";
            } else {
                return this.busiInvestTerm.isEmpty() ? " " : this.busiInvestTerm;
            }
        }

        public Character getEligTermFlag() {
            return this.eligTermFlag != null ? this.eligTermFlag : ' ';
        }

        public Character getClientIncomeType() {
            return this.clientIncomeType != null ? this.clientIncomeType : ' ';
        }

        public Character getIncomeType() {
            return this.incomeType != null ? this.incomeType : ' ';
        }

        public Character getEligIncomeFlag() {
            return this.eligIncomeFlag != null ? this.eligIncomeFlag : ' ';
        }

        public Double getAssetBalance() {
            return this.assetBalance != null ? this.assetBalance : 0.0D;
        }

        public Double getMinAssetNeed() {
            return this.minAssetNeed != null ? this.minAssetNeed : 0.0D;
        }

        public Character getMinRankFlag() {
            return this.minRankFlag != null ? this.minRankFlag : ' ';
        }

        public Character getNeedAdaptiveFlag() {
            return this.needAdaptiveFlag != null ? this.needAdaptiveFlag : ' ';
        }

        public Integer getCorpBeginDate() {
            return this.corpBeginDate != null ? this.corpBeginDate : 0;
        }

        public Integer getCorpEndDate() {
            return this.corpEndDate != null ? this.corpEndDate : 0;
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public Character getWeakRiskFlag() {
            return this.weakRiskFlag != null ? this.weakRiskFlag : ' ';
        }

        public Character getPreferRiskMatchFlag() {
            return this.preferRiskMatchFlag != null ? this.preferRiskMatchFlag : ' ';
        }

        public String getAcptId() {
            if (this.acptId == null) {
                return " ";
            } else {
                return this.acptId.isEmpty() ? " " : this.acptId;
            }
        }

        public void setTraceNo(String traceNo) {
            this.traceNo = traceNo;
        }

        public void setClientBusiMatchFlag(Character clientBusiMatchFlag) {
            this.clientBusiMatchFlag = clientBusiMatchFlag;
        }

        public void setCorpRiskLevel(Integer corpRiskLevel) {
            this.corpRiskLevel = corpRiskLevel;
        }

        public void setEligRiskFlag(Character eligRiskFlag) {
            this.eligRiskFlag = eligRiskFlag;
        }

        public void setBusinRiskLevel(String businRiskLevel) {
            this.businRiskLevel = businRiskLevel;
        }

        public void setEnInvestKind(String enInvestKind) {
            this.enInvestKind = enInvestKind;
        }

        public void setEligInvestkindFlag(Character eligInvestkindFlag) {
            this.eligInvestkindFlag = eligInvestkindFlag;
        }

        public void setBusiInvestKind(String busiInvestKind) {
            this.busiInvestKind = busiInvestKind;
        }

        public void setEnInvestTerm(String enInvestTerm) {
            this.enInvestTerm = enInvestTerm;
        }

        public void setBusiInvestTerm(String busiInvestTerm) {
            this.busiInvestTerm = busiInvestTerm;
        }

        public void setEligTermFlag(Character eligTermFlag) {
            this.eligTermFlag = eligTermFlag;
        }

        public void setClientIncomeType(Character clientIncomeType) {
            this.clientIncomeType = clientIncomeType;
        }

        public void setIncomeType(Character incomeType) {
            this.incomeType = incomeType;
        }

        public void setEligIncomeFlag(Character eligIncomeFlag) {
            this.eligIncomeFlag = eligIncomeFlag;
        }

        public void setAssetBalance(Double assetBalance) {
            this.assetBalance = assetBalance;
        }

        public void setMinAssetNeed(Double minAssetNeed) {
            this.minAssetNeed = minAssetNeed;
        }

        public void setMinRankFlag(Character minRankFlag) {
            this.minRankFlag = minRankFlag;
        }

        public void setNeedAdaptiveFlag(Character needAdaptiveFlag) {
            this.needAdaptiveFlag = needAdaptiveFlag;
        }

        public void setCorpBeginDate(Integer corpBeginDate) {
            this.corpBeginDate = corpBeginDate;
        }

        public void setCorpEndDate(Integer corpEndDate) {
            this.corpEndDate = corpEndDate;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public void setWeakRiskFlag(Character weakRiskFlag) {
            this.weakRiskFlag = weakRiskFlag;
        }

        public void setPreferRiskMatchFlag(Character preferRiskMatchFlag) {
            this.preferRiskMatchFlag = preferRiskMatchFlag;
        }

        public void setAcptId(String acptId) {
            this.acptId = acptId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetCusQualiResultInnerOutput:(");
            buffer.append("traceNo:" + this.traceNo);
            buffer.append(",clientBusiMatchFlag:" + this.clientBusiMatchFlag);
            buffer.append(",corpRiskLevel:" + this.corpRiskLevel);
            buffer.append(",eligRiskFlag:" + this.eligRiskFlag);
            buffer.append(",businRiskLevel:" + this.businRiskLevel);
            buffer.append(",enInvestKind:" + this.enInvestKind);
            buffer.append(",eligInvestkindFlag:" + this.eligInvestkindFlag);
            buffer.append(",busiInvestKind:" + this.busiInvestKind);
            buffer.append(",enInvestTerm:" + this.enInvestTerm);
            buffer.append(",busiInvestTerm:" + this.busiInvestTerm);
            buffer.append(",eligTermFlag:" + this.eligTermFlag);
            buffer.append(",clientIncomeType:" + this.clientIncomeType);
            buffer.append(",incomeType:" + this.incomeType);
            buffer.append(",eligIncomeFlag:" + this.eligIncomeFlag);
            buffer.append(",assetBalance:" + this.assetBalance);
            buffer.append(",minAssetNeed:" + this.minAssetNeed);
            buffer.append(",minRankFlag:" + this.minRankFlag);
            buffer.append(",needAdaptiveFlag:" + this.needAdaptiveFlag);
            buffer.append(",corpBeginDate:" + this.corpBeginDate);
            buffer.append(",corpEndDate:" + this.corpEndDate);
            buffer.append(",initDate:" + this.initDate);
            buffer.append(",weakRiskFlag:" + this.weakRiskFlag);
            buffer.append(",preferRiskMatchFlag:" + this.preferRiskMatchFlag);
            buffer.append(",acptId:" + this.acptId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.traceNo);
            builder.append(this.clientBusiMatchFlag);
            builder.append(this.corpRiskLevel);
            builder.append(this.eligRiskFlag);
            builder.append(this.businRiskLevel);
            builder.append(this.enInvestKind);
            builder.append(this.eligInvestkindFlag);
            builder.append(this.busiInvestKind);
            builder.append(this.enInvestTerm);
            builder.append(this.busiInvestTerm);
            builder.append(this.eligTermFlag);
            builder.append(this.clientIncomeType);
            builder.append(this.incomeType);
            builder.append(this.eligIncomeFlag);
            builder.append(this.assetBalance);
            builder.append(this.minAssetNeed);
            builder.append(this.minRankFlag);
            builder.append(this.needAdaptiveFlag);
            builder.append(this.corpBeginDate);
            builder.append(this.corpEndDate);
            builder.append(this.initDate);
            builder.append(this.weakRiskFlag);
            builder.append(this.preferRiskMatchFlag);
            builder.append(this.acptId);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.GetCusQualiResultInnerOutput) {
                InnerElgService.GetCusQualiResultInnerOutput test = (InnerElgService.GetCusQualiResultInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.traceNo, test.traceNo);
                builder.append(this.clientBusiMatchFlag, test.clientBusiMatchFlag);
                builder.append(this.corpRiskLevel, test.corpRiskLevel);
                builder.append(this.eligRiskFlag, test.eligRiskFlag);
                builder.append(this.businRiskLevel, test.businRiskLevel);
                builder.append(this.enInvestKind, test.enInvestKind);
                builder.append(this.eligInvestkindFlag, test.eligInvestkindFlag);
                builder.append(this.busiInvestKind, test.busiInvestKind);
                builder.append(this.enInvestTerm, test.enInvestTerm);
                builder.append(this.busiInvestTerm, test.busiInvestTerm);
                builder.append(this.eligTermFlag, test.eligTermFlag);
                builder.append(this.clientIncomeType, test.clientIncomeType);
                builder.append(this.incomeType, test.incomeType);
                builder.append(this.eligIncomeFlag, test.eligIncomeFlag);
                builder.append(this.assetBalance, test.assetBalance);
                builder.append(this.minAssetNeed, test.minAssetNeed);
                builder.append(this.minRankFlag, test.minRankFlag);
                builder.append(this.needAdaptiveFlag, test.needAdaptiveFlag);
                builder.append(this.corpBeginDate, test.corpBeginDate);
                builder.append(this.corpEndDate, test.corpEndDate);
                builder.append(this.initDate, test.initDate);
                builder.append(this.weakRiskFlag, test.weakRiskFlag);
                builder.append(this.preferRiskMatchFlag, test.preferRiskMatchFlag);
                builder.append(this.acptId, test.acptId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetCusQualiResultInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer branchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String clientId = " ";
        @SinogramLength(
                min = 1,
                max = 10,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String acptBusinId = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String paramType = " ";
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String acptBusinKind = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fundAccount = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String enParamId = " ";
        @SinogramLength(
                min = 0,
                max = 20,
                charset = "utf-8"
        )
        private String stockAccount = " ";

        public GetCusQualiResultInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getAcptBusinId() {
            if (this.acptBusinId == null) {
                return " ";
            } else {
                return this.acptBusinId.isEmpty() ? " " : this.acptBusinId;
            }
        }

        public String getParamType() {
            if (this.paramType == null) {
                return " ";
            } else {
                return this.paramType.isEmpty() ? " " : this.paramType;
            }
        }

        public String getAcptBusinKind() {
            if (this.acptBusinKind == null) {
                return " ";
            } else {
                return this.acptBusinKind.isEmpty() ? " " : this.acptBusinKind;
            }
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getEnParamId() {
            if (this.enParamId == null) {
                return " ";
            } else {
                return this.enParamId.isEmpty() ? " " : this.enParamId;
            }
        }

        public String getStockAccount() {
            if (this.stockAccount == null) {
                return " ";
            } else {
                return this.stockAccount.isEmpty() ? " " : this.stockAccount;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setAcptBusinId(String acptBusinId) {
            this.acptBusinId = acptBusinId;
        }

        public void setParamType(String paramType) {
            this.paramType = paramType;
        }

        public void setAcptBusinKind(String acptBusinKind) {
            this.acptBusinKind = acptBusinKind;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setEnParamId(String enParamId) {
            this.enParamId = enParamId;
        }

        public void setStockAccount(String stockAccount) {
            this.stockAccount = stockAccount;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetCusQualiResultInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",acptBusinId:" + this.acptBusinId);
            buffer.append(",paramType:" + this.paramType);
            buffer.append(",acptBusinKind:" + this.acptBusinKind);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",enParamId:" + this.enParamId);
            buffer.append(",stockAccount:" + this.stockAccount);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.branchNo);
            builder.append(this.clientId);
            builder.append(this.acptBusinId);
            builder.append(this.paramType);
            builder.append(this.acptBusinKind);
            builder.append(this.fundAccount);
            builder.append(this.enParamId);
            builder.append(this.stockAccount);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.GetCusQualiResultInnerInput) {
                InnerElgService.GetCusQualiResultInnerInput test = (InnerElgService.GetCusQualiResultInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.clientId, test.clientId);
                builder.append(this.acptBusinId, test.acptBusinId);
                builder.append(this.paramType, test.paramType);
                builder.append(this.acptBusinKind, test.acptBusinKind);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.enParamId, test.enParamId);
                builder.append(this.stockAccount, test.stockAccount);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetClientpreferByIdInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String clientId = " ";
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double assetBalance = 0.0D;
        private String enInvestKind = " ";
        private String enInvestTerm = " ";
        private Integer profBeginDate = 0;
        private Integer profEndDate = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character profType = ' ';
        private Integer pfRiskLevel = 0;
        private Integer pfRiskBeginDate = 0;
        private Integer pfRiskEndDate = 0;
        private String enPfInvestKind = " ";
        private String enPfInvestTerm = " ";
        private Integer corpRiskLevel = 0;
        private Integer corpBeginDate = 0;
        private Integer corpEndDate = 0;
        @SerializeDoubleDigit(
                digit = 8
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double enMaxdeficitRate = 0.0D;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character organFlag = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character minRankFlag = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character clientIncomeType = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character idKind = ' ';
        private String idNo = " ";
        private String fullName = " ";
        private String remark = " ";
        private String custId = " ";
        private Integer corpModiTime = 0;

        public GetClientpreferByIdInnerOutput() {
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public Double getAssetBalance() {
            return this.assetBalance != null ? this.assetBalance : 0.0D;
        }

        public String getEnInvestKind() {
            if (this.enInvestKind == null) {
                return " ";
            } else {
                return this.enInvestKind.isEmpty() ? " " : this.enInvestKind;
            }
        }

        public String getEnInvestTerm() {
            if (this.enInvestTerm == null) {
                return " ";
            } else {
                return this.enInvestTerm.isEmpty() ? " " : this.enInvestTerm;
            }
        }

        public Integer getProfBeginDate() {
            return this.profBeginDate != null ? this.profBeginDate : 0;
        }

        public Integer getProfEndDate() {
            return this.profEndDate != null ? this.profEndDate : 0;
        }

        public Character getProfType() {
            return this.profType != null ? this.profType : ' ';
        }

        public Integer getPfRiskLevel() {
            return this.pfRiskLevel != null ? this.pfRiskLevel : 0;
        }

        public Integer getPfRiskBeginDate() {
            return this.pfRiskBeginDate != null ? this.pfRiskBeginDate : 0;
        }

        public Integer getPfRiskEndDate() {
            return this.pfRiskEndDate != null ? this.pfRiskEndDate : 0;
        }

        public String getEnPfInvestKind() {
            if (this.enPfInvestKind == null) {
                return " ";
            } else {
                return this.enPfInvestKind.isEmpty() ? " " : this.enPfInvestKind;
            }
        }

        public String getEnPfInvestTerm() {
            if (this.enPfInvestTerm == null) {
                return " ";
            } else {
                return this.enPfInvestTerm.isEmpty() ? " " : this.enPfInvestTerm;
            }
        }

        public Integer getCorpRiskLevel() {
            return this.corpRiskLevel != null ? this.corpRiskLevel : 0;
        }

        public Integer getCorpBeginDate() {
            return this.corpBeginDate != null ? this.corpBeginDate : 0;
        }

        public Integer getCorpEndDate() {
            return this.corpEndDate != null ? this.corpEndDate : 0;
        }

        public Double getEnMaxdeficitRate() {
            return this.enMaxdeficitRate != null ? this.enMaxdeficitRate : 0.0D;
        }

        public Character getOrganFlag() {
            return this.organFlag != null ? this.organFlag : ' ';
        }

        public Character getMinRankFlag() {
            return this.minRankFlag != null ? this.minRankFlag : ' ';
        }

        public Character getClientIncomeType() {
            return this.clientIncomeType != null ? this.clientIncomeType : ' ';
        }

        public Character getIdKind() {
            return this.idKind != null ? this.idKind : ' ';
        }

        public String getIdNo() {
            if (this.idNo == null) {
                return " ";
            } else {
                return this.idNo.isEmpty() ? " " : this.idNo;
            }
        }

        public String getFullName() {
            if (this.fullName == null) {
                return " ";
            } else {
                return this.fullName.isEmpty() ? " " : this.fullName;
            }
        }

        public String getRemark() {
            if (this.remark == null) {
                return " ";
            } else {
                return this.remark.isEmpty() ? " " : this.remark;
            }
        }

        public String getCustId() {
            if (this.custId == null) {
                return " ";
            } else {
                return this.custId.isEmpty() ? " " : this.custId;
            }
        }

        public Integer getCorpModiTime() {
            return this.corpModiTime != null ? this.corpModiTime : 0;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setAssetBalance(Double assetBalance) {
            this.assetBalance = assetBalance;
        }

        public void setEnInvestKind(String enInvestKind) {
            this.enInvestKind = enInvestKind;
        }

        public void setEnInvestTerm(String enInvestTerm) {
            this.enInvestTerm = enInvestTerm;
        }

        public void setProfBeginDate(Integer profBeginDate) {
            this.profBeginDate = profBeginDate;
        }

        public void setProfEndDate(Integer profEndDate) {
            this.profEndDate = profEndDate;
        }

        public void setProfType(Character profType) {
            this.profType = profType;
        }

        public void setPfRiskLevel(Integer pfRiskLevel) {
            this.pfRiskLevel = pfRiskLevel;
        }

        public void setPfRiskBeginDate(Integer pfRiskBeginDate) {
            this.pfRiskBeginDate = pfRiskBeginDate;
        }

        public void setPfRiskEndDate(Integer pfRiskEndDate) {
            this.pfRiskEndDate = pfRiskEndDate;
        }

        public void setEnPfInvestKind(String enPfInvestKind) {
            this.enPfInvestKind = enPfInvestKind;
        }

        public void setEnPfInvestTerm(String enPfInvestTerm) {
            this.enPfInvestTerm = enPfInvestTerm;
        }

        public void setCorpRiskLevel(Integer corpRiskLevel) {
            this.corpRiskLevel = corpRiskLevel;
        }

        public void setCorpBeginDate(Integer corpBeginDate) {
            this.corpBeginDate = corpBeginDate;
        }

        public void setCorpEndDate(Integer corpEndDate) {
            this.corpEndDate = corpEndDate;
        }

        public void setEnMaxdeficitRate(Double enMaxdeficitRate) {
            this.enMaxdeficitRate = enMaxdeficitRate;
        }

        public void setOrganFlag(Character organFlag) {
            this.organFlag = organFlag;
        }

        public void setMinRankFlag(Character minRankFlag) {
            this.minRankFlag = minRankFlag;
        }

        public void setClientIncomeType(Character clientIncomeType) {
            this.clientIncomeType = clientIncomeType;
        }

        public void setIdKind(Character idKind) {
            this.idKind = idKind;
        }

        public void setIdNo(String idNo) {
            this.idNo = idNo;
        }

        public void setFullName(String fullName) {
            this.fullName = fullName;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public void setCustId(String custId) {
            this.custId = custId;
        }

        public void setCorpModiTime(Integer corpModiTime) {
            this.corpModiTime = corpModiTime;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetClientpreferByIdInnerOutput:(");
            buffer.append("clientId:" + this.clientId);
            buffer.append(",assetBalance:" + this.assetBalance);
            buffer.append(",enInvestKind:" + this.enInvestKind);
            buffer.append(",enInvestTerm:" + this.enInvestTerm);
            buffer.append(",profBeginDate:" + this.profBeginDate);
            buffer.append(",profEndDate:" + this.profEndDate);
            buffer.append(",profType:" + this.profType);
            buffer.append(",pfRiskLevel:" + this.pfRiskLevel);
            buffer.append(",pfRiskBeginDate:" + this.pfRiskBeginDate);
            buffer.append(",pfRiskEndDate:" + this.pfRiskEndDate);
            buffer.append(",enPfInvestKind:" + this.enPfInvestKind);
            buffer.append(",enPfInvestTerm:" + this.enPfInvestTerm);
            buffer.append(",corpRiskLevel:" + this.corpRiskLevel);
            buffer.append(",corpBeginDate:" + this.corpBeginDate);
            buffer.append(",corpEndDate:" + this.corpEndDate);
            buffer.append(",enMaxdeficitRate:" + this.enMaxdeficitRate);
            buffer.append(",organFlag:" + this.organFlag);
            buffer.append(",minRankFlag:" + this.minRankFlag);
            buffer.append(",clientIncomeType:" + this.clientIncomeType);
            buffer.append(",idKind:" + this.idKind);
            buffer.append(",idNo:" + this.idNo);
            buffer.append(",fullName:" + this.fullName);
            buffer.append(",remark:" + this.remark);
            buffer.append(",custId:" + this.custId);
            buffer.append(",corpModiTime:" + this.corpModiTime);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.clientId);
            builder.append(this.assetBalance);
            builder.append(this.enInvestKind);
            builder.append(this.enInvestTerm);
            builder.append(this.profBeginDate);
            builder.append(this.profEndDate);
            builder.append(this.profType);
            builder.append(this.pfRiskLevel);
            builder.append(this.pfRiskBeginDate);
            builder.append(this.pfRiskEndDate);
            builder.append(this.enPfInvestKind);
            builder.append(this.enPfInvestTerm);
            builder.append(this.corpRiskLevel);
            builder.append(this.corpBeginDate);
            builder.append(this.corpEndDate);
            builder.append(this.enMaxdeficitRate);
            builder.append(this.organFlag);
            builder.append(this.minRankFlag);
            builder.append(this.clientIncomeType);
            builder.append(this.idKind);
            builder.append(this.idNo);
            builder.append(this.fullName);
            builder.append(this.remark);
            builder.append(this.custId);
            builder.append(this.corpModiTime);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.GetClientpreferByIdInnerOutput) {
                InnerElgService.GetClientpreferByIdInnerOutput test = (InnerElgService.GetClientpreferByIdInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.clientId, test.clientId);
                builder.append(this.assetBalance, test.assetBalance);
                builder.append(this.enInvestKind, test.enInvestKind);
                builder.append(this.enInvestTerm, test.enInvestTerm);
                builder.append(this.profBeginDate, test.profBeginDate);
                builder.append(this.profEndDate, test.profEndDate);
                builder.append(this.profType, test.profType);
                builder.append(this.pfRiskLevel, test.pfRiskLevel);
                builder.append(this.pfRiskBeginDate, test.pfRiskBeginDate);
                builder.append(this.pfRiskEndDate, test.pfRiskEndDate);
                builder.append(this.enPfInvestKind, test.enPfInvestKind);
                builder.append(this.enPfInvestTerm, test.enPfInvestTerm);
                builder.append(this.corpRiskLevel, test.corpRiskLevel);
                builder.append(this.corpBeginDate, test.corpBeginDate);
                builder.append(this.corpEndDate, test.corpEndDate);
                builder.append(this.enMaxdeficitRate, test.enMaxdeficitRate);
                builder.append(this.organFlag, test.organFlag);
                builder.append(this.minRankFlag, test.minRankFlag);
                builder.append(this.clientIncomeType, test.clientIncomeType);
                builder.append(this.idKind, test.idKind);
                builder.append(this.idNo, test.idNo);
                builder.append(this.fullName, test.fullName);
                builder.append(this.remark, test.remark);
                builder.append(this.custId, test.custId);
                builder.append(this.corpModiTime, test.corpModiTime);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetClientpreferByIdInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer branchNo = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character idKind = ' ';
        @SinogramLength(
                min = 0,
                max = 40,
                charset = "utf-8"
        )
        private String idNo = " ";
        @SinogramLength(
                min = 0,
                max = 180,
                charset = "utf-8"
        )
        private String fullName = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String clientId = " ";
        @SinogramLength(
                min = 0,
                max = 90,
                charset = "utf-8"
        )
        private String clientName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character actionFlag = ' ';

        public GetClientpreferByIdInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Character getIdKind() {
            return this.idKind != null ? this.idKind : ' ';
        }

        public String getIdNo() {
            if (this.idNo == null) {
                return " ";
            } else {
                return this.idNo.isEmpty() ? " " : this.idNo;
            }
        }

        public String getFullName() {
            if (this.fullName == null) {
                return " ";
            } else {
                return this.fullName.isEmpty() ? " " : this.fullName;
            }
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getClientName() {
            if (this.clientName == null) {
                return " ";
            } else {
                return this.clientName.isEmpty() ? " " : this.clientName;
            }
        }

        public Character getActionFlag() {
            return this.actionFlag != null ? this.actionFlag : ' ';
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setIdKind(Character idKind) {
            this.idKind = idKind;
        }

        public void setIdNo(String idNo) {
            this.idNo = idNo;
        }

        public void setFullName(String fullName) {
            this.fullName = fullName;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setClientName(String clientName) {
            this.clientName = clientName;
        }

        public void setActionFlag(Character actionFlag) {
            this.actionFlag = actionFlag;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetClientpreferByIdInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",idKind:" + this.idKind);
            buffer.append(",idNo:" + this.idNo);
            buffer.append(",fullName:" + this.fullName);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",clientName:" + this.clientName);
            buffer.append(",actionFlag:" + this.actionFlag);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.branchNo);
            builder.append(this.idKind);
            builder.append(this.idNo);
            builder.append(this.fullName);
            builder.append(this.clientId);
            builder.append(this.clientName);
            builder.append(this.actionFlag);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.GetClientpreferByIdInnerInput) {
                InnerElgService.GetClientpreferByIdInnerInput test = (InnerElgService.GetClientpreferByIdInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.idKind, test.idKind);
                builder.append(this.idNo, test.idNo);
                builder.append(this.fullName, test.fullName);
                builder.append(this.clientId, test.clientId);
                builder.append(this.clientName, test.clientName);
                builder.append(this.actionFlag, test.actionFlag);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetBusinQualiargInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String businRiskLevel = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character investKind = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character investTerm = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character incomeType = ' ';
        private String enInvestKind = " ";
        private String enInvestTerm = " ";
        private String enCorpRiskLevel = " ";
        private String enClientIncomeType = " ";
        private String weakCorpRiskLevel = " ";

        public GetBusinQualiargInnerOutput() {
        }

        public String getBusinRiskLevel() {
            if (this.businRiskLevel == null) {
                return " ";
            } else {
                return this.businRiskLevel.isEmpty() ? " " : this.businRiskLevel;
            }
        }

        public Character getInvestKind() {
            return this.investKind != null ? this.investKind : ' ';
        }

        public Character getInvestTerm() {
            return this.investTerm != null ? this.investTerm : ' ';
        }

        public Character getIncomeType() {
            return this.incomeType != null ? this.incomeType : ' ';
        }

        public String getEnInvestKind() {
            if (this.enInvestKind == null) {
                return " ";
            } else {
                return this.enInvestKind.isEmpty() ? " " : this.enInvestKind;
            }
        }

        public String getEnInvestTerm() {
            if (this.enInvestTerm == null) {
                return " ";
            } else {
                return this.enInvestTerm.isEmpty() ? " " : this.enInvestTerm;
            }
        }

        public String getEnCorpRiskLevel() {
            if (this.enCorpRiskLevel == null) {
                return " ";
            } else {
                return this.enCorpRiskLevel.isEmpty() ? " " : this.enCorpRiskLevel;
            }
        }

        public String getEnClientIncomeType() {
            if (this.enClientIncomeType == null) {
                return " ";
            } else {
                return this.enClientIncomeType.isEmpty() ? " " : this.enClientIncomeType;
            }
        }

        public String getWeakCorpRiskLevel() {
            if (this.weakCorpRiskLevel == null) {
                return " ";
            } else {
                return this.weakCorpRiskLevel.isEmpty() ? " " : this.weakCorpRiskLevel;
            }
        }

        public void setBusinRiskLevel(String businRiskLevel) {
            this.businRiskLevel = businRiskLevel;
        }

        public void setInvestKind(Character investKind) {
            this.investKind = investKind;
        }

        public void setInvestTerm(Character investTerm) {
            this.investTerm = investTerm;
        }

        public void setIncomeType(Character incomeType) {
            this.incomeType = incomeType;
        }

        public void setEnInvestKind(String enInvestKind) {
            this.enInvestKind = enInvestKind;
        }

        public void setEnInvestTerm(String enInvestTerm) {
            this.enInvestTerm = enInvestTerm;
        }

        public void setEnCorpRiskLevel(String enCorpRiskLevel) {
            this.enCorpRiskLevel = enCorpRiskLevel;
        }

        public void setEnClientIncomeType(String enClientIncomeType) {
            this.enClientIncomeType = enClientIncomeType;
        }

        public void setWeakCorpRiskLevel(String weakCorpRiskLevel) {
            this.weakCorpRiskLevel = weakCorpRiskLevel;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetBusinQualiargInnerOutput:(");
            buffer.append("businRiskLevel:" + this.businRiskLevel);
            buffer.append(",investKind:" + this.investKind);
            buffer.append(",investTerm:" + this.investTerm);
            buffer.append(",incomeType:" + this.incomeType);
            buffer.append(",enInvestKind:" + this.enInvestKind);
            buffer.append(",enInvestTerm:" + this.enInvestTerm);
            buffer.append(",enCorpRiskLevel:" + this.enCorpRiskLevel);
            buffer.append(",enClientIncomeType:" + this.enClientIncomeType);
            buffer.append(",weakCorpRiskLevel:" + this.weakCorpRiskLevel);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.businRiskLevel);
            builder.append(this.investKind);
            builder.append(this.investTerm);
            builder.append(this.incomeType);
            builder.append(this.enInvestKind);
            builder.append(this.enInvestTerm);
            builder.append(this.enCorpRiskLevel);
            builder.append(this.enClientIncomeType);
            builder.append(this.weakCorpRiskLevel);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.GetBusinQualiargInnerOutput) {
                InnerElgService.GetBusinQualiargInnerOutput test = (InnerElgService.GetBusinQualiargInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.businRiskLevel, test.businRiskLevel);
                builder.append(this.investKind, test.investKind);
                builder.append(this.investTerm, test.investTerm);
                builder.append(this.incomeType, test.incomeType);
                builder.append(this.enInvestKind, test.enInvestKind);
                builder.append(this.enInvestTerm, test.enInvestTerm);
                builder.append(this.enCorpRiskLevel, test.enCorpRiskLevel);
                builder.append(this.enClientIncomeType, test.enClientIncomeType);
                builder.append(this.weakCorpRiskLevel, test.weakCorpRiskLevel);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetBusinQualiargInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer branchNo = 0;
        @SinogramLength(
                min = 1,
                max = 10,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String acptBusinId = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character organFlag = ' ';
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId = " ";

        public GetBusinQualiargInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getAcptBusinId() {
            if (this.acptBusinId == null) {
                return " ";
            } else {
                return this.acptBusinId.isEmpty() ? " " : this.acptBusinId;
            }
        }

        public Character getOrganFlag() {
            return this.organFlag != null ? this.organFlag : ' ';
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setAcptBusinId(String acptBusinId) {
            this.acptBusinId = acptBusinId;
        }

        public void setOrganFlag(Character organFlag) {
            this.organFlag = organFlag;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetBusinQualiargInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",acptBusinId:" + this.acptBusinId);
            buffer.append(",organFlag:" + this.organFlag);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.branchNo);
            builder.append(this.acptBusinId);
            builder.append(this.organFlag);
            builder.append(this.clientId);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.GetBusinQualiargInnerInput) {
                InnerElgService.GetBusinQualiargInnerInput test = (InnerElgService.GetBusinQualiargInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.acptBusinId, test.acptBusinId);
                builder.append(this.organFlag, test.organFlag);
                builder.append(this.clientId, test.clientId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetBusinAgreementInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer signDate = 0;
        private String clientId = " ";
        private String fundAccount = " ";
        private String agreeType = " ";
        private String agreementId = " ";
        private String agreementVersion = " ";
        private String templateDir = " ";
        private String registerContent = " ";
        private Integer csfcEndDate = 0;
        private String acptBusinId = " ";
        private String acptBusinKind = " ";
        private String acptId = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character certType = ' ';
        private String certSign = " ";
        private String certOriginal = " ";
        private String remark = " ";
        private String positionStr = " ";
        private String exchangeType = " ";
        private Integer initDate = 0;

        public GetBusinAgreementInnerOutput() {
        }

        public Integer getSignDate() {
            return this.signDate != null ? this.signDate : 0;
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getAgreeType() {
            if (this.agreeType == null) {
                return " ";
            } else {
                return this.agreeType.isEmpty() ? " " : this.agreeType;
            }
        }

        public String getAgreementId() {
            if (this.agreementId == null) {
                return " ";
            } else {
                return this.agreementId.isEmpty() ? " " : this.agreementId;
            }
        }

        public String getAgreementVersion() {
            if (this.agreementVersion == null) {
                return " ";
            } else {
                return this.agreementVersion.isEmpty() ? " " : this.agreementVersion;
            }
        }

        public String getTemplateDir() {
            if (this.templateDir == null) {
                return " ";
            } else {
                return this.templateDir.isEmpty() ? " " : this.templateDir;
            }
        }

        public String getRegisterContent() {
            if (this.registerContent == null) {
                return " ";
            } else {
                return this.registerContent.isEmpty() ? " " : this.registerContent;
            }
        }

        public Integer getCsfcEndDate() {
            return this.csfcEndDate != null ? this.csfcEndDate : 0;
        }

        public String getAcptBusinId() {
            if (this.acptBusinId == null) {
                return " ";
            } else {
                return this.acptBusinId.isEmpty() ? " " : this.acptBusinId;
            }
        }

        public String getAcptBusinKind() {
            if (this.acptBusinKind == null) {
                return " ";
            } else {
                return this.acptBusinKind.isEmpty() ? " " : this.acptBusinKind;
            }
        }

        public String getAcptId() {
            if (this.acptId == null) {
                return " ";
            } else {
                return this.acptId.isEmpty() ? " " : this.acptId;
            }
        }

        public Character getCertType() {
            return this.certType != null ? this.certType : ' ';
        }

        public String getCertSign() {
            if (this.certSign == null) {
                return " ";
            } else {
                return this.certSign.isEmpty() ? " " : this.certSign;
            }
        }

        public String getCertOriginal() {
            if (this.certOriginal == null) {
                return " ";
            } else {
                return this.certOriginal.isEmpty() ? " " : this.certOriginal;
            }
        }

        public String getRemark() {
            if (this.remark == null) {
                return " ";
            } else {
                return this.remark.isEmpty() ? " " : this.remark;
            }
        }

        public String getPositionStr() {
            if (this.positionStr == null) {
                return " ";
            } else {
                return this.positionStr.isEmpty() ? " " : this.positionStr;
            }
        }

        public String getExchangeType() {
            if (this.exchangeType == null) {
                return " ";
            } else {
                return this.exchangeType.isEmpty() ? " " : this.exchangeType;
            }
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public void setSignDate(Integer signDate) {
            this.signDate = signDate;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setAgreeType(String agreeType) {
            this.agreeType = agreeType;
        }

        public void setAgreementId(String agreementId) {
            this.agreementId = agreementId;
        }

        public void setAgreementVersion(String agreementVersion) {
            this.agreementVersion = agreementVersion;
        }

        public void setTemplateDir(String templateDir) {
            this.templateDir = templateDir;
        }

        public void setRegisterContent(String registerContent) {
            this.registerContent = registerContent;
        }

        public void setCsfcEndDate(Integer csfcEndDate) {
            this.csfcEndDate = csfcEndDate;
        }

        public void setAcptBusinId(String acptBusinId) {
            this.acptBusinId = acptBusinId;
        }

        public void setAcptBusinKind(String acptBusinKind) {
            this.acptBusinKind = acptBusinKind;
        }

        public void setAcptId(String acptId) {
            this.acptId = acptId;
        }

        public void setCertType(Character certType) {
            this.certType = certType;
        }

        public void setCertSign(String certSign) {
            this.certSign = certSign;
        }

        public void setCertOriginal(String certOriginal) {
            this.certOriginal = certOriginal;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public void setPositionStr(String positionStr) {
            this.positionStr = positionStr;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetBusinAgreementInnerOutput:(");
            buffer.append("signDate:" + this.signDate);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",agreeType:" + this.agreeType);
            buffer.append(",agreementId:" + this.agreementId);
            buffer.append(",agreementVersion:" + this.agreementVersion);
            buffer.append(",templateDir:" + this.templateDir);
            buffer.append(",registerContent:" + this.registerContent);
            buffer.append(",csfcEndDate:" + this.csfcEndDate);
            buffer.append(",acptBusinId:" + this.acptBusinId);
            buffer.append(",acptBusinKind:" + this.acptBusinKind);
            buffer.append(",acptId:" + this.acptId);
            buffer.append(",certType:" + this.certType);
            buffer.append(",certSign:" + this.certSign);
            buffer.append(",certOriginal:" + this.certOriginal);
            buffer.append(",remark:" + this.remark);
            buffer.append(",positionStr:" + this.positionStr);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(",initDate:" + this.initDate);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.signDate);
            builder.append(this.clientId);
            builder.append(this.fundAccount);
            builder.append(this.agreeType);
            builder.append(this.agreementId);
            builder.append(this.agreementVersion);
            builder.append(this.templateDir);
            builder.append(this.registerContent);
            builder.append(this.csfcEndDate);
            builder.append(this.acptBusinId);
            builder.append(this.acptBusinKind);
            builder.append(this.acptId);
            builder.append(this.certType);
            builder.append(this.certSign);
            builder.append(this.certOriginal);
            builder.append(this.remark);
            builder.append(this.positionStr);
            builder.append(this.exchangeType);
            builder.append(this.initDate);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.GetBusinAgreementInnerOutput) {
                InnerElgService.GetBusinAgreementInnerOutput test = (InnerElgService.GetBusinAgreementInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.signDate, test.signDate);
                builder.append(this.clientId, test.clientId);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.agreeType, test.agreeType);
                builder.append(this.agreementId, test.agreementId);
                builder.append(this.agreementVersion, test.agreementVersion);
                builder.append(this.templateDir, test.templateDir);
                builder.append(this.registerContent, test.registerContent);
                builder.append(this.csfcEndDate, test.csfcEndDate);
                builder.append(this.acptBusinId, test.acptBusinId);
                builder.append(this.acptBusinKind, test.acptBusinKind);
                builder.append(this.acptId, test.acptId);
                builder.append(this.certType, test.certType);
                builder.append(this.certSign, test.certSign);
                builder.append(this.certOriginal, test.certOriginal);
                builder.append(this.remark, test.remark);
                builder.append(this.positionStr, test.positionStr);
                builder.append(this.exchangeType, test.exchangeType);
                builder.append(this.initDate, test.initDate);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetBusinAgreementInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer branchNo = 0;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId = " ";
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String enAgreeType = " ";

        public GetBusinAgreementInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getEnAgreeType() {
            if (this.enAgreeType == null) {
                return " ";
            } else {
                return this.enAgreeType.isEmpty() ? " " : this.enAgreeType;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setEnAgreeType(String enAgreeType) {
            this.enAgreeType = enAgreeType;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetBusinAgreementInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",enAgreeType:" + this.enAgreeType);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.branchNo);
            builder.append(this.clientId);
            builder.append(this.enAgreeType);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.GetBusinAgreementInnerInput) {
                InnerElgService.GetBusinAgreementInnerInput test = (InnerElgService.GetBusinAgreementInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.clientId, test.clientId);
                builder.append(this.enAgreeType, test.enAgreeType);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class DeleteStockholderElginfoInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Long serialNo = 0L;

        public DeleteStockholderElginfoInnerOutput() {
        }

        public Long getSerialNo() {
            return this.serialNo != null ? this.serialNo : 0L;
        }

        public void setSerialNo(Long serialNo) {
            this.serialNo = serialNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("DeleteStockholderElginfoInnerOutput:(");
            buffer.append("serialNo:" + this.serialNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.serialNo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.DeleteStockholderElginfoInnerOutput) {
                InnerElgService.DeleteStockholderElginfoInnerOutput test = (InnerElgService.DeleteStockholderElginfoInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.serialNo, test.serialNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class DeleteStockholderElginfoInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer branchNo = 0;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId = " ";
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String fundAccount = " ";
        @SinogramLength(
                min = 1,
                max = 20,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String stockAccount = " ";
        @SinogramLength(
                min = 1,
                max = 4,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String exchangeType = " ";

        public DeleteStockholderElginfoInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getStockAccount() {
            if (this.stockAccount == null) {
                return " ";
            } else {
                return this.stockAccount.isEmpty() ? " " : this.stockAccount;
            }
        }

        public String getExchangeType() {
            if (this.exchangeType == null) {
                return " ";
            } else {
                return this.exchangeType.isEmpty() ? " " : this.exchangeType;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setStockAccount(String stockAccount) {
            this.stockAccount = stockAccount;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("DeleteStockholderElginfoInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",stockAccount:" + this.stockAccount);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.branchNo);
            builder.append(this.clientId);
            builder.append(this.fundAccount);
            builder.append(this.stockAccount);
            builder.append(this.exchangeType);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.DeleteStockholderElginfoInnerInput) {
                InnerElgService.DeleteStockholderElginfoInnerInput test = (InnerElgService.DeleteStockholderElginfoInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.clientId, test.clientId);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.stockAccount, test.stockAccount);
                builder.append(this.exchangeType, test.exchangeType);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class DeleteOpenRightDetailInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Long serialNo = 0L;

        public DeleteOpenRightDetailInnerOutput() {
        }

        public Long getSerialNo() {
            return this.serialNo != null ? this.serialNo : 0L;
        }

        public void setSerialNo(Long serialNo) {
            this.serialNo = serialNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("DeleteOpenRightDetailInnerOutput:(");
            buffer.append("serialNo:" + this.serialNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.serialNo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.DeleteOpenRightDetailInnerOutput) {
                InnerElgService.DeleteOpenRightDetailInnerOutput test = (InnerElgService.DeleteOpenRightDetailInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.serialNo, test.serialNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class DeleteOpenRightDetailInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer branchNo = 0;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId = " ";
        @SinogramLength(
                min = 1,
                max = 20,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String stockAccount = " ";
        @SinogramLength(
                min = 1,
                max = 4,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String exchangeType = " ";
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String fundAccount = " ";
        private Integer businessFlag = 0;

        public DeleteOpenRightDetailInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getStockAccount() {
            if (this.stockAccount == null) {
                return " ";
            } else {
                return this.stockAccount.isEmpty() ? " " : this.stockAccount;
            }
        }

        public String getExchangeType() {
            if (this.exchangeType == null) {
                return " ";
            } else {
                return this.exchangeType.isEmpty() ? " " : this.exchangeType;
            }
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public Integer getBusinessFlag() {
            return this.businessFlag != null ? this.businessFlag : 0;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setStockAccount(String stockAccount) {
            this.stockAccount = stockAccount;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setBusinessFlag(Integer businessFlag) {
            this.businessFlag = businessFlag;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("DeleteOpenRightDetailInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",stockAccount:" + this.stockAccount);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",businessFlag:" + this.businessFlag);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.branchNo);
            builder.append(this.clientId);
            builder.append(this.stockAccount);
            builder.append(this.exchangeType);
            builder.append(this.fundAccount);
            builder.append(this.businessFlag);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.DeleteOpenRightDetailInnerInput) {
                InnerElgService.DeleteOpenRightDetailInnerInput test = (InnerElgService.DeleteOpenRightDetailInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.clientId, test.clientId);
                builder.append(this.stockAccount, test.stockAccount);
                builder.append(this.exchangeType, test.exchangeType);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.businessFlag, test.businessFlag);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class DeleteDayinitinfoDataInitInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer initDate = 0;

        public DeleteDayinitinfoDataInitInnerOutput() {
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("DeleteDayinitinfoDataInitInnerOutput:(");
            buffer.append("initDate:" + this.initDate);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.initDate);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.DeleteDayinitinfoDataInitInnerOutput) {
                InnerElgService.DeleteDayinitinfoDataInitInnerOutput test = (InnerElgService.DeleteDayinitinfoDataInitInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.initDate, test.initDate);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class DeleteDayinitinfoDataInitInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer branchNo = 0;
        private Integer initDate = 0;

        public DeleteDayinitinfoDataInitInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("DeleteDayinitinfoDataInitInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",initDate:" + this.initDate);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.branchNo);
            builder.append(this.initDate);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.DeleteDayinitinfoDataInitInnerInput) {
                InnerElgService.DeleteDayinitinfoDataInitInnerInput test = (InnerElgService.DeleteDayinitinfoDataInitInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.initDate, test.initDate);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class DeleteClientpreferByIdInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Long serialNo = 0L;

        public DeleteClientpreferByIdInnerOutput() {
        }

        public Long getSerialNo() {
            return this.serialNo != null ? this.serialNo : 0L;
        }

        public void setSerialNo(Long serialNo) {
            this.serialNo = serialNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("DeleteClientpreferByIdInnerOutput:(");
            buffer.append("serialNo:" + this.serialNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.serialNo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.DeleteClientpreferByIdInnerOutput) {
                InnerElgService.DeleteClientpreferByIdInnerOutput test = (InnerElgService.DeleteClientpreferByIdInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.serialNo, test.serialNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class DeleteClientpreferByIdInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer branchNo = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character idKind = ' ';
        @SinogramLength(
                min = 0,
                max = 40,
                charset = "utf-8"
        )
        private String idNo = " ";
        @SinogramLength(
                min = 0,
                max = 180,
                charset = "utf-8"
        )
        private String fullName = " ";

        public DeleteClientpreferByIdInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Character getIdKind() {
            return this.idKind != null ? this.idKind : ' ';
        }

        public String getIdNo() {
            if (this.idNo == null) {
                return " ";
            } else {
                return this.idNo.isEmpty() ? " " : this.idNo;
            }
        }

        public String getFullName() {
            if (this.fullName == null) {
                return " ";
            } else {
                return this.fullName.isEmpty() ? " " : this.fullName;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setIdKind(Character idKind) {
            this.idKind = idKind;
        }

        public void setIdNo(String idNo) {
            this.idNo = idNo;
        }

        public void setFullName(String fullName) {
            this.fullName = fullName;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("DeleteClientpreferByIdInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",idKind:" + this.idKind);
            buffer.append(",idNo:" + this.idNo);
            buffer.append(",fullName:" + this.fullName);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.branchNo);
            builder.append(this.idKind);
            builder.append(this.idNo);
            builder.append(this.fullName);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerElgService.DeleteClientpreferByIdInnerInput) {
                InnerElgService.DeleteClientpreferByIdInnerInput test = (InnerElgService.DeleteClientpreferByIdInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.idKind, test.idKind);
                builder.append(this.idNo, test.idNo);
                builder.append(this.fullName, test.fullName);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }
}
