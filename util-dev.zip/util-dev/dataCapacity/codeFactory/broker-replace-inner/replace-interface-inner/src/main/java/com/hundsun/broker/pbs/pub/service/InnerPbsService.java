//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.hundsun.broker.pbs.pub.service;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.hundsun.broker.base.PublicChecker.PublicParams;
import com.hundsun.broker.base.databind.CharacterJsonDeserializer;
import com.hundsun.jrescloud.rpc.annotation.CloudFunction;
import com.hundsun.jrescloud.rpc.annotation.CloudService;
import com.hundsun.jrescloud.rpc.def.json.DoubleJsonDeserializer;
import com.hundsun.jrescloud.rpc.def.json.SerializeDoubleDigit;
import com.hundsun.jrescloud.rpc.def.validation.SinogramLength;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.validation.Valid;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

@CloudService(
        validation = true,
        validationNull = false,
        application = "hsbroker.pbs"
)
public interface InnerPbsService {

    @CloudFunction(
            value = "pbs.getAllbranchByCompanyNoInner",
            desc = "组织机构券商编号查询",
            apiUrl = "/getAllbranchByCompanyNoInner"
    )
    List<InnerPbsService.GetAllbranchByCompanyNoInnerOutput> getAllbranchByCompanyNoInner(InnerPbsService.GetAllbranchByCompanyNoInnerInput var1);

    @CloudFunction(
            value = "pbs.getAllbranchByUserIdInner",
            desc = "组织机构用户编号查询",
            apiUrl = "/getAllbranchByUserIdInner"
    )
    List<InnerPbsService.GetAllbranchByUserIdInnerOutput> getAllbranchByUserIdInner(InnerPbsService.GetAllbranchByUserIdInnerInput var1);

    @CloudFunction(
            value = "pbs.getBranchByUserIdInner",
            desc = "组织机构用户查询",
            apiUrl = "/getBranchByUserIdInner"
    )
    InnerPbsService.GetBranchByUserIdInnerOutput getBranchByUserIdInner(InnerPbsService.GetBranchByUserIdInnerInput var1);

    @CloudFunction(
            value = "pbs.getDictionarySingleInner",
            desc = "数据字典子项查询",
            apiUrl = "/getDictionarySingleInner"
    )
    InnerPbsService.GetDictionarySingleInnerOutput getDictionarySingleInner(InnerPbsService.GetDictionarySingleInnerInput var1);

    @CloudFunction(
            value = "pbs.getDictionaryWithDictentryStrInner",
            desc = "数据字典结果集查询",
            apiUrl = "/getDictionaryWithDictentryStrInner"
    )
    List<InnerPbsService.GetDictionaryWithDictentryStrInnerOutput> getDictionaryWithDictentryStrInner(InnerPbsService.GetDictionaryWithDictentryStrInnerInput var1);

    @CloudFunction(
            value = "pbs.getUserrightInner",
            desc = "用户限制查询",
            apiUrl = "/getUserrightInner"
    )
    InnerPbsService.GetUserrightInnerOutput getUserrightInner(InnerPbsService.GetUserrightInnerInput var1);

    @CloudFunction(
            value = "pbs.postFiledownloadInner",
            desc = "文件下载信息增加",
            apiUrl = "/postFiledownloadInner"
    )
    InnerPbsService.PostFiledownloadInnerOutput postFiledownloadInner(InnerPbsService.PostFiledownloadInnerInput var1);

    @CloudFunction(
            value = "pbs.putFiledownloadInner",
            desc = "文件下载信息修改",
            apiUrl = "/putFiledownloadInner"
    )
    InnerPbsService.PutFiledownloadInnerOutput putFiledownloadInner(InnerPbsService.PutFiledownloadInnerInput var1);

    @CloudFunction(
            value = "pbs.getSysconfigInner",
            desc = "系统配置查询",
            apiUrl = "/getSysconfigInner"
    )
    InnerPbsService.GetSysconfigInnerOutput getSysconfigInner(InnerPbsService.GetSysconfigInnerInput var1);


    public static class PostDataSynInfoInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String opRemark = " ";

        public PostDataSynInfoInnerOutput() {
        }

        public String getOpRemark() {
            if (this.opRemark == null) {
                return " ";
            } else {
                return this.opRemark.isEmpty() ? " " : this.opRemark;
            }
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostDataSynInfoInnerOutput:(");
            buffer.append("opRemark:" + this.opRemark);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opRemark);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.PostDataSynInfoInnerOutput) {
                InnerPbsService.PostDataSynInfoInnerOutput test = (InnerPbsService.PostDataSynInfoInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opRemark, test.opRemark);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostDataSynInfoInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @NotNull(
                message = "不能为空"
        )
        private Integer sysInitDate = 0;
        @SinogramLength(
                min = 1,
                max = 180,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String tableName = " ";
        @SinogramLength(
                min = 1,
                max = 120,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String schemaName = " ";
        @NotNull(
                message = "不能为空"
        )
        private Integer syncDate = 0;
        @NotNull(
                message = "不能为空"
        )
        private Integer beginTime = 0;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character status = ' ';
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String remark = " ";

        public PostDataSynInfoInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getSysInitDate() {
            return this.sysInitDate != null ? this.sysInitDate : 0;
        }

        public String getTableName() {
            if (this.tableName == null) {
                return " ";
            } else {
                return this.tableName.isEmpty() ? " " : this.tableName;
            }
        }

        public String getSchemaName() {
            if (this.schemaName == null) {
                return " ";
            } else {
                return this.schemaName.isEmpty() ? " " : this.schemaName;
            }
        }

        public Integer getSyncDate() {
            return this.syncDate != null ? this.syncDate : 0;
        }

        public Integer getBeginTime() {
            return this.beginTime != null ? this.beginTime : 0;
        }

        public Character getStatus() {
            return this.status != null ? this.status : ' ';
        }

        public String getRemark() {
            if (this.remark == null) {
                return " ";
            } else {
                return this.remark.isEmpty() ? " " : this.remark;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setSysInitDate(Integer sysInitDate) {
            this.sysInitDate = sysInitDate;
        }

        public void setTableName(String tableName) {
            this.tableName = tableName;
        }

        public void setSchemaName(String schemaName) {
            this.schemaName = schemaName;
        }

        public void setSyncDate(Integer syncDate) {
            this.syncDate = syncDate;
        }

        public void setBeginTime(Integer beginTime) {
            this.beginTime = beginTime;
        }

        public void setStatus(Character status) {
            this.status = status;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostDataSynInfoInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",sysInitDate:" + this.sysInitDate);
            buffer.append(",tableName:" + this.tableName);
            buffer.append(",schemaName:" + this.schemaName);
            buffer.append(",syncDate:" + this.syncDate);
            buffer.append(",beginTime:" + this.beginTime);
            buffer.append(",status:" + this.status);
            buffer.append(",remark:" + this.remark);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.sysInitDate);
            builder.append(this.tableName);
            builder.append(this.schemaName);
            builder.append(this.syncDate);
            builder.append(this.beginTime);
            builder.append(this.status);
            builder.append(this.remark);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.PostDataSynInfoInnerInput) {
                InnerPbsService.PostDataSynInfoInnerInput test = (InnerPbsService.PostDataSynInfoInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.sysInitDate, test.sysInitDate);
                builder.append(this.tableName, test.tableName);
                builder.append(this.schemaName, test.schemaName);
                builder.append(this.syncDate, test.syncDate);
                builder.append(this.beginTime, test.beginTime);
                builder.append(this.status, test.status);
                builder.append(this.remark, test.remark);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutDataSynInfoInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String opRemark = " ";

        public PutDataSynInfoInnerOutput() {
        }

        public String getOpRemark() {
            if (this.opRemark == null) {
                return " ";
            } else {
                return this.opRemark.isEmpty() ? " " : this.opRemark;
            }
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutDataSynInfoInnerOutput:(");
            buffer.append("opRemark:" + this.opRemark);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opRemark);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.PutDataSynInfoInnerOutput) {
                InnerPbsService.PutDataSynInfoInnerOutput test = (InnerPbsService.PutDataSynInfoInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opRemark, test.opRemark);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutDataSynInfoInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @NotNull(
                message = "不能为空"
        )
        private Integer sysInitDate = 0;
        @SinogramLength(
                min = 1,
                max = 180,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String tableName = " ";
        @SinogramLength(
                min = 1,
                max = 120,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String schemaName = " ";
        @NotNull(
                message = "不能为空"
        )
        private Integer syncDate = 0;
        @NotNull(
                message = "不能为空"
        )
        private Integer beginTime = 0;
        @NotNull(
                message = "不能为空"
        )
        private Integer endTime = 0;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character status = ' ';
        private Long syncNumber = 0L;
        private Long syncNumberSucceed = 0L;
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String remark = " ";

        public PutDataSynInfoInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getSysInitDate() {
            return this.sysInitDate != null ? this.sysInitDate : 0;
        }

        public String getTableName() {
            if (this.tableName == null) {
                return " ";
            } else {
                return this.tableName.isEmpty() ? " " : this.tableName;
            }
        }

        public String getSchemaName() {
            if (this.schemaName == null) {
                return " ";
            } else {
                return this.schemaName.isEmpty() ? " " : this.schemaName;
            }
        }

        public Integer getSyncDate() {
            return this.syncDate != null ? this.syncDate : 0;
        }

        public Integer getBeginTime() {
            return this.beginTime != null ? this.beginTime : 0;
        }

        public Integer getEndTime() {
            return this.endTime != null ? this.endTime : 0;
        }

        public Character getStatus() {
            return this.status != null ? this.status : ' ';
        }

        public Long getSyncNumber() {
            return this.syncNumber != null ? this.syncNumber : 0L;
        }

        public Long getSyncNumberSucceed() {
            return this.syncNumberSucceed != null ? this.syncNumberSucceed : 0L;
        }

        public String getRemark() {
            if (this.remark == null) {
                return " ";
            } else {
                return this.remark.isEmpty() ? " " : this.remark;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setSysInitDate(Integer sysInitDate) {
            this.sysInitDate = sysInitDate;
        }

        public void setTableName(String tableName) {
            this.tableName = tableName;
        }

        public void setSchemaName(String schemaName) {
            this.schemaName = schemaName;
        }

        public void setSyncDate(Integer syncDate) {
            this.syncDate = syncDate;
        }

        public void setBeginTime(Integer beginTime) {
            this.beginTime = beginTime;
        }

        public void setEndTime(Integer endTime) {
            this.endTime = endTime;
        }

        public void setStatus(Character status) {
            this.status = status;
        }

        public void setSyncNumber(Long syncNumber) {
            this.syncNumber = syncNumber;
        }

        public void setSyncNumberSucceed(Long syncNumberSucceed) {
            this.syncNumberSucceed = syncNumberSucceed;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutDataSynInfoInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",sysInitDate:" + this.sysInitDate);
            buffer.append(",tableName:" + this.tableName);
            buffer.append(",schemaName:" + this.schemaName);
            buffer.append(",syncDate:" + this.syncDate);
            buffer.append(",beginTime:" + this.beginTime);
            buffer.append(",endTime:" + this.endTime);
            buffer.append(",status:" + this.status);
            buffer.append(",syncNumber:" + this.syncNumber);
            buffer.append(",syncNumberSucceed:" + this.syncNumberSucceed);
            buffer.append(",remark:" + this.remark);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.sysInitDate);
            builder.append(this.tableName);
            builder.append(this.schemaName);
            builder.append(this.syncDate);
            builder.append(this.beginTime);
            builder.append(this.endTime);
            builder.append(this.status);
            builder.append(this.syncNumber);
            builder.append(this.syncNumberSucceed);
            builder.append(this.remark);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.PutDataSynInfoInnerInput) {
                InnerPbsService.PutDataSynInfoInnerInput test = (InnerPbsService.PutDataSynInfoInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.sysInitDate, test.sysInitDate);
                builder.append(this.tableName, test.tableName);
                builder.append(this.schemaName, test.schemaName);
                builder.append(this.syncDate, test.syncDate);
                builder.append(this.beginTime, test.beginTime);
                builder.append(this.endTime, test.endTime);
                builder.append(this.status, test.status);
                builder.append(this.syncNumber, test.syncNumber);
                builder.append(this.syncNumberSucceed, test.syncNumberSucceed);
                builder.append(this.remark, test.remark);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetDataSynInfoInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer sysInitDate = 0;
        private String schemaName = " ";
        private String tableName = " ";
        private Integer syncDate = 0;
        private Integer beginTime = 0;
        private Integer endTime = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character status = ' ';
        private Long syncNumber = 0L;
        private Long syncNumberSucceed = 0L;
        private String remark = " ";

        public GetDataSynInfoInnerOutput() {
        }

        public Integer getSysInitDate() {
            return this.sysInitDate != null ? this.sysInitDate : 0;
        }

        public String getSchemaName() {
            if (this.schemaName == null) {
                return " ";
            } else {
                return this.schemaName.isEmpty() ? " " : this.schemaName;
            }
        }

        public String getTableName() {
            if (this.tableName == null) {
                return " ";
            } else {
                return this.tableName.isEmpty() ? " " : this.tableName;
            }
        }

        public Integer getSyncDate() {
            return this.syncDate != null ? this.syncDate : 0;
        }

        public Integer getBeginTime() {
            return this.beginTime != null ? this.beginTime : 0;
        }

        public Integer getEndTime() {
            return this.endTime != null ? this.endTime : 0;
        }

        public Character getStatus() {
            return this.status != null ? this.status : ' ';
        }

        public Long getSyncNumber() {
            return this.syncNumber != null ? this.syncNumber : 0L;
        }

        public Long getSyncNumberSucceed() {
            return this.syncNumberSucceed != null ? this.syncNumberSucceed : 0L;
        }

        public String getRemark() {
            if (this.remark == null) {
                return " ";
            } else {
                return this.remark.isEmpty() ? " " : this.remark;
            }
        }

        public void setSysInitDate(Integer sysInitDate) {
            this.sysInitDate = sysInitDate;
        }

        public void setSchemaName(String schemaName) {
            this.schemaName = schemaName;
        }

        public void setTableName(String tableName) {
            this.tableName = tableName;
        }

        public void setSyncDate(Integer syncDate) {
            this.syncDate = syncDate;
        }

        public void setBeginTime(Integer beginTime) {
            this.beginTime = beginTime;
        }

        public void setEndTime(Integer endTime) {
            this.endTime = endTime;
        }

        public void setStatus(Character status) {
            this.status = status;
        }

        public void setSyncNumber(Long syncNumber) {
            this.syncNumber = syncNumber;
        }

        public void setSyncNumberSucceed(Long syncNumberSucceed) {
            this.syncNumberSucceed = syncNumberSucceed;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetDataSynInfoInnerOutput:(");
            buffer.append("sysInitDate:" + this.sysInitDate);
            buffer.append(",schemaName:" + this.schemaName);
            buffer.append(",tableName:" + this.tableName);
            buffer.append(",syncDate:" + this.syncDate);
            buffer.append(",beginTime:" + this.beginTime);
            buffer.append(",endTime:" + this.endTime);
            buffer.append(",status:" + this.status);
            buffer.append(",syncNumber:" + this.syncNumber);
            buffer.append(",syncNumberSucceed:" + this.syncNumberSucceed);
            buffer.append(",remark:" + this.remark);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.sysInitDate);
            builder.append(this.schemaName);
            builder.append(this.tableName);
            builder.append(this.syncDate);
            builder.append(this.beginTime);
            builder.append(this.endTime);
            builder.append(this.status);
            builder.append(this.syncNumber);
            builder.append(this.syncNumberSucceed);
            builder.append(this.remark);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetDataSynInfoInnerOutput) {
                InnerPbsService.GetDataSynInfoInnerOutput test = (InnerPbsService.GetDataSynInfoInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.sysInitDate, test.sysInitDate);
                builder.append(this.schemaName, test.schemaName);
                builder.append(this.tableName, test.tableName);
                builder.append(this.syncDate, test.syncDate);
                builder.append(this.beginTime, test.beginTime);
                builder.append(this.endTime, test.endTime);
                builder.append(this.status, test.status);
                builder.append(this.syncNumber, test.syncNumber);
                builder.append(this.syncNumberSucceed, test.syncNumberSucceed);
                builder.append(this.remark, test.remark);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetDataSynInfoInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @NotNull(
                message = "不能为空"
        )
        private Integer sysInitDate = 0;
        @SinogramLength(
                min = 1,
                max = 180,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String tableName = " ";
        @SinogramLength(
                min = 1,
                max = 120,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String schemaName = " ";

        public GetDataSynInfoInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getSysInitDate() {
            return this.sysInitDate != null ? this.sysInitDate : 0;
        }

        public String getTableName() {
            if (this.tableName == null) {
                return " ";
            } else {
                return this.tableName.isEmpty() ? " " : this.tableName;
            }
        }

        public String getSchemaName() {
            if (this.schemaName == null) {
                return " ";
            } else {
                return this.schemaName.isEmpty() ? " " : this.schemaName;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setSysInitDate(Integer sysInitDate) {
            this.sysInitDate = sysInitDate;
        }

        public void setTableName(String tableName) {
            this.tableName = tableName;
        }

        public void setSchemaName(String schemaName) {
            this.schemaName = schemaName;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetDataSynInfoInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",sysInitDate:" + this.sysInitDate);
            buffer.append(",tableName:" + this.tableName);
            buffer.append(",schemaName:" + this.schemaName);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.sysInitDate);
            builder.append(this.tableName);
            builder.append(this.schemaName);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetDataSynInfoInnerInput) {
                InnerPbsService.GetDataSynInfoInnerInput test = (InnerPbsService.GetDataSynInfoInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.sysInitDate, test.sysInitDate);
                builder.append(this.tableName, test.tableName);
                builder.append(this.schemaName, test.schemaName);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class OperlogDTO implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer initDate = 0;
        private Long serialNo = 0L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        private Integer branchNo = 0;
        private Integer currDate = 0;
        private Integer currTime = 0;
        @SinogramLength(
                min = 0,
                max = 8,
                charset = "utf-8"
        )
        private String systemStr = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String menuCode = " ";
        @SinogramLength(
                min = 0,
                max = 180,
                charset = "utf-8"
        )
        private String menuName = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String functionStr = " ";
        @SinogramLength(
                min = 0,
                max = 180,
                charset = "utf-8"
        )
        private String functionName = " ";
        private Integer businessFlag = 0;
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String opRemark = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character operatorAction = ' ';
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String clientId = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fundAccount = " ";
        @SinogramLength(
                min = 0,
                max = 20,
                charset = "utf-8"
        )
        private String tradeAccount = " ";
        @Digits(
                integer = 13,
                fraction = 2,
                message = "发生数量【occurAmount】 超出精度范围, 最大整数位为【13】, 小数位为【2】"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double occurAmount = 0.0D;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "发生金额【occurBalance】 超出精度范围, 最大整数位为【13】, 小数位为【2】"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double occurBalance = 0.0D;
        @SinogramLength(
                min = 0,
                max = 3,
                charset = "utf-8"
        )
        private String moneyType = " ";
        private Long joinSerialNo = 0L;
        private Integer joinDate = 0;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String traceId = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String acptId = " ";
        @SinogramLength(
                min = 0,
                max = 100,
                charset = "utf-8"
        )
        private String positionStr = " ";

        public OperlogDTO() {
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public Long getSerialNo() {
            return this.serialNo != null ? this.serialNo : 0L;
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Integer getCurrDate() {
            return this.currDate != null ? this.currDate : 0;
        }

        public Integer getCurrTime() {
            return this.currTime != null ? this.currTime : 0;
        }

        public String getSystemStr() {
            if (this.systemStr == null) {
                return " ";
            } else {
                return this.systemStr.isEmpty() ? " " : this.systemStr;
            }
        }

        public String getMenuCode() {
            if (this.menuCode == null) {
                return " ";
            } else {
                return this.menuCode.isEmpty() ? " " : this.menuCode;
            }
        }

        public String getMenuName() {
            if (this.menuName == null) {
                return " ";
            } else {
                return this.menuName.isEmpty() ? " " : this.menuName;
            }
        }

        public String getFunctionStr() {
            if (this.functionStr == null) {
                return " ";
            } else {
                return this.functionStr.isEmpty() ? " " : this.functionStr;
            }
        }

        public String getFunctionName() {
            if (this.functionName == null) {
                return " ";
            } else {
                return this.functionName.isEmpty() ? " " : this.functionName;
            }
        }

        public Integer getBusinessFlag() {
            return this.businessFlag != null ? this.businessFlag : 0;
        }

        public String getOpRemark() {
            if (this.opRemark == null) {
                return " ";
            } else {
                return this.opRemark.isEmpty() ? " " : this.opRemark;
            }
        }

        public Character getOperatorAction() {
            return this.operatorAction != null ? this.operatorAction : ' ';
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getTradeAccount() {
            if (this.tradeAccount == null) {
                return " ";
            } else {
                return this.tradeAccount.isEmpty() ? " " : this.tradeAccount;
            }
        }

        public Double getOccurAmount() {
            return this.occurAmount != null ? this.occurAmount : 0.0D;
        }

        public Double getOccurBalance() {
            return this.occurBalance != null ? this.occurBalance : 0.0D;
        }

        public String getMoneyType() {
            if (this.moneyType == null) {
                return " ";
            } else {
                return this.moneyType.isEmpty() ? " " : this.moneyType;
            }
        }

        public Long getJoinSerialNo() {
            return this.joinSerialNo != null ? this.joinSerialNo : 0L;
        }

        public Integer getJoinDate() {
            return this.joinDate != null ? this.joinDate : 0;
        }

        public String getTraceId() {
            if (this.traceId == null) {
                return " ";
            } else {
                return this.traceId.isEmpty() ? " " : this.traceId;
            }
        }

        public String getAcptId() {
            if (this.acptId == null) {
                return " ";
            } else {
                return this.acptId.isEmpty() ? " " : this.acptId;
            }
        }

        public String getPositionStr() {
            if (this.positionStr == null) {
                return " ";
            } else {
                return this.positionStr.isEmpty() ? " " : this.positionStr;
            }
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public void setSerialNo(Long serialNo) {
            this.serialNo = serialNo;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setCurrDate(Integer currDate) {
            this.currDate = currDate;
        }

        public void setCurrTime(Integer currTime) {
            this.currTime = currTime;
        }

        public void setSystemStr(String systemStr) {
            this.systemStr = systemStr;
        }

        public void setMenuCode(String menuCode) {
            this.menuCode = menuCode;
        }

        public void setMenuName(String menuName) {
            this.menuName = menuName;
        }

        public void setFunctionStr(String functionStr) {
            this.functionStr = functionStr;
        }

        public void setFunctionName(String functionName) {
            this.functionName = functionName;
        }

        public void setBusinessFlag(Integer businessFlag) {
            this.businessFlag = businessFlag;
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public void setOperatorAction(Character operatorAction) {
            this.operatorAction = operatorAction;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setTradeAccount(String tradeAccount) {
            this.tradeAccount = tradeAccount;
        }

        public void setOccurAmount(Double occurAmount) {
            this.occurAmount = occurAmount;
        }

        public void setOccurBalance(Double occurBalance) {
            this.occurBalance = occurBalance;
        }

        public void setMoneyType(String moneyType) {
            this.moneyType = moneyType;
        }

        public void setJoinSerialNo(Long joinSerialNo) {
            this.joinSerialNo = joinSerialNo;
        }

        public void setJoinDate(Integer joinDate) {
            this.joinDate = joinDate;
        }

        public void setTraceId(String traceId) {
            this.traceId = traceId;
        }

        public void setAcptId(String acptId) {
            this.acptId = acptId;
        }

        public void setPositionStr(String positionStr) {
            this.positionStr = positionStr;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("OperlogDTO:(");
            buffer.append("initDate:" + this.initDate);
            buffer.append(",serialNo:" + this.serialNo);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",currDate:" + this.currDate);
            buffer.append(",currTime:" + this.currTime);
            buffer.append(",systemStr:" + this.systemStr);
            buffer.append(",menuCode:" + this.menuCode);
            buffer.append(",menuName:" + this.menuName);
            buffer.append(",functionStr:" + this.functionStr);
            buffer.append(",functionName:" + this.functionName);
            buffer.append(",businessFlag:" + this.businessFlag);
            buffer.append(",opRemark:" + this.opRemark);
            buffer.append(",operatorAction:" + this.operatorAction);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",tradeAccount:" + this.tradeAccount);
            buffer.append(",occurAmount:" + this.occurAmount);
            buffer.append(",occurBalance:" + this.occurBalance);
            buffer.append(",moneyType:" + this.moneyType);
            buffer.append(",joinSerialNo:" + this.joinSerialNo);
            buffer.append(",joinDate:" + this.joinDate);
            buffer.append(",traceId:" + this.traceId);
            buffer.append(",acptId:" + this.acptId);
            buffer.append(",positionStr:" + this.positionStr);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.initDate);
            builder.append(this.serialNo);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opEntrustWay);
            builder.append(this.opStation);
            builder.append(this.branchNo);
            builder.append(this.currDate);
            builder.append(this.currTime);
            builder.append(this.systemStr);
            builder.append(this.menuCode);
            builder.append(this.menuName);
            builder.append(this.functionStr);
            builder.append(this.functionName);
            builder.append(this.businessFlag);
            builder.append(this.opRemark);
            builder.append(this.operatorAction);
            builder.append(this.clientId);
            builder.append(this.fundAccount);
            builder.append(this.tradeAccount);
            builder.append(this.occurAmount);
            builder.append(this.occurBalance);
            builder.append(this.moneyType);
            builder.append(this.joinSerialNo);
            builder.append(this.joinDate);
            builder.append(this.traceId);
            builder.append(this.acptId);
            builder.append(this.positionStr);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.OperlogDTO) {
                InnerPbsService.OperlogDTO test = (InnerPbsService.OperlogDTO)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.initDate, test.initDate);
                builder.append(this.serialNo, test.serialNo);
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.opStation, test.opStation);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.currDate, test.currDate);
                builder.append(this.currTime, test.currTime);
                builder.append(this.systemStr, test.systemStr);
                builder.append(this.menuCode, test.menuCode);
                builder.append(this.menuName, test.menuName);
                builder.append(this.functionStr, test.functionStr);
                builder.append(this.functionName, test.functionName);
                builder.append(this.businessFlag, test.businessFlag);
                builder.append(this.opRemark, test.opRemark);
                builder.append(this.operatorAction, test.operatorAction);
                builder.append(this.clientId, test.clientId);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.tradeAccount, test.tradeAccount);
                builder.append(this.occurAmount, test.occurAmount);
                builder.append(this.occurBalance, test.occurBalance);
                builder.append(this.moneyType, test.moneyType);
                builder.append(this.joinSerialNo, test.joinSerialNo);
                builder.append(this.joinDate, test.joinDate);
                builder.append(this.traceId, test.traceId);
                builder.append(this.acptId, test.acptId);
                builder.append(this.positionStr, test.positionStr);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class TreeHsmenuDTO implements Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 180,
                charset = "utf-8"
        )
        private String menuName = " ";
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String roleRights = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String menuCode = " ";
        private Long orderNo = 0L;
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String menuUrl = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String menuIcon = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String menuArg = " ";
        @SinogramLength(
                min = 0,
                max = 128,
                charset = "utf-8"
        )
        private String openFlag = " ";
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String remark = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String orgId = " ";
        @SinogramLength(
                min = 0,
                max = 100,
                charset = "utf-8"
        )
        private String fontName = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String hkMenuName = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String langMenuName = " ";
        @SinogramLength(
                min = 0,
                max = 2,
                charset = "utf-8"
        )
        private String isHidden = " ";
        @SinogramLength(
                min = 0,
                max = 2,
                charset = "utf-8"
        )
        private String isKeepAlivea = " ";
        @SinogramLength(
                min = 0,
                max = 100,
                charset = "utf-8"
        )
        private String appCode = " ";
        @SinogramLength(
                min = 0,
                max = 10,
                charset = "utf-8"
        )
        private String menuIsLeaf = " ";
        @SinogramLength(
                min = 0,
                max = 128,
                charset = "utf-8"
        )
        private String menuPluginDll = " ";
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String menuPluginName = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String treeIdx = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String parentCode = " ";
        @SinogramLength(
                min = 0,
                max = 8,
                charset = "utf-8"
        )
        private String windowModel = " ";
        @SinogramLength(
                min = 0,
                max = 100,
                charset = "utf-8"
        )
        private String menuKindCode = " ";
        @SinogramLength(
                min = 0,
                max = 20,
                charset = "utf-8"
        )
        private String menuConfig = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character collectFlag = ' ';
        @Valid
        private List<InnerPbsService.TreeHsmenuDTO> children = new ArrayList();

        public TreeHsmenuDTO() {
        }

        public String getMenuName() {
            if (this.menuName == null) {
                return " ";
            } else {
                return this.menuName.isEmpty() ? " " : this.menuName;
            }
        }

        public String getRoleRights() {
            if (this.roleRights == null) {
                return " ";
            } else {
                return this.roleRights.isEmpty() ? " " : this.roleRights;
            }
        }

        public String getMenuCode() {
            if (this.menuCode == null) {
                return " ";
            } else {
                return this.menuCode.isEmpty() ? " " : this.menuCode;
            }
        }

        public Long getOrderNo() {
            return this.orderNo != null ? this.orderNo : 0L;
        }

        public String getMenuUrl() {
            if (this.menuUrl == null) {
                return " ";
            } else {
                return this.menuUrl.isEmpty() ? " " : this.menuUrl;
            }
        }

        public String getMenuIcon() {
            if (this.menuIcon == null) {
                return " ";
            } else {
                return this.menuIcon.isEmpty() ? " " : this.menuIcon;
            }
        }

        public String getMenuArg() {
            if (this.menuArg == null) {
                return " ";
            } else {
                return this.menuArg.isEmpty() ? " " : this.menuArg;
            }
        }

        public String getOpenFlag() {
            if (this.openFlag == null) {
                return " ";
            } else {
                return this.openFlag.isEmpty() ? " " : this.openFlag;
            }
        }

        public String getRemark() {
            if (this.remark == null) {
                return " ";
            } else {
                return this.remark.isEmpty() ? " " : this.remark;
            }
        }

        public String getOrgId() {
            if (this.orgId == null) {
                return " ";
            } else {
                return this.orgId.isEmpty() ? " " : this.orgId;
            }
        }

        public String getFontName() {
            if (this.fontName == null) {
                return " ";
            } else {
                return this.fontName.isEmpty() ? " " : this.fontName;
            }
        }

        public String getHkMenuName() {
            if (this.hkMenuName == null) {
                return " ";
            } else {
                return this.hkMenuName.isEmpty() ? " " : this.hkMenuName;
            }
        }

        public String getLangMenuName() {
            if (this.langMenuName == null) {
                return " ";
            } else {
                return this.langMenuName.isEmpty() ? " " : this.langMenuName;
            }
        }

        public String getIsHidden() {
            if (this.isHidden == null) {
                return " ";
            } else {
                return this.isHidden.isEmpty() ? " " : this.isHidden;
            }
        }

        public String getIsKeepAlivea() {
            if (this.isKeepAlivea == null) {
                return " ";
            } else {
                return this.isKeepAlivea.isEmpty() ? " " : this.isKeepAlivea;
            }
        }

        public String getAppCode() {
            if (this.appCode == null) {
                return " ";
            } else {
                return this.appCode.isEmpty() ? " " : this.appCode;
            }
        }

        public String getMenuIsLeaf() {
            if (this.menuIsLeaf == null) {
                return " ";
            } else {
                return this.menuIsLeaf.isEmpty() ? " " : this.menuIsLeaf;
            }
        }

        public String getMenuPluginDll() {
            if (this.menuPluginDll == null) {
                return " ";
            } else {
                return this.menuPluginDll.isEmpty() ? " " : this.menuPluginDll;
            }
        }

        public String getMenuPluginName() {
            if (this.menuPluginName == null) {
                return " ";
            } else {
                return this.menuPluginName.isEmpty() ? " " : this.menuPluginName;
            }
        }

        public String getTreeIdx() {
            if (this.treeIdx == null) {
                return " ";
            } else {
                return this.treeIdx.isEmpty() ? " " : this.treeIdx;
            }
        }

        public String getParentCode() {
            if (this.parentCode == null) {
                return " ";
            } else {
                return this.parentCode.isEmpty() ? " " : this.parentCode;
            }
        }

        public String getWindowModel() {
            if (this.windowModel == null) {
                return " ";
            } else {
                return this.windowModel.isEmpty() ? " " : this.windowModel;
            }
        }

        public String getMenuKindCode() {
            if (this.menuKindCode == null) {
                return " ";
            } else {
                return this.menuKindCode.isEmpty() ? " " : this.menuKindCode;
            }
        }

        public String getMenuConfig() {
            if (this.menuConfig == null) {
                return " ";
            } else {
                return this.menuConfig.isEmpty() ? " " : this.menuConfig;
            }
        }

        public Character getCollectFlag() {
            return this.collectFlag != null ? this.collectFlag : ' ';
        }

        public List<InnerPbsService.TreeHsmenuDTO> getChildren() {
            return (List)(this.children != null ? this.children : new ArrayList());
        }

        public void setMenuName(String menuName) {
            this.menuName = menuName;
        }

        public void setRoleRights(String roleRights) {
            this.roleRights = roleRights;
        }

        public void setMenuCode(String menuCode) {
            this.menuCode = menuCode;
        }

        public void setOrderNo(Long orderNo) {
            this.orderNo = orderNo;
        }

        public void setMenuUrl(String menuUrl) {
            this.menuUrl = menuUrl;
        }

        public void setMenuIcon(String menuIcon) {
            this.menuIcon = menuIcon;
        }

        public void setMenuArg(String menuArg) {
            this.menuArg = menuArg;
        }

        public void setOpenFlag(String openFlag) {
            this.openFlag = openFlag;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public void setOrgId(String orgId) {
            this.orgId = orgId;
        }

        public void setFontName(String fontName) {
            this.fontName = fontName;
        }

        public void setHkMenuName(String hkMenuName) {
            this.hkMenuName = hkMenuName;
        }

        public void setLangMenuName(String langMenuName) {
            this.langMenuName = langMenuName;
        }

        public void setIsHidden(String isHidden) {
            this.isHidden = isHidden;
        }

        public void setIsKeepAlivea(String isKeepAlivea) {
            this.isKeepAlivea = isKeepAlivea;
        }

        public void setAppCode(String appCode) {
            this.appCode = appCode;
        }

        public void setMenuIsLeaf(String menuIsLeaf) {
            this.menuIsLeaf = menuIsLeaf;
        }

        public void setMenuPluginDll(String menuPluginDll) {
            this.menuPluginDll = menuPluginDll;
        }

        public void setMenuPluginName(String menuPluginName) {
            this.menuPluginName = menuPluginName;
        }

        public void setTreeIdx(String treeIdx) {
            this.treeIdx = treeIdx;
        }

        public void setParentCode(String parentCode) {
            this.parentCode = parentCode;
        }

        public void setWindowModel(String windowModel) {
            this.windowModel = windowModel;
        }

        public void setMenuKindCode(String menuKindCode) {
            this.menuKindCode = menuKindCode;
        }

        public void setMenuConfig(String menuConfig) {
            this.menuConfig = menuConfig;
        }

        public void setCollectFlag(Character collectFlag) {
            this.collectFlag = collectFlag;
        }

        public void setChildren(List<InnerPbsService.TreeHsmenuDTO> children) {
            this.children = children;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("TreeHsmenuDTO:(");
            buffer.append("menuName:" + this.menuName);
            buffer.append(",roleRights:" + this.roleRights);
            buffer.append(",menuCode:" + this.menuCode);
            buffer.append(",orderNo:" + this.orderNo);
            buffer.append(",menuUrl:" + this.menuUrl);
            buffer.append(",menuIcon:" + this.menuIcon);
            buffer.append(",menuArg:" + this.menuArg);
            buffer.append(",openFlag:" + this.openFlag);
            buffer.append(",remark:" + this.remark);
            buffer.append(",orgId:" + this.orgId);
            buffer.append(",fontName:" + this.fontName);
            buffer.append(",hkMenuName:" + this.hkMenuName);
            buffer.append(",langMenuName:" + this.langMenuName);
            buffer.append(",isHidden:" + this.isHidden);
            buffer.append(",isKeepAlivea:" + this.isKeepAlivea);
            buffer.append(",appCode:" + this.appCode);
            buffer.append(",menuIsLeaf:" + this.menuIsLeaf);
            buffer.append(",menuPluginDll:" + this.menuPluginDll);
            buffer.append(",menuPluginName:" + this.menuPluginName);
            buffer.append(",treeIdx:" + this.treeIdx);
            buffer.append(",parentCode:" + this.parentCode);
            buffer.append(",windowModel:" + this.windowModel);
            buffer.append(",menuKindCode:" + this.menuKindCode);
            buffer.append(",menuConfig:" + this.menuConfig);
            buffer.append(",collectFlag:" + this.collectFlag);
            buffer.append(",children:" + this.children);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.menuName);
            builder.append(this.roleRights);
            builder.append(this.menuCode);
            builder.append(this.orderNo);
            builder.append(this.menuUrl);
            builder.append(this.menuIcon);
            builder.append(this.menuArg);
            builder.append(this.openFlag);
            builder.append(this.remark);
            builder.append(this.orgId);
            builder.append(this.fontName);
            builder.append(this.hkMenuName);
            builder.append(this.langMenuName);
            builder.append(this.isHidden);
            builder.append(this.isKeepAlivea);
            builder.append(this.appCode);
            builder.append(this.menuIsLeaf);
            builder.append(this.menuPluginDll);
            builder.append(this.menuPluginName);
            builder.append(this.treeIdx);
            builder.append(this.parentCode);
            builder.append(this.windowModel);
            builder.append(this.menuKindCode);
            builder.append(this.menuConfig);
            builder.append(this.collectFlag);
            builder.append(this.children);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.TreeHsmenuDTO) {
                InnerPbsService.TreeHsmenuDTO test = (InnerPbsService.TreeHsmenuDTO)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.menuName, test.menuName);
                builder.append(this.roleRights, test.roleRights);
                builder.append(this.menuCode, test.menuCode);
                builder.append(this.orderNo, test.orderNo);
                builder.append(this.menuUrl, test.menuUrl);
                builder.append(this.menuIcon, test.menuIcon);
                builder.append(this.menuArg, test.menuArg);
                builder.append(this.openFlag, test.openFlag);
                builder.append(this.remark, test.remark);
                builder.append(this.orgId, test.orgId);
                builder.append(this.fontName, test.fontName);
                builder.append(this.hkMenuName, test.hkMenuName);
                builder.append(this.langMenuName, test.langMenuName);
                builder.append(this.isHidden, test.isHidden);
                builder.append(this.isKeepAlivea, test.isKeepAlivea);
                builder.append(this.appCode, test.appCode);
                builder.append(this.menuIsLeaf, test.menuIsLeaf);
                builder.append(this.menuPluginDll, test.menuPluginDll);
                builder.append(this.menuPluginName, test.menuPluginName);
                builder.append(this.treeIdx, test.treeIdx);
                builder.append(this.parentCode, test.parentCode);
                builder.append(this.windowModel, test.windowModel);
                builder.append(this.menuKindCode, test.menuKindCode);
                builder.append(this.menuConfig, test.menuConfig);
                builder.append(this.collectFlag, test.collectFlag);
                builder.append(this.children, test.children);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetUserListInnerDTO implements Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String userId = " ";
        @SinogramLength(
                min = 0,
                max = 60,
                charset = "utf-8"
        )
        private String operatorName = " ";
        private Integer branchNo = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character idKind = ' ';
        @SinogramLength(
                min = 0,
                max = 40,
                charset = "utf-8"
        )
        private String idNo = " ";
        @SinogramLength(
                min = 0,
                max = 128,
                charset = "utf-8"
        )
        private String emailAddress = " ";
        @SinogramLength(
                min = 0,
                max = 24,
                charset = "utf-8"
        )
        private String mobileTel = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String telephone = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character userType = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character userStatus = ' ';

        public GetUserListInnerDTO() {
        }

        public String getUserId() {
            if (this.userId == null) {
                return " ";
            } else {
                return this.userId.isEmpty() ? " " : this.userId;
            }
        }

        public String getOperatorName() {
            if (this.operatorName == null) {
                return " ";
            } else {
                return this.operatorName.isEmpty() ? " " : this.operatorName;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Character getIdKind() {
            return this.idKind != null ? this.idKind : ' ';
        }

        public String getIdNo() {
            if (this.idNo == null) {
                return " ";
            } else {
                return this.idNo.isEmpty() ? " " : this.idNo;
            }
        }

        public String getEmailAddress() {
            if (this.emailAddress == null) {
                return " ";
            } else {
                return this.emailAddress.isEmpty() ? " " : this.emailAddress;
            }
        }

        public String getMobileTel() {
            if (this.mobileTel == null) {
                return " ";
            } else {
                return this.mobileTel.isEmpty() ? " " : this.mobileTel;
            }
        }

        public String getTelephone() {
            if (this.telephone == null) {
                return " ";
            } else {
                return this.telephone.isEmpty() ? " " : this.telephone;
            }
        }

        public Character getUserType() {
            return this.userType != null ? this.userType : ' ';
        }

        public Character getUserStatus() {
            return this.userStatus != null ? this.userStatus : ' ';
        }

        public void setUserId(String userId) {
            this.userId = userId;
        }

        public void setOperatorName(String operatorName) {
            this.operatorName = operatorName;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setIdKind(Character idKind) {
            this.idKind = idKind;
        }

        public void setIdNo(String idNo) {
            this.idNo = idNo;
        }

        public void setEmailAddress(String emailAddress) {
            this.emailAddress = emailAddress;
        }

        public void setMobileTel(String mobileTel) {
            this.mobileTel = mobileTel;
        }

        public void setTelephone(String telephone) {
            this.telephone = telephone;
        }

        public void setUserType(Character userType) {
            this.userType = userType;
        }

        public void setUserStatus(Character userStatus) {
            this.userStatus = userStatus;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetUserListInnerDTO:(");
            buffer.append("userId:" + this.userId);
            buffer.append(",operatorName:" + this.operatorName);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",idKind:" + this.idKind);
            buffer.append(",idNo:" + this.idNo);
            buffer.append(",emailAddress:" + this.emailAddress);
            buffer.append(",mobileTel:" + this.mobileTel);
            buffer.append(",telephone:" + this.telephone);
            buffer.append(",userType:" + this.userType);
            buffer.append(",userStatus:" + this.userStatus);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.userId);
            builder.append(this.operatorName);
            builder.append(this.branchNo);
            builder.append(this.idKind);
            builder.append(this.idNo);
            builder.append(this.emailAddress);
            builder.append(this.mobileTel);
            builder.append(this.telephone);
            builder.append(this.userType);
            builder.append(this.userStatus);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetUserListInnerDTO) {
                InnerPbsService.GetUserListInnerDTO test = (InnerPbsService.GetUserListInnerDTO)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.userId, test.userId);
                builder.append(this.operatorName, test.operatorName);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.idKind, test.idKind);
                builder.append(this.idNo, test.idNo);
                builder.append(this.emailAddress, test.emailAddress);
                builder.append(this.mobileTel, test.mobileTel);
                builder.append(this.telephone, test.telephone);
                builder.append(this.userType, test.userType);
                builder.append(this.userStatus, test.userStatus);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class SyncDatasourceDTO implements Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String tableNameSrc = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character realSyncFlag = ' ';
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String todapCond = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character dapPartitionFlag = ' ';
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String primaryKeyInfo = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character mainShardingFlag = ' ';

        public SyncDatasourceDTO() {
        }

        public String getTableNameSrc() {
            if (this.tableNameSrc == null) {
                return " ";
            } else {
                return this.tableNameSrc.isEmpty() ? " " : this.tableNameSrc;
            }
        }

        public Character getRealSyncFlag() {
            return this.realSyncFlag != null ? this.realSyncFlag : ' ';
        }

        public String getTodapCond() {
            if (this.todapCond == null) {
                return " ";
            } else {
                return this.todapCond.isEmpty() ? " " : this.todapCond;
            }
        }

        public Character getDapPartitionFlag() {
            return this.dapPartitionFlag != null ? this.dapPartitionFlag : ' ';
        }

        public String getPrimaryKeyInfo() {
            if (this.primaryKeyInfo == null) {
                return " ";
            } else {
                return this.primaryKeyInfo.isEmpty() ? " " : this.primaryKeyInfo;
            }
        }

        public Character getMainShardingFlag() {
            return this.mainShardingFlag != null ? this.mainShardingFlag : ' ';
        }

        public void setTableNameSrc(String tableNameSrc) {
            this.tableNameSrc = tableNameSrc;
        }

        public void setRealSyncFlag(Character realSyncFlag) {
            this.realSyncFlag = realSyncFlag;
        }

        public void setTodapCond(String todapCond) {
            this.todapCond = todapCond;
        }

        public void setDapPartitionFlag(Character dapPartitionFlag) {
            this.dapPartitionFlag = dapPartitionFlag;
        }

        public void setPrimaryKeyInfo(String primaryKeyInfo) {
            this.primaryKeyInfo = primaryKeyInfo;
        }

        public void setMainShardingFlag(Character mainShardingFlag) {
            this.mainShardingFlag = mainShardingFlag;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("SyncDatasourceDTO:(");
            buffer.append("tableNameSrc:" + this.tableNameSrc);
            buffer.append(",realSyncFlag:" + this.realSyncFlag);
            buffer.append(",todapCond:" + this.todapCond);
            buffer.append(",dapPartitionFlag:" + this.dapPartitionFlag);
            buffer.append(",primaryKeyInfo:" + this.primaryKeyInfo);
            buffer.append(",mainShardingFlag:" + this.mainShardingFlag);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.tableNameSrc);
            builder.append(this.realSyncFlag);
            builder.append(this.todapCond);
            builder.append(this.dapPartitionFlag);
            builder.append(this.primaryKeyInfo);
            builder.append(this.mainShardingFlag);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.SyncDatasourceDTO) {
                InnerPbsService.SyncDatasourceDTO test = (InnerPbsService.SyncDatasourceDTO)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.tableNameSrc, test.tableNameSrc);
                builder.append(this.realSyncFlag, test.realSyncFlag);
                builder.append(this.todapCond, test.todapCond);
                builder.append(this.dapPartitionFlag, test.dapPartitionFlag);
                builder.append(this.primaryKeyInfo, test.primaryKeyInfo);
                builder.append(this.mainShardingFlag, test.mainShardingFlag);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class RolesDTO implements Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String roleId = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character roleKind = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String roleName = " ";

        public RolesDTO() {
        }

        public String getRoleId() {
            if (this.roleId == null) {
                return " ";
            } else {
                return this.roleId.isEmpty() ? " " : this.roleId;
            }
        }

        public Character getRoleKind() {
            return this.roleKind != null ? this.roleKind : ' ';
        }

        public String getRoleName() {
            if (this.roleName == null) {
                return " ";
            } else {
                return this.roleName.isEmpty() ? " " : this.roleName;
            }
        }

        public void setRoleId(String roleId) {
            this.roleId = roleId;
        }

        public void setRoleKind(Character roleKind) {
            this.roleKind = roleKind;
        }

        public void setRoleName(String roleName) {
            this.roleName = roleName;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("RolesDTO:(");
            buffer.append("roleId:" + this.roleId);
            buffer.append(",roleKind:" + this.roleKind);
            buffer.append(",roleName:" + this.roleName);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.roleId);
            builder.append(this.roleKind);
            builder.append(this.roleName);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.RolesDTO) {
                InnerPbsService.RolesDTO test = (InnerPbsService.RolesDTO)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.roleId, test.roleId);
                builder.append(this.roleKind, test.roleKind);
                builder.append(this.roleName, test.roleName);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class FileDownloadDTO implements Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 100,
                charset = "utf-8"
        )
        private String positionStr = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String menuCode = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String filePath = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String fileName = " ";
        private Integer initDate = 0;
        private Integer modifyTime = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character downStatus = ' ';
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String remark = " ";
        private Integer dateClear = 0;

        public FileDownloadDTO() {
        }

        public String getPositionStr() {
            if (this.positionStr == null) {
                return " ";
            } else {
                return this.positionStr.isEmpty() ? " " : this.positionStr;
            }
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getMenuCode() {
            if (this.menuCode == null) {
                return " ";
            } else {
                return this.menuCode.isEmpty() ? " " : this.menuCode;
            }
        }

        public String getFilePath() {
            if (this.filePath == null) {
                return " ";
            } else {
                return this.filePath.isEmpty() ? " " : this.filePath;
            }
        }

        public String getFileName() {
            if (this.fileName == null) {
                return " ";
            } else {
                return this.fileName.isEmpty() ? " " : this.fileName;
            }
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public Integer getModifyTime() {
            return this.modifyTime != null ? this.modifyTime : 0;
        }

        public Character getDownStatus() {
            return this.downStatus != null ? this.downStatus : ' ';
        }

        public String getRemark() {
            if (this.remark == null) {
                return " ";
            } else {
                return this.remark.isEmpty() ? " " : this.remark;
            }
        }

        public Integer getDateClear() {
            return this.dateClear != null ? this.dateClear : 0;
        }

        public void setPositionStr(String positionStr) {
            this.positionStr = positionStr;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setMenuCode(String menuCode) {
            this.menuCode = menuCode;
        }

        public void setFilePath(String filePath) {
            this.filePath = filePath;
        }

        public void setFileName(String fileName) {
            this.fileName = fileName;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public void setModifyTime(Integer modifyTime) {
            this.modifyTime = modifyTime;
        }

        public void setDownStatus(Character downStatus) {
            this.downStatus = downStatus;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public void setDateClear(Integer dateClear) {
            this.dateClear = dateClear;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("FileDownloadDTO:(");
            buffer.append("positionStr:" + this.positionStr);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",menuCode:" + this.menuCode);
            buffer.append(",filePath:" + this.filePath);
            buffer.append(",fileName:" + this.fileName);
            buffer.append(",initDate:" + this.initDate);
            buffer.append(",modifyTime:" + this.modifyTime);
            buffer.append(",downStatus:" + this.downStatus);
            buffer.append(",remark:" + this.remark);
            buffer.append(",dateClear:" + this.dateClear);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.positionStr);
            builder.append(this.operatorNo);
            builder.append(this.menuCode);
            builder.append(this.filePath);
            builder.append(this.fileName);
            builder.append(this.initDate);
            builder.append(this.modifyTime);
            builder.append(this.downStatus);
            builder.append(this.remark);
            builder.append(this.dateClear);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.FileDownloadDTO) {
                InnerPbsService.FileDownloadDTO test = (InnerPbsService.FileDownloadDTO)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.positionStr, test.positionStr);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.menuCode, test.menuCode);
                builder.append(this.filePath, test.filePath);
                builder.append(this.fileName, test.fileName);
                builder.append(this.initDate, test.initDate);
                builder.append(this.modifyTime, test.modifyTime);
                builder.append(this.downStatus, test.downStatus);
                builder.append(this.remark, test.remark);
                builder.append(this.dateClear, test.dateClear);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class FieldtonameDTO implements Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 180,
                charset = "utf-8"
        )
        private String englishName = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String entryName = " ";
        private Integer dictEntry = 0;

        public FieldtonameDTO() {
        }

        public String getEnglishName() {
            if (this.englishName == null) {
                return " ";
            } else {
                return this.englishName.isEmpty() ? " " : this.englishName;
            }
        }

        public String getEntryName() {
            if (this.entryName == null) {
                return " ";
            } else {
                return this.entryName.isEmpty() ? " " : this.entryName;
            }
        }

        public Integer getDictEntry() {
            return this.dictEntry != null ? this.dictEntry : 0;
        }

        public void setEnglishName(String englishName) {
            this.englishName = englishName;
        }

        public void setEntryName(String entryName) {
            this.entryName = entryName;
        }

        public void setDictEntry(Integer dictEntry) {
            this.dictEntry = dictEntry;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("FieldtonameDTO:(");
            buffer.append("englishName:" + this.englishName);
            buffer.append(",entryName:" + this.entryName);
            buffer.append(",dictEntry:" + this.dictEntry);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.englishName);
            builder.append(this.entryName);
            builder.append(this.dictEntry);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.FieldtonameDTO) {
                InnerPbsService.FieldtonameDTO test = (InnerPbsService.FieldtonameDTO)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.englishName, test.englishName);
                builder.append(this.entryName, test.entryName);
                builder.append(this.dictEntry, test.dictEntry);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class DictionaryOutputDTO implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer branchNo = 0;
        private Integer dictEntry = 0;
        @SinogramLength(
                min = 0,
                max = 8,
                charset = "utf-8"
        )
        private String subEntry = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character dictType = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character accessLevel = ' ';
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String dictPrompt = " ";
        @SinogramLength(
                min = 0,
                max = 8,
                charset = "utf-8"
        )
        private String code = " ";
        @SinogramLength(
                min = 0,
                max = 100,
                charset = "utf-8"
        )
        private String text = " ";
        @SinogramLength(
                min = 0,
                max = 100,
                charset = "utf-8"
        )
        private String enSystemStr = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character dictionaryFlag = ' ';
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String entryName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character manageLevel = ' ';

        public DictionaryOutputDTO() {
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Integer getDictEntry() {
            return this.dictEntry != null ? this.dictEntry : 0;
        }

        public String getSubEntry() {
            if (this.subEntry == null) {
                return " ";
            } else {
                return this.subEntry.isEmpty() ? " " : this.subEntry;
            }
        }

        public Character getDictType() {
            return this.dictType != null ? this.dictType : ' ';
        }

        public Character getAccessLevel() {
            return this.accessLevel != null ? this.accessLevel : ' ';
        }

        public String getDictPrompt() {
            if (this.dictPrompt == null) {
                return " ";
            } else {
                return this.dictPrompt.isEmpty() ? " " : this.dictPrompt;
            }
        }

        public String getCode() {
            if (this.code == null) {
                return " ";
            } else {
                return this.code.isEmpty() ? " " : this.code;
            }
        }

        public String getText() {
            if (this.text == null) {
                return " ";
            } else {
                return this.text.isEmpty() ? " " : this.text;
            }
        }

        public String getEnSystemStr() {
            if (this.enSystemStr == null) {
                return " ";
            } else {
                return this.enSystemStr.isEmpty() ? " " : this.enSystemStr;
            }
        }

        public Character getDictionaryFlag() {
            return this.dictionaryFlag != null ? this.dictionaryFlag : ' ';
        }

        public String getEntryName() {
            if (this.entryName == null) {
                return " ";
            } else {
                return this.entryName.isEmpty() ? " " : this.entryName;
            }
        }

        public Character getManageLevel() {
            return this.manageLevel != null ? this.manageLevel : ' ';
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setDictEntry(Integer dictEntry) {
            this.dictEntry = dictEntry;
        }

        public void setSubEntry(String subEntry) {
            this.subEntry = subEntry;
        }

        public void setDictType(Character dictType) {
            this.dictType = dictType;
        }

        public void setAccessLevel(Character accessLevel) {
            this.accessLevel = accessLevel;
        }

        public void setDictPrompt(String dictPrompt) {
            this.dictPrompt = dictPrompt;
        }

        public void setCode(String code) {
            this.code = code;
        }

        public void setText(String text) {
            this.text = text;
        }

        public void setEnSystemStr(String enSystemStr) {
            this.enSystemStr = enSystemStr;
        }

        public void setDictionaryFlag(Character dictionaryFlag) {
            this.dictionaryFlag = dictionaryFlag;
        }

        public void setEntryName(String entryName) {
            this.entryName = entryName;
        }

        public void setManageLevel(Character manageLevel) {
            this.manageLevel = manageLevel;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("DictionaryOutputDTO:(");
            buffer.append("branchNo:" + this.branchNo);
            buffer.append(",dictEntry:" + this.dictEntry);
            buffer.append(",subEntry:" + this.subEntry);
            buffer.append(",dictType:" + this.dictType);
            buffer.append(",accessLevel:" + this.accessLevel);
            buffer.append(",dictPrompt:" + this.dictPrompt);
            buffer.append(",code:" + this.code);
            buffer.append(",text:" + this.text);
            buffer.append(",enSystemStr:" + this.enSystemStr);
            buffer.append(",dictionaryFlag:" + this.dictionaryFlag);
            buffer.append(",entryName:" + this.entryName);
            buffer.append(",manageLevel:" + this.manageLevel);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.branchNo);
            builder.append(this.dictEntry);
            builder.append(this.subEntry);
            builder.append(this.dictType);
            builder.append(this.accessLevel);
            builder.append(this.dictPrompt);
            builder.append(this.code);
            builder.append(this.text);
            builder.append(this.enSystemStr);
            builder.append(this.dictionaryFlag);
            builder.append(this.entryName);
            builder.append(this.manageLevel);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.DictionaryOutputDTO) {
                InnerPbsService.DictionaryOutputDTO test = (InnerPbsService.DictionaryOutputDTO)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.dictEntry, test.dictEntry);
                builder.append(this.subEntry, test.subEntry);
                builder.append(this.dictType, test.dictType);
                builder.append(this.accessLevel, test.accessLevel);
                builder.append(this.dictPrompt, test.dictPrompt);
                builder.append(this.code, test.code);
                builder.append(this.text, test.text);
                builder.append(this.enSystemStr, test.enSystemStr);
                builder.append(this.dictionaryFlag, test.dictionaryFlag);
                builder.append(this.entryName, test.entryName);
                builder.append(this.manageLevel, test.manageLevel);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class DictEntryDTO implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer dictEntry = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character manageLevel = ' ';
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String entryName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character accessLevel = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character dictType = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character dictKind = ' ';

        public DictEntryDTO() {
        }

        public Integer getDictEntry() {
            return this.dictEntry != null ? this.dictEntry : 0;
        }

        public Character getManageLevel() {
            return this.manageLevel != null ? this.manageLevel : ' ';
        }

        public String getEntryName() {
            if (this.entryName == null) {
                return " ";
            } else {
                return this.entryName.isEmpty() ? " " : this.entryName;
            }
        }

        public Character getAccessLevel() {
            return this.accessLevel != null ? this.accessLevel : ' ';
        }

        public Character getDictType() {
            return this.dictType != null ? this.dictType : ' ';
        }

        public Character getDictKind() {
            return this.dictKind != null ? this.dictKind : ' ';
        }

        public void setDictEntry(Integer dictEntry) {
            this.dictEntry = dictEntry;
        }

        public void setManageLevel(Character manageLevel) {
            this.manageLevel = manageLevel;
        }

        public void setEntryName(String entryName) {
            this.entryName = entryName;
        }

        public void setAccessLevel(Character accessLevel) {
            this.accessLevel = accessLevel;
        }

        public void setDictType(Character dictType) {
            this.dictType = dictType;
        }

        public void setDictKind(Character dictKind) {
            this.dictKind = dictKind;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("DictEntryDTO:(");
            buffer.append("dictEntry:" + this.dictEntry);
            buffer.append(",manageLevel:" + this.manageLevel);
            buffer.append(",entryName:" + this.entryName);
            buffer.append(",accessLevel:" + this.accessLevel);
            buffer.append(",dictType:" + this.dictType);
            buffer.append(",dictKind:" + this.dictKind);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.dictEntry);
            builder.append(this.manageLevel);
            builder.append(this.entryName);
            builder.append(this.accessLevel);
            builder.append(this.dictType);
            builder.append(this.dictKind);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.DictEntryDTO) {
                InnerPbsService.DictEntryDTO test = (InnerPbsService.DictEntryDTO)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.dictEntry, test.dictEntry);
                builder.append(this.manageLevel, test.manageLevel);
                builder.append(this.entryName, test.entryName);
                builder.append(this.accessLevel, test.accessLevel);
                builder.append(this.dictType, test.dictType);
                builder.append(this.dictKind, test.dictKind);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class BusinessFlagDTO implements Serializable {
        private static final long serialVersionUID = 1L;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character borrowLend = ' ';
        private Integer businessFlag = 0;
        @SinogramLength(
                min = 0,
                max = 16,
                charset = "utf-8"
        )
        private String businessGroup = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String businessGroupUser = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character businessKind = ' ';
        @SinogramLength(
                min = 0,
                max = 180,
                charset = "utf-8"
        )
        private String businessName = " ";
        @SinogramLength(
                min = 0,
                max = 8,
                charset = "utf-8"
        )
        private String businessSubject = " ";
        private Integer joinBusinessFlag = 0;

        public BusinessFlagDTO() {
        }

        public Character getBorrowLend() {
            return this.borrowLend != null ? this.borrowLend : ' ';
        }

        public Integer getBusinessFlag() {
            return this.businessFlag != null ? this.businessFlag : 0;
        }

        public String getBusinessGroup() {
            if (this.businessGroup == null) {
                return " ";
            } else {
                return this.businessGroup.isEmpty() ? " " : this.businessGroup;
            }
        }

        public String getBusinessGroupUser() {
            if (this.businessGroupUser == null) {
                return " ";
            } else {
                return this.businessGroupUser.isEmpty() ? " " : this.businessGroupUser;
            }
        }

        public Character getBusinessKind() {
            return this.businessKind != null ? this.businessKind : ' ';
        }

        public String getBusinessName() {
            if (this.businessName == null) {
                return " ";
            } else {
                return this.businessName.isEmpty() ? " " : this.businessName;
            }
        }

        public String getBusinessSubject() {
            if (this.businessSubject == null) {
                return " ";
            } else {
                return this.businessSubject.isEmpty() ? " " : this.businessSubject;
            }
        }

        public Integer getJoinBusinessFlag() {
            return this.joinBusinessFlag != null ? this.joinBusinessFlag : 0;
        }

        public void setBorrowLend(Character borrowLend) {
            this.borrowLend = borrowLend;
        }

        public void setBusinessFlag(Integer businessFlag) {
            this.businessFlag = businessFlag;
        }

        public void setBusinessGroup(String businessGroup) {
            this.businessGroup = businessGroup;
        }

        public void setBusinessGroupUser(String businessGroupUser) {
            this.businessGroupUser = businessGroupUser;
        }

        public void setBusinessKind(Character businessKind) {
            this.businessKind = businessKind;
        }

        public void setBusinessName(String businessName) {
            this.businessName = businessName;
        }

        public void setBusinessSubject(String businessSubject) {
            this.businessSubject = businessSubject;
        }

        public void setJoinBusinessFlag(Integer joinBusinessFlag) {
            this.joinBusinessFlag = joinBusinessFlag;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("BusinessFlagDTO:(");
            buffer.append("borrowLend:" + this.borrowLend);
            buffer.append(",businessFlag:" + this.businessFlag);
            buffer.append(",businessGroup:" + this.businessGroup);
            buffer.append(",businessGroupUser:" + this.businessGroupUser);
            buffer.append(",businessKind:" + this.businessKind);
            buffer.append(",businessName:" + this.businessName);
            buffer.append(",businessSubject:" + this.businessSubject);
            buffer.append(",joinBusinessFlag:" + this.joinBusinessFlag);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.borrowLend);
            builder.append(this.businessFlag);
            builder.append(this.businessGroup);
            builder.append(this.businessGroupUser);
            builder.append(this.businessKind);
            builder.append(this.businessName);
            builder.append(this.businessSubject);
            builder.append(this.joinBusinessFlag);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.BusinessFlagDTO) {
                InnerPbsService.BusinessFlagDTO test = (InnerPbsService.BusinessFlagDTO)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.borrowLend, test.borrowLend);
                builder.append(this.businessFlag, test.businessFlag);
                builder.append(this.businessGroup, test.businessGroup);
                builder.append(this.businessGroupUser, test.businessGroupUser);
                builder.append(this.businessKind, test.businessKind);
                builder.append(this.businessName, test.businessName);
                builder.append(this.businessSubject, test.businessSubject);
                builder.append(this.joinBusinessFlag, test.joinBusinessFlag);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class BranchTreeDTO implements Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 180,
                charset = "utf-8"
        )
        private String address = " ";
        private Integer branchNo = 0;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String branchName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character branchType = ' ';
        private Integer branchZone = 0;
        @SinogramLength(
                min = 0,
                max = 60,
                charset = "utf-8"
        )
        private String contact = " ";
        private Integer dealBranchNo = 0;
        private Integer level1 = 0;
        private Integer level10 = 0;
        private Integer level2 = 0;
        private Integer level3 = 0;
        private Integer level4 = 0;
        private Integer level5 = 0;
        private Integer level6 = 0;
        private Integer level7 = 0;
        private Integer level8 = 0;
        private Integer level9 = 0;
        @SinogramLength(
                min = 0,
                max = 10,
                charset = "utf-8"
        )
        private String localNo = " ";
        private Integer manageBranchNo = 0;
        private Integer sysnodeId = 0;
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String telephone = " ";
        private Integer treeLevel = 0;
        private Integer upBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 10,
                charset = "utf-8"
        )
        private String opennetCode = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String branchCtrlstr = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character branchKind = ' ';
        private Integer companyNo = 0;
        private Integer branchGroup = 0;
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String title = " ";
        @Valid
        private List<InnerPbsService.BranchTreeDTO> children = new ArrayList();

        public BranchTreeDTO() {
        }

        public String getAddress() {
            if (this.address == null) {
                return " ";
            } else {
                return this.address.isEmpty() ? " " : this.address;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getBranchName() {
            if (this.branchName == null) {
                return " ";
            } else {
                return this.branchName.isEmpty() ? " " : this.branchName;
            }
        }

        public Character getBranchType() {
            return this.branchType != null ? this.branchType : ' ';
        }

        public Integer getBranchZone() {
            return this.branchZone != null ? this.branchZone : 0;
        }

        public String getContact() {
            if (this.contact == null) {
                return " ";
            } else {
                return this.contact.isEmpty() ? " " : this.contact;
            }
        }

        public Integer getDealBranchNo() {
            return this.dealBranchNo != null ? this.dealBranchNo : 0;
        }

        public Integer getLevel1() {
            return this.level1 != null ? this.level1 : 0;
        }

        public Integer getLevel10() {
            return this.level10 != null ? this.level10 : 0;
        }

        public Integer getLevel2() {
            return this.level2 != null ? this.level2 : 0;
        }

        public Integer getLevel3() {
            return this.level3 != null ? this.level3 : 0;
        }

        public Integer getLevel4() {
            return this.level4 != null ? this.level4 : 0;
        }

        public Integer getLevel5() {
            return this.level5 != null ? this.level5 : 0;
        }

        public Integer getLevel6() {
            return this.level6 != null ? this.level6 : 0;
        }

        public Integer getLevel7() {
            return this.level7 != null ? this.level7 : 0;
        }

        public Integer getLevel8() {
            return this.level8 != null ? this.level8 : 0;
        }

        public Integer getLevel9() {
            return this.level9 != null ? this.level9 : 0;
        }

        public String getLocalNo() {
            if (this.localNo == null) {
                return " ";
            } else {
                return this.localNo.isEmpty() ? " " : this.localNo;
            }
        }

        public Integer getManageBranchNo() {
            return this.manageBranchNo != null ? this.manageBranchNo : 0;
        }

        public Integer getSysnodeId() {
            return this.sysnodeId != null ? this.sysnodeId : 0;
        }

        public String getTelephone() {
            if (this.telephone == null) {
                return " ";
            } else {
                return this.telephone.isEmpty() ? " " : this.telephone;
            }
        }

        public Integer getTreeLevel() {
            return this.treeLevel != null ? this.treeLevel : 0;
        }

        public Integer getUpBranchNo() {
            return this.upBranchNo != null ? this.upBranchNo : 0;
        }

        public String getOpennetCode() {
            if (this.opennetCode == null) {
                return " ";
            } else {
                return this.opennetCode.isEmpty() ? " " : this.opennetCode;
            }
        }

        public String getBranchCtrlstr() {
            if (this.branchCtrlstr == null) {
                return " ";
            } else {
                return this.branchCtrlstr.isEmpty() ? " " : this.branchCtrlstr;
            }
        }

        public Character getBranchKind() {
            return this.branchKind != null ? this.branchKind : ' ';
        }

        public Integer getCompanyNo() {
            return this.companyNo != null ? this.companyNo : 0;
        }

        public Integer getBranchGroup() {
            return this.branchGroup != null ? this.branchGroup : 0;
        }

        public String getTitle() {
            if (this.title == null) {
                return " ";
            } else {
                return this.title.isEmpty() ? " " : this.title;
            }
        }

        public List<InnerPbsService.BranchTreeDTO> getChildren() {
            return (List)(this.children != null ? this.children : new ArrayList());
        }

        public void setAddress(String address) {
            this.address = address;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setBranchName(String branchName) {
            this.branchName = branchName;
        }

        public void setBranchType(Character branchType) {
            this.branchType = branchType;
        }

        public void setBranchZone(Integer branchZone) {
            this.branchZone = branchZone;
        }

        public void setContact(String contact) {
            this.contact = contact;
        }

        public void setDealBranchNo(Integer dealBranchNo) {
            this.dealBranchNo = dealBranchNo;
        }

        public void setLevel1(Integer level1) {
            this.level1 = level1;
        }

        public void setLevel10(Integer level10) {
            this.level10 = level10;
        }

        public void setLevel2(Integer level2) {
            this.level2 = level2;
        }

        public void setLevel3(Integer level3) {
            this.level3 = level3;
        }

        public void setLevel4(Integer level4) {
            this.level4 = level4;
        }

        public void setLevel5(Integer level5) {
            this.level5 = level5;
        }

        public void setLevel6(Integer level6) {
            this.level6 = level6;
        }

        public void setLevel7(Integer level7) {
            this.level7 = level7;
        }

        public void setLevel8(Integer level8) {
            this.level8 = level8;
        }

        public void setLevel9(Integer level9) {
            this.level9 = level9;
        }

        public void setLocalNo(String localNo) {
            this.localNo = localNo;
        }

        public void setManageBranchNo(Integer manageBranchNo) {
            this.manageBranchNo = manageBranchNo;
        }

        public void setSysnodeId(Integer sysnodeId) {
            this.sysnodeId = sysnodeId;
        }

        public void setTelephone(String telephone) {
            this.telephone = telephone;
        }

        public void setTreeLevel(Integer treeLevel) {
            this.treeLevel = treeLevel;
        }

        public void setUpBranchNo(Integer upBranchNo) {
            this.upBranchNo = upBranchNo;
        }

        public void setOpennetCode(String opennetCode) {
            this.opennetCode = opennetCode;
        }

        public void setBranchCtrlstr(String branchCtrlstr) {
            this.branchCtrlstr = branchCtrlstr;
        }

        public void setBranchKind(Character branchKind) {
            this.branchKind = branchKind;
        }

        public void setCompanyNo(Integer companyNo) {
            this.companyNo = companyNo;
        }

        public void setBranchGroup(Integer branchGroup) {
            this.branchGroup = branchGroup;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public void setChildren(List<InnerPbsService.BranchTreeDTO> children) {
            this.children = children;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("BranchTreeDTO:(");
            buffer.append("address:" + this.address);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",branchName:" + this.branchName);
            buffer.append(",branchType:" + this.branchType);
            buffer.append(",branchZone:" + this.branchZone);
            buffer.append(",contact:" + this.contact);
            buffer.append(",dealBranchNo:" + this.dealBranchNo);
            buffer.append(",level1:" + this.level1);
            buffer.append(",level10:" + this.level10);
            buffer.append(",level2:" + this.level2);
            buffer.append(",level3:" + this.level3);
            buffer.append(",level4:" + this.level4);
            buffer.append(",level5:" + this.level5);
            buffer.append(",level6:" + this.level6);
            buffer.append(",level7:" + this.level7);
            buffer.append(",level8:" + this.level8);
            buffer.append(",level9:" + this.level9);
            buffer.append(",localNo:" + this.localNo);
            buffer.append(",manageBranchNo:" + this.manageBranchNo);
            buffer.append(",sysnodeId:" + this.sysnodeId);
            buffer.append(",telephone:" + this.telephone);
            buffer.append(",treeLevel:" + this.treeLevel);
            buffer.append(",upBranchNo:" + this.upBranchNo);
            buffer.append(",opennetCode:" + this.opennetCode);
            buffer.append(",branchCtrlstr:" + this.branchCtrlstr);
            buffer.append(",branchKind:" + this.branchKind);
            buffer.append(",companyNo:" + this.companyNo);
            buffer.append(",branchGroup:" + this.branchGroup);
            buffer.append(",title:" + this.title);
            buffer.append(",children:" + this.children);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.address);
            builder.append(this.branchNo);
            builder.append(this.branchName);
            builder.append(this.branchType);
            builder.append(this.branchZone);
            builder.append(this.contact);
            builder.append(this.dealBranchNo);
            builder.append(this.level1);
            builder.append(this.level10);
            builder.append(this.level2);
            builder.append(this.level3);
            builder.append(this.level4);
            builder.append(this.level5);
            builder.append(this.level6);
            builder.append(this.level7);
            builder.append(this.level8);
            builder.append(this.level9);
            builder.append(this.localNo);
            builder.append(this.manageBranchNo);
            builder.append(this.sysnodeId);
            builder.append(this.telephone);
            builder.append(this.treeLevel);
            builder.append(this.upBranchNo);
            builder.append(this.opennetCode);
            builder.append(this.branchCtrlstr);
            builder.append(this.branchKind);
            builder.append(this.companyNo);
            builder.append(this.branchGroup);
            builder.append(this.title);
            builder.append(this.children);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.BranchTreeDTO) {
                InnerPbsService.BranchTreeDTO test = (InnerPbsService.BranchTreeDTO)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.address, test.address);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.branchName, test.branchName);
                builder.append(this.branchType, test.branchType);
                builder.append(this.branchZone, test.branchZone);
                builder.append(this.contact, test.contact);
                builder.append(this.dealBranchNo, test.dealBranchNo);
                builder.append(this.level1, test.level1);
                builder.append(this.level10, test.level10);
                builder.append(this.level2, test.level2);
                builder.append(this.level3, test.level3);
                builder.append(this.level4, test.level4);
                builder.append(this.level5, test.level5);
                builder.append(this.level6, test.level6);
                builder.append(this.level7, test.level7);
                builder.append(this.level8, test.level8);
                builder.append(this.level9, test.level9);
                builder.append(this.localNo, test.localNo);
                builder.append(this.manageBranchNo, test.manageBranchNo);
                builder.append(this.sysnodeId, test.sysnodeId);
                builder.append(this.telephone, test.telephone);
                builder.append(this.treeLevel, test.treeLevel);
                builder.append(this.upBranchNo, test.upBranchNo);
                builder.append(this.opennetCode, test.opennetCode);
                builder.append(this.branchCtrlstr, test.branchCtrlstr);
                builder.append(this.branchKind, test.branchKind);
                builder.append(this.companyNo, test.companyNo);
                builder.append(this.branchGroup, test.branchGroup);
                builder.append(this.title, test.title);
                builder.append(this.children, test.children);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class AllCompanyInUsingDTO implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer companyNo = 0;
        @SinogramLength(
                min = 0,
                max = 24,
                charset = "utf-8"
        )
        private String companyCode = " ";
        @SinogramLength(
                min = 0,
                max = 180,
                charset = "utf-8"
        )
        private String companyName = " ";
        @SinogramLength(
                min = 0,
                max = 180,
                charset = "utf-8"
        )
        private String companyfullName = " ";

        public AllCompanyInUsingDTO() {
        }

        public Integer getCompanyNo() {
            return this.companyNo != null ? this.companyNo : 0;
        }

        public String getCompanyCode() {
            if (this.companyCode == null) {
                return " ";
            } else {
                return this.companyCode.isEmpty() ? " " : this.companyCode;
            }
        }

        public String getCompanyName() {
            if (this.companyName == null) {
                return " ";
            } else {
                return this.companyName.isEmpty() ? " " : this.companyName;
            }
        }

        public String getCompanyfullName() {
            if (this.companyfullName == null) {
                return " ";
            } else {
                return this.companyfullName.isEmpty() ? " " : this.companyfullName;
            }
        }

        public void setCompanyNo(Integer companyNo) {
            this.companyNo = companyNo;
        }

        public void setCompanyCode(String companyCode) {
            this.companyCode = companyCode;
        }

        public void setCompanyName(String companyName) {
            this.companyName = companyName;
        }

        public void setCompanyfullName(String companyfullName) {
            this.companyfullName = companyfullName;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("AllCompanyInUsingDTO:(");
            buffer.append("companyNo:" + this.companyNo);
            buffer.append(",companyCode:" + this.companyCode);
            buffer.append(",companyName:" + this.companyName);
            buffer.append(",companyfullName:" + this.companyfullName);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.companyNo);
            builder.append(this.companyCode);
            builder.append(this.companyName);
            builder.append(this.companyfullName);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.AllCompanyInUsingDTO) {
                InnerPbsService.AllCompanyInUsingDTO test = (InnerPbsService.AllCompanyInUsingDTO)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.companyNo, test.companyNo);
                builder.append(this.companyCode, test.companyCode);
                builder.append(this.companyName, test.companyName);
                builder.append(this.companyfullName, test.companyfullName);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class AllBranchDTO implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer branchNo = 0;
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String orgCode = " ";
        @SinogramLength(
                min = 0,
                max = 8,
                charset = "utf-8"
        )
        private String dimension = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String branchName = " ";
        private Integer upBranchNo = 0;
        private Integer sysnodeId = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character branchType = ' ';
        private Integer branchZone = 0;
        private Integer companyNo = 0;
        private Integer treeLevel = 0;
        @SinogramLength(
                min = 0,
                max = 10,
                charset = "utf-8"
        )
        private String localNo = " ";
        @SinogramLength(
                min = 0,
                max = 8,
                charset = "utf-8"
        )
        private String csrcCode = " ";
        @SinogramLength(
                min = 0,
                max = 60,
                charset = "utf-8"
        )
        private String contact = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String telephone = " ";
        @SinogramLength(
                min = 0,
                max = 6,
                charset = "utf-8"
        )
        private String zipcode = " ";
        @SinogramLength(
                min = 0,
                max = 180,
                charset = "utf-8"
        )
        private String address = " ";
        private Integer level1 = 0;
        private Integer level2 = 0;
        private Integer level3 = 0;
        private Integer level4 = 0;
        private Integer level5 = 0;
        private Integer level6 = 0;
        private Integer level7 = 0;
        private Integer level8 = 0;
        private Integer level9 = 0;
        private Integer level10 = 0;
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String branchCtrlstr = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String cmccId = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String exchId = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String eMail = " ";
        private Integer organSysnodeId = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character branchKind = ' ';
        @SinogramLength(
                min = 0,
                max = 16,
                charset = "utf-8"
        )
        private String provinceCode = " ";
        @SinogramLength(
                min = 0,
                max = 16,
                charset = "utf-8"
        )
        private String cityCode = " ";
        @SinogramLength(
                min = 0,
                max = 10,
                charset = "utf-8"
        )
        private String opennetCode = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character addFlag = ' ';
        private Integer manageBranchNo = 0;
        private Integer dealBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 100,
                charset = "utf-8"
        )
        private String positionStr = " ";
        @SinogramLength(
                min = 0,
                max = 128,
                charset = "utf-8"
        )
        private String sysOnlineFlag = " ";
        private Integer branchGroup = 0;

        public AllBranchDTO() {
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getOrgCode() {
            if (this.orgCode == null) {
                return " ";
            } else {
                return this.orgCode.isEmpty() ? " " : this.orgCode;
            }
        }

        public String getDimension() {
            if (this.dimension == null) {
                return " ";
            } else {
                return this.dimension.isEmpty() ? " " : this.dimension;
            }
        }

        public String getBranchName() {
            if (this.branchName == null) {
                return " ";
            } else {
                return this.branchName.isEmpty() ? " " : this.branchName;
            }
        }

        public Integer getUpBranchNo() {
            return this.upBranchNo != null ? this.upBranchNo : 0;
        }

        public Integer getSysnodeId() {
            return this.sysnodeId != null ? this.sysnodeId : 0;
        }

        public Character getBranchType() {
            return this.branchType != null ? this.branchType : ' ';
        }

        public Integer getBranchZone() {
            return this.branchZone != null ? this.branchZone : 0;
        }

        public Integer getCompanyNo() {
            return this.companyNo != null ? this.companyNo : 0;
        }

        public Integer getTreeLevel() {
            return this.treeLevel != null ? this.treeLevel : 0;
        }

        public String getLocalNo() {
            if (this.localNo == null) {
                return " ";
            } else {
                return this.localNo.isEmpty() ? " " : this.localNo;
            }
        }

        public String getCsrcCode() {
            if (this.csrcCode == null) {
                return " ";
            } else {
                return this.csrcCode.isEmpty() ? " " : this.csrcCode;
            }
        }

        public String getContact() {
            if (this.contact == null) {
                return " ";
            } else {
                return this.contact.isEmpty() ? " " : this.contact;
            }
        }

        public String getTelephone() {
            if (this.telephone == null) {
                return " ";
            } else {
                return this.telephone.isEmpty() ? " " : this.telephone;
            }
        }

        public String getZipcode() {
            if (this.zipcode == null) {
                return " ";
            } else {
                return this.zipcode.isEmpty() ? " " : this.zipcode;
            }
        }

        public String getAddress() {
            if (this.address == null) {
                return " ";
            } else {
                return this.address.isEmpty() ? " " : this.address;
            }
        }

        public Integer getLevel1() {
            return this.level1 != null ? this.level1 : 0;
        }

        public Integer getLevel2() {
            return this.level2 != null ? this.level2 : 0;
        }

        public Integer getLevel3() {
            return this.level3 != null ? this.level3 : 0;
        }

        public Integer getLevel4() {
            return this.level4 != null ? this.level4 : 0;
        }

        public Integer getLevel5() {
            return this.level5 != null ? this.level5 : 0;
        }

        public Integer getLevel6() {
            return this.level6 != null ? this.level6 : 0;
        }

        public Integer getLevel7() {
            return this.level7 != null ? this.level7 : 0;
        }

        public Integer getLevel8() {
            return this.level8 != null ? this.level8 : 0;
        }

        public Integer getLevel9() {
            return this.level9 != null ? this.level9 : 0;
        }

        public Integer getLevel10() {
            return this.level10 != null ? this.level10 : 0;
        }

        public String getBranchCtrlstr() {
            if (this.branchCtrlstr == null) {
                return " ";
            } else {
                return this.branchCtrlstr.isEmpty() ? " " : this.branchCtrlstr;
            }
        }

        public String getCmccId() {
            if (this.cmccId == null) {
                return " ";
            } else {
                return this.cmccId.isEmpty() ? " " : this.cmccId;
            }
        }

        public String getExchId() {
            if (this.exchId == null) {
                return " ";
            } else {
                return this.exchId.isEmpty() ? " " : this.exchId;
            }
        }

        public String geteMail() {
            if (this.eMail == null) {
                return " ";
            } else {
                return this.eMail.isEmpty() ? " " : this.eMail;
            }
        }

        public Integer getOrganSysnodeId() {
            return this.organSysnodeId != null ? this.organSysnodeId : 0;
        }

        public Character getBranchKind() {
            return this.branchKind != null ? this.branchKind : ' ';
        }

        public String getProvinceCode() {
            if (this.provinceCode == null) {
                return " ";
            } else {
                return this.provinceCode.isEmpty() ? " " : this.provinceCode;
            }
        }

        public String getCityCode() {
            if (this.cityCode == null) {
                return " ";
            } else {
                return this.cityCode.isEmpty() ? " " : this.cityCode;
            }
        }

        public String getOpennetCode() {
            if (this.opennetCode == null) {
                return " ";
            } else {
                return this.opennetCode.isEmpty() ? " " : this.opennetCode;
            }
        }

        public Character getAddFlag() {
            return this.addFlag != null ? this.addFlag : ' ';
        }

        public Integer getManageBranchNo() {
            return this.manageBranchNo != null ? this.manageBranchNo : 0;
        }

        public Integer getDealBranchNo() {
            return this.dealBranchNo != null ? this.dealBranchNo : 0;
        }

        public String getPositionStr() {
            if (this.positionStr == null) {
                return " ";
            } else {
                return this.positionStr.isEmpty() ? " " : this.positionStr;
            }
        }

        public String getSysOnlineFlag() {
            if (this.sysOnlineFlag == null) {
                return " ";
            } else {
                return this.sysOnlineFlag.isEmpty() ? " " : this.sysOnlineFlag;
            }
        }

        public Integer getBranchGroup() {
            return this.branchGroup != null ? this.branchGroup : 0;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setOrgCode(String orgCode) {
            this.orgCode = orgCode;
        }

        public void setDimension(String dimension) {
            this.dimension = dimension;
        }

        public void setBranchName(String branchName) {
            this.branchName = branchName;
        }

        public void setUpBranchNo(Integer upBranchNo) {
            this.upBranchNo = upBranchNo;
        }

        public void setSysnodeId(Integer sysnodeId) {
            this.sysnodeId = sysnodeId;
        }

        public void setBranchType(Character branchType) {
            this.branchType = branchType;
        }

        public void setBranchZone(Integer branchZone) {
            this.branchZone = branchZone;
        }

        public void setCompanyNo(Integer companyNo) {
            this.companyNo = companyNo;
        }

        public void setTreeLevel(Integer treeLevel) {
            this.treeLevel = treeLevel;
        }

        public void setLocalNo(String localNo) {
            this.localNo = localNo;
        }

        public void setCsrcCode(String csrcCode) {
            this.csrcCode = csrcCode;
        }

        public void setContact(String contact) {
            this.contact = contact;
        }

        public void setTelephone(String telephone) {
            this.telephone = telephone;
        }

        public void setZipcode(String zipcode) {
            this.zipcode = zipcode;
        }

        public void setAddress(String address) {
            this.address = address;
        }

        public void setLevel1(Integer level1) {
            this.level1 = level1;
        }

        public void setLevel2(Integer level2) {
            this.level2 = level2;
        }

        public void setLevel3(Integer level3) {
            this.level3 = level3;
        }

        public void setLevel4(Integer level4) {
            this.level4 = level4;
        }

        public void setLevel5(Integer level5) {
            this.level5 = level5;
        }

        public void setLevel6(Integer level6) {
            this.level6 = level6;
        }

        public void setLevel7(Integer level7) {
            this.level7 = level7;
        }

        public void setLevel8(Integer level8) {
            this.level8 = level8;
        }

        public void setLevel9(Integer level9) {
            this.level9 = level9;
        }

        public void setLevel10(Integer level10) {
            this.level10 = level10;
        }

        public void setBranchCtrlstr(String branchCtrlstr) {
            this.branchCtrlstr = branchCtrlstr;
        }

        public void setCmccId(String cmccId) {
            this.cmccId = cmccId;
        }

        public void setExchId(String exchId) {
            this.exchId = exchId;
        }

        public void seteMail(String eMail) {
            this.eMail = eMail;
        }

        public void setOrganSysnodeId(Integer organSysnodeId) {
            this.organSysnodeId = organSysnodeId;
        }

        public void setBranchKind(Character branchKind) {
            this.branchKind = branchKind;
        }

        public void setProvinceCode(String provinceCode) {
            this.provinceCode = provinceCode;
        }

        public void setCityCode(String cityCode) {
            this.cityCode = cityCode;
        }

        public void setOpennetCode(String opennetCode) {
            this.opennetCode = opennetCode;
        }

        public void setAddFlag(Character addFlag) {
            this.addFlag = addFlag;
        }

        public void setManageBranchNo(Integer manageBranchNo) {
            this.manageBranchNo = manageBranchNo;
        }

        public void setDealBranchNo(Integer dealBranchNo) {
            this.dealBranchNo = dealBranchNo;
        }

        public void setPositionStr(String positionStr) {
            this.positionStr = positionStr;
        }

        public void setSysOnlineFlag(String sysOnlineFlag) {
            this.sysOnlineFlag = sysOnlineFlag;
        }

        public void setBranchGroup(Integer branchGroup) {
            this.branchGroup = branchGroup;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("AllBranchDTO:(");
            buffer.append("branchNo:" + this.branchNo);
            buffer.append(",orgCode:" + this.orgCode);
            buffer.append(",dimension:" + this.dimension);
            buffer.append(",branchName:" + this.branchName);
            buffer.append(",upBranchNo:" + this.upBranchNo);
            buffer.append(",sysnodeId:" + this.sysnodeId);
            buffer.append(",branchType:" + this.branchType);
            buffer.append(",branchZone:" + this.branchZone);
            buffer.append(",companyNo:" + this.companyNo);
            buffer.append(",treeLevel:" + this.treeLevel);
            buffer.append(",localNo:" + this.localNo);
            buffer.append(",csrcCode:" + this.csrcCode);
            buffer.append(",contact:" + this.contact);
            buffer.append(",telephone:" + this.telephone);
            buffer.append(",zipcode:" + this.zipcode);
            buffer.append(",address:" + this.address);
            buffer.append(",level1:" + this.level1);
            buffer.append(",level2:" + this.level2);
            buffer.append(",level3:" + this.level3);
            buffer.append(",level4:" + this.level4);
            buffer.append(",level5:" + this.level5);
            buffer.append(",level6:" + this.level6);
            buffer.append(",level7:" + this.level7);
            buffer.append(",level8:" + this.level8);
            buffer.append(",level9:" + this.level9);
            buffer.append(",level10:" + this.level10);
            buffer.append(",branchCtrlstr:" + this.branchCtrlstr);
            buffer.append(",cmccId:" + this.cmccId);
            buffer.append(",exchId:" + this.exchId);
            buffer.append(",eMail:" + this.eMail);
            buffer.append(",organSysnodeId:" + this.organSysnodeId);
            buffer.append(",branchKind:" + this.branchKind);
            buffer.append(",provinceCode:" + this.provinceCode);
            buffer.append(",cityCode:" + this.cityCode);
            buffer.append(",opennetCode:" + this.opennetCode);
            buffer.append(",addFlag:" + this.addFlag);
            buffer.append(",manageBranchNo:" + this.manageBranchNo);
            buffer.append(",dealBranchNo:" + this.dealBranchNo);
            buffer.append(",positionStr:" + this.positionStr);
            buffer.append(",sysOnlineFlag:" + this.sysOnlineFlag);
            buffer.append(",branchGroup:" + this.branchGroup);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.branchNo);
            builder.append(this.orgCode);
            builder.append(this.dimension);
            builder.append(this.branchName);
            builder.append(this.upBranchNo);
            builder.append(this.sysnodeId);
            builder.append(this.branchType);
            builder.append(this.branchZone);
            builder.append(this.companyNo);
            builder.append(this.treeLevel);
            builder.append(this.localNo);
            builder.append(this.csrcCode);
            builder.append(this.contact);
            builder.append(this.telephone);
            builder.append(this.zipcode);
            builder.append(this.address);
            builder.append(this.level1);
            builder.append(this.level2);
            builder.append(this.level3);
            builder.append(this.level4);
            builder.append(this.level5);
            builder.append(this.level6);
            builder.append(this.level7);
            builder.append(this.level8);
            builder.append(this.level9);
            builder.append(this.level10);
            builder.append(this.branchCtrlstr);
            builder.append(this.cmccId);
            builder.append(this.exchId);
            builder.append(this.eMail);
            builder.append(this.organSysnodeId);
            builder.append(this.branchKind);
            builder.append(this.provinceCode);
            builder.append(this.cityCode);
            builder.append(this.opennetCode);
            builder.append(this.addFlag);
            builder.append(this.manageBranchNo);
            builder.append(this.dealBranchNo);
            builder.append(this.positionStr);
            builder.append(this.sysOnlineFlag);
            builder.append(this.branchGroup);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.AllBranchDTO) {
                InnerPbsService.AllBranchDTO test = (InnerPbsService.AllBranchDTO)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.orgCode, test.orgCode);
                builder.append(this.dimension, test.dimension);
                builder.append(this.branchName, test.branchName);
                builder.append(this.upBranchNo, test.upBranchNo);
                builder.append(this.sysnodeId, test.sysnodeId);
                builder.append(this.branchType, test.branchType);
                builder.append(this.branchZone, test.branchZone);
                builder.append(this.companyNo, test.companyNo);
                builder.append(this.treeLevel, test.treeLevel);
                builder.append(this.localNo, test.localNo);
                builder.append(this.csrcCode, test.csrcCode);
                builder.append(this.contact, test.contact);
                builder.append(this.telephone, test.telephone);
                builder.append(this.zipcode, test.zipcode);
                builder.append(this.address, test.address);
                builder.append(this.level1, test.level1);
                builder.append(this.level2, test.level2);
                builder.append(this.level3, test.level3);
                builder.append(this.level4, test.level4);
                builder.append(this.level5, test.level5);
                builder.append(this.level6, test.level6);
                builder.append(this.level7, test.level7);
                builder.append(this.level8, test.level8);
                builder.append(this.level9, test.level9);
                builder.append(this.level10, test.level10);
                builder.append(this.branchCtrlstr, test.branchCtrlstr);
                builder.append(this.cmccId, test.cmccId);
                builder.append(this.exchId, test.exchId);
                builder.append(this.eMail, test.eMail);
                builder.append(this.organSysnodeId, test.organSysnodeId);
                builder.append(this.branchKind, test.branchKind);
                builder.append(this.provinceCode, test.provinceCode);
                builder.append(this.cityCode, test.cityCode);
                builder.append(this.opennetCode, test.opennetCode);
                builder.append(this.addFlag, test.addFlag);
                builder.append(this.manageBranchNo, test.manageBranchNo);
                builder.append(this.dealBranchNo, test.dealBranchNo);
                builder.append(this.positionStr, test.positionStr);
                builder.append(this.sysOnlineFlag, test.sysOnlineFlag);
                builder.append(this.branchGroup, test.branchGroup);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutUserPasswordInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String returnCode = " ";
        private String returnInfo = " ";

        public PutUserPasswordInnerOutput() {
        }

        public String getReturnCode() {
            if (this.returnCode == null) {
                return " ";
            } else {
                return this.returnCode.isEmpty() ? " " : this.returnCode;
            }
        }

        public String getReturnInfo() {
            if (this.returnInfo == null) {
                return " ";
            } else {
                return this.returnInfo.isEmpty() ? " " : this.returnInfo;
            }
        }

        public void setReturnCode(String returnCode) {
            this.returnCode = returnCode;
        }

        public void setReturnInfo(String returnInfo) {
            this.returnInfo = returnInfo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutUserPasswordInnerOutput:(");
            buffer.append("returnCode:" + this.returnCode);
            buffer.append(",returnInfo:" + this.returnInfo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.returnCode);
            builder.append(this.returnInfo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.PutUserPasswordInnerOutput) {
                InnerPbsService.PutUserPasswordInnerOutput test = (InnerPbsService.PutUserPasswordInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.returnCode, test.returnCode);
                builder.append(this.returnInfo, test.returnInfo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutUserPasswordInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String oldPassword = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String newPassword = " ";

        public PutUserPasswordInnerInput() {
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOldPassword() {
            if (this.oldPassword == null) {
                return " ";
            } else {
                return this.oldPassword.isEmpty() ? " " : this.oldPassword;
            }
        }

        public String getNewPassword() {
            if (this.newPassword == null) {
                return " ";
            } else {
                return this.newPassword.isEmpty() ? " " : this.newPassword;
            }
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOldPassword(String oldPassword) {
            this.oldPassword = oldPassword;
        }

        public void setNewPassword(String newPassword) {
            this.newPassword = newPassword;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutUserPasswordInnerInput:(");
            buffer.append("operatorNo:" + this.operatorNo);
            buffer.append(",oldPassword:" + this.oldPassword);
            buffer.append(",newPassword:" + this.newPassword);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.operatorNo);
            builder.append(this.oldPassword);
            builder.append(this.newPassword);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.PutUserPasswordInnerInput) {
                InnerPbsService.PutUserPasswordInnerInput test = (InnerPbsService.PutUserPasswordInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.oldPassword, test.oldPassword);
                builder.append(this.newPassword, test.newPassword);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutUserInfoInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String returnCode = " ";
        private String returnInfo = " ";

        public PutUserInfoInnerOutput() {
        }

        public String getReturnCode() {
            if (this.returnCode == null) {
                return " ";
            } else {
                return this.returnCode.isEmpty() ? " " : this.returnCode;
            }
        }

        public String getReturnInfo() {
            if (this.returnInfo == null) {
                return " ";
            } else {
                return this.returnInfo.isEmpty() ? " " : this.returnInfo;
            }
        }

        public void setReturnCode(String returnCode) {
            this.returnCode = returnCode;
        }

        public void setReturnInfo(String returnInfo) {
            this.returnInfo = returnInfo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutUserInfoInnerOutput:(");
            buffer.append("returnCode:" + this.returnCode);
            buffer.append(",returnInfo:" + this.returnInfo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.returnCode);
            builder.append(this.returnInfo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.PutUserInfoInnerOutput) {
                InnerPbsService.PutUserInfoInnerOutput test = (InnerPbsService.PutUserInfoInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.returnCode, test.returnCode);
                builder.append(this.returnInfo, test.returnInfo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutUserInfoInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String userId = " ";
        @SinogramLength(
                min = 0,
                max = 180,
                charset = "utf-8"
        )
        private String userName = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String userPassword = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character userType = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character userStatus = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String branchName = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String mobile = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String phone = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String fax = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String email = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character idKind = ' ';
        @SinogramLength(
                min = 0,
                max = 40,
                charset = "utf-8"
        )
        private String idNo = " ";
        @SinogramLength(
                min = 0,
                max = 40,
                charset = "utf-8"
        )
        private String qualifyNo = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character operStatus = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character messageType = ' ';
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String remark = " ";

        public PutUserInfoInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getUserId() {
            if (this.userId == null) {
                return " ";
            } else {
                return this.userId.isEmpty() ? " " : this.userId;
            }
        }

        public String getUserName() {
            if (this.userName == null) {
                return " ";
            } else {
                return this.userName.isEmpty() ? " " : this.userName;
            }
        }

        public String getUserPassword() {
            if (this.userPassword == null) {
                return " ";
            } else {
                return this.userPassword.isEmpty() ? " " : this.userPassword;
            }
        }

        public Character getUserType() {
            return this.userType != null ? this.userType : ' ';
        }

        public Character getUserStatus() {
            return this.userStatus != null ? this.userStatus : ' ';
        }

        public String getBranchName() {
            if (this.branchName == null) {
                return " ";
            } else {
                return this.branchName.isEmpty() ? " " : this.branchName;
            }
        }

        public String getMobile() {
            if (this.mobile == null) {
                return " ";
            } else {
                return this.mobile.isEmpty() ? " " : this.mobile;
            }
        }

        public String getPhone() {
            if (this.phone == null) {
                return " ";
            } else {
                return this.phone.isEmpty() ? " " : this.phone;
            }
        }

        public String getFax() {
            if (this.fax == null) {
                return " ";
            } else {
                return this.fax.isEmpty() ? " " : this.fax;
            }
        }

        public String getEmail() {
            if (this.email == null) {
                return " ";
            } else {
                return this.email.isEmpty() ? " " : this.email;
            }
        }

        public Character getIdKind() {
            return this.idKind != null ? this.idKind : ' ';
        }

        public String getIdNo() {
            if (this.idNo == null) {
                return " ";
            } else {
                return this.idNo.isEmpty() ? " " : this.idNo;
            }
        }

        public String getQualifyNo() {
            if (this.qualifyNo == null) {
                return " ";
            } else {
                return this.qualifyNo.isEmpty() ? " " : this.qualifyNo;
            }
        }

        public Character getOperStatus() {
            return this.operStatus != null ? this.operStatus : ' ';
        }

        public Character getMessageType() {
            return this.messageType != null ? this.messageType : ' ';
        }

        public String getRemark() {
            if (this.remark == null) {
                return " ";
            } else {
                return this.remark.isEmpty() ? " " : this.remark;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setUserId(String userId) {
            this.userId = userId;
        }

        public void setUserName(String userName) {
            this.userName = userName;
        }

        public void setUserPassword(String userPassword) {
            this.userPassword = userPassword;
        }

        public void setUserType(Character userType) {
            this.userType = userType;
        }

        public void setUserStatus(Character userStatus) {
            this.userStatus = userStatus;
        }

        public void setBranchName(String branchName) {
            this.branchName = branchName;
        }

        public void setMobile(String mobile) {
            this.mobile = mobile;
        }

        public void setPhone(String phone) {
            this.phone = phone;
        }

        public void setFax(String fax) {
            this.fax = fax;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        public void setIdKind(Character idKind) {
            this.idKind = idKind;
        }

        public void setIdNo(String idNo) {
            this.idNo = idNo;
        }

        public void setQualifyNo(String qualifyNo) {
            this.qualifyNo = qualifyNo;
        }

        public void setOperStatus(Character operStatus) {
            this.operStatus = operStatus;
        }

        public void setMessageType(Character messageType) {
            this.messageType = messageType;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutUserInfoInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",userId:" + this.userId);
            buffer.append(",userName:" + this.userName);
            buffer.append(",userPassword:" + this.userPassword);
            buffer.append(",userType:" + this.userType);
            buffer.append(",userStatus:" + this.userStatus);
            buffer.append(",branchName:" + this.branchName);
            buffer.append(",mobile:" + this.mobile);
            buffer.append(",phone:" + this.phone);
            buffer.append(",fax:" + this.fax);
            buffer.append(",email:" + this.email);
            buffer.append(",idKind:" + this.idKind);
            buffer.append(",idNo:" + this.idNo);
            buffer.append(",qualifyNo:" + this.qualifyNo);
            buffer.append(",operStatus:" + this.operStatus);
            buffer.append(",messageType:" + this.messageType);
            buffer.append(",remark:" + this.remark);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.userId);
            builder.append(this.userName);
            builder.append(this.userPassword);
            builder.append(this.userType);
            builder.append(this.userStatus);
            builder.append(this.branchName);
            builder.append(this.mobile);
            builder.append(this.phone);
            builder.append(this.fax);
            builder.append(this.email);
            builder.append(this.idKind);
            builder.append(this.idNo);
            builder.append(this.qualifyNo);
            builder.append(this.operStatus);
            builder.append(this.messageType);
            builder.append(this.remark);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.PutUserInfoInnerInput) {
                InnerPbsService.PutUserInfoInnerInput test = (InnerPbsService.PutUserInfoInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.userId, test.userId);
                builder.append(this.userName, test.userName);
                builder.append(this.userPassword, test.userPassword);
                builder.append(this.userType, test.userType);
                builder.append(this.userStatus, test.userStatus);
                builder.append(this.branchName, test.branchName);
                builder.append(this.mobile, test.mobile);
                builder.append(this.phone, test.phone);
                builder.append(this.fax, test.fax);
                builder.append(this.email, test.email);
                builder.append(this.idKind, test.idKind);
                builder.append(this.idNo, test.idNo);
                builder.append(this.qualifyNo, test.qualifyNo);
                builder.append(this.operStatus, test.operStatus);
                builder.append(this.messageType, test.messageType);
                builder.append(this.remark, test.remark);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutInitdatemodelInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Long serialNo = 0L;

        public PutInitdatemodelInnerOutput() {
        }

        public Long getSerialNo() {
            return this.serialNo != null ? this.serialNo : 0L;
        }

        public void setSerialNo(Long serialNo) {
            this.serialNo = serialNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutInitdatemodelInnerOutput:(");
            buffer.append("serialNo:" + this.serialNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.serialNo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.PutInitdatemodelInnerOutput) {
                InnerPbsService.PutInitdatemodelInnerOutput test = (InnerPbsService.PutInitdatemodelInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.serialNo, test.serialNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutInitdatemodelInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @NotNull(
                message = "不能为空"
        )
        private Integer initDate = 0;
        @NotNull(
                message = "不能为空"
        )
        private Integer initModel = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character settleFlag = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character tradeFlag = ' ';

        public PutInitdatemodelInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public Integer getInitModel() {
            return this.initModel != null ? this.initModel : 0;
        }

        public Character getSettleFlag() {
            return this.settleFlag != null ? this.settleFlag : ' ';
        }

        public Character getTradeFlag() {
            return this.tradeFlag != null ? this.tradeFlag : ' ';
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public void setInitModel(Integer initModel) {
            this.initModel = initModel;
        }

        public void setSettleFlag(Character settleFlag) {
            this.settleFlag = settleFlag;
        }

        public void setTradeFlag(Character tradeFlag) {
            this.tradeFlag = tradeFlag;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutInitdatemodelInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",initDate:" + this.initDate);
            buffer.append(",initModel:" + this.initModel);
            buffer.append(",settleFlag:" + this.settleFlag);
            buffer.append(",tradeFlag:" + this.tradeFlag);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.initDate);
            builder.append(this.initModel);
            builder.append(this.settleFlag);
            builder.append(this.tradeFlag);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.PutInitdatemodelInnerInput) {
                InnerPbsService.PutInitdatemodelInnerInput test = (InnerPbsService.PutInitdatemodelInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.initDate, test.initDate);
                builder.append(this.initModel, test.initModel);
                builder.append(this.settleFlag, test.settleFlag);
                builder.append(this.tradeFlag, test.tradeFlag);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutFiledownloadInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String resultCode = " ";
        private String positionStr = " ";

        public PutFiledownloadInnerOutput() {
        }

        public String getResultCode() {
            if (this.resultCode == null) {
                return " ";
            } else {
                return this.resultCode.isEmpty() ? " " : this.resultCode;
            }
        }

        public String getPositionStr() {
            if (this.positionStr == null) {
                return " ";
            } else {
                return this.positionStr.isEmpty() ? " " : this.positionStr;
            }
        }

        public void setResultCode(String resultCode) {
            this.resultCode = resultCode;
        }

        public void setPositionStr(String positionStr) {
            this.positionStr = positionStr;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutFiledownloadInnerOutput:(");
            buffer.append("resultCode:" + this.resultCode);
            buffer.append(",positionStr:" + this.positionStr);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.resultCode);
            builder.append(this.positionStr);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.PutFiledownloadInnerOutput) {
                InnerPbsService.PutFiledownloadInnerOutput test = (InnerPbsService.PutFiledownloadInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.resultCode, test.resultCode);
                builder.append(this.positionStr, test.positionStr);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutFiledownloadInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 1,
                max = 100,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String positionStr = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character downStatus = ' ';
        private Integer dateClear = 0;
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String remark = " ";

        public PutFiledownloadInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getPositionStr() {
            if (this.positionStr == null) {
                return " ";
            } else {
                return this.positionStr.isEmpty() ? " " : this.positionStr;
            }
        }

        public Character getDownStatus() {
            return this.downStatus != null ? this.downStatus : ' ';
        }

        public Integer getDateClear() {
            return this.dateClear != null ? this.dateClear : 0;
        }

        public String getRemark() {
            if (this.remark == null) {
                return " ";
            } else {
                return this.remark.isEmpty() ? " " : this.remark;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setPositionStr(String positionStr) {
            this.positionStr = positionStr;
        }

        public void setDownStatus(Character downStatus) {
            this.downStatus = downStatus;
        }

        public void setDateClear(Integer dateClear) {
            this.dateClear = dateClear;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutFiledownloadInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",positionStr:" + this.positionStr);
            buffer.append(",downStatus:" + this.downStatus);
            buffer.append(",dateClear:" + this.dateClear);
            buffer.append(",remark:" + this.remark);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.positionStr);
            builder.append(this.downStatus);
            builder.append(this.dateClear);
            builder.append(this.remark);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.PutFiledownloadInnerInput) {
                InnerPbsService.PutFiledownloadInnerInput test = (InnerPbsService.PutFiledownloadInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.positionStr, test.positionStr);
                builder.append(this.downStatus, test.downStatus);
                builder.append(this.dateClear, test.dateClear);
                builder.append(this.remark, test.remark);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutFiledownloadClearInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String resultCode = " ";
        private Integer total = 0;

        public PutFiledownloadClearInnerOutput() {
        }

        public String getResultCode() {
            if (this.resultCode == null) {
                return " ";
            } else {
                return this.resultCode.isEmpty() ? " " : this.resultCode;
            }
        }

        public Integer getTotal() {
            return this.total != null ? this.total : 0;
        }

        public void setResultCode(String resultCode) {
            this.resultCode = resultCode;
        }

        public void setTotal(Integer total) {
            this.total = total;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutFiledownloadClearInnerOutput:(");
            buffer.append("resultCode:" + this.resultCode);
            buffer.append(",total:" + this.total);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.resultCode);
            builder.append(this.total);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.PutFiledownloadClearInnerOutput) {
                InnerPbsService.PutFiledownloadClearInnerOutput test = (InnerPbsService.PutFiledownloadClearInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.resultCode, test.resultCode);
                builder.append(this.total, test.total);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutFiledownloadClearInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';

        public PutFiledownloadClearInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutFiledownloadClearInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.PutFiledownloadClearInnerInput) {
                InnerPbsService.PutFiledownloadClearInnerInput test = (InnerPbsService.PutFiledownloadClearInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutDayinitinfoResetSerialnoInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer initDate = 0;

        public PutDayinitinfoResetSerialnoInnerOutput() {
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutDayinitinfoResetSerialnoInnerOutput:(");
            buffer.append("initDate:" + this.initDate);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.initDate);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.PutDayinitinfoResetSerialnoInnerOutput) {
                InnerPbsService.PutDayinitinfoResetSerialnoInnerOutput test = (InnerPbsService.PutDayinitinfoResetSerialnoInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.initDate, test.initDate);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutDayinitinfoResetSerialnoInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';

        public PutDayinitinfoResetSerialnoInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutDayinitinfoResetSerialnoInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.PutDayinitinfoResetSerialnoInnerInput) {
                InnerPbsService.PutDayinitinfoResetSerialnoInnerInput test = (InnerPbsService.PutDayinitinfoResetSerialnoInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutDayinitinfoDateChangeInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String sysName = " ";
        private Integer initDate = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character sysStatus = ' ';
        private Integer initModel = 0;
        private Integer updateDate = 0;
        private Integer updateTime = 0;

        public PutDayinitinfoDateChangeInnerOutput() {
        }

        public String getSysName() {
            if (this.sysName == null) {
                return " ";
            } else {
                return this.sysName.isEmpty() ? " " : this.sysName;
            }
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public Character getSysStatus() {
            return this.sysStatus != null ? this.sysStatus : ' ';
        }

        public Integer getInitModel() {
            return this.initModel != null ? this.initModel : 0;
        }

        public Integer getUpdateDate() {
            return this.updateDate != null ? this.updateDate : 0;
        }

        public Integer getUpdateTime() {
            return this.updateTime != null ? this.updateTime : 0;
        }

        public void setSysName(String sysName) {
            this.sysName = sysName;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public void setSysStatus(Character sysStatus) {
            this.sysStatus = sysStatus;
        }

        public void setInitModel(Integer initModel) {
            this.initModel = initModel;
        }

        public void setUpdateDate(Integer updateDate) {
            this.updateDate = updateDate;
        }

        public void setUpdateTime(Integer updateTime) {
            this.updateTime = updateTime;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutDayinitinfoDateChangeInnerOutput:(");
            buffer.append("sysName:" + this.sysName);
            buffer.append(",initDate:" + this.initDate);
            buffer.append(",sysStatus:" + this.sysStatus);
            buffer.append(",initModel:" + this.initModel);
            buffer.append(",updateDate:" + this.updateDate);
            buffer.append(",updateTime:" + this.updateTime);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.sysName);
            builder.append(this.initDate);
            builder.append(this.sysStatus);
            builder.append(this.initModel);
            builder.append(this.updateDate);
            builder.append(this.updateTime);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.PutDayinitinfoDateChangeInnerOutput) {
                InnerPbsService.PutDayinitinfoDateChangeInnerOutput test = (InnerPbsService.PutDayinitinfoDateChangeInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.sysName, test.sysName);
                builder.append(this.initDate, test.initDate);
                builder.append(this.sysStatus, test.sysStatus);
                builder.append(this.initModel, test.initModel);
                builder.append(this.updateDate, test.updateDate);
                builder.append(this.updateTime, test.updateTime);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutDayinitinfoDateChangeInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';

        public PutDayinitinfoDateChangeInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutDayinitinfoDateChangeInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.PutDayinitinfoDateChangeInnerInput) {
                InnerPbsService.PutDayinitinfoDateChangeInnerInput test = (InnerPbsService.PutDayinitinfoDateChangeInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostOperlogListInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer errorNo = 0;
        private String errorInfo = " ";

        public PostOperlogListInnerOutput() {
        }

        public Integer getErrorNo() {
            return this.errorNo != null ? this.errorNo : 0;
        }

        public String getErrorInfo() {
            if (this.errorInfo == null) {
                return " ";
            } else {
                return this.errorInfo.isEmpty() ? " " : this.errorInfo;
            }
        }

        public void setErrorNo(Integer errorNo) {
            this.errorNo = errorNo;
        }

        public void setErrorInfo(String errorInfo) {
            this.errorInfo = errorInfo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostOperlogListInnerOutput:(");
            buffer.append("errorNo:" + this.errorNo);
            buffer.append(",errorInfo:" + this.errorInfo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.errorNo);
            builder.append(this.errorInfo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.PostOperlogListInnerOutput) {
                InnerPbsService.PostOperlogListInnerOutput test = (InnerPbsService.PostOperlogListInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.errorNo, test.errorNo);
                builder.append(this.errorInfo, test.errorInfo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostOperlogListInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @Valid
        private List<InnerPbsService.OperlogDTO> operLogs = new ArrayList();

        public PostOperlogListInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public List<InnerPbsService.OperlogDTO> getOperLogs() {
            return (List)(this.operLogs != null ? this.operLogs : new ArrayList());
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOperLogs(List<InnerPbsService.OperlogDTO> operLogs) {
            this.operLogs = operLogs;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostOperlogListInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",operLogs:" + this.operLogs);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.operLogs);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.PostOperlogListInnerInput) {
                InnerPbsService.PostOperlogListInnerInput test = (InnerPbsService.PostOperlogListInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.operLogs, test.operLogs);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostOperlogInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer errorNo = 0;
        private String errorInfo = " ";

        public PostOperlogInnerOutput() {
        }

        public Integer getErrorNo() {
            return this.errorNo != null ? this.errorNo : 0;
        }

        public String getErrorInfo() {
            if (this.errorInfo == null) {
                return " ";
            } else {
                return this.errorInfo.isEmpty() ? " " : this.errorInfo;
            }
        }

        public void setErrorNo(Integer errorNo) {
            this.errorNo = errorNo;
        }

        public void setErrorInfo(String errorInfo) {
            this.errorInfo = errorInfo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostOperlogInnerOutput:(");
            buffer.append("errorNo:" + this.errorNo);
            buffer.append(",errorInfo:" + this.errorInfo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.errorNo);
            builder.append(this.errorInfo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.PostOperlogInnerOutput) {
                InnerPbsService.PostOperlogInnerOutput test = (InnerPbsService.PostOperlogInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.errorNo, test.errorNo);
                builder.append(this.errorInfo, test.errorInfo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostOperlogInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer branchNo = 0;
        private Integer currDate = 0;
        private Integer currTime = 0;
        @SinogramLength(
                min = 0,
                max = 8,
                charset = "utf-8"
        )
        private String systemStr = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String menuCode = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String functionStr = " ";
        private Integer businessFlag = 0;
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String opRemark = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character operatorAction = ' ';
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String clientId = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fundAccount = " ";
        @SinogramLength(
                min = 0,
                max = 20,
                charset = "utf-8"
        )
        private String tradeAccount = " ";
        @Digits(
                integer = 13,
                fraction = 2,
                message = "发生数量【occurAmount】 超出精度范围, 最大整数位为【13】, 小数位为【2】"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double occurAmount = 0.0D;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "发生金额【occurBalance】 超出精度范围, 最大整数位为【13】, 小数位为【2】"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double occurBalance = 0.0D;
        @SinogramLength(
                min = 0,
                max = 3,
                charset = "utf-8"
        )
        private String moneyType = " ";
        private Long joinSerialNo = 0L;
        private Integer joinDate = 0;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String traceId = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String acptId = " ";

        public PostOperlogInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Integer getCurrDate() {
            return this.currDate != null ? this.currDate : 0;
        }

        public Integer getCurrTime() {
            return this.currTime != null ? this.currTime : 0;
        }

        public String getSystemStr() {
            if (this.systemStr == null) {
                return " ";
            } else {
                return this.systemStr.isEmpty() ? " " : this.systemStr;
            }
        }

        public String getMenuCode() {
            if (this.menuCode == null) {
                return " ";
            } else {
                return this.menuCode.isEmpty() ? " " : this.menuCode;
            }
        }

        public String getFunctionStr() {
            if (this.functionStr == null) {
                return " ";
            } else {
                return this.functionStr.isEmpty() ? " " : this.functionStr;
            }
        }

        public Integer getBusinessFlag() {
            return this.businessFlag != null ? this.businessFlag : 0;
        }

        public String getOpRemark() {
            if (this.opRemark == null) {
                return " ";
            } else {
                return this.opRemark.isEmpty() ? " " : this.opRemark;
            }
        }

        public Character getOperatorAction() {
            return this.operatorAction != null ? this.operatorAction : ' ';
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getTradeAccount() {
            if (this.tradeAccount == null) {
                return " ";
            } else {
                return this.tradeAccount.isEmpty() ? " " : this.tradeAccount;
            }
        }

        public Double getOccurAmount() {
            return this.occurAmount != null ? this.occurAmount : 0.0D;
        }

        public Double getOccurBalance() {
            return this.occurBalance != null ? this.occurBalance : 0.0D;
        }

        public String getMoneyType() {
            if (this.moneyType == null) {
                return " ";
            } else {
                return this.moneyType.isEmpty() ? " " : this.moneyType;
            }
        }

        public Long getJoinSerialNo() {
            return this.joinSerialNo != null ? this.joinSerialNo : 0L;
        }

        public Integer getJoinDate() {
            return this.joinDate != null ? this.joinDate : 0;
        }

        public String getTraceId() {
            if (this.traceId == null) {
                return " ";
            } else {
                return this.traceId.isEmpty() ? " " : this.traceId;
            }
        }

        public String getAcptId() {
            if (this.acptId == null) {
                return " ";
            } else {
                return this.acptId.isEmpty() ? " " : this.acptId;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setCurrDate(Integer currDate) {
            this.currDate = currDate;
        }

        public void setCurrTime(Integer currTime) {
            this.currTime = currTime;
        }

        public void setSystemStr(String systemStr) {
            this.systemStr = systemStr;
        }

        public void setMenuCode(String menuCode) {
            this.menuCode = menuCode;
        }

        public void setFunctionStr(String functionStr) {
            this.functionStr = functionStr;
        }

        public void setBusinessFlag(Integer businessFlag) {
            this.businessFlag = businessFlag;
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public void setOperatorAction(Character operatorAction) {
            this.operatorAction = operatorAction;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setTradeAccount(String tradeAccount) {
            this.tradeAccount = tradeAccount;
        }

        public void setOccurAmount(Double occurAmount) {
            this.occurAmount = occurAmount;
        }

        public void setOccurBalance(Double occurBalance) {
            this.occurBalance = occurBalance;
        }

        public void setMoneyType(String moneyType) {
            this.moneyType = moneyType;
        }

        public void setJoinSerialNo(Long joinSerialNo) {
            this.joinSerialNo = joinSerialNo;
        }

        public void setJoinDate(Integer joinDate) {
            this.joinDate = joinDate;
        }

        public void setTraceId(String traceId) {
            this.traceId = traceId;
        }

        public void setAcptId(String acptId) {
            this.acptId = acptId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostOperlogInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",currDate:" + this.currDate);
            buffer.append(",currTime:" + this.currTime);
            buffer.append(",systemStr:" + this.systemStr);
            buffer.append(",menuCode:" + this.menuCode);
            buffer.append(",functionStr:" + this.functionStr);
            buffer.append(",businessFlag:" + this.businessFlag);
            buffer.append(",opRemark:" + this.opRemark);
            buffer.append(",operatorAction:" + this.operatorAction);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",tradeAccount:" + this.tradeAccount);
            buffer.append(",occurAmount:" + this.occurAmount);
            buffer.append(",occurBalance:" + this.occurBalance);
            buffer.append(",moneyType:" + this.moneyType);
            buffer.append(",joinSerialNo:" + this.joinSerialNo);
            buffer.append(",joinDate:" + this.joinDate);
            buffer.append(",traceId:" + this.traceId);
            buffer.append(",acptId:" + this.acptId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.branchNo);
            builder.append(this.currDate);
            builder.append(this.currTime);
            builder.append(this.systemStr);
            builder.append(this.menuCode);
            builder.append(this.functionStr);
            builder.append(this.businessFlag);
            builder.append(this.opRemark);
            builder.append(this.operatorAction);
            builder.append(this.clientId);
            builder.append(this.fundAccount);
            builder.append(this.tradeAccount);
            builder.append(this.occurAmount);
            builder.append(this.occurBalance);
            builder.append(this.moneyType);
            builder.append(this.joinSerialNo);
            builder.append(this.joinDate);
            builder.append(this.traceId);
            builder.append(this.acptId);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.PostOperlogInnerInput) {
                InnerPbsService.PostOperlogInnerInput test = (InnerPbsService.PostOperlogInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.currDate, test.currDate);
                builder.append(this.currTime, test.currTime);
                builder.append(this.systemStr, test.systemStr);
                builder.append(this.menuCode, test.menuCode);
                builder.append(this.functionStr, test.functionStr);
                builder.append(this.businessFlag, test.businessFlag);
                builder.append(this.opRemark, test.opRemark);
                builder.append(this.operatorAction, test.operatorAction);
                builder.append(this.clientId, test.clientId);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.tradeAccount, test.tradeAccount);
                builder.append(this.occurAmount, test.occurAmount);
                builder.append(this.occurBalance, test.occurBalance);
                builder.append(this.moneyType, test.moneyType);
                builder.append(this.joinSerialNo, test.joinSerialNo);
                builder.append(this.joinDate, test.joinDate);
                builder.append(this.traceId, test.traceId);
                builder.append(this.acptId, test.acptId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostHsmenuTransInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String returnCode = " ";
        private String returnInfo = " ";

        public PostHsmenuTransInnerOutput() {
        }

        public String getReturnCode() {
            if (this.returnCode == null) {
                return " ";
            } else {
                return this.returnCode.isEmpty() ? " " : this.returnCode;
            }
        }

        public String getReturnInfo() {
            if (this.returnInfo == null) {
                return " ";
            } else {
                return this.returnInfo.isEmpty() ? " " : this.returnInfo;
            }
        }

        public void setReturnCode(String returnCode) {
            this.returnCode = returnCode;
        }

        public void setReturnInfo(String returnInfo) {
            this.returnInfo = returnInfo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostHsmenuTransInnerOutput:(");
            buffer.append("returnCode:" + this.returnCode);
            buffer.append(",returnInfo:" + this.returnInfo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.returnCode);
            builder.append(this.returnInfo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.PostHsmenuTransInnerOutput) {
                InnerPbsService.PostHsmenuTransInnerOutput test = (InnerPbsService.PostHsmenuTransInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.returnCode, test.returnCode);
                builder.append(this.returnInfo, test.returnInfo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostHsmenuTransInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String menuCodePbs = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String menuNamePbs = " ";
        @SinogramLength(
                min = 1,
                max = 100,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String kindCodePbs = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String parentCodePbs = " ";
        @SinogramLength(
                min = 0,
                max = 100,
                charset = "utf-8"
        )
        private String appCodePbs = " ";
        @SinogramLength(
                min = 0,
                max = 10,
                charset = "utf-8"
        )
        private String menuTypePbs = " ";
        @SinogramLength(
                min = 0,
                max = 100,
                charset = "utf-8"
        )
        private String tenantIdPbs = " ";

        public PostHsmenuTransInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getMenuCodePbs() {
            if (this.menuCodePbs == null) {
                return " ";
            } else {
                return this.menuCodePbs.isEmpty() ? " " : this.menuCodePbs;
            }
        }

        public String getMenuNamePbs() {
            if (this.menuNamePbs == null) {
                return " ";
            } else {
                return this.menuNamePbs.isEmpty() ? " " : this.menuNamePbs;
            }
        }

        public String getKindCodePbs() {
            if (this.kindCodePbs == null) {
                return " ";
            } else {
                return this.kindCodePbs.isEmpty() ? " " : this.kindCodePbs;
            }
        }

        public String getParentCodePbs() {
            if (this.parentCodePbs == null) {
                return " ";
            } else {
                return this.parentCodePbs.isEmpty() ? " " : this.parentCodePbs;
            }
        }

        public String getAppCodePbs() {
            if (this.appCodePbs == null) {
                return " ";
            } else {
                return this.appCodePbs.isEmpty() ? " " : this.appCodePbs;
            }
        }

        public String getMenuTypePbs() {
            if (this.menuTypePbs == null) {
                return " ";
            } else {
                return this.menuTypePbs.isEmpty() ? " " : this.menuTypePbs;
            }
        }

        public String getTenantIdPbs() {
            if (this.tenantIdPbs == null) {
                return " ";
            } else {
                return this.tenantIdPbs.isEmpty() ? " " : this.tenantIdPbs;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setMenuCodePbs(String menuCodePbs) {
            this.menuCodePbs = menuCodePbs;
        }

        public void setMenuNamePbs(String menuNamePbs) {
            this.menuNamePbs = menuNamePbs;
        }

        public void setKindCodePbs(String kindCodePbs) {
            this.kindCodePbs = kindCodePbs;
        }

        public void setParentCodePbs(String parentCodePbs) {
            this.parentCodePbs = parentCodePbs;
        }

        public void setAppCodePbs(String appCodePbs) {
            this.appCodePbs = appCodePbs;
        }

        public void setMenuTypePbs(String menuTypePbs) {
            this.menuTypePbs = menuTypePbs;
        }

        public void setTenantIdPbs(String tenantIdPbs) {
            this.tenantIdPbs = tenantIdPbs;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostHsmenuTransInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",menuCodePbs:" + this.menuCodePbs);
            buffer.append(",menuNamePbs:" + this.menuNamePbs);
            buffer.append(",kindCodePbs:" + this.kindCodePbs);
            buffer.append(",parentCodePbs:" + this.parentCodePbs);
            buffer.append(",appCodePbs:" + this.appCodePbs);
            buffer.append(",menuTypePbs:" + this.menuTypePbs);
            buffer.append(",tenantIdPbs:" + this.tenantIdPbs);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.menuCodePbs);
            builder.append(this.menuNamePbs);
            builder.append(this.kindCodePbs);
            builder.append(this.parentCodePbs);
            builder.append(this.appCodePbs);
            builder.append(this.menuTypePbs);
            builder.append(this.tenantIdPbs);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.PostHsmenuTransInnerInput) {
                InnerPbsService.PostHsmenuTransInnerInput test = (InnerPbsService.PostHsmenuTransInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.menuCodePbs, test.menuCodePbs);
                builder.append(this.menuNamePbs, test.menuNamePbs);
                builder.append(this.kindCodePbs, test.kindCodePbs);
                builder.append(this.parentCodePbs, test.parentCodePbs);
                builder.append(this.appCodePbs, test.appCodePbs);
                builder.append(this.menuTypePbs, test.menuTypePbs);
                builder.append(this.tenantIdPbs, test.tenantIdPbs);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostHsmenuSubtransInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String returnCode = " ";
        private String returnInfo = " ";

        public PostHsmenuSubtransInnerOutput() {
        }

        public String getReturnCode() {
            if (this.returnCode == null) {
                return " ";
            } else {
                return this.returnCode.isEmpty() ? " " : this.returnCode;
            }
        }

        public String getReturnInfo() {
            if (this.returnInfo == null) {
                return " ";
            } else {
                return this.returnInfo.isEmpty() ? " " : this.returnInfo;
            }
        }

        public void setReturnCode(String returnCode) {
            this.returnCode = returnCode;
        }

        public void setReturnInfo(String returnInfo) {
            this.returnInfo = returnInfo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostHsmenuSubtransInnerOutput:(");
            buffer.append("returnCode:" + this.returnCode);
            buffer.append(",returnInfo:" + this.returnInfo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.returnCode);
            builder.append(this.returnInfo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.PostHsmenuSubtransInnerOutput) {
                InnerPbsService.PostHsmenuSubtransInnerOutput test = (InnerPbsService.PostHsmenuSubtransInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.returnCode, test.returnCode);
                builder.append(this.returnInfo, test.returnInfo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostHsmenuSubtransInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String transCodePbs = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String subTransCodePbs = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String subTransNamePbs = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character subctrlFlag = ' ';
        @SinogramLength(
                min = 0,
                max = 256,
                charset = "utf-8"
        )
        private String relUrlPbs = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character loginFlag = ' ';
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String remark = " ";
        @SinogramLength(
                min = 0,
                max = 100,
                charset = "utf-8"
        )
        private String tenantIdPbs = " ";

        public PostHsmenuSubtransInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getTransCodePbs() {
            if (this.transCodePbs == null) {
                return " ";
            } else {
                return this.transCodePbs.isEmpty() ? " " : this.transCodePbs;
            }
        }

        public String getSubTransCodePbs() {
            if (this.subTransCodePbs == null) {
                return " ";
            } else {
                return this.subTransCodePbs.isEmpty() ? " " : this.subTransCodePbs;
            }
        }

        public String getSubTransNamePbs() {
            if (this.subTransNamePbs == null) {
                return " ";
            } else {
                return this.subTransNamePbs.isEmpty() ? " " : this.subTransNamePbs;
            }
        }

        public Character getSubctrlFlag() {
            return this.subctrlFlag != null ? this.subctrlFlag : ' ';
        }

        public String getRelUrlPbs() {
            if (this.relUrlPbs == null) {
                return " ";
            } else {
                return this.relUrlPbs.isEmpty() ? " " : this.relUrlPbs;
            }
        }

        public Character getLoginFlag() {
            return this.loginFlag != null ? this.loginFlag : ' ';
        }

        public String getRemark() {
            if (this.remark == null) {
                return " ";
            } else {
                return this.remark.isEmpty() ? " " : this.remark;
            }
        }

        public String getTenantIdPbs() {
            if (this.tenantIdPbs == null) {
                return " ";
            } else {
                return this.tenantIdPbs.isEmpty() ? " " : this.tenantIdPbs;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setTransCodePbs(String transCodePbs) {
            this.transCodePbs = transCodePbs;
        }

        public void setSubTransCodePbs(String subTransCodePbs) {
            this.subTransCodePbs = subTransCodePbs;
        }

        public void setSubTransNamePbs(String subTransNamePbs) {
            this.subTransNamePbs = subTransNamePbs;
        }

        public void setSubctrlFlag(Character subctrlFlag) {
            this.subctrlFlag = subctrlFlag;
        }

        public void setRelUrlPbs(String relUrlPbs) {
            this.relUrlPbs = relUrlPbs;
        }

        public void setLoginFlag(Character loginFlag) {
            this.loginFlag = loginFlag;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public void setTenantIdPbs(String tenantIdPbs) {
            this.tenantIdPbs = tenantIdPbs;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostHsmenuSubtransInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",transCodePbs:" + this.transCodePbs);
            buffer.append(",subTransCodePbs:" + this.subTransCodePbs);
            buffer.append(",subTransNamePbs:" + this.subTransNamePbs);
            buffer.append(",subctrlFlag:" + this.subctrlFlag);
            buffer.append(",relUrlPbs:" + this.relUrlPbs);
            buffer.append(",loginFlag:" + this.loginFlag);
            buffer.append(",remark:" + this.remark);
            buffer.append(",tenantIdPbs:" + this.tenantIdPbs);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.transCodePbs);
            builder.append(this.subTransCodePbs);
            builder.append(this.subTransNamePbs);
            builder.append(this.subctrlFlag);
            builder.append(this.relUrlPbs);
            builder.append(this.loginFlag);
            builder.append(this.remark);
            builder.append(this.tenantIdPbs);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.PostHsmenuSubtransInnerInput) {
                InnerPbsService.PostHsmenuSubtransInnerInput test = (InnerPbsService.PostHsmenuSubtransInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.transCodePbs, test.transCodePbs);
                builder.append(this.subTransCodePbs, test.subTransCodePbs);
                builder.append(this.subTransNamePbs, test.subTransNamePbs);
                builder.append(this.subctrlFlag, test.subctrlFlag);
                builder.append(this.relUrlPbs, test.relUrlPbs);
                builder.append(this.loginFlag, test.loginFlag);
                builder.append(this.remark, test.remark);
                builder.append(this.tenantIdPbs, test.tenantIdPbs);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostFiledownloadInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String resultCode = " ";
        private String positionStr = " ";

        public PostFiledownloadInnerOutput() {
        }

        public String getResultCode() {
            if (this.resultCode == null) {
                return " ";
            } else {
                return this.resultCode.isEmpty() ? " " : this.resultCode;
            }
        }

        public String getPositionStr() {
            if (this.positionStr == null) {
                return " ";
            } else {
                return this.positionStr.isEmpty() ? " " : this.positionStr;
            }
        }

        public void setResultCode(String resultCode) {
            this.resultCode = resultCode;
        }

        public void setPositionStr(String positionStr) {
            this.positionStr = positionStr;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostFiledownloadInnerOutput:(");
            buffer.append("resultCode:" + this.resultCode);
            buffer.append(",positionStr:" + this.positionStr);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.resultCode);
            builder.append(this.positionStr);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.PostFiledownloadInnerOutput) {
                InnerPbsService.PostFiledownloadInnerOutput test = (InnerPbsService.PostFiledownloadInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.resultCode, test.resultCode);
                builder.append(this.positionStr, test.positionStr);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostFiledownloadInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 1,
                max = 64,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String menuCode = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String filePath = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String fileName = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character downStatus = ' ';
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String remark = " ";
        private Integer dateClear = 0;

        public PostFiledownloadInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getMenuCode() {
            if (this.menuCode == null) {
                return " ";
            } else {
                return this.menuCode.isEmpty() ? " " : this.menuCode;
            }
        }

        public String getFilePath() {
            if (this.filePath == null) {
                return " ";
            } else {
                return this.filePath.isEmpty() ? " " : this.filePath;
            }
        }

        public String getFileName() {
            if (this.fileName == null) {
                return " ";
            } else {
                return this.fileName.isEmpty() ? " " : this.fileName;
            }
        }

        public Character getDownStatus() {
            return this.downStatus != null ? this.downStatus : ' ';
        }

        public String getRemark() {
            if (this.remark == null) {
                return " ";
            } else {
                return this.remark.isEmpty() ? " " : this.remark;
            }
        }

        public Integer getDateClear() {
            return this.dateClear != null ? this.dateClear : 0;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setMenuCode(String menuCode) {
            this.menuCode = menuCode;
        }

        public void setFilePath(String filePath) {
            this.filePath = filePath;
        }

        public void setFileName(String fileName) {
            this.fileName = fileName;
        }

        public void setDownStatus(Character downStatus) {
            this.downStatus = downStatus;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public void setDateClear(Integer dateClear) {
            this.dateClear = dateClear;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostFiledownloadInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",menuCode:" + this.menuCode);
            buffer.append(",filePath:" + this.filePath);
            buffer.append(",fileName:" + this.fileName);
            buffer.append(",downStatus:" + this.downStatus);
            buffer.append(",remark:" + this.remark);
            buffer.append(",dateClear:" + this.dateClear);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.menuCode);
            builder.append(this.filePath);
            builder.append(this.fileName);
            builder.append(this.downStatus);
            builder.append(this.remark);
            builder.append(this.dateClear);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.PostFiledownloadInnerInput) {
                InnerPbsService.PostFiledownloadInnerInput test = (InnerPbsService.PostFiledownloadInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.menuCode, test.menuCode);
                builder.append(this.filePath, test.filePath);
                builder.append(this.fileName, test.fileName);
                builder.append(this.downStatus, test.downStatus);
                builder.append(this.remark, test.remark);
                builder.append(this.dateClear, test.dateClear);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostDayinitinfoSqlInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer rowcount = 0;
        private String settleClob = " ";

        public PostDayinitinfoSqlInnerOutput() {
        }

        public Integer getRowcount() {
            return this.rowcount != null ? this.rowcount : 0;
        }

        public String getSettleClob() {
            if (this.settleClob == null) {
                return " ";
            } else {
                return this.settleClob.isEmpty() ? " " : this.settleClob;
            }
        }

        public void setRowcount(Integer rowcount) {
            this.rowcount = rowcount;
        }

        public void setSettleClob(String settleClob) {
            this.settleClob = settleClob;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostDayinitinfoSqlInnerOutput:(");
            buffer.append("rowcount:" + this.rowcount);
            buffer.append(",settleClob:" + this.settleClob);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.rowcount);
            builder.append(this.settleClob);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.PostDayinitinfoSqlInnerOutput) {
                InnerPbsService.PostDayinitinfoSqlInnerOutput test = (InnerPbsService.PostDayinitinfoSqlInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.rowcount, test.rowcount);
                builder.append(this.settleClob, test.settleClob);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostDayinitinfoSqlInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 1,
                max = 16000,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String executeSql = " ";
        @SinogramLength(
                min = 1,
                max = 2000,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String tokenKey = " ";
        private Integer actionIn = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character dealMode = ' ';

        public PostDayinitinfoSqlInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getExecuteSql() {
            if (this.executeSql == null) {
                return " ";
            } else {
                return this.executeSql.isEmpty() ? " " : this.executeSql;
            }
        }

        public String getTokenKey() {
            if (this.tokenKey == null) {
                return " ";
            } else {
                return this.tokenKey.isEmpty() ? " " : this.tokenKey;
            }
        }

        public Integer getActionIn() {
            return this.actionIn != null ? this.actionIn : 0;
        }

        public Character getDealMode() {
            return this.dealMode != null ? this.dealMode : ' ';
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setExecuteSql(String executeSql) {
            this.executeSql = executeSql;
        }

        public void setTokenKey(String tokenKey) {
            this.tokenKey = tokenKey;
        }

        public void setActionIn(Integer actionIn) {
            this.actionIn = actionIn;
        }

        public void setDealMode(Character dealMode) {
            this.dealMode = dealMode;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostDayinitinfoSqlInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",executeSql:" + this.executeSql);
            buffer.append(",tokenKey:" + this.tokenKey);
            buffer.append(",actionIn:" + this.actionIn);
            buffer.append(",dealMode:" + this.dealMode);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.executeSql);
            builder.append(this.tokenKey);
            builder.append(this.actionIn);
            builder.append(this.dealMode);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.PostDayinitinfoSqlInnerInput) {
                InnerPbsService.PostDayinitinfoSqlInnerInput test = (InnerPbsService.PostDayinitinfoSqlInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.executeSql, test.executeSql);
                builder.append(this.tokenKey, test.tokenKey);
                builder.append(this.actionIn, test.actionIn);
                builder.append(this.dealMode, test.dealMode);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostDayinitinfoDataToprevInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer initDate = 0;

        public PostDayinitinfoDataToprevInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostDayinitinfoDataToprevInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",initDate:" + this.initDate);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.initDate);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.PostDayinitinfoDataToprevInnerInput) {
                InnerPbsService.PostDayinitinfoDataToprevInnerInput test = (InnerPbsService.PostDayinitinfoDataToprevInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.initDate, test.initDate);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetUserstationInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String userId = " ";
        private Long ordinal = 0L;
        private Integer branchNo = 0;
        private String authBindStation = " ";
        private String nickName = " ";
        private Integer bindDate = 0;
        private Integer validDate = 0;
        private String positionStr = " ";

        public GetUserstationInnerOutput() {
        }

        public String getUserId() {
            if (this.userId == null) {
                return " ";
            } else {
                return this.userId.isEmpty() ? " " : this.userId;
            }
        }

        public Long getOrdinal() {
            return this.ordinal != null ? this.ordinal : 0L;
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getAuthBindStation() {
            if (this.authBindStation == null) {
                return " ";
            } else {
                return this.authBindStation.isEmpty() ? " " : this.authBindStation;
            }
        }

        public String getNickName() {
            if (this.nickName == null) {
                return " ";
            } else {
                return this.nickName.isEmpty() ? " " : this.nickName;
            }
        }

        public Integer getBindDate() {
            return this.bindDate != null ? this.bindDate : 0;
        }

        public Integer getValidDate() {
            return this.validDate != null ? this.validDate : 0;
        }

        public String getPositionStr() {
            if (this.positionStr == null) {
                return " ";
            } else {
                return this.positionStr.isEmpty() ? " " : this.positionStr;
            }
        }

        public void setUserId(String userId) {
            this.userId = userId;
        }

        public void setOrdinal(Long ordinal) {
            this.ordinal = ordinal;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setAuthBindStation(String authBindStation) {
            this.authBindStation = authBindStation;
        }

        public void setNickName(String nickName) {
            this.nickName = nickName;
        }

        public void setBindDate(Integer bindDate) {
            this.bindDate = bindDate;
        }

        public void setValidDate(Integer validDate) {
            this.validDate = validDate;
        }

        public void setPositionStr(String positionStr) {
            this.positionStr = positionStr;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetUserstationInnerOutput:(");
            buffer.append("userId:" + this.userId);
            buffer.append(",ordinal:" + this.ordinal);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",authBindStation:" + this.authBindStation);
            buffer.append(",nickName:" + this.nickName);
            buffer.append(",bindDate:" + this.bindDate);
            buffer.append(",validDate:" + this.validDate);
            buffer.append(",positionStr:" + this.positionStr);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.userId);
            builder.append(this.ordinal);
            builder.append(this.branchNo);
            builder.append(this.authBindStation);
            builder.append(this.nickName);
            builder.append(this.bindDate);
            builder.append(this.validDate);
            builder.append(this.positionStr);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetUserstationInnerOutput) {
                InnerPbsService.GetUserstationInnerOutput test = (InnerPbsService.GetUserstationInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.userId, test.userId);
                builder.append(this.ordinal, test.ordinal);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.authBindStation, test.authBindStation);
                builder.append(this.nickName, test.nickName);
                builder.append(this.bindDate, test.bindDate);
                builder.append(this.validDate, test.validDate);
                builder.append(this.positionStr, test.positionStr);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetUserstationInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 1,
                max = 32,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String userId = " ";

        public GetUserstationInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getUserId() {
            if (this.userId == null) {
                return " ";
            } else {
                return this.userId.isEmpty() ? " " : this.userId;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setUserId(String userId) {
            this.userId = userId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetUserstationInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",userId:" + this.userId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.userId);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetUserstationInnerInput) {
                InnerPbsService.GetUserstationInnerInput test = (InnerPbsService.GetUserstationInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.userId, test.userId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetUserstationCheckInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String errorCode = " ";
        private String errorInfo = " ";

        public GetUserstationCheckInnerOutput() {
        }

        public String getErrorCode() {
            if (this.errorCode == null) {
                return " ";
            } else {
                return this.errorCode.isEmpty() ? " " : this.errorCode;
            }
        }

        public String getErrorInfo() {
            if (this.errorInfo == null) {
                return " ";
            } else {
                return this.errorInfo.isEmpty() ? " " : this.errorInfo;
            }
        }

        public void setErrorCode(String errorCode) {
            this.errorCode = errorCode;
        }

        public void setErrorInfo(String errorInfo) {
            this.errorInfo = errorInfo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetUserstationCheckInnerOutput:(");
            buffer.append("errorCode:" + this.errorCode);
            buffer.append(",errorInfo:" + this.errorInfo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.errorCode);
            builder.append(this.errorInfo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetUserstationCheckInnerOutput) {
                InnerPbsService.GetUserstationCheckInnerOutput test = (InnerPbsService.GetUserstationCheckInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.errorCode, test.errorCode);
                builder.append(this.errorInfo, test.errorInfo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetUserstationCheckInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer branchNo = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character assetProp = ' ';
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String stockType = " ";
        private Integer roomCode = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character entrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String exchangeType = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character contractType = ' ';
        private Integer clientGroup = 0;
        @SinogramLength(
                min = 0,
                max = 6,
                charset = "utf-8"
        )
        private String bankNo = " ";
        @SinogramLength(
                min = 0,
                max = 3,
                charset = "utf-8"
        )
        private String moneyType = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fundAccount = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String clientId = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String functionStr = " ";

        public GetUserstationCheckInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Character getAssetProp() {
            return this.assetProp != null ? this.assetProp : ' ';
        }

        public String getStockType() {
            if (this.stockType == null) {
                return " ";
            } else {
                return this.stockType.isEmpty() ? " " : this.stockType;
            }
        }

        public Integer getRoomCode() {
            return this.roomCode != null ? this.roomCode : 0;
        }

        public Character getEntrustWay() {
            return this.entrustWay != null ? this.entrustWay : ' ';
        }

        public String getExchangeType() {
            if (this.exchangeType == null) {
                return " ";
            } else {
                return this.exchangeType.isEmpty() ? " " : this.exchangeType;
            }
        }

        public Character getContractType() {
            return this.contractType != null ? this.contractType : ' ';
        }

        public Integer getClientGroup() {
            return this.clientGroup != null ? this.clientGroup : 0;
        }

        public String getBankNo() {
            if (this.bankNo == null) {
                return " ";
            } else {
                return this.bankNo.isEmpty() ? " " : this.bankNo;
            }
        }

        public String getMoneyType() {
            if (this.moneyType == null) {
                return " ";
            } else {
                return this.moneyType.isEmpty() ? " " : this.moneyType;
            }
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getFunctionStr() {
            if (this.functionStr == null) {
                return " ";
            } else {
                return this.functionStr.isEmpty() ? " " : this.functionStr;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setAssetProp(Character assetProp) {
            this.assetProp = assetProp;
        }

        public void setStockType(String stockType) {
            this.stockType = stockType;
        }

        public void setRoomCode(Integer roomCode) {
            this.roomCode = roomCode;
        }

        public void setEntrustWay(Character entrustWay) {
            this.entrustWay = entrustWay;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public void setContractType(Character contractType) {
            this.contractType = contractType;
        }

        public void setClientGroup(Integer clientGroup) {
            this.clientGroup = clientGroup;
        }

        public void setBankNo(String bankNo) {
            this.bankNo = bankNo;
        }

        public void setMoneyType(String moneyType) {
            this.moneyType = moneyType;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setFunctionStr(String functionStr) {
            this.functionStr = functionStr;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetUserstationCheckInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",assetProp:" + this.assetProp);
            buffer.append(",stockType:" + this.stockType);
            buffer.append(",roomCode:" + this.roomCode);
            buffer.append(",entrustWay:" + this.entrustWay);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(",contractType:" + this.contractType);
            buffer.append(",clientGroup:" + this.clientGroup);
            buffer.append(",bankNo:" + this.bankNo);
            buffer.append(",moneyType:" + this.moneyType);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",functionStr:" + this.functionStr);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.branchNo);
            builder.append(this.assetProp);
            builder.append(this.stockType);
            builder.append(this.roomCode);
            builder.append(this.entrustWay);
            builder.append(this.exchangeType);
            builder.append(this.contractType);
            builder.append(this.clientGroup);
            builder.append(this.bankNo);
            builder.append(this.moneyType);
            builder.append(this.fundAccount);
            builder.append(this.clientId);
            builder.append(this.functionStr);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetUserstationCheckInnerInput) {
                InnerPbsService.GetUserstationCheckInnerInput test = (InnerPbsService.GetUserstationCheckInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.assetProp, test.assetProp);
                builder.append(this.stockType, test.stockType);
                builder.append(this.roomCode, test.roomCode);
                builder.append(this.entrustWay, test.entrustWay);
                builder.append(this.exchangeType, test.exchangeType);
                builder.append(this.contractType, test.contractType);
                builder.append(this.clientGroup, test.clientGroup);
                builder.append(this.bankNo, test.bankNo);
                builder.append(this.moneyType, test.moneyType);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.clientId, test.clientId);
                builder.append(this.functionStr, test.functionStr);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetUserrightMenuAuthInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String menuCode = " ";

        public GetUserrightMenuAuthInnerOutput() {
        }

        public String getMenuCode() {
            if (this.menuCode == null) {
                return " ";
            } else {
                return this.menuCode.isEmpty() ? " " : this.menuCode;
            }
        }

        public void setMenuCode(String menuCode) {
            this.menuCode = menuCode;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetUserrightMenuAuthInnerOutput:(");
            buffer.append("menuCode:" + this.menuCode);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.menuCode);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetUserrightMenuAuthInnerOutput) {
                InnerPbsService.GetUserrightMenuAuthInnerOutput test = (InnerPbsService.GetUserrightMenuAuthInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.menuCode, test.menuCode);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetUserrightMenuAuthInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @NotNull(
                message = "不能为空"
        )
        private Integer branchNo = 0;
        private Integer actionIn = 0;

        public GetUserrightMenuAuthInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Integer getActionIn() {
            return this.actionIn != null ? this.actionIn : 0;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setActionIn(Integer actionIn) {
            this.actionIn = actionIn;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetUserrightMenuAuthInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",actionIn:" + this.actionIn);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.branchNo);
            builder.append(this.actionIn);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetUserrightMenuAuthInnerInput) {
                InnerPbsService.GetUserrightMenuAuthInnerInput test = (InnerPbsService.GetUserrightMenuAuthInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.actionIn, test.actionIn);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetUserrightListInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String userId = " ";
        private Integer branchNo = 0;
        private String enRoomCode = " ";
        private String forbidRoomCode = " ";
        private String dictEntryStr = " ";
        private String operRoles = " ";
        private String authRoles = " ";

        public GetUserrightListInnerOutput() {
        }

        public String getUserId() {
            if (this.userId == null) {
                return " ";
            } else {
                return this.userId.isEmpty() ? " " : this.userId;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getEnRoomCode() {
            if (this.enRoomCode == null) {
                return " ";
            } else {
                return this.enRoomCode.isEmpty() ? " " : this.enRoomCode;
            }
        }

        public String getForbidRoomCode() {
            if (this.forbidRoomCode == null) {
                return " ";
            } else {
                return this.forbidRoomCode.isEmpty() ? " " : this.forbidRoomCode;
            }
        }

        public String getDictEntryStr() {
            if (this.dictEntryStr == null) {
                return " ";
            } else {
                return this.dictEntryStr.isEmpty() ? " " : this.dictEntryStr;
            }
        }

        public String getOperRoles() {
            if (this.operRoles == null) {
                return " ";
            } else {
                return this.operRoles.isEmpty() ? " " : this.operRoles;
            }
        }

        public String getAuthRoles() {
            if (this.authRoles == null) {
                return " ";
            } else {
                return this.authRoles.isEmpty() ? " " : this.authRoles;
            }
        }

        public void setUserId(String userId) {
            this.userId = userId;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setEnRoomCode(String enRoomCode) {
            this.enRoomCode = enRoomCode;
        }

        public void setForbidRoomCode(String forbidRoomCode) {
            this.forbidRoomCode = forbidRoomCode;
        }

        public void setDictEntryStr(String dictEntryStr) {
            this.dictEntryStr = dictEntryStr;
        }

        public void setOperRoles(String operRoles) {
            this.operRoles = operRoles;
        }

        public void setAuthRoles(String authRoles) {
            this.authRoles = authRoles;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetUserrightListInnerOutput:(");
            buffer.append("userId:" + this.userId);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",enRoomCode:" + this.enRoomCode);
            buffer.append(",forbidRoomCode:" + this.forbidRoomCode);
            buffer.append(",dictEntryStr:" + this.dictEntryStr);
            buffer.append(",operRoles:" + this.operRoles);
            buffer.append(",authRoles:" + this.authRoles);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.userId);
            builder.append(this.branchNo);
            builder.append(this.enRoomCode);
            builder.append(this.forbidRoomCode);
            builder.append(this.dictEntryStr);
            builder.append(this.operRoles);
            builder.append(this.authRoles);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetUserrightListInnerOutput) {
                InnerPbsService.GetUserrightListInnerOutput test = (InnerPbsService.GetUserrightListInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.userId, test.userId);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.enRoomCode, test.enRoomCode);
                builder.append(this.forbidRoomCode, test.forbidRoomCode);
                builder.append(this.dictEntryStr, test.dictEntryStr);
                builder.append(this.operRoles, test.operRoles);
                builder.append(this.authRoles, test.authRoles);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetUserrightListInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 1,
                max = 32,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String userId = " ";
        private Integer branchNo = 0;

        public GetUserrightListInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getUserId() {
            if (this.userId == null) {
                return " ";
            } else {
                return this.userId.isEmpty() ? " " : this.userId;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setUserId(String userId) {
            this.userId = userId;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetUserrightListInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",userId:" + this.userId);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.userId);
            builder.append(this.branchNo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetUserrightListInnerInput) {
                InnerPbsService.GetUserrightListInnerInput test = (InnerPbsService.GetUserrightListInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.userId, test.userId);
                builder.append(this.branchNo, test.branchNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetUserrightListByBranchNoInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String userId = " ";
        private Integer branchNo = 0;
        private String enAssetProp = " ";
        private String enStockType = " ";
        private String enRoomCode = " ";
        private String enEntrustWay = " ";
        private String operatorRights = " ";
        private String enExchangeType = " ";
        private String enContractType = " ";
        private String enClientGroup = " ";
        private String enBankNo = " ";
        private String enMoneyType = " ";
        private String forbidClientGroup = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character status = ' ';
        private String targetUserId = " ";
        private String forbidRoomCode = " ";
        private String operRoles = " ";
        private String authRoles = " ";
        private Integer updateDate = 0;
        private Integer updateTime = 0;

        public GetUserrightListByBranchNoInnerOutput() {
        }

        public String getUserId() {
            if (this.userId == null) {
                return " ";
            } else {
                return this.userId.isEmpty() ? " " : this.userId;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getEnAssetProp() {
            if (this.enAssetProp == null) {
                return " ";
            } else {
                return this.enAssetProp.isEmpty() ? " " : this.enAssetProp;
            }
        }

        public String getEnStockType() {
            if (this.enStockType == null) {
                return " ";
            } else {
                return this.enStockType.isEmpty() ? " " : this.enStockType;
            }
        }

        public String getEnRoomCode() {
            if (this.enRoomCode == null) {
                return " ";
            } else {
                return this.enRoomCode.isEmpty() ? " " : this.enRoomCode;
            }
        }

        public String getEnEntrustWay() {
            if (this.enEntrustWay == null) {
                return " ";
            } else {
                return this.enEntrustWay.isEmpty() ? " " : this.enEntrustWay;
            }
        }

        public String getOperatorRights() {
            if (this.operatorRights == null) {
                return " ";
            } else {
                return this.operatorRights.isEmpty() ? " " : this.operatorRights;
            }
        }

        public String getEnExchangeType() {
            if (this.enExchangeType == null) {
                return " ";
            } else {
                return this.enExchangeType.isEmpty() ? " " : this.enExchangeType;
            }
        }

        public String getEnContractType() {
            if (this.enContractType == null) {
                return " ";
            } else {
                return this.enContractType.isEmpty() ? " " : this.enContractType;
            }
        }

        public String getEnClientGroup() {
            if (this.enClientGroup == null) {
                return " ";
            } else {
                return this.enClientGroup.isEmpty() ? " " : this.enClientGroup;
            }
        }

        public String getEnBankNo() {
            if (this.enBankNo == null) {
                return " ";
            } else {
                return this.enBankNo.isEmpty() ? " " : this.enBankNo;
            }
        }

        public String getEnMoneyType() {
            if (this.enMoneyType == null) {
                return " ";
            } else {
                return this.enMoneyType.isEmpty() ? " " : this.enMoneyType;
            }
        }

        public String getForbidClientGroup() {
            if (this.forbidClientGroup == null) {
                return " ";
            } else {
                return this.forbidClientGroup.isEmpty() ? " " : this.forbidClientGroup;
            }
        }

        public Character getStatus() {
            return this.status != null ? this.status : ' ';
        }

        public String getTargetUserId() {
            if (this.targetUserId == null) {
                return " ";
            } else {
                return this.targetUserId.isEmpty() ? " " : this.targetUserId;
            }
        }

        public String getForbidRoomCode() {
            if (this.forbidRoomCode == null) {
                return " ";
            } else {
                return this.forbidRoomCode.isEmpty() ? " " : this.forbidRoomCode;
            }
        }

        public String getOperRoles() {
            if (this.operRoles == null) {
                return " ";
            } else {
                return this.operRoles.isEmpty() ? " " : this.operRoles;
            }
        }

        public String getAuthRoles() {
            if (this.authRoles == null) {
                return " ";
            } else {
                return this.authRoles.isEmpty() ? " " : this.authRoles;
            }
        }

        public Integer getUpdateDate() {
            return this.updateDate != null ? this.updateDate : 0;
        }

        public Integer getUpdateTime() {
            return this.updateTime != null ? this.updateTime : 0;
        }

        public void setUserId(String userId) {
            this.userId = userId;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setEnAssetProp(String enAssetProp) {
            this.enAssetProp = enAssetProp;
        }

        public void setEnStockType(String enStockType) {
            this.enStockType = enStockType;
        }

        public void setEnRoomCode(String enRoomCode) {
            this.enRoomCode = enRoomCode;
        }

        public void setEnEntrustWay(String enEntrustWay) {
            this.enEntrustWay = enEntrustWay;
        }

        public void setOperatorRights(String operatorRights) {
            this.operatorRights = operatorRights;
        }

        public void setEnExchangeType(String enExchangeType) {
            this.enExchangeType = enExchangeType;
        }

        public void setEnContractType(String enContractType) {
            this.enContractType = enContractType;
        }

        public void setEnClientGroup(String enClientGroup) {
            this.enClientGroup = enClientGroup;
        }

        public void setEnBankNo(String enBankNo) {
            this.enBankNo = enBankNo;
        }

        public void setEnMoneyType(String enMoneyType) {
            this.enMoneyType = enMoneyType;
        }

        public void setForbidClientGroup(String forbidClientGroup) {
            this.forbidClientGroup = forbidClientGroup;
        }

        public void setStatus(Character status) {
            this.status = status;
        }

        public void setTargetUserId(String targetUserId) {
            this.targetUserId = targetUserId;
        }

        public void setForbidRoomCode(String forbidRoomCode) {
            this.forbidRoomCode = forbidRoomCode;
        }

        public void setOperRoles(String operRoles) {
            this.operRoles = operRoles;
        }

        public void setAuthRoles(String authRoles) {
            this.authRoles = authRoles;
        }

        public void setUpdateDate(Integer updateDate) {
            this.updateDate = updateDate;
        }

        public void setUpdateTime(Integer updateTime) {
            this.updateTime = updateTime;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetUserrightListByBranchNoInnerOutput:(");
            buffer.append("userId:" + this.userId);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",enAssetProp:" + this.enAssetProp);
            buffer.append(",enStockType:" + this.enStockType);
            buffer.append(",enRoomCode:" + this.enRoomCode);
            buffer.append(",enEntrustWay:" + this.enEntrustWay);
            buffer.append(",operatorRights:" + this.operatorRights);
            buffer.append(",enExchangeType:" + this.enExchangeType);
            buffer.append(",enContractType:" + this.enContractType);
            buffer.append(",enClientGroup:" + this.enClientGroup);
            buffer.append(",enBankNo:" + this.enBankNo);
            buffer.append(",enMoneyType:" + this.enMoneyType);
            buffer.append(",forbidClientGroup:" + this.forbidClientGroup);
            buffer.append(",status:" + this.status);
            buffer.append(",targetUserId:" + this.targetUserId);
            buffer.append(",forbidRoomCode:" + this.forbidRoomCode);
            buffer.append(",operRoles:" + this.operRoles);
            buffer.append(",authRoles:" + this.authRoles);
            buffer.append(",updateDate:" + this.updateDate);
            buffer.append(",updateTime:" + this.updateTime);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.userId);
            builder.append(this.branchNo);
            builder.append(this.enAssetProp);
            builder.append(this.enStockType);
            builder.append(this.enRoomCode);
            builder.append(this.enEntrustWay);
            builder.append(this.operatorRights);
            builder.append(this.enExchangeType);
            builder.append(this.enContractType);
            builder.append(this.enClientGroup);
            builder.append(this.enBankNo);
            builder.append(this.enMoneyType);
            builder.append(this.forbidClientGroup);
            builder.append(this.status);
            builder.append(this.targetUserId);
            builder.append(this.forbidRoomCode);
            builder.append(this.operRoles);
            builder.append(this.authRoles);
            builder.append(this.updateDate);
            builder.append(this.updateTime);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetUserrightListByBranchNoInnerOutput) {
                InnerPbsService.GetUserrightListByBranchNoInnerOutput test = (InnerPbsService.GetUserrightListByBranchNoInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.userId, test.userId);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.enAssetProp, test.enAssetProp);
                builder.append(this.enStockType, test.enStockType);
                builder.append(this.enRoomCode, test.enRoomCode);
                builder.append(this.enEntrustWay, test.enEntrustWay);
                builder.append(this.operatorRights, test.operatorRights);
                builder.append(this.enExchangeType, test.enExchangeType);
                builder.append(this.enContractType, test.enContractType);
                builder.append(this.enClientGroup, test.enClientGroup);
                builder.append(this.enBankNo, test.enBankNo);
                builder.append(this.enMoneyType, test.enMoneyType);
                builder.append(this.forbidClientGroup, test.forbidClientGroup);
                builder.append(this.status, test.status);
                builder.append(this.targetUserId, test.targetUserId);
                builder.append(this.forbidRoomCode, test.forbidRoomCode);
                builder.append(this.operRoles, test.operRoles);
                builder.append(this.authRoles, test.authRoles);
                builder.append(this.updateDate, test.updateDate);
                builder.append(this.updateTime, test.updateTime);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetUserrightListByBranchNoInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer branchNo = 0;

        public GetUserrightListByBranchNoInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetUserrightListByBranchNoInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.branchNo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetUserrightListByBranchNoInnerInput) {
                InnerPbsService.GetUserrightListByBranchNoInnerInput test = (InnerPbsService.GetUserrightListByBranchNoInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.branchNo, test.branchNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetUserrightListByBranchNoOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String userId = " ";
        private Integer branchNo = 0;
        private String enAssetProp = " ";
        private String enStockType = " ";
        private String enRoomCode = " ";
        private String enEntrustWay = " ";
        private String operatorRights = " ";
        private String enExchangeType = " ";
        private String enContractType = " ";
        private String enClientGroup = " ";
        private String enBankNo = " ";
        private String enMoneyType = " ";
        private String forbidClientGroup = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character status = ' ';
        private String targetUserId = " ";
        private String forbidRoomCode = " ";
        private String operRoles = " ";
        private String authRoles = " ";
        private Integer updateDate = 0;
        private Integer updateTime = 0;

        public GetUserrightListByBranchNoOutput() {
        }

        public String getUserId() {
            if (this.userId == null) {
                return " ";
            } else {
                return this.userId.isEmpty() ? " " : this.userId;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getEnAssetProp() {
            if (this.enAssetProp == null) {
                return " ";
            } else {
                return this.enAssetProp.isEmpty() ? " " : this.enAssetProp;
            }
        }

        public String getEnStockType() {
            if (this.enStockType == null) {
                return " ";
            } else {
                return this.enStockType.isEmpty() ? " " : this.enStockType;
            }
        }

        public String getEnRoomCode() {
            if (this.enRoomCode == null) {
                return " ";
            } else {
                return this.enRoomCode.isEmpty() ? " " : this.enRoomCode;
            }
        }

        public String getEnEntrustWay() {
            if (this.enEntrustWay == null) {
                return " ";
            } else {
                return this.enEntrustWay.isEmpty() ? " " : this.enEntrustWay;
            }
        }

        public String getOperatorRights() {
            if (this.operatorRights == null) {
                return " ";
            } else {
                return this.operatorRights.isEmpty() ? " " : this.operatorRights;
            }
        }

        public String getEnExchangeType() {
            if (this.enExchangeType == null) {
                return " ";
            } else {
                return this.enExchangeType.isEmpty() ? " " : this.enExchangeType;
            }
        }

        public String getEnContractType() {
            if (this.enContractType == null) {
                return " ";
            } else {
                return this.enContractType.isEmpty() ? " " : this.enContractType;
            }
        }

        public String getEnClientGroup() {
            if (this.enClientGroup == null) {
                return " ";
            } else {
                return this.enClientGroup.isEmpty() ? " " : this.enClientGroup;
            }
        }

        public String getEnBankNo() {
            if (this.enBankNo == null) {
                return " ";
            } else {
                return this.enBankNo.isEmpty() ? " " : this.enBankNo;
            }
        }

        public String getEnMoneyType() {
            if (this.enMoneyType == null) {
                return " ";
            } else {
                return this.enMoneyType.isEmpty() ? " " : this.enMoneyType;
            }
        }

        public String getForbidClientGroup() {
            if (this.forbidClientGroup == null) {
                return " ";
            } else {
                return this.forbidClientGroup.isEmpty() ? " " : this.forbidClientGroup;
            }
        }

        public Character getStatus() {
            return this.status != null ? this.status : ' ';
        }

        public String getTargetUserId() {
            if (this.targetUserId == null) {
                return " ";
            } else {
                return this.targetUserId.isEmpty() ? " " : this.targetUserId;
            }
        }

        public String getForbidRoomCode() {
            if (this.forbidRoomCode == null) {
                return " ";
            } else {
                return this.forbidRoomCode.isEmpty() ? " " : this.forbidRoomCode;
            }
        }

        public String getOperRoles() {
            if (this.operRoles == null) {
                return " ";
            } else {
                return this.operRoles.isEmpty() ? " " : this.operRoles;
            }
        }

        public String getAuthRoles() {
            if (this.authRoles == null) {
                return " ";
            } else {
                return this.authRoles.isEmpty() ? " " : this.authRoles;
            }
        }

        public Integer getUpdateDate() {
            return this.updateDate != null ? this.updateDate : 0;
        }

        public Integer getUpdateTime() {
            return this.updateTime != null ? this.updateTime : 0;
        }

        public void setUserId(String userId) {
            this.userId = userId;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setEnAssetProp(String enAssetProp) {
            this.enAssetProp = enAssetProp;
        }

        public void setEnStockType(String enStockType) {
            this.enStockType = enStockType;
        }

        public void setEnRoomCode(String enRoomCode) {
            this.enRoomCode = enRoomCode;
        }

        public void setEnEntrustWay(String enEntrustWay) {
            this.enEntrustWay = enEntrustWay;
        }

        public void setOperatorRights(String operatorRights) {
            this.operatorRights = operatorRights;
        }

        public void setEnExchangeType(String enExchangeType) {
            this.enExchangeType = enExchangeType;
        }

        public void setEnContractType(String enContractType) {
            this.enContractType = enContractType;
        }

        public void setEnClientGroup(String enClientGroup) {
            this.enClientGroup = enClientGroup;
        }

        public void setEnBankNo(String enBankNo) {
            this.enBankNo = enBankNo;
        }

        public void setEnMoneyType(String enMoneyType) {
            this.enMoneyType = enMoneyType;
        }

        public void setForbidClientGroup(String forbidClientGroup) {
            this.forbidClientGroup = forbidClientGroup;
        }

        public void setStatus(Character status) {
            this.status = status;
        }

        public void setTargetUserId(String targetUserId) {
            this.targetUserId = targetUserId;
        }

        public void setForbidRoomCode(String forbidRoomCode) {
            this.forbidRoomCode = forbidRoomCode;
        }

        public void setOperRoles(String operRoles) {
            this.operRoles = operRoles;
        }

        public void setAuthRoles(String authRoles) {
            this.authRoles = authRoles;
        }

        public void setUpdateDate(Integer updateDate) {
            this.updateDate = updateDate;
        }

        public void setUpdateTime(Integer updateTime) {
            this.updateTime = updateTime;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetUserrightListByBranchNoOutput:(");
            buffer.append("userId:" + this.userId);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",enAssetProp:" + this.enAssetProp);
            buffer.append(",enStockType:" + this.enStockType);
            buffer.append(",enRoomCode:" + this.enRoomCode);
            buffer.append(",enEntrustWay:" + this.enEntrustWay);
            buffer.append(",operatorRights:" + this.operatorRights);
            buffer.append(",enExchangeType:" + this.enExchangeType);
            buffer.append(",enContractType:" + this.enContractType);
            buffer.append(",enClientGroup:" + this.enClientGroup);
            buffer.append(",enBankNo:" + this.enBankNo);
            buffer.append(",enMoneyType:" + this.enMoneyType);
            buffer.append(",forbidClientGroup:" + this.forbidClientGroup);
            buffer.append(",status:" + this.status);
            buffer.append(",targetUserId:" + this.targetUserId);
            buffer.append(",forbidRoomCode:" + this.forbidRoomCode);
            buffer.append(",operRoles:" + this.operRoles);
            buffer.append(",authRoles:" + this.authRoles);
            buffer.append(",updateDate:" + this.updateDate);
            buffer.append(",updateTime:" + this.updateTime);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.userId);
            builder.append(this.branchNo);
            builder.append(this.enAssetProp);
            builder.append(this.enStockType);
            builder.append(this.enRoomCode);
            builder.append(this.enEntrustWay);
            builder.append(this.operatorRights);
            builder.append(this.enExchangeType);
            builder.append(this.enContractType);
            builder.append(this.enClientGroup);
            builder.append(this.enBankNo);
            builder.append(this.enMoneyType);
            builder.append(this.forbidClientGroup);
            builder.append(this.status);
            builder.append(this.targetUserId);
            builder.append(this.forbidRoomCode);
            builder.append(this.operRoles);
            builder.append(this.authRoles);
            builder.append(this.updateDate);
            builder.append(this.updateTime);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetUserrightListByBranchNoOutput) {
                InnerPbsService.GetUserrightListByBranchNoOutput test = (InnerPbsService.GetUserrightListByBranchNoOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.userId, test.userId);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.enAssetProp, test.enAssetProp);
                builder.append(this.enStockType, test.enStockType);
                builder.append(this.enRoomCode, test.enRoomCode);
                builder.append(this.enEntrustWay, test.enEntrustWay);
                builder.append(this.operatorRights, test.operatorRights);
                builder.append(this.enExchangeType, test.enExchangeType);
                builder.append(this.enContractType, test.enContractType);
                builder.append(this.enClientGroup, test.enClientGroup);
                builder.append(this.enBankNo, test.enBankNo);
                builder.append(this.enMoneyType, test.enMoneyType);
                builder.append(this.forbidClientGroup, test.forbidClientGroup);
                builder.append(this.status, test.status);
                builder.append(this.targetUserId, test.targetUserId);
                builder.append(this.forbidRoomCode, test.forbidRoomCode);
                builder.append(this.operRoles, test.operRoles);
                builder.append(this.authRoles, test.authRoles);
                builder.append(this.updateDate, test.updateDate);
                builder.append(this.updateTime, test.updateTime);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetUserrightListByBranchNoInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer branchNo = 0;

        public GetUserrightListByBranchNoInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetUserrightListByBranchNoInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.branchNo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetUserrightListByBranchNoInput) {
                InnerPbsService.GetUserrightListByBranchNoInput test = (InnerPbsService.GetUserrightListByBranchNoInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.branchNo, test.branchNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetUserrightInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String userId = " ";
        private Integer branchNo = 0;
        private String operatorRights = " ";
        private String enClientGroup = " ";
        private String enRoomCode = " ";
        private String enExchangeType = " ";
        private String enStockType = " ";
        private String enContractType = " ";
        private String enEntrustWay = " ";
        private String enBankNo = " ";
        private String enMoneyType = " ";
        private String enAssetProp = " ";
        private String forbidClientGroup = " ";
        private String forbidRoomCode = " ";
        private String operRoles = " ";
        private String authRoles = " ";
        private String enClientProp = " ";

        public GetUserrightInnerOutput() {
        }

        public String getUserId() {
            if (this.userId == null) {
                return " ";
            } else {
                return this.userId.isEmpty() ? " " : this.userId;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getOperatorRights() {
            if (this.operatorRights == null) {
                return " ";
            } else {
                return this.operatorRights.isEmpty() ? " " : this.operatorRights;
            }
        }

        public String getEnClientGroup() {
            if (this.enClientGroup == null) {
                return " ";
            } else {
                return this.enClientGroup.isEmpty() ? " " : this.enClientGroup;
            }
        }

        public String getEnRoomCode() {
            if (this.enRoomCode == null) {
                return " ";
            } else {
                return this.enRoomCode.isEmpty() ? " " : this.enRoomCode;
            }
        }

        public String getEnExchangeType() {
            if (this.enExchangeType == null) {
                return " ";
            } else {
                return this.enExchangeType.isEmpty() ? " " : this.enExchangeType;
            }
        }

        public String getEnStockType() {
            if (this.enStockType == null) {
                return " ";
            } else {
                return this.enStockType.isEmpty() ? " " : this.enStockType;
            }
        }

        public String getEnContractType() {
            if (this.enContractType == null) {
                return " ";
            } else {
                return this.enContractType.isEmpty() ? " " : this.enContractType;
            }
        }

        public String getEnEntrustWay() {
            if (this.enEntrustWay == null) {
                return " ";
            } else {
                return this.enEntrustWay.isEmpty() ? " " : this.enEntrustWay;
            }
        }

        public String getEnBankNo() {
            if (this.enBankNo == null) {
                return " ";
            } else {
                return this.enBankNo.isEmpty() ? " " : this.enBankNo;
            }
        }

        public String getEnMoneyType() {
            if (this.enMoneyType == null) {
                return " ";
            } else {
                return this.enMoneyType.isEmpty() ? " " : this.enMoneyType;
            }
        }

        public String getEnAssetProp() {
            if (this.enAssetProp == null) {
                return " ";
            } else {
                return this.enAssetProp.isEmpty() ? " " : this.enAssetProp;
            }
        }

        public String getForbidClientGroup() {
            if (this.forbidClientGroup == null) {
                return " ";
            } else {
                return this.forbidClientGroup.isEmpty() ? " " : this.forbidClientGroup;
            }
        }

        public String getForbidRoomCode() {
            if (this.forbidRoomCode == null) {
                return " ";
            } else {
                return this.forbidRoomCode.isEmpty() ? " " : this.forbidRoomCode;
            }
        }

        public String getOperRoles() {
            if (this.operRoles == null) {
                return " ";
            } else {
                return this.operRoles.isEmpty() ? " " : this.operRoles;
            }
        }

        public String getAuthRoles() {
            if (this.authRoles == null) {
                return " ";
            } else {
                return this.authRoles.isEmpty() ? " " : this.authRoles;
            }
        }

        public String getEnClientProp() {
            if (this.enClientProp == null) {
                return " ";
            } else {
                return this.enClientProp.isEmpty() ? " " : this.enClientProp;
            }
        }

        public void setUserId(String userId) {
            this.userId = userId;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setOperatorRights(String operatorRights) {
            this.operatorRights = operatorRights;
        }

        public void setEnClientGroup(String enClientGroup) {
            this.enClientGroup = enClientGroup;
        }

        public void setEnRoomCode(String enRoomCode) {
            this.enRoomCode = enRoomCode;
        }

        public void setEnExchangeType(String enExchangeType) {
            this.enExchangeType = enExchangeType;
        }

        public void setEnStockType(String enStockType) {
            this.enStockType = enStockType;
        }

        public void setEnContractType(String enContractType) {
            this.enContractType = enContractType;
        }

        public void setEnEntrustWay(String enEntrustWay) {
            this.enEntrustWay = enEntrustWay;
        }

        public void setEnBankNo(String enBankNo) {
            this.enBankNo = enBankNo;
        }

        public void setEnMoneyType(String enMoneyType) {
            this.enMoneyType = enMoneyType;
        }

        public void setEnAssetProp(String enAssetProp) {
            this.enAssetProp = enAssetProp;
        }

        public void setForbidClientGroup(String forbidClientGroup) {
            this.forbidClientGroup = forbidClientGroup;
        }

        public void setForbidRoomCode(String forbidRoomCode) {
            this.forbidRoomCode = forbidRoomCode;
        }

        public void setOperRoles(String operRoles) {
            this.operRoles = operRoles;
        }

        public void setAuthRoles(String authRoles) {
            this.authRoles = authRoles;
        }

        public void setEnClientProp(String enClientProp) {
            this.enClientProp = enClientProp;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetUserrightInnerOutput:(");
            buffer.append("userId:" + this.userId);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",operatorRights:" + this.operatorRights);
            buffer.append(",enClientGroup:" + this.enClientGroup);
            buffer.append(",enRoomCode:" + this.enRoomCode);
            buffer.append(",enExchangeType:" + this.enExchangeType);
            buffer.append(",enStockType:" + this.enStockType);
            buffer.append(",enContractType:" + this.enContractType);
            buffer.append(",enEntrustWay:" + this.enEntrustWay);
            buffer.append(",enBankNo:" + this.enBankNo);
            buffer.append(",enMoneyType:" + this.enMoneyType);
            buffer.append(",enAssetProp:" + this.enAssetProp);
            buffer.append(",forbidClientGroup:" + this.forbidClientGroup);
            buffer.append(",forbidRoomCode:" + this.forbidRoomCode);
            buffer.append(",operRoles:" + this.operRoles);
            buffer.append(",authRoles:" + this.authRoles);
            buffer.append(",enClientProp:" + this.enClientProp);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.userId);
            builder.append(this.branchNo);
            builder.append(this.operatorRights);
            builder.append(this.enClientGroup);
            builder.append(this.enRoomCode);
            builder.append(this.enExchangeType);
            builder.append(this.enStockType);
            builder.append(this.enContractType);
            builder.append(this.enEntrustWay);
            builder.append(this.enBankNo);
            builder.append(this.enMoneyType);
            builder.append(this.enAssetProp);
            builder.append(this.forbidClientGroup);
            builder.append(this.forbidRoomCode);
            builder.append(this.operRoles);
            builder.append(this.authRoles);
            builder.append(this.enClientProp);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetUserrightInnerOutput) {
                InnerPbsService.GetUserrightInnerOutput test = (InnerPbsService.GetUserrightInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.userId, test.userId);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.operatorRights, test.operatorRights);
                builder.append(this.enClientGroup, test.enClientGroup);
                builder.append(this.enRoomCode, test.enRoomCode);
                builder.append(this.enExchangeType, test.enExchangeType);
                builder.append(this.enStockType, test.enStockType);
                builder.append(this.enContractType, test.enContractType);
                builder.append(this.enEntrustWay, test.enEntrustWay);
                builder.append(this.enBankNo, test.enBankNo);
                builder.append(this.enMoneyType, test.enMoneyType);
                builder.append(this.enAssetProp, test.enAssetProp);
                builder.append(this.forbidClientGroup, test.forbidClientGroup);
                builder.append(this.forbidRoomCode, test.forbidRoomCode);
                builder.append(this.operRoles, test.operRoles);
                builder.append(this.authRoles, test.authRoles);
                builder.append(this.enClientProp, test.enClientProp);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetUserrightInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 1,
                max = 32,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String userId = " ";
        @NotNull(
                message = "不能为空"
        )
        private Integer branchNo = 0;
        private Integer clientBranchNo = 0;
        @SinogramLength(
                min = 1,
                max = 64,
                charset = "utf-8"
        )
        private String menuCode = " ";
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        private String clientId = " ";

        public GetUserrightInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getUserId() {
            if (this.userId == null) {
                return " ";
            } else {
                return this.userId.isEmpty() ? " " : this.userId;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Integer getClientBranchNo() {
            return this.clientBranchNo != null ? this.clientBranchNo : 0;
        }

        public String getMenuCode() {
            if (this.menuCode == null) {
                return " ";
            } else {
                return this.menuCode.isEmpty() ? " " : this.menuCode;
            }
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setUserId(String userId) {
            this.userId = userId;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setClientBranchNo(Integer clientBranchNo) {
            this.clientBranchNo = clientBranchNo;
        }

        public void setMenuCode(String menuCode) {
            this.menuCode = menuCode;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetUserrightInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",userId:" + this.userId);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",clientBranchNo:" + this.clientBranchNo);
            buffer.append(",menuCode:" + this.menuCode);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.userId);
            builder.append(this.branchNo);
            builder.append(this.clientBranchNo);
            builder.append(this.menuCode);
            builder.append(this.clientId);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetUserrightInnerInput) {
                InnerPbsService.GetUserrightInnerInput test = (InnerPbsService.GetUserrightInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.userId, test.userId);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.clientBranchNo, test.clientBranchNo);
                builder.append(this.menuCode, test.menuCode);
                builder.append(this.clientId, test.clientId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetUserrightDictInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String userId = " ";
        private String enAssetProp = " ";
        private String enStockType = " ";
        private String enRoomCode = " ";
        private String enEntrustWay = " ";
        private String enExchangeType = " ";
        private String enContractType = " ";
        private String enClientGroup = " ";
        private String enBankNo = " ";
        private String enMoneyType = " ";

        public GetUserrightDictInnerOutput() {
        }

        public String getUserId() {
            if (this.userId == null) {
                return " ";
            } else {
                return this.userId.isEmpty() ? " " : this.userId;
            }
        }

        public String getEnAssetProp() {
            if (this.enAssetProp == null) {
                return " ";
            } else {
                return this.enAssetProp.isEmpty() ? " " : this.enAssetProp;
            }
        }

        public String getEnStockType() {
            if (this.enStockType == null) {
                return " ";
            } else {
                return this.enStockType.isEmpty() ? " " : this.enStockType;
            }
        }

        public String getEnRoomCode() {
            if (this.enRoomCode == null) {
                return " ";
            } else {
                return this.enRoomCode.isEmpty() ? " " : this.enRoomCode;
            }
        }

        public String getEnEntrustWay() {
            if (this.enEntrustWay == null) {
                return " ";
            } else {
                return this.enEntrustWay.isEmpty() ? " " : this.enEntrustWay;
            }
        }

        public String getEnExchangeType() {
            if (this.enExchangeType == null) {
                return " ";
            } else {
                return this.enExchangeType.isEmpty() ? " " : this.enExchangeType;
            }
        }

        public String getEnContractType() {
            if (this.enContractType == null) {
                return " ";
            } else {
                return this.enContractType.isEmpty() ? " " : this.enContractType;
            }
        }

        public String getEnClientGroup() {
            if (this.enClientGroup == null) {
                return " ";
            } else {
                return this.enClientGroup.isEmpty() ? " " : this.enClientGroup;
            }
        }

        public String getEnBankNo() {
            if (this.enBankNo == null) {
                return " ";
            } else {
                return this.enBankNo.isEmpty() ? " " : this.enBankNo;
            }
        }

        public String getEnMoneyType() {
            if (this.enMoneyType == null) {
                return " ";
            } else {
                return this.enMoneyType.isEmpty() ? " " : this.enMoneyType;
            }
        }

        public void setUserId(String userId) {
            this.userId = userId;
        }

        public void setEnAssetProp(String enAssetProp) {
            this.enAssetProp = enAssetProp;
        }

        public void setEnStockType(String enStockType) {
            this.enStockType = enStockType;
        }

        public void setEnRoomCode(String enRoomCode) {
            this.enRoomCode = enRoomCode;
        }

        public void setEnEntrustWay(String enEntrustWay) {
            this.enEntrustWay = enEntrustWay;
        }

        public void setEnExchangeType(String enExchangeType) {
            this.enExchangeType = enExchangeType;
        }

        public void setEnContractType(String enContractType) {
            this.enContractType = enContractType;
        }

        public void setEnClientGroup(String enClientGroup) {
            this.enClientGroup = enClientGroup;
        }

        public void setEnBankNo(String enBankNo) {
            this.enBankNo = enBankNo;
        }

        public void setEnMoneyType(String enMoneyType) {
            this.enMoneyType = enMoneyType;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetUserrightDictInnerOutput:(");
            buffer.append("userId:" + this.userId);
            buffer.append(",enAssetProp:" + this.enAssetProp);
            buffer.append(",enStockType:" + this.enStockType);
            buffer.append(",enRoomCode:" + this.enRoomCode);
            buffer.append(",enEntrustWay:" + this.enEntrustWay);
            buffer.append(",enExchangeType:" + this.enExchangeType);
            buffer.append(",enContractType:" + this.enContractType);
            buffer.append(",enClientGroup:" + this.enClientGroup);
            buffer.append(",enBankNo:" + this.enBankNo);
            buffer.append(",enMoneyType:" + this.enMoneyType);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.userId);
            builder.append(this.enAssetProp);
            builder.append(this.enStockType);
            builder.append(this.enRoomCode);
            builder.append(this.enEntrustWay);
            builder.append(this.enExchangeType);
            builder.append(this.enContractType);
            builder.append(this.enClientGroup);
            builder.append(this.enBankNo);
            builder.append(this.enMoneyType);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetUserrightDictInnerOutput) {
                InnerPbsService.GetUserrightDictInnerOutput test = (InnerPbsService.GetUserrightDictInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.userId, test.userId);
                builder.append(this.enAssetProp, test.enAssetProp);
                builder.append(this.enStockType, test.enStockType);
                builder.append(this.enRoomCode, test.enRoomCode);
                builder.append(this.enEntrustWay, test.enEntrustWay);
                builder.append(this.enExchangeType, test.enExchangeType);
                builder.append(this.enContractType, test.enContractType);
                builder.append(this.enClientGroup, test.enClientGroup);
                builder.append(this.enBankNo, test.enBankNo);
                builder.append(this.enMoneyType, test.enMoneyType);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetUserrightDictInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';

        public GetUserrightDictInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetUserrightDictInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetUserrightDictInnerInput) {
                InnerPbsService.GetUserrightDictInnerInput test = (InnerPbsService.GetUserrightDictInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetUseroperlimitsInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String dealResult = " ";

        public GetUseroperlimitsInnerOutput() {
        }

        public String getDealResult() {
            if (this.dealResult == null) {
                return " ";
            } else {
                return this.dealResult.isEmpty() ? " " : this.dealResult;
            }
        }

        public void setDealResult(String dealResult) {
            this.dealResult = dealResult;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetUseroperlimitsInnerOutput:(");
            buffer.append("dealResult:" + this.dealResult);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.dealResult);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetUseroperlimitsInnerOutput) {
                InnerPbsService.GetUseroperlimitsInnerOutput test = (InnerPbsService.GetUseroperlimitsInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.dealResult, test.dealResult);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetUseroperlimitsInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fundAccount = " ";
        private Integer initDate = 0;
        private Integer mainBranchNo = 0;
        private Integer menuId = 0;
        private Integer opActionIn = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character userType = ' ';

        public GetUseroperlimitsInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public Integer getMainBranchNo() {
            return this.mainBranchNo != null ? this.mainBranchNo : 0;
        }

        public Integer getMenuId() {
            return this.menuId != null ? this.menuId : 0;
        }

        public Integer getOpActionIn() {
            return this.opActionIn != null ? this.opActionIn : 0;
        }

        public Character getUserType() {
            return this.userType != null ? this.userType : ' ';
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public void setMainBranchNo(Integer mainBranchNo) {
            this.mainBranchNo = mainBranchNo;
        }

        public void setMenuId(Integer menuId) {
            this.menuId = menuId;
        }

        public void setOpActionIn(Integer opActionIn) {
            this.opActionIn = opActionIn;
        }

        public void setUserType(Character userType) {
            this.userType = userType;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetUseroperlimitsInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",initDate:" + this.initDate);
            buffer.append(",mainBranchNo:" + this.mainBranchNo);
            buffer.append(",menuId:" + this.menuId);
            buffer.append(",opActionIn:" + this.opActionIn);
            buffer.append(",userType:" + this.userType);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.fundAccount);
            builder.append(this.initDate);
            builder.append(this.mainBranchNo);
            builder.append(this.menuId);
            builder.append(this.opActionIn);
            builder.append(this.userType);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetUseroperlimitsInnerInput) {
                InnerPbsService.GetUseroperlimitsInnerInput test = (InnerPbsService.GetUseroperlimitsInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.initDate, test.initDate);
                builder.append(this.mainBranchNo, test.mainBranchNo);
                builder.append(this.menuId, test.menuId);
                builder.append(this.opActionIn, test.opActionIn);
                builder.append(this.userType, test.userType);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetUserPwdStandardInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer minLength = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character kindLength = ' ';

        public GetUserPwdStandardInnerOutput() {
        }

        public Integer getMinLength() {
            return this.minLength != null ? this.minLength : 0;
        }

        public Character getKindLength() {
            return this.kindLength != null ? this.kindLength : ' ';
        }

        public void setMinLength(Integer minLength) {
            this.minLength = minLength;
        }

        public void setKindLength(Character kindLength) {
            this.kindLength = kindLength;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetUserPwdStandardInnerOutput:(");
            buffer.append("minLength:" + this.minLength);
            buffer.append(",kindLength:" + this.kindLength);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.minLength);
            builder.append(this.kindLength);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetUserPwdStandardInnerOutput) {
                InnerPbsService.GetUserPwdStandardInnerOutput test = (InnerPbsService.GetUserPwdStandardInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.minLength, test.minLength);
                builder.append(this.kindLength, test.kindLength);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetUserPwdStandardInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';

        public GetUserPwdStandardInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetUserPwdStandardInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetUserPwdStandardInnerInput) {
                InnerPbsService.GetUserPwdStandardInnerInput test = (InnerPbsService.GetUserPwdStandardInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetUserPwdExpiredCheckInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String resultCode = " ";

        public GetUserPwdExpiredCheckInnerOutput() {
        }

        public String getResultCode() {
            if (this.resultCode == null) {
                return " ";
            } else {
                return this.resultCode.isEmpty() ? " " : this.resultCode;
            }
        }

        public void setResultCode(String resultCode) {
            this.resultCode = resultCode;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetUserPwdExpiredCheckInnerOutput:(");
            buffer.append("resultCode:" + this.resultCode);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.resultCode);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetUserPwdExpiredCheckInnerOutput) {
                InnerPbsService.GetUserPwdExpiredCheckInnerOutput test = (InnerPbsService.GetUserPwdExpiredCheckInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.resultCode, test.resultCode);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetUserPwdExpiredCheckInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';

        public GetUserPwdExpiredCheckInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetUserPwdExpiredCheckInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetUserPwdExpiredCheckInnerInput) {
                InnerPbsService.GetUserPwdExpiredCheckInnerInput test = (InnerPbsService.GetUserPwdExpiredCheckInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetUserPermissionsInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String menuCode = " ";
        private String functionCode = " ";

        public GetUserPermissionsInnerOutput() {
        }

        public String getMenuCode() {
            if (this.menuCode == null) {
                return " ";
            } else {
                return this.menuCode.isEmpty() ? " " : this.menuCode;
            }
        }

        public String getFunctionCode() {
            if (this.functionCode == null) {
                return " ";
            } else {
                return this.functionCode.isEmpty() ? " " : this.functionCode;
            }
        }

        public void setMenuCode(String menuCode) {
            this.menuCode = menuCode;
        }

        public void setFunctionCode(String functionCode) {
            this.functionCode = functionCode;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetUserPermissionsInnerOutput:(");
            buffer.append("menuCode:" + this.menuCode);
            buffer.append(",functionCode:" + this.functionCode);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.menuCode);
            builder.append(this.functionCode);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetUserPermissionsInnerOutput) {
                InnerPbsService.GetUserPermissionsInnerOutput test = (InnerPbsService.GetUserPermissionsInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.menuCode, test.menuCode);
                builder.append(this.functionCode, test.functionCode);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetUserPermissionsInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 64,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String token = " ";

        public GetUserPermissionsInnerInput() {
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getToken() {
            if (this.token == null) {
                return " ";
            } else {
                return this.token.isEmpty() ? " " : this.token;
            }
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setToken(String token) {
            this.token = token;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetUserPermissionsInnerInput:(");
            buffer.append("operatorNo:" + this.operatorNo);
            buffer.append(",token:" + this.token);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.operatorNo);
            builder.append(this.token);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetUserPermissionsInnerInput) {
                InnerPbsService.GetUserPermissionsInnerInput test = (InnerPbsService.GetUserPermissionsInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.token, test.token);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetUserPasswordCheckInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String errorCode = " ";
        private String errorInfo = " ";

        public GetUserPasswordCheckInnerOutput() {
        }

        public String getErrorCode() {
            if (this.errorCode == null) {
                return " ";
            } else {
                return this.errorCode.isEmpty() ? " " : this.errorCode;
            }
        }

        public String getErrorInfo() {
            if (this.errorInfo == null) {
                return " ";
            } else {
                return this.errorInfo.isEmpty() ? " " : this.errorInfo;
            }
        }

        public void setErrorCode(String errorCode) {
            this.errorCode = errorCode;
        }

        public void setErrorInfo(String errorInfo) {
            this.errorInfo = errorInfo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetUserPasswordCheckInnerOutput:(");
            buffer.append("errorCode:" + this.errorCode);
            buffer.append(",errorInfo:" + this.errorInfo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.errorCode);
            builder.append(this.errorInfo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetUserPasswordCheckInnerOutput) {
                InnerPbsService.GetUserPasswordCheckInnerOutput test = (InnerPbsService.GetUserPasswordCheckInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.errorCode, test.errorCode);
                builder.append(this.errorInfo, test.errorInfo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetUserPasswordCheckInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 1,
                max = 32,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String userId = " ";
        @SinogramLength(
                min = 1,
                max = 64,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String password = " ";

        public GetUserPasswordCheckInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getUserId() {
            if (this.userId == null) {
                return " ";
            } else {
                return this.userId.isEmpty() ? " " : this.userId;
            }
        }

        public String getPassword() {
            if (this.password == null) {
                return " ";
            } else {
                return this.password.isEmpty() ? " " : this.password;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setUserId(String userId) {
            this.userId = userId;
        }

        public void setPassword(String password) {
            this.password = password;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetUserPasswordCheckInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",userId:" + this.userId);
            buffer.append(",password:" + this.password);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.userId);
            builder.append(this.password);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetUserPasswordCheckInnerInput) {
                InnerPbsService.GetUserPasswordCheckInnerInput test = (InnerPbsService.GetUserPasswordCheckInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.userId, test.userId);
                builder.append(this.password, test.password);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetUserMenuInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private List<InnerPbsService.TreeHsmenuDTO> menuList = new ArrayList();

        public GetUserMenuInnerOutput() {
        }

        public List<InnerPbsService.TreeHsmenuDTO> getMenuList() {
            return (List)(this.menuList != null ? this.menuList : new ArrayList());
        }

        public void setMenuList(List<InnerPbsService.TreeHsmenuDTO> menuList) {
            this.menuList = menuList;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetUserMenuInnerOutput:(");
            buffer.append("menuList:" + this.menuList);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.menuList);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetUserMenuInnerOutput) {
                InnerPbsService.GetUserMenuInnerOutput test = (InnerPbsService.GetUserMenuInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.menuList, test.menuList);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetUserMenuInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 512,
                charset = "utf-8"
        )
        private String userToken = " ";

        public GetUserMenuInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getUserToken() {
            if (this.userToken == null) {
                return " ";
            } else {
                return this.userToken.isEmpty() ? " " : this.userToken;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setUserToken(String userToken) {
            this.userToken = userToken;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetUserMenuInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",userToken:" + this.userToken);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.userToken);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetUserMenuInnerInput) {
                InnerPbsService.GetUserMenuInnerInput test = (InnerPbsService.GetUserMenuInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.userToken, test.userToken);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetUserListPageInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer total = 0;
        private Integer currentPage = 0;
        private List<InnerPbsService.GetUserListInnerDTO> rows = new ArrayList();

        public GetUserListPageInnerOutput() {
        }

        public Integer getTotal() {
            return this.total != null ? this.total : 0;
        }

        public Integer getCurrentPage() {
            return this.currentPage != null ? this.currentPage : 0;
        }

        public List<InnerPbsService.GetUserListInnerDTO> getRows() {
            return (List)(this.rows != null ? this.rows : new ArrayList());
        }

        public void setTotal(Integer total) {
            this.total = total;
        }

        public void setCurrentPage(Integer currentPage) {
            this.currentPage = currentPage;
        }

        public void setRows(List<InnerPbsService.GetUserListInnerDTO> rows) {
            this.rows = rows;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetUserListPageInnerOutput:(");
            buffer.append("total:" + this.total);
            buffer.append(",currentPage:" + this.currentPage);
            buffer.append(",rows:" + this.rows);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.total);
            builder.append(this.currentPage);
            builder.append(this.rows);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetUserListPageInnerOutput) {
                InnerPbsService.GetUserListPageInnerOutput test = (InnerPbsService.GetUserListPageInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.total, test.total);
                builder.append(this.currentPage, test.currentPage);
                builder.append(this.rows, test.rows);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetUserListPageInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String userId = " ";
        @SinogramLength(
                min = 0,
                max = 60,
                charset = "utf-8"
        )
        private String operatorName = " ";
        private Integer branchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String roleId = " ";
        private Integer pageNo = 0;
        private Integer pageSize = 0;

        public GetUserListPageInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getUserId() {
            if (this.userId == null) {
                return " ";
            } else {
                return this.userId.isEmpty() ? " " : this.userId;
            }
        }

        public String getOperatorName() {
            if (this.operatorName == null) {
                return " ";
            } else {
                return this.operatorName.isEmpty() ? " " : this.operatorName;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getRoleId() {
            if (this.roleId == null) {
                return " ";
            } else {
                return this.roleId.isEmpty() ? " " : this.roleId;
            }
        }

        public Integer getPageNo() {
            return this.pageNo != null ? this.pageNo : 0;
        }

        public Integer getPageSize() {
            return this.pageSize != null ? this.pageSize : 0;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setUserId(String userId) {
            this.userId = userId;
        }

        public void setOperatorName(String operatorName) {
            this.operatorName = operatorName;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setRoleId(String roleId) {
            this.roleId = roleId;
        }

        public void setPageNo(Integer pageNo) {
            this.pageNo = pageNo;
        }

        public void setPageSize(Integer pageSize) {
            this.pageSize = pageSize;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetUserListPageInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",userId:" + this.userId);
            buffer.append(",operatorName:" + this.operatorName);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",roleId:" + this.roleId);
            buffer.append(",pageNo:" + this.pageNo);
            buffer.append(",pageSize:" + this.pageSize);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.userId);
            builder.append(this.operatorName);
            builder.append(this.branchNo);
            builder.append(this.roleId);
            builder.append(this.pageNo);
            builder.append(this.pageSize);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetUserListPageInnerInput) {
                InnerPbsService.GetUserListPageInnerInput test = (InnerPbsService.GetUserListPageInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.userId, test.userId);
                builder.append(this.operatorName, test.operatorName);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.roleId, test.roleId);
                builder.append(this.pageNo, test.pageNo);
                builder.append(this.pageSize, test.pageSize);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetUserListInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String userId = " ";
        private String operatorName = " ";
        private Integer branchNo = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character idKind = ' ';
        private String idNo = " ";
        private String emailAddress = " ";
        private String mobileTel = " ";
        private String telephone = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character userType = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character userStatus = ' ';

        public GetUserListInnerOutput() {
        }

        public String getUserId() {
            if (this.userId == null) {
                return " ";
            } else {
                return this.userId.isEmpty() ? " " : this.userId;
            }
        }

        public String getOperatorName() {
            if (this.operatorName == null) {
                return " ";
            } else {
                return this.operatorName.isEmpty() ? " " : this.operatorName;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Character getIdKind() {
            return this.idKind != null ? this.idKind : ' ';
        }

        public String getIdNo() {
            if (this.idNo == null) {
                return " ";
            } else {
                return this.idNo.isEmpty() ? " " : this.idNo;
            }
        }

        public String getEmailAddress() {
            if (this.emailAddress == null) {
                return " ";
            } else {
                return this.emailAddress.isEmpty() ? " " : this.emailAddress;
            }
        }

        public String getMobileTel() {
            if (this.mobileTel == null) {
                return " ";
            } else {
                return this.mobileTel.isEmpty() ? " " : this.mobileTel;
            }
        }

        public String getTelephone() {
            if (this.telephone == null) {
                return " ";
            } else {
                return this.telephone.isEmpty() ? " " : this.telephone;
            }
        }

        public Character getUserType() {
            return this.userType != null ? this.userType : ' ';
        }

        public Character getUserStatus() {
            return this.userStatus != null ? this.userStatus : ' ';
        }

        public void setUserId(String userId) {
            this.userId = userId;
        }

        public void setOperatorName(String operatorName) {
            this.operatorName = operatorName;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setIdKind(Character idKind) {
            this.idKind = idKind;
        }

        public void setIdNo(String idNo) {
            this.idNo = idNo;
        }

        public void setEmailAddress(String emailAddress) {
            this.emailAddress = emailAddress;
        }

        public void setMobileTel(String mobileTel) {
            this.mobileTel = mobileTel;
        }

        public void setTelephone(String telephone) {
            this.telephone = telephone;
        }

        public void setUserType(Character userType) {
            this.userType = userType;
        }

        public void setUserStatus(Character userStatus) {
            this.userStatus = userStatus;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetUserListInnerOutput:(");
            buffer.append("userId:" + this.userId);
            buffer.append(",operatorName:" + this.operatorName);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",idKind:" + this.idKind);
            buffer.append(",idNo:" + this.idNo);
            buffer.append(",emailAddress:" + this.emailAddress);
            buffer.append(",mobileTel:" + this.mobileTel);
            buffer.append(",telephone:" + this.telephone);
            buffer.append(",userType:" + this.userType);
            buffer.append(",userStatus:" + this.userStatus);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.userId);
            builder.append(this.operatorName);
            builder.append(this.branchNo);
            builder.append(this.idKind);
            builder.append(this.idNo);
            builder.append(this.emailAddress);
            builder.append(this.mobileTel);
            builder.append(this.telephone);
            builder.append(this.userType);
            builder.append(this.userStatus);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetUserListInnerOutput) {
                InnerPbsService.GetUserListInnerOutput test = (InnerPbsService.GetUserListInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.userId, test.userId);
                builder.append(this.operatorName, test.operatorName);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.idKind, test.idKind);
                builder.append(this.idNo, test.idNo);
                builder.append(this.emailAddress, test.emailAddress);
                builder.append(this.mobileTel, test.mobileTel);
                builder.append(this.telephone, test.telephone);
                builder.append(this.userType, test.userType);
                builder.append(this.userStatus, test.userStatus);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetUserListInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String userId = " ";
        @SinogramLength(
                min = 0,
                max = 60,
                charset = "utf-8"
        )
        private String operatorName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character userStatus = ' ';
        private Integer branchNo = 0;

        public GetUserListInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getUserId() {
            if (this.userId == null) {
                return " ";
            } else {
                return this.userId.isEmpty() ? " " : this.userId;
            }
        }

        public String getOperatorName() {
            if (this.operatorName == null) {
                return " ";
            } else {
                return this.operatorName.isEmpty() ? " " : this.operatorName;
            }
        }

        public Character getUserStatus() {
            return this.userStatus != null ? this.userStatus : ' ';
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setUserId(String userId) {
            this.userId = userId;
        }

        public void setOperatorName(String operatorName) {
            this.operatorName = operatorName;
        }

        public void setUserStatus(Character userStatus) {
            this.userStatus = userStatus;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetUserListInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",userId:" + this.userId);
            buffer.append(",operatorName:" + this.operatorName);
            buffer.append(",userStatus:" + this.userStatus);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.userId);
            builder.append(this.operatorName);
            builder.append(this.userStatus);
            builder.append(this.branchNo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetUserListInnerInput) {
                InnerPbsService.GetUserListInnerInput test = (InnerPbsService.GetUserListInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.userId, test.userId);
                builder.append(this.operatorName, test.operatorName);
                builder.append(this.userStatus, test.userStatus);
                builder.append(this.branchNo, test.branchNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetUserListBySearchIdInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String userId = " ";
        private String userName = " ";
        private String mobile = " ";
        private String email = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character userStatus = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character userType = ' ';

        public GetUserListBySearchIdInnerOutput() {
        }

        public String getUserId() {
            if (this.userId == null) {
                return " ";
            } else {
                return this.userId.isEmpty() ? " " : this.userId;
            }
        }

        public String getUserName() {
            if (this.userName == null) {
                return " ";
            } else {
                return this.userName.isEmpty() ? " " : this.userName;
            }
        }

        public String getMobile() {
            if (this.mobile == null) {
                return " ";
            } else {
                return this.mobile.isEmpty() ? " " : this.mobile;
            }
        }

        public String getEmail() {
            if (this.email == null) {
                return " ";
            } else {
                return this.email.isEmpty() ? " " : this.email;
            }
        }

        public Character getUserStatus() {
            return this.userStatus != null ? this.userStatus : ' ';
        }

        public Character getUserType() {
            return this.userType != null ? this.userType : ' ';
        }

        public void setUserId(String userId) {
            this.userId = userId;
        }

        public void setUserName(String userName) {
            this.userName = userName;
        }

        public void setMobile(String mobile) {
            this.mobile = mobile;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        public void setUserStatus(Character userStatus) {
            this.userStatus = userStatus;
        }

        public void setUserType(Character userType) {
            this.userType = userType;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetUserListBySearchIdInnerOutput:(");
            buffer.append("userId:" + this.userId);
            buffer.append(",userName:" + this.userName);
            buffer.append(",mobile:" + this.mobile);
            buffer.append(",email:" + this.email);
            buffer.append(",userStatus:" + this.userStatus);
            buffer.append(",userType:" + this.userType);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.userId);
            builder.append(this.userName);
            builder.append(this.mobile);
            builder.append(this.email);
            builder.append(this.userStatus);
            builder.append(this.userType);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetUserListBySearchIdInnerOutput) {
                InnerPbsService.GetUserListBySearchIdInnerOutput test = (InnerPbsService.GetUserListBySearchIdInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.userId, test.userId);
                builder.append(this.userName, test.userName);
                builder.append(this.mobile, test.mobile);
                builder.append(this.email, test.email);
                builder.append(this.userStatus, test.userStatus);
                builder.append(this.userType, test.userType);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetUserListBySearchIdInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 1,
                max = 60,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String searchName = " ";
        @SinogramLength(
                min = 1,
                max = 32,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String searchId = " ";

        public GetUserListBySearchIdInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getSearchName() {
            if (this.searchName == null) {
                return " ";
            } else {
                return this.searchName.isEmpty() ? " " : this.searchName;
            }
        }

        public String getSearchId() {
            if (this.searchId == null) {
                return " ";
            } else {
                return this.searchId.isEmpty() ? " " : this.searchId;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setSearchName(String searchName) {
            this.searchName = searchName;
        }

        public void setSearchId(String searchId) {
            this.searchId = searchId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetUserListBySearchIdInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",searchName:" + this.searchName);
            buffer.append(",searchId:" + this.searchId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.searchName);
            builder.append(this.searchId);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetUserListBySearchIdInnerInput) {
                InnerPbsService.GetUserListBySearchIdInnerInput test = (InnerPbsService.GetUserListBySearchIdInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.searchName, test.searchName);
                builder.append(this.searchId, test.searchId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetUserListByRoleInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String userId = " ";
        private String operatorName = " ";
        private Integer branchNo = 0;
        private String branchName = " ";
        private String emailAddress = " ";
        private String mobileTel = " ";

        public GetUserListByRoleInnerOutput() {
        }

        public String getUserId() {
            if (this.userId == null) {
                return " ";
            } else {
                return this.userId.isEmpty() ? " " : this.userId;
            }
        }

        public String getOperatorName() {
            if (this.operatorName == null) {
                return " ";
            } else {
                return this.operatorName.isEmpty() ? " " : this.operatorName;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getBranchName() {
            if (this.branchName == null) {
                return " ";
            } else {
                return this.branchName.isEmpty() ? " " : this.branchName;
            }
        }

        public String getEmailAddress() {
            if (this.emailAddress == null) {
                return " ";
            } else {
                return this.emailAddress.isEmpty() ? " " : this.emailAddress;
            }
        }

        public String getMobileTel() {
            if (this.mobileTel == null) {
                return " ";
            } else {
                return this.mobileTel.isEmpty() ? " " : this.mobileTel;
            }
        }

        public void setUserId(String userId) {
            this.userId = userId;
        }

        public void setOperatorName(String operatorName) {
            this.operatorName = operatorName;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setBranchName(String branchName) {
            this.branchName = branchName;
        }

        public void setEmailAddress(String emailAddress) {
            this.emailAddress = emailAddress;
        }

        public void setMobileTel(String mobileTel) {
            this.mobileTel = mobileTel;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetUserListByRoleInnerOutput:(");
            buffer.append("userId:" + this.userId);
            buffer.append(",operatorName:" + this.operatorName);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",branchName:" + this.branchName);
            buffer.append(",emailAddress:" + this.emailAddress);
            buffer.append(",mobileTel:" + this.mobileTel);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.userId);
            builder.append(this.operatorName);
            builder.append(this.branchNo);
            builder.append(this.branchName);
            builder.append(this.emailAddress);
            builder.append(this.mobileTel);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetUserListByRoleInnerOutput) {
                InnerPbsService.GetUserListByRoleInnerOutput test = (InnerPbsService.GetUserListByRoleInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.userId, test.userId);
                builder.append(this.operatorName, test.operatorName);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.branchName, test.branchName);
                builder.append(this.emailAddress, test.emailAddress);
                builder.append(this.mobileTel, test.mobileTel);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetUserListByRoleInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer branchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String roleId = " ";
        private Integer branchZone = 0;

        public GetUserListByRoleInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getRoleId() {
            if (this.roleId == null) {
                return " ";
            } else {
                return this.roleId.isEmpty() ? " " : this.roleId;
            }
        }

        public Integer getBranchZone() {
            return this.branchZone != null ? this.branchZone : 0;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setRoleId(String roleId) {
            this.roleId = roleId;
        }

        public void setBranchZone(Integer branchZone) {
            this.branchZone = branchZone;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetUserListByRoleInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",roleId:" + this.roleId);
            buffer.append(",branchZone:" + this.branchZone);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.branchNo);
            builder.append(this.roleId);
            builder.append(this.branchZone);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetUserListByRoleInnerInput) {
                InnerPbsService.GetUserListByRoleInnerInput test = (InnerPbsService.GetUserListByRoleInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.roleId, test.roleId);
                builder.append(this.branchZone, test.branchZone);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetUserExpiredDaysInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer validDays = 0;

        public GetUserExpiredDaysInnerOutput() {
        }

        public Integer getValidDays() {
            return this.validDays != null ? this.validDays : 0;
        }

        public void setValidDays(Integer validDays) {
            this.validDays = validDays;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetUserExpiredDaysInnerOutput:(");
            buffer.append("validDays:" + this.validDays);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.validDays);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetUserExpiredDaysInnerOutput) {
                InnerPbsService.GetUserExpiredDaysInnerOutput test = (InnerPbsService.GetUserExpiredDaysInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.validDays, test.validDays);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetUserExpiredDaysInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';

        public GetUserExpiredDaysInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetUserExpiredDaysInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetUserExpiredDaysInnerInput) {
                InnerPbsService.GetUserExpiredDaysInnerInput test = (InnerPbsService.GetUserExpiredDaysInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetUserCurrInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String returnCode = " ";
        private String returnInfo = " ";
        private String userId = " ";
        private String userName = " ";
        private Integer branchNo = 0;
        private String branchName = " ";
        private String mobile = " ";
        private String email = " ";
        private String phone = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character idKind = ' ';
        private String idNo = " ";
        private String qualifyNo = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character operStatus = ' ';

        public GetUserCurrInnerOutput() {
        }

        public String getReturnCode() {
            if (this.returnCode == null) {
                return " ";
            } else {
                return this.returnCode.isEmpty() ? " " : this.returnCode;
            }
        }

        public String getReturnInfo() {
            if (this.returnInfo == null) {
                return " ";
            } else {
                return this.returnInfo.isEmpty() ? " " : this.returnInfo;
            }
        }

        public String getUserId() {
            if (this.userId == null) {
                return " ";
            } else {
                return this.userId.isEmpty() ? " " : this.userId;
            }
        }

        public String getUserName() {
            if (this.userName == null) {
                return " ";
            } else {
                return this.userName.isEmpty() ? " " : this.userName;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getBranchName() {
            if (this.branchName == null) {
                return " ";
            } else {
                return this.branchName.isEmpty() ? " " : this.branchName;
            }
        }

        public String getMobile() {
            if (this.mobile == null) {
                return " ";
            } else {
                return this.mobile.isEmpty() ? " " : this.mobile;
            }
        }

        public String getEmail() {
            if (this.email == null) {
                return " ";
            } else {
                return this.email.isEmpty() ? " " : this.email;
            }
        }

        public String getPhone() {
            if (this.phone == null) {
                return " ";
            } else {
                return this.phone.isEmpty() ? " " : this.phone;
            }
        }

        public Character getIdKind() {
            return this.idKind != null ? this.idKind : ' ';
        }

        public String getIdNo() {
            if (this.idNo == null) {
                return " ";
            } else {
                return this.idNo.isEmpty() ? " " : this.idNo;
            }
        }

        public String getQualifyNo() {
            if (this.qualifyNo == null) {
                return " ";
            } else {
                return this.qualifyNo.isEmpty() ? " " : this.qualifyNo;
            }
        }

        public Character getOperStatus() {
            return this.operStatus != null ? this.operStatus : ' ';
        }

        public void setReturnCode(String returnCode) {
            this.returnCode = returnCode;
        }

        public void setReturnInfo(String returnInfo) {
            this.returnInfo = returnInfo;
        }

        public void setUserId(String userId) {
            this.userId = userId;
        }

        public void setUserName(String userName) {
            this.userName = userName;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setBranchName(String branchName) {
            this.branchName = branchName;
        }

        public void setMobile(String mobile) {
            this.mobile = mobile;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        public void setPhone(String phone) {
            this.phone = phone;
        }

        public void setIdKind(Character idKind) {
            this.idKind = idKind;
        }

        public void setIdNo(String idNo) {
            this.idNo = idNo;
        }

        public void setQualifyNo(String qualifyNo) {
            this.qualifyNo = qualifyNo;
        }

        public void setOperStatus(Character operStatus) {
            this.operStatus = operStatus;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetUserCurrInnerOutput:(");
            buffer.append("returnCode:" + this.returnCode);
            buffer.append(",returnInfo:" + this.returnInfo);
            buffer.append(",userId:" + this.userId);
            buffer.append(",userName:" + this.userName);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",branchName:" + this.branchName);
            buffer.append(",mobile:" + this.mobile);
            buffer.append(",email:" + this.email);
            buffer.append(",phone:" + this.phone);
            buffer.append(",idKind:" + this.idKind);
            buffer.append(",idNo:" + this.idNo);
            buffer.append(",qualifyNo:" + this.qualifyNo);
            buffer.append(",operStatus:" + this.operStatus);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.returnCode);
            builder.append(this.returnInfo);
            builder.append(this.userId);
            builder.append(this.userName);
            builder.append(this.branchNo);
            builder.append(this.branchName);
            builder.append(this.mobile);
            builder.append(this.email);
            builder.append(this.phone);
            builder.append(this.idKind);
            builder.append(this.idNo);
            builder.append(this.qualifyNo);
            builder.append(this.operStatus);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetUserCurrInnerOutput) {
                InnerPbsService.GetUserCurrInnerOutput test = (InnerPbsService.GetUserCurrInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.returnCode, test.returnCode);
                builder.append(this.returnInfo, test.returnInfo);
                builder.append(this.userId, test.userId);
                builder.append(this.userName, test.userName);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.branchName, test.branchName);
                builder.append(this.mobile, test.mobile);
                builder.append(this.email, test.email);
                builder.append(this.phone, test.phone);
                builder.append(this.idKind, test.idKind);
                builder.append(this.idNo, test.idNo);
                builder.append(this.qualifyNo, test.qualifyNo);
                builder.append(this.operStatus, test.operStatus);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetUserCurrInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String operatorNo = " ";

        public GetUserCurrInnerInput() {
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetUserCurrInnerInput:(");
            buffer.append("operatorNo:" + this.operatorNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.operatorNo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetUserCurrInnerInput) {
                InnerPbsService.GetUserCurrInnerInput test = (InnerPbsService.GetUserCurrInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.operatorNo, test.operatorNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetSysconfigInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer branchNo = 0;
        private Integer configNo = 0;
        private String configName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character configType = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character manageLevel = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character accessLevel = ' ';
        private String enSystemStr = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character dataType = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character charConfig = ' ';
        private Integer intConfig = 0;
        private String strConfig = " ";
        private String remark = " ";
        private String groupCode = " ";

        public GetSysconfigInnerOutput() {
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Integer getConfigNo() {
            return this.configNo != null ? this.configNo : 0;
        }

        public String getConfigName() {
            if (this.configName == null) {
                return " ";
            } else {
                return this.configName.isEmpty() ? " " : this.configName;
            }
        }

        public Character getConfigType() {
            return this.configType != null ? this.configType : ' ';
        }

        public Character getManageLevel() {
            return this.manageLevel != null ? this.manageLevel : ' ';
        }

        public Character getAccessLevel() {
            return this.accessLevel != null ? this.accessLevel : ' ';
        }

        public String getEnSystemStr() {
            if (this.enSystemStr == null) {
                return " ";
            } else {
                return this.enSystemStr.isEmpty() ? " " : this.enSystemStr;
            }
        }

        public Character getDataType() {
            return this.dataType != null ? this.dataType : ' ';
        }

        public Character getCharConfig() {
            return this.charConfig != null ? this.charConfig : ' ';
        }

        public Integer getIntConfig() {
            return this.intConfig != null ? this.intConfig : 0;
        }

        public String getStrConfig() {
            if (this.strConfig == null) {
                return " ";
            } else {
                return this.strConfig.isEmpty() ? " " : this.strConfig;
            }
        }

        public String getRemark() {
            if (this.remark == null) {
                return " ";
            } else {
                return this.remark.isEmpty() ? " " : this.remark;
            }
        }

        public String getGroupCode() {
            if (this.groupCode == null) {
                return " ";
            } else {
                return this.groupCode.isEmpty() ? " " : this.groupCode;
            }
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setConfigNo(Integer configNo) {
            this.configNo = configNo;
        }

        public void setConfigName(String configName) {
            this.configName = configName;
        }

        public void setConfigType(Character configType) {
            this.configType = configType;
        }

        public void setManageLevel(Character manageLevel) {
            this.manageLevel = manageLevel;
        }

        public void setAccessLevel(Character accessLevel) {
            this.accessLevel = accessLevel;
        }

        public void setEnSystemStr(String enSystemStr) {
            this.enSystemStr = enSystemStr;
        }

        public void setDataType(Character dataType) {
            this.dataType = dataType;
        }

        public void setCharConfig(Character charConfig) {
            this.charConfig = charConfig;
        }

        public void setIntConfig(Integer intConfig) {
            this.intConfig = intConfig;
        }

        public void setStrConfig(String strConfig) {
            this.strConfig = strConfig;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public void setGroupCode(String groupCode) {
            this.groupCode = groupCode;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetSysconfigInnerOutput:(");
            buffer.append("branchNo:" + this.branchNo);
            buffer.append(",configNo:" + this.configNo);
            buffer.append(",configName:" + this.configName);
            buffer.append(",configType:" + this.configType);
            buffer.append(",manageLevel:" + this.manageLevel);
            buffer.append(",accessLevel:" + this.accessLevel);
            buffer.append(",enSystemStr:" + this.enSystemStr);
            buffer.append(",dataType:" + this.dataType);
            buffer.append(",charConfig:" + this.charConfig);
            buffer.append(",intConfig:" + this.intConfig);
            buffer.append(",strConfig:" + this.strConfig);
            buffer.append(",remark:" + this.remark);
            buffer.append(",groupCode:" + this.groupCode);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.branchNo);
            builder.append(this.configNo);
            builder.append(this.configName);
            builder.append(this.configType);
            builder.append(this.manageLevel);
            builder.append(this.accessLevel);
            builder.append(this.enSystemStr);
            builder.append(this.dataType);
            builder.append(this.charConfig);
            builder.append(this.intConfig);
            builder.append(this.strConfig);
            builder.append(this.remark);
            builder.append(this.groupCode);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetSysconfigInnerOutput) {
                InnerPbsService.GetSysconfigInnerOutput test = (InnerPbsService.GetSysconfigInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.configNo, test.configNo);
                builder.append(this.configName, test.configName);
                builder.append(this.configType, test.configType);
                builder.append(this.manageLevel, test.manageLevel);
                builder.append(this.accessLevel, test.accessLevel);
                builder.append(this.enSystemStr, test.enSystemStr);
                builder.append(this.dataType, test.dataType);
                builder.append(this.charConfig, test.charConfig);
                builder.append(this.intConfig, test.intConfig);
                builder.append(this.strConfig, test.strConfig);
                builder.append(this.remark, test.remark);
                builder.append(this.groupCode, test.groupCode);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetSysconfigInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @NotNull(
                message = "不能为空"
        )
        private Integer branchNo = 0;
        @NotNull(
                message = "不能为空"
        )
        private Integer configNo = 0;
        @SinogramLength(
                min = 0,
                max = 100,
                charset = "utf-8"
        )
        private String enSystemStr = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character actionFlag = ' ';

        public GetSysconfigInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Integer getConfigNo() {
            return this.configNo != null ? this.configNo : 0;
        }

        public String getEnSystemStr() {
            if (this.enSystemStr == null) {
                return " ";
            } else {
                return this.enSystemStr.isEmpty() ? " " : this.enSystemStr;
            }
        }

        public Character getActionFlag() {
            return this.actionFlag != null ? this.actionFlag : ' ';
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setConfigNo(Integer configNo) {
            this.configNo = configNo;
        }

        public void setEnSystemStr(String enSystemStr) {
            this.enSystemStr = enSystemStr;
        }

        public void setActionFlag(Character actionFlag) {
            this.actionFlag = actionFlag;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetSysconfigInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",configNo:" + this.configNo);
            buffer.append(",enSystemStr:" + this.enSystemStr);
            buffer.append(",actionFlag:" + this.actionFlag);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.branchNo);
            builder.append(this.configNo);
            builder.append(this.enSystemStr);
            builder.append(this.actionFlag);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetSysconfigInnerInput) {
                InnerPbsService.GetSysconfigInnerInput test = (InnerPbsService.GetSysconfigInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.configNo, test.configNo);
                builder.append(this.enSystemStr, test.enSystemStr);
                builder.append(this.actionFlag, test.actionFlag);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetSyncdatasourceListInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String tableNameSrc = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character realSyncFlag = ' ';
        private String todapCond = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character dapPartitionFlag = ' ';
        private String primaryKeyInfo = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character mainShardingFlag = ' ';

        public GetSyncdatasourceListInnerOutput() {
        }

        public String getTableNameSrc() {
            if (this.tableNameSrc == null) {
                return " ";
            } else {
                return this.tableNameSrc.isEmpty() ? " " : this.tableNameSrc;
            }
        }

        public Character getRealSyncFlag() {
            return this.realSyncFlag != null ? this.realSyncFlag : ' ';
        }

        public String getTodapCond() {
            if (this.todapCond == null) {
                return " ";
            } else {
                return this.todapCond.isEmpty() ? " " : this.todapCond;
            }
        }

        public Character getDapPartitionFlag() {
            return this.dapPartitionFlag != null ? this.dapPartitionFlag : ' ';
        }

        public String getPrimaryKeyInfo() {
            if (this.primaryKeyInfo == null) {
                return " ";
            } else {
                return this.primaryKeyInfo.isEmpty() ? " " : this.primaryKeyInfo;
            }
        }

        public Character getMainShardingFlag() {
            return this.mainShardingFlag != null ? this.mainShardingFlag : ' ';
        }

        public void setTableNameSrc(String tableNameSrc) {
            this.tableNameSrc = tableNameSrc;
        }

        public void setRealSyncFlag(Character realSyncFlag) {
            this.realSyncFlag = realSyncFlag;
        }

        public void setTodapCond(String todapCond) {
            this.todapCond = todapCond;
        }

        public void setDapPartitionFlag(Character dapPartitionFlag) {
            this.dapPartitionFlag = dapPartitionFlag;
        }

        public void setPrimaryKeyInfo(String primaryKeyInfo) {
            this.primaryKeyInfo = primaryKeyInfo;
        }

        public void setMainShardingFlag(Character mainShardingFlag) {
            this.mainShardingFlag = mainShardingFlag;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetSyncdatasourceListInnerOutput:(");
            buffer.append("tableNameSrc:" + this.tableNameSrc);
            buffer.append(",realSyncFlag:" + this.realSyncFlag);
            buffer.append(",todapCond:" + this.todapCond);
            buffer.append(",dapPartitionFlag:" + this.dapPartitionFlag);
            buffer.append(",primaryKeyInfo:" + this.primaryKeyInfo);
            buffer.append(",mainShardingFlag:" + this.mainShardingFlag);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.tableNameSrc);
            builder.append(this.realSyncFlag);
            builder.append(this.todapCond);
            builder.append(this.dapPartitionFlag);
            builder.append(this.primaryKeyInfo);
            builder.append(this.mainShardingFlag);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetSyncdatasourceListInnerOutput) {
                InnerPbsService.GetSyncdatasourceListInnerOutput test = (InnerPbsService.GetSyncdatasourceListInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.tableNameSrc, test.tableNameSrc);
                builder.append(this.realSyncFlag, test.realSyncFlag);
                builder.append(this.todapCond, test.todapCond);
                builder.append(this.dapPartitionFlag, test.dapPartitionFlag);
                builder.append(this.primaryKeyInfo, test.primaryKeyInfo);
                builder.append(this.mainShardingFlag, test.mainShardingFlag);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetSyncdatasourceListInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private List<String> tableNameSrc = new ArrayList();
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character realSyncFlag = ' ';
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String systemCode = " ";
        private Integer pageNo = 0;
        private Integer pageSize = 0;

        public GetSyncdatasourceListInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public List<String> getTableNameSrc() {
            return (List)(this.tableNameSrc != null ? this.tableNameSrc : new ArrayList());
        }

        public Character getRealSyncFlag() {
            return this.realSyncFlag != null ? this.realSyncFlag : ' ';
        }

        public String getSystemCode() {
            if (this.systemCode == null) {
                return " ";
            } else {
                return this.systemCode.isEmpty() ? " " : this.systemCode;
            }
        }

        public Integer getPageNo() {
            return this.pageNo != null ? this.pageNo : 0;
        }

        public Integer getPageSize() {
            return this.pageSize != null ? this.pageSize : 0;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setTableNameSrc(List<String> tableNameSrc) {
            this.tableNameSrc = tableNameSrc;
        }

        public void setRealSyncFlag(Character realSyncFlag) {
            this.realSyncFlag = realSyncFlag;
        }

        public void setSystemCode(String systemCode) {
            this.systemCode = systemCode;
        }

        public void setPageNo(Integer pageNo) {
            this.pageNo = pageNo;
        }

        public void setPageSize(Integer pageSize) {
            this.pageSize = pageSize;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetSyncdatasourceListInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",tableNameSrc:" + this.tableNameSrc);
            buffer.append(",realSyncFlag:" + this.realSyncFlag);
            buffer.append(",systemCode:" + this.systemCode);
            buffer.append(",pageNo:" + this.pageNo);
            buffer.append(",pageSize:" + this.pageSize);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.tableNameSrc);
            builder.append(this.realSyncFlag);
            builder.append(this.systemCode);
            builder.append(this.pageNo);
            builder.append(this.pageSize);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetSyncdatasourceListInnerInput) {
                InnerPbsService.GetSyncdatasourceListInnerInput test = (InnerPbsService.GetSyncdatasourceListInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.tableNameSrc, test.tableNameSrc);
                builder.append(this.realSyncFlag, test.realSyncFlag);
                builder.append(this.systemCode, test.systemCode);
                builder.append(this.pageNo, test.pageNo);
                builder.append(this.pageSize, test.pageSize);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetSyncdatasourceInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer total = 0;
        private Integer currentPage = 0;
        private List<InnerPbsService.SyncDatasourceDTO> rows = new ArrayList();

        public GetSyncdatasourceInnerOutput() {
        }

        public Integer getTotal() {
            return this.total != null ? this.total : 0;
        }

        public Integer getCurrentPage() {
            return this.currentPage != null ? this.currentPage : 0;
        }

        public List<InnerPbsService.SyncDatasourceDTO> getRows() {
            return (List)(this.rows != null ? this.rows : new ArrayList());
        }

        public void setTotal(Integer total) {
            this.total = total;
        }

        public void setCurrentPage(Integer currentPage) {
            this.currentPage = currentPage;
        }

        public void setRows(List<InnerPbsService.SyncDatasourceDTO> rows) {
            this.rows = rows;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetSyncdatasourceInnerOutput:(");
            buffer.append("total:" + this.total);
            buffer.append(",currentPage:" + this.currentPage);
            buffer.append(",rows:" + this.rows);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.total);
            builder.append(this.currentPage);
            builder.append(this.rows);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetSyncdatasourceInnerOutput) {
                InnerPbsService.GetSyncdatasourceInnerOutput test = (InnerPbsService.GetSyncdatasourceInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.total, test.total);
                builder.append(this.currentPage, test.currentPage);
                builder.append(this.rows, test.rows);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetSyncdatasourceInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private List<String> tableNameSrc = new ArrayList();
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character realSyncFlag = ' ';
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String systemCode = " ";
        private Integer pageNo = 0;
        private Integer pageSize = 0;

        public GetSyncdatasourceInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public List<String> getTableNameSrc() {
            return (List)(this.tableNameSrc != null ? this.tableNameSrc : new ArrayList());
        }

        public Character getRealSyncFlag() {
            return this.realSyncFlag != null ? this.realSyncFlag : ' ';
        }

        public String getSystemCode() {
            if (this.systemCode == null) {
                return " ";
            } else {
                return this.systemCode.isEmpty() ? " " : this.systemCode;
            }
        }

        public Integer getPageNo() {
            return this.pageNo != null ? this.pageNo : 0;
        }

        public Integer getPageSize() {
            return this.pageSize != null ? this.pageSize : 0;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setTableNameSrc(List<String> tableNameSrc) {
            this.tableNameSrc = tableNameSrc;
        }

        public void setRealSyncFlag(Character realSyncFlag) {
            this.realSyncFlag = realSyncFlag;
        }

        public void setSystemCode(String systemCode) {
            this.systemCode = systemCode;
        }

        public void setPageNo(Integer pageNo) {
            this.pageNo = pageNo;
        }

        public void setPageSize(Integer pageSize) {
            this.pageSize = pageSize;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetSyncdatasourceInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",tableNameSrc:" + this.tableNameSrc);
            buffer.append(",realSyncFlag:" + this.realSyncFlag);
            buffer.append(",systemCode:" + this.systemCode);
            buffer.append(",pageNo:" + this.pageNo);
            buffer.append(",pageSize:" + this.pageSize);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.tableNameSrc);
            builder.append(this.realSyncFlag);
            builder.append(this.systemCode);
            builder.append(this.pageNo);
            builder.append(this.pageSize);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetSyncdatasourceInnerInput) {
                InnerPbsService.GetSyncdatasourceInnerInput test = (InnerPbsService.GetSyncdatasourceInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.tableNameSrc, test.tableNameSrc);
                builder.append(this.realSyncFlag, test.realSyncFlag);
                builder.append(this.systemCode, test.systemCode);
                builder.append(this.pageNo, test.pageNo);
                builder.append(this.pageSize, test.pageSize);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetSearchfunctionAllInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer functionId = 0;
        private String functionStr = " ";
        private String functionName = " ";

        public GetSearchfunctionAllInnerOutput() {
        }

        public Integer getFunctionId() {
            return this.functionId != null ? this.functionId : 0;
        }

        public String getFunctionStr() {
            if (this.functionStr == null) {
                return " ";
            } else {
                return this.functionStr.isEmpty() ? " " : this.functionStr;
            }
        }

        public String getFunctionName() {
            if (this.functionName == null) {
                return " ";
            } else {
                return this.functionName.isEmpty() ? " " : this.functionName;
            }
        }

        public void setFunctionId(Integer functionId) {
            this.functionId = functionId;
        }

        public void setFunctionStr(String functionStr) {
            this.functionStr = functionStr;
        }

        public void setFunctionName(String functionName) {
            this.functionName = functionName;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetSearchfunctionAllInnerOutput:(");
            buffer.append("functionId:" + this.functionId);
            buffer.append(",functionStr:" + this.functionStr);
            buffer.append(",functionName:" + this.functionName);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.functionId);
            builder.append(this.functionStr);
            builder.append(this.functionName);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetSearchfunctionAllInnerOutput) {
                InnerPbsService.GetSearchfunctionAllInnerOutput test = (InnerPbsService.GetSearchfunctionAllInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.functionId, test.functionId);
                builder.append(this.functionStr, test.functionStr);
                builder.append(this.functionName, test.functionName);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetRolesListPageInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer total = 0;
        private Integer currentPage = 0;
        private List<InnerPbsService.RolesDTO> rows = new ArrayList();

        public GetRolesListPageInnerOutput() {
        }

        public Integer getTotal() {
            return this.total != null ? this.total : 0;
        }

        public Integer getCurrentPage() {
            return this.currentPage != null ? this.currentPage : 0;
        }

        public List<InnerPbsService.RolesDTO> getRows() {
            return (List)(this.rows != null ? this.rows : new ArrayList());
        }

        public void setTotal(Integer total) {
            this.total = total;
        }

        public void setCurrentPage(Integer currentPage) {
            this.currentPage = currentPage;
        }

        public void setRows(List<InnerPbsService.RolesDTO> rows) {
            this.rows = rows;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetRolesListPageInnerOutput:(");
            buffer.append("total:" + this.total);
            buffer.append(",currentPage:" + this.currentPage);
            buffer.append(",rows:" + this.rows);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.total);
            builder.append(this.currentPage);
            builder.append(this.rows);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetRolesListPageInnerOutput) {
                InnerPbsService.GetRolesListPageInnerOutput test = (InnerPbsService.GetRolesListPageInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.total, test.total);
                builder.append(this.currentPage, test.currentPage);
                builder.append(this.rows, test.rows);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetRolesListPageInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String roleId = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character roleKind = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String roleName = " ";
        private Integer pageNo = 0;
        private Integer pageSize = 0;

        public GetRolesListPageInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getRoleId() {
            if (this.roleId == null) {
                return " ";
            } else {
                return this.roleId.isEmpty() ? " " : this.roleId;
            }
        }

        public Character getRoleKind() {
            return this.roleKind != null ? this.roleKind : ' ';
        }

        public String getRoleName() {
            if (this.roleName == null) {
                return " ";
            } else {
                return this.roleName.isEmpty() ? " " : this.roleName;
            }
        }

        public Integer getPageNo() {
            return this.pageNo != null ? this.pageNo : 0;
        }

        public Integer getPageSize() {
            return this.pageSize != null ? this.pageSize : 0;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setRoleId(String roleId) {
            this.roleId = roleId;
        }

        public void setRoleKind(Character roleKind) {
            this.roleKind = roleKind;
        }

        public void setRoleName(String roleName) {
            this.roleName = roleName;
        }

        public void setPageNo(Integer pageNo) {
            this.pageNo = pageNo;
        }

        public void setPageSize(Integer pageSize) {
            this.pageSize = pageSize;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetRolesListPageInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",roleId:" + this.roleId);
            buffer.append(",roleKind:" + this.roleKind);
            buffer.append(",roleName:" + this.roleName);
            buffer.append(",pageNo:" + this.pageNo);
            buffer.append(",pageSize:" + this.pageSize);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.roleId);
            builder.append(this.roleKind);
            builder.append(this.roleName);
            builder.append(this.pageNo);
            builder.append(this.pageSize);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetRolesListPageInnerInput) {
                InnerPbsService.GetRolesListPageInnerInput test = (InnerPbsService.GetRolesListPageInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.roleId, test.roleId);
                builder.append(this.roleKind, test.roleKind);
                builder.append(this.roleName, test.roleName);
                builder.append(this.pageNo, test.pageNo);
                builder.append(this.pageSize, test.pageSize);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetRolesListInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String roleId = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character roleKind = ' ';
        private String roleName = " ";

        public GetRolesListInnerOutput() {
        }

        public String getRoleId() {
            if (this.roleId == null) {
                return " ";
            } else {
                return this.roleId.isEmpty() ? " " : this.roleId;
            }
        }

        public Character getRoleKind() {
            return this.roleKind != null ? this.roleKind : ' ';
        }

        public String getRoleName() {
            if (this.roleName == null) {
                return " ";
            } else {
                return this.roleName.isEmpty() ? " " : this.roleName;
            }
        }

        public void setRoleId(String roleId) {
            this.roleId = roleId;
        }

        public void setRoleKind(Character roleKind) {
            this.roleKind = roleKind;
        }

        public void setRoleName(String roleName) {
            this.roleName = roleName;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetRolesListInnerOutput:(");
            buffer.append("roleId:" + this.roleId);
            buffer.append(",roleKind:" + this.roleKind);
            buffer.append(",roleName:" + this.roleName);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.roleId);
            builder.append(this.roleKind);
            builder.append(this.roleName);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetRolesListInnerOutput) {
                InnerPbsService.GetRolesListInnerOutput test = (InnerPbsService.GetRolesListInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.roleId, test.roleId);
                builder.append(this.roleKind, test.roleKind);
                builder.append(this.roleName, test.roleName);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetRolesListInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 1,
                max = 32,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String userId = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character queryType = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character rightType = '0';

        public GetRolesListInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getUserId() {
            if (this.userId == null) {
                return " ";
            } else {
                return this.userId.isEmpty() ? " " : this.userId;
            }
        }

        public Character getQueryType() {
            return this.queryType != null ? this.queryType : ' ';
        }

        public Character getRightType() {
            return this.rightType != null ? this.rightType : '\u0000';
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setUserId(String userId) {
            this.userId = userId;
        }

        public void setQueryType(Character queryType) {
            this.queryType = queryType;
        }

        public void setRightType(Character rightType) {
            this.rightType = rightType;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetRolesListInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",userId:" + this.userId);
            buffer.append(",queryType:" + this.queryType);
            buffer.append(",rightType:" + this.rightType);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.userId);
            builder.append(this.queryType);
            builder.append(this.rightType);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetRolesListInnerInput) {
                InnerPbsService.GetRolesListInnerInput test = (InnerPbsService.GetRolesListInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.userId, test.userId);
                builder.append(this.queryType, test.queryType);
                builder.append(this.rightType, test.rightType);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetPrivatefunctionCheckInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String resultCode = " ";

        public GetPrivatefunctionCheckInnerOutput() {
        }

        public String getResultCode() {
            if (this.resultCode == null) {
                return " ";
            } else {
                return this.resultCode.isEmpty() ? " " : this.resultCode;
            }
        }

        public void setResultCode(String resultCode) {
            this.resultCode = resultCode;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetPrivatefunctionCheckInnerOutput:(");
            buffer.append("resultCode:" + this.resultCode);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.resultCode);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetPrivatefunctionCheckInnerOutput) {
                InnerPbsService.GetPrivatefunctionCheckInnerOutput test = (InnerPbsService.GetPrivatefunctionCheckInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.resultCode, test.resultCode);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetPrivatefunctionCheckInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String functionStr = " ";

        public GetPrivatefunctionCheckInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getFunctionStr() {
            if (this.functionStr == null) {
                return " ";
            } else {
                return this.functionStr.isEmpty() ? " " : this.functionStr;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setFunctionStr(String functionStr) {
            this.functionStr = functionStr;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetPrivatefunctionCheckInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",functionStr:" + this.functionStr);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.functionStr);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetPrivatefunctionCheckInnerInput) {
                InnerPbsService.GetPrivatefunctionCheckInnerInput test = (InnerPbsService.GetPrivatefunctionCheckInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.functionStr, test.functionStr);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetPrivatefieldinfoListInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String englishName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character dealMode = ' ';
        private Integer beginIndex = 0;
        private Integer endIndex = 0;
        private String remark = " ";

        public GetPrivatefieldinfoListInnerOutput() {
        }

        public String getEnglishName() {
            if (this.englishName == null) {
                return " ";
            } else {
                return this.englishName.isEmpty() ? " " : this.englishName;
            }
        }

        public Character getDealMode() {
            return this.dealMode != null ? this.dealMode : ' ';
        }

        public Integer getBeginIndex() {
            return this.beginIndex != null ? this.beginIndex : 0;
        }

        public Integer getEndIndex() {
            return this.endIndex != null ? this.endIndex : 0;
        }

        public String getRemark() {
            if (this.remark == null) {
                return " ";
            } else {
                return this.remark.isEmpty() ? " " : this.remark;
            }
        }

        public void setEnglishName(String englishName) {
            this.englishName = englishName;
        }

        public void setDealMode(Character dealMode) {
            this.dealMode = dealMode;
        }

        public void setBeginIndex(Integer beginIndex) {
            this.beginIndex = beginIndex;
        }

        public void setEndIndex(Integer endIndex) {
            this.endIndex = endIndex;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetPrivatefieldinfoListInnerOutput:(");
            buffer.append("englishName:" + this.englishName);
            buffer.append(",dealMode:" + this.dealMode);
            buffer.append(",beginIndex:" + this.beginIndex);
            buffer.append(",endIndex:" + this.endIndex);
            buffer.append(",remark:" + this.remark);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.englishName);
            builder.append(this.dealMode);
            builder.append(this.beginIndex);
            builder.append(this.endIndex);
            builder.append(this.remark);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetPrivatefieldinfoListInnerOutput) {
                InnerPbsService.GetPrivatefieldinfoListInnerOutput test = (InnerPbsService.GetPrivatefieldinfoListInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.englishName, test.englishName);
                builder.append(this.dealMode, test.dealMode);
                builder.append(this.beginIndex, test.beginIndex);
                builder.append(this.endIndex, test.endIndex);
                builder.append(this.remark, test.remark);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetPrivatefieldinfoListInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 1,
                max = 2000,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String englishNameStr = " ";

        public GetPrivatefieldinfoListInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getEnglishNameStr() {
            if (this.englishNameStr == null) {
                return " ";
            } else {
                return this.englishNameStr.isEmpty() ? " " : this.englishNameStr;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setEnglishNameStr(String englishNameStr) {
            this.englishNameStr = englishNameStr;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetPrivatefieldinfoListInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",englishNameStr:" + this.englishNameStr);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.englishNameStr);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetPrivatefieldinfoListInnerInput) {
                InnerPbsService.GetPrivatefieldinfoListInnerInput test = (InnerPbsService.GetPrivatefieldinfoListInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.englishNameStr, test.englishNameStr);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetPrivatefieldinfoAllInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String englishName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character dealMode = ' ';
        private Integer beginIndex = 0;
        private Integer endIndex = 0;
        private String remark = " ";

        public GetPrivatefieldinfoAllInnerOutput() {
        }

        public String getEnglishName() {
            if (this.englishName == null) {
                return " ";
            } else {
                return this.englishName.isEmpty() ? " " : this.englishName;
            }
        }

        public Character getDealMode() {
            return this.dealMode != null ? this.dealMode : ' ';
        }

        public Integer getBeginIndex() {
            return this.beginIndex != null ? this.beginIndex : 0;
        }

        public Integer getEndIndex() {
            return this.endIndex != null ? this.endIndex : 0;
        }

        public String getRemark() {
            if (this.remark == null) {
                return " ";
            } else {
                return this.remark.isEmpty() ? " " : this.remark;
            }
        }

        public void setEnglishName(String englishName) {
            this.englishName = englishName;
        }

        public void setDealMode(Character dealMode) {
            this.dealMode = dealMode;
        }

        public void setBeginIndex(Integer beginIndex) {
            this.beginIndex = beginIndex;
        }

        public void setEndIndex(Integer endIndex) {
            this.endIndex = endIndex;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetPrivatefieldinfoAllInnerOutput:(");
            buffer.append("englishName:" + this.englishName);
            buffer.append(",dealMode:" + this.dealMode);
            buffer.append(",beginIndex:" + this.beginIndex);
            buffer.append(",endIndex:" + this.endIndex);
            buffer.append(",remark:" + this.remark);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.englishName);
            builder.append(this.dealMode);
            builder.append(this.beginIndex);
            builder.append(this.endIndex);
            builder.append(this.remark);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetPrivatefieldinfoAllInnerOutput) {
                InnerPbsService.GetPrivatefieldinfoAllInnerOutput test = (InnerPbsService.GetPrivatefieldinfoAllInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.englishName, test.englishName);
                builder.append(this.dealMode, test.dealMode);
                builder.append(this.beginIndex, test.beginIndex);
                builder.append(this.endIndex, test.endIndex);
                builder.append(this.remark, test.remark);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetPbsfunctionForFieldkindListOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String userId = " ";
        private String enFieldKind = " ";

        public GetPbsfunctionForFieldkindListOutput() {
        }

        public String getUserId() {
            if (this.userId == null) {
                return " ";
            } else {
                return this.userId.isEmpty() ? " " : this.userId;
            }
        }

        public String getEnFieldKind() {
            if (this.enFieldKind == null) {
                return " ";
            } else {
                return this.enFieldKind.isEmpty() ? " " : this.enFieldKind;
            }
        }

        public void setUserId(String userId) {
            this.userId = userId;
        }

        public void setEnFieldKind(String enFieldKind) {
            this.enFieldKind = enFieldKind;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetPbsfunctionForFieldkindListOutput:(");
            buffer.append("userId:" + this.userId);
            buffer.append(",enFieldKind:" + this.enFieldKind);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.userId);
            builder.append(this.enFieldKind);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetPbsfunctionForFieldkindListOutput) {
                InnerPbsService.GetPbsfunctionForFieldkindListOutput test = (InnerPbsService.GetPbsfunctionForFieldkindListOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.userId, test.userId);
                builder.append(this.enFieldKind, test.enFieldKind);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetPbsfunctionForFieldkindListInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String userId = " ";

        public GetPbsfunctionForFieldkindListInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getUserId() {
            if (this.userId == null) {
                return " ";
            } else {
                return this.userId.isEmpty() ? " " : this.userId;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setUserId(String userId) {
            this.userId = userId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetPbsfunctionForFieldkindListInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",userId:" + this.userId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.userId);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetPbsfunctionForFieldkindListInput) {
                InnerPbsService.GetPbsfunctionForFieldkindListInput test = (InnerPbsService.GetPbsfunctionForFieldkindListInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.userId, test.userId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetMctopicsInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String topicName = " ";
        private String topicDecp = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character reliableLevel = ' ';
        private Integer issuePriority = 0;
        private Integer msgLifeTime = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character topicStatus = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character kickStrategy = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character businessVerify = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character local = ' ';
        private Integer issueType = 0;
        private String filterField1 = " ";
        private String filterField2 = " ";
        private String filterField3 = " ";
        private String filterField4 = " ";
        private String filterField5 = " ";
        private String filterField6 = " ";
        private String subscribeStr = " ";
        private String publishStr = " ";

        public GetMctopicsInnerOutput() {
        }

        public String getTopicName() {
            if (this.topicName == null) {
                return " ";
            } else {
                return this.topicName.isEmpty() ? " " : this.topicName;
            }
        }

        public String getTopicDecp() {
            if (this.topicDecp == null) {
                return " ";
            } else {
                return this.topicDecp.isEmpty() ? " " : this.topicDecp;
            }
        }

        public Character getReliableLevel() {
            return this.reliableLevel != null ? this.reliableLevel : ' ';
        }

        public Integer getIssuePriority() {
            return this.issuePriority != null ? this.issuePriority : 0;
        }

        public Integer getMsgLifeTime() {
            return this.msgLifeTime != null ? this.msgLifeTime : 0;
        }

        public Character getTopicStatus() {
            return this.topicStatus != null ? this.topicStatus : ' ';
        }

        public Character getKickStrategy() {
            return this.kickStrategy != null ? this.kickStrategy : ' ';
        }

        public Character getBusinessVerify() {
            return this.businessVerify != null ? this.businessVerify : ' ';
        }

        public Character getLocal() {
            return this.local != null ? this.local : ' ';
        }

        public Integer getIssueType() {
            return this.issueType != null ? this.issueType : 0;
        }

        public String getFilterField1() {
            if (this.filterField1 == null) {
                return " ";
            } else {
                return this.filterField1.isEmpty() ? " " : this.filterField1;
            }
        }

        public String getFilterField2() {
            if (this.filterField2 == null) {
                return " ";
            } else {
                return this.filterField2.isEmpty() ? " " : this.filterField2;
            }
        }

        public String getFilterField3() {
            if (this.filterField3 == null) {
                return " ";
            } else {
                return this.filterField3.isEmpty() ? " " : this.filterField3;
            }
        }

        public String getFilterField4() {
            if (this.filterField4 == null) {
                return " ";
            } else {
                return this.filterField4.isEmpty() ? " " : this.filterField4;
            }
        }

        public String getFilterField5() {
            if (this.filterField5 == null) {
                return " ";
            } else {
                return this.filterField5.isEmpty() ? " " : this.filterField5;
            }
        }

        public String getFilterField6() {
            if (this.filterField6 == null) {
                return " ";
            } else {
                return this.filterField6.isEmpty() ? " " : this.filterField6;
            }
        }

        public String getSubscribeStr() {
            if (this.subscribeStr == null) {
                return " ";
            } else {
                return this.subscribeStr.isEmpty() ? " " : this.subscribeStr;
            }
        }

        public String getPublishStr() {
            if (this.publishStr == null) {
                return " ";
            } else {
                return this.publishStr.isEmpty() ? " " : this.publishStr;
            }
        }

        public void setTopicName(String topicName) {
            this.topicName = topicName;
        }

        public void setTopicDecp(String topicDecp) {
            this.topicDecp = topicDecp;
        }

        public void setReliableLevel(Character reliableLevel) {
            this.reliableLevel = reliableLevel;
        }

        public void setIssuePriority(Integer issuePriority) {
            this.issuePriority = issuePriority;
        }

        public void setMsgLifeTime(Integer msgLifeTime) {
            this.msgLifeTime = msgLifeTime;
        }

        public void setTopicStatus(Character topicStatus) {
            this.topicStatus = topicStatus;
        }

        public void setKickStrategy(Character kickStrategy) {
            this.kickStrategy = kickStrategy;
        }

        public void setBusinessVerify(Character businessVerify) {
            this.businessVerify = businessVerify;
        }

        public void setLocal(Character local) {
            this.local = local;
        }

        public void setIssueType(Integer issueType) {
            this.issueType = issueType;
        }

        public void setFilterField1(String filterField1) {
            this.filterField1 = filterField1;
        }

        public void setFilterField2(String filterField2) {
            this.filterField2 = filterField2;
        }

        public void setFilterField3(String filterField3) {
            this.filterField3 = filterField3;
        }

        public void setFilterField4(String filterField4) {
            this.filterField4 = filterField4;
        }

        public void setFilterField5(String filterField5) {
            this.filterField5 = filterField5;
        }

        public void setFilterField6(String filterField6) {
            this.filterField6 = filterField6;
        }

        public void setSubscribeStr(String subscribeStr) {
            this.subscribeStr = subscribeStr;
        }

        public void setPublishStr(String publishStr) {
            this.publishStr = publishStr;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetMctopicsInnerOutput:(");
            buffer.append("topicName:" + this.topicName);
            buffer.append(",topicDecp:" + this.topicDecp);
            buffer.append(",reliableLevel:" + this.reliableLevel);
            buffer.append(",issuePriority:" + this.issuePriority);
            buffer.append(",msgLifeTime:" + this.msgLifeTime);
            buffer.append(",topicStatus:" + this.topicStatus);
            buffer.append(",kickStrategy:" + this.kickStrategy);
            buffer.append(",businessVerify:" + this.businessVerify);
            buffer.append(",local:" + this.local);
            buffer.append(",issueType:" + this.issueType);
            buffer.append(",filterField1:" + this.filterField1);
            buffer.append(",filterField2:" + this.filterField2);
            buffer.append(",filterField3:" + this.filterField3);
            buffer.append(",filterField4:" + this.filterField4);
            buffer.append(",filterField5:" + this.filterField5);
            buffer.append(",filterField6:" + this.filterField6);
            buffer.append(",subscribeStr:" + this.subscribeStr);
            buffer.append(",publishStr:" + this.publishStr);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.topicName);
            builder.append(this.topicDecp);
            builder.append(this.reliableLevel);
            builder.append(this.issuePriority);
            builder.append(this.msgLifeTime);
            builder.append(this.topicStatus);
            builder.append(this.kickStrategy);
            builder.append(this.businessVerify);
            builder.append(this.local);
            builder.append(this.issueType);
            builder.append(this.filterField1);
            builder.append(this.filterField2);
            builder.append(this.filterField3);
            builder.append(this.filterField4);
            builder.append(this.filterField5);
            builder.append(this.filterField6);
            builder.append(this.subscribeStr);
            builder.append(this.publishStr);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetMctopicsInnerOutput) {
                InnerPbsService.GetMctopicsInnerOutput test = (InnerPbsService.GetMctopicsInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.topicName, test.topicName);
                builder.append(this.topicDecp, test.topicDecp);
                builder.append(this.reliableLevel, test.reliableLevel);
                builder.append(this.issuePriority, test.issuePriority);
                builder.append(this.msgLifeTime, test.msgLifeTime);
                builder.append(this.topicStatus, test.topicStatus);
                builder.append(this.kickStrategy, test.kickStrategy);
                builder.append(this.businessVerify, test.businessVerify);
                builder.append(this.local, test.local);
                builder.append(this.issueType, test.issueType);
                builder.append(this.filterField1, test.filterField1);
                builder.append(this.filterField2, test.filterField2);
                builder.append(this.filterField3, test.filterField3);
                builder.append(this.filterField4, test.filterField4);
                builder.append(this.filterField5, test.filterField5);
                builder.append(this.filterField6, test.filterField6);
                builder.append(this.subscribeStr, test.subscribeStr);
                builder.append(this.publishStr, test.publishStr);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetLicensePermissionsInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character licenseStatus = ' ';

        public GetLicensePermissionsInnerOutput() {
        }

        public Character getLicenseStatus() {
            return this.licenseStatus != null ? this.licenseStatus : ' ';
        }

        public void setLicenseStatus(Character licenseStatus) {
            this.licenseStatus = licenseStatus;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetLicensePermissionsInnerOutput:(");
            buffer.append("licenseStatus:" + this.licenseStatus);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.licenseStatus);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetLicensePermissionsInnerOutput) {
                InnerPbsService.GetLicensePermissionsInnerOutput test = (InnerPbsService.GetLicensePermissionsInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.licenseStatus, test.licenseStatus);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetLicensePermissionsInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @NotNull(
                message = "不能为空"
        )
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 64,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 1,
                max = 64,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String menuCode = " ";
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String licenseId = " ";

        public GetLicensePermissionsInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getMenuCode() {
            if (this.menuCode == null) {
                return " ";
            } else {
                return this.menuCode.isEmpty() ? " " : this.menuCode;
            }
        }

        public String getLicenseId() {
            if (this.licenseId == null) {
                return " ";
            } else {
                return this.licenseId.isEmpty() ? " " : this.licenseId;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setMenuCode(String menuCode) {
            this.menuCode = menuCode;
        }

        public void setLicenseId(String licenseId) {
            this.licenseId = licenseId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetLicensePermissionsInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",menuCode:" + this.menuCode);
            buffer.append(",licenseId:" + this.licenseId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.menuCode);
            builder.append(this.licenseId);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetLicensePermissionsInnerInput) {
                InnerPbsService.GetLicensePermissionsInnerInput test = (InnerPbsService.GetLicensePermissionsInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.menuCode, test.menuCode);
                builder.append(this.licenseId, test.licenseId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetInitdatemodelInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer initDate = 0;
        private Integer initModel = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character settleFlag = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character tradeFlag = ' ';

        public GetInitdatemodelInnerOutput() {
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public Integer getInitModel() {
            return this.initModel != null ? this.initModel : 0;
        }

        public Character getSettleFlag() {
            return this.settleFlag != null ? this.settleFlag : ' ';
        }

        public Character getTradeFlag() {
            return this.tradeFlag != null ? this.tradeFlag : ' ';
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public void setInitModel(Integer initModel) {
            this.initModel = initModel;
        }

        public void setSettleFlag(Character settleFlag) {
            this.settleFlag = settleFlag;
        }

        public void setTradeFlag(Character tradeFlag) {
            this.tradeFlag = tradeFlag;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetInitdatemodelInnerOutput:(");
            buffer.append("initDate:" + this.initDate);
            buffer.append(",initModel:" + this.initModel);
            buffer.append(",settleFlag:" + this.settleFlag);
            buffer.append(",tradeFlag:" + this.tradeFlag);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.initDate);
            builder.append(this.initModel);
            builder.append(this.settleFlag);
            builder.append(this.tradeFlag);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetInitdatemodelInnerOutput) {
                InnerPbsService.GetInitdatemodelInnerOutput test = (InnerPbsService.GetInitdatemodelInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.initDate, test.initDate);
                builder.append(this.initModel, test.initModel);
                builder.append(this.settleFlag, test.settleFlag);
                builder.append(this.tradeFlag, test.tradeFlag);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetInitdatemodelInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer dateCount = 0;
        private Integer initDate = 0;
        private Integer initModel = 0;

        public GetInitdatemodelInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getDateCount() {
            return this.dateCount != null ? this.dateCount : 0;
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public Integer getInitModel() {
            return this.initModel != null ? this.initModel : 0;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setDateCount(Integer dateCount) {
            this.dateCount = dateCount;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public void setInitModel(Integer initModel) {
            this.initModel = initModel;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetInitdatemodelInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",dateCount:" + this.dateCount);
            buffer.append(",initDate:" + this.initDate);
            buffer.append(",initModel:" + this.initModel);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.dateCount);
            builder.append(this.initDate);
            builder.append(this.initModel);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetInitdatemodelInnerInput) {
                InnerPbsService.GetInitdatemodelInnerInput test = (InnerPbsService.GetInitdatemodelInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.dateCount, test.dateCount);
                builder.append(this.initDate, test.initDate);
                builder.append(this.initModel, test.initModel);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetInitconfigByServiceNameInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String tableName = " ";
        private String initconfigCond = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character initconfigFlag = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character tolastFlag = ' ';
        private String tolastCond = " ";
        private String serviceName = " ";

        public GetInitconfigByServiceNameInnerOutput() {
        }

        public String getTableName() {
            if (this.tableName == null) {
                return " ";
            } else {
                return this.tableName.isEmpty() ? " " : this.tableName;
            }
        }

        public String getInitconfigCond() {
            if (this.initconfigCond == null) {
                return " ";
            } else {
                return this.initconfigCond.isEmpty() ? " " : this.initconfigCond;
            }
        }

        public Character getInitconfigFlag() {
            return this.initconfigFlag != null ? this.initconfigFlag : ' ';
        }

        public Character getTolastFlag() {
            return this.tolastFlag != null ? this.tolastFlag : ' ';
        }

        public String getTolastCond() {
            if (this.tolastCond == null) {
                return " ";
            } else {
                return this.tolastCond.isEmpty() ? " " : this.tolastCond;
            }
        }

        public String getServiceName() {
            if (this.serviceName == null) {
                return " ";
            } else {
                return this.serviceName.isEmpty() ? " " : this.serviceName;
            }
        }

        public void setTableName(String tableName) {
            this.tableName = tableName;
        }

        public void setInitconfigCond(String initconfigCond) {
            this.initconfigCond = initconfigCond;
        }

        public void setInitconfigFlag(Character initconfigFlag) {
            this.initconfigFlag = initconfigFlag;
        }

        public void setTolastFlag(Character tolastFlag) {
            this.tolastFlag = tolastFlag;
        }

        public void setTolastCond(String tolastCond) {
            this.tolastCond = tolastCond;
        }

        public void setServiceName(String serviceName) {
            this.serviceName = serviceName;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetInitconfigByServiceNameInnerOutput:(");
            buffer.append("tableName:" + this.tableName);
            buffer.append(",initconfigCond:" + this.initconfigCond);
            buffer.append(",initconfigFlag:" + this.initconfigFlag);
            buffer.append(",tolastFlag:" + this.tolastFlag);
            buffer.append(",tolastCond:" + this.tolastCond);
            buffer.append(",serviceName:" + this.serviceName);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.tableName);
            builder.append(this.initconfigCond);
            builder.append(this.initconfigFlag);
            builder.append(this.tolastFlag);
            builder.append(this.tolastCond);
            builder.append(this.serviceName);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetInitconfigByServiceNameInnerOutput) {
                InnerPbsService.GetInitconfigByServiceNameInnerOutput test = (InnerPbsService.GetInitconfigByServiceNameInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.tableName, test.tableName);
                builder.append(this.initconfigCond, test.initconfigCond);
                builder.append(this.initconfigFlag, test.initconfigFlag);
                builder.append(this.tolastFlag, test.tolastFlag);
                builder.append(this.tolastCond, test.tolastCond);
                builder.append(this.serviceName, test.serviceName);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetInitconfigByServiceNameInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String serviceName = " ";

        public GetInitconfigByServiceNameInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getServiceName() {
            if (this.serviceName == null) {
                return " ";
            } else {
                return this.serviceName.isEmpty() ? " " : this.serviceName;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setServiceName(String serviceName) {
            this.serviceName = serviceName;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetInitconfigByServiceNameInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",serviceName:" + this.serviceName);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.serviceName);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetInitconfigByServiceNameInnerInput) {
                InnerPbsService.GetInitconfigByServiceNameInnerInput test = (InnerPbsService.GetInitconfigByServiceNameInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.serviceName, test.serviceName);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetHsmenuTransInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String menuCode = " ";
        private String menuName = " ";

        public GetHsmenuTransInnerOutput() {
        }

        public String getMenuCode() {
            if (this.menuCode == null) {
                return " ";
            } else {
                return this.menuCode.isEmpty() ? " " : this.menuCode;
            }
        }

        public String getMenuName() {
            if (this.menuName == null) {
                return " ";
            } else {
                return this.menuName.isEmpty() ? " " : this.menuName;
            }
        }

        public void setMenuCode(String menuCode) {
            this.menuCode = menuCode;
        }

        public void setMenuName(String menuName) {
            this.menuName = menuName;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetHsmenuTransInnerOutput:(");
            buffer.append("menuCode:" + this.menuCode);
            buffer.append(",menuName:" + this.menuName);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.menuCode);
            builder.append(this.menuName);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetHsmenuTransInnerOutput) {
                InnerPbsService.GetHsmenuTransInnerOutput test = (InnerPbsService.GetHsmenuTransInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.menuCode, test.menuCode);
                builder.append(this.menuName, test.menuName);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetHsmenuTransInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';

        public GetHsmenuTransInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetHsmenuTransInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetHsmenuTransInnerInput) {
                InnerPbsService.GetHsmenuTransInnerInput test = (InnerPbsService.GetHsmenuTransInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetHsmenuAllInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String menuCode = " ";
        private String menuName = " ";
        private String menuUrl = " ";
        private String treeIdx = " ";

        public GetHsmenuAllInnerOutput() {
        }

        public String getMenuCode() {
            if (this.menuCode == null) {
                return " ";
            } else {
                return this.menuCode.isEmpty() ? " " : this.menuCode;
            }
        }

        public String getMenuName() {
            if (this.menuName == null) {
                return " ";
            } else {
                return this.menuName.isEmpty() ? " " : this.menuName;
            }
        }

        public String getMenuUrl() {
            if (this.menuUrl == null) {
                return " ";
            } else {
                return this.menuUrl.isEmpty() ? " " : this.menuUrl;
            }
        }

        public String getTreeIdx() {
            if (this.treeIdx == null) {
                return " ";
            } else {
                return this.treeIdx.isEmpty() ? " " : this.treeIdx;
            }
        }

        public void setMenuCode(String menuCode) {
            this.menuCode = menuCode;
        }

        public void setMenuName(String menuName) {
            this.menuName = menuName;
        }

        public void setMenuUrl(String menuUrl) {
            this.menuUrl = menuUrl;
        }

        public void setTreeIdx(String treeIdx) {
            this.treeIdx = treeIdx;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetHsmenuAllInnerOutput:(");
            buffer.append("menuCode:" + this.menuCode);
            buffer.append(",menuName:" + this.menuName);
            buffer.append(",menuUrl:" + this.menuUrl);
            buffer.append(",treeIdx:" + this.treeIdx);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.menuCode);
            builder.append(this.menuName);
            builder.append(this.menuUrl);
            builder.append(this.treeIdx);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetHsmenuAllInnerOutput) {
                InnerPbsService.GetHsmenuAllInnerOutput test = (InnerPbsService.GetHsmenuAllInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.menuCode, test.menuCode);
                builder.append(this.menuName, test.menuName);
                builder.append(this.menuUrl, test.menuUrl);
                builder.append(this.treeIdx, test.treeIdx);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetHsmenuAllInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';

        public GetHsmenuAllInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetHsmenuAllInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetHsmenuAllInnerInput) {
                InnerPbsService.GetHsmenuAllInnerInput test = (InnerPbsService.GetHsmenuAllInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetHsfunctionTransInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String functionStr = " ";
        private String functionName = " ";

        public GetHsfunctionTransInnerOutput() {
        }

        public String getFunctionStr() {
            if (this.functionStr == null) {
                return " ";
            } else {
                return this.functionStr.isEmpty() ? " " : this.functionStr;
            }
        }

        public String getFunctionName() {
            if (this.functionName == null) {
                return " ";
            } else {
                return this.functionName.isEmpty() ? " " : this.functionName;
            }
        }

        public void setFunctionStr(String functionStr) {
            this.functionStr = functionStr;
        }

        public void setFunctionName(String functionName) {
            this.functionName = functionName;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetHsfunctionTransInnerOutput:(");
            buffer.append("functionStr:" + this.functionStr);
            buffer.append(",functionName:" + this.functionName);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.functionStr);
            builder.append(this.functionName);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetHsfunctionTransInnerOutput) {
                InnerPbsService.GetHsfunctionTransInnerOutput test = (InnerPbsService.GetHsfunctionTransInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.functionStr, test.functionStr);
                builder.append(this.functionName, test.functionName);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetHsfunctionTransInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';

        public GetHsfunctionTransInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetHsfunctionTransInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetHsfunctionTransInnerInput) {
                InnerPbsService.GetHsfunctionTransInnerInput test = (InnerPbsService.GetHsfunctionTransInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetHsfunctionInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String functionStr = " ";
        private String functionName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character passwordType = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character accessLevel = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character funcBusiType = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character funcBusiProp = ' ';
        private String funcFlagStr = " ";
        private Integer reststartTime = 0;
        private Integer restendTime = 0;
        private String enSysStatus = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character rightType = ' ';

        public GetHsfunctionInnerOutput() {
        }

        public String getFunctionStr() {
            if (this.functionStr == null) {
                return " ";
            } else {
                return this.functionStr.isEmpty() ? " " : this.functionStr;
            }
        }

        public String getFunctionName() {
            if (this.functionName == null) {
                return " ";
            } else {
                return this.functionName.isEmpty() ? " " : this.functionName;
            }
        }

        public Character getPasswordType() {
            return this.passwordType != null ? this.passwordType : ' ';
        }

        public Character getAccessLevel() {
            return this.accessLevel != null ? this.accessLevel : ' ';
        }

        public Character getFuncBusiType() {
            return this.funcBusiType != null ? this.funcBusiType : ' ';
        }

        public Character getFuncBusiProp() {
            return this.funcBusiProp != null ? this.funcBusiProp : ' ';
        }

        public String getFuncFlagStr() {
            if (this.funcFlagStr == null) {
                return " ";
            } else {
                return this.funcFlagStr.isEmpty() ? " " : this.funcFlagStr;
            }
        }

        public Integer getReststartTime() {
            return this.reststartTime != null ? this.reststartTime : 0;
        }

        public Integer getRestendTime() {
            return this.restendTime != null ? this.restendTime : 0;
        }

        public String getEnSysStatus() {
            if (this.enSysStatus == null) {
                return " ";
            } else {
                return this.enSysStatus.isEmpty() ? " " : this.enSysStatus;
            }
        }

        public Character getRightType() {
            return this.rightType != null ? this.rightType : ' ';
        }

        public void setFunctionStr(String functionStr) {
            this.functionStr = functionStr;
        }

        public void setFunctionName(String functionName) {
            this.functionName = functionName;
        }

        public void setPasswordType(Character passwordType) {
            this.passwordType = passwordType;
        }

        public void setAccessLevel(Character accessLevel) {
            this.accessLevel = accessLevel;
        }

        public void setFuncBusiType(Character funcBusiType) {
            this.funcBusiType = funcBusiType;
        }

        public void setFuncBusiProp(Character funcBusiProp) {
            this.funcBusiProp = funcBusiProp;
        }

        public void setFuncFlagStr(String funcFlagStr) {
            this.funcFlagStr = funcFlagStr;
        }

        public void setReststartTime(Integer reststartTime) {
            this.reststartTime = reststartTime;
        }

        public void setRestendTime(Integer restendTime) {
            this.restendTime = restendTime;
        }

        public void setEnSysStatus(String enSysStatus) {
            this.enSysStatus = enSysStatus;
        }

        public void setRightType(Character rightType) {
            this.rightType = rightType;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetHsfunctionInnerOutput:(");
            buffer.append("functionStr:" + this.functionStr);
            buffer.append(",functionName:" + this.functionName);
            buffer.append(",passwordType:" + this.passwordType);
            buffer.append(",accessLevel:" + this.accessLevel);
            buffer.append(",funcBusiType:" + this.funcBusiType);
            buffer.append(",funcBusiProp:" + this.funcBusiProp);
            buffer.append(",funcFlagStr:" + this.funcFlagStr);
            buffer.append(",reststartTime:" + this.reststartTime);
            buffer.append(",restendTime:" + this.restendTime);
            buffer.append(",enSysStatus:" + this.enSysStatus);
            buffer.append(",rightType:" + this.rightType);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.functionStr);
            builder.append(this.functionName);
            builder.append(this.passwordType);
            builder.append(this.accessLevel);
            builder.append(this.funcBusiType);
            builder.append(this.funcBusiProp);
            builder.append(this.funcFlagStr);
            builder.append(this.reststartTime);
            builder.append(this.restendTime);
            builder.append(this.enSysStatus);
            builder.append(this.rightType);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetHsfunctionInnerOutput) {
                InnerPbsService.GetHsfunctionInnerOutput test = (InnerPbsService.GetHsfunctionInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.functionStr, test.functionStr);
                builder.append(this.functionName, test.functionName);
                builder.append(this.passwordType, test.passwordType);
                builder.append(this.accessLevel, test.accessLevel);
                builder.append(this.funcBusiType, test.funcBusiType);
                builder.append(this.funcBusiProp, test.funcBusiProp);
                builder.append(this.funcFlagStr, test.funcFlagStr);
                builder.append(this.reststartTime, test.reststartTime);
                builder.append(this.restendTime, test.restendTime);
                builder.append(this.enSysStatus, test.enSysStatus);
                builder.append(this.rightType, test.rightType);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetHsfunctionInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String functionStr = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String actionStr = " ";

        public GetHsfunctionInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getFunctionStr() {
            if (this.functionStr == null) {
                return " ";
            } else {
                return this.functionStr.isEmpty() ? " " : this.functionStr;
            }
        }

        public String getActionStr() {
            if (this.actionStr == null) {
                return " ";
            } else {
                return this.actionStr.isEmpty() ? " " : this.actionStr;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setFunctionStr(String functionStr) {
            this.functionStr = functionStr;
        }

        public void setActionStr(String actionStr) {
            this.actionStr = actionStr;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetHsfunctionInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",functionStr:" + this.functionStr);
            buffer.append(",actionStr:" + this.actionStr);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.functionStr);
            builder.append(this.actionStr);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetHsfunctionInnerInput) {
                InnerPbsService.GetHsfunctionInnerInput test = (InnerPbsService.GetHsfunctionInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.functionStr, test.functionStr);
                builder.append(this.actionStr, test.actionStr);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetForbidroomcodeInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer branchNo = 0;
        private String forbidRoomCode = " ";

        public GetForbidroomcodeInnerOutput() {
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getForbidRoomCode() {
            if (this.forbidRoomCode == null) {
                return " ";
            } else {
                return this.forbidRoomCode.isEmpty() ? " " : this.forbidRoomCode;
            }
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setForbidRoomCode(String forbidRoomCode) {
            this.forbidRoomCode = forbidRoomCode;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetForbidroomcodeInnerOutput:(");
            buffer.append("branchNo:" + this.branchNo);
            buffer.append(",forbidRoomCode:" + this.forbidRoomCode);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.branchNo);
            builder.append(this.forbidRoomCode);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetForbidroomcodeInnerOutput) {
                InnerPbsService.GetForbidroomcodeInnerOutput test = (InnerPbsService.GetForbidroomcodeInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.forbidRoomCode, test.forbidRoomCode);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetForbidroomcodeInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer branchNo = 0;
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String orgCode = " ";

        public GetForbidroomcodeInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getOrgCode() {
            if (this.orgCode == null) {
                return " ";
            } else {
                return this.orgCode.isEmpty() ? " " : this.orgCode;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setOrgCode(String orgCode) {
            this.orgCode = orgCode;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetForbidroomcodeInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",orgCode:" + this.orgCode);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.branchNo);
            builder.append(this.orgCode);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetForbidroomcodeInnerInput) {
                InnerPbsService.GetForbidroomcodeInnerInput test = (InnerPbsService.GetForbidroomcodeInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.orgCode, test.orgCode);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetForbidclientgroupInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer branchNo = 0;
        private String forbidClientGroup = " ";

        public GetForbidclientgroupInnerOutput() {
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getForbidClientGroup() {
            if (this.forbidClientGroup == null) {
                return " ";
            } else {
                return this.forbidClientGroup.isEmpty() ? " " : this.forbidClientGroup;
            }
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setForbidClientGroup(String forbidClientGroup) {
            this.forbidClientGroup = forbidClientGroup;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetForbidclientgroupInnerOutput:(");
            buffer.append("branchNo:" + this.branchNo);
            buffer.append(",forbidClientGroup:" + this.forbidClientGroup);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.branchNo);
            builder.append(this.forbidClientGroup);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetForbidclientgroupInnerOutput) {
                InnerPbsService.GetForbidclientgroupInnerOutput test = (InnerPbsService.GetForbidclientgroupInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.forbidClientGroup, test.forbidClientGroup);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetForbidclientgroupInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer branchNo = 0;
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String orgCode = " ";

        public GetForbidclientgroupInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getOrgCode() {
            if (this.orgCode == null) {
                return " ";
            } else {
                return this.orgCode.isEmpty() ? " " : this.orgCode;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setOrgCode(String orgCode) {
            this.orgCode = orgCode;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetForbidclientgroupInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",orgCode:" + this.orgCode);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.branchNo);
            builder.append(this.orgCode);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetForbidclientgroupInnerInput) {
                InnerPbsService.GetForbidclientgroupInnerInput test = (InnerPbsService.GetForbidclientgroupInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.orgCode, test.orgCode);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetFiledownloadInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer total = 0;
        private Integer currentPage = 0;
        private List<InnerPbsService.FileDownloadDTO> rows = new ArrayList();

        public GetFiledownloadInnerOutput() {
        }

        public Integer getTotal() {
            return this.total != null ? this.total : 0;
        }

        public Integer getCurrentPage() {
            return this.currentPage != null ? this.currentPage : 0;
        }

        public List<InnerPbsService.FileDownloadDTO> getRows() {
            return (List)(this.rows != null ? this.rows : new ArrayList());
        }

        public void setTotal(Integer total) {
            this.total = total;
        }

        public void setCurrentPage(Integer currentPage) {
            this.currentPage = currentPage;
        }

        public void setRows(List<InnerPbsService.FileDownloadDTO> rows) {
            this.rows = rows;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetFiledownloadInnerOutput:(");
            buffer.append("total:" + this.total);
            buffer.append(",currentPage:" + this.currentPage);
            buffer.append(",rows:" + this.rows);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.total);
            builder.append(this.currentPage);
            builder.append(this.rows);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetFiledownloadInnerOutput) {
                InnerPbsService.GetFiledownloadInnerOutput test = (InnerPbsService.GetFiledownloadInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.total, test.total);
                builder.append(this.currentPage, test.currentPage);
                builder.append(this.rows, test.rows);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetFiledownloadInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String operatorNoB = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String menuCodeT = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String filePath = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String fileName = " ";
        private Integer initDate = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character downStatus = ' ';
        @SinogramLength(
                min = 0,
                max = 100,
                charset = "utf-8"
        )
        private String positionStr = " ";
        private Integer pageNo = 0;
        private Integer pageSize = 0;

        public GetFiledownloadInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getOperatorNoB() {
            if (this.operatorNoB == null) {
                return " ";
            } else {
                return this.operatorNoB.isEmpty() ? " " : this.operatorNoB;
            }
        }

        public String getMenuCodeT() {
            if (this.menuCodeT == null) {
                return " ";
            } else {
                return this.menuCodeT.isEmpty() ? " " : this.menuCodeT;
            }
        }

        public String getFilePath() {
            if (this.filePath == null) {
                return " ";
            } else {
                return this.filePath.isEmpty() ? " " : this.filePath;
            }
        }

        public String getFileName() {
            if (this.fileName == null) {
                return " ";
            } else {
                return this.fileName.isEmpty() ? " " : this.fileName;
            }
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public Character getDownStatus() {
            return this.downStatus != null ? this.downStatus : ' ';
        }

        public String getPositionStr() {
            if (this.positionStr == null) {
                return " ";
            } else {
                return this.positionStr.isEmpty() ? " " : this.positionStr;
            }
        }

        public Integer getPageNo() {
            return this.pageNo != null ? this.pageNo : 0;
        }

        public Integer getPageSize() {
            return this.pageSize != null ? this.pageSize : 0;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOperatorNoB(String operatorNoB) {
            this.operatorNoB = operatorNoB;
        }

        public void setMenuCodeT(String menuCodeT) {
            this.menuCodeT = menuCodeT;
        }

        public void setFilePath(String filePath) {
            this.filePath = filePath;
        }

        public void setFileName(String fileName) {
            this.fileName = fileName;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public void setDownStatus(Character downStatus) {
            this.downStatus = downStatus;
        }

        public void setPositionStr(String positionStr) {
            this.positionStr = positionStr;
        }

        public void setPageNo(Integer pageNo) {
            this.pageNo = pageNo;
        }

        public void setPageSize(Integer pageSize) {
            this.pageSize = pageSize;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetFiledownloadInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",operatorNoB:" + this.operatorNoB);
            buffer.append(",menuCodeT:" + this.menuCodeT);
            buffer.append(",filePath:" + this.filePath);
            buffer.append(",fileName:" + this.fileName);
            buffer.append(",initDate:" + this.initDate);
            buffer.append(",downStatus:" + this.downStatus);
            buffer.append(",positionStr:" + this.positionStr);
            buffer.append(",pageNo:" + this.pageNo);
            buffer.append(",pageSize:" + this.pageSize);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.operatorNoB);
            builder.append(this.menuCodeT);
            builder.append(this.filePath);
            builder.append(this.fileName);
            builder.append(this.initDate);
            builder.append(this.downStatus);
            builder.append(this.positionStr);
            builder.append(this.pageNo);
            builder.append(this.pageSize);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetFiledownloadInnerInput) {
                InnerPbsService.GetFiledownloadInnerInput test = (InnerPbsService.GetFiledownloadInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.operatorNoB, test.operatorNoB);
                builder.append(this.menuCodeT, test.menuCodeT);
                builder.append(this.filePath, test.filePath);
                builder.append(this.fileName, test.fileName);
                builder.append(this.initDate, test.initDate);
                builder.append(this.downStatus, test.downStatus);
                builder.append(this.positionStr, test.positionStr);
                builder.append(this.pageNo, test.pageNo);
                builder.append(this.pageSize, test.pageSize);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetFieldtonameInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String englishName = " ";
        private String chineseName = " ";
        private Integer dictEntry = 0;

        public GetFieldtonameInnerOutput() {
        }

        public String getEnglishName() {
            if (this.englishName == null) {
                return " ";
            } else {
                return this.englishName.isEmpty() ? " " : this.englishName;
            }
        }

        public String getChineseName() {
            if (this.chineseName == null) {
                return " ";
            } else {
                return this.chineseName.isEmpty() ? " " : this.chineseName;
            }
        }

        public Integer getDictEntry() {
            return this.dictEntry != null ? this.dictEntry : 0;
        }

        public void setEnglishName(String englishName) {
            this.englishName = englishName;
        }

        public void setChineseName(String chineseName) {
            this.chineseName = chineseName;
        }

        public void setDictEntry(Integer dictEntry) {
            this.dictEntry = dictEntry;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetFieldtonameInnerOutput:(");
            buffer.append("englishName:" + this.englishName);
            buffer.append(",chineseName:" + this.chineseName);
            buffer.append(",dictEntry:" + this.dictEntry);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.englishName);
            builder.append(this.chineseName);
            builder.append(this.dictEntry);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetFieldtonameInnerOutput) {
                InnerPbsService.GetFieldtonameInnerOutput test = (InnerPbsService.GetFieldtonameInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.englishName, test.englishName);
                builder.append(this.chineseName, test.chineseName);
                builder.append(this.dictEntry, test.dictEntry);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetFieldtonameInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 1,
                max = 2000,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String englishNameStr = " ";

        public GetFieldtonameInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getEnglishNameStr() {
            if (this.englishNameStr == null) {
                return " ";
            } else {
                return this.englishNameStr.isEmpty() ? " " : this.englishNameStr;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setEnglishNameStr(String englishNameStr) {
            this.englishNameStr = englishNameStr;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetFieldtonameInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",englishNameStr:" + this.englishNameStr);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.englishNameStr);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetFieldtonameInnerInput) {
                InnerPbsService.GetFieldtonameInnerInput test = (InnerPbsService.GetFieldtonameInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.englishNameStr, test.englishNameStr);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetFieldtonameAllInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private List<InnerPbsService.FieldtonameDTO> rows = new ArrayList();

        public GetFieldtonameAllInnerOutput() {
        }

        public List<InnerPbsService.FieldtonameDTO> getRows() {
            return (List)(this.rows != null ? this.rows : new ArrayList());
        }

        public void setRows(List<InnerPbsService.FieldtonameDTO> rows) {
            this.rows = rows;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetFieldtonameAllInnerOutput:(");
            buffer.append("rows:" + this.rows);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.rows);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetFieldtonameAllInnerOutput) {
                InnerPbsService.GetFieldtonameAllInnerOutput test = (InnerPbsService.GetFieldtonameAllInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.rows, test.rows);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetFieldtonameAllInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 180,
                charset = "utf-8"
        )
        private String englishName = " ";
        private Integer pageSize = 0;
        private Integer pageNo = 0;

        public GetFieldtonameAllInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getEnglishName() {
            if (this.englishName == null) {
                return " ";
            } else {
                return this.englishName.isEmpty() ? " " : this.englishName;
            }
        }

        public Integer getPageSize() {
            return this.pageSize != null ? this.pageSize : 0;
        }

        public Integer getPageNo() {
            return this.pageNo != null ? this.pageNo : 0;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setEnglishName(String englishName) {
            this.englishName = englishName;
        }

        public void setPageSize(Integer pageSize) {
            this.pageSize = pageSize;
        }

        public void setPageNo(Integer pageNo) {
            this.pageNo = pageNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetFieldtonameAllInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",englishName:" + this.englishName);
            buffer.append(",pageSize:" + this.pageSize);
            buffer.append(",pageNo:" + this.pageNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.englishName);
            builder.append(this.pageSize);
            builder.append(this.pageNo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetFieldtonameAllInnerInput) {
                InnerPbsService.GetFieldtonameAllInnerInput test = (InnerPbsService.GetFieldtonameAllInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.englishName, test.englishName);
                builder.append(this.pageSize, test.pageSize);
                builder.append(this.pageNo, test.pageNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetDictionaryWithDictentryStrInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer dictEntry = 0;
        private String dictName = " ";
        private List<InnerPbsService.DictionaryOutputDTO> dictionarys = new ArrayList();
        private String englishName = " ";
        private String entryName = " ";

        public GetDictionaryWithDictentryStrInnerOutput() {
        }

        public Integer getDictEntry() {
            return this.dictEntry != null ? this.dictEntry : 0;
        }

        public String getDictName() {
            if (this.dictName == null) {
                return " ";
            } else {
                return this.dictName.isEmpty() ? " " : this.dictName;
            }
        }

        public List<InnerPbsService.DictionaryOutputDTO> getDictionarys() {
            return (List)(this.dictionarys != null ? this.dictionarys : new ArrayList());
        }

        public String getEnglishName() {
            if (this.englishName == null) {
                return " ";
            } else {
                return this.englishName.isEmpty() ? " " : this.englishName;
            }
        }

        public String getEntryName() {
            if (this.entryName == null) {
                return " ";
            } else {
                return this.entryName.isEmpty() ? " " : this.entryName;
            }
        }

        public void setDictEntry(Integer dictEntry) {
            this.dictEntry = dictEntry;
        }

        public void setDictName(String dictName) {
            this.dictName = dictName;
        }

        public void setDictionarys(List<InnerPbsService.DictionaryOutputDTO> dictionarys) {
            this.dictionarys = dictionarys;
        }

        public void setEnglishName(String englishName) {
            this.englishName = englishName;
        }

        public void setEntryName(String entryName) {
            this.entryName = entryName;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetDictionaryWithDictentryStrInnerOutput:(");
            buffer.append("dictEntry:" + this.dictEntry);
            buffer.append(",dictName:" + this.dictName);
            buffer.append(",dictionarys:" + this.dictionarys);
            buffer.append(",englishName:" + this.englishName);
            buffer.append(",entryName:" + this.entryName);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.dictEntry);
            builder.append(this.dictName);
            builder.append(this.dictionarys);
            builder.append(this.englishName);
            builder.append(this.entryName);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetDictionaryWithDictentryStrInnerOutput) {
                InnerPbsService.GetDictionaryWithDictentryStrInnerOutput test = (InnerPbsService.GetDictionaryWithDictentryStrInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.dictEntry, test.dictEntry);
                builder.append(this.dictName, test.dictName);
                builder.append(this.dictionarys, test.dictionarys);
                builder.append(this.englishName, test.englishName);
                builder.append(this.entryName, test.entryName);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetDictionaryWithDictentryStrInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 1,
                max = 2000,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String dictEntryStr = " ";
        private Integer branchNo = 0;

        public GetDictionaryWithDictentryStrInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getDictEntryStr() {
            if (this.dictEntryStr == null) {
                return " ";
            } else {
                return this.dictEntryStr.isEmpty() ? " " : this.dictEntryStr;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setDictEntryStr(String dictEntryStr) {
            this.dictEntryStr = dictEntryStr;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetDictionaryWithDictentryStrInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",dictEntryStr:" + this.dictEntryStr);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.dictEntryStr);
            builder.append(this.branchNo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetDictionaryWithDictentryStrInnerInput) {
                InnerPbsService.GetDictionaryWithDictentryStrInnerInput test = (InnerPbsService.GetDictionaryWithDictentryStrInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.dictEntryStr, test.dictEntryStr);
                builder.append(this.branchNo, test.branchNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetDictionarySingleInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer branchNo = 0;
        private Integer dictEntry = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character dictType = ' ';
        private String subEntry = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character accessLevel = ' ';
        private String dictPrompt = " ";

        public GetDictionarySingleInnerOutput() {
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Integer getDictEntry() {
            return this.dictEntry != null ? this.dictEntry : 0;
        }

        public Character getDictType() {
            return this.dictType != null ? this.dictType : ' ';
        }

        public String getSubEntry() {
            if (this.subEntry == null) {
                return " ";
            } else {
                return this.subEntry.isEmpty() ? " " : this.subEntry;
            }
        }

        public Character getAccessLevel() {
            return this.accessLevel != null ? this.accessLevel : ' ';
        }

        public String getDictPrompt() {
            if (this.dictPrompt == null) {
                return " ";
            } else {
                return this.dictPrompt.isEmpty() ? " " : this.dictPrompt;
            }
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setDictEntry(Integer dictEntry) {
            this.dictEntry = dictEntry;
        }

        public void setDictType(Character dictType) {
            this.dictType = dictType;
        }

        public void setSubEntry(String subEntry) {
            this.subEntry = subEntry;
        }

        public void setAccessLevel(Character accessLevel) {
            this.accessLevel = accessLevel;
        }

        public void setDictPrompt(String dictPrompt) {
            this.dictPrompt = dictPrompt;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetDictionarySingleInnerOutput:(");
            buffer.append("branchNo:" + this.branchNo);
            buffer.append(",dictEntry:" + this.dictEntry);
            buffer.append(",dictType:" + this.dictType);
            buffer.append(",subEntry:" + this.subEntry);
            buffer.append(",accessLevel:" + this.accessLevel);
            buffer.append(",dictPrompt:" + this.dictPrompt);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.branchNo);
            builder.append(this.dictEntry);
            builder.append(this.dictType);
            builder.append(this.subEntry);
            builder.append(this.accessLevel);
            builder.append(this.dictPrompt);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetDictionarySingleInnerOutput) {
                InnerPbsService.GetDictionarySingleInnerOutput test = (InnerPbsService.GetDictionarySingleInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.dictEntry, test.dictEntry);
                builder.append(this.dictType, test.dictType);
                builder.append(this.subEntry, test.subEntry);
                builder.append(this.accessLevel, test.accessLevel);
                builder.append(this.dictPrompt, test.dictPrompt);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetDictionarySingleInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer dictEntry = 0;
        @SinogramLength(
                min = 0,
                max = 8,
                charset = "utf-8"
        )
        private String subEntry = " ";

        public GetDictionarySingleInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getDictEntry() {
            return this.dictEntry != null ? this.dictEntry : 0;
        }

        public String getSubEntry() {
            if (this.subEntry == null) {
                return " ";
            } else {
                return this.subEntry.isEmpty() ? " " : this.subEntry;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setDictEntry(Integer dictEntry) {
            this.dictEntry = dictEntry;
        }

        public void setSubEntry(String subEntry) {
            this.subEntry = subEntry;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetDictionarySingleInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",dictEntry:" + this.dictEntry);
            buffer.append(",subEntry:" + this.subEntry);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.dictEntry);
            builder.append(this.subEntry);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetDictionarySingleInnerInput) {
                InnerPbsService.GetDictionarySingleInnerInput test = (InnerPbsService.GetDictionarySingleInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.dictEntry, test.dictEntry);
                builder.append(this.subEntry, test.subEntry);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetDictionaryInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer currentPage = 0;
        private List<InnerPbsService.DictionaryOutputDTO> results = new ArrayList();
        private Integer total = 0;

        public GetDictionaryInnerOutput() {
        }

        public Integer getCurrentPage() {
            return this.currentPage != null ? this.currentPage : 0;
        }

        public List<InnerPbsService.DictionaryOutputDTO> getResults() {
            return (List)(this.results != null ? this.results : new ArrayList());
        }

        public Integer getTotal() {
            return this.total != null ? this.total : 0;
        }

        public void setCurrentPage(Integer currentPage) {
            this.currentPage = currentPage;
        }

        public void setResults(List<InnerPbsService.DictionaryOutputDTO> results) {
            this.results = results;
        }

        public void setTotal(Integer total) {
            this.total = total;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetDictionaryInnerOutput:(");
            buffer.append("currentPage:" + this.currentPage);
            buffer.append(",results:" + this.results);
            buffer.append(",total:" + this.total);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.currentPage);
            builder.append(this.results);
            builder.append(this.total);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetDictionaryInnerOutput) {
                InnerPbsService.GetDictionaryInnerOutput test = (InnerPbsService.GetDictionaryInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.currentPage, test.currentPage);
                builder.append(this.results, test.results);
                builder.append(this.total, test.total);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetDictionaryInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer pageNo = 0;
        private Integer pageSize = 0;
        private Integer branchNo = 0;

        public GetDictionaryInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getPageNo() {
            return this.pageNo != null ? this.pageNo : 0;
        }

        public Integer getPageSize() {
            return this.pageSize != null ? this.pageSize : 0;
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setPageNo(Integer pageNo) {
            this.pageNo = pageNo;
        }

        public void setPageSize(Integer pageSize) {
            this.pageSize = pageSize;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetDictionaryInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",pageNo:" + this.pageNo);
            buffer.append(",pageSize:" + this.pageSize);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.pageNo);
            builder.append(this.pageSize);
            builder.append(this.branchNo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetDictionaryInnerInput) {
                InnerPbsService.GetDictionaryInnerInput test = (InnerPbsService.GetDictionaryInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.pageNo, test.pageNo);
                builder.append(this.pageSize, test.pageSize);
                builder.append(this.branchNo, test.branchNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetDictentryPageInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer currentPage = 0;
        private Integer total = 0;
        private List<InnerPbsService.DictEntryDTO> rows = new ArrayList();

        public GetDictentryPageInnerOutput() {
        }

        public Integer getCurrentPage() {
            return this.currentPage != null ? this.currentPage : 0;
        }

        public Integer getTotal() {
            return this.total != null ? this.total : 0;
        }

        public List<InnerPbsService.DictEntryDTO> getRows() {
            return (List)(this.rows != null ? this.rows : new ArrayList());
        }

        public void setCurrentPage(Integer currentPage) {
            this.currentPage = currentPage;
        }

        public void setTotal(Integer total) {
            this.total = total;
        }

        public void setRows(List<InnerPbsService.DictEntryDTO> rows) {
            this.rows = rows;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetDictentryPageInnerOutput:(");
            buffer.append("currentPage:" + this.currentPage);
            buffer.append(",total:" + this.total);
            buffer.append(",rows:" + this.rows);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.currentPage);
            builder.append(this.total);
            builder.append(this.rows);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetDictentryPageInnerOutput) {
                InnerPbsService.GetDictentryPageInnerOutput test = (InnerPbsService.GetDictentryPageInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.currentPage, test.currentPage);
                builder.append(this.total, test.total);
                builder.append(this.rows, test.rows);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetDictentryPageInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer dictEntry = 0;
        private Integer pageNo = 0;
        private Integer pageSize = 0;

        public GetDictentryPageInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getDictEntry() {
            return this.dictEntry != null ? this.dictEntry : 0;
        }

        public Integer getPageNo() {
            return this.pageNo != null ? this.pageNo : 0;
        }

        public Integer getPageSize() {
            return this.pageSize != null ? this.pageSize : 0;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setDictEntry(Integer dictEntry) {
            this.dictEntry = dictEntry;
        }

        public void setPageNo(Integer pageNo) {
            this.pageNo = pageNo;
        }

        public void setPageSize(Integer pageSize) {
            this.pageSize = pageSize;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetDictentryPageInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",dictEntry:" + this.dictEntry);
            buffer.append(",pageNo:" + this.pageNo);
            buffer.append(",pageSize:" + this.pageSize);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.dictEntry);
            builder.append(this.pageNo);
            builder.append(this.pageSize);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetDictentryPageInnerInput) {
                InnerPbsService.GetDictentryPageInnerInput test = (InnerPbsService.GetDictentryPageInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.dictEntry, test.dictEntry);
                builder.append(this.pageNo, test.pageNo);
                builder.append(this.pageSize, test.pageSize);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetConsumwayInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String consumWay = " ";
        private String consumName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character funddealMode = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character settdealMode = ' ';
        private String consumAccount = " ";
        private String remark = " ";

        public GetConsumwayInnerOutput() {
        }

        public String getConsumWay() {
            if (this.consumWay == null) {
                return " ";
            } else {
                return this.consumWay.isEmpty() ? " " : this.consumWay;
            }
        }

        public String getConsumName() {
            if (this.consumName == null) {
                return " ";
            } else {
                return this.consumName.isEmpty() ? " " : this.consumName;
            }
        }

        public Character getFunddealMode() {
            return this.funddealMode != null ? this.funddealMode : ' ';
        }

        public Character getSettdealMode() {
            return this.settdealMode != null ? this.settdealMode : ' ';
        }

        public String getConsumAccount() {
            if (this.consumAccount == null) {
                return " ";
            } else {
                return this.consumAccount.isEmpty() ? " " : this.consumAccount;
            }
        }

        public String getRemark() {
            if (this.remark == null) {
                return " ";
            } else {
                return this.remark.isEmpty() ? " " : this.remark;
            }
        }

        public void setConsumWay(String consumWay) {
            this.consumWay = consumWay;
        }

        public void setConsumName(String consumName) {
            this.consumName = consumName;
        }

        public void setFunddealMode(Character funddealMode) {
            this.funddealMode = funddealMode;
        }

        public void setSettdealMode(Character settdealMode) {
            this.settdealMode = settdealMode;
        }

        public void setConsumAccount(String consumAccount) {
            this.consumAccount = consumAccount;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetConsumwayInnerOutput:(");
            buffer.append("consumWay:" + this.consumWay);
            buffer.append(",consumName:" + this.consumName);
            buffer.append(",funddealMode:" + this.funddealMode);
            buffer.append(",settdealMode:" + this.settdealMode);
            buffer.append(",consumAccount:" + this.consumAccount);
            buffer.append(",remark:" + this.remark);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.consumWay);
            builder.append(this.consumName);
            builder.append(this.funddealMode);
            builder.append(this.settdealMode);
            builder.append(this.consumAccount);
            builder.append(this.remark);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetConsumwayInnerOutput) {
                InnerPbsService.GetConsumwayInnerOutput test = (InnerPbsService.GetConsumwayInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.consumWay, test.consumWay);
                builder.append(this.consumName, test.consumName);
                builder.append(this.funddealMode, test.funddealMode);
                builder.append(this.settdealMode, test.settdealMode);
                builder.append(this.consumAccount, test.consumAccount);
                builder.append(this.remark, test.remark);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetConsumwayInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String consumWay = " ";

        public GetConsumwayInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getConsumWay() {
            if (this.consumWay == null) {
                return " ";
            } else {
                return this.consumWay.isEmpty() ? " " : this.consumWay;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setConsumWay(String consumWay) {
            this.consumWay = consumWay;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetConsumwayInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",consumWay:" + this.consumWay);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.consumWay);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetConsumwayInnerInput) {
                InnerPbsService.GetConsumwayInnerInput test = (InnerPbsService.GetConsumwayInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.consumWay, test.consumWay);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetConsumconfigInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String consumKind = " ";
        private String consumWay = " ";
        private String operatorNo = " ";
        private String opPassword = " ";

        public GetConsumconfigInnerOutput() {
        }

        public String getConsumKind() {
            if (this.consumKind == null) {
                return " ";
            } else {
                return this.consumKind.isEmpty() ? " " : this.consumKind;
            }
        }

        public String getConsumWay() {
            if (this.consumWay == null) {
                return " ";
            } else {
                return this.consumWay.isEmpty() ? " " : this.consumWay;
            }
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public void setConsumKind(String consumKind) {
            this.consumKind = consumKind;
        }

        public void setConsumWay(String consumWay) {
            this.consumWay = consumWay;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetConsumconfigInnerOutput:(");
            buffer.append("consumKind:" + this.consumKind);
            buffer.append(",consumWay:" + this.consumWay);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.consumKind);
            builder.append(this.consumWay);
            builder.append(this.operatorNo);
            builder.append(this.opPassword);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetConsumconfigInnerOutput) {
                InnerPbsService.GetConsumconfigInnerOutput test = (InnerPbsService.GetConsumconfigInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.consumKind, test.consumKind);
                builder.append(this.consumWay, test.consumWay);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opPassword, test.opPassword);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetConsumconfigInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 2,
                charset = "utf-8"
        )
        private String consumKind = " ";

        public GetConsumconfigInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getConsumKind() {
            if (this.consumKind == null) {
                return " ";
            } else {
                return this.consumKind.isEmpty() ? " " : this.consumKind;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setConsumKind(String consumKind) {
            this.consumKind = consumKind;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetConsumconfigInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",consumKind:" + this.consumKind);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.consumKind);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetConsumconfigInnerInput) {
                InnerPbsService.GetConsumconfigInnerInput test = (InnerPbsService.GetConsumconfigInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.consumKind, test.consumKind);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetClientInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer branchNo = 0;
        private String custId = " ";
        private String clientId = " ";
        private String clientName = " ";
        private String fullName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character organFlag = ' ';
        private String nationality = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character idKind = ' ';
        private String idNo = " ";
        private Integer idBegindate = 0;
        private Integer idEnddate = 0;
        private String idAddress = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character clientGender = ' ';
        private String mobileTel = " ";
        private Integer branchNoFund = 0;
        private String eMail = " ";

        public GetClientInnerOutput() {
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getCustId() {
            if (this.custId == null) {
                return " ";
            } else {
                return this.custId.isEmpty() ? " " : this.custId;
            }
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getClientName() {
            if (this.clientName == null) {
                return " ";
            } else {
                return this.clientName.isEmpty() ? " " : this.clientName;
            }
        }

        public String getFullName() {
            if (this.fullName == null) {
                return " ";
            } else {
                return this.fullName.isEmpty() ? " " : this.fullName;
            }
        }

        public Character getOrganFlag() {
            return this.organFlag != null ? this.organFlag : ' ';
        }

        public String getNationality() {
            if (this.nationality == null) {
                return " ";
            } else {
                return this.nationality.isEmpty() ? " " : this.nationality;
            }
        }

        public Character getIdKind() {
            return this.idKind != null ? this.idKind : ' ';
        }

        public String getIdNo() {
            if (this.idNo == null) {
                return " ";
            } else {
                return this.idNo.isEmpty() ? " " : this.idNo;
            }
        }

        public Integer getIdBegindate() {
            return this.idBegindate != null ? this.idBegindate : 0;
        }

        public Integer getIdEnddate() {
            return this.idEnddate != null ? this.idEnddate : 0;
        }

        public String getIdAddress() {
            if (this.idAddress == null) {
                return " ";
            } else {
                return this.idAddress.isEmpty() ? " " : this.idAddress;
            }
        }

        public Character getClientGender() {
            return this.clientGender != null ? this.clientGender : ' ';
        }

        public String getMobileTel() {
            if (this.mobileTel == null) {
                return " ";
            } else {
                return this.mobileTel.isEmpty() ? " " : this.mobileTel;
            }
        }

        public Integer getBranchNoFund() {
            return this.branchNoFund != null ? this.branchNoFund : 0;
        }

        public String geteMail() {
            if (this.eMail == null) {
                return " ";
            } else {
                return this.eMail.isEmpty() ? " " : this.eMail;
            }
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setCustId(String custId) {
            this.custId = custId;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setClientName(String clientName) {
            this.clientName = clientName;
        }

        public void setFullName(String fullName) {
            this.fullName = fullName;
        }

        public void setOrganFlag(Character organFlag) {
            this.organFlag = organFlag;
        }

        public void setNationality(String nationality) {
            this.nationality = nationality;
        }

        public void setIdKind(Character idKind) {
            this.idKind = idKind;
        }

        public void setIdNo(String idNo) {
            this.idNo = idNo;
        }

        public void setIdBegindate(Integer idBegindate) {
            this.idBegindate = idBegindate;
        }

        public void setIdEnddate(Integer idEnddate) {
            this.idEnddate = idEnddate;
        }

        public void setIdAddress(String idAddress) {
            this.idAddress = idAddress;
        }

        public void setClientGender(Character clientGender) {
            this.clientGender = clientGender;
        }

        public void setMobileTel(String mobileTel) {
            this.mobileTel = mobileTel;
        }

        public void setBranchNoFund(Integer branchNoFund) {
            this.branchNoFund = branchNoFund;
        }

        public void seteMail(String eMail) {
            this.eMail = eMail;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetClientInnerOutput:(");
            buffer.append("branchNo:" + this.branchNo);
            buffer.append(",custId:" + this.custId);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",clientName:" + this.clientName);
            buffer.append(",fullName:" + this.fullName);
            buffer.append(",organFlag:" + this.organFlag);
            buffer.append(",nationality:" + this.nationality);
            buffer.append(",idKind:" + this.idKind);
            buffer.append(",idNo:" + this.idNo);
            buffer.append(",idBegindate:" + this.idBegindate);
            buffer.append(",idEnddate:" + this.idEnddate);
            buffer.append(",idAddress:" + this.idAddress);
            buffer.append(",clientGender:" + this.clientGender);
            buffer.append(",mobileTel:" + this.mobileTel);
            buffer.append(",branchNoFund:" + this.branchNoFund);
            buffer.append(",eMail:" + this.eMail);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.branchNo);
            builder.append(this.custId);
            builder.append(this.clientId);
            builder.append(this.clientName);
            builder.append(this.fullName);
            builder.append(this.organFlag);
            builder.append(this.nationality);
            builder.append(this.idKind);
            builder.append(this.idNo);
            builder.append(this.idBegindate);
            builder.append(this.idEnddate);
            builder.append(this.idAddress);
            builder.append(this.clientGender);
            builder.append(this.mobileTel);
            builder.append(this.branchNoFund);
            builder.append(this.eMail);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetClientInnerOutput) {
                InnerPbsService.GetClientInnerOutput test = (InnerPbsService.GetClientInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.custId, test.custId);
                builder.append(this.clientId, test.clientId);
                builder.append(this.clientName, test.clientName);
                builder.append(this.fullName, test.fullName);
                builder.append(this.organFlag, test.organFlag);
                builder.append(this.nationality, test.nationality);
                builder.append(this.idKind, test.idKind);
                builder.append(this.idNo, test.idNo);
                builder.append(this.idBegindate, test.idBegindate);
                builder.append(this.idEnddate, test.idEnddate);
                builder.append(this.idAddress, test.idAddress);
                builder.append(this.clientGender, test.clientGender);
                builder.append(this.mobileTel, test.mobileTel);
                builder.append(this.branchNoFund, test.branchNoFund);
                builder.append(this.eMail, test.eMail);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetClientInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fundAccount = " ";

        public GetClientInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetClientInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.clientId);
            builder.append(this.fundAccount);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetClientInnerInput) {
                InnerPbsService.GetClientInnerInput test = (InnerPbsService.GetClientInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.clientId, test.clientId);
                builder.append(this.fundAccount, test.fundAccount);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetCitycodeInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String cityCode = " ";
        private String upCityCode = " ";
        private String cityName = " ";
        private String citySpell = " ";
        private String cityLetter = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character cityLevel = ' ';
        private String positionStr = " ";
        private String remark = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character cityGroup = ' ';

        public GetCitycodeInnerOutput() {
        }

        public String getCityCode() {
            if (this.cityCode == null) {
                return " ";
            } else {
                return this.cityCode.isEmpty() ? " " : this.cityCode;
            }
        }

        public String getUpCityCode() {
            if (this.upCityCode == null) {
                return " ";
            } else {
                return this.upCityCode.isEmpty() ? " " : this.upCityCode;
            }
        }

        public String getCityName() {
            if (this.cityName == null) {
                return " ";
            } else {
                return this.cityName.isEmpty() ? " " : this.cityName;
            }
        }

        public String getCitySpell() {
            if (this.citySpell == null) {
                return " ";
            } else {
                return this.citySpell.isEmpty() ? " " : this.citySpell;
            }
        }

        public String getCityLetter() {
            if (this.cityLetter == null) {
                return " ";
            } else {
                return this.cityLetter.isEmpty() ? " " : this.cityLetter;
            }
        }

        public Character getCityLevel() {
            return this.cityLevel != null ? this.cityLevel : ' ';
        }

        public String getPositionStr() {
            if (this.positionStr == null) {
                return " ";
            } else {
                return this.positionStr.isEmpty() ? " " : this.positionStr;
            }
        }

        public String getRemark() {
            if (this.remark == null) {
                return " ";
            } else {
                return this.remark.isEmpty() ? " " : this.remark;
            }
        }

        public Character getCityGroup() {
            return this.cityGroup != null ? this.cityGroup : ' ';
        }

        public void setCityCode(String cityCode) {
            this.cityCode = cityCode;
        }

        public void setUpCityCode(String upCityCode) {
            this.upCityCode = upCityCode;
        }

        public void setCityName(String cityName) {
            this.cityName = cityName;
        }

        public void setCitySpell(String citySpell) {
            this.citySpell = citySpell;
        }

        public void setCityLetter(String cityLetter) {
            this.cityLetter = cityLetter;
        }

        public void setCityLevel(Character cityLevel) {
            this.cityLevel = cityLevel;
        }

        public void setPositionStr(String positionStr) {
            this.positionStr = positionStr;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public void setCityGroup(Character cityGroup) {
            this.cityGroup = cityGroup;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetCitycodeInnerOutput:(");
            buffer.append("cityCode:" + this.cityCode);
            buffer.append(",upCityCode:" + this.upCityCode);
            buffer.append(",cityName:" + this.cityName);
            buffer.append(",citySpell:" + this.citySpell);
            buffer.append(",cityLetter:" + this.cityLetter);
            buffer.append(",cityLevel:" + this.cityLevel);
            buffer.append(",positionStr:" + this.positionStr);
            buffer.append(",remark:" + this.remark);
            buffer.append(",cityGroup:" + this.cityGroup);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.cityCode);
            builder.append(this.upCityCode);
            builder.append(this.cityName);
            builder.append(this.citySpell);
            builder.append(this.cityLetter);
            builder.append(this.cityLevel);
            builder.append(this.positionStr);
            builder.append(this.remark);
            builder.append(this.cityGroup);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetCitycodeInnerOutput) {
                InnerPbsService.GetCitycodeInnerOutput test = (InnerPbsService.GetCitycodeInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.cityCode, test.cityCode);
                builder.append(this.upCityCode, test.upCityCode);
                builder.append(this.cityName, test.cityName);
                builder.append(this.citySpell, test.citySpell);
                builder.append(this.cityLetter, test.cityLetter);
                builder.append(this.cityLevel, test.cityLevel);
                builder.append(this.positionStr, test.positionStr);
                builder.append(this.remark, test.remark);
                builder.append(this.cityGroup, test.cityGroup);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetCitycodeInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 1,
                max = 16,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String cityCode = " ";

        public GetCitycodeInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getCityCode() {
            if (this.cityCode == null) {
                return " ";
            } else {
                return this.cityCode.isEmpty() ? " " : this.cityCode;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setCityCode(String cityCode) {
            this.cityCode = cityCode;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetCitycodeInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",cityCode:" + this.cityCode);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.cityCode);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetCitycodeInnerInput) {
                InnerPbsService.GetCitycodeInnerInput test = (InnerPbsService.GetCitycodeInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.cityCode, test.cityCode);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetCitycodeAllInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String cityCode = " ";
        private String upCityCode = " ";
        private String cityName = " ";
        private String citySpell = " ";
        private String cityLetter = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character cityLevel = ' ';
        private String positionStr = " ";
        private String remark = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character cityGroup = ' ';

        public GetCitycodeAllInnerOutput() {
        }

        public String getCityCode() {
            if (this.cityCode == null) {
                return " ";
            } else {
                return this.cityCode.isEmpty() ? " " : this.cityCode;
            }
        }

        public String getUpCityCode() {
            if (this.upCityCode == null) {
                return " ";
            } else {
                return this.upCityCode.isEmpty() ? " " : this.upCityCode;
            }
        }

        public String getCityName() {
            if (this.cityName == null) {
                return " ";
            } else {
                return this.cityName.isEmpty() ? " " : this.cityName;
            }
        }

        public String getCitySpell() {
            if (this.citySpell == null) {
                return " ";
            } else {
                return this.citySpell.isEmpty() ? " " : this.citySpell;
            }
        }

        public String getCityLetter() {
            if (this.cityLetter == null) {
                return " ";
            } else {
                return this.cityLetter.isEmpty() ? " " : this.cityLetter;
            }
        }

        public Character getCityLevel() {
            return this.cityLevel != null ? this.cityLevel : ' ';
        }

        public String getPositionStr() {
            if (this.positionStr == null) {
                return " ";
            } else {
                return this.positionStr.isEmpty() ? " " : this.positionStr;
            }
        }

        public String getRemark() {
            if (this.remark == null) {
                return " ";
            } else {
                return this.remark.isEmpty() ? " " : this.remark;
            }
        }

        public Character getCityGroup() {
            return this.cityGroup != null ? this.cityGroup : ' ';
        }

        public void setCityCode(String cityCode) {
            this.cityCode = cityCode;
        }

        public void setUpCityCode(String upCityCode) {
            this.upCityCode = upCityCode;
        }

        public void setCityName(String cityName) {
            this.cityName = cityName;
        }

        public void setCitySpell(String citySpell) {
            this.citySpell = citySpell;
        }

        public void setCityLetter(String cityLetter) {
            this.cityLetter = cityLetter;
        }

        public void setCityLevel(Character cityLevel) {
            this.cityLevel = cityLevel;
        }

        public void setPositionStr(String positionStr) {
            this.positionStr = positionStr;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public void setCityGroup(Character cityGroup) {
            this.cityGroup = cityGroup;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetCitycodeAllInnerOutput:(");
            buffer.append("cityCode:" + this.cityCode);
            buffer.append(",upCityCode:" + this.upCityCode);
            buffer.append(",cityName:" + this.cityName);
            buffer.append(",citySpell:" + this.citySpell);
            buffer.append(",cityLetter:" + this.cityLetter);
            buffer.append(",cityLevel:" + this.cityLevel);
            buffer.append(",positionStr:" + this.positionStr);
            buffer.append(",remark:" + this.remark);
            buffer.append(",cityGroup:" + this.cityGroup);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.cityCode);
            builder.append(this.upCityCode);
            builder.append(this.cityName);
            builder.append(this.citySpell);
            builder.append(this.cityLetter);
            builder.append(this.cityLevel);
            builder.append(this.positionStr);
            builder.append(this.remark);
            builder.append(this.cityGroup);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetCitycodeAllInnerOutput) {
                InnerPbsService.GetCitycodeAllInnerOutput test = (InnerPbsService.GetCitycodeAllInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.cityCode, test.cityCode);
                builder.append(this.upCityCode, test.upCityCode);
                builder.append(this.cityName, test.cityName);
                builder.append(this.citySpell, test.citySpell);
                builder.append(this.cityLetter, test.cityLetter);
                builder.append(this.cityLevel, test.cityLevel);
                builder.append(this.positionStr, test.positionStr);
                builder.append(this.remark, test.remark);
                builder.append(this.cityGroup, test.cityGroup);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetCitycodeAllInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 16,
                charset = "utf-8"
        )
        private String cityCode = " ";

        public GetCitycodeAllInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getCityCode() {
            if (this.cityCode == null) {
                return " ";
            } else {
                return this.cityCode.isEmpty() ? " " : this.cityCode;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setCityCode(String cityCode) {
            this.cityCode = cityCode;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetCitycodeAllInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",cityCode:" + this.cityCode);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.cityCode);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetCitycodeAllInnerInput) {
                InnerPbsService.GetCitycodeAllInnerInput test = (InnerPbsService.GetCitycodeAllInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.cityCode, test.cityCode);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetBusinessflagPageInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer total = 0;
        private Integer currentPage = 0;
        private List<InnerPbsService.BusinessFlagDTO> rows = new ArrayList();

        public GetBusinessflagPageInnerOutput() {
        }

        public Integer getTotal() {
            return this.total != null ? this.total : 0;
        }

        public Integer getCurrentPage() {
            return this.currentPage != null ? this.currentPage : 0;
        }

        public List<InnerPbsService.BusinessFlagDTO> getRows() {
            return (List)(this.rows != null ? this.rows : new ArrayList());
        }

        public void setTotal(Integer total) {
            this.total = total;
        }

        public void setCurrentPage(Integer currentPage) {
            this.currentPage = currentPage;
        }

        public void setRows(List<InnerPbsService.BusinessFlagDTO> rows) {
            this.rows = rows;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetBusinessflagPageInnerOutput:(");
            buffer.append("total:" + this.total);
            buffer.append(",currentPage:" + this.currentPage);
            buffer.append(",rows:" + this.rows);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.total);
            builder.append(this.currentPage);
            builder.append(this.rows);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetBusinessflagPageInnerOutput) {
                InnerPbsService.GetBusinessflagPageInnerOutput test = (InnerPbsService.GetBusinessflagPageInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.total, test.total);
                builder.append(this.currentPage, test.currentPage);
                builder.append(this.rows, test.rows);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetBusinessflagPageInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer pageSize = 0;
        private Integer pageNo = 0;
        private Integer businessFlag = 0;

        public GetBusinessflagPageInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getPageSize() {
            return this.pageSize != null ? this.pageSize : 0;
        }

        public Integer getPageNo() {
            return this.pageNo != null ? this.pageNo : 0;
        }

        public Integer getBusinessFlag() {
            return this.businessFlag != null ? this.businessFlag : 0;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setPageSize(Integer pageSize) {
            this.pageSize = pageSize;
        }

        public void setPageNo(Integer pageNo) {
            this.pageNo = pageNo;
        }

        public void setBusinessFlag(Integer businessFlag) {
            this.businessFlag = businessFlag;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetBusinessflagPageInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",pageSize:" + this.pageSize);
            buffer.append(",pageNo:" + this.pageNo);
            buffer.append(",businessFlag:" + this.businessFlag);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.pageSize);
            builder.append(this.pageNo);
            builder.append(this.businessFlag);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetBusinessflagPageInnerInput) {
                InnerPbsService.GetBusinessflagPageInnerInput test = (InnerPbsService.GetBusinessflagPageInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.pageSize, test.pageSize);
                builder.append(this.pageNo, test.pageNo);
                builder.append(this.businessFlag, test.businessFlag);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetBusinessargInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer businsysId = 0;
        private String businsysName = " ";
        private String operatorNo = " ";
        private String opPassword = " ";
        private Integer branchNo = 0;

        public GetBusinessargInnerOutput() {
        }

        public Integer getBusinsysId() {
            return this.businsysId != null ? this.businsysId : 0;
        }

        public String getBusinsysName() {
            if (this.businsysName == null) {
                return " ";
            } else {
                return this.businsysName.isEmpty() ? " " : this.businsysName;
            }
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public void setBusinsysId(Integer businsysId) {
            this.businsysId = businsysId;
        }

        public void setBusinsysName(String businsysName) {
            this.businsysName = businsysName;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetBusinessargInnerOutput:(");
            buffer.append("businsysId:" + this.businsysId);
            buffer.append(",businsysName:" + this.businsysName);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.businsysId);
            builder.append(this.businsysName);
            builder.append(this.operatorNo);
            builder.append(this.opPassword);
            builder.append(this.branchNo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetBusinessargInnerOutput) {
                InnerPbsService.GetBusinessargInnerOutput test = (InnerPbsService.GetBusinessargInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.businsysId, test.businsysId);
                builder.append(this.businsysName, test.businsysName);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.branchNo, test.branchNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetBusinessargInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer businsysId = 0;

        public GetBusinessargInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getBusinsysId() {
            return this.businsysId != null ? this.businsysId : 0;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setBusinsysId(Integer businsysId) {
            this.businsysId = businsysId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetBusinessargInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",businsysId:" + this.businsysId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.businsysId);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetBusinessargInnerInput) {
                InnerPbsService.GetBusinessargInnerInput test = (InnerPbsService.GetBusinessargInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.businsysId, test.businsysId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetBranchprefixInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer branchNo = 0;
        private String contractPrefix = " ";
        private String exchangeType = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character financeType = ' ';
        private String rptBranchId = " ";

        public GetBranchprefixInnerOutput() {
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getContractPrefix() {
            if (this.contractPrefix == null) {
                return " ";
            } else {
                return this.contractPrefix.isEmpty() ? " " : this.contractPrefix;
            }
        }

        public String getExchangeType() {
            if (this.exchangeType == null) {
                return " ";
            } else {
                return this.exchangeType.isEmpty() ? " " : this.exchangeType;
            }
        }

        public Character getFinanceType() {
            return this.financeType != null ? this.financeType : ' ';
        }

        public String getRptBranchId() {
            if (this.rptBranchId == null) {
                return " ";
            } else {
                return this.rptBranchId.isEmpty() ? " " : this.rptBranchId;
            }
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setContractPrefix(String contractPrefix) {
            this.contractPrefix = contractPrefix;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public void setFinanceType(Character financeType) {
            this.financeType = financeType;
        }

        public void setRptBranchId(String rptBranchId) {
            this.rptBranchId = rptBranchId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetBranchprefixInnerOutput:(");
            buffer.append("branchNo:" + this.branchNo);
            buffer.append(",contractPrefix:" + this.contractPrefix);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(",financeType:" + this.financeType);
            buffer.append(",rptBranchId:" + this.rptBranchId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.branchNo);
            builder.append(this.contractPrefix);
            builder.append(this.exchangeType);
            builder.append(this.financeType);
            builder.append(this.rptBranchId);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetBranchprefixInnerOutput) {
                InnerPbsService.GetBranchprefixInnerOutput test = (InnerPbsService.GetBranchprefixInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.contractPrefix, test.contractPrefix);
                builder.append(this.exchangeType, test.exchangeType);
                builder.append(this.financeType, test.financeType);
                builder.append(this.rptBranchId, test.rptBranchId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetBranchprefixInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @NotNull(
                message = "不能为空"
        )
        private Integer branchNo = 0;
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String exchangeType = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character financeType = ' ';

        public GetBranchprefixInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getExchangeType() {
            if (this.exchangeType == null) {
                return " ";
            } else {
                return this.exchangeType.isEmpty() ? " " : this.exchangeType;
            }
        }

        public Character getFinanceType() {
            return this.financeType != null ? this.financeType : ' ';
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public void setFinanceType(Character financeType) {
            this.financeType = financeType;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetBranchprefixInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(",financeType:" + this.financeType);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.branchNo);
            builder.append(this.exchangeType);
            builder.append(this.financeType);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetBranchprefixInnerInput) {
                InnerPbsService.GetBranchprefixInnerInput test = (InnerPbsService.GetBranchprefixInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.exchangeType, test.exchangeType);
                builder.append(this.financeType, test.financeType);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetBranchTreeInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private List<InnerPbsService.BranchTreeDTO> branchTree = new ArrayList();

        public GetBranchTreeInnerOutput() {
        }

        public List<InnerPbsService.BranchTreeDTO> getBranchTree() {
            return (List)(this.branchTree != null ? this.branchTree : new ArrayList());
        }

        public void setBranchTree(List<InnerPbsService.BranchTreeDTO> branchTree) {
            this.branchTree = branchTree;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetBranchTreeInnerOutput:(");
            buffer.append("branchTree:" + this.branchTree);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.branchTree);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetBranchTreeInnerOutput) {
                InnerPbsService.GetBranchTreeInnerOutput test = (InnerPbsService.GetBranchTreeInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.branchTree, test.branchTree);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetBranchTreeInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer branchNo = 0;

        public GetBranchTreeInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetBranchTreeInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.branchNo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetBranchTreeInnerInput) {
                InnerPbsService.GetBranchTreeInnerInput test = (InnerPbsService.GetBranchTreeInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.branchNo, test.branchNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetBranchByUserIdInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private List<InnerPbsService.AllBranchDTO> operBranches = new ArrayList();
        private List<InnerPbsService.AllBranchDTO> enAllowBranchNo = new ArrayList();

        public GetBranchByUserIdInnerOutput() {
        }

        public List<InnerPbsService.AllBranchDTO> getOperBranches() {
            return (List)(this.operBranches != null ? this.operBranches : new ArrayList());
        }

        public List<InnerPbsService.AllBranchDTO> getEnAllowBranchNo() {
            return (List)(this.enAllowBranchNo != null ? this.enAllowBranchNo : new ArrayList());
        }

        public void setOperBranches(List<InnerPbsService.AllBranchDTO> operBranches) {
            this.operBranches = operBranches;
        }

        public void setEnAllowBranchNo(List<InnerPbsService.AllBranchDTO> enAllowBranchNo) {
            this.enAllowBranchNo = enAllowBranchNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetBranchByUserIdInnerOutput:(");
            buffer.append("operBranches:" + this.operBranches);
            buffer.append(",enAllowBranchNo:" + this.enAllowBranchNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.operBranches);
            builder.append(this.enAllowBranchNo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetBranchByUserIdInnerOutput) {
                InnerPbsService.GetBranchByUserIdInnerOutput test = (InnerPbsService.GetBranchByUserIdInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.operBranches, test.operBranches);
                builder.append(this.enAllowBranchNo, test.enAllowBranchNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetBranchByUserIdInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 1,
                max = 32,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String userId = " ";

        public GetBranchByUserIdInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getUserId() {
            if (this.userId == null) {
                return " ";
            } else {
                return this.userId.isEmpty() ? " " : this.userId;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setUserId(String userId) {
            this.userId = userId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetBranchByUserIdInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",userId:" + this.userId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.userId);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetBranchByUserIdInnerInput) {
                InnerPbsService.GetBranchByUserIdInnerInput test = (InnerPbsService.GetBranchByUserIdInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.userId, test.userId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetArgCurrtimeInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer currDate = 0;
        private Integer currTime = 0;
        private Integer currMilltime = 0;

        public GetArgCurrtimeInnerOutput() {
        }

        public Integer getCurrDate() {
            return this.currDate != null ? this.currDate : 0;
        }

        public Integer getCurrTime() {
            return this.currTime != null ? this.currTime : 0;
        }

        public Integer getCurrMilltime() {
            return this.currMilltime != null ? this.currMilltime : 0;
        }

        public void setCurrDate(Integer currDate) {
            this.currDate = currDate;
        }

        public void setCurrTime(Integer currTime) {
            this.currTime = currTime;
        }

        public void setCurrMilltime(Integer currMilltime) {
            this.currMilltime = currMilltime;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetArgCurrtimeInnerOutput:(");
            buffer.append("currDate:" + this.currDate);
            buffer.append(",currTime:" + this.currTime);
            buffer.append(",currMilltime:" + this.currMilltime);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.currDate);
            builder.append(this.currTime);
            builder.append(this.currMilltime);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetArgCurrtimeInnerOutput) {
                InnerPbsService.GetArgCurrtimeInnerOutput test = (InnerPbsService.GetArgCurrtimeInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.currDate, test.currDate);
                builder.append(this.currTime, test.currTime);
                builder.append(this.currMilltime, test.currMilltime);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetArgCurrtimeInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';

        public GetArgCurrtimeInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetArgCurrtimeInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetArgCurrtimeInnerInput) {
                InnerPbsService.GetArgCurrtimeInnerInput test = (InnerPbsService.GetArgCurrtimeInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetAllcompanyInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private List<InnerPbsService.AllCompanyInUsingDTO> results = new ArrayList();

        public GetAllcompanyInnerOutput() {
        }

        public List<InnerPbsService.AllCompanyInUsingDTO> getResults() {
            return (List)(this.results != null ? this.results : new ArrayList());
        }

        public void setResults(List<InnerPbsService.AllCompanyInUsingDTO> results) {
            this.results = results;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetAllcompanyInnerOutput:(");
            buffer.append("results:" + this.results);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.results);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetAllcompanyInnerOutput) {
                InnerPbsService.GetAllcompanyInnerOutput test = (InnerPbsService.GetAllcompanyInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.results, test.results);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetAllcompanyInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @NotNull(
                message = "不能为空"
        )
        private Integer actionIn = 0;
        @NotNull(
                message = "不能为空"
        )
        private Integer companyNo = 0;

        public GetAllcompanyInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getActionIn() {
            return this.actionIn != null ? this.actionIn : 0;
        }

        public Integer getCompanyNo() {
            return this.companyNo != null ? this.companyNo : 0;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setActionIn(Integer actionIn) {
            this.actionIn = actionIn;
        }

        public void setCompanyNo(Integer companyNo) {
            this.companyNo = companyNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetAllcompanyInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",actionIn:" + this.actionIn);
            buffer.append(",companyNo:" + this.companyNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.actionIn);
            builder.append(this.companyNo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetAllcompanyInnerInput) {
                InnerPbsService.GetAllcompanyInnerInput test = (InnerPbsService.GetAllcompanyInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.actionIn, test.actionIn);
                builder.append(this.companyNo, test.companyNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetAllcompanyAllInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String openorganCode = " ";
        private String szdcSelfmainSeat = " ";
        private String szTransreportSeat = " ";
        private String szdcMainSeat = " ";
        private String szdcCrdtfileSeat = " ";
        private String crtClearNo = " ";
        private String szOptmainSeat = " ";
        private String agencyNo = " ";
        private String shbBlockreportSeat = " ";
        private String stbSelfmainSeat = " ";
        private String companyfullName = " ";
        private String szqrpReportCode = " ";
        private String sipfClearPerson = " ";
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double netCapital = 0.0D;
        private String szbMainSeat = " ";
        private String szdcCrdtabstactSeat = " ";
        private String companyName = " ";
        private Integer companyNo = 0;
        private String reserveAccountSzqrp = " ";
        private String companyFlagStr = " ";
        private String reserveAccountSz = " ";
        private String shbFirmClearNo = " ";
        private String szArpSeat = " ";
        private String shdcCbpfirmId = " ";
        private String openSeat = " ";
        private String companyCode = " ";
        private String stbMainSeat = " ";
        private String szdcCrdtfineSeat = " ";
        private String shaBlockreportSeat = " ";
        private String sipfCompanyNo = " ";
        private String shdcCrdtfirmId = " ";
        private String stbDeputySecuid = " ";
        private String shoptBrokerCode = " ";
        private String szdcFirmId = " ";
        private String shaFirmClearNo = " ";
        private String szdcCrdtmainSeat = " ";
        private String stbdcFirmId = " ";
        private String stbdcCrdtfileSeat = " ";
        private String agencyNoSz = " ";
        private String tsCompanyNo = " ";
        private String shaCrdtblockreportSeat = " ";

        public GetAllcompanyAllInnerOutput() {
        }

        public String getOpenorganCode() {
            if (this.openorganCode == null) {
                return " ";
            } else {
                return this.openorganCode.isEmpty() ? " " : this.openorganCode;
            }
        }

        public String getSzdcSelfmainSeat() {
            if (this.szdcSelfmainSeat == null) {
                return " ";
            } else {
                return this.szdcSelfmainSeat.isEmpty() ? " " : this.szdcSelfmainSeat;
            }
        }

        public String getSzTransreportSeat() {
            if (this.szTransreportSeat == null) {
                return " ";
            } else {
                return this.szTransreportSeat.isEmpty() ? " " : this.szTransreportSeat;
            }
        }

        public String getSzdcMainSeat() {
            if (this.szdcMainSeat == null) {
                return " ";
            } else {
                return this.szdcMainSeat.isEmpty() ? " " : this.szdcMainSeat;
            }
        }

        public String getSzdcCrdtfileSeat() {
            if (this.szdcCrdtfileSeat == null) {
                return " ";
            } else {
                return this.szdcCrdtfileSeat.isEmpty() ? " " : this.szdcCrdtfileSeat;
            }
        }

        public String getCrtClearNo() {
            if (this.crtClearNo == null) {
                return " ";
            } else {
                return this.crtClearNo.isEmpty() ? " " : this.crtClearNo;
            }
        }

        public String getSzOptmainSeat() {
            if (this.szOptmainSeat == null) {
                return " ";
            } else {
                return this.szOptmainSeat.isEmpty() ? " " : this.szOptmainSeat;
            }
        }

        public String getAgencyNo() {
            if (this.agencyNo == null) {
                return " ";
            } else {
                return this.agencyNo.isEmpty() ? " " : this.agencyNo;
            }
        }

        public String getShbBlockreportSeat() {
            if (this.shbBlockreportSeat == null) {
                return " ";
            } else {
                return this.shbBlockreportSeat.isEmpty() ? " " : this.shbBlockreportSeat;
            }
        }

        public String getStbSelfmainSeat() {
            if (this.stbSelfmainSeat == null) {
                return " ";
            } else {
                return this.stbSelfmainSeat.isEmpty() ? " " : this.stbSelfmainSeat;
            }
        }

        public String getCompanyfullName() {
            if (this.companyfullName == null) {
                return " ";
            } else {
                return this.companyfullName.isEmpty() ? " " : this.companyfullName;
            }
        }

        public String getSzqrpReportCode() {
            if (this.szqrpReportCode == null) {
                return " ";
            } else {
                return this.szqrpReportCode.isEmpty() ? " " : this.szqrpReportCode;
            }
        }

        public String getSipfClearPerson() {
            if (this.sipfClearPerson == null) {
                return " ";
            } else {
                return this.sipfClearPerson.isEmpty() ? " " : this.sipfClearPerson;
            }
        }

        public Double getNetCapital() {
            return this.netCapital != null ? this.netCapital : 0.0D;
        }

        public String getSzbMainSeat() {
            if (this.szbMainSeat == null) {
                return " ";
            } else {
                return this.szbMainSeat.isEmpty() ? " " : this.szbMainSeat;
            }
        }

        public String getSzdcCrdtabstactSeat() {
            if (this.szdcCrdtabstactSeat == null) {
                return " ";
            } else {
                return this.szdcCrdtabstactSeat.isEmpty() ? " " : this.szdcCrdtabstactSeat;
            }
        }

        public String getCompanyName() {
            if (this.companyName == null) {
                return " ";
            } else {
                return this.companyName.isEmpty() ? " " : this.companyName;
            }
        }

        public Integer getCompanyNo() {
            return this.companyNo != null ? this.companyNo : 0;
        }

        public String getReserveAccountSzqrp() {
            if (this.reserveAccountSzqrp == null) {
                return " ";
            } else {
                return this.reserveAccountSzqrp.isEmpty() ? " " : this.reserveAccountSzqrp;
            }
        }

        public String getCompanyFlagStr() {
            if (this.companyFlagStr == null) {
                return " ";
            } else {
                return this.companyFlagStr.isEmpty() ? " " : this.companyFlagStr;
            }
        }

        public String getReserveAccountSz() {
            if (this.reserveAccountSz == null) {
                return " ";
            } else {
                return this.reserveAccountSz.isEmpty() ? " " : this.reserveAccountSz;
            }
        }

        public String getShbFirmClearNo() {
            if (this.shbFirmClearNo == null) {
                return " ";
            } else {
                return this.shbFirmClearNo.isEmpty() ? " " : this.shbFirmClearNo;
            }
        }

        public String getSzArpSeat() {
            if (this.szArpSeat == null) {
                return " ";
            } else {
                return this.szArpSeat.isEmpty() ? " " : this.szArpSeat;
            }
        }

        public String getShdcCbpfirmId() {
            if (this.shdcCbpfirmId == null) {
                return " ";
            } else {
                return this.shdcCbpfirmId.isEmpty() ? " " : this.shdcCbpfirmId;
            }
        }

        public String getOpenSeat() {
            if (this.openSeat == null) {
                return " ";
            } else {
                return this.openSeat.isEmpty() ? " " : this.openSeat;
            }
        }

        public String getCompanyCode() {
            if (this.companyCode == null) {
                return " ";
            } else {
                return this.companyCode.isEmpty() ? " " : this.companyCode;
            }
        }

        public String getStbMainSeat() {
            if (this.stbMainSeat == null) {
                return " ";
            } else {
                return this.stbMainSeat.isEmpty() ? " " : this.stbMainSeat;
            }
        }

        public String getSzdcCrdtfineSeat() {
            if (this.szdcCrdtfineSeat == null) {
                return " ";
            } else {
                return this.szdcCrdtfineSeat.isEmpty() ? " " : this.szdcCrdtfineSeat;
            }
        }

        public String getShaBlockreportSeat() {
            if (this.shaBlockreportSeat == null) {
                return " ";
            } else {
                return this.shaBlockreportSeat.isEmpty() ? " " : this.shaBlockreportSeat;
            }
        }

        public String getSipfCompanyNo() {
            if (this.sipfCompanyNo == null) {
                return " ";
            } else {
                return this.sipfCompanyNo.isEmpty() ? " " : this.sipfCompanyNo;
            }
        }

        public String getShdcCrdtfirmId() {
            if (this.shdcCrdtfirmId == null) {
                return " ";
            } else {
                return this.shdcCrdtfirmId.isEmpty() ? " " : this.shdcCrdtfirmId;
            }
        }

        public String getStbDeputySecuid() {
            if (this.stbDeputySecuid == null) {
                return " ";
            } else {
                return this.stbDeputySecuid.isEmpty() ? " " : this.stbDeputySecuid;
            }
        }

        public String getShoptBrokerCode() {
            if (this.shoptBrokerCode == null) {
                return " ";
            } else {
                return this.shoptBrokerCode.isEmpty() ? " " : this.shoptBrokerCode;
            }
        }

        public String getSzdcFirmId() {
            if (this.szdcFirmId == null) {
                return " ";
            } else {
                return this.szdcFirmId.isEmpty() ? " " : this.szdcFirmId;
            }
        }

        public String getShaFirmClearNo() {
            if (this.shaFirmClearNo == null) {
                return " ";
            } else {
                return this.shaFirmClearNo.isEmpty() ? " " : this.shaFirmClearNo;
            }
        }

        public String getSzdcCrdtmainSeat() {
            if (this.szdcCrdtmainSeat == null) {
                return " ";
            } else {
                return this.szdcCrdtmainSeat.isEmpty() ? " " : this.szdcCrdtmainSeat;
            }
        }

        public String getStbdcFirmId() {
            if (this.stbdcFirmId == null) {
                return " ";
            } else {
                return this.stbdcFirmId.isEmpty() ? " " : this.stbdcFirmId;
            }
        }

        public String getStbdcCrdtfileSeat() {
            if (this.stbdcCrdtfileSeat == null) {
                return " ";
            } else {
                return this.stbdcCrdtfileSeat.isEmpty() ? " " : this.stbdcCrdtfileSeat;
            }
        }

        public String getAgencyNoSz() {
            if (this.agencyNoSz == null) {
                return " ";
            } else {
                return this.agencyNoSz.isEmpty() ? " " : this.agencyNoSz;
            }
        }

        public String getTsCompanyNo() {
            if (this.tsCompanyNo == null) {
                return " ";
            } else {
                return this.tsCompanyNo.isEmpty() ? " " : this.tsCompanyNo;
            }
        }

        public String getShaCrdtblockreportSeat() {
            if (this.shaCrdtblockreportSeat == null) {
                return " ";
            } else {
                return this.shaCrdtblockreportSeat.isEmpty() ? " " : this.shaCrdtblockreportSeat;
            }
        }

        public void setOpenorganCode(String openorganCode) {
            this.openorganCode = openorganCode;
        }

        public void setSzdcSelfmainSeat(String szdcSelfmainSeat) {
            this.szdcSelfmainSeat = szdcSelfmainSeat;
        }

        public void setSzTransreportSeat(String szTransreportSeat) {
            this.szTransreportSeat = szTransreportSeat;
        }

        public void setSzdcMainSeat(String szdcMainSeat) {
            this.szdcMainSeat = szdcMainSeat;
        }

        public void setSzdcCrdtfileSeat(String szdcCrdtfileSeat) {
            this.szdcCrdtfileSeat = szdcCrdtfileSeat;
        }

        public void setCrtClearNo(String crtClearNo) {
            this.crtClearNo = crtClearNo;
        }

        public void setSzOptmainSeat(String szOptmainSeat) {
            this.szOptmainSeat = szOptmainSeat;
        }

        public void setAgencyNo(String agencyNo) {
            this.agencyNo = agencyNo;
        }

        public void setShbBlockreportSeat(String shbBlockreportSeat) {
            this.shbBlockreportSeat = shbBlockreportSeat;
        }

        public void setStbSelfmainSeat(String stbSelfmainSeat) {
            this.stbSelfmainSeat = stbSelfmainSeat;
        }

        public void setCompanyfullName(String companyfullName) {
            this.companyfullName = companyfullName;
        }

        public void setSzqrpReportCode(String szqrpReportCode) {
            this.szqrpReportCode = szqrpReportCode;
        }

        public void setSipfClearPerson(String sipfClearPerson) {
            this.sipfClearPerson = sipfClearPerson;
        }

        public void setNetCapital(Double netCapital) {
            this.netCapital = netCapital;
        }

        public void setSzbMainSeat(String szbMainSeat) {
            this.szbMainSeat = szbMainSeat;
        }

        public void setSzdcCrdtabstactSeat(String szdcCrdtabstactSeat) {
            this.szdcCrdtabstactSeat = szdcCrdtabstactSeat;
        }

        public void setCompanyName(String companyName) {
            this.companyName = companyName;
        }

        public void setCompanyNo(Integer companyNo) {
            this.companyNo = companyNo;
        }

        public void setReserveAccountSzqrp(String reserveAccountSzqrp) {
            this.reserveAccountSzqrp = reserveAccountSzqrp;
        }

        public void setCompanyFlagStr(String companyFlagStr) {
            this.companyFlagStr = companyFlagStr;
        }

        public void setReserveAccountSz(String reserveAccountSz) {
            this.reserveAccountSz = reserveAccountSz;
        }

        public void setShbFirmClearNo(String shbFirmClearNo) {
            this.shbFirmClearNo = shbFirmClearNo;
        }

        public void setSzArpSeat(String szArpSeat) {
            this.szArpSeat = szArpSeat;
        }

        public void setShdcCbpfirmId(String shdcCbpfirmId) {
            this.shdcCbpfirmId = shdcCbpfirmId;
        }

        public void setOpenSeat(String openSeat) {
            this.openSeat = openSeat;
        }

        public void setCompanyCode(String companyCode) {
            this.companyCode = companyCode;
        }

        public void setStbMainSeat(String stbMainSeat) {
            this.stbMainSeat = stbMainSeat;
        }

        public void setSzdcCrdtfineSeat(String szdcCrdtfineSeat) {
            this.szdcCrdtfineSeat = szdcCrdtfineSeat;
        }

        public void setShaBlockreportSeat(String shaBlockreportSeat) {
            this.shaBlockreportSeat = shaBlockreportSeat;
        }

        public void setSipfCompanyNo(String sipfCompanyNo) {
            this.sipfCompanyNo = sipfCompanyNo;
        }

        public void setShdcCrdtfirmId(String shdcCrdtfirmId) {
            this.shdcCrdtfirmId = shdcCrdtfirmId;
        }

        public void setStbDeputySecuid(String stbDeputySecuid) {
            this.stbDeputySecuid = stbDeputySecuid;
        }

        public void setShoptBrokerCode(String shoptBrokerCode) {
            this.shoptBrokerCode = shoptBrokerCode;
        }

        public void setSzdcFirmId(String szdcFirmId) {
            this.szdcFirmId = szdcFirmId;
        }

        public void setShaFirmClearNo(String shaFirmClearNo) {
            this.shaFirmClearNo = shaFirmClearNo;
        }

        public void setSzdcCrdtmainSeat(String szdcCrdtmainSeat) {
            this.szdcCrdtmainSeat = szdcCrdtmainSeat;
        }

        public void setStbdcFirmId(String stbdcFirmId) {
            this.stbdcFirmId = stbdcFirmId;
        }

        public void setStbdcCrdtfileSeat(String stbdcCrdtfileSeat) {
            this.stbdcCrdtfileSeat = stbdcCrdtfileSeat;
        }

        public void setAgencyNoSz(String agencyNoSz) {
            this.agencyNoSz = agencyNoSz;
        }

        public void setTsCompanyNo(String tsCompanyNo) {
            this.tsCompanyNo = tsCompanyNo;
        }

        public void setShaCrdtblockreportSeat(String shaCrdtblockreportSeat) {
            this.shaCrdtblockreportSeat = shaCrdtblockreportSeat;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetAllcompanyAllInnerOutput:(");
            buffer.append("openorganCode:" + this.openorganCode);
            buffer.append(",szdcSelfmainSeat:" + this.szdcSelfmainSeat);
            buffer.append(",szTransreportSeat:" + this.szTransreportSeat);
            buffer.append(",szdcMainSeat:" + this.szdcMainSeat);
            buffer.append(",szdcCrdtfileSeat:" + this.szdcCrdtfileSeat);
            buffer.append(",crtClearNo:" + this.crtClearNo);
            buffer.append(",szOptmainSeat:" + this.szOptmainSeat);
            buffer.append(",agencyNo:" + this.agencyNo);
            buffer.append(",shbBlockreportSeat:" + this.shbBlockreportSeat);
            buffer.append(",stbSelfmainSeat:" + this.stbSelfmainSeat);
            buffer.append(",companyfullName:" + this.companyfullName);
            buffer.append(",szqrpReportCode:" + this.szqrpReportCode);
            buffer.append(",sipfClearPerson:" + this.sipfClearPerson);
            buffer.append(",netCapital:" + this.netCapital);
            buffer.append(",szbMainSeat:" + this.szbMainSeat);
            buffer.append(",szdcCrdtabstactSeat:" + this.szdcCrdtabstactSeat);
            buffer.append(",companyName:" + this.companyName);
            buffer.append(",companyNo:" + this.companyNo);
            buffer.append(",reserveAccountSzqrp:" + this.reserveAccountSzqrp);
            buffer.append(",companyFlagStr:" + this.companyFlagStr);
            buffer.append(",reserveAccountSz:" + this.reserveAccountSz);
            buffer.append(",shbFirmClearNo:" + this.shbFirmClearNo);
            buffer.append(",szArpSeat:" + this.szArpSeat);
            buffer.append(",shdcCbpfirmId:" + this.shdcCbpfirmId);
            buffer.append(",openSeat:" + this.openSeat);
            buffer.append(",companyCode:" + this.companyCode);
            buffer.append(",stbMainSeat:" + this.stbMainSeat);
            buffer.append(",szdcCrdtfineSeat:" + this.szdcCrdtfineSeat);
            buffer.append(",shaBlockreportSeat:" + this.shaBlockreportSeat);
            buffer.append(",sipfCompanyNo:" + this.sipfCompanyNo);
            buffer.append(",shdcCrdtfirmId:" + this.shdcCrdtfirmId);
            buffer.append(",stbDeputySecuid:" + this.stbDeputySecuid);
            buffer.append(",shoptBrokerCode:" + this.shoptBrokerCode);
            buffer.append(",szdcFirmId:" + this.szdcFirmId);
            buffer.append(",shaFirmClearNo:" + this.shaFirmClearNo);
            buffer.append(",szdcCrdtmainSeat:" + this.szdcCrdtmainSeat);
            buffer.append(",stbdcFirmId:" + this.stbdcFirmId);
            buffer.append(",stbdcCrdtfileSeat:" + this.stbdcCrdtfileSeat);
            buffer.append(",agencyNoSz:" + this.agencyNoSz);
            buffer.append(",tsCompanyNo:" + this.tsCompanyNo);
            buffer.append(",shaCrdtblockreportSeat:" + this.shaCrdtblockreportSeat);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.openorganCode);
            builder.append(this.szdcSelfmainSeat);
            builder.append(this.szTransreportSeat);
            builder.append(this.szdcMainSeat);
            builder.append(this.szdcCrdtfileSeat);
            builder.append(this.crtClearNo);
            builder.append(this.szOptmainSeat);
            builder.append(this.agencyNo);
            builder.append(this.shbBlockreportSeat);
            builder.append(this.stbSelfmainSeat);
            builder.append(this.companyfullName);
            builder.append(this.szqrpReportCode);
            builder.append(this.sipfClearPerson);
            builder.append(this.netCapital);
            builder.append(this.szbMainSeat);
            builder.append(this.szdcCrdtabstactSeat);
            builder.append(this.companyName);
            builder.append(this.companyNo);
            builder.append(this.reserveAccountSzqrp);
            builder.append(this.companyFlagStr);
            builder.append(this.reserveAccountSz);
            builder.append(this.shbFirmClearNo);
            builder.append(this.szArpSeat);
            builder.append(this.shdcCbpfirmId);
            builder.append(this.openSeat);
            builder.append(this.companyCode);
            builder.append(this.stbMainSeat);
            builder.append(this.szdcCrdtfineSeat);
            builder.append(this.shaBlockreportSeat);
            builder.append(this.sipfCompanyNo);
            builder.append(this.shdcCrdtfirmId);
            builder.append(this.stbDeputySecuid);
            builder.append(this.shoptBrokerCode);
            builder.append(this.szdcFirmId);
            builder.append(this.shaFirmClearNo);
            builder.append(this.szdcCrdtmainSeat);
            builder.append(this.stbdcFirmId);
            builder.append(this.stbdcCrdtfileSeat);
            builder.append(this.agencyNoSz);
            builder.append(this.tsCompanyNo);
            builder.append(this.shaCrdtblockreportSeat);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetAllcompanyAllInnerOutput) {
                InnerPbsService.GetAllcompanyAllInnerOutput test = (InnerPbsService.GetAllcompanyAllInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.openorganCode, test.openorganCode);
                builder.append(this.szdcSelfmainSeat, test.szdcSelfmainSeat);
                builder.append(this.szTransreportSeat, test.szTransreportSeat);
                builder.append(this.szdcMainSeat, test.szdcMainSeat);
                builder.append(this.szdcCrdtfileSeat, test.szdcCrdtfileSeat);
                builder.append(this.crtClearNo, test.crtClearNo);
                builder.append(this.szOptmainSeat, test.szOptmainSeat);
                builder.append(this.agencyNo, test.agencyNo);
                builder.append(this.shbBlockreportSeat, test.shbBlockreportSeat);
                builder.append(this.stbSelfmainSeat, test.stbSelfmainSeat);
                builder.append(this.companyfullName, test.companyfullName);
                builder.append(this.szqrpReportCode, test.szqrpReportCode);
                builder.append(this.sipfClearPerson, test.sipfClearPerson);
                builder.append(this.netCapital, test.netCapital);
                builder.append(this.szbMainSeat, test.szbMainSeat);
                builder.append(this.szdcCrdtabstactSeat, test.szdcCrdtabstactSeat);
                builder.append(this.companyName, test.companyName);
                builder.append(this.companyNo, test.companyNo);
                builder.append(this.reserveAccountSzqrp, test.reserveAccountSzqrp);
                builder.append(this.companyFlagStr, test.companyFlagStr);
                builder.append(this.reserveAccountSz, test.reserveAccountSz);
                builder.append(this.shbFirmClearNo, test.shbFirmClearNo);
                builder.append(this.szArpSeat, test.szArpSeat);
                builder.append(this.shdcCbpfirmId, test.shdcCbpfirmId);
                builder.append(this.openSeat, test.openSeat);
                builder.append(this.companyCode, test.companyCode);
                builder.append(this.stbMainSeat, test.stbMainSeat);
                builder.append(this.szdcCrdtfineSeat, test.szdcCrdtfineSeat);
                builder.append(this.shaBlockreportSeat, test.shaBlockreportSeat);
                builder.append(this.sipfCompanyNo, test.sipfCompanyNo);
                builder.append(this.shdcCrdtfirmId, test.shdcCrdtfirmId);
                builder.append(this.stbDeputySecuid, test.stbDeputySecuid);
                builder.append(this.shoptBrokerCode, test.shoptBrokerCode);
                builder.append(this.szdcFirmId, test.szdcFirmId);
                builder.append(this.shaFirmClearNo, test.shaFirmClearNo);
                builder.append(this.szdcCrdtmainSeat, test.szdcCrdtmainSeat);
                builder.append(this.stbdcFirmId, test.stbdcFirmId);
                builder.append(this.stbdcCrdtfileSeat, test.stbdcCrdtfileSeat);
                builder.append(this.agencyNoSz, test.agencyNoSz);
                builder.append(this.tsCompanyNo, test.tsCompanyNo);
                builder.append(this.shaCrdtblockreportSeat, test.shaCrdtblockreportSeat);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetAllcompanyAllInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer companyNo = 0;

        public GetAllcompanyAllInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getCompanyNo() {
            return this.companyNo != null ? this.companyNo : 0;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setCompanyNo(Integer companyNo) {
            this.companyNo = companyNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetAllcompanyAllInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",companyNo:" + this.companyNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.companyNo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetAllcompanyAllInnerInput) {
                InnerPbsService.GetAllcompanyAllInnerInput test = (InnerPbsService.GetAllcompanyAllInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.companyNo, test.companyNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetAllbranchPageInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer total = 0;
        private Integer currentPage = 0;
        private List<InnerPbsService.AllBranchDTO> rows = new ArrayList();

        public GetAllbranchPageInnerOutput() {
        }

        public Integer getTotal() {
            return this.total != null ? this.total : 0;
        }

        public Integer getCurrentPage() {
            return this.currentPage != null ? this.currentPage : 0;
        }

        public List<InnerPbsService.AllBranchDTO> getRows() {
            return (List)(this.rows != null ? this.rows : new ArrayList());
        }

        public void setTotal(Integer total) {
            this.total = total;
        }

        public void setCurrentPage(Integer currentPage) {
            this.currentPage = currentPage;
        }

        public void setRows(List<InnerPbsService.AllBranchDTO> rows) {
            this.rows = rows;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetAllbranchPageInnerOutput:(");
            buffer.append("total:" + this.total);
            buffer.append(",currentPage:" + this.currentPage);
            buffer.append(",rows:" + this.rows);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.total);
            builder.append(this.currentPage);
            builder.append(this.rows);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetAllbranchPageInnerOutput) {
                InnerPbsService.GetAllbranchPageInnerOutput test = (InnerPbsService.GetAllbranchPageInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.total, test.total);
                builder.append(this.currentPage, test.currentPage);
                builder.append(this.rows, test.rows);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetAllbranchPageInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer companyNo = 0;
        private Integer branchNo = 0;
        private Integer pageNo = 0;
        private Integer pageSize = 0;

        public GetAllbranchPageInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getCompanyNo() {
            return this.companyNo != null ? this.companyNo : 0;
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Integer getPageNo() {
            return this.pageNo != null ? this.pageNo : 0;
        }

        public Integer getPageSize() {
            return this.pageSize != null ? this.pageSize : 0;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setCompanyNo(Integer companyNo) {
            this.companyNo = companyNo;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setPageNo(Integer pageNo) {
            this.pageNo = pageNo;
        }

        public void setPageSize(Integer pageSize) {
            this.pageSize = pageSize;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetAllbranchPageInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",companyNo:" + this.companyNo);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",pageNo:" + this.pageNo);
            buffer.append(",pageSize:" + this.pageSize);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.companyNo);
            builder.append(this.branchNo);
            builder.append(this.pageNo);
            builder.append(this.pageSize);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetAllbranchPageInnerInput) {
                InnerPbsService.GetAllbranchPageInnerInput test = (InnerPbsService.GetAllbranchPageInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.companyNo, test.companyNo);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.pageNo, test.pageNo);
                builder.append(this.pageSize, test.pageSize);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetAllbranchInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String address = " ";
        private Integer branchNo = 0;
        private String branchName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character branchType = ' ';
        private Integer branchZone = 0;
        private String contact = " ";
        private Integer dealBranchNo = 0;
        private Integer level1 = 0;
        private Integer level10 = 0;
        private Integer level2 = 0;
        private Integer level3 = 0;
        private Integer level4 = 0;
        private Integer level5 = 0;
        private Integer level6 = 0;
        private Integer level7 = 0;
        private Integer level8 = 0;
        private Integer level9 = 0;
        private String localNo = " ";
        private Integer manageBranchNo = 0;
        private Integer sysnodeId = 0;
        private String telephone = " ";
        private Integer treeLevel = 0;
        private Integer upBranchNo = 0;
        private String opennetCode = " ";
        private String branchCtrlstr = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character branchKind = ' ';
        private Integer companyNo = 0;
        private Integer branchGroup = 0;

        public GetAllbranchInnerOutput() {
        }

        public String getAddress() {
            if (this.address == null) {
                return " ";
            } else {
                return this.address.isEmpty() ? " " : this.address;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getBranchName() {
            if (this.branchName == null) {
                return " ";
            } else {
                return this.branchName.isEmpty() ? " " : this.branchName;
            }
        }

        public Character getBranchType() {
            return this.branchType != null ? this.branchType : ' ';
        }

        public Integer getBranchZone() {
            return this.branchZone != null ? this.branchZone : 0;
        }

        public String getContact() {
            if (this.contact == null) {
                return " ";
            } else {
                return this.contact.isEmpty() ? " " : this.contact;
            }
        }

        public Integer getDealBranchNo() {
            return this.dealBranchNo != null ? this.dealBranchNo : 0;
        }

        public Integer getLevel1() {
            return this.level1 != null ? this.level1 : 0;
        }

        public Integer getLevel10() {
            return this.level10 != null ? this.level10 : 0;
        }

        public Integer getLevel2() {
            return this.level2 != null ? this.level2 : 0;
        }

        public Integer getLevel3() {
            return this.level3 != null ? this.level3 : 0;
        }

        public Integer getLevel4() {
            return this.level4 != null ? this.level4 : 0;
        }

        public Integer getLevel5() {
            return this.level5 != null ? this.level5 : 0;
        }

        public Integer getLevel6() {
            return this.level6 != null ? this.level6 : 0;
        }

        public Integer getLevel7() {
            return this.level7 != null ? this.level7 : 0;
        }

        public Integer getLevel8() {
            return this.level8 != null ? this.level8 : 0;
        }

        public Integer getLevel9() {
            return this.level9 != null ? this.level9 : 0;
        }

        public String getLocalNo() {
            if (this.localNo == null) {
                return " ";
            } else {
                return this.localNo.isEmpty() ? " " : this.localNo;
            }
        }

        public Integer getManageBranchNo() {
            return this.manageBranchNo != null ? this.manageBranchNo : 0;
        }

        public Integer getSysnodeId() {
            return this.sysnodeId != null ? this.sysnodeId : 0;
        }

        public String getTelephone() {
            if (this.telephone == null) {
                return " ";
            } else {
                return this.telephone.isEmpty() ? " " : this.telephone;
            }
        }

        public Integer getTreeLevel() {
            return this.treeLevel != null ? this.treeLevel : 0;
        }

        public Integer getUpBranchNo() {
            return this.upBranchNo != null ? this.upBranchNo : 0;
        }

        public String getOpennetCode() {
            if (this.opennetCode == null) {
                return " ";
            } else {
                return this.opennetCode.isEmpty() ? " " : this.opennetCode;
            }
        }

        public String getBranchCtrlstr() {
            if (this.branchCtrlstr == null) {
                return " ";
            } else {
                return this.branchCtrlstr.isEmpty() ? " " : this.branchCtrlstr;
            }
        }

        public Character getBranchKind() {
            return this.branchKind != null ? this.branchKind : ' ';
        }

        public Integer getCompanyNo() {
            return this.companyNo != null ? this.companyNo : 0;
        }

        public Integer getBranchGroup() {
            return this.branchGroup != null ? this.branchGroup : 0;
        }

        public void setAddress(String address) {
            this.address = address;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setBranchName(String branchName) {
            this.branchName = branchName;
        }

        public void setBranchType(Character branchType) {
            this.branchType = branchType;
        }

        public void setBranchZone(Integer branchZone) {
            this.branchZone = branchZone;
        }

        public void setContact(String contact) {
            this.contact = contact;
        }

        public void setDealBranchNo(Integer dealBranchNo) {
            this.dealBranchNo = dealBranchNo;
        }

        public void setLevel1(Integer level1) {
            this.level1 = level1;
        }

        public void setLevel10(Integer level10) {
            this.level10 = level10;
        }

        public void setLevel2(Integer level2) {
            this.level2 = level2;
        }

        public void setLevel3(Integer level3) {
            this.level3 = level3;
        }

        public void setLevel4(Integer level4) {
            this.level4 = level4;
        }

        public void setLevel5(Integer level5) {
            this.level5 = level5;
        }

        public void setLevel6(Integer level6) {
            this.level6 = level6;
        }

        public void setLevel7(Integer level7) {
            this.level7 = level7;
        }

        public void setLevel8(Integer level8) {
            this.level8 = level8;
        }

        public void setLevel9(Integer level9) {
            this.level9 = level9;
        }

        public void setLocalNo(String localNo) {
            this.localNo = localNo;
        }

        public void setManageBranchNo(Integer manageBranchNo) {
            this.manageBranchNo = manageBranchNo;
        }

        public void setSysnodeId(Integer sysnodeId) {
            this.sysnodeId = sysnodeId;
        }

        public void setTelephone(String telephone) {
            this.telephone = telephone;
        }

        public void setTreeLevel(Integer treeLevel) {
            this.treeLevel = treeLevel;
        }

        public void setUpBranchNo(Integer upBranchNo) {
            this.upBranchNo = upBranchNo;
        }

        public void setOpennetCode(String opennetCode) {
            this.opennetCode = opennetCode;
        }

        public void setBranchCtrlstr(String branchCtrlstr) {
            this.branchCtrlstr = branchCtrlstr;
        }

        public void setBranchKind(Character branchKind) {
            this.branchKind = branchKind;
        }

        public void setCompanyNo(Integer companyNo) {
            this.companyNo = companyNo;
        }

        public void setBranchGroup(Integer branchGroup) {
            this.branchGroup = branchGroup;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetAllbranchInnerOutput:(");
            buffer.append("address:" + this.address);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",branchName:" + this.branchName);
            buffer.append(",branchType:" + this.branchType);
            buffer.append(",branchZone:" + this.branchZone);
            buffer.append(",contact:" + this.contact);
            buffer.append(",dealBranchNo:" + this.dealBranchNo);
            buffer.append(",level1:" + this.level1);
            buffer.append(",level10:" + this.level10);
            buffer.append(",level2:" + this.level2);
            buffer.append(",level3:" + this.level3);
            buffer.append(",level4:" + this.level4);
            buffer.append(",level5:" + this.level5);
            buffer.append(",level6:" + this.level6);
            buffer.append(",level7:" + this.level7);
            buffer.append(",level8:" + this.level8);
            buffer.append(",level9:" + this.level9);
            buffer.append(",localNo:" + this.localNo);
            buffer.append(",manageBranchNo:" + this.manageBranchNo);
            buffer.append(",sysnodeId:" + this.sysnodeId);
            buffer.append(",telephone:" + this.telephone);
            buffer.append(",treeLevel:" + this.treeLevel);
            buffer.append(",upBranchNo:" + this.upBranchNo);
            buffer.append(",opennetCode:" + this.opennetCode);
            buffer.append(",branchCtrlstr:" + this.branchCtrlstr);
            buffer.append(",branchKind:" + this.branchKind);
            buffer.append(",companyNo:" + this.companyNo);
            buffer.append(",branchGroup:" + this.branchGroup);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.address);
            builder.append(this.branchNo);
            builder.append(this.branchName);
            builder.append(this.branchType);
            builder.append(this.branchZone);
            builder.append(this.contact);
            builder.append(this.dealBranchNo);
            builder.append(this.level1);
            builder.append(this.level10);
            builder.append(this.level2);
            builder.append(this.level3);
            builder.append(this.level4);
            builder.append(this.level5);
            builder.append(this.level6);
            builder.append(this.level7);
            builder.append(this.level8);
            builder.append(this.level9);
            builder.append(this.localNo);
            builder.append(this.manageBranchNo);
            builder.append(this.sysnodeId);
            builder.append(this.telephone);
            builder.append(this.treeLevel);
            builder.append(this.upBranchNo);
            builder.append(this.opennetCode);
            builder.append(this.branchCtrlstr);
            builder.append(this.branchKind);
            builder.append(this.companyNo);
            builder.append(this.branchGroup);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetAllbranchInnerOutput) {
                InnerPbsService.GetAllbranchInnerOutput test = (InnerPbsService.GetAllbranchInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.address, test.address);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.branchName, test.branchName);
                builder.append(this.branchType, test.branchType);
                builder.append(this.branchZone, test.branchZone);
                builder.append(this.contact, test.contact);
                builder.append(this.dealBranchNo, test.dealBranchNo);
                builder.append(this.level1, test.level1);
                builder.append(this.level10, test.level10);
                builder.append(this.level2, test.level2);
                builder.append(this.level3, test.level3);
                builder.append(this.level4, test.level4);
                builder.append(this.level5, test.level5);
                builder.append(this.level6, test.level6);
                builder.append(this.level7, test.level7);
                builder.append(this.level8, test.level8);
                builder.append(this.level9, test.level9);
                builder.append(this.localNo, test.localNo);
                builder.append(this.manageBranchNo, test.manageBranchNo);
                builder.append(this.sysnodeId, test.sysnodeId);
                builder.append(this.telephone, test.telephone);
                builder.append(this.treeLevel, test.treeLevel);
                builder.append(this.upBranchNo, test.upBranchNo);
                builder.append(this.opennetCode, test.opennetCode);
                builder.append(this.branchCtrlstr, test.branchCtrlstr);
                builder.append(this.branchKind, test.branchKind);
                builder.append(this.companyNo, test.companyNo);
                builder.append(this.branchGroup, test.branchGroup);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetAllbranchInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';

        public GetAllbranchInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetAllbranchInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetAllbranchInnerInput) {
                InnerPbsService.GetAllbranchInnerInput test = (InnerPbsService.GetAllbranchInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetAllbranchByUserIdInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character addFlag = ' ';
        private String address = " ";
        private String branchCtrlstr = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character branchKind = ' ';
        private String branchName = " ";
        private Integer branchNo = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character branchType = ' ';
        private Integer branchZone = 0;
        private String cityCode = " ";
        private String cmccId = " ";
        private Integer companyNo = 0;
        private String contact = " ";
        private String csrcCode = " ";
        private Integer dealBranchNo = 0;
        private String dimension = " ";
        private String eMail = " ";
        private String exchId = " ";
        private Integer level1 = 0;
        private Integer level10 = 0;
        private Integer level2 = 0;
        private Integer level3 = 0;
        private Integer level4 = 0;
        private Integer level5 = 0;
        private Integer level6 = 0;
        private Integer level7 = 0;
        private Integer level8 = 0;
        private Integer level9 = 0;
        private String localNo = " ";
        private Integer manageBranchNo = 0;
        private String orgCode = " ";
        private Integer organSysnodeId = 0;
        private String provinceCode = " ";
        private Integer sysnodeId = 0;
        private String telphone = " ";
        private Integer treeLevel = 0;
        private Integer upBranchNo = 0;
        private String zipcode = " ";
        private String opennetCode = " ";
        private Integer branchGroup = 0;

        public GetAllbranchByUserIdInnerOutput() {
        }

        public Character getAddFlag() {
            return this.addFlag != null ? this.addFlag : ' ';
        }

        public String getAddress() {
            if (this.address == null) {
                return " ";
            } else {
                return this.address.isEmpty() ? " " : this.address;
            }
        }

        public String getBranchCtrlstr() {
            if (this.branchCtrlstr == null) {
                return " ";
            } else {
                return this.branchCtrlstr.isEmpty() ? " " : this.branchCtrlstr;
            }
        }

        public Character getBranchKind() {
            return this.branchKind != null ? this.branchKind : ' ';
        }

        public String getBranchName() {
            if (this.branchName == null) {
                return " ";
            } else {
                return this.branchName.isEmpty() ? " " : this.branchName;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Character getBranchType() {
            return this.branchType != null ? this.branchType : ' ';
        }

        public Integer getBranchZone() {
            return this.branchZone != null ? this.branchZone : 0;
        }

        public String getCityCode() {
            if (this.cityCode == null) {
                return " ";
            } else {
                return this.cityCode.isEmpty() ? " " : this.cityCode;
            }
        }

        public String getCmccId() {
            if (this.cmccId == null) {
                return " ";
            } else {
                return this.cmccId.isEmpty() ? " " : this.cmccId;
            }
        }

        public Integer getCompanyNo() {
            return this.companyNo != null ? this.companyNo : 0;
        }

        public String getContact() {
            if (this.contact == null) {
                return " ";
            } else {
                return this.contact.isEmpty() ? " " : this.contact;
            }
        }

        public String getCsrcCode() {
            if (this.csrcCode == null) {
                return " ";
            } else {
                return this.csrcCode.isEmpty() ? " " : this.csrcCode;
            }
        }

        public Integer getDealBranchNo() {
            return this.dealBranchNo != null ? this.dealBranchNo : 0;
        }

        public String getDimension() {
            if (this.dimension == null) {
                return " ";
            } else {
                return this.dimension.isEmpty() ? " " : this.dimension;
            }
        }

        public String geteMail() {
            if (this.eMail == null) {
                return " ";
            } else {
                return this.eMail.isEmpty() ? " " : this.eMail;
            }
        }

        public String getExchId() {
            if (this.exchId == null) {
                return " ";
            } else {
                return this.exchId.isEmpty() ? " " : this.exchId;
            }
        }

        public Integer getLevel1() {
            return this.level1 != null ? this.level1 : 0;
        }

        public Integer getLevel10() {
            return this.level10 != null ? this.level10 : 0;
        }

        public Integer getLevel2() {
            return this.level2 != null ? this.level2 : 0;
        }

        public Integer getLevel3() {
            return this.level3 != null ? this.level3 : 0;
        }

        public Integer getLevel4() {
            return this.level4 != null ? this.level4 : 0;
        }

        public Integer getLevel5() {
            return this.level5 != null ? this.level5 : 0;
        }

        public Integer getLevel6() {
            return this.level6 != null ? this.level6 : 0;
        }

        public Integer getLevel7() {
            return this.level7 != null ? this.level7 : 0;
        }

        public Integer getLevel8() {
            return this.level8 != null ? this.level8 : 0;
        }

        public Integer getLevel9() {
            return this.level9 != null ? this.level9 : 0;
        }

        public String getLocalNo() {
            if (this.localNo == null) {
                return " ";
            } else {
                return this.localNo.isEmpty() ? " " : this.localNo;
            }
        }

        public Integer getManageBranchNo() {
            return this.manageBranchNo != null ? this.manageBranchNo : 0;
        }

        public String getOrgCode() {
            if (this.orgCode == null) {
                return " ";
            } else {
                return this.orgCode.isEmpty() ? " " : this.orgCode;
            }
        }

        public Integer getOrganSysnodeId() {
            return this.organSysnodeId != null ? this.organSysnodeId : 0;
        }

        public String getProvinceCode() {
            if (this.provinceCode == null) {
                return " ";
            } else {
                return this.provinceCode.isEmpty() ? " " : this.provinceCode;
            }
        }

        public Integer getSysnodeId() {
            return this.sysnodeId != null ? this.sysnodeId : 0;
        }

        public String getTelphone() {
            if (this.telphone == null) {
                return " ";
            } else {
                return this.telphone.isEmpty() ? " " : this.telphone;
            }
        }

        public Integer getTreeLevel() {
            return this.treeLevel != null ? this.treeLevel : 0;
        }

        public Integer getUpBranchNo() {
            return this.upBranchNo != null ? this.upBranchNo : 0;
        }

        public String getZipcode() {
            if (this.zipcode == null) {
                return " ";
            } else {
                return this.zipcode.isEmpty() ? " " : this.zipcode;
            }
        }

        public String getOpennetCode() {
            if (this.opennetCode == null) {
                return " ";
            } else {
                return this.opennetCode.isEmpty() ? " " : this.opennetCode;
            }
        }

        public Integer getBranchGroup() {
            return this.branchGroup != null ? this.branchGroup : 0;
        }

        public void setAddFlag(Character addFlag) {
            this.addFlag = addFlag;
        }

        public void setAddress(String address) {
            this.address = address;
        }

        public void setBranchCtrlstr(String branchCtrlstr) {
            this.branchCtrlstr = branchCtrlstr;
        }

        public void setBranchKind(Character branchKind) {
            this.branchKind = branchKind;
        }

        public void setBranchName(String branchName) {
            this.branchName = branchName;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setBranchType(Character branchType) {
            this.branchType = branchType;
        }

        public void setBranchZone(Integer branchZone) {
            this.branchZone = branchZone;
        }

        public void setCityCode(String cityCode) {
            this.cityCode = cityCode;
        }

        public void setCmccId(String cmccId) {
            this.cmccId = cmccId;
        }

        public void setCompanyNo(Integer companyNo) {
            this.companyNo = companyNo;
        }

        public void setContact(String contact) {
            this.contact = contact;
        }

        public void setCsrcCode(String csrcCode) {
            this.csrcCode = csrcCode;
        }

        public void setDealBranchNo(Integer dealBranchNo) {
            this.dealBranchNo = dealBranchNo;
        }

        public void setDimension(String dimension) {
            this.dimension = dimension;
        }

        public void seteMail(String eMail) {
            this.eMail = eMail;
        }

        public void setExchId(String exchId) {
            this.exchId = exchId;
        }

        public void setLevel1(Integer level1) {
            this.level1 = level1;
        }

        public void setLevel10(Integer level10) {
            this.level10 = level10;
        }

        public void setLevel2(Integer level2) {
            this.level2 = level2;
        }

        public void setLevel3(Integer level3) {
            this.level3 = level3;
        }

        public void setLevel4(Integer level4) {
            this.level4 = level4;
        }

        public void setLevel5(Integer level5) {
            this.level5 = level5;
        }

        public void setLevel6(Integer level6) {
            this.level6 = level6;
        }

        public void setLevel7(Integer level7) {
            this.level7 = level7;
        }

        public void setLevel8(Integer level8) {
            this.level8 = level8;
        }

        public void setLevel9(Integer level9) {
            this.level9 = level9;
        }

        public void setLocalNo(String localNo) {
            this.localNo = localNo;
        }

        public void setManageBranchNo(Integer manageBranchNo) {
            this.manageBranchNo = manageBranchNo;
        }

        public void setOrgCode(String orgCode) {
            this.orgCode = orgCode;
        }

        public void setOrganSysnodeId(Integer organSysnodeId) {
            this.organSysnodeId = organSysnodeId;
        }

        public void setProvinceCode(String provinceCode) {
            this.provinceCode = provinceCode;
        }

        public void setSysnodeId(Integer sysnodeId) {
            this.sysnodeId = sysnodeId;
        }

        public void setTelphone(String telphone) {
            this.telphone = telphone;
        }

        public void setTreeLevel(Integer treeLevel) {
            this.treeLevel = treeLevel;
        }

        public void setUpBranchNo(Integer upBranchNo) {
            this.upBranchNo = upBranchNo;
        }

        public void setZipcode(String zipcode) {
            this.zipcode = zipcode;
        }

        public void setOpennetCode(String opennetCode) {
            this.opennetCode = opennetCode;
        }

        public void setBranchGroup(Integer branchGroup) {
            this.branchGroup = branchGroup;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetAllbranchByUserIdInnerOutput:(");
            buffer.append("addFlag:" + this.addFlag);
            buffer.append(",address:" + this.address);
            buffer.append(",branchCtrlstr:" + this.branchCtrlstr);
            buffer.append(",branchKind:" + this.branchKind);
            buffer.append(",branchName:" + this.branchName);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",branchType:" + this.branchType);
            buffer.append(",branchZone:" + this.branchZone);
            buffer.append(",cityCode:" + this.cityCode);
            buffer.append(",cmccId:" + this.cmccId);
            buffer.append(",companyNo:" + this.companyNo);
            buffer.append(",contact:" + this.contact);
            buffer.append(",csrcCode:" + this.csrcCode);
            buffer.append(",dealBranchNo:" + this.dealBranchNo);
            buffer.append(",dimension:" + this.dimension);
            buffer.append(",eMail:" + this.eMail);
            buffer.append(",exchId:" + this.exchId);
            buffer.append(",level1:" + this.level1);
            buffer.append(",level10:" + this.level10);
            buffer.append(",level2:" + this.level2);
            buffer.append(",level3:" + this.level3);
            buffer.append(",level4:" + this.level4);
            buffer.append(",level5:" + this.level5);
            buffer.append(",level6:" + this.level6);
            buffer.append(",level7:" + this.level7);
            buffer.append(",level8:" + this.level8);
            buffer.append(",level9:" + this.level9);
            buffer.append(",localNo:" + this.localNo);
            buffer.append(",manageBranchNo:" + this.manageBranchNo);
            buffer.append(",orgCode:" + this.orgCode);
            buffer.append(",organSysnodeId:" + this.organSysnodeId);
            buffer.append(",provinceCode:" + this.provinceCode);
            buffer.append(",sysnodeId:" + this.sysnodeId);
            buffer.append(",telphone:" + this.telphone);
            buffer.append(",treeLevel:" + this.treeLevel);
            buffer.append(",upBranchNo:" + this.upBranchNo);
            buffer.append(",zipcode:" + this.zipcode);
            buffer.append(",opennetCode:" + this.opennetCode);
            buffer.append(",branchGroup:" + this.branchGroup);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.addFlag);
            builder.append(this.address);
            builder.append(this.branchCtrlstr);
            builder.append(this.branchKind);
            builder.append(this.branchName);
            builder.append(this.branchNo);
            builder.append(this.branchType);
            builder.append(this.branchZone);
            builder.append(this.cityCode);
            builder.append(this.cmccId);
            builder.append(this.companyNo);
            builder.append(this.contact);
            builder.append(this.csrcCode);
            builder.append(this.dealBranchNo);
            builder.append(this.dimension);
            builder.append(this.eMail);
            builder.append(this.exchId);
            builder.append(this.level1);
            builder.append(this.level10);
            builder.append(this.level2);
            builder.append(this.level3);
            builder.append(this.level4);
            builder.append(this.level5);
            builder.append(this.level6);
            builder.append(this.level7);
            builder.append(this.level8);
            builder.append(this.level9);
            builder.append(this.localNo);
            builder.append(this.manageBranchNo);
            builder.append(this.orgCode);
            builder.append(this.organSysnodeId);
            builder.append(this.provinceCode);
            builder.append(this.sysnodeId);
            builder.append(this.telphone);
            builder.append(this.treeLevel);
            builder.append(this.upBranchNo);
            builder.append(this.zipcode);
            builder.append(this.opennetCode);
            builder.append(this.branchGroup);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetAllbranchByUserIdInnerOutput) {
                InnerPbsService.GetAllbranchByUserIdInnerOutput test = (InnerPbsService.GetAllbranchByUserIdInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.addFlag, test.addFlag);
                builder.append(this.address, test.address);
                builder.append(this.branchCtrlstr, test.branchCtrlstr);
                builder.append(this.branchKind, test.branchKind);
                builder.append(this.branchName, test.branchName);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.branchType, test.branchType);
                builder.append(this.branchZone, test.branchZone);
                builder.append(this.cityCode, test.cityCode);
                builder.append(this.cmccId, test.cmccId);
                builder.append(this.companyNo, test.companyNo);
                builder.append(this.contact, test.contact);
                builder.append(this.csrcCode, test.csrcCode);
                builder.append(this.dealBranchNo, test.dealBranchNo);
                builder.append(this.dimension, test.dimension);
                builder.append(this.eMail, test.eMail);
                builder.append(this.exchId, test.exchId);
                builder.append(this.level1, test.level1);
                builder.append(this.level10, test.level10);
                builder.append(this.level2, test.level2);
                builder.append(this.level3, test.level3);
                builder.append(this.level4, test.level4);
                builder.append(this.level5, test.level5);
                builder.append(this.level6, test.level6);
                builder.append(this.level7, test.level7);
                builder.append(this.level8, test.level8);
                builder.append(this.level9, test.level9);
                builder.append(this.localNo, test.localNo);
                builder.append(this.manageBranchNo, test.manageBranchNo);
                builder.append(this.orgCode, test.orgCode);
                builder.append(this.organSysnodeId, test.organSysnodeId);
                builder.append(this.provinceCode, test.provinceCode);
                builder.append(this.sysnodeId, test.sysnodeId);
                builder.append(this.telphone, test.telphone);
                builder.append(this.treeLevel, test.treeLevel);
                builder.append(this.upBranchNo, test.upBranchNo);
                builder.append(this.zipcode, test.zipcode);
                builder.append(this.opennetCode, test.opennetCode);
                builder.append(this.branchGroup, test.branchGroup);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetAllbranchByUserIdInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 1,
                max = 32,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String userId = " ";

        public GetAllbranchByUserIdInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getUserId() {
            if (this.userId == null) {
                return " ";
            } else {
                return this.userId.isEmpty() ? " " : this.userId;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setUserId(String userId) {
            this.userId = userId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetAllbranchByUserIdInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",userId:" + this.userId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.userId);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetAllbranchByUserIdInnerInput) {
                InnerPbsService.GetAllbranchByUserIdInnerInput test = (InnerPbsService.GetAllbranchByUserIdInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.userId, test.userId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetAllbranchByCompanyNoInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character branchKind = ' ';
        private String branchName = " ";
        private Integer branchNo = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character branchType = ' ';
        private String cityCode = " ";
        private Integer companyNo = 0;
        private Integer dealBranchNo = 0;
        private String dimension = " ";
        private Integer manageBranchNo = 0;
        private String orgCode = " ";
        private String provinceCode = " ";
        private Integer sysnodeId = 0;
        private Integer upBranchNo = 0;
        private String opennetCode = " ";
        private Integer branchGroup = 0;

        public GetAllbranchByCompanyNoInnerOutput() {
        }

        public Character getBranchKind() {
            return this.branchKind != null ? this.branchKind : ' ';
        }

        public String getBranchName() {
            if (this.branchName == null) {
                return " ";
            } else {
                return this.branchName.isEmpty() ? " " : this.branchName;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Character getBranchType() {
            return this.branchType != null ? this.branchType : ' ';
        }

        public String getCityCode() {
            if (this.cityCode == null) {
                return " ";
            } else {
                return this.cityCode.isEmpty() ? " " : this.cityCode;
            }
        }

        public Integer getCompanyNo() {
            return this.companyNo != null ? this.companyNo : 0;
        }

        public Integer getDealBranchNo() {
            return this.dealBranchNo != null ? this.dealBranchNo : 0;
        }

        public String getDimension() {
            if (this.dimension == null) {
                return " ";
            } else {
                return this.dimension.isEmpty() ? " " : this.dimension;
            }
        }

        public Integer getManageBranchNo() {
            return this.manageBranchNo != null ? this.manageBranchNo : 0;
        }

        public String getOrgCode() {
            if (this.orgCode == null) {
                return " ";
            } else {
                return this.orgCode.isEmpty() ? " " : this.orgCode;
            }
        }

        public String getProvinceCode() {
            if (this.provinceCode == null) {
                return " ";
            } else {
                return this.provinceCode.isEmpty() ? " " : this.provinceCode;
            }
        }

        public Integer getSysnodeId() {
            return this.sysnodeId != null ? this.sysnodeId : 0;
        }

        public Integer getUpBranchNo() {
            return this.upBranchNo != null ? this.upBranchNo : 0;
        }

        public String getOpennetCode() {
            if (this.opennetCode == null) {
                return " ";
            } else {
                return this.opennetCode.isEmpty() ? " " : this.opennetCode;
            }
        }

        public Integer getBranchGroup() {
            return this.branchGroup != null ? this.branchGroup : 0;
        }

        public void setBranchKind(Character branchKind) {
            this.branchKind = branchKind;
        }

        public void setBranchName(String branchName) {
            this.branchName = branchName;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setBranchType(Character branchType) {
            this.branchType = branchType;
        }

        public void setCityCode(String cityCode) {
            this.cityCode = cityCode;
        }

        public void setCompanyNo(Integer companyNo) {
            this.companyNo = companyNo;
        }

        public void setDealBranchNo(Integer dealBranchNo) {
            this.dealBranchNo = dealBranchNo;
        }

        public void setDimension(String dimension) {
            this.dimension = dimension;
        }

        public void setManageBranchNo(Integer manageBranchNo) {
            this.manageBranchNo = manageBranchNo;
        }

        public void setOrgCode(String orgCode) {
            this.orgCode = orgCode;
        }

        public void setProvinceCode(String provinceCode) {
            this.provinceCode = provinceCode;
        }

        public void setSysnodeId(Integer sysnodeId) {
            this.sysnodeId = sysnodeId;
        }

        public void setUpBranchNo(Integer upBranchNo) {
            this.upBranchNo = upBranchNo;
        }

        public void setOpennetCode(String opennetCode) {
            this.opennetCode = opennetCode;
        }

        public void setBranchGroup(Integer branchGroup) {
            this.branchGroup = branchGroup;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetAllbranchByCompanyNoInnerOutput:(");
            buffer.append("branchKind:" + this.branchKind);
            buffer.append(",branchName:" + this.branchName);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",branchType:" + this.branchType);
            buffer.append(",cityCode:" + this.cityCode);
            buffer.append(",companyNo:" + this.companyNo);
            buffer.append(",dealBranchNo:" + this.dealBranchNo);
            buffer.append(",dimension:" + this.dimension);
            buffer.append(",manageBranchNo:" + this.manageBranchNo);
            buffer.append(",orgCode:" + this.orgCode);
            buffer.append(",provinceCode:" + this.provinceCode);
            buffer.append(",sysnodeId:" + this.sysnodeId);
            buffer.append(",upBranchNo:" + this.upBranchNo);
            buffer.append(",opennetCode:" + this.opennetCode);
            buffer.append(",branchGroup:" + this.branchGroup);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.branchKind);
            builder.append(this.branchName);
            builder.append(this.branchNo);
            builder.append(this.branchType);
            builder.append(this.cityCode);
            builder.append(this.companyNo);
            builder.append(this.dealBranchNo);
            builder.append(this.dimension);
            builder.append(this.manageBranchNo);
            builder.append(this.orgCode);
            builder.append(this.provinceCode);
            builder.append(this.sysnodeId);
            builder.append(this.upBranchNo);
            builder.append(this.opennetCode);
            builder.append(this.branchGroup);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetAllbranchByCompanyNoInnerOutput) {
                InnerPbsService.GetAllbranchByCompanyNoInnerOutput test = (InnerPbsService.GetAllbranchByCompanyNoInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.branchKind, test.branchKind);
                builder.append(this.branchName, test.branchName);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.branchType, test.branchType);
                builder.append(this.cityCode, test.cityCode);
                builder.append(this.companyNo, test.companyNo);
                builder.append(this.dealBranchNo, test.dealBranchNo);
                builder.append(this.dimension, test.dimension);
                builder.append(this.manageBranchNo, test.manageBranchNo);
                builder.append(this.orgCode, test.orgCode);
                builder.append(this.provinceCode, test.provinceCode);
                builder.append(this.sysnodeId, test.sysnodeId);
                builder.append(this.upBranchNo, test.upBranchNo);
                builder.append(this.opennetCode, test.opennetCode);
                builder.append(this.branchGroup, test.branchGroup);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetAllbranchByCompanyNoInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @NotNull(
                message = "不能为空"
        )
        private Integer companyNo = 0;

        public GetAllbranchByCompanyNoInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getCompanyNo() {
            return this.companyNo != null ? this.companyNo : 0;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setCompanyNo(Integer companyNo) {
            this.companyNo = companyNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetAllbranchByCompanyNoInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",companyNo:" + this.companyNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.companyNo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetAllbranchByCompanyNoInnerInput) {
                InnerPbsService.GetAllbranchByCompanyNoInnerInput test = (InnerPbsService.GetAllbranchByCompanyNoInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.companyNo, test.companyNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetAllbranchByBranchNoInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String address = " ";
        private String branchName = " ";
        private Integer branchNo = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character branchType = ' ';
        private Integer branchZone = 0;
        private String contact = " ";
        private Integer dealBranchNo = 0;
        private Integer level1 = 0;
        private Integer level10 = 0;
        private Integer level2 = 0;
        private Integer level3 = 0;
        private Integer level4 = 0;
        private Integer level5 = 0;
        private Integer level6 = 0;
        private Integer level7 = 0;
        private Integer level8 = 0;
        private Integer level9 = 0;
        private String localNo = " ";
        private Integer manageBranchNo = 0;
        private Integer sysnodeId = 0;
        private String telephone = " ";
        private Integer treeLevel = 0;
        private Integer upBranchNo = 0;
        private String opennetCode = " ";
        private Integer companyNo = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character branchKind = ' ';
        private Integer branchGroup = 0;
        private String sysOnlineFlag = " ";

        public GetAllbranchByBranchNoInnerOutput() {
        }

        public String getAddress() {
            if (this.address == null) {
                return " ";
            } else {
                return this.address.isEmpty() ? " " : this.address;
            }
        }

        public String getBranchName() {
            if (this.branchName == null) {
                return " ";
            } else {
                return this.branchName.isEmpty() ? " " : this.branchName;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Character getBranchType() {
            return this.branchType != null ? this.branchType : ' ';
        }

        public Integer getBranchZone() {
            return this.branchZone != null ? this.branchZone : 0;
        }

        public String getContact() {
            if (this.contact == null) {
                return " ";
            } else {
                return this.contact.isEmpty() ? " " : this.contact;
            }
        }

        public Integer getDealBranchNo() {
            return this.dealBranchNo != null ? this.dealBranchNo : 0;
        }

        public Integer getLevel1() {
            return this.level1 != null ? this.level1 : 0;
        }

        public Integer getLevel10() {
            return this.level10 != null ? this.level10 : 0;
        }

        public Integer getLevel2() {
            return this.level2 != null ? this.level2 : 0;
        }

        public Integer getLevel3() {
            return this.level3 != null ? this.level3 : 0;
        }

        public Integer getLevel4() {
            return this.level4 != null ? this.level4 : 0;
        }

        public Integer getLevel5() {
            return this.level5 != null ? this.level5 : 0;
        }

        public Integer getLevel6() {
            return this.level6 != null ? this.level6 : 0;
        }

        public Integer getLevel7() {
            return this.level7 != null ? this.level7 : 0;
        }

        public Integer getLevel8() {
            return this.level8 != null ? this.level8 : 0;
        }

        public Integer getLevel9() {
            return this.level9 != null ? this.level9 : 0;
        }

        public String getLocalNo() {
            if (this.localNo == null) {
                return " ";
            } else {
                return this.localNo.isEmpty() ? " " : this.localNo;
            }
        }

        public Integer getManageBranchNo() {
            return this.manageBranchNo != null ? this.manageBranchNo : 0;
        }

        public Integer getSysnodeId() {
            return this.sysnodeId != null ? this.sysnodeId : 0;
        }

        public String getTelephone() {
            if (this.telephone == null) {
                return " ";
            } else {
                return this.telephone.isEmpty() ? " " : this.telephone;
            }
        }

        public Integer getTreeLevel() {
            return this.treeLevel != null ? this.treeLevel : 0;
        }

        public Integer getUpBranchNo() {
            return this.upBranchNo != null ? this.upBranchNo : 0;
        }

        public String getOpennetCode() {
            if (this.opennetCode == null) {
                return " ";
            } else {
                return this.opennetCode.isEmpty() ? " " : this.opennetCode;
            }
        }

        public Integer getCompanyNo() {
            return this.companyNo != null ? this.companyNo : 0;
        }

        public Character getBranchKind() {
            return this.branchKind != null ? this.branchKind : ' ';
        }

        public Integer getBranchGroup() {
            return this.branchGroup != null ? this.branchGroup : 0;
        }

        public String getSysOnlineFlag() {
            if (this.sysOnlineFlag == null) {
                return " ";
            } else {
                return this.sysOnlineFlag.isEmpty() ? " " : this.sysOnlineFlag;
            }
        }

        public void setAddress(String address) {
            this.address = address;
        }

        public void setBranchName(String branchName) {
            this.branchName = branchName;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setBranchType(Character branchType) {
            this.branchType = branchType;
        }

        public void setBranchZone(Integer branchZone) {
            this.branchZone = branchZone;
        }

        public void setContact(String contact) {
            this.contact = contact;
        }

        public void setDealBranchNo(Integer dealBranchNo) {
            this.dealBranchNo = dealBranchNo;
        }

        public void setLevel1(Integer level1) {
            this.level1 = level1;
        }

        public void setLevel10(Integer level10) {
            this.level10 = level10;
        }

        public void setLevel2(Integer level2) {
            this.level2 = level2;
        }

        public void setLevel3(Integer level3) {
            this.level3 = level3;
        }

        public void setLevel4(Integer level4) {
            this.level4 = level4;
        }

        public void setLevel5(Integer level5) {
            this.level5 = level5;
        }

        public void setLevel6(Integer level6) {
            this.level6 = level6;
        }

        public void setLevel7(Integer level7) {
            this.level7 = level7;
        }

        public void setLevel8(Integer level8) {
            this.level8 = level8;
        }

        public void setLevel9(Integer level9) {
            this.level9 = level9;
        }

        public void setLocalNo(String localNo) {
            this.localNo = localNo;
        }

        public void setManageBranchNo(Integer manageBranchNo) {
            this.manageBranchNo = manageBranchNo;
        }

        public void setSysnodeId(Integer sysnodeId) {
            this.sysnodeId = sysnodeId;
        }

        public void setTelephone(String telephone) {
            this.telephone = telephone;
        }

        public void setTreeLevel(Integer treeLevel) {
            this.treeLevel = treeLevel;
        }

        public void setUpBranchNo(Integer upBranchNo) {
            this.upBranchNo = upBranchNo;
        }

        public void setOpennetCode(String opennetCode) {
            this.opennetCode = opennetCode;
        }

        public void setCompanyNo(Integer companyNo) {
            this.companyNo = companyNo;
        }

        public void setBranchKind(Character branchKind) {
            this.branchKind = branchKind;
        }

        public void setBranchGroup(Integer branchGroup) {
            this.branchGroup = branchGroup;
        }

        public void setSysOnlineFlag(String sysOnlineFlag) {
            this.sysOnlineFlag = sysOnlineFlag;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetAllbranchByBranchNoInnerOutput:(");
            buffer.append("address:" + this.address);
            buffer.append(",branchName:" + this.branchName);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",branchType:" + this.branchType);
            buffer.append(",branchZone:" + this.branchZone);
            buffer.append(",contact:" + this.contact);
            buffer.append(",dealBranchNo:" + this.dealBranchNo);
            buffer.append(",level1:" + this.level1);
            buffer.append(",level10:" + this.level10);
            buffer.append(",level2:" + this.level2);
            buffer.append(",level3:" + this.level3);
            buffer.append(",level4:" + this.level4);
            buffer.append(",level5:" + this.level5);
            buffer.append(",level6:" + this.level6);
            buffer.append(",level7:" + this.level7);
            buffer.append(",level8:" + this.level8);
            buffer.append(",level9:" + this.level9);
            buffer.append(",localNo:" + this.localNo);
            buffer.append(",manageBranchNo:" + this.manageBranchNo);
            buffer.append(",sysnodeId:" + this.sysnodeId);
            buffer.append(",telephone:" + this.telephone);
            buffer.append(",treeLevel:" + this.treeLevel);
            buffer.append(",upBranchNo:" + this.upBranchNo);
            buffer.append(",opennetCode:" + this.opennetCode);
            buffer.append(",companyNo:" + this.companyNo);
            buffer.append(",branchKind:" + this.branchKind);
            buffer.append(",branchGroup:" + this.branchGroup);
            buffer.append(",sysOnlineFlag:" + this.sysOnlineFlag);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.address);
            builder.append(this.branchName);
            builder.append(this.branchNo);
            builder.append(this.branchType);
            builder.append(this.branchZone);
            builder.append(this.contact);
            builder.append(this.dealBranchNo);
            builder.append(this.level1);
            builder.append(this.level10);
            builder.append(this.level2);
            builder.append(this.level3);
            builder.append(this.level4);
            builder.append(this.level5);
            builder.append(this.level6);
            builder.append(this.level7);
            builder.append(this.level8);
            builder.append(this.level9);
            builder.append(this.localNo);
            builder.append(this.manageBranchNo);
            builder.append(this.sysnodeId);
            builder.append(this.telephone);
            builder.append(this.treeLevel);
            builder.append(this.upBranchNo);
            builder.append(this.opennetCode);
            builder.append(this.companyNo);
            builder.append(this.branchKind);
            builder.append(this.branchGroup);
            builder.append(this.sysOnlineFlag);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetAllbranchByBranchNoInnerOutput) {
                InnerPbsService.GetAllbranchByBranchNoInnerOutput test = (InnerPbsService.GetAllbranchByBranchNoInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.address, test.address);
                builder.append(this.branchName, test.branchName);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.branchType, test.branchType);
                builder.append(this.branchZone, test.branchZone);
                builder.append(this.contact, test.contact);
                builder.append(this.dealBranchNo, test.dealBranchNo);
                builder.append(this.level1, test.level1);
                builder.append(this.level10, test.level10);
                builder.append(this.level2, test.level2);
                builder.append(this.level3, test.level3);
                builder.append(this.level4, test.level4);
                builder.append(this.level5, test.level5);
                builder.append(this.level6, test.level6);
                builder.append(this.level7, test.level7);
                builder.append(this.level8, test.level8);
                builder.append(this.level9, test.level9);
                builder.append(this.localNo, test.localNo);
                builder.append(this.manageBranchNo, test.manageBranchNo);
                builder.append(this.sysnodeId, test.sysnodeId);
                builder.append(this.telephone, test.telephone);
                builder.append(this.treeLevel, test.treeLevel);
                builder.append(this.upBranchNo, test.upBranchNo);
                builder.append(this.opennetCode, test.opennetCode);
                builder.append(this.companyNo, test.companyNo);
                builder.append(this.branchKind, test.branchKind);
                builder.append(this.branchGroup, test.branchGroup);
                builder.append(this.sysOnlineFlag, test.sysOnlineFlag);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetAllbranchByBranchNoInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @NotNull(
                message = "不能为空"
        )
        private Integer branchNo = 0;

        public GetAllbranchByBranchNoInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetAllbranchByBranchNoInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.branchNo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.GetAllbranchByBranchNoInnerInput) {
                InnerPbsService.GetAllbranchByBranchNoInnerInput test = (InnerPbsService.GetAllbranchByBranchNoInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.branchNo, test.branchNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class DeleteDayinitinfoDataInitInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer initDate = 0;

        public DeleteDayinitinfoDataInitInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("DeleteDayinitinfoDataInitInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",initDate:" + this.initDate);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.initDate);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerPbsService.DeleteDayinitinfoDataInitInnerInput) {
                InnerPbsService.DeleteDayinitinfoDataInitInnerInput test = (InnerPbsService.DeleteDayinitinfoDataInitInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.initDate, test.initDate);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }
}
