//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.hundsun.broker.bcp.pub.service;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.hundsun.broker.base.PublicChecker.PublicParams;
import com.hundsun.broker.base.databind.CharacterJsonDeserializer;
import com.hundsun.jrescloud.rpc.annotation.CloudFunction;
import com.hundsun.jrescloud.rpc.annotation.CloudService;
import com.hundsun.jrescloud.rpc.def.validation.SinogramLength;
import java.io.Serializable;
import java.util.List;
import javax.validation.constraints.NotNull;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

@CloudService(
        validation = true,
        validationNull = false,
        application = "hsbroker.bcp"
)
public interface InnerBcpService {
    @CloudFunction(
            value = "bcp.getDataswapAcodeQueryInner",
            desc = "一码通账户查询",
            apiUrl = "/getDataswapAcodeQueryInner"
    )
    List<InnerBcpService.GetDataswapAcodeQueryInnerOutput> getDataswapAcodeQueryInner(InnerBcpService.GetDataswapAcodeQueryInnerInput var1);

    @CloudFunction(
            value = "bcp.getDataswapHolderQueryInner",
            desc = "证券账户查询",
            apiUrl = "/getDataswapHolderQueryInner"
    )
    List<InnerBcpService.GetDataswapHolderQueryInnerOutput> getDataswapHolderQueryInner(InnerBcpService.GetDataswapHolderQueryInnerInput var1);

    @CloudFunction(
            value = "bcp.putDataswapAcodeCheckInner",
            desc = "中登一码通检查",
            apiUrl = "/putDataswapAcodeCheckInner"
    )
    InnerBcpService.PutDataswapAcodeCheckInnerOutput putDataswapAcodeCheckInner(InnerBcpService.PutDataswapAcodeCheckInnerInput var1);

    @CloudFunction(
            value = "bcp.putDataswapGeneralCheckInner",
            desc = "中登账户信息校验",
            apiUrl = "/putDataswapGeneralCheckInner"
    )
    InnerBcpService.PutDataswapGeneralCheckInnerOutput putDataswapGeneralCheckInner(InnerBcpService.PutDataswapGeneralCheckInnerInput var1);

    @CloudFunction(
            value = "bcp.putDataswapHolderCheckInner",
            desc = "证券账户检查",
            apiUrl = "/putDataswapHolderCheckInner"
    )
    InnerBcpService.PutDataswapHolderCheckInnerOutput putDataswapHolderCheckInner(InnerBcpService.PutDataswapHolderCheckInnerInput var1);


    public static class GetDataswapHolderCheckInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String opRemark = " ";

        public GetDataswapHolderCheckInnerOutput() {
        }

        public String getOpRemark() {
            if (this.opRemark == null) {
                return " ";
            } else {
                return this.opRemark.isEmpty() ? " " : this.opRemark;
            }
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetDataswapHolderCheckInnerOutput:(");
            buffer.append("opRemark:" + this.opRemark);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opRemark);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBcpService.GetDataswapHolderCheckInnerOutput) {
                InnerBcpService.GetDataswapHolderCheckInnerOutput test = (InnerBcpService.GetDataswapHolderCheckInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opRemark, test.opRemark);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetDataswapHolderCheckInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String functionStr = " ";
        private Integer branchNo = 0;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId;
        @SinogramLength(
                min = 1,
                max = 16000,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String paramData;

        public GetDataswapHolderCheckInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getFunctionStr() {
            if (this.functionStr == null) {
                return " ";
            } else {
                return this.functionStr.isEmpty() ? " " : this.functionStr;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getClientId() {
            return this.clientId;
        }

        public String getParamData() {
            return this.paramData;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setFunctionStr(String functionStr) {
            this.functionStr = functionStr;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setParamData(String paramData) {
            this.paramData = paramData;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetDataswapHolderCheckInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",functionStr:" + this.functionStr);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",paramData:" + this.paramData);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.functionStr);
            builder.append(this.branchNo);
            builder.append(this.clientId);
            builder.append(this.paramData);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBcpService.GetDataswapHolderCheckInnerInput) {
                InnerBcpService.GetDataswapHolderCheckInnerInput test = (InnerBcpService.GetDataswapHolderCheckInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.functionStr, test.functionStr);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.clientId, test.clientId);
                builder.append(this.paramData, test.paramData);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutDataswapRelationshipCheckInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String opRemark = " ";

        public PutDataswapRelationshipCheckInnerOutput() {
        }

        public String getOpRemark() {
            if (this.opRemark == null) {
                return " ";
            } else {
                return this.opRemark.isEmpty() ? " " : this.opRemark;
            }
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutDataswapRelationshipCheckInnerOutput:(");
            buffer.append("opRemark:" + this.opRemark);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opRemark);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBcpService.PutDataswapRelationshipCheckInnerOutput) {
                InnerBcpService.PutDataswapRelationshipCheckInnerOutput test = (InnerBcpService.PutDataswapRelationshipCheckInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opRemark, test.opRemark);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutDataswapRelationshipCheckInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId;
        @SinogramLength(
                min = 1,
                max = 2,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String csdcBusiKind;
        @SinogramLength(
                min = 1,
                max = 20,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String acodeAccount;
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String enCsdcHolderKind;
        @SinogramLength(
                min = 0,
                max = 8000,
                charset = "utf-8"
        )
        private String stockAccountStr;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character dealFlag = '1';

        public PutDataswapRelationshipCheckInnerInput() {
        }

        public String getClientId() {
            return this.clientId;
        }

        public String getCsdcBusiKind() {
            return this.csdcBusiKind;
        }

        public String getAcodeAccount() {
            return this.acodeAccount;
        }

        public String getEnCsdcHolderKind() {
            return this.enCsdcHolderKind;
        }

        public String getStockAccountStr() {
            return this.stockAccountStr;
        }

        public Character getDealFlag() {
            return this.dealFlag != null ? this.dealFlag : '\u0001';
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setCsdcBusiKind(String csdcBusiKind) {
            this.csdcBusiKind = csdcBusiKind;
        }

        public void setAcodeAccount(String acodeAccount) {
            this.acodeAccount = acodeAccount;
        }

        public void setEnCsdcHolderKind(String enCsdcHolderKind) {
            this.enCsdcHolderKind = enCsdcHolderKind;
        }

        public void setStockAccountStr(String stockAccountStr) {
            this.stockAccountStr = stockAccountStr;
        }

        public void setDealFlag(Character dealFlag) {
            this.dealFlag = dealFlag;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutDataswapRelationshipCheckInnerInput:(");
            buffer.append("clientId:" + this.clientId);
            buffer.append(",csdcBusiKind:" + this.csdcBusiKind);
            buffer.append(",acodeAccount:" + this.acodeAccount);
            buffer.append(",enCsdcHolderKind:" + this.enCsdcHolderKind);
            buffer.append(",stockAccountStr:" + this.stockAccountStr);
            buffer.append(",dealFlag:" + this.dealFlag);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.clientId);
            builder.append(this.csdcBusiKind);
            builder.append(this.acodeAccount);
            builder.append(this.enCsdcHolderKind);
            builder.append(this.stockAccountStr);
            builder.append(this.dealFlag);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBcpService.PutDataswapRelationshipCheckInnerInput) {
                InnerBcpService.PutDataswapRelationshipCheckInnerInput test = (InnerBcpService.PutDataswapRelationshipCheckInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.clientId, test.clientId);
                builder.append(this.csdcBusiKind, test.csdcBusiKind);
                builder.append(this.acodeAccount, test.acodeAccount);
                builder.append(this.enCsdcHolderKind, test.enCsdcHolderKind);
                builder.append(this.stockAccountStr, test.stockAccountStr);
                builder.append(this.dealFlag, test.dealFlag);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutDataswapAcctActiveInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String opRemark = " ";

        public PutDataswapAcctActiveInnerOutput() {
        }

        public String getOpRemark() {
            if (this.opRemark == null) {
                return " ";
            } else {
                return this.opRemark.isEmpty() ? " " : this.opRemark;
            }
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutDataswapAcctActiveInnerOutput:(");
            buffer.append("opRemark:" + this.opRemark);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opRemark);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBcpService.PutDataswapAcctActiveInnerOutput) {
                InnerBcpService.PutDataswapAcctActiveInnerOutput test = (InnerBcpService.PutDataswapAcctActiveInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opRemark, test.opRemark);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutDataswapAcctActiveInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId;
        @SinogramLength(
                min = 1,
                max = 20,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String acodeAccount;
        @SinogramLength(
                min = 0,
                max = 2,
                charset = "utf-8"
        )
        private String csdcIdKind = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String csdcIdNo = " ";
        @SinogramLength(
                min = 0,
                max = 180,
                charset = "utf-8"
        )
        private String csdcClientName = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fundAccount = " ";
        @SinogramLength(
                min = 1,
                max = 16000,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String paramData;
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String acptId = " ";

        public PutDataswapAcctActiveInnerInput() {
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getClientId() {
            return this.clientId;
        }

        public String getAcodeAccount() {
            return this.acodeAccount;
        }

        public String getCsdcIdKind() {
            if (this.csdcIdKind == null) {
                return " ";
            } else {
                return this.csdcIdKind.isEmpty() ? " " : this.csdcIdKind;
            }
        }

        public String getCsdcIdNo() {
            if (this.csdcIdNo == null) {
                return " ";
            } else {
                return this.csdcIdNo.isEmpty() ? " " : this.csdcIdNo;
            }
        }

        public String getCsdcClientName() {
            if (this.csdcClientName == null) {
                return " ";
            } else {
                return this.csdcClientName.isEmpty() ? " " : this.csdcClientName;
            }
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getParamData() {
            return this.paramData;
        }

        public String getAcptId() {
            if (this.acptId == null) {
                return " ";
            } else {
                return this.acptId.isEmpty() ? " " : this.acptId;
            }
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setAcodeAccount(String acodeAccount) {
            this.acodeAccount = acodeAccount;
        }

        public void setCsdcIdKind(String csdcIdKind) {
            this.csdcIdKind = csdcIdKind;
        }

        public void setCsdcIdNo(String csdcIdNo) {
            this.csdcIdNo = csdcIdNo;
        }

        public void setCsdcClientName(String csdcClientName) {
            this.csdcClientName = csdcClientName;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setParamData(String paramData) {
            this.paramData = paramData;
        }

        public void setAcptId(String acptId) {
            this.acptId = acptId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutDataswapAcctActiveInnerInput:(");
            buffer.append("opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",acodeAccount:" + this.acodeAccount);
            buffer.append(",csdcIdKind:" + this.csdcIdKind);
            buffer.append(",csdcIdNo:" + this.csdcIdNo);
            buffer.append(",csdcClientName:" + this.csdcClientName);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",paramData:" + this.paramData);
            buffer.append(",acptId:" + this.acptId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.clientId);
            builder.append(this.acodeAccount);
            builder.append(this.csdcIdKind);
            builder.append(this.csdcIdNo);
            builder.append(this.csdcClientName);
            builder.append(this.fundAccount);
            builder.append(this.paramData);
            builder.append(this.acptId);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBcpService.PutDataswapAcctActiveInnerInput) {
                InnerBcpService.PutDataswapAcctActiveInnerInput test = (InnerBcpService.PutDataswapAcctActiveInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.clientId, test.clientId);
                builder.append(this.acodeAccount, test.acodeAccount);
                builder.append(this.csdcIdKind, test.csdcIdKind);
                builder.append(this.csdcIdNo, test.csdcIdNo);
                builder.append(this.csdcClientName, test.csdcClientName);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.paramData, test.paramData);
                builder.append(this.acptId, test.acptId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostDataswapAcodeOpenInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String csdcAcodeAccount = " ";
        private String opRemark = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character newFlag = ' ';
        private String csdcClientName = " ";
        private String csdcIdKind = " ";
        private String csdcIdNo = " ";

        public PostDataswapAcodeOpenInnerOutput() {
        }

        public String getCsdcAcodeAccount() {
            if (this.csdcAcodeAccount == null) {
                return " ";
            } else {
                return this.csdcAcodeAccount.isEmpty() ? " " : this.csdcAcodeAccount;
            }
        }

        public String getOpRemark() {
            if (this.opRemark == null) {
                return " ";
            } else {
                return this.opRemark.isEmpty() ? " " : this.opRemark;
            }
        }

        public Character getNewFlag() {
            return this.newFlag != null ? this.newFlag : ' ';
        }

        public String getCsdcClientName() {
            if (this.csdcClientName == null) {
                return " ";
            } else {
                return this.csdcClientName.isEmpty() ? " " : this.csdcClientName;
            }
        }

        public String getCsdcIdKind() {
            if (this.csdcIdKind == null) {
                return " ";
            } else {
                return this.csdcIdKind.isEmpty() ? " " : this.csdcIdKind;
            }
        }

        public String getCsdcIdNo() {
            if (this.csdcIdNo == null) {
                return " ";
            } else {
                return this.csdcIdNo.isEmpty() ? " " : this.csdcIdNo;
            }
        }

        public void setCsdcAcodeAccount(String csdcAcodeAccount) {
            this.csdcAcodeAccount = csdcAcodeAccount;
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public void setNewFlag(Character newFlag) {
            this.newFlag = newFlag;
        }

        public void setCsdcClientName(String csdcClientName) {
            this.csdcClientName = csdcClientName;
        }

        public void setCsdcIdKind(String csdcIdKind) {
            this.csdcIdKind = csdcIdKind;
        }

        public void setCsdcIdNo(String csdcIdNo) {
            this.csdcIdNo = csdcIdNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostDataswapAcodeOpenInnerOutput:(");
            buffer.append("csdcAcodeAccount:" + this.csdcAcodeAccount);
            buffer.append(",opRemark:" + this.opRemark);
            buffer.append(",newFlag:" + this.newFlag);
            buffer.append(",csdcClientName:" + this.csdcClientName);
            buffer.append(",csdcIdKind:" + this.csdcIdKind);
            buffer.append(",csdcIdNo:" + this.csdcIdNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.csdcAcodeAccount);
            builder.append(this.opRemark);
            builder.append(this.newFlag);
            builder.append(this.csdcClientName);
            builder.append(this.csdcIdKind);
            builder.append(this.csdcIdNo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBcpService.PostDataswapAcodeOpenInnerOutput) {
                InnerBcpService.PostDataswapAcodeOpenInnerOutput test = (InnerBcpService.PostDataswapAcodeOpenInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.csdcAcodeAccount, test.csdcAcodeAccount);
                builder.append(this.opRemark, test.opRemark);
                builder.append(this.newFlag, test.newFlag);
                builder.append(this.csdcClientName, test.csdcClientName);
                builder.append(this.csdcIdKind, test.csdcIdKind);
                builder.append(this.csdcIdNo, test.csdcIdNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostDataswapAcodeOpenInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId;
        private Integer branchNo = 0;
        @SinogramLength(
                min = 1,
                max = 180,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String csdcClientName;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character csdcAccountKind;
        @SinogramLength(
                min = 1,
                max = 3,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String csdcNationality;
        @SinogramLength(
                min = 1,
                max = 2,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String csdcIdKind;
        @SinogramLength(
                min = 1,
                max = 64,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String csdcIdNo;
        @NotNull(
                message = "不能为空"
        )
        private Integer csdcIdEnddate;
        @SinogramLength(
                min = 0,
                max = 120,
                charset = "utf-8"
        )
        private String csdcIdAddress = " ";
        @SinogramLength(
                min = 0,
                max = 2,
                charset = "utf-8"
        )
        private String csdcAuxiIdKind = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String csdcAuxiIdNo = " ";
        private Integer csdcAuxiIdEnddate = 0;
        @SinogramLength(
                min = 0,
                max = 180,
                charset = "utf-8"
        )
        private String csdcAuxiIdAddress = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character csdcOpenType;
        private Integer csdcBirthday = 0;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character csdcClientGender;
        @SinogramLength(
                min = 0,
                max = 2,
                charset = "utf-8"
        )
        private String csdcDegreeCode = " ";
        @SinogramLength(
                min = 0,
                max = 2,
                charset = "utf-8"
        )
        private String csdcProfessionCode = " ";
        @SinogramLength(
                min = 0,
                max = 2,
                charset = "utf-8"
        )
        private String csdcNationId = " ";
        @SinogramLength(
                min = 0,
                max = 2,
                charset = "utf-8"
        )
        private String csdcOrganType = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character csdcRegisterFundProp = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character csdcStateOwnedProp = ' ';
        @SinogramLength(
                min = 0,
                max = 30,
                charset = "utf-8"
        )
        private String csdcOrganName = " ";
        @SinogramLength(
                min = 0,
                max = 100,
                charset = "utf-8"
        )
        private String organEnglishName = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String csdcHomePage = " ";
        @SinogramLength(
                min = 0,
                max = 90,
                charset = "utf-8"
        )
        private String csdcInstreprName = " ";
        @SinogramLength(
                min = 0,
                max = 2,
                charset = "utf-8"
        )
        private String csdcInstreprIdKind = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String csdcInstreprIdNo = " ";
        @SinogramLength(
                min = 0,
                max = 90,
                charset = "utf-8"
        )
        private String csdcRelationName = " ";
        @SinogramLength(
                min = 0,
                max = 2,
                charset = "utf-8"
        )
        private String csdcRelationIdKind = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String csdcRelationIdNo = " ";
        @SinogramLength(
                min = 0,
                max = 20,
                charset = "utf-8"
        )
        private String csdcMobilephone = " ";
        @SinogramLength(
                min = 0,
                max = 20,
                charset = "utf-8"
        )
        private String csdcPhoneCode = " ";
        @SinogramLength(
                min = 0,
                max = 20,
                charset = "utf-8"
        )
        private String csdcFax = " ";
        @SinogramLength(
                min = 0,
                max = 180,
                charset = "utf-8"
        )
        private String csdcAddress = " ";
        @SinogramLength(
                min = 0,
                max = 8,
                charset = "utf-8"
        )
        private String csdcZipcode = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String csdcEmail = " ";
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String csdcOpenSmsFlag = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character csdcNetsvrFlag;
        @SinogramLength(
                min = 0,
                max = 16,
                charset = "utf-8"
        )
        private String csdcNetsvrPassword = " ";
        @SinogramLength(
                min = 0,
                max = 10,
                charset = "utf-8"
        )
        private String csdcReserve1 = " ";
        @SinogramLength(
                min = 0,
                max = 10,
                charset = "utf-8"
        )
        private String csdcReserve2 = " ";
        @SinogramLength(
                min = 0,
                max = 10,
                charset = "utf-8"
        )
        private String csdcReserve3 = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String acptId = " ";
        @SinogramLength(
                min = 0,
                max = 20,
                charset = "utf-8"
        )
        private String csdcAcodeAccount = " ";

        public PostDataswapAcodeOpenInnerInput() {
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getClientId() {
            return this.clientId;
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getCsdcClientName() {
            return this.csdcClientName;
        }

        public Character getCsdcAccountKind() {
            return this.csdcAccountKind;
        }

        public String getCsdcNationality() {
            return this.csdcNationality;
        }

        public String getCsdcIdKind() {
            return this.csdcIdKind;
        }

        public String getCsdcIdNo() {
            return this.csdcIdNo;
        }

        public Integer getCsdcIdEnddate() {
            return this.csdcIdEnddate;
        }

        public String getCsdcIdAddress() {
            if (this.csdcIdAddress == null) {
                return " ";
            } else {
                return this.csdcIdAddress.isEmpty() ? " " : this.csdcIdAddress;
            }
        }

        public String getCsdcAuxiIdKind() {
            if (this.csdcAuxiIdKind == null) {
                return " ";
            } else {
                return this.csdcAuxiIdKind.isEmpty() ? " " : this.csdcAuxiIdKind;
            }
        }

        public String getCsdcAuxiIdNo() {
            if (this.csdcAuxiIdNo == null) {
                return " ";
            } else {
                return this.csdcAuxiIdNo.isEmpty() ? " " : this.csdcAuxiIdNo;
            }
        }

        public Integer getCsdcAuxiIdEnddate() {
            return this.csdcAuxiIdEnddate != null ? this.csdcAuxiIdEnddate : 0;
        }

        public String getCsdcAuxiIdAddress() {
            if (this.csdcAuxiIdAddress == null) {
                return " ";
            } else {
                return this.csdcAuxiIdAddress.isEmpty() ? " " : this.csdcAuxiIdAddress;
            }
        }

        public Character getCsdcOpenType() {
            return this.csdcOpenType;
        }

        public Integer getCsdcBirthday() {
            return this.csdcBirthday != null ? this.csdcBirthday : 0;
        }

        public Character getCsdcClientGender() {
            return this.csdcClientGender;
        }

        public String getCsdcDegreeCode() {
            if (this.csdcDegreeCode == null) {
                return " ";
            } else {
                return this.csdcDegreeCode.isEmpty() ? " " : this.csdcDegreeCode;
            }
        }

        public String getCsdcProfessionCode() {
            if (this.csdcProfessionCode == null) {
                return " ";
            } else {
                return this.csdcProfessionCode.isEmpty() ? " " : this.csdcProfessionCode;
            }
        }

        public String getCsdcNationId() {
            if (this.csdcNationId == null) {
                return " ";
            } else {
                return this.csdcNationId.isEmpty() ? " " : this.csdcNationId;
            }
        }

        public String getCsdcOrganType() {
            if (this.csdcOrganType == null) {
                return " ";
            } else {
                return this.csdcOrganType.isEmpty() ? " " : this.csdcOrganType;
            }
        }

        public Character getCsdcRegisterFundProp() {
            return this.csdcRegisterFundProp != null ? this.csdcRegisterFundProp : ' ';
        }

        public Character getCsdcStateOwnedProp() {
            return this.csdcStateOwnedProp != null ? this.csdcStateOwnedProp : ' ';
        }

        public String getCsdcOrganName() {
            if (this.csdcOrganName == null) {
                return " ";
            } else {
                return this.csdcOrganName.isEmpty() ? " " : this.csdcOrganName;
            }
        }

        public String getOrganEnglishName() {
            if (this.organEnglishName == null) {
                return " ";
            } else {
                return this.organEnglishName.isEmpty() ? " " : this.organEnglishName;
            }
        }

        public String getCsdcHomePage() {
            if (this.csdcHomePage == null) {
                return " ";
            } else {
                return this.csdcHomePage.isEmpty() ? " " : this.csdcHomePage;
            }
        }

        public String getCsdcInstreprName() {
            if (this.csdcInstreprName == null) {
                return " ";
            } else {
                return this.csdcInstreprName.isEmpty() ? " " : this.csdcInstreprName;
            }
        }

        public String getCsdcInstreprIdKind() {
            if (this.csdcInstreprIdKind == null) {
                return " ";
            } else {
                return this.csdcInstreprIdKind.isEmpty() ? " " : this.csdcInstreprIdKind;
            }
        }

        public String getCsdcInstreprIdNo() {
            if (this.csdcInstreprIdNo == null) {
                return " ";
            } else {
                return this.csdcInstreprIdNo.isEmpty() ? " " : this.csdcInstreprIdNo;
            }
        }

        public String getCsdcRelationName() {
            if (this.csdcRelationName == null) {
                return " ";
            } else {
                return this.csdcRelationName.isEmpty() ? " " : this.csdcRelationName;
            }
        }

        public String getCsdcRelationIdKind() {
            if (this.csdcRelationIdKind == null) {
                return " ";
            } else {
                return this.csdcRelationIdKind.isEmpty() ? " " : this.csdcRelationIdKind;
            }
        }

        public String getCsdcRelationIdNo() {
            if (this.csdcRelationIdNo == null) {
                return " ";
            } else {
                return this.csdcRelationIdNo.isEmpty() ? " " : this.csdcRelationIdNo;
            }
        }

        public String getCsdcMobilephone() {
            if (this.csdcMobilephone == null) {
                return " ";
            } else {
                return this.csdcMobilephone.isEmpty() ? " " : this.csdcMobilephone;
            }
        }

        public String getCsdcPhoneCode() {
            if (this.csdcPhoneCode == null) {
                return " ";
            } else {
                return this.csdcPhoneCode.isEmpty() ? " " : this.csdcPhoneCode;
            }
        }

        public String getCsdcFax() {
            if (this.csdcFax == null) {
                return " ";
            } else {
                return this.csdcFax.isEmpty() ? " " : this.csdcFax;
            }
        }

        public String getCsdcAddress() {
            if (this.csdcAddress == null) {
                return " ";
            } else {
                return this.csdcAddress.isEmpty() ? " " : this.csdcAddress;
            }
        }

        public String getCsdcZipcode() {
            if (this.csdcZipcode == null) {
                return " ";
            } else {
                return this.csdcZipcode.isEmpty() ? " " : this.csdcZipcode;
            }
        }

        public String getCsdcEmail() {
            if (this.csdcEmail == null) {
                return " ";
            } else {
                return this.csdcEmail.isEmpty() ? " " : this.csdcEmail;
            }
        }

        public String getCsdcOpenSmsFlag() {
            if (this.csdcOpenSmsFlag == null) {
                return " ";
            } else {
                return this.csdcOpenSmsFlag.isEmpty() ? " " : this.csdcOpenSmsFlag;
            }
        }

        public Character getCsdcNetsvrFlag() {
            return this.csdcNetsvrFlag;
        }

        public String getCsdcNetsvrPassword() {
            if (this.csdcNetsvrPassword == null) {
                return " ";
            } else {
                return this.csdcNetsvrPassword.isEmpty() ? " " : this.csdcNetsvrPassword;
            }
        }

        public String getCsdcReserve1() {
            if (this.csdcReserve1 == null) {
                return " ";
            } else {
                return this.csdcReserve1.isEmpty() ? " " : this.csdcReserve1;
            }
        }

        public String getCsdcReserve2() {
            if (this.csdcReserve2 == null) {
                return " ";
            } else {
                return this.csdcReserve2.isEmpty() ? " " : this.csdcReserve2;
            }
        }

        public String getCsdcReserve3() {
            if (this.csdcReserve3 == null) {
                return " ";
            } else {
                return this.csdcReserve3.isEmpty() ? " " : this.csdcReserve3;
            }
        }

        public String getAcptId() {
            if (this.acptId == null) {
                return " ";
            } else {
                return this.acptId.isEmpty() ? " " : this.acptId;
            }
        }

        public String getCsdcAcodeAccount() {
            if (this.csdcAcodeAccount == null) {
                return " ";
            } else {
                return this.csdcAcodeAccount.isEmpty() ? " " : this.csdcAcodeAccount;
            }
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setCsdcClientName(String csdcClientName) {
            this.csdcClientName = csdcClientName;
        }

        public void setCsdcAccountKind(Character csdcAccountKind) {
            this.csdcAccountKind = csdcAccountKind;
        }

        public void setCsdcNationality(String csdcNationality) {
            this.csdcNationality = csdcNationality;
        }

        public void setCsdcIdKind(String csdcIdKind) {
            this.csdcIdKind = csdcIdKind;
        }

        public void setCsdcIdNo(String csdcIdNo) {
            this.csdcIdNo = csdcIdNo;
        }

        public void setCsdcIdEnddate(Integer csdcIdEnddate) {
            this.csdcIdEnddate = csdcIdEnddate;
        }

        public void setCsdcIdAddress(String csdcIdAddress) {
            this.csdcIdAddress = csdcIdAddress;
        }

        public void setCsdcAuxiIdKind(String csdcAuxiIdKind) {
            this.csdcAuxiIdKind = csdcAuxiIdKind;
        }

        public void setCsdcAuxiIdNo(String csdcAuxiIdNo) {
            this.csdcAuxiIdNo = csdcAuxiIdNo;
        }

        public void setCsdcAuxiIdEnddate(Integer csdcAuxiIdEnddate) {
            this.csdcAuxiIdEnddate = csdcAuxiIdEnddate;
        }

        public void setCsdcAuxiIdAddress(String csdcAuxiIdAddress) {
            this.csdcAuxiIdAddress = csdcAuxiIdAddress;
        }

        public void setCsdcOpenType(Character csdcOpenType) {
            this.csdcOpenType = csdcOpenType;
        }

        public void setCsdcBirthday(Integer csdcBirthday) {
            this.csdcBirthday = csdcBirthday;
        }

        public void setCsdcClientGender(Character csdcClientGender) {
            this.csdcClientGender = csdcClientGender;
        }

        public void setCsdcDegreeCode(String csdcDegreeCode) {
            this.csdcDegreeCode = csdcDegreeCode;
        }

        public void setCsdcProfessionCode(String csdcProfessionCode) {
            this.csdcProfessionCode = csdcProfessionCode;
        }

        public void setCsdcNationId(String csdcNationId) {
            this.csdcNationId = csdcNationId;
        }

        public void setCsdcOrganType(String csdcOrganType) {
            this.csdcOrganType = csdcOrganType;
        }

        public void setCsdcRegisterFundProp(Character csdcRegisterFundProp) {
            this.csdcRegisterFundProp = csdcRegisterFundProp;
        }

        public void setCsdcStateOwnedProp(Character csdcStateOwnedProp) {
            this.csdcStateOwnedProp = csdcStateOwnedProp;
        }

        public void setCsdcOrganName(String csdcOrganName) {
            this.csdcOrganName = csdcOrganName;
        }

        public void setOrganEnglishName(String organEnglishName) {
            this.organEnglishName = organEnglishName;
        }

        public void setCsdcHomePage(String csdcHomePage) {
            this.csdcHomePage = csdcHomePage;
        }

        public void setCsdcInstreprName(String csdcInstreprName) {
            this.csdcInstreprName = csdcInstreprName;
        }

        public void setCsdcInstreprIdKind(String csdcInstreprIdKind) {
            this.csdcInstreprIdKind = csdcInstreprIdKind;
        }

        public void setCsdcInstreprIdNo(String csdcInstreprIdNo) {
            this.csdcInstreprIdNo = csdcInstreprIdNo;
        }

        public void setCsdcRelationName(String csdcRelationName) {
            this.csdcRelationName = csdcRelationName;
        }

        public void setCsdcRelationIdKind(String csdcRelationIdKind) {
            this.csdcRelationIdKind = csdcRelationIdKind;
        }

        public void setCsdcRelationIdNo(String csdcRelationIdNo) {
            this.csdcRelationIdNo = csdcRelationIdNo;
        }

        public void setCsdcMobilephone(String csdcMobilephone) {
            this.csdcMobilephone = csdcMobilephone;
        }

        public void setCsdcPhoneCode(String csdcPhoneCode) {
            this.csdcPhoneCode = csdcPhoneCode;
        }

        public void setCsdcFax(String csdcFax) {
            this.csdcFax = csdcFax;
        }

        public void setCsdcAddress(String csdcAddress) {
            this.csdcAddress = csdcAddress;
        }

        public void setCsdcZipcode(String csdcZipcode) {
            this.csdcZipcode = csdcZipcode;
        }

        public void setCsdcEmail(String csdcEmail) {
            this.csdcEmail = csdcEmail;
        }

        public void setCsdcOpenSmsFlag(String csdcOpenSmsFlag) {
            this.csdcOpenSmsFlag = csdcOpenSmsFlag;
        }

        public void setCsdcNetsvrFlag(Character csdcNetsvrFlag) {
            this.csdcNetsvrFlag = csdcNetsvrFlag;
        }

        public void setCsdcNetsvrPassword(String csdcNetsvrPassword) {
            this.csdcNetsvrPassword = csdcNetsvrPassword;
        }

        public void setCsdcReserve1(String csdcReserve1) {
            this.csdcReserve1 = csdcReserve1;
        }

        public void setCsdcReserve2(String csdcReserve2) {
            this.csdcReserve2 = csdcReserve2;
        }

        public void setCsdcReserve3(String csdcReserve3) {
            this.csdcReserve3 = csdcReserve3;
        }

        public void setAcptId(String acptId) {
            this.acptId = acptId;
        }

        public void setCsdcAcodeAccount(String csdcAcodeAccount) {
            this.csdcAcodeAccount = csdcAcodeAccount;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostDataswapAcodeOpenInnerInput:(");
            buffer.append("opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",csdcClientName:" + this.csdcClientName);
            buffer.append(",csdcAccountKind:" + this.csdcAccountKind);
            buffer.append(",csdcNationality:" + this.csdcNationality);
            buffer.append(",csdcIdKind:" + this.csdcIdKind);
            buffer.append(",csdcIdNo:" + this.csdcIdNo);
            buffer.append(",csdcIdEnddate:" + this.csdcIdEnddate);
            buffer.append(",csdcIdAddress:" + this.csdcIdAddress);
            buffer.append(",csdcAuxiIdKind:" + this.csdcAuxiIdKind);
            buffer.append(",csdcAuxiIdNo:" + this.csdcAuxiIdNo);
            buffer.append(",csdcAuxiIdEnddate:" + this.csdcAuxiIdEnddate);
            buffer.append(",csdcAuxiIdAddress:" + this.csdcAuxiIdAddress);
            buffer.append(",csdcOpenType:" + this.csdcOpenType);
            buffer.append(",csdcBirthday:" + this.csdcBirthday);
            buffer.append(",csdcClientGender:" + this.csdcClientGender);
            buffer.append(",csdcDegreeCode:" + this.csdcDegreeCode);
            buffer.append(",csdcProfessionCode:" + this.csdcProfessionCode);
            buffer.append(",csdcNationId:" + this.csdcNationId);
            buffer.append(",csdcOrganType:" + this.csdcOrganType);
            buffer.append(",csdcRegisterFundProp:" + this.csdcRegisterFundProp);
            buffer.append(",csdcStateOwnedProp:" + this.csdcStateOwnedProp);
            buffer.append(",csdcOrganName:" + this.csdcOrganName);
            buffer.append(",organEnglishName:" + this.organEnglishName);
            buffer.append(",csdcHomePage:" + this.csdcHomePage);
            buffer.append(",csdcInstreprName:" + this.csdcInstreprName);
            buffer.append(",csdcInstreprIdKind:" + this.csdcInstreprIdKind);
            buffer.append(",csdcInstreprIdNo:" + this.csdcInstreprIdNo);
            buffer.append(",csdcRelationName:" + this.csdcRelationName);
            buffer.append(",csdcRelationIdKind:" + this.csdcRelationIdKind);
            buffer.append(",csdcRelationIdNo:" + this.csdcRelationIdNo);
            buffer.append(",csdcMobilephone:" + this.csdcMobilephone);
            buffer.append(",csdcPhoneCode:" + this.csdcPhoneCode);
            buffer.append(",csdcFax:" + this.csdcFax);
            buffer.append(",csdcAddress:" + this.csdcAddress);
            buffer.append(",csdcZipcode:" + this.csdcZipcode);
            buffer.append(",csdcEmail:" + this.csdcEmail);
            buffer.append(",csdcOpenSmsFlag:" + this.csdcOpenSmsFlag);
            buffer.append(",csdcNetsvrFlag:" + this.csdcNetsvrFlag);
            buffer.append(",csdcNetsvrPassword:" + this.csdcNetsvrPassword);
            buffer.append(",csdcReserve1:" + this.csdcReserve1);
            buffer.append(",csdcReserve2:" + this.csdcReserve2);
            buffer.append(",csdcReserve3:" + this.csdcReserve3);
            buffer.append(",acptId:" + this.acptId);
            buffer.append(",csdcAcodeAccount:" + this.csdcAcodeAccount);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.clientId);
            builder.append(this.branchNo);
            builder.append(this.csdcClientName);
            builder.append(this.csdcAccountKind);
            builder.append(this.csdcNationality);
            builder.append(this.csdcIdKind);
            builder.append(this.csdcIdNo);
            builder.append(this.csdcIdEnddate);
            builder.append(this.csdcIdAddress);
            builder.append(this.csdcAuxiIdKind);
            builder.append(this.csdcAuxiIdNo);
            builder.append(this.csdcAuxiIdEnddate);
            builder.append(this.csdcAuxiIdAddress);
            builder.append(this.csdcOpenType);
            builder.append(this.csdcBirthday);
            builder.append(this.csdcClientGender);
            builder.append(this.csdcDegreeCode);
            builder.append(this.csdcProfessionCode);
            builder.append(this.csdcNationId);
            builder.append(this.csdcOrganType);
            builder.append(this.csdcRegisterFundProp);
            builder.append(this.csdcStateOwnedProp);
            builder.append(this.csdcOrganName);
            builder.append(this.organEnglishName);
            builder.append(this.csdcHomePage);
            builder.append(this.csdcInstreprName);
            builder.append(this.csdcInstreprIdKind);
            builder.append(this.csdcInstreprIdNo);
            builder.append(this.csdcRelationName);
            builder.append(this.csdcRelationIdKind);
            builder.append(this.csdcRelationIdNo);
            builder.append(this.csdcMobilephone);
            builder.append(this.csdcPhoneCode);
            builder.append(this.csdcFax);
            builder.append(this.csdcAddress);
            builder.append(this.csdcZipcode);
            builder.append(this.csdcEmail);
            builder.append(this.csdcOpenSmsFlag);
            builder.append(this.csdcNetsvrFlag);
            builder.append(this.csdcNetsvrPassword);
            builder.append(this.csdcReserve1);
            builder.append(this.csdcReserve2);
            builder.append(this.csdcReserve3);
            builder.append(this.acptId);
            builder.append(this.csdcAcodeAccount);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBcpService.PostDataswapAcodeOpenInnerInput) {
                InnerBcpService.PostDataswapAcodeOpenInnerInput test = (InnerBcpService.PostDataswapAcodeOpenInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.clientId, test.clientId);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.csdcClientName, test.csdcClientName);
                builder.append(this.csdcAccountKind, test.csdcAccountKind);
                builder.append(this.csdcNationality, test.csdcNationality);
                builder.append(this.csdcIdKind, test.csdcIdKind);
                builder.append(this.csdcIdNo, test.csdcIdNo);
                builder.append(this.csdcIdEnddate, test.csdcIdEnddate);
                builder.append(this.csdcIdAddress, test.csdcIdAddress);
                builder.append(this.csdcAuxiIdKind, test.csdcAuxiIdKind);
                builder.append(this.csdcAuxiIdNo, test.csdcAuxiIdNo);
                builder.append(this.csdcAuxiIdEnddate, test.csdcAuxiIdEnddate);
                builder.append(this.csdcAuxiIdAddress, test.csdcAuxiIdAddress);
                builder.append(this.csdcOpenType, test.csdcOpenType);
                builder.append(this.csdcBirthday, test.csdcBirthday);
                builder.append(this.csdcClientGender, test.csdcClientGender);
                builder.append(this.csdcDegreeCode, test.csdcDegreeCode);
                builder.append(this.csdcProfessionCode, test.csdcProfessionCode);
                builder.append(this.csdcNationId, test.csdcNationId);
                builder.append(this.csdcOrganType, test.csdcOrganType);
                builder.append(this.csdcRegisterFundProp, test.csdcRegisterFundProp);
                builder.append(this.csdcStateOwnedProp, test.csdcStateOwnedProp);
                builder.append(this.csdcOrganName, test.csdcOrganName);
                builder.append(this.organEnglishName, test.organEnglishName);
                builder.append(this.csdcHomePage, test.csdcHomePage);
                builder.append(this.csdcInstreprName, test.csdcInstreprName);
                builder.append(this.csdcInstreprIdKind, test.csdcInstreprIdKind);
                builder.append(this.csdcInstreprIdNo, test.csdcInstreprIdNo);
                builder.append(this.csdcRelationName, test.csdcRelationName);
                builder.append(this.csdcRelationIdKind, test.csdcRelationIdKind);
                builder.append(this.csdcRelationIdNo, test.csdcRelationIdNo);
                builder.append(this.csdcMobilephone, test.csdcMobilephone);
                builder.append(this.csdcPhoneCode, test.csdcPhoneCode);
                builder.append(this.csdcFax, test.csdcFax);
                builder.append(this.csdcAddress, test.csdcAddress);
                builder.append(this.csdcZipcode, test.csdcZipcode);
                builder.append(this.csdcEmail, test.csdcEmail);
                builder.append(this.csdcOpenSmsFlag, test.csdcOpenSmsFlag);
                builder.append(this.csdcNetsvrFlag, test.csdcNetsvrFlag);
                builder.append(this.csdcNetsvrPassword, test.csdcNetsvrPassword);
                builder.append(this.csdcReserve1, test.csdcReserve1);
                builder.append(this.csdcReserve2, test.csdcReserve2);
                builder.append(this.csdcReserve3, test.csdcReserve3);
                builder.append(this.acptId, test.acptId);
                builder.append(this.csdcAcodeAccount, test.csdcAcodeAccount);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutDataswapInfoModInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String positionStr = " ";

        public PutDataswapInfoModInnerOutput() {
        }

        public String getPositionStr() {
            if (this.positionStr == null) {
                return " ";
            } else {
                return this.positionStr.isEmpty() ? " " : this.positionStr;
            }
        }

        public void setPositionStr(String positionStr) {
            this.positionStr = positionStr;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutDataswapInfoModInnerOutput:(");
            buffer.append("positionStr:" + this.positionStr);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.positionStr);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBcpService.PutDataswapInfoModInnerOutput) {
                InnerBcpService.PutDataswapInfoModInnerOutput test = (InnerBcpService.PutDataswapInfoModInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.positionStr, test.positionStr);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutDataswapInfoModInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fundAccount = " ";
        @SinogramLength(
                min = 1,
                max = 20,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String acodeAccount;
        @SinogramLength(
                min = 1,
                max = 16000,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String paramData;

        public PutDataswapInfoModInnerInput() {
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getClientId() {
            return this.clientId;
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getAcodeAccount() {
            return this.acodeAccount;
        }

        public String getParamData() {
            return this.paramData;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setAcodeAccount(String acodeAccount) {
            this.acodeAccount = acodeAccount;
        }

        public void setParamData(String paramData) {
            this.paramData = paramData;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutDataswapInfoModInnerInput:(");
            buffer.append("opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",acodeAccount:" + this.acodeAccount);
            buffer.append(",paramData:" + this.paramData);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.clientId);
            builder.append(this.fundAccount);
            builder.append(this.acodeAccount);
            builder.append(this.paramData);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBcpService.PutDataswapInfoModInnerInput) {
                InnerBcpService.PutDataswapInfoModInnerInput test = (InnerBcpService.PutDataswapInfoModInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.clientId, test.clientId);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.acodeAccount, test.acodeAccount);
                builder.append(this.paramData, test.paramData);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutDataswapHolderCheckInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String opRemark = " ";

        public PutDataswapHolderCheckInnerOutput() {
        }

        public String getOpRemark() {
            if (this.opRemark == null) {
                return " ";
            } else {
                return this.opRemark.isEmpty() ? " " : this.opRemark;
            }
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutDataswapHolderCheckInnerOutput:(");
            buffer.append("opRemark:" + this.opRemark);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opRemark);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBcpService.PutDataswapHolderCheckInnerOutput) {
                InnerBcpService.PutDataswapHolderCheckInnerOutput test = (InnerBcpService.PutDataswapHolderCheckInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opRemark, test.opRemark);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutDataswapHolderCheckInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String functionStr = " ";
        private Integer branchNo = 0;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId;
        @SinogramLength(
                min = 1,
                max = 16000,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String paramData;

        public PutDataswapHolderCheckInnerInput() {
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getFunctionStr() {
            if (this.functionStr == null) {
                return " ";
            } else {
                return this.functionStr.isEmpty() ? " " : this.functionStr;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getClientId() {
            return this.clientId;
        }

        public String getParamData() {
            return this.paramData;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setFunctionStr(String functionStr) {
            this.functionStr = functionStr;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setParamData(String paramData) {
            this.paramData = paramData;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutDataswapHolderCheckInnerInput:(");
            buffer.append("opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",functionStr:" + this.functionStr);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",paramData:" + this.paramData);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.functionStr);
            builder.append(this.branchNo);
            builder.append(this.clientId);
            builder.append(this.paramData);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBcpService.PutDataswapHolderCheckInnerInput) {
                InnerBcpService.PutDataswapHolderCheckInnerInput test = (InnerBcpService.PutDataswapHolderCheckInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.functionStr, test.functionStr);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.clientId, test.clientId);
                builder.append(this.paramData, test.paramData);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutDataswapGeneralCheckInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String opRemark = " ";
        private String csdcAcodeAccount = " ";
        private String csdcIdKind = " ";
        private String csdcIdNo = " ";

        public PutDataswapGeneralCheckInnerOutput() {
        }

        public String getOpRemark() {
            if (this.opRemark == null) {
                return " ";
            } else {
                return this.opRemark.isEmpty() ? " " : this.opRemark;
            }
        }

        public String getCsdcAcodeAccount() {
            if (this.csdcAcodeAccount == null) {
                return " ";
            } else {
                return this.csdcAcodeAccount.isEmpty() ? " " : this.csdcAcodeAccount;
            }
        }

        public String getCsdcIdKind() {
            if (this.csdcIdKind == null) {
                return " ";
            } else {
                return this.csdcIdKind.isEmpty() ? " " : this.csdcIdKind;
            }
        }

        public String getCsdcIdNo() {
            if (this.csdcIdNo == null) {
                return " ";
            } else {
                return this.csdcIdNo.isEmpty() ? " " : this.csdcIdNo;
            }
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public void setCsdcAcodeAccount(String csdcAcodeAccount) {
            this.csdcAcodeAccount = csdcAcodeAccount;
        }

        public void setCsdcIdKind(String csdcIdKind) {
            this.csdcIdKind = csdcIdKind;
        }

        public void setCsdcIdNo(String csdcIdNo) {
            this.csdcIdNo = csdcIdNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutDataswapGeneralCheckInnerOutput:(");
            buffer.append("opRemark:" + this.opRemark);
            buffer.append(",csdcAcodeAccount:" + this.csdcAcodeAccount);
            buffer.append(",csdcIdKind:" + this.csdcIdKind);
            buffer.append(",csdcIdNo:" + this.csdcIdNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opRemark);
            builder.append(this.csdcAcodeAccount);
            builder.append(this.csdcIdKind);
            builder.append(this.csdcIdNo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBcpService.PutDataswapGeneralCheckInnerOutput) {
                InnerBcpService.PutDataswapGeneralCheckInnerOutput test = (InnerBcpService.PutDataswapGeneralCheckInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opRemark, test.opRemark);
                builder.append(this.csdcAcodeAccount, test.csdcAcodeAccount);
                builder.append(this.csdcIdKind, test.csdcIdKind);
                builder.append(this.csdcIdNo, test.csdcIdNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutDataswapGeneralCheckInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String functionStr = " ";
        private Integer branchNo = 0;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId;
        @SinogramLength(
                min = 1,
                max = 16000,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String paramData;

        public PutDataswapGeneralCheckInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getFunctionStr() {
            if (this.functionStr == null) {
                return " ";
            } else {
                return this.functionStr.isEmpty() ? " " : this.functionStr;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getClientId() {
            return this.clientId;
        }

        public String getParamData() {
            return this.paramData;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setFunctionStr(String functionStr) {
            this.functionStr = functionStr;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setParamData(String paramData) {
            this.paramData = paramData;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutDataswapGeneralCheckInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",functionStr:" + this.functionStr);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",paramData:" + this.paramData);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.functionStr);
            builder.append(this.branchNo);
            builder.append(this.clientId);
            builder.append(this.paramData);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBcpService.PutDataswapGeneralCheckInnerInput) {
                InnerBcpService.PutDataswapGeneralCheckInnerInput test = (InnerBcpService.PutDataswapGeneralCheckInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.functionStr, test.functionStr);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.clientId, test.clientId);
                builder.append(this.paramData, test.paramData);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutDataswapAcodeCheckInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String opRemark = " ";
        private String csdcAcodeAccount = " ";

        public PutDataswapAcodeCheckInnerOutput() {
        }

        public String getOpRemark() {
            if (this.opRemark == null) {
                return " ";
            } else {
                return this.opRemark.isEmpty() ? " " : this.opRemark;
            }
        }

        public String getCsdcAcodeAccount() {
            if (this.csdcAcodeAccount == null) {
                return " ";
            } else {
                return this.csdcAcodeAccount.isEmpty() ? " " : this.csdcAcodeAccount;
            }
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public void setCsdcAcodeAccount(String csdcAcodeAccount) {
            this.csdcAcodeAccount = csdcAcodeAccount;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutDataswapAcodeCheckInnerOutput:(");
            buffer.append("opRemark:" + this.opRemark);
            buffer.append(",csdcAcodeAccount:" + this.csdcAcodeAccount);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opRemark);
            builder.append(this.csdcAcodeAccount);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBcpService.PutDataswapAcodeCheckInnerOutput) {
                InnerBcpService.PutDataswapAcodeCheckInnerOutput test = (InnerBcpService.PutDataswapAcodeCheckInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opRemark, test.opRemark);
                builder.append(this.csdcAcodeAccount, test.csdcAcodeAccount);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutDataswapAcodeCheckInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String functionStr = " ";
        private Integer branchNo = 0;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId;
        @SinogramLength(
                min = 0,
                max = 20,
                charset = "utf-8"
        )
        private String acodeAccount = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character csdcAcodeStatus = ' ';

        public PutDataswapAcodeCheckInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getFunctionStr() {
            if (this.functionStr == null) {
                return " ";
            } else {
                return this.functionStr.isEmpty() ? " " : this.functionStr;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getClientId() {
            return this.clientId;
        }

        public String getAcodeAccount() {
            if (this.acodeAccount == null) {
                return " ";
            } else {
                return this.acodeAccount.isEmpty() ? " " : this.acodeAccount;
            }
        }

        public Character getCsdcAcodeStatus() {
            return this.csdcAcodeStatus != null ? this.csdcAcodeStatus : ' ';
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setFunctionStr(String functionStr) {
            this.functionStr = functionStr;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setAcodeAccount(String acodeAccount) {
            this.acodeAccount = acodeAccount;
        }

        public void setCsdcAcodeStatus(Character csdcAcodeStatus) {
            this.csdcAcodeStatus = csdcAcodeStatus;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutDataswapAcodeCheckInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",functionStr:" + this.functionStr);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",acodeAccount:" + this.acodeAccount);
            buffer.append(",csdcAcodeStatus:" + this.csdcAcodeStatus);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.functionStr);
            builder.append(this.branchNo);
            builder.append(this.clientId);
            builder.append(this.acodeAccount);
            builder.append(this.csdcAcodeStatus);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBcpService.PutDataswapAcodeCheckInnerInput) {
                InnerBcpService.PutDataswapAcodeCheckInnerInput test = (InnerBcpService.PutDataswapAcodeCheckInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.functionStr, test.functionStr);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.clientId, test.clientId);
                builder.append(this.acodeAccount, test.acodeAccount);
                builder.append(this.csdcAcodeStatus, test.csdcAcodeStatus);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutDataswapEligInfoModInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String csdcBusiKind = " ";
        private String csdcAcodeAccount = " ";
        private String csdcHolderKind = " ";
        private String csdcStockAccount = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character csdcEligKind = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character csdcSignKind = ' ';
        private Integer csdcSignDate = 0;
        private String csdcBranchId = " ";
        private String resultCode = " ";
        private String dealInfo = " ";

        public PutDataswapEligInfoModInnerOutput() {
        }

        public String getCsdcBusiKind() {
            if (this.csdcBusiKind == null) {
                return " ";
            } else {
                return this.csdcBusiKind.isEmpty() ? " " : this.csdcBusiKind;
            }
        }

        public String getCsdcAcodeAccount() {
            if (this.csdcAcodeAccount == null) {
                return " ";
            } else {
                return this.csdcAcodeAccount.isEmpty() ? " " : this.csdcAcodeAccount;
            }
        }

        public String getCsdcHolderKind() {
            if (this.csdcHolderKind == null) {
                return " ";
            } else {
                return this.csdcHolderKind.isEmpty() ? " " : this.csdcHolderKind;
            }
        }

        public String getCsdcStockAccount() {
            if (this.csdcStockAccount == null) {
                return " ";
            } else {
                return this.csdcStockAccount.isEmpty() ? " " : this.csdcStockAccount;
            }
        }

        public Character getCsdcEligKind() {
            return this.csdcEligKind != null ? this.csdcEligKind : ' ';
        }

        public Character getCsdcSignKind() {
            return this.csdcSignKind != null ? this.csdcSignKind : ' ';
        }

        public Integer getCsdcSignDate() {
            return this.csdcSignDate != null ? this.csdcSignDate : 0;
        }

        public String getCsdcBranchId() {
            if (this.csdcBranchId == null) {
                return " ";
            } else {
                return this.csdcBranchId.isEmpty() ? " " : this.csdcBranchId;
            }
        }

        public String getResultCode() {
            if (this.resultCode == null) {
                return " ";
            } else {
                return this.resultCode.isEmpty() ? " " : this.resultCode;
            }
        }

        public String getDealInfo() {
            if (this.dealInfo == null) {
                return " ";
            } else {
                return this.dealInfo.isEmpty() ? " " : this.dealInfo;
            }
        }

        public void setCsdcBusiKind(String csdcBusiKind) {
            this.csdcBusiKind = csdcBusiKind;
        }

        public void setCsdcAcodeAccount(String csdcAcodeAccount) {
            this.csdcAcodeAccount = csdcAcodeAccount;
        }

        public void setCsdcHolderKind(String csdcHolderKind) {
            this.csdcHolderKind = csdcHolderKind;
        }

        public void setCsdcStockAccount(String csdcStockAccount) {
            this.csdcStockAccount = csdcStockAccount;
        }

        public void setCsdcEligKind(Character csdcEligKind) {
            this.csdcEligKind = csdcEligKind;
        }

        public void setCsdcSignKind(Character csdcSignKind) {
            this.csdcSignKind = csdcSignKind;
        }

        public void setCsdcSignDate(Integer csdcSignDate) {
            this.csdcSignDate = csdcSignDate;
        }

        public void setCsdcBranchId(String csdcBranchId) {
            this.csdcBranchId = csdcBranchId;
        }

        public void setResultCode(String resultCode) {
            this.resultCode = resultCode;
        }

        public void setDealInfo(String dealInfo) {
            this.dealInfo = dealInfo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutDataswapEligInfoModInnerOutput:(");
            buffer.append("csdcBusiKind:" + this.csdcBusiKind);
            buffer.append(",csdcAcodeAccount:" + this.csdcAcodeAccount);
            buffer.append(",csdcHolderKind:" + this.csdcHolderKind);
            buffer.append(",csdcStockAccount:" + this.csdcStockAccount);
            buffer.append(",csdcEligKind:" + this.csdcEligKind);
            buffer.append(",csdcSignKind:" + this.csdcSignKind);
            buffer.append(",csdcSignDate:" + this.csdcSignDate);
            buffer.append(",csdcBranchId:" + this.csdcBranchId);
            buffer.append(",resultCode:" + this.resultCode);
            buffer.append(",dealInfo:" + this.dealInfo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.csdcBusiKind);
            builder.append(this.csdcAcodeAccount);
            builder.append(this.csdcHolderKind);
            builder.append(this.csdcStockAccount);
            builder.append(this.csdcEligKind);
            builder.append(this.csdcSignKind);
            builder.append(this.csdcSignDate);
            builder.append(this.csdcBranchId);
            builder.append(this.resultCode);
            builder.append(this.dealInfo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBcpService.PutDataswapEligInfoModInnerOutput) {
                InnerBcpService.PutDataswapEligInfoModInnerOutput test = (InnerBcpService.PutDataswapEligInfoModInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.csdcBusiKind, test.csdcBusiKind);
                builder.append(this.csdcAcodeAccount, test.csdcAcodeAccount);
                builder.append(this.csdcHolderKind, test.csdcHolderKind);
                builder.append(this.csdcStockAccount, test.csdcStockAccount);
                builder.append(this.csdcEligKind, test.csdcEligKind);
                builder.append(this.csdcSignKind, test.csdcSignKind);
                builder.append(this.csdcSignDate, test.csdcSignDate);
                builder.append(this.csdcBranchId, test.csdcBranchId);
                builder.append(this.resultCode, test.resultCode);
                builder.append(this.dealInfo, test.dealInfo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutDataswapEligInfoModInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fundAccount = " ";
        @SinogramLength(
                min = 1,
                max = 2,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String csdcBusiKind;
        @SinogramLength(
                min = 0,
                max = 20,
                charset = "utf-8"
        )
        private String acodeAccount = " ";
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String exchangeType = " ";
        @SinogramLength(
                min = 0,
                max = 2,
                charset = "utf-8"
        )
        private String csdcHolderKind = " ";
        @SinogramLength(
                min = 1,
                max = 20,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String stockAccount;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character csdcEligKind = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character csdcSignKind = ' ';
        private Integer csdcSignDate = 0;
        @SinogramLength(
                min = 0,
                max = 2,
                charset = "utf-8"
        )
        private String csdcBranchId = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String acptId = " ";

        public PutDataswapEligInfoModInnerInput() {
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getClientId() {
            return this.clientId;
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getCsdcBusiKind() {
            return this.csdcBusiKind;
        }

        public String getAcodeAccount() {
            if (this.acodeAccount == null) {
                return " ";
            } else {
                return this.acodeAccount.isEmpty() ? " " : this.acodeAccount;
            }
        }

        public String getExchangeType() {
            if (this.exchangeType == null) {
                return " ";
            } else {
                return this.exchangeType.isEmpty() ? " " : this.exchangeType;
            }
        }

        public String getCsdcHolderKind() {
            if (this.csdcHolderKind == null) {
                return " ";
            } else {
                return this.csdcHolderKind.isEmpty() ? " " : this.csdcHolderKind;
            }
        }

        public String getStockAccount() {
            return this.stockAccount;
        }

        public Character getCsdcEligKind() {
            return this.csdcEligKind != null ? this.csdcEligKind : ' ';
        }

        public Character getCsdcSignKind() {
            return this.csdcSignKind != null ? this.csdcSignKind : ' ';
        }

        public Integer getCsdcSignDate() {
            return this.csdcSignDate != null ? this.csdcSignDate : 0;
        }

        public String getCsdcBranchId() {
            if (this.csdcBranchId == null) {
                return " ";
            } else {
                return this.csdcBranchId.isEmpty() ? " " : this.csdcBranchId;
            }
        }

        public String getAcptId() {
            if (this.acptId == null) {
                return " ";
            } else {
                return this.acptId.isEmpty() ? " " : this.acptId;
            }
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setCsdcBusiKind(String csdcBusiKind) {
            this.csdcBusiKind = csdcBusiKind;
        }

        public void setAcodeAccount(String acodeAccount) {
            this.acodeAccount = acodeAccount;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public void setCsdcHolderKind(String csdcHolderKind) {
            this.csdcHolderKind = csdcHolderKind;
        }

        public void setStockAccount(String stockAccount) {
            this.stockAccount = stockAccount;
        }

        public void setCsdcEligKind(Character csdcEligKind) {
            this.csdcEligKind = csdcEligKind;
        }

        public void setCsdcSignKind(Character csdcSignKind) {
            this.csdcSignKind = csdcSignKind;
        }

        public void setCsdcSignDate(Integer csdcSignDate) {
            this.csdcSignDate = csdcSignDate;
        }

        public void setCsdcBranchId(String csdcBranchId) {
            this.csdcBranchId = csdcBranchId;
        }

        public void setAcptId(String acptId) {
            this.acptId = acptId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutDataswapEligInfoModInnerInput:(");
            buffer.append("opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",csdcBusiKind:" + this.csdcBusiKind);
            buffer.append(",acodeAccount:" + this.acodeAccount);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(",csdcHolderKind:" + this.csdcHolderKind);
            buffer.append(",stockAccount:" + this.stockAccount);
            buffer.append(",csdcEligKind:" + this.csdcEligKind);
            buffer.append(",csdcSignKind:" + this.csdcSignKind);
            buffer.append(",csdcSignDate:" + this.csdcSignDate);
            buffer.append(",csdcBranchId:" + this.csdcBranchId);
            buffer.append(",acptId:" + this.acptId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.clientId);
            builder.append(this.fundAccount);
            builder.append(this.csdcBusiKind);
            builder.append(this.acodeAccount);
            builder.append(this.exchangeType);
            builder.append(this.csdcHolderKind);
            builder.append(this.stockAccount);
            builder.append(this.csdcEligKind);
            builder.append(this.csdcSignKind);
            builder.append(this.csdcSignDate);
            builder.append(this.csdcBranchId);
            builder.append(this.acptId);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBcpService.PutDataswapEligInfoModInnerInput) {
                InnerBcpService.PutDataswapEligInfoModInnerInput test = (InnerBcpService.PutDataswapEligInfoModInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.clientId, test.clientId);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.csdcBusiKind, test.csdcBusiKind);
                builder.append(this.acodeAccount, test.acodeAccount);
                builder.append(this.exchangeType, test.exchangeType);
                builder.append(this.csdcHolderKind, test.csdcHolderKind);
                builder.append(this.stockAccount, test.stockAccount);
                builder.append(this.csdcEligKind, test.csdcEligKind);
                builder.append(this.csdcSignKind, test.csdcSignKind);
                builder.append(this.csdcSignDate, test.csdcSignDate);
                builder.append(this.csdcBranchId, test.csdcBranchId);
                builder.append(this.acptId, test.acptId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetDataswapHolderQueryInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String csdcClientName = " ";
        private String csdcIdKind = " ";
        private String csdcIdNo = " ";
        private String csdcAcodeAccount = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character csdcAcodeStatus = ' ';
        private String csdcHolderKind = " ";
        private String csdcStockAccount = " ";
        private String csdcHolderStatus = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character csdcOpenType = ' ';
        private Integer csdcOpenDate = 0;
        private String csdcOpenorganName = " ";
        private Integer csdcCancelDate = 0;
        private String csdcCancelOrganName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character csdcRelationFlag = ' ';
        private String csdcRelationOrganName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character csdcUnquFlag = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character csdcUnquTradeRestricts = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character csdcUnquReasonKind = ' ';
        private String resultCode = " ";
        private String dealInfo = " ";

        public GetDataswapHolderQueryInnerOutput() {
        }

        public String getCsdcClientName() {
            if (this.csdcClientName == null) {
                return " ";
            } else {
                return this.csdcClientName.isEmpty() ? " " : this.csdcClientName;
            }
        }

        public String getCsdcIdKind() {
            if (this.csdcIdKind == null) {
                return " ";
            } else {
                return this.csdcIdKind.isEmpty() ? " " : this.csdcIdKind;
            }
        }

        public String getCsdcIdNo() {
            if (this.csdcIdNo == null) {
                return " ";
            } else {
                return this.csdcIdNo.isEmpty() ? " " : this.csdcIdNo;
            }
        }

        public String getCsdcAcodeAccount() {
            if (this.csdcAcodeAccount == null) {
                return " ";
            } else {
                return this.csdcAcodeAccount.isEmpty() ? " " : this.csdcAcodeAccount;
            }
        }

        public Character getCsdcAcodeStatus() {
            return this.csdcAcodeStatus != null ? this.csdcAcodeStatus : ' ';
        }

        public String getCsdcHolderKind() {
            if (this.csdcHolderKind == null) {
                return " ";
            } else {
                return this.csdcHolderKind.isEmpty() ? " " : this.csdcHolderKind;
            }
        }

        public String getCsdcStockAccount() {
            if (this.csdcStockAccount == null) {
                return " ";
            } else {
                return this.csdcStockAccount.isEmpty() ? " " : this.csdcStockAccount;
            }
        }

        public String getCsdcHolderStatus() {
            if (this.csdcHolderStatus == null) {
                return " ";
            } else {
                return this.csdcHolderStatus.isEmpty() ? " " : this.csdcHolderStatus;
            }
        }

        public Character getCsdcOpenType() {
            return this.csdcOpenType != null ? this.csdcOpenType : ' ';
        }

        public Integer getCsdcOpenDate() {
            return this.csdcOpenDate != null ? this.csdcOpenDate : 0;
        }

        public String getCsdcOpenorganName() {
            if (this.csdcOpenorganName == null) {
                return " ";
            } else {
                return this.csdcOpenorganName.isEmpty() ? " " : this.csdcOpenorganName;
            }
        }

        public Integer getCsdcCancelDate() {
            return this.csdcCancelDate != null ? this.csdcCancelDate : 0;
        }

        public String getCsdcCancelOrganName() {
            if (this.csdcCancelOrganName == null) {
                return " ";
            } else {
                return this.csdcCancelOrganName.isEmpty() ? " " : this.csdcCancelOrganName;
            }
        }

        public Character getCsdcRelationFlag() {
            return this.csdcRelationFlag != null ? this.csdcRelationFlag : ' ';
        }

        public String getCsdcRelationOrganName() {
            if (this.csdcRelationOrganName == null) {
                return " ";
            } else {
                return this.csdcRelationOrganName.isEmpty() ? " " : this.csdcRelationOrganName;
            }
        }

        public Character getCsdcUnquFlag() {
            return this.csdcUnquFlag != null ? this.csdcUnquFlag : ' ';
        }

        public Character getCsdcUnquTradeRestricts() {
            return this.csdcUnquTradeRestricts != null ? this.csdcUnquTradeRestricts : ' ';
        }

        public Character getCsdcUnquReasonKind() {
            return this.csdcUnquReasonKind != null ? this.csdcUnquReasonKind : ' ';
        }

        public String getResultCode() {
            if (this.resultCode == null) {
                return " ";
            } else {
                return this.resultCode.isEmpty() ? " " : this.resultCode;
            }
        }

        public String getDealInfo() {
            if (this.dealInfo == null) {
                return " ";
            } else {
                return this.dealInfo.isEmpty() ? " " : this.dealInfo;
            }
        }

        public void setCsdcClientName(String csdcClientName) {
            this.csdcClientName = csdcClientName;
        }

        public void setCsdcIdKind(String csdcIdKind) {
            this.csdcIdKind = csdcIdKind;
        }

        public void setCsdcIdNo(String csdcIdNo) {
            this.csdcIdNo = csdcIdNo;
        }

        public void setCsdcAcodeAccount(String csdcAcodeAccount) {
            this.csdcAcodeAccount = csdcAcodeAccount;
        }

        public void setCsdcAcodeStatus(Character csdcAcodeStatus) {
            this.csdcAcodeStatus = csdcAcodeStatus;
        }

        public void setCsdcHolderKind(String csdcHolderKind) {
            this.csdcHolderKind = csdcHolderKind;
        }

        public void setCsdcStockAccount(String csdcStockAccount) {
            this.csdcStockAccount = csdcStockAccount;
        }

        public void setCsdcHolderStatus(String csdcHolderStatus) {
            this.csdcHolderStatus = csdcHolderStatus;
        }

        public void setCsdcOpenType(Character csdcOpenType) {
            this.csdcOpenType = csdcOpenType;
        }

        public void setCsdcOpenDate(Integer csdcOpenDate) {
            this.csdcOpenDate = csdcOpenDate;
        }

        public void setCsdcOpenorganName(String csdcOpenorganName) {
            this.csdcOpenorganName = csdcOpenorganName;
        }

        public void setCsdcCancelDate(Integer csdcCancelDate) {
            this.csdcCancelDate = csdcCancelDate;
        }

        public void setCsdcCancelOrganName(String csdcCancelOrganName) {
            this.csdcCancelOrganName = csdcCancelOrganName;
        }

        public void setCsdcRelationFlag(Character csdcRelationFlag) {
            this.csdcRelationFlag = csdcRelationFlag;
        }

        public void setCsdcRelationOrganName(String csdcRelationOrganName) {
            this.csdcRelationOrganName = csdcRelationOrganName;
        }

        public void setCsdcUnquFlag(Character csdcUnquFlag) {
            this.csdcUnquFlag = csdcUnquFlag;
        }

        public void setCsdcUnquTradeRestricts(Character csdcUnquTradeRestricts) {
            this.csdcUnquTradeRestricts = csdcUnquTradeRestricts;
        }

        public void setCsdcUnquReasonKind(Character csdcUnquReasonKind) {
            this.csdcUnquReasonKind = csdcUnquReasonKind;
        }

        public void setResultCode(String resultCode) {
            this.resultCode = resultCode;
        }

        public void setDealInfo(String dealInfo) {
            this.dealInfo = dealInfo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetDataswapHolderQueryInnerOutput:(");
            buffer.append("csdcClientName:" + this.csdcClientName);
            buffer.append(",csdcIdKind:" + this.csdcIdKind);
            buffer.append(",csdcIdNo:" + this.csdcIdNo);
            buffer.append(",csdcAcodeAccount:" + this.csdcAcodeAccount);
            buffer.append(",csdcAcodeStatus:" + this.csdcAcodeStatus);
            buffer.append(",csdcHolderKind:" + this.csdcHolderKind);
            buffer.append(",csdcStockAccount:" + this.csdcStockAccount);
            buffer.append(",csdcHolderStatus:" + this.csdcHolderStatus);
            buffer.append(",csdcOpenType:" + this.csdcOpenType);
            buffer.append(",csdcOpenDate:" + this.csdcOpenDate);
            buffer.append(",csdcOpenorganName:" + this.csdcOpenorganName);
            buffer.append(",csdcCancelDate:" + this.csdcCancelDate);
            buffer.append(",csdcCancelOrganName:" + this.csdcCancelOrganName);
            buffer.append(",csdcRelationFlag:" + this.csdcRelationFlag);
            buffer.append(",csdcRelationOrganName:" + this.csdcRelationOrganName);
            buffer.append(",csdcUnquFlag:" + this.csdcUnquFlag);
            buffer.append(",csdcUnquTradeRestricts:" + this.csdcUnquTradeRestricts);
            buffer.append(",csdcUnquReasonKind:" + this.csdcUnquReasonKind);
            buffer.append(",resultCode:" + this.resultCode);
            buffer.append(",dealInfo:" + this.dealInfo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.csdcClientName);
            builder.append(this.csdcIdKind);
            builder.append(this.csdcIdNo);
            builder.append(this.csdcAcodeAccount);
            builder.append(this.csdcAcodeStatus);
            builder.append(this.csdcHolderKind);
            builder.append(this.csdcStockAccount);
            builder.append(this.csdcHolderStatus);
            builder.append(this.csdcOpenType);
            builder.append(this.csdcOpenDate);
            builder.append(this.csdcOpenorganName);
            builder.append(this.csdcCancelDate);
            builder.append(this.csdcCancelOrganName);
            builder.append(this.csdcRelationFlag);
            builder.append(this.csdcRelationOrganName);
            builder.append(this.csdcUnquFlag);
            builder.append(this.csdcUnquTradeRestricts);
            builder.append(this.csdcUnquReasonKind);
            builder.append(this.resultCode);
            builder.append(this.dealInfo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBcpService.GetDataswapHolderQueryInnerOutput) {
                InnerBcpService.GetDataswapHolderQueryInnerOutput test = (InnerBcpService.GetDataswapHolderQueryInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.csdcClientName, test.csdcClientName);
                builder.append(this.csdcIdKind, test.csdcIdKind);
                builder.append(this.csdcIdNo, test.csdcIdNo);
                builder.append(this.csdcAcodeAccount, test.csdcAcodeAccount);
                builder.append(this.csdcAcodeStatus, test.csdcAcodeStatus);
                builder.append(this.csdcHolderKind, test.csdcHolderKind);
                builder.append(this.csdcStockAccount, test.csdcStockAccount);
                builder.append(this.csdcHolderStatus, test.csdcHolderStatus);
                builder.append(this.csdcOpenType, test.csdcOpenType);
                builder.append(this.csdcOpenDate, test.csdcOpenDate);
                builder.append(this.csdcOpenorganName, test.csdcOpenorganName);
                builder.append(this.csdcCancelDate, test.csdcCancelDate);
                builder.append(this.csdcCancelOrganName, test.csdcCancelOrganName);
                builder.append(this.csdcRelationFlag, test.csdcRelationFlag);
                builder.append(this.csdcRelationOrganName, test.csdcRelationOrganName);
                builder.append(this.csdcUnquFlag, test.csdcUnquFlag);
                builder.append(this.csdcUnquTradeRestricts, test.csdcUnquTradeRestricts);
                builder.append(this.csdcUnquReasonKind, test.csdcUnquReasonKind);
                builder.append(this.resultCode, test.resultCode);
                builder.append(this.dealInfo, test.dealInfo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetDataswapHolderQueryInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fundAccount = " ";
        @SinogramLength(
                min = 0,
                max = 20,
                charset = "utf-8"
        )
        private String acodeAccount = " ";
        @SinogramLength(
                min = 0,
                max = 180,
                charset = "utf-8"
        )
        private String csdcClientName = " ";
        @SinogramLength(
                min = 0,
                max = 2,
                charset = "utf-8"
        )
        private String csdcIdKind = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String csdcIdNo = " ";
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String exchangeType = " ";
        @SinogramLength(
                min = 0,
                max = 2,
                charset = "utf-8"
        )
        private String csdcHolderKind = " ";
        @SinogramLength(
                min = 0,
                max = 20,
                charset = "utf-8"
        )
        private String stockAccount = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String enStockAccount = " ";

        public GetDataswapHolderQueryInnerInput() {
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getClientId() {
            return this.clientId;
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getAcodeAccount() {
            if (this.acodeAccount == null) {
                return " ";
            } else {
                return this.acodeAccount.isEmpty() ? " " : this.acodeAccount;
            }
        }

        public String getCsdcClientName() {
            if (this.csdcClientName == null) {
                return " ";
            } else {
                return this.csdcClientName.isEmpty() ? " " : this.csdcClientName;
            }
        }

        public String getCsdcIdKind() {
            if (this.csdcIdKind == null) {
                return " ";
            } else {
                return this.csdcIdKind.isEmpty() ? " " : this.csdcIdKind;
            }
        }

        public String getCsdcIdNo() {
            if (this.csdcIdNo == null) {
                return " ";
            } else {
                return this.csdcIdNo.isEmpty() ? " " : this.csdcIdNo;
            }
        }

        public String getExchangeType() {
            if (this.exchangeType == null) {
                return " ";
            } else {
                return this.exchangeType.isEmpty() ? " " : this.exchangeType;
            }
        }

        public String getCsdcHolderKind() {
            if (this.csdcHolderKind == null) {
                return " ";
            } else {
                return this.csdcHolderKind.isEmpty() ? " " : this.csdcHolderKind;
            }
        }

        public String getStockAccount() {
            if (this.stockAccount == null) {
                return " ";
            } else {
                return this.stockAccount.isEmpty() ? " " : this.stockAccount;
            }
        }

        public String getEnStockAccount() {
            if (this.enStockAccount == null) {
                return " ";
            } else {
                return this.enStockAccount.isEmpty() ? " " : this.enStockAccount;
            }
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setAcodeAccount(String acodeAccount) {
            this.acodeAccount = acodeAccount;
        }

        public void setCsdcClientName(String csdcClientName) {
            this.csdcClientName = csdcClientName;
        }

        public void setCsdcIdKind(String csdcIdKind) {
            this.csdcIdKind = csdcIdKind;
        }

        public void setCsdcIdNo(String csdcIdNo) {
            this.csdcIdNo = csdcIdNo;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public void setCsdcHolderKind(String csdcHolderKind) {
            this.csdcHolderKind = csdcHolderKind;
        }

        public void setStockAccount(String stockAccount) {
            this.stockAccount = stockAccount;
        }

        public void setEnStockAccount(String enStockAccount) {
            this.enStockAccount = enStockAccount;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetDataswapHolderQueryInnerInput:(");
            buffer.append("opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",acodeAccount:" + this.acodeAccount);
            buffer.append(",csdcClientName:" + this.csdcClientName);
            buffer.append(",csdcIdKind:" + this.csdcIdKind);
            buffer.append(",csdcIdNo:" + this.csdcIdNo);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(",csdcHolderKind:" + this.csdcHolderKind);
            buffer.append(",stockAccount:" + this.stockAccount);
            buffer.append(",enStockAccount:" + this.enStockAccount);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.clientId);
            builder.append(this.fundAccount);
            builder.append(this.acodeAccount);
            builder.append(this.csdcClientName);
            builder.append(this.csdcIdKind);
            builder.append(this.csdcIdNo);
            builder.append(this.exchangeType);
            builder.append(this.csdcHolderKind);
            builder.append(this.stockAccount);
            builder.append(this.enStockAccount);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBcpService.GetDataswapHolderQueryInnerInput) {
                InnerBcpService.GetDataswapHolderQueryInnerInput test = (InnerBcpService.GetDataswapHolderQueryInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.clientId, test.clientId);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.acodeAccount, test.acodeAccount);
                builder.append(this.csdcClientName, test.csdcClientName);
                builder.append(this.csdcIdKind, test.csdcIdKind);
                builder.append(this.csdcIdNo, test.csdcIdNo);
                builder.append(this.exchangeType, test.exchangeType);
                builder.append(this.csdcHolderKind, test.csdcHolderKind);
                builder.append(this.stockAccount, test.stockAccount);
                builder.append(this.enStockAccount, test.enStockAccount);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetDataswapFirstDayQueryInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String resultCode = " ";
        private String dealInfo = " ";
        private String csdcClientName = " ";
        private String csdcIdKind = " ";
        private String csdcIdNo = " ";
        private String csdcAcodeAccount = " ";
        private String csdcHolderKind = " ";
        private String csdcStockAccount = " ";
        private String csdcHolderStatus = " ";
        private Integer csdcFirstTradeDate = 0;

        public GetDataswapFirstDayQueryInnerOutput() {
        }

        public String getResultCode() {
            if (this.resultCode == null) {
                return " ";
            } else {
                return this.resultCode.isEmpty() ? " " : this.resultCode;
            }
        }

        public String getDealInfo() {
            if (this.dealInfo == null) {
                return " ";
            } else {
                return this.dealInfo.isEmpty() ? " " : this.dealInfo;
            }
        }

        public String getCsdcClientName() {
            if (this.csdcClientName == null) {
                return " ";
            } else {
                return this.csdcClientName.isEmpty() ? " " : this.csdcClientName;
            }
        }

        public String getCsdcIdKind() {
            if (this.csdcIdKind == null) {
                return " ";
            } else {
                return this.csdcIdKind.isEmpty() ? " " : this.csdcIdKind;
            }
        }

        public String getCsdcIdNo() {
            if (this.csdcIdNo == null) {
                return " ";
            } else {
                return this.csdcIdNo.isEmpty() ? " " : this.csdcIdNo;
            }
        }

        public String getCsdcAcodeAccount() {
            if (this.csdcAcodeAccount == null) {
                return " ";
            } else {
                return this.csdcAcodeAccount.isEmpty() ? " " : this.csdcAcodeAccount;
            }
        }

        public String getCsdcHolderKind() {
            if (this.csdcHolderKind == null) {
                return " ";
            } else {
                return this.csdcHolderKind.isEmpty() ? " " : this.csdcHolderKind;
            }
        }

        public String getCsdcStockAccount() {
            if (this.csdcStockAccount == null) {
                return " ";
            } else {
                return this.csdcStockAccount.isEmpty() ? " " : this.csdcStockAccount;
            }
        }

        public String getCsdcHolderStatus() {
            if (this.csdcHolderStatus == null) {
                return " ";
            } else {
                return this.csdcHolderStatus.isEmpty() ? " " : this.csdcHolderStatus;
            }
        }

        public Integer getCsdcFirstTradeDate() {
            return this.csdcFirstTradeDate != null ? this.csdcFirstTradeDate : 0;
        }

        public void setResultCode(String resultCode) {
            this.resultCode = resultCode;
        }

        public void setDealInfo(String dealInfo) {
            this.dealInfo = dealInfo;
        }

        public void setCsdcClientName(String csdcClientName) {
            this.csdcClientName = csdcClientName;
        }

        public void setCsdcIdKind(String csdcIdKind) {
            this.csdcIdKind = csdcIdKind;
        }

        public void setCsdcIdNo(String csdcIdNo) {
            this.csdcIdNo = csdcIdNo;
        }

        public void setCsdcAcodeAccount(String csdcAcodeAccount) {
            this.csdcAcodeAccount = csdcAcodeAccount;
        }

        public void setCsdcHolderKind(String csdcHolderKind) {
            this.csdcHolderKind = csdcHolderKind;
        }

        public void setCsdcStockAccount(String csdcStockAccount) {
            this.csdcStockAccount = csdcStockAccount;
        }

        public void setCsdcHolderStatus(String csdcHolderStatus) {
            this.csdcHolderStatus = csdcHolderStatus;
        }

        public void setCsdcFirstTradeDate(Integer csdcFirstTradeDate) {
            this.csdcFirstTradeDate = csdcFirstTradeDate;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetDataswapFirstDayQueryInnerOutput:(");
            buffer.append("resultCode:" + this.resultCode);
            buffer.append(",dealInfo:" + this.dealInfo);
            buffer.append(",csdcClientName:" + this.csdcClientName);
            buffer.append(",csdcIdKind:" + this.csdcIdKind);
            buffer.append(",csdcIdNo:" + this.csdcIdNo);
            buffer.append(",csdcAcodeAccount:" + this.csdcAcodeAccount);
            buffer.append(",csdcHolderKind:" + this.csdcHolderKind);
            buffer.append(",csdcStockAccount:" + this.csdcStockAccount);
            buffer.append(",csdcHolderStatus:" + this.csdcHolderStatus);
            buffer.append(",csdcFirstTradeDate:" + this.csdcFirstTradeDate);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.resultCode);
            builder.append(this.dealInfo);
            builder.append(this.csdcClientName);
            builder.append(this.csdcIdKind);
            builder.append(this.csdcIdNo);
            builder.append(this.csdcAcodeAccount);
            builder.append(this.csdcHolderKind);
            builder.append(this.csdcStockAccount);
            builder.append(this.csdcHolderStatus);
            builder.append(this.csdcFirstTradeDate);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBcpService.GetDataswapFirstDayQueryInnerOutput) {
                InnerBcpService.GetDataswapFirstDayQueryInnerOutput test = (InnerBcpService.GetDataswapFirstDayQueryInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.resultCode, test.resultCode);
                builder.append(this.dealInfo, test.dealInfo);
                builder.append(this.csdcClientName, test.csdcClientName);
                builder.append(this.csdcIdKind, test.csdcIdKind);
                builder.append(this.csdcIdNo, test.csdcIdNo);
                builder.append(this.csdcAcodeAccount, test.csdcAcodeAccount);
                builder.append(this.csdcHolderKind, test.csdcHolderKind);
                builder.append(this.csdcStockAccount, test.csdcStockAccount);
                builder.append(this.csdcHolderStatus, test.csdcHolderStatus);
                builder.append(this.csdcFirstTradeDate, test.csdcFirstTradeDate);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetDataswapFirstDayQueryInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fundAccount = " ";
        @SinogramLength(
                min = 0,
                max = 180,
                charset = "utf-8"
        )
        private String fullName = " ";
        @SinogramLength(
                min = 0,
                max = 40,
                charset = "utf-8"
        )
        private String idNo = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character idKind = ' ';
        @SinogramLength(
                min = 0,
                max = 20,
                charset = "utf-8"
        )
        private String acodeAccount = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character holderKind = ' ';
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String exchangeType = " ";
        @SinogramLength(
                min = 0,
                max = 20,
                charset = "utf-8"
        )
        private String stockAccount = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character queryMode = ' ';

        public GetDataswapFirstDayQueryInnerInput() {
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getClientId() {
            return this.clientId;
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getFullName() {
            if (this.fullName == null) {
                return " ";
            } else {
                return this.fullName.isEmpty() ? " " : this.fullName;
            }
        }

        public String getIdNo() {
            if (this.idNo == null) {
                return " ";
            } else {
                return this.idNo.isEmpty() ? " " : this.idNo;
            }
        }

        public Character getIdKind() {
            return this.idKind != null ? this.idKind : ' ';
        }

        public String getAcodeAccount() {
            if (this.acodeAccount == null) {
                return " ";
            } else {
                return this.acodeAccount.isEmpty() ? " " : this.acodeAccount;
            }
        }

        public Character getHolderKind() {
            return this.holderKind != null ? this.holderKind : ' ';
        }

        public String getExchangeType() {
            if (this.exchangeType == null) {
                return " ";
            } else {
                return this.exchangeType.isEmpty() ? " " : this.exchangeType;
            }
        }

        public String getStockAccount() {
            if (this.stockAccount == null) {
                return " ";
            } else {
                return this.stockAccount.isEmpty() ? " " : this.stockAccount;
            }
        }

        public Character getQueryMode() {
            return this.queryMode != null ? this.queryMode : ' ';
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setFullName(String fullName) {
            this.fullName = fullName;
        }

        public void setIdNo(String idNo) {
            this.idNo = idNo;
        }

        public void setIdKind(Character idKind) {
            this.idKind = idKind;
        }

        public void setAcodeAccount(String acodeAccount) {
            this.acodeAccount = acodeAccount;
        }

        public void setHolderKind(Character holderKind) {
            this.holderKind = holderKind;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public void setStockAccount(String stockAccount) {
            this.stockAccount = stockAccount;
        }

        public void setQueryMode(Character queryMode) {
            this.queryMode = queryMode;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetDataswapFirstDayQueryInnerInput:(");
            buffer.append("opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",fullName:" + this.fullName);
            buffer.append(",idNo:" + this.idNo);
            buffer.append(",idKind:" + this.idKind);
            buffer.append(",acodeAccount:" + this.acodeAccount);
            buffer.append(",holderKind:" + this.holderKind);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(",stockAccount:" + this.stockAccount);
            buffer.append(",queryMode:" + this.queryMode);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.clientId);
            builder.append(this.fundAccount);
            builder.append(this.fullName);
            builder.append(this.idNo);
            builder.append(this.idKind);
            builder.append(this.acodeAccount);
            builder.append(this.holderKind);
            builder.append(this.exchangeType);
            builder.append(this.stockAccount);
            builder.append(this.queryMode);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBcpService.GetDataswapFirstDayQueryInnerInput) {
                InnerBcpService.GetDataswapFirstDayQueryInnerInput test = (InnerBcpService.GetDataswapFirstDayQueryInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.clientId, test.clientId);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.fullName, test.fullName);
                builder.append(this.idNo, test.idNo);
                builder.append(this.idKind, test.idKind);
                builder.append(this.acodeAccount, test.acodeAccount);
                builder.append(this.holderKind, test.holderKind);
                builder.append(this.exchangeType, test.exchangeType);
                builder.append(this.stockAccount, test.stockAccount);
                builder.append(this.queryMode, test.queryMode);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetDataswapAcodeQueryInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String csdcClientName = " ";
        private String csdcIdKind = " ";
        private String csdcIdNo = " ";
        private String csdcAcodeAccount = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character csdcAcodeStatus = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character csdcOpenType = ' ';
        private Integer csdcOpenDate = 0;
        private String csdcOpenorganName = " ";
        private Integer csdcCancelDate = 0;
        private String csdcCancelOrganName = " ";
        private String csdcOpenorganCode = " ";
        private String csdcOpennetCode = " ";
        private String resultCode = " ";

        public GetDataswapAcodeQueryInnerOutput() {
        }

        public String getCsdcClientName() {
            if (this.csdcClientName == null) {
                return " ";
            } else {
                return this.csdcClientName.isEmpty() ? " " : this.csdcClientName;
            }
        }

        public String getCsdcIdKind() {
            if (this.csdcIdKind == null) {
                return " ";
            } else {
                return this.csdcIdKind.isEmpty() ? " " : this.csdcIdKind;
            }
        }

        public String getCsdcIdNo() {
            if (this.csdcIdNo == null) {
                return " ";
            } else {
                return this.csdcIdNo.isEmpty() ? " " : this.csdcIdNo;
            }
        }

        public String getCsdcAcodeAccount() {
            if (this.csdcAcodeAccount == null) {
                return " ";
            } else {
                return this.csdcAcodeAccount.isEmpty() ? " " : this.csdcAcodeAccount;
            }
        }

        public Character getCsdcAcodeStatus() {
            return this.csdcAcodeStatus != null ? this.csdcAcodeStatus : ' ';
        }

        public Character getCsdcOpenType() {
            return this.csdcOpenType != null ? this.csdcOpenType : ' ';
        }

        public Integer getCsdcOpenDate() {
            return this.csdcOpenDate != null ? this.csdcOpenDate : 0;
        }

        public String getCsdcOpenorganName() {
            if (this.csdcOpenorganName == null) {
                return " ";
            } else {
                return this.csdcOpenorganName.isEmpty() ? " " : this.csdcOpenorganName;
            }
        }

        public Integer getCsdcCancelDate() {
            return this.csdcCancelDate != null ? this.csdcCancelDate : 0;
        }

        public String getCsdcCancelOrganName() {
            if (this.csdcCancelOrganName == null) {
                return " ";
            } else {
                return this.csdcCancelOrganName.isEmpty() ? " " : this.csdcCancelOrganName;
            }
        }

        public String getCsdcOpenorganCode() {
            if (this.csdcOpenorganCode == null) {
                return " ";
            } else {
                return this.csdcOpenorganCode.isEmpty() ? " " : this.csdcOpenorganCode;
            }
        }

        public String getCsdcOpennetCode() {
            if (this.csdcOpennetCode == null) {
                return " ";
            } else {
                return this.csdcOpennetCode.isEmpty() ? " " : this.csdcOpennetCode;
            }
        }

        public String getResultCode() {
            if (this.resultCode == null) {
                return " ";
            } else {
                return this.resultCode.isEmpty() ? " " : this.resultCode;
            }
        }

        public void setCsdcClientName(String csdcClientName) {
            this.csdcClientName = csdcClientName;
        }

        public void setCsdcIdKind(String csdcIdKind) {
            this.csdcIdKind = csdcIdKind;
        }

        public void setCsdcIdNo(String csdcIdNo) {
            this.csdcIdNo = csdcIdNo;
        }

        public void setCsdcAcodeAccount(String csdcAcodeAccount) {
            this.csdcAcodeAccount = csdcAcodeAccount;
        }

        public void setCsdcAcodeStatus(Character csdcAcodeStatus) {
            this.csdcAcodeStatus = csdcAcodeStatus;
        }

        public void setCsdcOpenType(Character csdcOpenType) {
            this.csdcOpenType = csdcOpenType;
        }

        public void setCsdcOpenDate(Integer csdcOpenDate) {
            this.csdcOpenDate = csdcOpenDate;
        }

        public void setCsdcOpenorganName(String csdcOpenorganName) {
            this.csdcOpenorganName = csdcOpenorganName;
        }

        public void setCsdcCancelDate(Integer csdcCancelDate) {
            this.csdcCancelDate = csdcCancelDate;
        }

        public void setCsdcCancelOrganName(String csdcCancelOrganName) {
            this.csdcCancelOrganName = csdcCancelOrganName;
        }

        public void setCsdcOpenorganCode(String csdcOpenorganCode) {
            this.csdcOpenorganCode = csdcOpenorganCode;
        }

        public void setCsdcOpennetCode(String csdcOpennetCode) {
            this.csdcOpennetCode = csdcOpennetCode;
        }

        public void setResultCode(String resultCode) {
            this.resultCode = resultCode;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetDataswapAcodeQueryInnerOutput:(");
            buffer.append("csdcClientName:" + this.csdcClientName);
            buffer.append(",csdcIdKind:" + this.csdcIdKind);
            buffer.append(",csdcIdNo:" + this.csdcIdNo);
            buffer.append(",csdcAcodeAccount:" + this.csdcAcodeAccount);
            buffer.append(",csdcAcodeStatus:" + this.csdcAcodeStatus);
            buffer.append(",csdcOpenType:" + this.csdcOpenType);
            buffer.append(",csdcOpenDate:" + this.csdcOpenDate);
            buffer.append(",csdcOpenorganName:" + this.csdcOpenorganName);
            buffer.append(",csdcCancelDate:" + this.csdcCancelDate);
            buffer.append(",csdcCancelOrganName:" + this.csdcCancelOrganName);
            buffer.append(",csdcOpenorganCode:" + this.csdcOpenorganCode);
            buffer.append(",csdcOpennetCode:" + this.csdcOpennetCode);
            buffer.append(",resultCode:" + this.resultCode);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.csdcClientName);
            builder.append(this.csdcIdKind);
            builder.append(this.csdcIdNo);
            builder.append(this.csdcAcodeAccount);
            builder.append(this.csdcAcodeStatus);
            builder.append(this.csdcOpenType);
            builder.append(this.csdcOpenDate);
            builder.append(this.csdcOpenorganName);
            builder.append(this.csdcCancelDate);
            builder.append(this.csdcCancelOrganName);
            builder.append(this.csdcOpenorganCode);
            builder.append(this.csdcOpennetCode);
            builder.append(this.resultCode);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBcpService.GetDataswapAcodeQueryInnerOutput) {
                InnerBcpService.GetDataswapAcodeQueryInnerOutput test = (InnerBcpService.GetDataswapAcodeQueryInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.csdcClientName, test.csdcClientName);
                builder.append(this.csdcIdKind, test.csdcIdKind);
                builder.append(this.csdcIdNo, test.csdcIdNo);
                builder.append(this.csdcAcodeAccount, test.csdcAcodeAccount);
                builder.append(this.csdcAcodeStatus, test.csdcAcodeStatus);
                builder.append(this.csdcOpenType, test.csdcOpenType);
                builder.append(this.csdcOpenDate, test.csdcOpenDate);
                builder.append(this.csdcOpenorganName, test.csdcOpenorganName);
                builder.append(this.csdcCancelDate, test.csdcCancelDate);
                builder.append(this.csdcCancelOrganName, test.csdcCancelOrganName);
                builder.append(this.csdcOpenorganCode, test.csdcOpenorganCode);
                builder.append(this.csdcOpennetCode, test.csdcOpennetCode);
                builder.append(this.resultCode, test.resultCode);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetDataswapAcodeQueryInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId;
        @SinogramLength(
                min = 0,
                max = 180,
                charset = "utf-8"
        )
        private String fullName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character idKind = ' ';
        @SinogramLength(
                min = 0,
                max = 40,
                charset = "utf-8"
        )
        private String idNo = " ";

        public GetDataswapAcodeQueryInnerInput() {
        }

        public String getClientId() {
            return this.clientId;
        }

        public String getFullName() {
            if (this.fullName == null) {
                return " ";
            } else {
                return this.fullName.isEmpty() ? " " : this.fullName;
            }
        }

        public Character getIdKind() {
            return this.idKind != null ? this.idKind : ' ';
        }

        public String getIdNo() {
            if (this.idNo == null) {
                return " ";
            } else {
                return this.idNo.isEmpty() ? " " : this.idNo;
            }
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setFullName(String fullName) {
            this.fullName = fullName;
        }

        public void setIdKind(Character idKind) {
            this.idKind = idKind;
        }

        public void setIdNo(String idNo) {
            this.idNo = idNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetDataswapAcodeQueryInnerInput:(");
            buffer.append("clientId:" + this.clientId);
            buffer.append(",fullName:" + this.fullName);
            buffer.append(",idKind:" + this.idKind);
            buffer.append(",idNo:" + this.idNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.clientId);
            builder.append(this.fullName);
            builder.append(this.idKind);
            builder.append(this.idNo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBcpService.GetDataswapAcodeQueryInnerInput) {
                InnerBcpService.GetDataswapAcodeQueryInnerInput test = (InnerBcpService.GetDataswapAcodeQueryInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.clientId, test.clientId);
                builder.append(this.fullName, test.fullName);
                builder.append(this.idKind, test.idKind);
                builder.append(this.idNo, test.idNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }
}
