//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.hundsun.broker.adapter.cms.pub.service;

import com.hundsun.broker.base.mq.MessageInfo;
import com.hundsun.jrescloud.rpc.annotation.CloudFunction;
import com.hundsun.jrescloud.rpc.annotation.CloudService;
import java.io.Serializable;
import java.util.List;
import java.util.Map;
import javax.validation.constraints.NotNull;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

@CloudService(
        validation = true,
        validationNull = false,
        application = "hsbroker.adapter.cms"
)
public interface InnerCmsActService {
    @CloudFunction(
            value = "adapter.cms.postRefreshData",
            apiUrl = "/adapter/cms/postRefreshData"
    )
    Boolean postRefreshData(MessageInfo<Map<String, Object>> var1);

    @CloudFunction(
            value = "adapter.cms.postOmcData",
            apiUrl = "/adapter/cms/postOmcData"
    )
    Boolean postOmcData(Map<String, Object> var1);

    @CloudFunction(
            value = "adapter.cms.getBankJourInner",
            apiUrl = "/adapter/cms/getBankJourInner"
    )
    List<InnerCmsActService.GetBankJourInnerOutput> getBankJourInner(InnerCmsActService.GetBankJourInnerInput var1);

    @CloudFunction(
            value = "adapter.cms.getAverageDailyAssetInner",
            apiUrl = "/adapter/cms/getAverageDailyAssetInner"
    )
    List<InnerCmsActService.GetAverageDailyAssetOutput> getAverageDailyAssetInner(InnerCmsActService.GetAverageDailyAssetInput var1);

    @CloudFunction(
            value = "adapter.cms.getBankAcctInfoInner",
            apiUrl = "/adapter/cms/getBankAcctInfoInner"
    )
    List<InnerCmsActService.GetBankAcctInfoOutput> getBankAcctInfoInner(InnerCmsActService.GetBankAcctInfoInput var1);

    public static class GetBankAcctInfoOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String bankNo;
        private String bankAccStatus;
        private String bankAcctType;

        public GetBankAcctInfoOutput() {
        }

        public String getBankNo() {
            return this.bankNo;
        }

        public String getBankAccStatus() {
            return this.bankAccStatus;
        }

        public String getBankAcctType() {
            return this.bankAcctType;
        }

        public void setBankNo(String bankNo) {
            this.bankNo = bankNo;
        }

        public void setBankAccStatus(String bankAccStatus) {
            this.bankAccStatus = bankAccStatus;
        }

        public void setBankAcctType(String bankAcctType) {
            this.bankAcctType = bankAcctType;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetBankAcctInfoOutput:(");
            buffer.append("bankNo:" + this.bankNo);
            buffer.append(",bankAccStatus:" + this.bankAccStatus);
            buffer.append(",bankAcctType:" + this.bankAcctType);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.bankNo);
            builder.append(this.bankAccStatus);
            builder.append(this.bankAcctType);
            return builder.toHashCode();
        }

        public boolean equals(InnerCmsActService.GetBankAcctInfoOutput obj) {
            if (obj instanceof InnerCmsActService.GetBankAcctInfoOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.bankNo, obj.bankNo);
                builder.append(this.bankAccStatus, obj.bankAccStatus);
                builder.append(this.bankAcctType, obj.bankAcctType);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetBankAcctInfoInput implements Serializable {
        private static final long serialVersionUID = 1L;
        @NotNull(
                message = "不能为空"
        )
        private String fundAccount;
        private String bankCode;
        private String moneyType;
        private String queryMode;
        private String branchCode;
        private String empCode;
        private String networkNo;

        public GetBankAcctInfoInput() {
        }

        public String getFundAccount() {
            return this.fundAccount;
        }

        public String getBankCode() {
            return this.bankCode;
        }

        public String getMoneyType() {
            return this.moneyType;
        }

        public String getQueryMode() {
            return this.queryMode;
        }

        public String getBranchCode() {
            return this.branchCode;
        }

        public String getEmpCode() {
            return this.empCode;
        }

        public String getNetworkNo() {
            return this.networkNo;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setBankCode(String bankCode) {
            this.bankCode = bankCode;
        }

        public void setMoneyType(String moneyType) {
            this.moneyType = moneyType;
        }

        public void setQueryMode(String queryMode) {
            this.queryMode = queryMode;
        }

        public void setBranchCode(String branchCode) {
            this.branchCode = branchCode;
        }

        public void setEmpCode(String empCode) {
            this.empCode = empCode;
        }

        public void setNetworkNo(String networkNo) {
            this.networkNo = networkNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetBankAcctInfoInput:(");
            buffer.append("fundAccount:" + this.fundAccount);
            buffer.append(",bankCode:" + this.bankCode);
            buffer.append(",moneyType:" + this.moneyType);
            buffer.append(",queryMode:" + this.queryMode);
            buffer.append(",branchCode:" + this.branchCode);
            buffer.append(",empCode:" + this.empCode);
            buffer.append(",networkNo:" + this.networkNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.fundAccount);
            builder.append(this.bankCode);
            builder.append(this.moneyType);
            builder.append(this.queryMode);
            builder.append(this.branchCode);
            builder.append(this.empCode);
            builder.append(this.networkNo);
            return builder.toHashCode();
        }

        public boolean equals(InnerCmsActService.GetBankAcctInfoInput obj) {
            if (obj instanceof InnerCmsActService.GetBankAcctInfoInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.fundAccount, obj.fundAccount);
                builder.append(this.bankCode, obj.bankCode);
                builder.append(this.moneyType, obj.moneyType);
                builder.append(this.queryMode, obj.queryMode);
                builder.append(this.branchCode, obj.branchCode);
                builder.append(this.empCode, obj.empCode);
                builder.append(this.networkNo, obj.networkNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetAverageDailyAssetOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Double tenDaysAveAsset;
        private Double twentyDaysAveAsset;
        private Integer updateDate;
        private Double optTwentyDaysAveAsset;
        private Double starTwentyDaysAveAsset;
        private Integer satisfyDays;
        private Double trustAsset;
        private Integer morethen50wFlag;
        private Integer satisfyDays2;
        private Integer upTestFlag;
        private Double t1StarAsset;

        public GetAverageDailyAssetOutput() {
        }

        public Double getTenDaysAveAsset() {
            return this.tenDaysAveAsset;
        }

        public Double getTwentyDaysAveAsset() {
            return this.twentyDaysAveAsset;
        }

        public Integer getUpdateDate() {
            return this.updateDate;
        }

        public Double getOptTwentyDaysAveAsset() {
            return this.optTwentyDaysAveAsset;
        }

        public Double getStarTwentyDaysAveAsset() {
            return this.starTwentyDaysAveAsset;
        }

        public Integer getSatisfyDays() {
            return this.satisfyDays;
        }

        public Double getTrustAsset() {
            return this.trustAsset;
        }

        public Integer getMorethen50wFlag() {
            return this.morethen50wFlag;
        }

        public Integer getSatisfyDays2() {
            return this.satisfyDays2;
        }

        public Integer getUpTestFlag() {
            return this.upTestFlag;
        }

        public Double getT1StarAsset() {
            return this.t1StarAsset;
        }

        public void setTenDaysAveAsset(Double tenDaysAveAsset) {
            this.tenDaysAveAsset = tenDaysAveAsset;
        }

        public void setTwentyDaysAveAsset(Double twentyDaysAveAsset) {
            this.twentyDaysAveAsset = twentyDaysAveAsset;
        }

        public void setUpdateDate(Integer updateDate) {
            this.updateDate = updateDate;
        }

        public void setOptTwentyDaysAveAsset(Double optTwentyDaysAveAsset) {
            this.optTwentyDaysAveAsset = optTwentyDaysAveAsset;
        }

        public void setStarTwentyDaysAveAsset(Double starTwentyDaysAveAsset) {
            this.starTwentyDaysAveAsset = starTwentyDaysAveAsset;
        }

        public void setSatisfyDays(Integer satisfyDays) {
            this.satisfyDays = satisfyDays;
        }

        public void setTrustAsset(Double trustAsset) {
            this.trustAsset = trustAsset;
        }

        public void setMorethen50wFlag(Integer morethen50wFlag) {
            this.morethen50wFlag = morethen50wFlag;
        }

        public void setSatisfyDays2(Integer satisfyDays2) {
            this.satisfyDays2 = satisfyDays2;
        }

        public void setUpTestFlag(Integer upTestFlag) {
            this.upTestFlag = upTestFlag;
        }

        public void setT1StarAsset(Double t1StarAsset) {
            this.t1StarAsset = t1StarAsset;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetAverageDailyAssetOutput:(");
            buffer.append("tenDaysAveAsset:" + this.tenDaysAveAsset);
            buffer.append(",twentyDaysAveAsset:" + this.twentyDaysAveAsset);
            buffer.append(",updateDate:" + this.updateDate);
            buffer.append(",optTwentyDaysAveAsset:" + this.optTwentyDaysAveAsset);
            buffer.append(",starTwentyDaysAveAsset:" + this.starTwentyDaysAveAsset);
            buffer.append(",satisfyDays:" + this.satisfyDays);
            buffer.append(",trustAsset:" + this.trustAsset);
            buffer.append(",morethen50wFlag:" + this.morethen50wFlag);
            buffer.append(",satisfyDays2:" + this.satisfyDays2);
            buffer.append(",upTestFlag:" + this.upTestFlag);
            buffer.append(",t1StarAsset:" + this.t1StarAsset);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.tenDaysAveAsset);
            builder.append(this.twentyDaysAveAsset);
            builder.append(this.updateDate);
            builder.append(this.optTwentyDaysAveAsset);
            builder.append(this.starTwentyDaysAveAsset);
            builder.append(this.satisfyDays);
            builder.append(this.trustAsset);
            builder.append(this.morethen50wFlag);
            builder.append(this.satisfyDays2);
            builder.append(this.upTestFlag);
            builder.append(this.t1StarAsset);
            return builder.toHashCode();
        }

        public boolean equals(InnerCmsActService.GetAverageDailyAssetOutput obj) {
            if (obj instanceof InnerCmsActService.GetAverageDailyAssetOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.tenDaysAveAsset, obj.tenDaysAveAsset);
                builder.append(this.twentyDaysAveAsset, obj.twentyDaysAveAsset);
                builder.append(this.updateDate, obj.updateDate);
                builder.append(this.optTwentyDaysAveAsset, obj.optTwentyDaysAveAsset);
                builder.append(this.starTwentyDaysAveAsset, obj.starTwentyDaysAveAsset);
                builder.append(this.satisfyDays, obj.satisfyDays);
                builder.append(this.trustAsset, obj.trustAsset);
                builder.append(this.morethen50wFlag, obj.morethen50wFlag);
                builder.append(this.satisfyDays2, obj.satisfyDays2);
                builder.append(this.upTestFlag, obj.upTestFlag);
                builder.append(this.t1StarAsset, obj.t1StarAsset);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetAverageDailyAssetInput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer occurBranhcNo;
        private Integer branchNo;
        private String networkAddress;
        @NotNull(
                message = "不能为空"
        )
        private String fundAccount;
        private Integer averageDays;

        public GetAverageDailyAssetInput() {
        }

        public Integer getOccurBranhcNo() {
            return this.occurBranhcNo;
        }

        public Integer getBranchNo() {
            return this.branchNo;
        }

        public String getNetworkAddress() {
            return this.networkAddress;
        }

        public String getFundAccount() {
            return this.fundAccount;
        }

        public Integer getAverageDays() {
            return this.averageDays;
        }

        public void setOccurBranhcNo(Integer occurBranhcNo) {
            this.occurBranhcNo = occurBranhcNo;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setNetworkAddress(String networkAddress) {
            this.networkAddress = networkAddress;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setAverageDays(Integer averageDays) {
            this.averageDays = averageDays;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetAverageDailyAssetInput:(");
            buffer.append("occurBranhcNo:" + this.occurBranhcNo);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",networkAddress:" + this.networkAddress);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",averageDays:" + this.averageDays);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.occurBranhcNo);
            builder.append(this.branchNo);
            builder.append(this.networkAddress);
            builder.append(this.fundAccount);
            builder.append(this.averageDays);
            return builder.toHashCode();
        }

        public boolean equals(InnerCmsActService.GetAverageDailyAssetInput obj) {
            if (obj instanceof InnerCmsActService.GetAverageDailyAssetInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.occurBranhcNo, obj.occurBranhcNo);
                builder.append(this.branchNo, obj.branchNo);
                builder.append(this.networkAddress, obj.networkAddress);
                builder.append(this.fundAccount, obj.fundAccount);
                builder.append(this.averageDays, obj.averageDays);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetBankJourInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Double occurBalance = 0.0D;
        private Integer requestCode = 0;
        private Integer requestDate = 0;
        private Integer requestTime = 0;

        public GetBankJourInnerOutput() {
        }

        public Double getOccurBalance() {
            return this.occurBalance != null ? this.occurBalance : 0.0D;
        }

        public Integer getRequestCode() {
            return this.requestCode != null ? this.requestCode : 0;
        }

        public Integer getRequestDate() {
            return this.requestDate != null ? this.requestDate : 0;
        }

        public Integer getRequestTime() {
            return this.requestTime != null ? this.requestTime : 0;
        }

        public void setOccurBalance(Double occurBalance) {
            this.occurBalance = occurBalance;
        }

        public void setRequestCode(Integer requestCode) {
            this.requestCode = requestCode;
        }

        public void setRequestDate(Integer requestDate) {
            this.requestDate = requestDate;
        }

        public void setRequestTime(Integer requestTime) {
            this.requestTime = requestTime;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetBankJourInnerOutput:(");
            buffer.append("occurBalance:" + this.occurBalance);
            buffer.append(",requestCode:" + this.requestCode);
            buffer.append(",requestDate:" + this.requestDate);
            buffer.append(",requestTime:" + this.requestTime);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.occurBalance);
            builder.append(this.requestCode);
            builder.append(this.requestDate);
            builder.append(this.requestTime);
            return builder.toHashCode();
        }

        public boolean equals(InnerCmsActService.GetBankJourInnerOutput obj) {
            if (obj instanceof InnerCmsActService.GetBankJourInnerOutput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.occurBalance, obj.occurBalance);
                builder.append(this.requestCode, obj.requestCode);
                builder.append(this.requestDate, obj.requestDate);
                builder.append(this.requestTime, obj.requestTime);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetBankJourInnerInput implements Serializable {
        private static final long serialVersionUID = 1L;
        @NotNull(
                message = "不能为空"
        )
        private Integer branchNo;
        @NotNull(
                message = "不能为空"
        )
        private String opBranchNo;
        @NotNull(
                message = "不能为空"
        )
        private Integer beginDate;
        @NotNull(
                message = "不能为空"
        )
        private Integer endDate;
        @NotNull(
                message = "不能为空"
        )
        private String fundAccount;
        private String moneyType;
        private String bankNo;
        @NotNull(
                message = "不能为空"
        )
        private String queryMode;
        private String operatorNo;
        private String opStation;

        public GetBankJourInnerInput() {
        }

        public Integer getBranchNo() {
            return this.branchNo;
        }

        public String getOpBranchNo() {
            return this.opBranchNo;
        }

        public Integer getBeginDate() {
            return this.beginDate;
        }

        public Integer getEndDate() {
            return this.endDate;
        }

        public String getFundAccount() {
            return this.fundAccount;
        }

        public String getMoneyType() {
            return this.moneyType;
        }

        public String getBankNo() {
            return this.bankNo;
        }

        public String getQueryMode() {
            return this.queryMode;
        }

        public String getOperatorNo() {
            return this.operatorNo;
        }

        public String getOpStation() {
            return this.opStation;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setOpBranchNo(String opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setBeginDate(Integer beginDate) {
            this.beginDate = beginDate;
        }

        public void setEndDate(Integer endDate) {
            this.endDate = endDate;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setMoneyType(String moneyType) {
            this.moneyType = moneyType;
        }

        public void setBankNo(String bankNo) {
            this.bankNo = bankNo;
        }

        public void setQueryMode(String queryMode) {
            this.queryMode = queryMode;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetBankJourInnerInput:(");
            buffer.append("branchNo:" + this.branchNo);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",beginDate:" + this.beginDate);
            buffer.append(",endDate:" + this.endDate);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",moneyType:" + this.moneyType);
            buffer.append(",bankNo:" + this.bankNo);
            buffer.append(",queryMode:" + this.queryMode);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.branchNo);
            builder.append(this.opBranchNo);
            builder.append(this.beginDate);
            builder.append(this.endDate);
            builder.append(this.fundAccount);
            builder.append(this.moneyType);
            builder.append(this.bankNo);
            builder.append(this.queryMode);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            return builder.toHashCode();
        }

        public boolean equals(InnerCmsActService.GetBankJourInnerInput obj) {
            if (obj instanceof InnerCmsActService.GetBankJourInnerInput) {
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.branchNo, obj.branchNo);
                builder.append(this.opBranchNo, obj.opBranchNo);
                builder.append(this.beginDate, obj.beginDate);
                builder.append(this.endDate, obj.endDate);
                builder.append(this.fundAccount, obj.fundAccount);
                builder.append(this.moneyType, obj.moneyType);
                builder.append(this.bankNo, obj.bankNo);
                builder.append(this.queryMode, obj.queryMode);
                builder.append(this.operatorNo, obj.operatorNo);
                builder.append(this.opStation, obj.opStation);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }
}
