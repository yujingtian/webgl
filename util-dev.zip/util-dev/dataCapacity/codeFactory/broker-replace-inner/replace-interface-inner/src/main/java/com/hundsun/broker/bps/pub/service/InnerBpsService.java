//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.hundsun.broker.bps.pub.service;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.hundsun.broker.base.PublicChecker.PublicParams;
import com.hundsun.broker.base.databind.CharacterJsonDeserializer;
import com.hundsun.jrescloud.rpc.annotation.CloudFunction;
import com.hundsun.jrescloud.rpc.annotation.CloudService;
import com.hundsun.jrescloud.rpc.def.json.DoubleJsonDeserializer;
import com.hundsun.jrescloud.rpc.def.json.LongJsonDeserializer;
import com.hundsun.jrescloud.rpc.def.json.LongJsonSerializer;
import com.hundsun.jrescloud.rpc.def.json.SerializeDoubleDigit;
import com.hundsun.jrescloud.rpc.def.validation.SinogramLength;
import java.io.Serializable;
import java.util.List;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

@CloudService(
        validation = true,
        validationNull = false,
        application = "hsbroker.bps"
)
public interface InnerBpsService {

    @CloudFunction(
            value = "bps.deleteBpsClientPreOpenInner",
            apiUrl = "/deleteBpsClientPreOpenInner"
    )
    InnerBpsService.DeleteBpsClientPreOpenInnerOutput deleteBpsClientPreOpenInner(InnerBpsService.DeleteBpsClientPreOpenInnerInput var1);

    @CloudFunction(
            value = "bps.getBpsAcptBusindataInner",
            apiUrl = "/getBpsAcptBusindataInner"
    )
    InnerBpsService.GetBpsAcptBusindataInnerOutput getBpsAcptBusindataInner(InnerBpsService.GetBpsAcptBusindataInnerInput var1);

    @CloudFunction(
            value = "bps.getBpsAcptformInfoInner",
            apiUrl = "/getBpsAcptformInfoInner"
    )
    InnerBpsService.GetBpsAcptformInfoInnerOutput getBpsAcptformInfoInner(InnerBpsService.GetBpsAcptformInfoInnerInput var1);

    @CloudFunction(
            value = "bps.getBpsAcptformListInner",
            apiUrl = "/getBpsAcptformListInner"
    )
    List<InnerBpsService.GetBpsAcptformListInnerOutput> getBpsAcptformListInner(InnerBpsService.GetBpsAcptformListInnerInput var1);

    @CloudFunction(
            value = "bps.getBpsClientPreOpenInner",
            apiUrl = "/getBpsClientPreOpenInner"
    )
    InnerBpsService.GetBpsClientPreOpenInnerOutput getBpsClientPreOpenInner(InnerBpsService.GetBpsClientPreOpenInnerInput var1);

    @CloudFunction(
            value = "bps.postBpsAcptbusinSubmitInner",
            apiUrl = "/postBpsAcptbusinSubmitInner"
    )
    InnerBpsService.PostBpsAcptbusinSubmitInnerOutput postBpsAcptbusinSubmitInner(InnerBpsService.PostBpsAcptbusinSubmitInnerInput var1);

    @CloudFunction(
            value = "bps.postBpsAcptformByOnceInner",
            apiUrl = "/postBpsAcptformByOnceInner"
    )
    InnerBpsService.PostBpsAcptformByOnceInnerOutput postBpsAcptformByOnceInner(InnerBpsService.PostBpsAcptformByOnceInnerInput var1);

    @CloudFunction(
            value = "bps.postBpsAcptformRegistInner",
            apiUrl = "/postBpsAcptformRegistInner"
    )
    InnerBpsService.PostBpsAcptformRegistInnerOutput postBpsAcptformRegistInner(InnerBpsService.PostBpsAcptformRegistInnerInput var1);

    @CloudFunction(
            value = "bps.postBpsClientPreOpenInner",
            apiUrl = "/postBpsClientPreOpenInner"
    )
    InnerBpsService.PostBpsClientPreOpenInnerOutput postBpsClientPreOpenInner(InnerBpsService.PostBpsClientPreOpenInnerInput var1);


    public static class GetPatchTaskInfoInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String patchAcptId = " ";
        private String qcId = " ";
        private String acptId = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character patchType = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character patchStatus = ' ';
        private String patchFlagStr = " ";
        private String patchReason = " ";
        private String patchContent = " ";
        private String operatorNo = " ";
        private String operatorName = " ";
        private Integer patchBranchNo = 0;
        private String patchOperatorNo = " ";
        private String patchOperatorName = " ";
        private Integer createDate = 0;
        private Integer createTime = 0;
        private Integer dealDate = 0;
        private Integer dealTime = 0;
        private String remark = " ";
        private Integer dateClear = 0;
        private String positionStr = " ";

        public GetPatchTaskInfoInnerOutput() {
        }

        public String getPatchAcptId() {
            if (this.patchAcptId == null) {
                return " ";
            } else {
                return this.patchAcptId.isEmpty() ? " " : this.patchAcptId;
            }
        }

        public String getQcId() {
            if (this.qcId == null) {
                return " ";
            } else {
                return this.qcId.isEmpty() ? " " : this.qcId;
            }
        }

        public String getAcptId() {
            if (this.acptId == null) {
                return " ";
            } else {
                return this.acptId.isEmpty() ? " " : this.acptId;
            }
        }

        public Character getPatchType() {
            return this.patchType != null ? this.patchType : ' ';
        }

        public Character getPatchStatus() {
            return this.patchStatus != null ? this.patchStatus : ' ';
        }

        public String getPatchFlagStr() {
            if (this.patchFlagStr == null) {
                return " ";
            } else {
                return this.patchFlagStr.isEmpty() ? " " : this.patchFlagStr;
            }
        }

        public String getPatchReason() {
            if (this.patchReason == null) {
                return " ";
            } else {
                return this.patchReason.isEmpty() ? " " : this.patchReason;
            }
        }

        public String getPatchContent() {
            if (this.patchContent == null) {
                return " ";
            } else {
                return this.patchContent.isEmpty() ? " " : this.patchContent;
            }
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOperatorName() {
            if (this.operatorName == null) {
                return " ";
            } else {
                return this.operatorName.isEmpty() ? " " : this.operatorName;
            }
        }

        public Integer getPatchBranchNo() {
            return this.patchBranchNo != null ? this.patchBranchNo : 0;
        }

        public String getPatchOperatorNo() {
            if (this.patchOperatorNo == null) {
                return " ";
            } else {
                return this.patchOperatorNo.isEmpty() ? " " : this.patchOperatorNo;
            }
        }

        public String getPatchOperatorName() {
            if (this.patchOperatorName == null) {
                return " ";
            } else {
                return this.patchOperatorName.isEmpty() ? " " : this.patchOperatorName;
            }
        }

        public Integer getCreateDate() {
            return this.createDate != null ? this.createDate : 0;
        }

        public Integer getCreateTime() {
            return this.createTime != null ? this.createTime : 0;
        }

        public Integer getDealDate() {
            return this.dealDate != null ? this.dealDate : 0;
        }

        public Integer getDealTime() {
            return this.dealTime != null ? this.dealTime : 0;
        }

        public String getRemark() {
            if (this.remark == null) {
                return " ";
            } else {
                return this.remark.isEmpty() ? " " : this.remark;
            }
        }

        public Integer getDateClear() {
            return this.dateClear != null ? this.dateClear : 0;
        }

        public String getPositionStr() {
            if (this.positionStr == null) {
                return " ";
            } else {
                return this.positionStr.isEmpty() ? " " : this.positionStr;
            }
        }

        public void setPatchAcptId(String patchAcptId) {
            this.patchAcptId = patchAcptId;
        }

        public void setQcId(String qcId) {
            this.qcId = qcId;
        }

        public void setAcptId(String acptId) {
            this.acptId = acptId;
        }

        public void setPatchType(Character patchType) {
            this.patchType = patchType;
        }

        public void setPatchStatus(Character patchStatus) {
            this.patchStatus = patchStatus;
        }

        public void setPatchFlagStr(String patchFlagStr) {
            this.patchFlagStr = patchFlagStr;
        }

        public void setPatchReason(String patchReason) {
            this.patchReason = patchReason;
        }

        public void setPatchContent(String patchContent) {
            this.patchContent = patchContent;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOperatorName(String operatorName) {
            this.operatorName = operatorName;
        }

        public void setPatchBranchNo(Integer patchBranchNo) {
            this.patchBranchNo = patchBranchNo;
        }

        public void setPatchOperatorNo(String patchOperatorNo) {
            this.patchOperatorNo = patchOperatorNo;
        }

        public void setPatchOperatorName(String patchOperatorName) {
            this.patchOperatorName = patchOperatorName;
        }

        public void setCreateDate(Integer createDate) {
            this.createDate = createDate;
        }

        public void setCreateTime(Integer createTime) {
            this.createTime = createTime;
        }

        public void setDealDate(Integer dealDate) {
            this.dealDate = dealDate;
        }

        public void setDealTime(Integer dealTime) {
            this.dealTime = dealTime;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public void setDateClear(Integer dateClear) {
            this.dateClear = dateClear;
        }

        public void setPositionStr(String positionStr) {
            this.positionStr = positionStr;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetPatchTaskInfoInnerOutput:(");
            buffer.append("patchAcptId:" + this.patchAcptId);
            buffer.append(",qcId:" + this.qcId);
            buffer.append(",acptId:" + this.acptId);
            buffer.append(",patchType:" + this.patchType);
            buffer.append(",patchStatus:" + this.patchStatus);
            buffer.append(",patchFlagStr:" + this.patchFlagStr);
            buffer.append(",patchReason:" + this.patchReason);
            buffer.append(",patchContent:" + this.patchContent);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",operatorName:" + this.operatorName);
            buffer.append(",patchBranchNo:" + this.patchBranchNo);
            buffer.append(",patchOperatorNo:" + this.patchOperatorNo);
            buffer.append(",patchOperatorName:" + this.patchOperatorName);
            buffer.append(",createDate:" + this.createDate);
            buffer.append(",createTime:" + this.createTime);
            buffer.append(",dealDate:" + this.dealDate);
            buffer.append(",dealTime:" + this.dealTime);
            buffer.append(",remark:" + this.remark);
            buffer.append(",dateClear:" + this.dateClear);
            buffer.append(",positionStr:" + this.positionStr);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.patchAcptId);
            builder.append(this.qcId);
            builder.append(this.acptId);
            builder.append(this.patchType);
            builder.append(this.patchStatus);
            builder.append(this.patchFlagStr);
            builder.append(this.patchReason);
            builder.append(this.patchContent);
            builder.append(this.operatorNo);
            builder.append(this.operatorName);
            builder.append(this.patchBranchNo);
            builder.append(this.patchOperatorNo);
            builder.append(this.patchOperatorName);
            builder.append(this.createDate);
            builder.append(this.createTime);
            builder.append(this.dealDate);
            builder.append(this.dealTime);
            builder.append(this.remark);
            builder.append(this.dateClear);
            builder.append(this.positionStr);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.GetPatchTaskInfoInnerOutput) {
                InnerBpsService.GetPatchTaskInfoInnerOutput test = (InnerBpsService.GetPatchTaskInfoInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.patchAcptId, test.patchAcptId);
                builder.append(this.qcId, test.qcId);
                builder.append(this.acptId, test.acptId);
                builder.append(this.patchType, test.patchType);
                builder.append(this.patchStatus, test.patchStatus);
                builder.append(this.patchFlagStr, test.patchFlagStr);
                builder.append(this.patchReason, test.patchReason);
                builder.append(this.patchContent, test.patchContent);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.operatorName, test.operatorName);
                builder.append(this.patchBranchNo, test.patchBranchNo);
                builder.append(this.patchOperatorNo, test.patchOperatorNo);
                builder.append(this.patchOperatorName, test.patchOperatorName);
                builder.append(this.createDate, test.createDate);
                builder.append(this.createTime, test.createTime);
                builder.append(this.dealDate, test.dealDate);
                builder.append(this.dealTime, test.dealTime);
                builder.append(this.remark, test.remark);
                builder.append(this.dateClear, test.dateClear);
                builder.append(this.positionStr, test.positionStr);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetPatchTaskInfoInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 60,
                charset = "utf-8"
        )
        private String operatorName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character useType = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String menuCode = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String functionStr = " ";
        private Integer branchNo = 0;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 32,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String patchAcptId;

        public GetPatchTaskInfoInnerInput() {
        }

        public String getOperatorName() {
            if (this.operatorName == null) {
                return " ";
            } else {
                return this.operatorName.isEmpty() ? " " : this.operatorName;
            }
        }

        public Character getUseType() {
            return this.useType != null ? this.useType : ' ';
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getMenuCode() {
            if (this.menuCode == null) {
                return " ";
            } else {
                return this.menuCode.isEmpty() ? " " : this.menuCode;
            }
        }

        public String getFunctionStr() {
            if (this.functionStr == null) {
                return " ";
            } else {
                return this.functionStr.isEmpty() ? " " : this.functionStr;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getPatchAcptId() {
            return this.patchAcptId;
        }

        public void setOperatorName(String operatorName) {
            this.operatorName = operatorName;
        }

        public void setUseType(Character useType) {
            this.useType = useType;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setMenuCode(String menuCode) {
            this.menuCode = menuCode;
        }

        public void setFunctionStr(String functionStr) {
            this.functionStr = functionStr;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setPatchAcptId(String patchAcptId) {
            this.patchAcptId = patchAcptId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetPatchTaskInfoInnerInput:(");
            buffer.append("operatorName:" + this.operatorName);
            buffer.append(",useType:" + this.useType);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",menuCode:" + this.menuCode);
            buffer.append(",functionStr:" + this.functionStr);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",patchAcptId:" + this.patchAcptId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.operatorName);
            builder.append(this.useType);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.menuCode);
            builder.append(this.functionStr);
            builder.append(this.branchNo);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.patchAcptId);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.GetPatchTaskInfoInnerInput) {
                InnerBpsService.GetPatchTaskInfoInnerInput test = (InnerBpsService.GetPatchTaskInfoInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.operatorName, test.operatorName);
                builder.append(this.useType, test.useType);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.menuCode, test.menuCode);
                builder.append(this.functionStr, test.functionStr);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.patchAcptId, test.patchAcptId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutAcptformRevokeInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Long serialNo = 0L;
        private String opRemark = " ";

        public PutAcptformRevokeInnerOutput() {
        }

        public Long getSerialNo() {
            return this.serialNo != null ? this.serialNo : 0L;
        }

        public String getOpRemark() {
            if (this.opRemark == null) {
                return " ";
            } else {
                return this.opRemark.isEmpty() ? " " : this.opRemark;
            }
        }

        public void setSerialNo(Long serialNo) {
            this.serialNo = serialNo;
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutAcptformRevokeInnerOutput:(");
            buffer.append("serialNo:" + this.serialNo);
            buffer.append(",opRemark:" + this.opRemark);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.serialNo);
            builder.append(this.opRemark);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.PutAcptformRevokeInnerOutput) {
                InnerBpsService.PutAcptformRevokeInnerOutput test = (InnerBpsService.PutAcptformRevokeInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.serialNo, test.serialNo);
                builder.append(this.opRemark, test.opRemark);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutAcptformRevokeInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 60,
                charset = "utf-8"
        )
        private String operatorName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character useType = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String menuCode = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String functionStr = " ";
        private Integer branchNo = 0;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String acptId = " ";
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String dealInfo = " ";

        public PutAcptformRevokeInnerInput() {
        }

        public String getOperatorName() {
            if (this.operatorName == null) {
                return " ";
            } else {
                return this.operatorName.isEmpty() ? " " : this.operatorName;
            }
        }

        public Character getUseType() {
            return this.useType != null ? this.useType : ' ';
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getMenuCode() {
            if (this.menuCode == null) {
                return " ";
            } else {
                return this.menuCode.isEmpty() ? " " : this.menuCode;
            }
        }

        public String getFunctionStr() {
            if (this.functionStr == null) {
                return " ";
            } else {
                return this.functionStr.isEmpty() ? " " : this.functionStr;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getAcptId() {
            if (this.acptId == null) {
                return " ";
            } else {
                return this.acptId.isEmpty() ? " " : this.acptId;
            }
        }

        public String getDealInfo() {
            if (this.dealInfo == null) {
                return " ";
            } else {
                return this.dealInfo.isEmpty() ? " " : this.dealInfo;
            }
        }

        public void setOperatorName(String operatorName) {
            this.operatorName = operatorName;
        }

        public void setUseType(Character useType) {
            this.useType = useType;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setMenuCode(String menuCode) {
            this.menuCode = menuCode;
        }

        public void setFunctionStr(String functionStr) {
            this.functionStr = functionStr;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setAcptId(String acptId) {
            this.acptId = acptId;
        }

        public void setDealInfo(String dealInfo) {
            this.dealInfo = dealInfo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutAcptformRevokeInnerInput:(");
            buffer.append("operatorName:" + this.operatorName);
            buffer.append(",useType:" + this.useType);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",menuCode:" + this.menuCode);
            buffer.append(",functionStr:" + this.functionStr);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",acptId:" + this.acptId);
            buffer.append(",dealInfo:" + this.dealInfo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.operatorName);
            builder.append(this.useType);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.menuCode);
            builder.append(this.functionStr);
            builder.append(this.branchNo);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.acptId);
            builder.append(this.dealInfo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.PutAcptformRevokeInnerInput) {
                InnerBpsService.PutAcptformRevokeInnerInput test = (InnerBpsService.PutAcptformRevokeInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.operatorName, test.operatorName);
                builder.append(this.useType, test.useType);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.menuCode, test.menuCode);
                builder.append(this.functionStr, test.functionStr);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.acptId, test.acptId);
                builder.append(this.dealInfo, test.dealInfo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetBpsRptAcptBusindataInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String functionData = " ";
        private String paramData = " ";

        public GetBpsRptAcptBusindataInnerOutput() {
        }

        public String getFunctionData() {
            if (this.functionData == null) {
                return " ";
            } else {
                return this.functionData.isEmpty() ? " " : this.functionData;
            }
        }

        public String getParamData() {
            if (this.paramData == null) {
                return " ";
            } else {
                return this.paramData.isEmpty() ? " " : this.paramData;
            }
        }

        public void setFunctionData(String functionData) {
            this.functionData = functionData;
        }

        public void setParamData(String paramData) {
            this.paramData = paramData;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetBpsRptAcptBusindataInnerOutput:(");
            buffer.append("functionData:" + this.functionData);
            buffer.append(",paramData:" + this.paramData);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.functionData);
            builder.append(this.paramData);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.GetBpsRptAcptBusindataInnerOutput) {
                InnerBpsService.GetBpsRptAcptBusindataInnerOutput test = (InnerBpsService.GetBpsRptAcptBusindataInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.functionData, test.functionData);
                builder.append(this.paramData, test.paramData);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetBpsRptAcptBusindataInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 60,
                charset = "utf-8"
        )
        private String operatorName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character useType = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String menuCode = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String functionStr = " ";
        private Integer branchNo = 0;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 32,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String acptId;

        public GetBpsRptAcptBusindataInnerInput() {
        }

        public String getOperatorName() {
            if (this.operatorName == null) {
                return " ";
            } else {
                return this.operatorName.isEmpty() ? " " : this.operatorName;
            }
        }

        public Character getUseType() {
            return this.useType != null ? this.useType : ' ';
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getMenuCode() {
            if (this.menuCode == null) {
                return " ";
            } else {
                return this.menuCode.isEmpty() ? " " : this.menuCode;
            }
        }

        public String getFunctionStr() {
            if (this.functionStr == null) {
                return " ";
            } else {
                return this.functionStr.isEmpty() ? " " : this.functionStr;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getAcptId() {
            return this.acptId;
        }

        public void setOperatorName(String operatorName) {
            this.operatorName = operatorName;
        }

        public void setUseType(Character useType) {
            this.useType = useType;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setMenuCode(String menuCode) {
            this.menuCode = menuCode;
        }

        public void setFunctionStr(String functionStr) {
            this.functionStr = functionStr;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setAcptId(String acptId) {
            this.acptId = acptId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetBpsRptAcptBusindataInnerInput:(");
            buffer.append("operatorName:" + this.operatorName);
            buffer.append(",useType:" + this.useType);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",menuCode:" + this.menuCode);
            buffer.append(",functionStr:" + this.functionStr);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",acptId:" + this.acptId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.operatorName);
            builder.append(this.useType);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.menuCode);
            builder.append(this.functionStr);
            builder.append(this.branchNo);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.acptId);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.GetBpsRptAcptBusindataInnerInput) {
                InnerBpsService.GetBpsRptAcptBusindataInnerInput test = (InnerBpsService.GetBpsRptAcptBusindataInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.operatorName, test.operatorName);
                builder.append(this.useType, test.useType);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.menuCode, test.menuCode);
                builder.append(this.functionStr, test.functionStr);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.acptId, test.acptId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetAcptFormInfoJourInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private List<InnerBpsService.AcptformjourDTO> rows;

        public GetAcptFormInfoJourInnerOutput() {
        }

        public List<InnerBpsService.AcptformjourDTO> getRows() {
            return this.rows;
        }

        public void setRows(List<InnerBpsService.AcptformjourDTO> rows) {
            this.rows = rows;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetAcptFormInfoJourInnerOutput:(");
            buffer.append("rows:" + this.rows);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.rows);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.GetAcptFormInfoJourInnerOutput) {
                InnerBpsService.GetAcptFormInfoJourInnerOutput test = (InnerBpsService.GetAcptFormInfoJourInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.rows, test.rows);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetAcptFormInfoJourInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 60,
                charset = "utf-8"
        )
        private String operatorName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character useType = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String menuCode = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String functionStr = " ";
        private Integer branchNo = 0;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 32,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String acptId;

        public GetAcptFormInfoJourInnerInput() {
        }

        public String getOperatorName() {
            if (this.operatorName == null) {
                return " ";
            } else {
                return this.operatorName.isEmpty() ? " " : this.operatorName;
            }
        }

        public Character getUseType() {
            return this.useType != null ? this.useType : ' ';
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getMenuCode() {
            if (this.menuCode == null) {
                return " ";
            } else {
                return this.menuCode.isEmpty() ? " " : this.menuCode;
            }
        }

        public String getFunctionStr() {
            if (this.functionStr == null) {
                return " ";
            } else {
                return this.functionStr.isEmpty() ? " " : this.functionStr;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getAcptId() {
            return this.acptId;
        }

        public void setOperatorName(String operatorName) {
            this.operatorName = operatorName;
        }

        public void setUseType(Character useType) {
            this.useType = useType;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setMenuCode(String menuCode) {
            this.menuCode = menuCode;
        }

        public void setFunctionStr(String functionStr) {
            this.functionStr = functionStr;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setAcptId(String acptId) {
            this.acptId = acptId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetAcptFormInfoJourInnerInput:(");
            buffer.append("operatorName:" + this.operatorName);
            buffer.append(",useType:" + this.useType);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",menuCode:" + this.menuCode);
            buffer.append(",functionStr:" + this.functionStr);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",acptId:" + this.acptId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.operatorName);
            builder.append(this.useType);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.menuCode);
            builder.append(this.functionStr);
            builder.append(this.branchNo);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.acptId);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.GetAcptFormInfoJourInnerInput) {
                InnerBpsService.GetAcptFormInfoJourInnerInput test = (InnerBpsService.GetAcptFormInfoJourInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.operatorName, test.operatorName);
                builder.append(this.useType, test.useType);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.menuCode, test.menuCode);
                builder.append(this.functionStr, test.functionStr);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.acptId, test.acptId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class AcptformjourDTO implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer initDate = 0;
        @JsonSerialize(
                using = LongJsonSerializer.class
        )
        @JsonDeserialize(
                using = LongJsonDeserializer.class
        )
        private Long serialNo = 0L;
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String acptId = " ";
        @SinogramLength(
                min = 0,
                max = 10,
                charset = "utf-8"
        )
        private String acptBusinId = " ";
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String acptBusinKind = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character acptFormStatus = ' ';
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String workflowOrderId = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fundAccount = " ";
        private Integer branchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String clientId = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        private Integer opBranchNo = 0;
        private Integer currDate = 0;
        private Integer currTime = 0;
        private Integer dateClear = 0;
        @SinogramLength(
                min = 0,
                max = 100,
                charset = "utf-8"
        )
        private String positionStr = " ";
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String remark = " ";
        private Integer errorNoInner = 0;
        @SinogramLength(
                min = 0,
                max = 500,
                charset = "utf-8"
        )
        private String errorInfoInner = " ";
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String opContent = " ";
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String dealInfo = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String rejectReason = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String rejectFlagStr = " ";
        @SinogramLength(
                min = 0,
                max = 180,
                charset = "utf-8"
        )
        private String fullName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character organFlag = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character idKind = ' ';
        @SinogramLength(
                min = 0,
                max = 40,
                charset = "utf-8"
        )
        private String idNo = " ";
        @SinogramLength(
                min = 0,
                max = 60,
                charset = "utf-8"
        )
        private String operatorName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character acptType = ' ';
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String custId = " ";
        private Integer count = 0;

        public AcptformjourDTO() {
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public Long getSerialNo() {
            return this.serialNo != null ? this.serialNo : 0L;
        }

        public String getAcptId() {
            if (this.acptId == null) {
                return " ";
            } else {
                return this.acptId.isEmpty() ? " " : this.acptId;
            }
        }

        public String getAcptBusinId() {
            if (this.acptBusinId == null) {
                return " ";
            } else {
                return this.acptBusinId.isEmpty() ? " " : this.acptBusinId;
            }
        }

        public String getAcptBusinKind() {
            if (this.acptBusinKind == null) {
                return " ";
            } else {
                return this.acptBusinKind.isEmpty() ? " " : this.acptBusinKind;
            }
        }

        public Character getAcptFormStatus() {
            return this.acptFormStatus != null ? this.acptFormStatus : ' ';
        }

        public String getWorkflowOrderId() {
            if (this.workflowOrderId == null) {
                return " ";
            } else {
                return this.workflowOrderId.isEmpty() ? " " : this.workflowOrderId;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public Integer getCurrDate() {
            return this.currDate != null ? this.currDate : 0;
        }

        public Integer getCurrTime() {
            return this.currTime != null ? this.currTime : 0;
        }

        public Integer getDateClear() {
            return this.dateClear != null ? this.dateClear : 0;
        }

        public String getPositionStr() {
            if (this.positionStr == null) {
                return " ";
            } else {
                return this.positionStr.isEmpty() ? " " : this.positionStr;
            }
        }

        public String getRemark() {
            if (this.remark == null) {
                return " ";
            } else {
                return this.remark.isEmpty() ? " " : this.remark;
            }
        }

        public Integer getErrorNoInner() {
            return this.errorNoInner != null ? this.errorNoInner : 0;
        }

        public String getErrorInfoInner() {
            if (this.errorInfoInner == null) {
                return " ";
            } else {
                return this.errorInfoInner.isEmpty() ? " " : this.errorInfoInner;
            }
        }

        public String getOpContent() {
            if (this.opContent == null) {
                return " ";
            } else {
                return this.opContent.isEmpty() ? " " : this.opContent;
            }
        }

        public String getDealInfo() {
            if (this.dealInfo == null) {
                return " ";
            } else {
                return this.dealInfo.isEmpty() ? " " : this.dealInfo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public String getRejectReason() {
            if (this.rejectReason == null) {
                return " ";
            } else {
                return this.rejectReason.isEmpty() ? " " : this.rejectReason;
            }
        }

        public String getRejectFlagStr() {
            if (this.rejectFlagStr == null) {
                return " ";
            } else {
                return this.rejectFlagStr.isEmpty() ? " " : this.rejectFlagStr;
            }
        }

        public String getFullName() {
            if (this.fullName == null) {
                return " ";
            } else {
                return this.fullName.isEmpty() ? " " : this.fullName;
            }
        }

        public Character getOrganFlag() {
            return this.organFlag != null ? this.organFlag : ' ';
        }

        public Character getIdKind() {
            return this.idKind != null ? this.idKind : ' ';
        }

        public String getIdNo() {
            if (this.idNo == null) {
                return " ";
            } else {
                return this.idNo.isEmpty() ? " " : this.idNo;
            }
        }

        public String getOperatorName() {
            if (this.operatorName == null) {
                return " ";
            } else {
                return this.operatorName.isEmpty() ? " " : this.operatorName;
            }
        }

        public Character getAcptType() {
            return this.acptType != null ? this.acptType : ' ';
        }

        public String getCustId() {
            if (this.custId == null) {
                return " ";
            } else {
                return this.custId.isEmpty() ? " " : this.custId;
            }
        }

        public Integer getCount() {
            return this.count != null ? this.count : 0;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public void setSerialNo(Long serialNo) {
            this.serialNo = serialNo;
        }

        public void setAcptId(String acptId) {
            this.acptId = acptId;
        }

        public void setAcptBusinId(String acptBusinId) {
            this.acptBusinId = acptBusinId;
        }

        public void setAcptBusinKind(String acptBusinKind) {
            this.acptBusinKind = acptBusinKind;
        }

        public void setAcptFormStatus(Character acptFormStatus) {
            this.acptFormStatus = acptFormStatus;
        }

        public void setWorkflowOrderId(String workflowOrderId) {
            this.workflowOrderId = workflowOrderId;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setCurrDate(Integer currDate) {
            this.currDate = currDate;
        }

        public void setCurrTime(Integer currTime) {
            this.currTime = currTime;
        }

        public void setDateClear(Integer dateClear) {
            this.dateClear = dateClear;
        }

        public void setPositionStr(String positionStr) {
            this.positionStr = positionStr;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public void setErrorNoInner(Integer errorNoInner) {
            this.errorNoInner = errorNoInner;
        }

        public void setErrorInfoInner(String errorInfoInner) {
            this.errorInfoInner = errorInfoInner;
        }

        public void setOpContent(String opContent) {
            this.opContent = opContent;
        }

        public void setDealInfo(String dealInfo) {
            this.dealInfo = dealInfo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setRejectReason(String rejectReason) {
            this.rejectReason = rejectReason;
        }

        public void setRejectFlagStr(String rejectFlagStr) {
            this.rejectFlagStr = rejectFlagStr;
        }

        public void setFullName(String fullName) {
            this.fullName = fullName;
        }

        public void setOrganFlag(Character organFlag) {
            this.organFlag = organFlag;
        }

        public void setIdKind(Character idKind) {
            this.idKind = idKind;
        }

        public void setIdNo(String idNo) {
            this.idNo = idNo;
        }

        public void setOperatorName(String operatorName) {
            this.operatorName = operatorName;
        }

        public void setAcptType(Character acptType) {
            this.acptType = acptType;
        }

        public void setCustId(String custId) {
            this.custId = custId;
        }

        public void setCount(Integer count) {
            this.count = count;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("AcptformjourDTO:(");
            buffer.append("initDate:" + this.initDate);
            buffer.append(",serialNo:" + this.serialNo);
            buffer.append(",acptId:" + this.acptId);
            buffer.append(",acptBusinId:" + this.acptBusinId);
            buffer.append(",acptBusinKind:" + this.acptBusinKind);
            buffer.append(",acptFormStatus:" + this.acptFormStatus);
            buffer.append(",workflowOrderId:" + this.workflowOrderId);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",currDate:" + this.currDate);
            buffer.append(",currTime:" + this.currTime);
            buffer.append(",dateClear:" + this.dateClear);
            buffer.append(",positionStr:" + this.positionStr);
            buffer.append(",remark:" + this.remark);
            buffer.append(",errorNoInner:" + this.errorNoInner);
            buffer.append(",errorInfoInner:" + this.errorInfoInner);
            buffer.append(",opContent:" + this.opContent);
            buffer.append(",dealInfo:" + this.dealInfo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",rejectReason:" + this.rejectReason);
            buffer.append(",rejectFlagStr:" + this.rejectFlagStr);
            buffer.append(",fullName:" + this.fullName);
            buffer.append(",organFlag:" + this.organFlag);
            buffer.append(",idKind:" + this.idKind);
            buffer.append(",idNo:" + this.idNo);
            buffer.append(",operatorName:" + this.operatorName);
            buffer.append(",acptType:" + this.acptType);
            buffer.append(",custId:" + this.custId);
            buffer.append(",count:" + this.count);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.initDate);
            builder.append(this.serialNo);
            builder.append(this.acptId);
            builder.append(this.acptBusinId);
            builder.append(this.acptBusinKind);
            builder.append(this.acptFormStatus);
            builder.append(this.workflowOrderId);
            builder.append(this.opEntrustWay);
            builder.append(this.fundAccount);
            builder.append(this.branchNo);
            builder.append(this.clientId);
            builder.append(this.operatorNo);
            builder.append(this.opBranchNo);
            builder.append(this.currDate);
            builder.append(this.currTime);
            builder.append(this.dateClear);
            builder.append(this.positionStr);
            builder.append(this.remark);
            builder.append(this.errorNoInner);
            builder.append(this.errorInfoInner);
            builder.append(this.opContent);
            builder.append(this.dealInfo);
            builder.append(this.opStation);
            builder.append(this.rejectReason);
            builder.append(this.rejectFlagStr);
            builder.append(this.fullName);
            builder.append(this.organFlag);
            builder.append(this.idKind);
            builder.append(this.idNo);
            builder.append(this.operatorName);
            builder.append(this.acptType);
            builder.append(this.custId);
            builder.append(this.count);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.AcptformjourDTO) {
                InnerBpsService.AcptformjourDTO test = (InnerBpsService.AcptformjourDTO)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.initDate, test.initDate);
                builder.append(this.serialNo, test.serialNo);
                builder.append(this.acptId, test.acptId);
                builder.append(this.acptBusinId, test.acptBusinId);
                builder.append(this.acptBusinKind, test.acptBusinKind);
                builder.append(this.acptFormStatus, test.acptFormStatus);
                builder.append(this.workflowOrderId, test.workflowOrderId);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.clientId, test.clientId);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.currDate, test.currDate);
                builder.append(this.currTime, test.currTime);
                builder.append(this.dateClear, test.dateClear);
                builder.append(this.positionStr, test.positionStr);
                builder.append(this.remark, test.remark);
                builder.append(this.errorNoInner, test.errorNoInner);
                builder.append(this.errorInfoInner, test.errorInfoInner);
                builder.append(this.opContent, test.opContent);
                builder.append(this.dealInfo, test.dealInfo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.rejectReason, test.rejectReason);
                builder.append(this.rejectFlagStr, test.rejectFlagStr);
                builder.append(this.fullName, test.fullName);
                builder.append(this.organFlag, test.organFlag);
                builder.append(this.idKind, test.idKind);
                builder.append(this.idNo, test.idNo);
                builder.append(this.operatorName, test.operatorName);
                builder.append(this.acptType, test.acptType);
                builder.append(this.custId, test.custId);
                builder.append(this.count, test.count);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutArchcachedataByAcptIdInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String opRemark = " ";

        public PutArchcachedataByAcptIdInnerOutput() {
        }

        public String getOpRemark() {
            if (this.opRemark == null) {
                return " ";
            } else {
                return this.opRemark.isEmpty() ? " " : this.opRemark;
            }
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutArchcachedataByAcptIdInnerOutput:(");
            buffer.append("opRemark:" + this.opRemark);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opRemark);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.PutArchcachedataByAcptIdInnerOutput) {
                InnerBpsService.PutArchcachedataByAcptIdInnerOutput test = (InnerBpsService.PutArchcachedataByAcptIdInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opRemark, test.opRemark);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutArchcachedataByAcptIdInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 60,
                charset = "utf-8"
        )
        private String operatorName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character useType = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String menuCode = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String functionStr = " ";
        private Integer branchNo = 0;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String acptId = " ";
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String acptBusinKind = " ";
        @SinogramLength(
                min = 0,
                max = 10,
                charset = "utf-8"
        )
        private String acptBusinId = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String custId = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character organFlag = ' ';
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fundAccount = " ";
        private Integer acptChannel = 0;

        public PutArchcachedataByAcptIdInnerInput() {
        }

        public String getOperatorName() {
            if (this.operatorName == null) {
                return " ";
            } else {
                return this.operatorName.isEmpty() ? " " : this.operatorName;
            }
        }

        public Character getUseType() {
            return this.useType != null ? this.useType : ' ';
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getMenuCode() {
            if (this.menuCode == null) {
                return " ";
            } else {
                return this.menuCode.isEmpty() ? " " : this.menuCode;
            }
        }

        public String getFunctionStr() {
            if (this.functionStr == null) {
                return " ";
            } else {
                return this.functionStr.isEmpty() ? " " : this.functionStr;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getAcptId() {
            if (this.acptId == null) {
                return " ";
            } else {
                return this.acptId.isEmpty() ? " " : this.acptId;
            }
        }

        public String getAcptBusinKind() {
            if (this.acptBusinKind == null) {
                return " ";
            } else {
                return this.acptBusinKind.isEmpty() ? " " : this.acptBusinKind;
            }
        }

        public String getAcptBusinId() {
            if (this.acptBusinId == null) {
                return " ";
            } else {
                return this.acptBusinId.isEmpty() ? " " : this.acptBusinId;
            }
        }

        public String getCustId() {
            if (this.custId == null) {
                return " ";
            } else {
                return this.custId.isEmpty() ? " " : this.custId;
            }
        }

        public Character getOrganFlag() {
            return this.organFlag != null ? this.organFlag : ' ';
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public Integer getAcptChannel() {
            return this.acptChannel != null ? this.acptChannel : 0;
        }

        public void setOperatorName(String operatorName) {
            this.operatorName = operatorName;
        }

        public void setUseType(Character useType) {
            this.useType = useType;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setMenuCode(String menuCode) {
            this.menuCode = menuCode;
        }

        public void setFunctionStr(String functionStr) {
            this.functionStr = functionStr;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setAcptId(String acptId) {
            this.acptId = acptId;
        }

        public void setAcptBusinKind(String acptBusinKind) {
            this.acptBusinKind = acptBusinKind;
        }

        public void setAcptBusinId(String acptBusinId) {
            this.acptBusinId = acptBusinId;
        }

        public void setCustId(String custId) {
            this.custId = custId;
        }

        public void setOrganFlag(Character organFlag) {
            this.organFlag = organFlag;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setAcptChannel(Integer acptChannel) {
            this.acptChannel = acptChannel;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutArchcachedataByAcptIdInnerInput:(");
            buffer.append("operatorName:" + this.operatorName);
            buffer.append(",useType:" + this.useType);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",menuCode:" + this.menuCode);
            buffer.append(",functionStr:" + this.functionStr);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",acptId:" + this.acptId);
            buffer.append(",acptBusinKind:" + this.acptBusinKind);
            buffer.append(",acptBusinId:" + this.acptBusinId);
            buffer.append(",custId:" + this.custId);
            buffer.append(",organFlag:" + this.organFlag);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",acptChannel:" + this.acptChannel);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.operatorName);
            builder.append(this.useType);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.menuCode);
            builder.append(this.functionStr);
            builder.append(this.branchNo);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.acptId);
            builder.append(this.acptBusinKind);
            builder.append(this.acptBusinId);
            builder.append(this.custId);
            builder.append(this.organFlag);
            builder.append(this.fundAccount);
            builder.append(this.acptChannel);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.PutArchcachedataByAcptIdInnerInput) {
                InnerBpsService.PutArchcachedataByAcptIdInnerInput test = (InnerBpsService.PutArchcachedataByAcptIdInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.operatorName, test.operatorName);
                builder.append(this.useType, test.useType);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.menuCode, test.menuCode);
                builder.append(this.functionStr, test.functionStr);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.acptId, test.acptId);
                builder.append(this.acptBusinKind, test.acptBusinKind);
                builder.append(this.acptBusinId, test.acptBusinId);
                builder.append(this.custId, test.custId);
                builder.append(this.organFlag, test.organFlag);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.acptChannel, test.acptChannel);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutOverdueAcptRevisitToHisInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String opRemark = " ";

        public PutOverdueAcptRevisitToHisInnerOutput() {
        }

        public String getOpRemark() {
            if (this.opRemark == null) {
                return " ";
            } else {
                return this.opRemark.isEmpty() ? " " : this.opRemark;
            }
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutOverdueAcptRevisitToHisInnerOutput:(");
            buffer.append("opRemark:" + this.opRemark);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opRemark);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.PutOverdueAcptRevisitToHisInnerOutput) {
                InnerBpsService.PutOverdueAcptRevisitToHisInnerOutput test = (InnerBpsService.PutOverdueAcptRevisitToHisInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opRemark, test.opRemark);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutOverdueAcptRevisitToHisInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 60,
                charset = "utf-8"
        )
        private String operatorName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character useType = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String menuCode = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String functionStr = " ";
        private Integer branchNo = 0;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @NotNull(
                message = "不能为空"
        )
        private Integer initDate;

        public PutOverdueAcptRevisitToHisInnerInput() {
        }

        public String getOperatorName() {
            if (this.operatorName == null) {
                return " ";
            } else {
                return this.operatorName.isEmpty() ? " " : this.operatorName;
            }
        }

        public Character getUseType() {
            return this.useType != null ? this.useType : ' ';
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getMenuCode() {
            if (this.menuCode == null) {
                return " ";
            } else {
                return this.menuCode.isEmpty() ? " " : this.menuCode;
            }
        }

        public String getFunctionStr() {
            if (this.functionStr == null) {
                return " ";
            } else {
                return this.functionStr.isEmpty() ? " " : this.functionStr;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public Integer getInitDate() {
            return this.initDate;
        }

        public void setOperatorName(String operatorName) {
            this.operatorName = operatorName;
        }

        public void setUseType(Character useType) {
            this.useType = useType;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setMenuCode(String menuCode) {
            this.menuCode = menuCode;
        }

        public void setFunctionStr(String functionStr) {
            this.functionStr = functionStr;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutOverdueAcptRevisitToHisInnerInput:(");
            buffer.append("operatorName:" + this.operatorName);
            buffer.append(",useType:" + this.useType);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",menuCode:" + this.menuCode);
            buffer.append(",functionStr:" + this.functionStr);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",initDate:" + this.initDate);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.operatorName);
            builder.append(this.useType);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.menuCode);
            builder.append(this.functionStr);
            builder.append(this.branchNo);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.initDate);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.PutOverdueAcptRevisitToHisInnerInput) {
                InnerBpsService.PutOverdueAcptRevisitToHisInnerInput test = (InnerBpsService.PutOverdueAcptRevisitToHisInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.operatorName, test.operatorName);
                builder.append(this.useType, test.useType);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.menuCode, test.menuCode);
                builder.append(this.functionStr, test.functionStr);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.initDate, test.initDate);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class AcptTimeAndOperatorInfoDTO implements Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String acptId = " ";
        @SinogramLength(
                min = 0,
                max = 10,
                charset = "utf-8"
        )
        private String acptBusinId = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        private Integer dealDate = 0;
        private Integer dealTime = 0;
        private String operatorName = " ";

        public AcptTimeAndOperatorInfoDTO() {
        }

        public String getAcptId() {
            if (this.acptId == null) {
                return " ";
            } else {
                return this.acptId.isEmpty() ? " " : this.acptId;
            }
        }

        public String getAcptBusinId() {
            if (this.acptBusinId == null) {
                return " ";
            } else {
                return this.acptBusinId.isEmpty() ? " " : this.acptBusinId;
            }
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public Integer getDealDate() {
            return this.dealDate != null ? this.dealDate : 0;
        }

        public Integer getDealTime() {
            return this.dealTime != null ? this.dealTime : 0;
        }

        public String getOperatorName() {
            if (this.operatorName == null) {
                return " ";
            } else {
                return this.operatorName.isEmpty() ? " " : this.operatorName;
            }
        }

        public void setAcptId(String acptId) {
            this.acptId = acptId;
        }

        public void setAcptBusinId(String acptBusinId) {
            this.acptBusinId = acptBusinId;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setDealDate(Integer dealDate) {
            this.dealDate = dealDate;
        }

        public void setDealTime(Integer dealTime) {
            this.dealTime = dealTime;
        }

        public void setOperatorName(String operatorName) {
            this.operatorName = operatorName;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("AcptTimeAndOperatorInfoDTO:(");
            buffer.append("acptId:" + this.acptId);
            buffer.append(",acptBusinId:" + this.acptBusinId);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",dealDate:" + this.dealDate);
            buffer.append(",dealTime:" + this.dealTime);
            buffer.append(",operatorName:" + this.operatorName);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.acptId);
            builder.append(this.acptBusinId);
            builder.append(this.operatorNo);
            builder.append(this.dealDate);
            builder.append(this.dealTime);
            builder.append(this.operatorName);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.AcptTimeAndOperatorInfoDTO) {
                InnerBpsService.AcptTimeAndOperatorInfoDTO test = (InnerBpsService.AcptTimeAndOperatorInfoDTO)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.acptId, test.acptId);
                builder.append(this.acptBusinId, test.acptBusinId);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.dealDate, test.dealDate);
                builder.append(this.dealTime, test.dealTime);
                builder.append(this.operatorName, test.operatorName);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutBpsAcptformClientIdInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 60,
                charset = "utf-8"
        )
        private String operatorName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character useType = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String menuCode = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String functionStr = " ";
        private Integer branchNo = 0;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 32,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String acptId;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fundAccount = " ";

        public PutBpsAcptformClientIdInnerInput() {
        }

        public String getOperatorName() {
            if (this.operatorName == null) {
                return " ";
            } else {
                return this.operatorName.isEmpty() ? " " : this.operatorName;
            }
        }

        public Character getUseType() {
            return this.useType != null ? this.useType : ' ';
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getMenuCode() {
            if (this.menuCode == null) {
                return " ";
            } else {
                return this.menuCode.isEmpty() ? " " : this.menuCode;
            }
        }

        public String getFunctionStr() {
            if (this.functionStr == null) {
                return " ";
            } else {
                return this.functionStr.isEmpty() ? " " : this.functionStr;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getAcptId() {
            return this.acptId;
        }

        public String getClientId() {
            return this.clientId;
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public void setOperatorName(String operatorName) {
            this.operatorName = operatorName;
        }

        public void setUseType(Character useType) {
            this.useType = useType;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setMenuCode(String menuCode) {
            this.menuCode = menuCode;
        }

        public void setFunctionStr(String functionStr) {
            this.functionStr = functionStr;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setAcptId(String acptId) {
            this.acptId = acptId;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutBpsAcptformClientIdInnerInput:(");
            buffer.append("operatorName:" + this.operatorName);
            buffer.append(",useType:" + this.useType);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",menuCode:" + this.menuCode);
            buffer.append(",functionStr:" + this.functionStr);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",acptId:" + this.acptId);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.operatorName);
            builder.append(this.useType);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.menuCode);
            builder.append(this.functionStr);
            builder.append(this.branchNo);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.acptId);
            builder.append(this.clientId);
            builder.append(this.fundAccount);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.PutBpsAcptformClientIdInnerInput) {
                InnerBpsService.PutBpsAcptformClientIdInnerInput test = (InnerBpsService.PutBpsAcptformClientIdInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.operatorName, test.operatorName);
                builder.append(this.useType, test.useType);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.menuCode, test.menuCode);
                builder.append(this.functionStr, test.functionStr);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.acptId, test.acptId);
                builder.append(this.clientId, test.clientId);
                builder.append(this.fundAccount, test.fundAccount);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutBpsAcptBusinDataInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String opRemark = " ";

        public PutBpsAcptBusinDataInnerOutput() {
        }

        public String getOpRemark() {
            if (this.opRemark == null) {
                return " ";
            } else {
                return this.opRemark.isEmpty() ? " " : this.opRemark;
            }
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutBpsAcptBusinDataInnerOutput:(");
            buffer.append("opRemark:" + this.opRemark);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opRemark);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.PutBpsAcptBusinDataInnerOutput) {
                InnerBpsService.PutBpsAcptBusinDataInnerOutput test = (InnerBpsService.PutBpsAcptBusinDataInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opRemark, test.opRemark);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutBpsAcptBusinDataInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 60,
                charset = "utf-8"
        )
        private String operatorName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character useType = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String menuCode = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String functionStr = " ";
        private Integer branchNo = 0;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 32,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String acptId;
        @SinogramLength(
                min = 0,
                max = 16000,
                charset = "utf-8"
        )
        private String paramData = " ";
        @SinogramLength(
                min = 0,
                max = 16000,
                charset = "utf-8"
        )
        private String functionData = " ";
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String remark = " ";

        public PutBpsAcptBusinDataInnerInput() {
        }

        public String getOperatorName() {
            if (this.operatorName == null) {
                return " ";
            } else {
                return this.operatorName.isEmpty() ? " " : this.operatorName;
            }
        }

        public Character getUseType() {
            return this.useType != null ? this.useType : ' ';
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getMenuCode() {
            if (this.menuCode == null) {
                return " ";
            } else {
                return this.menuCode.isEmpty() ? " " : this.menuCode;
            }
        }

        public String getFunctionStr() {
            if (this.functionStr == null) {
                return " ";
            } else {
                return this.functionStr.isEmpty() ? " " : this.functionStr;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getAcptId() {
            return this.acptId;
        }

        public String getParamData() {
            if (this.paramData == null) {
                return " ";
            } else {
                return this.paramData.isEmpty() ? " " : this.paramData;
            }
        }

        public String getFunctionData() {
            if (this.functionData == null) {
                return " ";
            } else {
                return this.functionData.isEmpty() ? " " : this.functionData;
            }
        }

        public String getRemark() {
            if (this.remark == null) {
                return " ";
            } else {
                return this.remark.isEmpty() ? " " : this.remark;
            }
        }

        public void setOperatorName(String operatorName) {
            this.operatorName = operatorName;
        }

        public void setUseType(Character useType) {
            this.useType = useType;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setMenuCode(String menuCode) {
            this.menuCode = menuCode;
        }

        public void setFunctionStr(String functionStr) {
            this.functionStr = functionStr;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setAcptId(String acptId) {
            this.acptId = acptId;
        }

        public void setParamData(String paramData) {
            this.paramData = paramData;
        }

        public void setFunctionData(String functionData) {
            this.functionData = functionData;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutBpsAcptBusinDataInnerInput:(");
            buffer.append("operatorName:" + this.operatorName);
            buffer.append(",useType:" + this.useType);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",menuCode:" + this.menuCode);
            buffer.append(",functionStr:" + this.functionStr);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",acptId:" + this.acptId);
            buffer.append(",paramData:" + this.paramData);
            buffer.append(",functionData:" + this.functionData);
            buffer.append(",remark:" + this.remark);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.operatorName);
            builder.append(this.useType);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.menuCode);
            builder.append(this.functionStr);
            builder.append(this.branchNo);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.acptId);
            builder.append(this.paramData);
            builder.append(this.functionData);
            builder.append(this.remark);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.PutBpsAcptBusinDataInnerInput) {
                InnerBpsService.PutBpsAcptBusinDataInnerInput test = (InnerBpsService.PutBpsAcptBusinDataInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.operatorName, test.operatorName);
                builder.append(this.useType, test.useType);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.menuCode, test.menuCode);
                builder.append(this.functionStr, test.functionStr);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.acptId, test.acptId);
                builder.append(this.paramData, test.paramData);
                builder.append(this.functionData, test.functionData);
                builder.append(this.remark, test.remark);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutBpsAcptformClientIdInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String opRemark = " ";

        public PutBpsAcptformClientIdInnerOutput() {
        }

        public String getOpRemark() {
            if (this.opRemark == null) {
                return " ";
            } else {
                return this.opRemark.isEmpty() ? " " : this.opRemark;
            }
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutBpsAcptformClientIdInnerOutput:(");
            buffer.append("opRemark:" + this.opRemark);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opRemark);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.PutBpsAcptformClientIdInnerOutput) {
                InnerBpsService.PutBpsAcptformClientIdInnerOutput test = (InnerBpsService.PutBpsAcptformClientIdInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opRemark, test.opRemark);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class AcptTaskDTO implements Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String acptId = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String taskNo = " ";

        public AcptTaskDTO() {
        }

        public String getAcptId() {
            if (this.acptId == null) {
                return " ";
            } else {
                return this.acptId.isEmpty() ? " " : this.acptId;
            }
        }

        public String getTaskNo() {
            if (this.taskNo == null) {
                return " ";
            } else {
                return this.taskNo.isEmpty() ? " " : this.taskNo;
            }
        }

        public void setAcptId(String acptId) {
            this.acptId = acptId;
        }

        public void setTaskNo(String taskNo) {
            this.taskNo = taskNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("AcptTaskDTO:(");
            buffer.append("acptId:" + this.acptId);
            buffer.append(",taskNo:" + this.taskNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.acptId);
            builder.append(this.taskNo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.AcptTaskDTO) {
                InnerBpsService.AcptTaskDTO test = (InnerBpsService.AcptTaskDTO)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.acptId, test.acptId);
                builder.append(this.taskNo, test.taskNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class ArchscanconfiglistDTO implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer archBusinessSysId = 0;
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String acptBusinKind = " ";
        @SinogramLength(
                min = 0,
                max = 10,
                charset = "utf-8"
        )
        private String acptBusinId = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character organFlag = ' ';
        @SinogramLength(
                min = 0,
                max = 6,
                charset = "utf-8"
        )
        private String archFileNo = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character haveScan = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character enableFlag = ' ';
        private Long templateId = 0L;
        @Digits(
                integer = 18,
                fraction = 0
        )
        @SerializeDoubleDigit(
                digit = 0
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double filterRulesId = 0.0D;
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String imageStandardName = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String imageName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character archFileType = ' ';
        private Integer imageDpi = 0;
        private Integer pageNumLimit = 0;
        private Long fileSize = 0L;
        private Integer lowerFileSize = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character baseFlag = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character datewaterFlag = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character importLocalFlag = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character imageSet = ' ';
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String remark = " ";
        @SinogramLength(
                min = 0,
                max = 4000,
                charset = "utf-8"
        )
        private String ocrMsg = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character registedFlag = ' ';

        public ArchscanconfiglistDTO() {
        }

        public Integer getArchBusinessSysId() {
            return this.archBusinessSysId != null ? this.archBusinessSysId : 0;
        }

        public String getAcptBusinKind() {
            if (this.acptBusinKind == null) {
                return " ";
            } else {
                return this.acptBusinKind.isEmpty() ? " " : this.acptBusinKind;
            }
        }

        public String getAcptBusinId() {
            if (this.acptBusinId == null) {
                return " ";
            } else {
                return this.acptBusinId.isEmpty() ? " " : this.acptBusinId;
            }
        }

        public Character getOrganFlag() {
            return this.organFlag != null ? this.organFlag : ' ';
        }

        public String getArchFileNo() {
            if (this.archFileNo == null) {
                return " ";
            } else {
                return this.archFileNo.isEmpty() ? " " : this.archFileNo;
            }
        }

        public Character getHaveScan() {
            return this.haveScan != null ? this.haveScan : ' ';
        }

        public Character getEnableFlag() {
            return this.enableFlag != null ? this.enableFlag : ' ';
        }

        public Long getTemplateId() {
            return this.templateId != null ? this.templateId : 0L;
        }

        public Double getFilterRulesId() {
            return this.filterRulesId != null ? this.filterRulesId : 0.0D;
        }

        public String getImageStandardName() {
            if (this.imageStandardName == null) {
                return " ";
            } else {
                return this.imageStandardName.isEmpty() ? " " : this.imageStandardName;
            }
        }

        public String getImageName() {
            if (this.imageName == null) {
                return " ";
            } else {
                return this.imageName.isEmpty() ? " " : this.imageName;
            }
        }

        public Character getArchFileType() {
            return this.archFileType != null ? this.archFileType : ' ';
        }

        public Integer getImageDpi() {
            return this.imageDpi != null ? this.imageDpi : 0;
        }

        public Integer getPageNumLimit() {
            return this.pageNumLimit != null ? this.pageNumLimit : 0;
        }

        public Long getFileSize() {
            return this.fileSize != null ? this.fileSize : 0L;
        }

        public Integer getLowerFileSize() {
            return this.lowerFileSize != null ? this.lowerFileSize : 0;
        }

        public Character getBaseFlag() {
            return this.baseFlag != null ? this.baseFlag : ' ';
        }

        public Character getDatewaterFlag() {
            return this.datewaterFlag != null ? this.datewaterFlag : ' ';
        }

        public Character getImportLocalFlag() {
            return this.importLocalFlag != null ? this.importLocalFlag : ' ';
        }

        public Character getImageSet() {
            return this.imageSet != null ? this.imageSet : ' ';
        }

        public String getRemark() {
            if (this.remark == null) {
                return " ";
            } else {
                return this.remark.isEmpty() ? " " : this.remark;
            }
        }

        public String getOcrMsg() {
            if (this.ocrMsg == null) {
                return " ";
            } else {
                return this.ocrMsg.isEmpty() ? " " : this.ocrMsg;
            }
        }

        public Character getRegistedFlag() {
            return this.registedFlag != null ? this.registedFlag : ' ';
        }

        public void setArchBusinessSysId(Integer archBusinessSysId) {
            this.archBusinessSysId = archBusinessSysId;
        }

        public void setAcptBusinKind(String acptBusinKind) {
            this.acptBusinKind = acptBusinKind;
        }

        public void setAcptBusinId(String acptBusinId) {
            this.acptBusinId = acptBusinId;
        }

        public void setOrganFlag(Character organFlag) {
            this.organFlag = organFlag;
        }

        public void setArchFileNo(String archFileNo) {
            this.archFileNo = archFileNo;
        }

        public void setHaveScan(Character haveScan) {
            this.haveScan = haveScan;
        }

        public void setEnableFlag(Character enableFlag) {
            this.enableFlag = enableFlag;
        }

        public void setTemplateId(Long templateId) {
            this.templateId = templateId;
        }

        public void setFilterRulesId(Double filterRulesId) {
            this.filterRulesId = filterRulesId;
        }

        public void setImageStandardName(String imageStandardName) {
            this.imageStandardName = imageStandardName;
        }

        public void setImageName(String imageName) {
            this.imageName = imageName;
        }

        public void setArchFileType(Character archFileType) {
            this.archFileType = archFileType;
        }

        public void setImageDpi(Integer imageDpi) {
            this.imageDpi = imageDpi;
        }

        public void setPageNumLimit(Integer pageNumLimit) {
            this.pageNumLimit = pageNumLimit;
        }

        public void setFileSize(Long fileSize) {
            this.fileSize = fileSize;
        }

        public void setLowerFileSize(Integer lowerFileSize) {
            this.lowerFileSize = lowerFileSize;
        }

        public void setBaseFlag(Character baseFlag) {
            this.baseFlag = baseFlag;
        }

        public void setDatewaterFlag(Character datewaterFlag) {
            this.datewaterFlag = datewaterFlag;
        }

        public void setImportLocalFlag(Character importLocalFlag) {
            this.importLocalFlag = importLocalFlag;
        }

        public void setImageSet(Character imageSet) {
            this.imageSet = imageSet;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public void setOcrMsg(String ocrMsg) {
            this.ocrMsg = ocrMsg;
        }

        public void setRegistedFlag(Character registedFlag) {
            this.registedFlag = registedFlag;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("ArchscanconfiglistDTO:(");
            buffer.append("archBusinessSysId:" + this.archBusinessSysId);
            buffer.append(",acptBusinKind:" + this.acptBusinKind);
            buffer.append(",acptBusinId:" + this.acptBusinId);
            buffer.append(",organFlag:" + this.organFlag);
            buffer.append(",archFileNo:" + this.archFileNo);
            buffer.append(",haveScan:" + this.haveScan);
            buffer.append(",enableFlag:" + this.enableFlag);
            buffer.append(",templateId:" + this.templateId);
            buffer.append(",filterRulesId:" + this.filterRulesId);
            buffer.append(",imageStandardName:" + this.imageStandardName);
            buffer.append(",imageName:" + this.imageName);
            buffer.append(",archFileType:" + this.archFileType);
            buffer.append(",imageDpi:" + this.imageDpi);
            buffer.append(",pageNumLimit:" + this.pageNumLimit);
            buffer.append(",fileSize:" + this.fileSize);
            buffer.append(",lowerFileSize:" + this.lowerFileSize);
            buffer.append(",baseFlag:" + this.baseFlag);
            buffer.append(",datewaterFlag:" + this.datewaterFlag);
            buffer.append(",importLocalFlag:" + this.importLocalFlag);
            buffer.append(",imageSet:" + this.imageSet);
            buffer.append(",remark:" + this.remark);
            buffer.append(",ocrMsg:" + this.ocrMsg);
            buffer.append(",registedFlag:" + this.registedFlag);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.archBusinessSysId);
            builder.append(this.acptBusinKind);
            builder.append(this.acptBusinId);
            builder.append(this.organFlag);
            builder.append(this.archFileNo);
            builder.append(this.haveScan);
            builder.append(this.enableFlag);
            builder.append(this.templateId);
            builder.append(this.filterRulesId);
            builder.append(this.imageStandardName);
            builder.append(this.imageName);
            builder.append(this.archFileType);
            builder.append(this.imageDpi);
            builder.append(this.pageNumLimit);
            builder.append(this.fileSize);
            builder.append(this.lowerFileSize);
            builder.append(this.baseFlag);
            builder.append(this.datewaterFlag);
            builder.append(this.importLocalFlag);
            builder.append(this.imageSet);
            builder.append(this.remark);
            builder.append(this.ocrMsg);
            builder.append(this.registedFlag);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.ArchscanconfiglistDTO) {
                InnerBpsService.ArchscanconfiglistDTO test = (InnerBpsService.ArchscanconfiglistDTO)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.archBusinessSysId, test.archBusinessSysId);
                builder.append(this.acptBusinKind, test.acptBusinKind);
                builder.append(this.acptBusinId, test.acptBusinId);
                builder.append(this.organFlag, test.organFlag);
                builder.append(this.archFileNo, test.archFileNo);
                builder.append(this.haveScan, test.haveScan);
                builder.append(this.enableFlag, test.enableFlag);
                builder.append(this.templateId, test.templateId);
                builder.append(this.filterRulesId, test.filterRulesId);
                builder.append(this.imageStandardName, test.imageStandardName);
                builder.append(this.imageName, test.imageName);
                builder.append(this.archFileType, test.archFileType);
                builder.append(this.imageDpi, test.imageDpi);
                builder.append(this.pageNumLimit, test.pageNumLimit);
                builder.append(this.fileSize, test.fileSize);
                builder.append(this.lowerFileSize, test.lowerFileSize);
                builder.append(this.baseFlag, test.baseFlag);
                builder.append(this.datewaterFlag, test.datewaterFlag);
                builder.append(this.importLocalFlag, test.importLocalFlag);
                builder.append(this.imageSet, test.imageSet);
                builder.append(this.remark, test.remark);
                builder.append(this.ocrMsg, test.ocrMsg);
                builder.append(this.registedFlag, test.registedFlag);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class AcpttplDTO implements Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String acptBusinKind = " ";
        @SinogramLength(
                min = 0,
                max = 10,
                charset = "utf-8"
        )
        private String acptBusinId = " ";
        @SinogramLength(
                min = 0,
                max = 180,
                charset = "utf-8"
        )
        private String acptCategoryName = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String processNo = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character upFlag = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character isEsign = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character modifiable = ' ';
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String enSubOpType = " ";
        @SinogramLength(
                min = 0,
                max = 500,
                charset = "utf-8"
        )
        private String acptProcessStr = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String acptTplFlags = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character agreementStatus = ' ';
        private Integer beginTime = 0;
        private Integer endTime = 0;
        @SinogramLength(
                min = 0,
                max = 4000,
                charset = "utf-8"
        )
        private String acptTip = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String menuCode = " ";
        @SinogramLength(
                min = 0,
                max = 4000,
                charset = "utf-8"
        )
        private String enFunctionStr = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character acptType = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character auditFlag = ' ';
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String acptEnrouteStr = " ";
        @SinogramLength(
                min = 0,
                max = 500,
                charset = "utf-8"
        )
        private String callbackFunctionStr = " ";
        @SinogramLength(
                min = 0,
                max = 4000,
                charset = "utf-8"
        )
        private String acptTplExt = " ";
        private Integer auditCostStandard = 0;

        public AcpttplDTO() {
        }

        public String getAcptBusinKind() {
            if (this.acptBusinKind == null) {
                return " ";
            } else {
                return this.acptBusinKind.isEmpty() ? " " : this.acptBusinKind;
            }
        }

        public String getAcptBusinId() {
            if (this.acptBusinId == null) {
                return " ";
            } else {
                return this.acptBusinId.isEmpty() ? " " : this.acptBusinId;
            }
        }

        public String getAcptCategoryName() {
            if (this.acptCategoryName == null) {
                return " ";
            } else {
                return this.acptCategoryName.isEmpty() ? " " : this.acptCategoryName;
            }
        }

        public String getProcessNo() {
            if (this.processNo == null) {
                return " ";
            } else {
                return this.processNo.isEmpty() ? " " : this.processNo;
            }
        }

        public Character getUpFlag() {
            return this.upFlag != null ? this.upFlag : ' ';
        }

        public Character getIsEsign() {
            return this.isEsign != null ? this.isEsign : ' ';
        }

        public Character getModifiable() {
            return this.modifiable != null ? this.modifiable : ' ';
        }

        public String getEnSubOpType() {
            if (this.enSubOpType == null) {
                return " ";
            } else {
                return this.enSubOpType.isEmpty() ? " " : this.enSubOpType;
            }
        }

        public String getAcptProcessStr() {
            if (this.acptProcessStr == null) {
                return " ";
            } else {
                return this.acptProcessStr.isEmpty() ? " " : this.acptProcessStr;
            }
        }

        public String getAcptTplFlags() {
            if (this.acptTplFlags == null) {
                return " ";
            } else {
                return this.acptTplFlags.isEmpty() ? " " : this.acptTplFlags;
            }
        }

        public Character getAgreementStatus() {
            return this.agreementStatus != null ? this.agreementStatus : ' ';
        }

        public Integer getBeginTime() {
            return this.beginTime != null ? this.beginTime : 0;
        }

        public Integer getEndTime() {
            return this.endTime != null ? this.endTime : 0;
        }

        public String getAcptTip() {
            if (this.acptTip == null) {
                return " ";
            } else {
                return this.acptTip.isEmpty() ? " " : this.acptTip;
            }
        }

        public String getMenuCode() {
            if (this.menuCode == null) {
                return " ";
            } else {
                return this.menuCode.isEmpty() ? " " : this.menuCode;
            }
        }

        public String getEnFunctionStr() {
            if (this.enFunctionStr == null) {
                return " ";
            } else {
                return this.enFunctionStr.isEmpty() ? " " : this.enFunctionStr;
            }
        }

        public Character getAcptType() {
            return this.acptType != null ? this.acptType : ' ';
        }

        public Character getAuditFlag() {
            return this.auditFlag != null ? this.auditFlag : ' ';
        }

        public String getAcptEnrouteStr() {
            if (this.acptEnrouteStr == null) {
                return " ";
            } else {
                return this.acptEnrouteStr.isEmpty() ? " " : this.acptEnrouteStr;
            }
        }

        public String getCallbackFunctionStr() {
            if (this.callbackFunctionStr == null) {
                return " ";
            } else {
                return this.callbackFunctionStr.isEmpty() ? " " : this.callbackFunctionStr;
            }
        }

        public String getAcptTplExt() {
            if (this.acptTplExt == null) {
                return " ";
            } else {
                return this.acptTplExt.isEmpty() ? " " : this.acptTplExt;
            }
        }

        public Integer getAuditCostStandard() {
            return this.auditCostStandard != null ? this.auditCostStandard : 0;
        }

        public void setAcptBusinKind(String acptBusinKind) {
            this.acptBusinKind = acptBusinKind;
        }

        public void setAcptBusinId(String acptBusinId) {
            this.acptBusinId = acptBusinId;
        }

        public void setAcptCategoryName(String acptCategoryName) {
            this.acptCategoryName = acptCategoryName;
        }

        public void setProcessNo(String processNo) {
            this.processNo = processNo;
        }

        public void setUpFlag(Character upFlag) {
            this.upFlag = upFlag;
        }

        public void setIsEsign(Character isEsign) {
            this.isEsign = isEsign;
        }

        public void setModifiable(Character modifiable) {
            this.modifiable = modifiable;
        }

        public void setEnSubOpType(String enSubOpType) {
            this.enSubOpType = enSubOpType;
        }

        public void setAcptProcessStr(String acptProcessStr) {
            this.acptProcessStr = acptProcessStr;
        }

        public void setAcptTplFlags(String acptTplFlags) {
            this.acptTplFlags = acptTplFlags;
        }

        public void setAgreementStatus(Character agreementStatus) {
            this.agreementStatus = agreementStatus;
        }

        public void setBeginTime(Integer beginTime) {
            this.beginTime = beginTime;
        }

        public void setEndTime(Integer endTime) {
            this.endTime = endTime;
        }

        public void setAcptTip(String acptTip) {
            this.acptTip = acptTip;
        }

        public void setMenuCode(String menuCode) {
            this.menuCode = menuCode;
        }

        public void setEnFunctionStr(String enFunctionStr) {
            this.enFunctionStr = enFunctionStr;
        }

        public void setAcptType(Character acptType) {
            this.acptType = acptType;
        }

        public void setAuditFlag(Character auditFlag) {
            this.auditFlag = auditFlag;
        }

        public void setAcptEnrouteStr(String acptEnrouteStr) {
            this.acptEnrouteStr = acptEnrouteStr;
        }

        public void setCallbackFunctionStr(String callbackFunctionStr) {
            this.callbackFunctionStr = callbackFunctionStr;
        }

        public void setAcptTplExt(String acptTplExt) {
            this.acptTplExt = acptTplExt;
        }

        public void setAuditCostStandard(Integer auditCostStandard) {
            this.auditCostStandard = auditCostStandard;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("AcpttplDTO:(");
            buffer.append("acptBusinKind:" + this.acptBusinKind);
            buffer.append(",acptBusinId:" + this.acptBusinId);
            buffer.append(",acptCategoryName:" + this.acptCategoryName);
            buffer.append(",processNo:" + this.processNo);
            buffer.append(",upFlag:" + this.upFlag);
            buffer.append(",isEsign:" + this.isEsign);
            buffer.append(",modifiable:" + this.modifiable);
            buffer.append(",enSubOpType:" + this.enSubOpType);
            buffer.append(",acptProcessStr:" + this.acptProcessStr);
            buffer.append(",acptTplFlags:" + this.acptTplFlags);
            buffer.append(",agreementStatus:" + this.agreementStatus);
            buffer.append(",beginTime:" + this.beginTime);
            buffer.append(",endTime:" + this.endTime);
            buffer.append(",acptTip:" + this.acptTip);
            buffer.append(",menuCode:" + this.menuCode);
            buffer.append(",enFunctionStr:" + this.enFunctionStr);
            buffer.append(",acptType:" + this.acptType);
            buffer.append(",auditFlag:" + this.auditFlag);
            buffer.append(",acptEnrouteStr:" + this.acptEnrouteStr);
            buffer.append(",callbackFunctionStr:" + this.callbackFunctionStr);
            buffer.append(",acptTplExt:" + this.acptTplExt);
            buffer.append(",auditCostStandard:" + this.auditCostStandard);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.acptBusinKind);
            builder.append(this.acptBusinId);
            builder.append(this.acptCategoryName);
            builder.append(this.processNo);
            builder.append(this.upFlag);
            builder.append(this.isEsign);
            builder.append(this.modifiable);
            builder.append(this.enSubOpType);
            builder.append(this.acptProcessStr);
            builder.append(this.acptTplFlags);
            builder.append(this.agreementStatus);
            builder.append(this.beginTime);
            builder.append(this.endTime);
            builder.append(this.acptTip);
            builder.append(this.menuCode);
            builder.append(this.enFunctionStr);
            builder.append(this.acptType);
            builder.append(this.auditFlag);
            builder.append(this.acptEnrouteStr);
            builder.append(this.callbackFunctionStr);
            builder.append(this.acptTplExt);
            builder.append(this.auditCostStandard);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.AcpttplDTO) {
                InnerBpsService.AcpttplDTO test = (InnerBpsService.AcpttplDTO)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.acptBusinKind, test.acptBusinKind);
                builder.append(this.acptBusinId, test.acptBusinId);
                builder.append(this.acptCategoryName, test.acptCategoryName);
                builder.append(this.processNo, test.processNo);
                builder.append(this.upFlag, test.upFlag);
                builder.append(this.isEsign, test.isEsign);
                builder.append(this.modifiable, test.modifiable);
                builder.append(this.enSubOpType, test.enSubOpType);
                builder.append(this.acptProcessStr, test.acptProcessStr);
                builder.append(this.acptTplFlags, test.acptTplFlags);
                builder.append(this.agreementStatus, test.agreementStatus);
                builder.append(this.beginTime, test.beginTime);
                builder.append(this.endTime, test.endTime);
                builder.append(this.acptTip, test.acptTip);
                builder.append(this.menuCode, test.menuCode);
                builder.append(this.enFunctionStr, test.enFunctionStr);
                builder.append(this.acptType, test.acptType);
                builder.append(this.auditFlag, test.auditFlag);
                builder.append(this.acptEnrouteStr, test.acptEnrouteStr);
                builder.append(this.callbackFunctionStr, test.callbackFunctionStr);
                builder.append(this.acptTplExt, test.acptTplExt);
                builder.append(this.auditCostStandard, test.auditCostStandard);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class AcptsubnodeDTO implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer subNodeId = 0;
        @SinogramLength(
                min = 0,
                max = 180,
                charset = "utf-8"
        )
        private String nodeName = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String sysName = " ";
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String enEditFields = " ";
        @SinogramLength(
                min = 0,
                max = 60,
                charset = "utf-8"
        )
        private String nodeElementName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character acptType = ' ';

        public AcptsubnodeDTO() {
        }

        public Integer getSubNodeId() {
            return this.subNodeId != null ? this.subNodeId : 0;
        }

        public String getNodeName() {
            if (this.nodeName == null) {
                return " ";
            } else {
                return this.nodeName.isEmpty() ? " " : this.nodeName;
            }
        }

        public String getSysName() {
            if (this.sysName == null) {
                return " ";
            } else {
                return this.sysName.isEmpty() ? " " : this.sysName;
            }
        }

        public String getEnEditFields() {
            if (this.enEditFields == null) {
                return " ";
            } else {
                return this.enEditFields.isEmpty() ? " " : this.enEditFields;
            }
        }

        public String getNodeElementName() {
            if (this.nodeElementName == null) {
                return " ";
            } else {
                return this.nodeElementName.isEmpty() ? " " : this.nodeElementName;
            }
        }

        public Character getAcptType() {
            return this.acptType != null ? this.acptType : ' ';
        }

        public void setSubNodeId(Integer subNodeId) {
            this.subNodeId = subNodeId;
        }

        public void setNodeName(String nodeName) {
            this.nodeName = nodeName;
        }

        public void setSysName(String sysName) {
            this.sysName = sysName;
        }

        public void setEnEditFields(String enEditFields) {
            this.enEditFields = enEditFields;
        }

        public void setNodeElementName(String nodeElementName) {
            this.nodeElementName = nodeElementName;
        }

        public void setAcptType(Character acptType) {
            this.acptType = acptType;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("AcptsubnodeDTO:(");
            buffer.append("subNodeId:" + this.subNodeId);
            buffer.append(",nodeName:" + this.nodeName);
            buffer.append(",sysName:" + this.sysName);
            buffer.append(",enEditFields:" + this.enEditFields);
            buffer.append(",nodeElementName:" + this.nodeElementName);
            buffer.append(",acptType:" + this.acptType);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.subNodeId);
            builder.append(this.nodeName);
            builder.append(this.sysName);
            builder.append(this.enEditFields);
            builder.append(this.nodeElementName);
            builder.append(this.acptType);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.AcptsubnodeDTO) {
                InnerBpsService.AcptsubnodeDTO test = (InnerBpsService.AcptsubnodeDTO)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.subNodeId, test.subNodeId);
                builder.append(this.nodeName, test.nodeName);
                builder.append(this.sysName, test.sysName);
                builder.append(this.enEditFields, test.enEditFields);
                builder.append(this.nodeElementName, test.nodeElementName);
                builder.append(this.acptType, test.acptType);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class OperatortaskDTO implements Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String taskNo = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String acptId = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character organFlag = ' ';
        private Integer branchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String clientId = " ";
        @SinogramLength(
                min = 0,
                max = 180,
                charset = "utf-8"
        )
        private String fullName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character idKind = ' ';
        @SinogramLength(
                min = 0,
                max = 40,
                charset = "utf-8"
        )
        private String idNo = " ";
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 60,
                charset = "utf-8"
        )
        private String operatorName = " ";
        private Integer auditBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 16,
                charset = "utf-8"
        )
        private String auditorNo = " ";
        @SinogramLength(
                min = 0,
                max = 180,
                charset = "utf-8"
        )
        private String auditorName = " ";
        private Integer opLevel = 0;
        @SinogramLength(
                min = 0,
                max = 10,
                charset = "utf-8"
        )
        private String acptBusinId = " ";
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String acptBusinKind = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String businodeName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character businodeKind = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character dealStatus = ' ';
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String remark = " ";
        private Integer acceptDate = 0;
        private Integer acceptTime = 0;
        private Integer dealDate = 0;
        private Integer dealTime = 0;
        private Integer dateClear = 0;
        @SinogramLength(
                min = 0,
                max = 100,
                charset = "utf-8"
        )
        private String positionStr = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character acptType = ' ';
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fundAccount = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String humanNode = " ";
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String rejectReason = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String rejectFlagStr = " ";

        public OperatortaskDTO() {
        }

        public String getTaskNo() {
            if (this.taskNo == null) {
                return " ";
            } else {
                return this.taskNo.isEmpty() ? " " : this.taskNo;
            }
        }

        public String getAcptId() {
            if (this.acptId == null) {
                return " ";
            } else {
                return this.acptId.isEmpty() ? " " : this.acptId;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Character getOrganFlag() {
            return this.organFlag != null ? this.organFlag : ' ';
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getFullName() {
            if (this.fullName == null) {
                return " ";
            } else {
                return this.fullName.isEmpty() ? " " : this.fullName;
            }
        }

        public Character getIdKind() {
            return this.idKind != null ? this.idKind : ' ';
        }

        public String getIdNo() {
            if (this.idNo == null) {
                return " ";
            } else {
                return this.idNo.isEmpty() ? " " : this.idNo;
            }
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOperatorName() {
            if (this.operatorName == null) {
                return " ";
            } else {
                return this.operatorName.isEmpty() ? " " : this.operatorName;
            }
        }

        public Integer getAuditBranchNo() {
            return this.auditBranchNo != null ? this.auditBranchNo : 0;
        }

        public String getAuditorNo() {
            if (this.auditorNo == null) {
                return " ";
            } else {
                return this.auditorNo.isEmpty() ? " " : this.auditorNo;
            }
        }

        public String getAuditorName() {
            if (this.auditorName == null) {
                return " ";
            } else {
                return this.auditorName.isEmpty() ? " " : this.auditorName;
            }
        }

        public Integer getOpLevel() {
            return this.opLevel != null ? this.opLevel : 0;
        }

        public String getAcptBusinId() {
            if (this.acptBusinId == null) {
                return " ";
            } else {
                return this.acptBusinId.isEmpty() ? " " : this.acptBusinId;
            }
        }

        public String getAcptBusinKind() {
            if (this.acptBusinKind == null) {
                return " ";
            } else {
                return this.acptBusinKind.isEmpty() ? " " : this.acptBusinKind;
            }
        }

        public String getBusinodeName() {
            if (this.businodeName == null) {
                return " ";
            } else {
                return this.businodeName.isEmpty() ? " " : this.businodeName;
            }
        }

        public Character getBusinodeKind() {
            return this.businodeKind != null ? this.businodeKind : ' ';
        }

        public Character getDealStatus() {
            return this.dealStatus != null ? this.dealStatus : ' ';
        }

        public String getRemark() {
            if (this.remark == null) {
                return " ";
            } else {
                return this.remark.isEmpty() ? " " : this.remark;
            }
        }

        public Integer getAcceptDate() {
            return this.acceptDate != null ? this.acceptDate : 0;
        }

        public Integer getAcceptTime() {
            return this.acceptTime != null ? this.acceptTime : 0;
        }

        public Integer getDealDate() {
            return this.dealDate != null ? this.dealDate : 0;
        }

        public Integer getDealTime() {
            return this.dealTime != null ? this.dealTime : 0;
        }

        public Integer getDateClear() {
            return this.dateClear != null ? this.dateClear : 0;
        }

        public String getPositionStr() {
            if (this.positionStr == null) {
                return " ";
            } else {
                return this.positionStr.isEmpty() ? " " : this.positionStr;
            }
        }

        public Character getAcptType() {
            return this.acptType != null ? this.acptType : ' ';
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getHumanNode() {
            if (this.humanNode == null) {
                return " ";
            } else {
                return this.humanNode.isEmpty() ? " " : this.humanNode;
            }
        }

        public String getRejectReason() {
            if (this.rejectReason == null) {
                return " ";
            } else {
                return this.rejectReason.isEmpty() ? " " : this.rejectReason;
            }
        }

        public String getRejectFlagStr() {
            if (this.rejectFlagStr == null) {
                return " ";
            } else {
                return this.rejectFlagStr.isEmpty() ? " " : this.rejectFlagStr;
            }
        }

        public void setTaskNo(String taskNo) {
            this.taskNo = taskNo;
        }

        public void setAcptId(String acptId) {
            this.acptId = acptId;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOrganFlag(Character organFlag) {
            this.organFlag = organFlag;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setFullName(String fullName) {
            this.fullName = fullName;
        }

        public void setIdKind(Character idKind) {
            this.idKind = idKind;
        }

        public void setIdNo(String idNo) {
            this.idNo = idNo;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOperatorName(String operatorName) {
            this.operatorName = operatorName;
        }

        public void setAuditBranchNo(Integer auditBranchNo) {
            this.auditBranchNo = auditBranchNo;
        }

        public void setAuditorNo(String auditorNo) {
            this.auditorNo = auditorNo;
        }

        public void setAuditorName(String auditorName) {
            this.auditorName = auditorName;
        }

        public void setOpLevel(Integer opLevel) {
            this.opLevel = opLevel;
        }

        public void setAcptBusinId(String acptBusinId) {
            this.acptBusinId = acptBusinId;
        }

        public void setAcptBusinKind(String acptBusinKind) {
            this.acptBusinKind = acptBusinKind;
        }

        public void setBusinodeName(String businodeName) {
            this.businodeName = businodeName;
        }

        public void setBusinodeKind(Character businodeKind) {
            this.businodeKind = businodeKind;
        }

        public void setDealStatus(Character dealStatus) {
            this.dealStatus = dealStatus;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public void setAcceptDate(Integer acceptDate) {
            this.acceptDate = acceptDate;
        }

        public void setAcceptTime(Integer acceptTime) {
            this.acceptTime = acceptTime;
        }

        public void setDealDate(Integer dealDate) {
            this.dealDate = dealDate;
        }

        public void setDealTime(Integer dealTime) {
            this.dealTime = dealTime;
        }

        public void setDateClear(Integer dateClear) {
            this.dateClear = dateClear;
        }

        public void setPositionStr(String positionStr) {
            this.positionStr = positionStr;
        }

        public void setAcptType(Character acptType) {
            this.acptType = acptType;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setHumanNode(String humanNode) {
            this.humanNode = humanNode;
        }

        public void setRejectReason(String rejectReason) {
            this.rejectReason = rejectReason;
        }

        public void setRejectFlagStr(String rejectFlagStr) {
            this.rejectFlagStr = rejectFlagStr;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("OperatortaskDTO:(");
            buffer.append("taskNo:" + this.taskNo);
            buffer.append(",acptId:" + this.acptId);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",organFlag:" + this.organFlag);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",fullName:" + this.fullName);
            buffer.append(",idKind:" + this.idKind);
            buffer.append(",idNo:" + this.idNo);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",operatorName:" + this.operatorName);
            buffer.append(",auditBranchNo:" + this.auditBranchNo);
            buffer.append(",auditorNo:" + this.auditorNo);
            buffer.append(",auditorName:" + this.auditorName);
            buffer.append(",opLevel:" + this.opLevel);
            buffer.append(",acptBusinId:" + this.acptBusinId);
            buffer.append(",acptBusinKind:" + this.acptBusinKind);
            buffer.append(",businodeName:" + this.businodeName);
            buffer.append(",businodeKind:" + this.businodeKind);
            buffer.append(",dealStatus:" + this.dealStatus);
            buffer.append(",remark:" + this.remark);
            buffer.append(",acceptDate:" + this.acceptDate);
            buffer.append(",acceptTime:" + this.acceptTime);
            buffer.append(",dealDate:" + this.dealDate);
            buffer.append(",dealTime:" + this.dealTime);
            buffer.append(",dateClear:" + this.dateClear);
            buffer.append(",positionStr:" + this.positionStr);
            buffer.append(",acptType:" + this.acptType);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",humanNode:" + this.humanNode);
            buffer.append(",rejectReason:" + this.rejectReason);
            buffer.append(",rejectFlagStr:" + this.rejectFlagStr);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.taskNo);
            builder.append(this.acptId);
            builder.append(this.opEntrustWay);
            builder.append(this.organFlag);
            builder.append(this.branchNo);
            builder.append(this.clientId);
            builder.append(this.fullName);
            builder.append(this.idKind);
            builder.append(this.idNo);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.operatorName);
            builder.append(this.auditBranchNo);
            builder.append(this.auditorNo);
            builder.append(this.auditorName);
            builder.append(this.opLevel);
            builder.append(this.acptBusinId);
            builder.append(this.acptBusinKind);
            builder.append(this.businodeName);
            builder.append(this.businodeKind);
            builder.append(this.dealStatus);
            builder.append(this.remark);
            builder.append(this.acceptDate);
            builder.append(this.acceptTime);
            builder.append(this.dealDate);
            builder.append(this.dealTime);
            builder.append(this.dateClear);
            builder.append(this.positionStr);
            builder.append(this.acptType);
            builder.append(this.fundAccount);
            builder.append(this.humanNode);
            builder.append(this.rejectReason);
            builder.append(this.rejectFlagStr);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.OperatortaskDTO) {
                InnerBpsService.OperatortaskDTO test = (InnerBpsService.OperatortaskDTO)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.taskNo, test.taskNo);
                builder.append(this.acptId, test.acptId);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.organFlag, test.organFlag);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.clientId, test.clientId);
                builder.append(this.fullName, test.fullName);
                builder.append(this.idKind, test.idKind);
                builder.append(this.idNo, test.idNo);
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.operatorName, test.operatorName);
                builder.append(this.auditBranchNo, test.auditBranchNo);
                builder.append(this.auditorNo, test.auditorNo);
                builder.append(this.auditorName, test.auditorName);
                builder.append(this.opLevel, test.opLevel);
                builder.append(this.acptBusinId, test.acptBusinId);
                builder.append(this.acptBusinKind, test.acptBusinKind);
                builder.append(this.businodeName, test.businodeName);
                builder.append(this.businodeKind, test.businodeKind);
                builder.append(this.dealStatus, test.dealStatus);
                builder.append(this.remark, test.remark);
                builder.append(this.acceptDate, test.acceptDate);
                builder.append(this.acceptTime, test.acceptTime);
                builder.append(this.dealDate, test.dealDate);
                builder.append(this.dealTime, test.dealTime);
                builder.append(this.dateClear, test.dateClear);
                builder.append(this.positionStr, test.positionStr);
                builder.append(this.acptType, test.acptType);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.humanNode, test.humanNode);
                builder.append(this.rejectReason, test.rejectReason);
                builder.append(this.rejectFlagStr, test.rejectFlagStr);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class OperatorToClaimTask implements Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String acptId = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character acptType = ' ';
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fundAccount = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String clientId = " ";
        @SinogramLength(
                min = 0,
                max = 180,
                charset = "utf-8"
        )
        private String fullName = " ";
        private Integer branchNo = 0;
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String acptBusinKind = " ";
        @SinogramLength(
                min = 0,
                max = 10,
                charset = "utf-8"
        )
        private String acptBusinId = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        private Integer opBranchNo = 0;
        private Integer acceptDate = 0;
        private Integer acceptTime = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character acptFormStatus = ' ';
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String workflowOrderId = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String taskNo = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String lastOperatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 60,
                charset = "utf-8"
        )
        private String lastOperatorName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character organFlag = ' ';
        @SinogramLength(
                min = 0,
                max = 100,
                charset = "utf-8"
        )
        private String positionStr = " ";
        private Integer opLevel = 0;
        @SinogramLength(
                min = 0,
                max = 16,
                charset = "utf-8"
        )
        private String statusName = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String loginAccount = " ";
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String opContent = " ";
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String rejectReason = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String rejectFlagStr = " ";
        private Integer acptChannel = 0;

        public OperatorToClaimTask() {
        }

        public String getAcptId() {
            if (this.acptId == null) {
                return " ";
            } else {
                return this.acptId.isEmpty() ? " " : this.acptId;
            }
        }

        public Character getAcptType() {
            return this.acptType != null ? this.acptType : ' ';
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getFullName() {
            if (this.fullName == null) {
                return " ";
            } else {
                return this.fullName.isEmpty() ? " " : this.fullName;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getAcptBusinKind() {
            if (this.acptBusinKind == null) {
                return " ";
            } else {
                return this.acptBusinKind.isEmpty() ? " " : this.acptBusinKind;
            }
        }

        public String getAcptBusinId() {
            if (this.acptBusinId == null) {
                return " ";
            } else {
                return this.acptBusinId.isEmpty() ? " " : this.acptBusinId;
            }
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public Integer getAcceptDate() {
            return this.acceptDate != null ? this.acceptDate : 0;
        }

        public Integer getAcceptTime() {
            return this.acceptTime != null ? this.acceptTime : 0;
        }

        public Character getAcptFormStatus() {
            return this.acptFormStatus != null ? this.acptFormStatus : ' ';
        }

        public String getWorkflowOrderId() {
            if (this.workflowOrderId == null) {
                return " ";
            } else {
                return this.workflowOrderId.isEmpty() ? " " : this.workflowOrderId;
            }
        }

        public String getTaskNo() {
            if (this.taskNo == null) {
                return " ";
            } else {
                return this.taskNo.isEmpty() ? " " : this.taskNo;
            }
        }

        public String getLastOperatorNo() {
            if (this.lastOperatorNo == null) {
                return " ";
            } else {
                return this.lastOperatorNo.isEmpty() ? " " : this.lastOperatorNo;
            }
        }

        public String getLastOperatorName() {
            if (this.lastOperatorName == null) {
                return " ";
            } else {
                return this.lastOperatorName.isEmpty() ? " " : this.lastOperatorName;
            }
        }

        public Character getOrganFlag() {
            return this.organFlag != null ? this.organFlag : ' ';
        }

        public String getPositionStr() {
            if (this.positionStr == null) {
                return " ";
            } else {
                return this.positionStr.isEmpty() ? " " : this.positionStr;
            }
        }

        public Integer getOpLevel() {
            return this.opLevel != null ? this.opLevel : 0;
        }

        public String getStatusName() {
            if (this.statusName == null) {
                return " ";
            } else {
                return this.statusName.isEmpty() ? " " : this.statusName;
            }
        }

        public String getLoginAccount() {
            if (this.loginAccount == null) {
                return " ";
            } else {
                return this.loginAccount.isEmpty() ? " " : this.loginAccount;
            }
        }

        public String getOpContent() {
            if (this.opContent == null) {
                return " ";
            } else {
                return this.opContent.isEmpty() ? " " : this.opContent;
            }
        }

        public String getRejectReason() {
            if (this.rejectReason == null) {
                return " ";
            } else {
                return this.rejectReason.isEmpty() ? " " : this.rejectReason;
            }
        }

        public String getRejectFlagStr() {
            if (this.rejectFlagStr == null) {
                return " ";
            } else {
                return this.rejectFlagStr.isEmpty() ? " " : this.rejectFlagStr;
            }
        }

        public Integer getAcptChannel() {
            return this.acptChannel != null ? this.acptChannel : 0;
        }

        public void setAcptId(String acptId) {
            this.acptId = acptId;
        }

        public void setAcptType(Character acptType) {
            this.acptType = acptType;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setFullName(String fullName) {
            this.fullName = fullName;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setAcptBusinKind(String acptBusinKind) {
            this.acptBusinKind = acptBusinKind;
        }

        public void setAcptBusinId(String acptBusinId) {
            this.acptBusinId = acptBusinId;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setAcceptDate(Integer acceptDate) {
            this.acceptDate = acceptDate;
        }

        public void setAcceptTime(Integer acceptTime) {
            this.acceptTime = acceptTime;
        }

        public void setAcptFormStatus(Character acptFormStatus) {
            this.acptFormStatus = acptFormStatus;
        }

        public void setWorkflowOrderId(String workflowOrderId) {
            this.workflowOrderId = workflowOrderId;
        }

        public void setTaskNo(String taskNo) {
            this.taskNo = taskNo;
        }

        public void setLastOperatorNo(String lastOperatorNo) {
            this.lastOperatorNo = lastOperatorNo;
        }

        public void setLastOperatorName(String lastOperatorName) {
            this.lastOperatorName = lastOperatorName;
        }

        public void setOrganFlag(Character organFlag) {
            this.organFlag = organFlag;
        }

        public void setPositionStr(String positionStr) {
            this.positionStr = positionStr;
        }

        public void setOpLevel(Integer opLevel) {
            this.opLevel = opLevel;
        }

        public void setStatusName(String statusName) {
            this.statusName = statusName;
        }

        public void setLoginAccount(String loginAccount) {
            this.loginAccount = loginAccount;
        }

        public void setOpContent(String opContent) {
            this.opContent = opContent;
        }

        public void setRejectReason(String rejectReason) {
            this.rejectReason = rejectReason;
        }

        public void setRejectFlagStr(String rejectFlagStr) {
            this.rejectFlagStr = rejectFlagStr;
        }

        public void setAcptChannel(Integer acptChannel) {
            this.acptChannel = acptChannel;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("OperatorToClaimTask:(");
            buffer.append("acptId:" + this.acptId);
            buffer.append(",acptType:" + this.acptType);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",fullName:" + this.fullName);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",acptBusinKind:" + this.acptBusinKind);
            buffer.append(",acptBusinId:" + this.acptBusinId);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",acceptDate:" + this.acceptDate);
            buffer.append(",acceptTime:" + this.acceptTime);
            buffer.append(",acptFormStatus:" + this.acptFormStatus);
            buffer.append(",workflowOrderId:" + this.workflowOrderId);
            buffer.append(",taskNo:" + this.taskNo);
            buffer.append(",lastOperatorNo:" + this.lastOperatorNo);
            buffer.append(",lastOperatorName:" + this.lastOperatorName);
            buffer.append(",organFlag:" + this.organFlag);
            buffer.append(",positionStr:" + this.positionStr);
            buffer.append(",opLevel:" + this.opLevel);
            buffer.append(",statusName:" + this.statusName);
            buffer.append(",loginAccount:" + this.loginAccount);
            buffer.append(",opContent:" + this.opContent);
            buffer.append(",rejectReason:" + this.rejectReason);
            buffer.append(",rejectFlagStr:" + this.rejectFlagStr);
            buffer.append(",acptChannel:" + this.acptChannel);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.acptId);
            builder.append(this.acptType);
            builder.append(this.fundAccount);
            builder.append(this.clientId);
            builder.append(this.fullName);
            builder.append(this.branchNo);
            builder.append(this.acptBusinKind);
            builder.append(this.acptBusinId);
            builder.append(this.operatorNo);
            builder.append(this.opBranchNo);
            builder.append(this.acceptDate);
            builder.append(this.acceptTime);
            builder.append(this.acptFormStatus);
            builder.append(this.workflowOrderId);
            builder.append(this.taskNo);
            builder.append(this.lastOperatorNo);
            builder.append(this.lastOperatorName);
            builder.append(this.organFlag);
            builder.append(this.positionStr);
            builder.append(this.opLevel);
            builder.append(this.statusName);
            builder.append(this.loginAccount);
            builder.append(this.opContent);
            builder.append(this.rejectReason);
            builder.append(this.rejectFlagStr);
            builder.append(this.acptChannel);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.OperatorToClaimTask) {
                InnerBpsService.OperatorToClaimTask test = (InnerBpsService.OperatorToClaimTask)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.acptId, test.acptId);
                builder.append(this.acptType, test.acptType);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.clientId, test.clientId);
                builder.append(this.fullName, test.fullName);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.acptBusinKind, test.acptBusinKind);
                builder.append(this.acptBusinId, test.acptBusinId);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.acceptDate, test.acceptDate);
                builder.append(this.acceptTime, test.acceptTime);
                builder.append(this.acptFormStatus, test.acptFormStatus);
                builder.append(this.workflowOrderId, test.workflowOrderId);
                builder.append(this.taskNo, test.taskNo);
                builder.append(this.lastOperatorNo, test.lastOperatorNo);
                builder.append(this.lastOperatorName, test.lastOperatorName);
                builder.append(this.organFlag, test.organFlag);
                builder.append(this.positionStr, test.positionStr);
                builder.append(this.opLevel, test.opLevel);
                builder.append(this.statusName, test.statusName);
                builder.append(this.loginAccount, test.loginAccount);
                builder.append(this.opContent, test.opContent);
                builder.append(this.rejectReason, test.rejectReason);
                builder.append(this.rejectFlagStr, test.rejectFlagStr);
                builder.append(this.acptChannel, test.acptChannel);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class OperatorHasDoneTaskDTO implements Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String taskNo = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String acptId = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character organFlag = ' ';
        private Integer branchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String clientId = " ";
        @SinogramLength(
                min = 0,
                max = 180,
                charset = "utf-8"
        )
        private String fullName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character idKind = ' ';
        @SinogramLength(
                min = 0,
                max = 40,
                charset = "utf-8"
        )
        private String idNo = " ";
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 60,
                charset = "utf-8"
        )
        private String operatorName = " ";
        private Integer auditBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 16,
                charset = "utf-8"
        )
        private String auditorNo = " ";
        @SinogramLength(
                min = 0,
                max = 180,
                charset = "utf-8"
        )
        private String auditorName = " ";
        private Integer opLevel = 0;
        @SinogramLength(
                min = 0,
                max = 10,
                charset = "utf-8"
        )
        private String acptBusinId = " ";
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String acptBusinKind = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String businodeName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character businodeKind = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character dealStatus = ' ';
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String remark = " ";
        private Integer acceptDate = 0;
        private Integer acceptTime = 0;
        private Integer dealDate = 0;
        private Integer dealTime = 0;
        private Integer dateClear = 0;
        @SinogramLength(
                min = 0,
                max = 100,
                charset = "utf-8"
        )
        private String positionStr = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character acptType = ' ';
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fundAccount = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String humanNode = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character acptFormStatus = ' ';

        public OperatorHasDoneTaskDTO() {
        }

        public String getTaskNo() {
            if (this.taskNo == null) {
                return " ";
            } else {
                return this.taskNo.isEmpty() ? " " : this.taskNo;
            }
        }

        public String getAcptId() {
            if (this.acptId == null) {
                return " ";
            } else {
                return this.acptId.isEmpty() ? " " : this.acptId;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Character getOrganFlag() {
            return this.organFlag != null ? this.organFlag : ' ';
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getFullName() {
            if (this.fullName == null) {
                return " ";
            } else {
                return this.fullName.isEmpty() ? " " : this.fullName;
            }
        }

        public Character getIdKind() {
            return this.idKind != null ? this.idKind : ' ';
        }

        public String getIdNo() {
            if (this.idNo == null) {
                return " ";
            } else {
                return this.idNo.isEmpty() ? " " : this.idNo;
            }
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOperatorName() {
            if (this.operatorName == null) {
                return " ";
            } else {
                return this.operatorName.isEmpty() ? " " : this.operatorName;
            }
        }

        public Integer getAuditBranchNo() {
            return this.auditBranchNo != null ? this.auditBranchNo : 0;
        }

        public String getAuditorNo() {
            if (this.auditorNo == null) {
                return " ";
            } else {
                return this.auditorNo.isEmpty() ? " " : this.auditorNo;
            }
        }

        public String getAuditorName() {
            if (this.auditorName == null) {
                return " ";
            } else {
                return this.auditorName.isEmpty() ? " " : this.auditorName;
            }
        }

        public Integer getOpLevel() {
            return this.opLevel != null ? this.opLevel : 0;
        }

        public String getAcptBusinId() {
            if (this.acptBusinId == null) {
                return " ";
            } else {
                return this.acptBusinId.isEmpty() ? " " : this.acptBusinId;
            }
        }

        public String getAcptBusinKind() {
            if (this.acptBusinKind == null) {
                return " ";
            } else {
                return this.acptBusinKind.isEmpty() ? " " : this.acptBusinKind;
            }
        }

        public String getBusinodeName() {
            if (this.businodeName == null) {
                return " ";
            } else {
                return this.businodeName.isEmpty() ? " " : this.businodeName;
            }
        }

        public Character getBusinodeKind() {
            return this.businodeKind != null ? this.businodeKind : ' ';
        }

        public Character getDealStatus() {
            return this.dealStatus != null ? this.dealStatus : ' ';
        }

        public String getRemark() {
            if (this.remark == null) {
                return " ";
            } else {
                return this.remark.isEmpty() ? " " : this.remark;
            }
        }

        public Integer getAcceptDate() {
            return this.acceptDate != null ? this.acceptDate : 0;
        }

        public Integer getAcceptTime() {
            return this.acceptTime != null ? this.acceptTime : 0;
        }

        public Integer getDealDate() {
            return this.dealDate != null ? this.dealDate : 0;
        }

        public Integer getDealTime() {
            return this.dealTime != null ? this.dealTime : 0;
        }

        public Integer getDateClear() {
            return this.dateClear != null ? this.dateClear : 0;
        }

        public String getPositionStr() {
            if (this.positionStr == null) {
                return " ";
            } else {
                return this.positionStr.isEmpty() ? " " : this.positionStr;
            }
        }

        public Character getAcptType() {
            return this.acptType != null ? this.acptType : ' ';
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getHumanNode() {
            if (this.humanNode == null) {
                return " ";
            } else {
                return this.humanNode.isEmpty() ? " " : this.humanNode;
            }
        }

        public Character getAcptFormStatus() {
            return this.acptFormStatus != null ? this.acptFormStatus : ' ';
        }

        public void setTaskNo(String taskNo) {
            this.taskNo = taskNo;
        }

        public void setAcptId(String acptId) {
            this.acptId = acptId;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOrganFlag(Character organFlag) {
            this.organFlag = organFlag;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setFullName(String fullName) {
            this.fullName = fullName;
        }

        public void setIdKind(Character idKind) {
            this.idKind = idKind;
        }

        public void setIdNo(String idNo) {
            this.idNo = idNo;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOperatorName(String operatorName) {
            this.operatorName = operatorName;
        }

        public void setAuditBranchNo(Integer auditBranchNo) {
            this.auditBranchNo = auditBranchNo;
        }

        public void setAuditorNo(String auditorNo) {
            this.auditorNo = auditorNo;
        }

        public void setAuditorName(String auditorName) {
            this.auditorName = auditorName;
        }

        public void setOpLevel(Integer opLevel) {
            this.opLevel = opLevel;
        }

        public void setAcptBusinId(String acptBusinId) {
            this.acptBusinId = acptBusinId;
        }

        public void setAcptBusinKind(String acptBusinKind) {
            this.acptBusinKind = acptBusinKind;
        }

        public void setBusinodeName(String businodeName) {
            this.businodeName = businodeName;
        }

        public void setBusinodeKind(Character businodeKind) {
            this.businodeKind = businodeKind;
        }

        public void setDealStatus(Character dealStatus) {
            this.dealStatus = dealStatus;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public void setAcceptDate(Integer acceptDate) {
            this.acceptDate = acceptDate;
        }

        public void setAcceptTime(Integer acceptTime) {
            this.acceptTime = acceptTime;
        }

        public void setDealDate(Integer dealDate) {
            this.dealDate = dealDate;
        }

        public void setDealTime(Integer dealTime) {
            this.dealTime = dealTime;
        }

        public void setDateClear(Integer dateClear) {
            this.dateClear = dateClear;
        }

        public void setPositionStr(String positionStr) {
            this.positionStr = positionStr;
        }

        public void setAcptType(Character acptType) {
            this.acptType = acptType;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setHumanNode(String humanNode) {
            this.humanNode = humanNode;
        }

        public void setAcptFormStatus(Character acptFormStatus) {
            this.acptFormStatus = acptFormStatus;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("OperatorHasDoneTaskDTO:(");
            buffer.append("taskNo:" + this.taskNo);
            buffer.append(",acptId:" + this.acptId);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",organFlag:" + this.organFlag);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",fullName:" + this.fullName);
            buffer.append(",idKind:" + this.idKind);
            buffer.append(",idNo:" + this.idNo);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",operatorName:" + this.operatorName);
            buffer.append(",auditBranchNo:" + this.auditBranchNo);
            buffer.append(",auditorNo:" + this.auditorNo);
            buffer.append(",auditorName:" + this.auditorName);
            buffer.append(",opLevel:" + this.opLevel);
            buffer.append(",acptBusinId:" + this.acptBusinId);
            buffer.append(",acptBusinKind:" + this.acptBusinKind);
            buffer.append(",businodeName:" + this.businodeName);
            buffer.append(",businodeKind:" + this.businodeKind);
            buffer.append(",dealStatus:" + this.dealStatus);
            buffer.append(",remark:" + this.remark);
            buffer.append(",acceptDate:" + this.acceptDate);
            buffer.append(",acceptTime:" + this.acceptTime);
            buffer.append(",dealDate:" + this.dealDate);
            buffer.append(",dealTime:" + this.dealTime);
            buffer.append(",dateClear:" + this.dateClear);
            buffer.append(",positionStr:" + this.positionStr);
            buffer.append(",acptType:" + this.acptType);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",humanNode:" + this.humanNode);
            buffer.append(",acptFormStatus:" + this.acptFormStatus);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.taskNo);
            builder.append(this.acptId);
            builder.append(this.opEntrustWay);
            builder.append(this.organFlag);
            builder.append(this.branchNo);
            builder.append(this.clientId);
            builder.append(this.fullName);
            builder.append(this.idKind);
            builder.append(this.idNo);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.operatorName);
            builder.append(this.auditBranchNo);
            builder.append(this.auditorNo);
            builder.append(this.auditorName);
            builder.append(this.opLevel);
            builder.append(this.acptBusinId);
            builder.append(this.acptBusinKind);
            builder.append(this.businodeName);
            builder.append(this.businodeKind);
            builder.append(this.dealStatus);
            builder.append(this.remark);
            builder.append(this.acceptDate);
            builder.append(this.acceptTime);
            builder.append(this.dealDate);
            builder.append(this.dealTime);
            builder.append(this.dateClear);
            builder.append(this.positionStr);
            builder.append(this.acptType);
            builder.append(this.fundAccount);
            builder.append(this.humanNode);
            builder.append(this.acptFormStatus);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.OperatorHasDoneTaskDTO) {
                InnerBpsService.OperatorHasDoneTaskDTO test = (InnerBpsService.OperatorHasDoneTaskDTO)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.taskNo, test.taskNo);
                builder.append(this.acptId, test.acptId);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.organFlag, test.organFlag);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.clientId, test.clientId);
                builder.append(this.fullName, test.fullName);
                builder.append(this.idKind, test.idKind);
                builder.append(this.idNo, test.idNo);
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.operatorName, test.operatorName);
                builder.append(this.auditBranchNo, test.auditBranchNo);
                builder.append(this.auditorNo, test.auditorNo);
                builder.append(this.auditorName, test.auditorName);
                builder.append(this.opLevel, test.opLevel);
                builder.append(this.acptBusinId, test.acptBusinId);
                builder.append(this.acptBusinKind, test.acptBusinKind);
                builder.append(this.businodeName, test.businodeName);
                builder.append(this.businodeKind, test.businodeKind);
                builder.append(this.dealStatus, test.dealStatus);
                builder.append(this.remark, test.remark);
                builder.append(this.acceptDate, test.acceptDate);
                builder.append(this.acceptTime, test.acceptTime);
                builder.append(this.dealDate, test.dealDate);
                builder.append(this.dealTime, test.dealTime);
                builder.append(this.dateClear, test.dateClear);
                builder.append(this.positionStr, test.positionStr);
                builder.append(this.acptType, test.acptType);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.humanNode, test.humanNode);
                builder.append(this.acptFormStatus, test.acptFormStatus);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class ArchfilelistDTO implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer archBusinessSysId = 0;
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String acptId = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fileStorageId = " ";
        @SinogramLength(
                min = 0,
                max = 6,
                charset = "utf-8"
        )
        private String archFileNo = " ";
        private Integer createDate = 0;
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String auditInfo = " ";
        private Integer createTime = 0;
        private Long fileSize = 0L;
        @SinogramLength(
                min = 0,
                max = 8000,
                charset = "utf-8"
        )
        private String imageData = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character archFileType = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character entrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String filePath = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String fileName = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String fileMd564 = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character uploadEndFlag = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character imageSet = ' ';
        private Integer pageNum = 0;
        @SinogramLength(
                min = 0,
                max = 6000,
                charset = "utf-8"
        )
        private String spriteIndex = " ";
        private Integer archAuditStatus = 0;
        @SinogramLength(
                min = 0,
                max = 4000,
                charset = "utf-8"
        )
        private String ocrMsg = " ";
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String thumbnailUrl = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String thumbnailStorageId = " ";
        private Long templateId = 0L;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character haveScan = ' ';
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String imageName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character registedFlag = ' ';

        public ArchfilelistDTO() {
        }

        public Integer getArchBusinessSysId() {
            return this.archBusinessSysId != null ? this.archBusinessSysId : 0;
        }

        public String getAcptId() {
            if (this.acptId == null) {
                return " ";
            } else {
                return this.acptId.isEmpty() ? " " : this.acptId;
            }
        }

        public String getFileStorageId() {
            if (this.fileStorageId == null) {
                return " ";
            } else {
                return this.fileStorageId.isEmpty() ? " " : this.fileStorageId;
            }
        }

        public String getArchFileNo() {
            if (this.archFileNo == null) {
                return " ";
            } else {
                return this.archFileNo.isEmpty() ? " " : this.archFileNo;
            }
        }

        public Integer getCreateDate() {
            return this.createDate != null ? this.createDate : 0;
        }

        public String getAuditInfo() {
            if (this.auditInfo == null) {
                return " ";
            } else {
                return this.auditInfo.isEmpty() ? " " : this.auditInfo;
            }
        }

        public Integer getCreateTime() {
            return this.createTime != null ? this.createTime : 0;
        }

        public Long getFileSize() {
            return this.fileSize != null ? this.fileSize : 0L;
        }

        public String getImageData() {
            if (this.imageData == null) {
                return " ";
            } else {
                return this.imageData.isEmpty() ? " " : this.imageData;
            }
        }

        public Character getArchFileType() {
            return this.archFileType != null ? this.archFileType : ' ';
        }

        public Character getEntrustWay() {
            return this.entrustWay != null ? this.entrustWay : ' ';
        }

        public String getFilePath() {
            if (this.filePath == null) {
                return " ";
            } else {
                return this.filePath.isEmpty() ? " " : this.filePath;
            }
        }

        public String getFileName() {
            if (this.fileName == null) {
                return " ";
            } else {
                return this.fileName.isEmpty() ? " " : this.fileName;
            }
        }

        public String getFileMd564() {
            if (this.fileMd564 == null) {
                return " ";
            } else {
                return this.fileMd564.isEmpty() ? " " : this.fileMd564;
            }
        }

        public Character getUploadEndFlag() {
            return this.uploadEndFlag != null ? this.uploadEndFlag : ' ';
        }

        public Character getImageSet() {
            return this.imageSet != null ? this.imageSet : ' ';
        }

        public Integer getPageNum() {
            return this.pageNum != null ? this.pageNum : 0;
        }

        public String getSpriteIndex() {
            if (this.spriteIndex == null) {
                return " ";
            } else {
                return this.spriteIndex.isEmpty() ? " " : this.spriteIndex;
            }
        }

        public Integer getArchAuditStatus() {
            return this.archAuditStatus != null ? this.archAuditStatus : 0;
        }

        public String getOcrMsg() {
            if (this.ocrMsg == null) {
                return " ";
            } else {
                return this.ocrMsg.isEmpty() ? " " : this.ocrMsg;
            }
        }

        public String getThumbnailUrl() {
            if (this.thumbnailUrl == null) {
                return " ";
            } else {
                return this.thumbnailUrl.isEmpty() ? " " : this.thumbnailUrl;
            }
        }

        public String getThumbnailStorageId() {
            if (this.thumbnailStorageId == null) {
                return " ";
            } else {
                return this.thumbnailStorageId.isEmpty() ? " " : this.thumbnailStorageId;
            }
        }

        public Long getTemplateId() {
            return this.templateId != null ? this.templateId : 0L;
        }

        public Character getHaveScan() {
            return this.haveScan != null ? this.haveScan : ' ';
        }

        public String getImageName() {
            if (this.imageName == null) {
                return " ";
            } else {
                return this.imageName.isEmpty() ? " " : this.imageName;
            }
        }

        public Character getRegistedFlag() {
            return this.registedFlag != null ? this.registedFlag : ' ';
        }

        public void setArchBusinessSysId(Integer archBusinessSysId) {
            this.archBusinessSysId = archBusinessSysId;
        }

        public void setAcptId(String acptId) {
            this.acptId = acptId;
        }

        public void setFileStorageId(String fileStorageId) {
            this.fileStorageId = fileStorageId;
        }

        public void setArchFileNo(String archFileNo) {
            this.archFileNo = archFileNo;
        }

        public void setCreateDate(Integer createDate) {
            this.createDate = createDate;
        }

        public void setAuditInfo(String auditInfo) {
            this.auditInfo = auditInfo;
        }

        public void setCreateTime(Integer createTime) {
            this.createTime = createTime;
        }

        public void setFileSize(Long fileSize) {
            this.fileSize = fileSize;
        }

        public void setImageData(String imageData) {
            this.imageData = imageData;
        }

        public void setArchFileType(Character archFileType) {
            this.archFileType = archFileType;
        }

        public void setEntrustWay(Character entrustWay) {
            this.entrustWay = entrustWay;
        }

        public void setFilePath(String filePath) {
            this.filePath = filePath;
        }

        public void setFileName(String fileName) {
            this.fileName = fileName;
        }

        public void setFileMd564(String fileMd564) {
            this.fileMd564 = fileMd564;
        }

        public void setUploadEndFlag(Character uploadEndFlag) {
            this.uploadEndFlag = uploadEndFlag;
        }

        public void setImageSet(Character imageSet) {
            this.imageSet = imageSet;
        }

        public void setPageNum(Integer pageNum) {
            this.pageNum = pageNum;
        }

        public void setSpriteIndex(String spriteIndex) {
            this.spriteIndex = spriteIndex;
        }

        public void setArchAuditStatus(Integer archAuditStatus) {
            this.archAuditStatus = archAuditStatus;
        }

        public void setOcrMsg(String ocrMsg) {
            this.ocrMsg = ocrMsg;
        }

        public void setThumbnailUrl(String thumbnailUrl) {
            this.thumbnailUrl = thumbnailUrl;
        }

        public void setThumbnailStorageId(String thumbnailStorageId) {
            this.thumbnailStorageId = thumbnailStorageId;
        }

        public void setTemplateId(Long templateId) {
            this.templateId = templateId;
        }

        public void setHaveScan(Character haveScan) {
            this.haveScan = haveScan;
        }

        public void setImageName(String imageName) {
            this.imageName = imageName;
        }

        public void setRegistedFlag(Character registedFlag) {
            this.registedFlag = registedFlag;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("ArchfilelistDTO:(");
            buffer.append("archBusinessSysId:" + this.archBusinessSysId);
            buffer.append(",acptId:" + this.acptId);
            buffer.append(",fileStorageId:" + this.fileStorageId);
            buffer.append(",archFileNo:" + this.archFileNo);
            buffer.append(",createDate:" + this.createDate);
            buffer.append(",auditInfo:" + this.auditInfo);
            buffer.append(",createTime:" + this.createTime);
            buffer.append(",fileSize:" + this.fileSize);
            buffer.append(",imageData:" + this.imageData);
            buffer.append(",archFileType:" + this.archFileType);
            buffer.append(",entrustWay:" + this.entrustWay);
            buffer.append(",filePath:" + this.filePath);
            buffer.append(",fileName:" + this.fileName);
            buffer.append(",fileMd564:" + this.fileMd564);
            buffer.append(",uploadEndFlag:" + this.uploadEndFlag);
            buffer.append(",imageSet:" + this.imageSet);
            buffer.append(",pageNum:" + this.pageNum);
            buffer.append(",spriteIndex:" + this.spriteIndex);
            buffer.append(",archAuditStatus:" + this.archAuditStatus);
            buffer.append(",ocrMsg:" + this.ocrMsg);
            buffer.append(",thumbnailUrl:" + this.thumbnailUrl);
            buffer.append(",thumbnailStorageId:" + this.thumbnailStorageId);
            buffer.append(",templateId:" + this.templateId);
            buffer.append(",haveScan:" + this.haveScan);
            buffer.append(",imageName:" + this.imageName);
            buffer.append(",registedFlag:" + this.registedFlag);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.archBusinessSysId);
            builder.append(this.acptId);
            builder.append(this.fileStorageId);
            builder.append(this.archFileNo);
            builder.append(this.createDate);
            builder.append(this.auditInfo);
            builder.append(this.createTime);
            builder.append(this.fileSize);
            builder.append(this.imageData);
            builder.append(this.archFileType);
            builder.append(this.entrustWay);
            builder.append(this.filePath);
            builder.append(this.fileName);
            builder.append(this.fileMd564);
            builder.append(this.uploadEndFlag);
            builder.append(this.imageSet);
            builder.append(this.pageNum);
            builder.append(this.spriteIndex);
            builder.append(this.archAuditStatus);
            builder.append(this.ocrMsg);
            builder.append(this.thumbnailUrl);
            builder.append(this.thumbnailStorageId);
            builder.append(this.templateId);
            builder.append(this.haveScan);
            builder.append(this.imageName);
            builder.append(this.registedFlag);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.ArchfilelistDTO) {
                InnerBpsService.ArchfilelistDTO test = (InnerBpsService.ArchfilelistDTO)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.archBusinessSysId, test.archBusinessSysId);
                builder.append(this.acptId, test.acptId);
                builder.append(this.fileStorageId, test.fileStorageId);
                builder.append(this.archFileNo, test.archFileNo);
                builder.append(this.createDate, test.createDate);
                builder.append(this.auditInfo, test.auditInfo);
                builder.append(this.createTime, test.createTime);
                builder.append(this.fileSize, test.fileSize);
                builder.append(this.imageData, test.imageData);
                builder.append(this.archFileType, test.archFileType);
                builder.append(this.entrustWay, test.entrustWay);
                builder.append(this.filePath, test.filePath);
                builder.append(this.fileName, test.fileName);
                builder.append(this.fileMd564, test.fileMd564);
                builder.append(this.uploadEndFlag, test.uploadEndFlag);
                builder.append(this.imageSet, test.imageSet);
                builder.append(this.pageNum, test.pageNum);
                builder.append(this.spriteIndex, test.spriteIndex);
                builder.append(this.archAuditStatus, test.archAuditStatus);
                builder.append(this.ocrMsg, test.ocrMsg);
                builder.append(this.thumbnailUrl, test.thumbnailUrl);
                builder.append(this.thumbnailStorageId, test.thumbnailStorageId);
                builder.append(this.templateId, test.templateId);
                builder.append(this.haveScan, test.haveScan);
                builder.append(this.imageName, test.imageName);
                builder.append(this.registedFlag, test.registedFlag);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class AcptformDTO implements Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String acptId = " ";
        @SinogramLength(
                min = 0,
                max = 10,
                charset = "utf-8"
        )
        private String acptBusinId = " ";
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String acptBusinKind = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character acptFormStatus = ' ';
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String workflowOrderId = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fundAccount = " ";
        private Integer branchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String clientId = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        private Integer opBranchNo = 0;
        private Integer acceptDate = 0;
        private Integer acceptTime = 0;
        private Integer dealDate = 0;
        private Integer dealTime = 0;
        private Integer dateClear = 0;
        @SinogramLength(
                min = 0,
                max = 100,
                charset = "utf-8"
        )
        private String positionStr = " ";
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String remark = " ";
        private Integer errorNoInner = 0;
        @SinogramLength(
                min = 0,
                max = 500,
                charset = "utf-8"
        )
        private String errorInfoInner = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character resend = ' ';
        private Integer initDate = 0;
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String columnStr = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @SinogramLength(
                min = 0,
                max = 180,
                charset = "utf-8"
        )
        private String fullName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character idKind = ' ';
        @SinogramLength(
                min = 0,
                max = 40,
                charset = "utf-8"
        )
        private String idNo = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character organFlag = ' ';
        private Integer opLevel = 0;
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String acptEnrouteField = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String rejectFlagStr = " ";
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String rejectReason = " ";
        private Integer acptChannel = 0;
        @SinogramLength(
                min = 0,
                max = 60,
                charset = "utf-8"
        )
        private String operatorName = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String custId = " ";
        private Integer count = 0;
        @SinogramLength(
                min = 0,
                max = 180,
                charset = "utf-8"
        )
        private String acptCategoryName = " ";

        public AcptformDTO() {
        }

        public String getAcptId() {
            if (this.acptId == null) {
                return " ";
            } else {
                return this.acptId.isEmpty() ? " " : this.acptId;
            }
        }

        public String getAcptBusinId() {
            if (this.acptBusinId == null) {
                return " ";
            } else {
                return this.acptBusinId.isEmpty() ? " " : this.acptBusinId;
            }
        }

        public String getAcptBusinKind() {
            if (this.acptBusinKind == null) {
                return " ";
            } else {
                return this.acptBusinKind.isEmpty() ? " " : this.acptBusinKind;
            }
        }

        public Character getAcptFormStatus() {
            return this.acptFormStatus != null ? this.acptFormStatus : ' ';
        }

        public String getWorkflowOrderId() {
            if (this.workflowOrderId == null) {
                return " ";
            } else {
                return this.workflowOrderId.isEmpty() ? " " : this.workflowOrderId;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public Integer getAcceptDate() {
            return this.acceptDate != null ? this.acceptDate : 0;
        }

        public Integer getAcceptTime() {
            return this.acceptTime != null ? this.acceptTime : 0;
        }

        public Integer getDealDate() {
            return this.dealDate != null ? this.dealDate : 0;
        }

        public Integer getDealTime() {
            return this.dealTime != null ? this.dealTime : 0;
        }

        public Integer getDateClear() {
            return this.dateClear != null ? this.dateClear : 0;
        }

        public String getPositionStr() {
            if (this.positionStr == null) {
                return " ";
            } else {
                return this.positionStr.isEmpty() ? " " : this.positionStr;
            }
        }

        public String getRemark() {
            if (this.remark == null) {
                return " ";
            } else {
                return this.remark.isEmpty() ? " " : this.remark;
            }
        }

        public Integer getErrorNoInner() {
            return this.errorNoInner != null ? this.errorNoInner : 0;
        }

        public String getErrorInfoInner() {
            if (this.errorInfoInner == null) {
                return " ";
            } else {
                return this.errorInfoInner.isEmpty() ? " " : this.errorInfoInner;
            }
        }

        public Character getResend() {
            return this.resend != null ? this.resend : ' ';
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public String getColumnStr() {
            if (this.columnStr == null) {
                return " ";
            } else {
                return this.columnStr.isEmpty() ? " " : this.columnStr;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public String getFullName() {
            if (this.fullName == null) {
                return " ";
            } else {
                return this.fullName.isEmpty() ? " " : this.fullName;
            }
        }

        public Character getIdKind() {
            return this.idKind != null ? this.idKind : ' ';
        }

        public String getIdNo() {
            if (this.idNo == null) {
                return " ";
            } else {
                return this.idNo.isEmpty() ? " " : this.idNo;
            }
        }

        public Character getOrganFlag() {
            return this.organFlag != null ? this.organFlag : ' ';
        }

        public Integer getOpLevel() {
            return this.opLevel != null ? this.opLevel : 0;
        }

        public String getAcptEnrouteField() {
            if (this.acptEnrouteField == null) {
                return " ";
            } else {
                return this.acptEnrouteField.isEmpty() ? " " : this.acptEnrouteField;
            }
        }

        public String getRejectFlagStr() {
            if (this.rejectFlagStr == null) {
                return " ";
            } else {
                return this.rejectFlagStr.isEmpty() ? " " : this.rejectFlagStr;
            }
        }

        public String getRejectReason() {
            if (this.rejectReason == null) {
                return " ";
            } else {
                return this.rejectReason.isEmpty() ? " " : this.rejectReason;
            }
        }

        public Integer getAcptChannel() {
            return this.acptChannel != null ? this.acptChannel : 0;
        }

        public String getOperatorName() {
            if (this.operatorName == null) {
                return " ";
            } else {
                return this.operatorName.isEmpty() ? " " : this.operatorName;
            }
        }

        public String getCustId() {
            if (this.custId == null) {
                return " ";
            } else {
                return this.custId.isEmpty() ? " " : this.custId;
            }
        }

        public Integer getCount() {
            return this.count != null ? this.count : 0;
        }

        public String getAcptCategoryName() {
            if (this.acptCategoryName == null) {
                return " ";
            } else {
                return this.acptCategoryName.isEmpty() ? " " : this.acptCategoryName;
            }
        }

        public void setAcptId(String acptId) {
            this.acptId = acptId;
        }

        public void setAcptBusinId(String acptBusinId) {
            this.acptBusinId = acptBusinId;
        }

        public void setAcptBusinKind(String acptBusinKind) {
            this.acptBusinKind = acptBusinKind;
        }

        public void setAcptFormStatus(Character acptFormStatus) {
            this.acptFormStatus = acptFormStatus;
        }

        public void setWorkflowOrderId(String workflowOrderId) {
            this.workflowOrderId = workflowOrderId;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setAcceptDate(Integer acceptDate) {
            this.acceptDate = acceptDate;
        }

        public void setAcceptTime(Integer acceptTime) {
            this.acceptTime = acceptTime;
        }

        public void setDealDate(Integer dealDate) {
            this.dealDate = dealDate;
        }

        public void setDealTime(Integer dealTime) {
            this.dealTime = dealTime;
        }

        public void setDateClear(Integer dateClear) {
            this.dateClear = dateClear;
        }

        public void setPositionStr(String positionStr) {
            this.positionStr = positionStr;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public void setErrorNoInner(Integer errorNoInner) {
            this.errorNoInner = errorNoInner;
        }

        public void setErrorInfoInner(String errorInfoInner) {
            this.errorInfoInner = errorInfoInner;
        }

        public void setResend(Character resend) {
            this.resend = resend;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public void setColumnStr(String columnStr) {
            this.columnStr = columnStr;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setFullName(String fullName) {
            this.fullName = fullName;
        }

        public void setIdKind(Character idKind) {
            this.idKind = idKind;
        }

        public void setIdNo(String idNo) {
            this.idNo = idNo;
        }

        public void setOrganFlag(Character organFlag) {
            this.organFlag = organFlag;
        }

        public void setOpLevel(Integer opLevel) {
            this.opLevel = opLevel;
        }

        public void setAcptEnrouteField(String acptEnrouteField) {
            this.acptEnrouteField = acptEnrouteField;
        }

        public void setRejectFlagStr(String rejectFlagStr) {
            this.rejectFlagStr = rejectFlagStr;
        }

        public void setRejectReason(String rejectReason) {
            this.rejectReason = rejectReason;
        }

        public void setAcptChannel(Integer acptChannel) {
            this.acptChannel = acptChannel;
        }

        public void setOperatorName(String operatorName) {
            this.operatorName = operatorName;
        }

        public void setCustId(String custId) {
            this.custId = custId;
        }

        public void setCount(Integer count) {
            this.count = count;
        }

        public void setAcptCategoryName(String acptCategoryName) {
            this.acptCategoryName = acptCategoryName;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("AcptformDTO:(");
            buffer.append("acptId:" + this.acptId);
            buffer.append(",acptBusinId:" + this.acptBusinId);
            buffer.append(",acptBusinKind:" + this.acptBusinKind);
            buffer.append(",acptFormStatus:" + this.acptFormStatus);
            buffer.append(",workflowOrderId:" + this.workflowOrderId);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",acceptDate:" + this.acceptDate);
            buffer.append(",acceptTime:" + this.acceptTime);
            buffer.append(",dealDate:" + this.dealDate);
            buffer.append(",dealTime:" + this.dealTime);
            buffer.append(",dateClear:" + this.dateClear);
            buffer.append(",positionStr:" + this.positionStr);
            buffer.append(",remark:" + this.remark);
            buffer.append(",errorNoInner:" + this.errorNoInner);
            buffer.append(",errorInfoInner:" + this.errorInfoInner);
            buffer.append(",resend:" + this.resend);
            buffer.append(",initDate:" + this.initDate);
            buffer.append(",columnStr:" + this.columnStr);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",fullName:" + this.fullName);
            buffer.append(",idKind:" + this.idKind);
            buffer.append(",idNo:" + this.idNo);
            buffer.append(",organFlag:" + this.organFlag);
            buffer.append(",opLevel:" + this.opLevel);
            buffer.append(",acptEnrouteField:" + this.acptEnrouteField);
            buffer.append(",rejectFlagStr:" + this.rejectFlagStr);
            buffer.append(",rejectReason:" + this.rejectReason);
            buffer.append(",acptChannel:" + this.acptChannel);
            buffer.append(",operatorName:" + this.operatorName);
            buffer.append(",custId:" + this.custId);
            buffer.append(",count:" + this.count);
            buffer.append(",acptCategoryName:" + this.acptCategoryName);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.acptId);
            builder.append(this.acptBusinId);
            builder.append(this.acptBusinKind);
            builder.append(this.acptFormStatus);
            builder.append(this.workflowOrderId);
            builder.append(this.opEntrustWay);
            builder.append(this.fundAccount);
            builder.append(this.branchNo);
            builder.append(this.clientId);
            builder.append(this.operatorNo);
            builder.append(this.opBranchNo);
            builder.append(this.acceptDate);
            builder.append(this.acceptTime);
            builder.append(this.dealDate);
            builder.append(this.dealTime);
            builder.append(this.dateClear);
            builder.append(this.positionStr);
            builder.append(this.remark);
            builder.append(this.errorNoInner);
            builder.append(this.errorInfoInner);
            builder.append(this.resend);
            builder.append(this.initDate);
            builder.append(this.columnStr);
            builder.append(this.opStation);
            builder.append(this.fullName);
            builder.append(this.idKind);
            builder.append(this.idNo);
            builder.append(this.organFlag);
            builder.append(this.opLevel);
            builder.append(this.acptEnrouteField);
            builder.append(this.rejectFlagStr);
            builder.append(this.rejectReason);
            builder.append(this.acptChannel);
            builder.append(this.operatorName);
            builder.append(this.custId);
            builder.append(this.count);
            builder.append(this.acptCategoryName);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.AcptformDTO) {
                InnerBpsService.AcptformDTO test = (InnerBpsService.AcptformDTO)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.acptId, test.acptId);
                builder.append(this.acptBusinId, test.acptBusinId);
                builder.append(this.acptBusinKind, test.acptBusinKind);
                builder.append(this.acptFormStatus, test.acptFormStatus);
                builder.append(this.workflowOrderId, test.workflowOrderId);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.clientId, test.clientId);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.acceptDate, test.acceptDate);
                builder.append(this.acceptTime, test.acceptTime);
                builder.append(this.dealDate, test.dealDate);
                builder.append(this.dealTime, test.dealTime);
                builder.append(this.dateClear, test.dateClear);
                builder.append(this.positionStr, test.positionStr);
                builder.append(this.remark, test.remark);
                builder.append(this.errorNoInner, test.errorNoInner);
                builder.append(this.errorInfoInner, test.errorInfoInner);
                builder.append(this.resend, test.resend);
                builder.append(this.initDate, test.initDate);
                builder.append(this.columnStr, test.columnStr);
                builder.append(this.opStation, test.opStation);
                builder.append(this.fullName, test.fullName);
                builder.append(this.idKind, test.idKind);
                builder.append(this.idNo, test.idNo);
                builder.append(this.organFlag, test.organFlag);
                builder.append(this.opLevel, test.opLevel);
                builder.append(this.acptEnrouteField, test.acptEnrouteField);
                builder.append(this.rejectFlagStr, test.rejectFlagStr);
                builder.append(this.rejectReason, test.rejectReason);
                builder.append(this.acptChannel, test.acptChannel);
                builder.append(this.operatorName, test.operatorName);
                builder.append(this.custId, test.custId);
                builder.append(this.count, test.count);
                builder.append(this.acptCategoryName, test.acptCategoryName);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutBpstaskTerminateInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String opRemark = " ";

        public PutBpstaskTerminateInnerOutput() {
        }

        public String getOpRemark() {
            if (this.opRemark == null) {
                return " ";
            } else {
                return this.opRemark.isEmpty() ? " " : this.opRemark;
            }
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutBpstaskTerminateInnerOutput:(");
            buffer.append("opRemark:" + this.opRemark);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opRemark);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.PutBpstaskTerminateInnerOutput) {
                InnerBpsService.PutBpstaskTerminateInnerOutput test = (InnerBpsService.PutBpstaskTerminateInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opRemark, test.opRemark);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutBpstaskTerminateInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 60,
                charset = "utf-8"
        )
        private String operatorName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character useType = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String menuCode = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String functionStr = " ";
        private Integer branchNo = 0;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 32,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String acptId;
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String taskNo = " ";
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String remark = " ";

        public PutBpstaskTerminateInnerInput() {
        }

        public String getOperatorName() {
            if (this.operatorName == null) {
                return " ";
            } else {
                return this.operatorName.isEmpty() ? " " : this.operatorName;
            }
        }

        public Character getUseType() {
            return this.useType != null ? this.useType : ' ';
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getMenuCode() {
            if (this.menuCode == null) {
                return " ";
            } else {
                return this.menuCode.isEmpty() ? " " : this.menuCode;
            }
        }

        public String getFunctionStr() {
            if (this.functionStr == null) {
                return " ";
            } else {
                return this.functionStr.isEmpty() ? " " : this.functionStr;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getAcptId() {
            return this.acptId;
        }

        public String getTaskNo() {
            if (this.taskNo == null) {
                return " ";
            } else {
                return this.taskNo.isEmpty() ? " " : this.taskNo;
            }
        }

        public String getRemark() {
            if (this.remark == null) {
                return " ";
            } else {
                return this.remark.isEmpty() ? " " : this.remark;
            }
        }

        public void setOperatorName(String operatorName) {
            this.operatorName = operatorName;
        }

        public void setUseType(Character useType) {
            this.useType = useType;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setMenuCode(String menuCode) {
            this.menuCode = menuCode;
        }

        public void setFunctionStr(String functionStr) {
            this.functionStr = functionStr;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setAcptId(String acptId) {
            this.acptId = acptId;
        }

        public void setTaskNo(String taskNo) {
            this.taskNo = taskNo;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutBpstaskTerminateInnerInput:(");
            buffer.append("operatorName:" + this.operatorName);
            buffer.append(",useType:" + this.useType);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",menuCode:" + this.menuCode);
            buffer.append(",functionStr:" + this.functionStr);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",acptId:" + this.acptId);
            buffer.append(",taskNo:" + this.taskNo);
            buffer.append(",remark:" + this.remark);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.operatorName);
            builder.append(this.useType);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.menuCode);
            builder.append(this.functionStr);
            builder.append(this.branchNo);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.acptId);
            builder.append(this.taskNo);
            builder.append(this.remark);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.PutBpstaskTerminateInnerInput) {
                InnerBpsService.PutBpstaskTerminateInnerInput test = (InnerBpsService.PutBpstaskTerminateInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.operatorName, test.operatorName);
                builder.append(this.useType, test.useType);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.menuCode, test.menuCode);
                builder.append(this.functionStr, test.functionStr);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.acptId, test.acptId);
                builder.append(this.taskNo, test.taskNo);
                builder.append(this.remark, test.remark);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutBpstaskRejectInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String opRemark = " ";

        public PutBpstaskRejectInnerOutput() {
        }

        public String getOpRemark() {
            if (this.opRemark == null) {
                return " ";
            } else {
                return this.opRemark.isEmpty() ? " " : this.opRemark;
            }
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutBpstaskRejectInnerOutput:(");
            buffer.append("opRemark:" + this.opRemark);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opRemark);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.PutBpstaskRejectInnerOutput) {
                InnerBpsService.PutBpstaskRejectInnerOutput test = (InnerBpsService.PutBpstaskRejectInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opRemark, test.opRemark);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutBpstaskRejectInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 60,
                charset = "utf-8"
        )
        private String operatorName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character useType = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String menuCode = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String functionStr = " ";
        private Integer branchNo = 0;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String acptId = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String taskNo = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String rejectFlagStr = " ";
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String rejectReason = " ";
        @SinogramLength(
                min = 1,
                max = 180,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String nodeName;

        public PutBpstaskRejectInnerInput() {
        }

        public String getOperatorName() {
            if (this.operatorName == null) {
                return " ";
            } else {
                return this.operatorName.isEmpty() ? " " : this.operatorName;
            }
        }

        public Character getUseType() {
            return this.useType != null ? this.useType : ' ';
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getMenuCode() {
            if (this.menuCode == null) {
                return " ";
            } else {
                return this.menuCode.isEmpty() ? " " : this.menuCode;
            }
        }

        public String getFunctionStr() {
            if (this.functionStr == null) {
                return " ";
            } else {
                return this.functionStr.isEmpty() ? " " : this.functionStr;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getAcptId() {
            if (this.acptId == null) {
                return " ";
            } else {
                return this.acptId.isEmpty() ? " " : this.acptId;
            }
        }

        public String getTaskNo() {
            if (this.taskNo == null) {
                return " ";
            } else {
                return this.taskNo.isEmpty() ? " " : this.taskNo;
            }
        }

        public String getRejectFlagStr() {
            if (this.rejectFlagStr == null) {
                return " ";
            } else {
                return this.rejectFlagStr.isEmpty() ? " " : this.rejectFlagStr;
            }
        }

        public String getRejectReason() {
            if (this.rejectReason == null) {
                return " ";
            } else {
                return this.rejectReason.isEmpty() ? " " : this.rejectReason;
            }
        }

        public String getNodeName() {
            return this.nodeName;
        }

        public void setOperatorName(String operatorName) {
            this.operatorName = operatorName;
        }

        public void setUseType(Character useType) {
            this.useType = useType;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setMenuCode(String menuCode) {
            this.menuCode = menuCode;
        }

        public void setFunctionStr(String functionStr) {
            this.functionStr = functionStr;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setAcptId(String acptId) {
            this.acptId = acptId;
        }

        public void setTaskNo(String taskNo) {
            this.taskNo = taskNo;
        }

        public void setRejectFlagStr(String rejectFlagStr) {
            this.rejectFlagStr = rejectFlagStr;
        }

        public void setRejectReason(String rejectReason) {
            this.rejectReason = rejectReason;
        }

        public void setNodeName(String nodeName) {
            this.nodeName = nodeName;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutBpstaskRejectInnerInput:(");
            buffer.append("operatorName:" + this.operatorName);
            buffer.append(",useType:" + this.useType);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",menuCode:" + this.menuCode);
            buffer.append(",functionStr:" + this.functionStr);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",acptId:" + this.acptId);
            buffer.append(",taskNo:" + this.taskNo);
            buffer.append(",rejectFlagStr:" + this.rejectFlagStr);
            buffer.append(",rejectReason:" + this.rejectReason);
            buffer.append(",nodeName:" + this.nodeName);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.operatorName);
            builder.append(this.useType);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.menuCode);
            builder.append(this.functionStr);
            builder.append(this.branchNo);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.acptId);
            builder.append(this.taskNo);
            builder.append(this.rejectFlagStr);
            builder.append(this.rejectReason);
            builder.append(this.nodeName);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.PutBpstaskRejectInnerInput) {
                InnerBpsService.PutBpstaskRejectInnerInput test = (InnerBpsService.PutBpstaskRejectInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.operatorName, test.operatorName);
                builder.append(this.useType, test.useType);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.menuCode, test.menuCode);
                builder.append(this.functionStr, test.functionStr);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.acptId, test.acptId);
                builder.append(this.taskNo, test.taskNo);
                builder.append(this.rejectFlagStr, test.rejectFlagStr);
                builder.append(this.rejectReason, test.rejectReason);
                builder.append(this.nodeName, test.nodeName);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutBpstaskPassInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String opRemark = " ";

        public PutBpstaskPassInnerOutput() {
        }

        public String getOpRemark() {
            if (this.opRemark == null) {
                return " ";
            } else {
                return this.opRemark.isEmpty() ? " " : this.opRemark;
            }
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutBpstaskPassInnerOutput:(");
            buffer.append("opRemark:" + this.opRemark);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opRemark);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.PutBpstaskPassInnerOutput) {
                InnerBpsService.PutBpstaskPassInnerOutput test = (InnerBpsService.PutBpstaskPassInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opRemark, test.opRemark);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutBpstaskPassInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 60,
                charset = "utf-8"
        )
        private String operatorName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character useType = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String menuCode = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String functionStr = " ";
        private Integer branchNo = 0;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String acptId = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String taskNo = " ";
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String remark = " ";

        public PutBpstaskPassInnerInput() {
        }

        public String getOperatorName() {
            if (this.operatorName == null) {
                return " ";
            } else {
                return this.operatorName.isEmpty() ? " " : this.operatorName;
            }
        }

        public Character getUseType() {
            return this.useType != null ? this.useType : ' ';
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getMenuCode() {
            if (this.menuCode == null) {
                return " ";
            } else {
                return this.menuCode.isEmpty() ? " " : this.menuCode;
            }
        }

        public String getFunctionStr() {
            if (this.functionStr == null) {
                return " ";
            } else {
                return this.functionStr.isEmpty() ? " " : this.functionStr;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getAcptId() {
            if (this.acptId == null) {
                return " ";
            } else {
                return this.acptId.isEmpty() ? " " : this.acptId;
            }
        }

        public String getTaskNo() {
            if (this.taskNo == null) {
                return " ";
            } else {
                return this.taskNo.isEmpty() ? " " : this.taskNo;
            }
        }

        public String getRemark() {
            if (this.remark == null) {
                return " ";
            } else {
                return this.remark.isEmpty() ? " " : this.remark;
            }
        }

        public void setOperatorName(String operatorName) {
            this.operatorName = operatorName;
        }

        public void setUseType(Character useType) {
            this.useType = useType;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setMenuCode(String menuCode) {
            this.menuCode = menuCode;
        }

        public void setFunctionStr(String functionStr) {
            this.functionStr = functionStr;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setAcptId(String acptId) {
            this.acptId = acptId;
        }

        public void setTaskNo(String taskNo) {
            this.taskNo = taskNo;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutBpstaskPassInnerInput:(");
            buffer.append("operatorName:" + this.operatorName);
            buffer.append(",useType:" + this.useType);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",menuCode:" + this.menuCode);
            buffer.append(",functionStr:" + this.functionStr);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",acptId:" + this.acptId);
            buffer.append(",taskNo:" + this.taskNo);
            buffer.append(",remark:" + this.remark);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.operatorName);
            builder.append(this.useType);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.menuCode);
            builder.append(this.functionStr);
            builder.append(this.branchNo);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.acptId);
            builder.append(this.taskNo);
            builder.append(this.remark);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.PutBpstaskPassInnerInput) {
                InnerBpsService.PutBpstaskPassInnerInput test = (InnerBpsService.PutBpstaskPassInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.operatorName, test.operatorName);
                builder.append(this.useType, test.useType);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.menuCode, test.menuCode);
                builder.append(this.functionStr, test.functionStr);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.acptId, test.acptId);
                builder.append(this.taskNo, test.taskNo);
                builder.append(this.remark, test.remark);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutBpsAcptformInvalidInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Long serialNo = 0L;
        private String opRemark = " ";

        public PutBpsAcptformInvalidInnerOutput() {
        }

        public Long getSerialNo() {
            return this.serialNo != null ? this.serialNo : 0L;
        }

        public String getOpRemark() {
            if (this.opRemark == null) {
                return " ";
            } else {
                return this.opRemark.isEmpty() ? " " : this.opRemark;
            }
        }

        public void setSerialNo(Long serialNo) {
            this.serialNo = serialNo;
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutBpsAcptformInvalidInnerOutput:(");
            buffer.append("serialNo:" + this.serialNo);
            buffer.append(",opRemark:" + this.opRemark);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.serialNo);
            builder.append(this.opRemark);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.PutBpsAcptformInvalidInnerOutput) {
                InnerBpsService.PutBpsAcptformInvalidInnerOutput test = (InnerBpsService.PutBpsAcptformInvalidInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.serialNo, test.serialNo);
                builder.append(this.opRemark, test.opRemark);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutBpsAcptformInvalidInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 60,
                charset = "utf-8"
        )
        private String operatorName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character useType = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String menuCode = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String functionStr = " ";
        private Integer branchNo = 0;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 32,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String acptId;
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String dealInfo = " ";

        public PutBpsAcptformInvalidInnerInput() {
        }

        public String getOperatorName() {
            if (this.operatorName == null) {
                return " ";
            } else {
                return this.operatorName.isEmpty() ? " " : this.operatorName;
            }
        }

        public Character getUseType() {
            return this.useType != null ? this.useType : ' ';
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getMenuCode() {
            if (this.menuCode == null) {
                return " ";
            } else {
                return this.menuCode.isEmpty() ? " " : this.menuCode;
            }
        }

        public String getFunctionStr() {
            if (this.functionStr == null) {
                return " ";
            } else {
                return this.functionStr.isEmpty() ? " " : this.functionStr;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getAcptId() {
            return this.acptId;
        }

        public String getDealInfo() {
            if (this.dealInfo == null) {
                return " ";
            } else {
                return this.dealInfo.isEmpty() ? " " : this.dealInfo;
            }
        }

        public void setOperatorName(String operatorName) {
            this.operatorName = operatorName;
        }

        public void setUseType(Character useType) {
            this.useType = useType;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setMenuCode(String menuCode) {
            this.menuCode = menuCode;
        }

        public void setFunctionStr(String functionStr) {
            this.functionStr = functionStr;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setAcptId(String acptId) {
            this.acptId = acptId;
        }

        public void setDealInfo(String dealInfo) {
            this.dealInfo = dealInfo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutBpsAcptformInvalidInnerInput:(");
            buffer.append("operatorName:" + this.operatorName);
            buffer.append(",useType:" + this.useType);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",menuCode:" + this.menuCode);
            buffer.append(",functionStr:" + this.functionStr);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",acptId:" + this.acptId);
            buffer.append(",dealInfo:" + this.dealInfo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.operatorName);
            builder.append(this.useType);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.menuCode);
            builder.append(this.functionStr);
            builder.append(this.branchNo);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.acptId);
            builder.append(this.dealInfo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.PutBpsAcptformInvalidInnerInput) {
                InnerBpsService.PutBpsAcptformInvalidInnerInput test = (InnerBpsService.PutBpsAcptformInvalidInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.operatorName, test.operatorName);
                builder.append(this.useType, test.useType);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.menuCode, test.menuCode);
                builder.append(this.functionStr, test.functionStr);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.acptId, test.acptId);
                builder.append(this.dealInfo, test.dealInfo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutBpsAcptformCustidInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String opRemark = " ";

        public PutBpsAcptformCustidInnerOutput() {
        }

        public String getOpRemark() {
            if (this.opRemark == null) {
                return " ";
            } else {
                return this.opRemark.isEmpty() ? " " : this.opRemark;
            }
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutBpsAcptformCustidInnerOutput:(");
            buffer.append("opRemark:" + this.opRemark);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opRemark);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.PutBpsAcptformCustidInnerOutput) {
                InnerBpsService.PutBpsAcptformCustidInnerOutput test = (InnerBpsService.PutBpsAcptformCustidInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opRemark, test.opRemark);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutBpsAcptformCustidInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 60,
                charset = "utf-8"
        )
        private String operatorName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character useType = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String menuCode = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String functionStr = " ";
        private Integer branchNo = 0;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 32,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String acptId;
        @SinogramLength(
                min = 1,
                max = 32,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String custId;

        public PutBpsAcptformCustidInnerInput() {
        }

        public String getOperatorName() {
            if (this.operatorName == null) {
                return " ";
            } else {
                return this.operatorName.isEmpty() ? " " : this.operatorName;
            }
        }

        public Character getUseType() {
            return this.useType != null ? this.useType : ' ';
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getMenuCode() {
            if (this.menuCode == null) {
                return " ";
            } else {
                return this.menuCode.isEmpty() ? " " : this.menuCode;
            }
        }

        public String getFunctionStr() {
            if (this.functionStr == null) {
                return " ";
            } else {
                return this.functionStr.isEmpty() ? " " : this.functionStr;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getAcptId() {
            return this.acptId;
        }

        public String getCustId() {
            return this.custId;
        }

        public void setOperatorName(String operatorName) {
            this.operatorName = operatorName;
        }

        public void setUseType(Character useType) {
            this.useType = useType;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setMenuCode(String menuCode) {
            this.menuCode = menuCode;
        }

        public void setFunctionStr(String functionStr) {
            this.functionStr = functionStr;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setAcptId(String acptId) {
            this.acptId = acptId;
        }

        public void setCustId(String custId) {
            this.custId = custId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutBpsAcptformCustidInnerInput:(");
            buffer.append("operatorName:" + this.operatorName);
            buffer.append(",useType:" + this.useType);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",menuCode:" + this.menuCode);
            buffer.append(",functionStr:" + this.functionStr);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",acptId:" + this.acptId);
            buffer.append(",custId:" + this.custId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.operatorName);
            builder.append(this.useType);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.menuCode);
            builder.append(this.functionStr);
            builder.append(this.branchNo);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.acptId);
            builder.append(this.custId);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.PutBpsAcptformCustidInnerInput) {
                InnerBpsService.PutBpsAcptformCustidInnerInput test = (InnerBpsService.PutBpsAcptformCustidInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.operatorName, test.operatorName);
                builder.append(this.useType, test.useType);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.menuCode, test.menuCode);
                builder.append(this.functionStr, test.functionStr);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.acptId, test.acptId);
                builder.append(this.custId, test.custId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutArgDateChangeInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer initDate;

        public PutArgDateChangeInnerOutput() {
        }

        public Integer getInitDate() {
            return this.initDate;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutArgDateChangeInnerOutput:(");
            buffer.append("initDate:" + this.initDate);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.initDate);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.PutArgDateChangeInnerOutput) {
                InnerBpsService.PutArgDateChangeInnerOutput test = (InnerBpsService.PutArgDateChangeInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.initDate, test.initDate);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutArgDateChangeInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 60,
                charset = "utf-8"
        )
        private String operatorName;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character useType;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword;
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String menuCode;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String functionStr;
        private Integer branchNo;
        private Integer opBranchNo;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo;
        private Integer businsysNo;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character auditAction;
        private Integer initDate = 0;

        public PutArgDateChangeInnerInput() {
        }

        public String getOperatorName() {
            return this.operatorName;
        }

        public Character getUseType() {
            return this.useType;
        }

        public String getOpPassword() {
            return this.opPassword;
        }

        public String getOpStation() {
            return this.opStation;
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay;
        }

        public String getMenuCode() {
            return this.menuCode;
        }

        public String getFunctionStr() {
            return this.functionStr;
        }

        public Integer getBranchNo() {
            return this.branchNo;
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo;
        }

        public String getOperatorNo() {
            return this.operatorNo;
        }

        public Integer getBusinsysNo() {
            return this.businsysNo;
        }

        public Character getAuditAction() {
            return this.auditAction;
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public void setOperatorName(String operatorName) {
            this.operatorName = operatorName;
        }

        public void setUseType(Character useType) {
            this.useType = useType;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setMenuCode(String menuCode) {
            this.menuCode = menuCode;
        }

        public void setFunctionStr(String functionStr) {
            this.functionStr = functionStr;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setBusinsysNo(Integer businsysNo) {
            this.businsysNo = businsysNo;
        }

        public void setAuditAction(Character auditAction) {
            this.auditAction = auditAction;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutArgDateChangeInnerInput:(");
            buffer.append("operatorName:" + this.operatorName);
            buffer.append(",useType:" + this.useType);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",menuCode:" + this.menuCode);
            buffer.append(",functionStr:" + this.functionStr);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",businsysNo:" + this.businsysNo);
            buffer.append(",auditAction:" + this.auditAction);
            buffer.append(",initDate:" + this.initDate);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.operatorName);
            builder.append(this.useType);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.menuCode);
            builder.append(this.functionStr);
            builder.append(this.branchNo);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.businsysNo);
            builder.append(this.auditAction);
            builder.append(this.initDate);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.PutArgDateChangeInnerInput) {
                InnerBpsService.PutArgDateChangeInnerInput test = (InnerBpsService.PutArgDateChangeInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.operatorName, test.operatorName);
                builder.append(this.useType, test.useType);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.menuCode, test.menuCode);
                builder.append(this.functionStr, test.functionStr);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.businsysNo, test.businsysNo);
                builder.append(this.auditAction, test.auditAction);
                builder.append(this.initDate, test.initDate);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutAcptbusinClaimInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private List<InnerBpsService.AcptTaskDTO> rows;
        private Integer total = 0;

        public PutAcptbusinClaimInnerOutput() {
        }

        public List<InnerBpsService.AcptTaskDTO> getRows() {
            return this.rows;
        }

        public Integer getTotal() {
            return this.total != null ? this.total : 0;
        }

        public void setRows(List<InnerBpsService.AcptTaskDTO> rows) {
            this.rows = rows;
        }

        public void setTotal(Integer total) {
            this.total = total;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutAcptbusinClaimInnerOutput:(");
            buffer.append("rows:" + this.rows);
            buffer.append(",total:" + this.total);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.rows);
            builder.append(this.total);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.PutAcptbusinClaimInnerOutput) {
                InnerBpsService.PutAcptbusinClaimInnerOutput test = (InnerBpsService.PutAcptbusinClaimInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.rows, test.rows);
                builder.append(this.total, test.total);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutAcptbusinClaimInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 60,
                charset = "utf-8"
        )
        private String operatorName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character useType = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String menuCode = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String functionStr = " ";
        private Integer branchNo = 0;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String acptId = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String taskNo = " ";

        public PutAcptbusinClaimInnerInput() {
        }

        public String getOperatorName() {
            if (this.operatorName == null) {
                return " ";
            } else {
                return this.operatorName.isEmpty() ? " " : this.operatorName;
            }
        }

        public Character getUseType() {
            return this.useType != null ? this.useType : ' ';
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getMenuCode() {
            if (this.menuCode == null) {
                return " ";
            } else {
                return this.menuCode.isEmpty() ? " " : this.menuCode;
            }
        }

        public String getFunctionStr() {
            if (this.functionStr == null) {
                return " ";
            } else {
                return this.functionStr.isEmpty() ? " " : this.functionStr;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getAcptId() {
            if (this.acptId == null) {
                return " ";
            } else {
                return this.acptId.isEmpty() ? " " : this.acptId;
            }
        }

        public String getTaskNo() {
            if (this.taskNo == null) {
                return " ";
            } else {
                return this.taskNo.isEmpty() ? " " : this.taskNo;
            }
        }

        public void setOperatorName(String operatorName) {
            this.operatorName = operatorName;
        }

        public void setUseType(Character useType) {
            this.useType = useType;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setMenuCode(String menuCode) {
            this.menuCode = menuCode;
        }

        public void setFunctionStr(String functionStr) {
            this.functionStr = functionStr;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setAcptId(String acptId) {
            this.acptId = acptId;
        }

        public void setTaskNo(String taskNo) {
            this.taskNo = taskNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutAcptbusinClaimInnerInput:(");
            buffer.append("operatorName:" + this.operatorName);
            buffer.append(",useType:" + this.useType);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",menuCode:" + this.menuCode);
            buffer.append(",functionStr:" + this.functionStr);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",acptId:" + this.acptId);
            buffer.append(",taskNo:" + this.taskNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.operatorName);
            builder.append(this.useType);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.menuCode);
            builder.append(this.functionStr);
            builder.append(this.branchNo);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.acptId);
            builder.append(this.taskNo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.PutAcptbusinClaimInnerInput) {
                InnerBpsService.PutAcptbusinClaimInnerInput test = (InnerBpsService.PutAcptbusinClaimInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.operatorName, test.operatorName);
                builder.append(this.useType, test.useType);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.menuCode, test.menuCode);
                builder.append(this.functionStr, test.functionStr);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.acptId, test.acptId);
                builder.append(this.taskNo, test.taskNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutAcptTplExtInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String opRemark = " ";

        public PutAcptTplExtInnerOutput() {
        }

        public String getOpRemark() {
            if (this.opRemark == null) {
                return " ";
            } else {
                return this.opRemark.isEmpty() ? " " : this.opRemark;
            }
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutAcptTplExtInnerOutput:(");
            buffer.append("opRemark:" + this.opRemark);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opRemark);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.PutAcptTplExtInnerOutput) {
                InnerBpsService.PutAcptTplExtInnerOutput test = (InnerBpsService.PutAcptTplExtInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opRemark, test.opRemark);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutAcptTplExtInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 60,
                charset = "utf-8"
        )
        private String operatorName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character useType = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String menuCode = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String functionStr = " ";
        private Integer branchNo = 0;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 10,
                charset = "utf-8"
        )
        private String acptBusinId = " ";
        @SinogramLength(
                min = 0,
                max = 4000,
                charset = "utf-8"
        )
        private String acptTplExt = " ";

        public PutAcptTplExtInnerInput() {
        }

        public String getOperatorName() {
            if (this.operatorName == null) {
                return " ";
            } else {
                return this.operatorName.isEmpty() ? " " : this.operatorName;
            }
        }

        public Character getUseType() {
            return this.useType != null ? this.useType : ' ';
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getMenuCode() {
            if (this.menuCode == null) {
                return " ";
            } else {
                return this.menuCode.isEmpty() ? " " : this.menuCode;
            }
        }

        public String getFunctionStr() {
            if (this.functionStr == null) {
                return " ";
            } else {
                return this.functionStr.isEmpty() ? " " : this.functionStr;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getAcptBusinId() {
            if (this.acptBusinId == null) {
                return " ";
            } else {
                return this.acptBusinId.isEmpty() ? " " : this.acptBusinId;
            }
        }

        public String getAcptTplExt() {
            if (this.acptTplExt == null) {
                return " ";
            } else {
                return this.acptTplExt.isEmpty() ? " " : this.acptTplExt;
            }
        }

        public void setOperatorName(String operatorName) {
            this.operatorName = operatorName;
        }

        public void setUseType(Character useType) {
            this.useType = useType;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setMenuCode(String menuCode) {
            this.menuCode = menuCode;
        }

        public void setFunctionStr(String functionStr) {
            this.functionStr = functionStr;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setAcptBusinId(String acptBusinId) {
            this.acptBusinId = acptBusinId;
        }

        public void setAcptTplExt(String acptTplExt) {
            this.acptTplExt = acptTplExt;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutAcptTplExtInnerInput:(");
            buffer.append("operatorName:" + this.operatorName);
            buffer.append(",useType:" + this.useType);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",menuCode:" + this.menuCode);
            buffer.append(",functionStr:" + this.functionStr);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",acptBusinId:" + this.acptBusinId);
            buffer.append(",acptTplExt:" + this.acptTplExt);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.operatorName);
            builder.append(this.useType);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.menuCode);
            builder.append(this.functionStr);
            builder.append(this.branchNo);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.acptBusinId);
            builder.append(this.acptTplExt);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.PutAcptTplExtInnerInput) {
                InnerBpsService.PutAcptTplExtInnerInput test = (InnerBpsService.PutAcptTplExtInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.operatorName, test.operatorName);
                builder.append(this.useType, test.useType);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.menuCode, test.menuCode);
                builder.append(this.functionStr, test.functionStr);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.acptBusinId, test.acptBusinId);
                builder.append(this.acptTplExt, test.acptTplExt);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostTsAcptFormtoHisInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 60,
                charset = "utf-8"
        )
        private String operatorName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character useType = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String menuCode = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String functionStr = " ";
        private Integer branchNo = 0;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        private Integer initDate = 0;

        public PostTsAcptFormtoHisInnerInput() {
        }

        public String getOperatorName() {
            if (this.operatorName == null) {
                return " ";
            } else {
                return this.operatorName.isEmpty() ? " " : this.operatorName;
            }
        }

        public Character getUseType() {
            return this.useType != null ? this.useType : ' ';
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getMenuCode() {
            if (this.menuCode == null) {
                return " ";
            } else {
                return this.menuCode.isEmpty() ? " " : this.menuCode;
            }
        }

        public String getFunctionStr() {
            if (this.functionStr == null) {
                return " ";
            } else {
                return this.functionStr.isEmpty() ? " " : this.functionStr;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public void setOperatorName(String operatorName) {
            this.operatorName = operatorName;
        }

        public void setUseType(Character useType) {
            this.useType = useType;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setMenuCode(String menuCode) {
            this.menuCode = menuCode;
        }

        public void setFunctionStr(String functionStr) {
            this.functionStr = functionStr;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostTsAcptFormtoHisInnerInput:(");
            buffer.append("operatorName:" + this.operatorName);
            buffer.append(",useType:" + this.useType);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",menuCode:" + this.menuCode);
            buffer.append(",functionStr:" + this.functionStr);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",initDate:" + this.initDate);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.operatorName);
            builder.append(this.useType);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.menuCode);
            builder.append(this.functionStr);
            builder.append(this.branchNo);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.initDate);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.PostTsAcptFormtoHisInnerInput) {
                InnerBpsService.PostTsAcptFormtoHisInnerInput test = (InnerBpsService.PostTsAcptFormtoHisInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.operatorName, test.operatorName);
                builder.append(this.useType, test.useType);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.menuCode, test.menuCode);
                builder.append(this.functionStr, test.functionStr);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.initDate, test.initDate);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostSettleDayIntoPrevInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 60,
                charset = "utf-8"
        )
        private String operatorName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character useType = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String menuCode = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String functionStr = " ";
        private Integer branchNo = 0;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";

        public PostSettleDayIntoPrevInnerInput() {
        }

        public String getOperatorName() {
            if (this.operatorName == null) {
                return " ";
            } else {
                return this.operatorName.isEmpty() ? " " : this.operatorName;
            }
        }

        public Character getUseType() {
            return this.useType != null ? this.useType : ' ';
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getMenuCode() {
            if (this.menuCode == null) {
                return " ";
            } else {
                return this.menuCode.isEmpty() ? " " : this.menuCode;
            }
        }

        public String getFunctionStr() {
            if (this.functionStr == null) {
                return " ";
            } else {
                return this.functionStr.isEmpty() ? " " : this.functionStr;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public void setOperatorName(String operatorName) {
            this.operatorName = operatorName;
        }

        public void setUseType(Character useType) {
            this.useType = useType;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setMenuCode(String menuCode) {
            this.menuCode = menuCode;
        }

        public void setFunctionStr(String functionStr) {
            this.functionStr = functionStr;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostSettleDayIntoPrevInnerInput:(");
            buffer.append("operatorName:" + this.operatorName);
            buffer.append(",useType:" + this.useType);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",menuCode:" + this.menuCode);
            buffer.append(",functionStr:" + this.functionStr);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.operatorName);
            builder.append(this.useType);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.menuCode);
            builder.append(this.functionStr);
            builder.append(this.branchNo);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.PostSettleDayIntoPrevInnerInput) {
                InnerBpsService.PostSettleDayIntoPrevInnerInput test = (InnerBpsService.PostSettleDayIntoPrevInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.operatorName, test.operatorName);
                builder.append(this.useType, test.useType);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.menuCode, test.menuCode);
                builder.append(this.functionStr, test.functionStr);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostFileCollectInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String acptId;

        public PostFileCollectInnerOutput() {
        }

        public String getAcptId() {
            return this.acptId;
        }

        public void setAcptId(String acptId) {
            this.acptId = acptId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostFileCollectInnerOutput:(");
            buffer.append("acptId:" + this.acptId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.acptId);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.PostFileCollectInnerOutput) {
                InnerBpsService.PostFileCollectInnerOutput test = (InnerBpsService.PostFileCollectInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.acptId, test.acptId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostFileCollectInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 60,
                charset = "utf-8"
        )
        private String operatorName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character useType = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String menuCode = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String functionStr = " ";
        private Integer branchNo = 0;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @NotEmpty(
                message = "不能为空"
        )
        private String fileData;
        @SinogramLength(
                min = 1,
                max = 6,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String archFileNo;
        @NotNull(
                message = "不能为空"
        )
        private Integer pageNo;
        @SinogramLength(
                min = 1,
                max = 64,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String fileMd5;
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String fileName;
        @NotNull(
                message = "不能为空"
        )
        private Long fileSize;
        private Integer actionIn = 0;
        @SinogramLength(
                min = 1,
                max = 32,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String custId;
        private Integer filePos = 0;
        private Integer recordSize = 0;
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String acptId = " ";
        @SinogramLength(
                min = 0,
                max = 10,
                charset = "utf-8"
        )
        private String acptBusinId = " ";

        public PostFileCollectInnerInput() {
        }

        public String getOperatorName() {
            if (this.operatorName == null) {
                return " ";
            } else {
                return this.operatorName.isEmpty() ? " " : this.operatorName;
            }
        }

        public Character getUseType() {
            return this.useType != null ? this.useType : ' ';
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getMenuCode() {
            if (this.menuCode == null) {
                return " ";
            } else {
                return this.menuCode.isEmpty() ? " " : this.menuCode;
            }
        }

        public String getFunctionStr() {
            if (this.functionStr == null) {
                return " ";
            } else {
                return this.functionStr.isEmpty() ? " " : this.functionStr;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getFileData() {
            return this.fileData;
        }

        public String getArchFileNo() {
            return this.archFileNo;
        }

        public Integer getPageNo() {
            return this.pageNo;
        }

        public String getFileMd5() {
            return this.fileMd5;
        }

        public String getFileName() {
            return this.fileName;
        }

        public Long getFileSize() {
            return this.fileSize;
        }

        public Integer getActionIn() {
            return this.actionIn != null ? this.actionIn : 0;
        }

        public String getCustId() {
            return this.custId;
        }

        public Integer getFilePos() {
            return this.filePos != null ? this.filePos : 0;
        }

        public Integer getRecordSize() {
            return this.recordSize != null ? this.recordSize : 0;
        }

        public String getAcptId() {
            if (this.acptId == null) {
                return " ";
            } else {
                return this.acptId.isEmpty() ? " " : this.acptId;
            }
        }

        public String getAcptBusinId() {
            if (this.acptBusinId == null) {
                return " ";
            } else {
                return this.acptBusinId.isEmpty() ? " " : this.acptBusinId;
            }
        }

        public void setOperatorName(String operatorName) {
            this.operatorName = operatorName;
        }

        public void setUseType(Character useType) {
            this.useType = useType;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setMenuCode(String menuCode) {
            this.menuCode = menuCode;
        }

        public void setFunctionStr(String functionStr) {
            this.functionStr = functionStr;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setFileData(String fileData) {
            this.fileData = fileData;
        }

        public void setArchFileNo(String archFileNo) {
            this.archFileNo = archFileNo;
        }

        public void setPageNo(Integer pageNo) {
            this.pageNo = pageNo;
        }

        public void setFileMd5(String fileMd5) {
            this.fileMd5 = fileMd5;
        }

        public void setFileName(String fileName) {
            this.fileName = fileName;
        }

        public void setFileSize(Long fileSize) {
            this.fileSize = fileSize;
        }

        public void setActionIn(Integer actionIn) {
            this.actionIn = actionIn;
        }

        public void setCustId(String custId) {
            this.custId = custId;
        }

        public void setFilePos(Integer filePos) {
            this.filePos = filePos;
        }

        public void setRecordSize(Integer recordSize) {
            this.recordSize = recordSize;
        }

        public void setAcptId(String acptId) {
            this.acptId = acptId;
        }

        public void setAcptBusinId(String acptBusinId) {
            this.acptBusinId = acptBusinId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostFileCollectInnerInput:(");
            buffer.append("operatorName:" + this.operatorName);
            buffer.append(",useType:" + this.useType);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",menuCode:" + this.menuCode);
            buffer.append(",functionStr:" + this.functionStr);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",fileData:" + this.fileData);
            buffer.append(",archFileNo:" + this.archFileNo);
            buffer.append(",pageNo:" + this.pageNo);
            buffer.append(",fileMd5:" + this.fileMd5);
            buffer.append(",fileName:" + this.fileName);
            buffer.append(",fileSize:" + this.fileSize);
            buffer.append(",actionIn:" + this.actionIn);
            buffer.append(",custId:" + this.custId);
            buffer.append(",filePos:" + this.filePos);
            buffer.append(",recordSize:" + this.recordSize);
            buffer.append(",acptId:" + this.acptId);
            buffer.append(",acptBusinId:" + this.acptBusinId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.operatorName);
            builder.append(this.useType);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.menuCode);
            builder.append(this.functionStr);
            builder.append(this.branchNo);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.fileData);
            builder.append(this.archFileNo);
            builder.append(this.pageNo);
            builder.append(this.fileMd5);
            builder.append(this.fileName);
            builder.append(this.fileSize);
            builder.append(this.actionIn);
            builder.append(this.custId);
            builder.append(this.filePos);
            builder.append(this.recordSize);
            builder.append(this.acptId);
            builder.append(this.acptBusinId);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.PostFileCollectInnerInput) {
                InnerBpsService.PostFileCollectInnerInput test = (InnerBpsService.PostFileCollectInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.operatorName, test.operatorName);
                builder.append(this.useType, test.useType);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.menuCode, test.menuCode);
                builder.append(this.functionStr, test.functionStr);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.fileData, test.fileData);
                builder.append(this.archFileNo, test.archFileNo);
                builder.append(this.pageNo, test.pageNo);
                builder.append(this.fileMd5, test.fileMd5);
                builder.append(this.fileName, test.fileName);
                builder.append(this.fileSize, test.fileSize);
                builder.append(this.actionIn, test.actionIn);
                builder.append(this.custId, test.custId);
                builder.append(this.filePos, test.filePos);
                builder.append(this.recordSize, test.recordSize);
                builder.append(this.acptId, test.acptId);
                builder.append(this.acptBusinId, test.acptBusinId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostBpsKpiRecordGenInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String opRemark = " ";

        public PostBpsKpiRecordGenInnerOutput() {
        }

        public String getOpRemark() {
            if (this.opRemark == null) {
                return " ";
            } else {
                return this.opRemark.isEmpty() ? " " : this.opRemark;
            }
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostBpsKpiRecordGenInnerOutput:(");
            buffer.append("opRemark:" + this.opRemark);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opRemark);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.PostBpsKpiRecordGenInnerOutput) {
                InnerBpsService.PostBpsKpiRecordGenInnerOutput test = (InnerBpsService.PostBpsKpiRecordGenInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opRemark, test.opRemark);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostBpsKpiRecordGenInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 60,
                charset = "utf-8"
        )
        private String operatorName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character useType = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String menuCode = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String functionStr = " ";
        private Integer branchNo = 0;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        private Integer initDate = 0;

        public PostBpsKpiRecordGenInnerInput() {
        }

        public String getOperatorName() {
            if (this.operatorName == null) {
                return " ";
            } else {
                return this.operatorName.isEmpty() ? " " : this.operatorName;
            }
        }

        public Character getUseType() {
            return this.useType != null ? this.useType : ' ';
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getMenuCode() {
            if (this.menuCode == null) {
                return " ";
            } else {
                return this.menuCode.isEmpty() ? " " : this.menuCode;
            }
        }

        public String getFunctionStr() {
            if (this.functionStr == null) {
                return " ";
            } else {
                return this.functionStr.isEmpty() ? " " : this.functionStr;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public void setOperatorName(String operatorName) {
            this.operatorName = operatorName;
        }

        public void setUseType(Character useType) {
            this.useType = useType;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setMenuCode(String menuCode) {
            this.menuCode = menuCode;
        }

        public void setFunctionStr(String functionStr) {
            this.functionStr = functionStr;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostBpsKpiRecordGenInnerInput:(");
            buffer.append("operatorName:" + this.operatorName);
            buffer.append(",useType:" + this.useType);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",menuCode:" + this.menuCode);
            buffer.append(",functionStr:" + this.functionStr);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",initDate:" + this.initDate);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.operatorName);
            builder.append(this.useType);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.menuCode);
            builder.append(this.functionStr);
            builder.append(this.branchNo);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.initDate);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.PostBpsKpiRecordGenInnerInput) {
                InnerBpsService.PostBpsKpiRecordGenInnerInput test = (InnerBpsService.PostBpsKpiRecordGenInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.operatorName, test.operatorName);
                builder.append(this.useType, test.useType);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.menuCode, test.menuCode);
                builder.append(this.functionStr, test.functionStr);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.initDate, test.initDate);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostBpsClientPreOpenInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String acptId = " ";

        public PostBpsClientPreOpenInnerOutput() {
        }

        public String getAcptId() {
            if (this.acptId == null) {
                return " ";
            } else {
                return this.acptId.isEmpty() ? " " : this.acptId;
            }
        }

        public void setAcptId(String acptId) {
            this.acptId = acptId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostBpsClientPreOpenInnerOutput:(");
            buffer.append("acptId:" + this.acptId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.acptId);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.PostBpsClientPreOpenInnerOutput) {
                InnerBpsService.PostBpsClientPreOpenInnerOutput test = (InnerBpsService.PostBpsClientPreOpenInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.acptId, test.acptId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostBpsClientPreOpenInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 60,
                charset = "utf-8"
        )
        private String operatorName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character useType = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String menuCode = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String functionStr = " ";
        private Integer branchNo = 0;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String clientId = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character idKind = ' ';
        @SinogramLength(
                min = 0,
                max = 40,
                charset = "utf-8"
        )
        private String idNo = " ";
        @SinogramLength(
                min = 0,
                max = 180,
                charset = "utf-8"
        )
        private String fullName = " ";
        @SinogramLength(
                min = 0,
                max = 16000,
                charset = "utf-8"
        )
        private String paramData = " ";

        public PostBpsClientPreOpenInnerInput() {
        }

        public String getOperatorName() {
            if (this.operatorName == null) {
                return " ";
            } else {
                return this.operatorName.isEmpty() ? " " : this.operatorName;
            }
        }

        public Character getUseType() {
            return this.useType != null ? this.useType : ' ';
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getMenuCode() {
            if (this.menuCode == null) {
                return " ";
            } else {
                return this.menuCode.isEmpty() ? " " : this.menuCode;
            }
        }

        public String getFunctionStr() {
            if (this.functionStr == null) {
                return " ";
            } else {
                return this.functionStr.isEmpty() ? " " : this.functionStr;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public Character getIdKind() {
            return this.idKind != null ? this.idKind : ' ';
        }

        public String getIdNo() {
            if (this.idNo == null) {
                return " ";
            } else {
                return this.idNo.isEmpty() ? " " : this.idNo;
            }
        }

        public String getFullName() {
            if (this.fullName == null) {
                return " ";
            } else {
                return this.fullName.isEmpty() ? " " : this.fullName;
            }
        }

        public String getParamData() {
            if (this.paramData == null) {
                return " ";
            } else {
                return this.paramData.isEmpty() ? " " : this.paramData;
            }
        }

        public void setOperatorName(String operatorName) {
            this.operatorName = operatorName;
        }

        public void setUseType(Character useType) {
            this.useType = useType;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setMenuCode(String menuCode) {
            this.menuCode = menuCode;
        }

        public void setFunctionStr(String functionStr) {
            this.functionStr = functionStr;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setIdKind(Character idKind) {
            this.idKind = idKind;
        }

        public void setIdNo(String idNo) {
            this.idNo = idNo;
        }

        public void setFullName(String fullName) {
            this.fullName = fullName;
        }

        public void setParamData(String paramData) {
            this.paramData = paramData;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostBpsClientPreOpenInnerInput:(");
            buffer.append("operatorName:" + this.operatorName);
            buffer.append(",useType:" + this.useType);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",menuCode:" + this.menuCode);
            buffer.append(",functionStr:" + this.functionStr);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",idKind:" + this.idKind);
            buffer.append(",idNo:" + this.idNo);
            buffer.append(",fullName:" + this.fullName);
            buffer.append(",paramData:" + this.paramData);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.operatorName);
            builder.append(this.useType);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.menuCode);
            builder.append(this.functionStr);
            builder.append(this.branchNo);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.clientId);
            builder.append(this.idKind);
            builder.append(this.idNo);
            builder.append(this.fullName);
            builder.append(this.paramData);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.PostBpsClientPreOpenInnerInput) {
                InnerBpsService.PostBpsClientPreOpenInnerInput test = (InnerBpsService.PostBpsClientPreOpenInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.operatorName, test.operatorName);
                builder.append(this.useType, test.useType);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.menuCode, test.menuCode);
                builder.append(this.functionStr, test.functionStr);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.clientId, test.clientId);
                builder.append(this.idKind, test.idKind);
                builder.append(this.idNo, test.idNo);
                builder.append(this.fullName, test.fullName);
                builder.append(this.paramData, test.paramData);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostBpsAcptformRegistInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String acptId = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character acptFormStatus = ' ';
        private String opRemark = " ";

        public PostBpsAcptformRegistInnerOutput() {
        }

        public String getAcptId() {
            if (this.acptId == null) {
                return " ";
            } else {
                return this.acptId.isEmpty() ? " " : this.acptId;
            }
        }

        public Character getAcptFormStatus() {
            return this.acptFormStatus != null ? this.acptFormStatus : ' ';
        }

        public String getOpRemark() {
            if (this.opRemark == null) {
                return " ";
            } else {
                return this.opRemark.isEmpty() ? " " : this.opRemark;
            }
        }

        public void setAcptId(String acptId) {
            this.acptId = acptId;
        }

        public void setAcptFormStatus(Character acptFormStatus) {
            this.acptFormStatus = acptFormStatus;
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostBpsAcptformRegistInnerOutput:(");
            buffer.append("acptId:" + this.acptId);
            buffer.append(",acptFormStatus:" + this.acptFormStatus);
            buffer.append(",opRemark:" + this.opRemark);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.acptId);
            builder.append(this.acptFormStatus);
            builder.append(this.opRemark);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.PostBpsAcptformRegistInnerOutput) {
                InnerBpsService.PostBpsAcptformRegistInnerOutput test = (InnerBpsService.PostBpsAcptformRegistInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.acptId, test.acptId);
                builder.append(this.acptFormStatus, test.acptFormStatus);
                builder.append(this.opRemark, test.opRemark);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostBpsAcptformRegistInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 60,
                charset = "utf-8"
        )
        private String operatorName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character useType = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String menuCode = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String functionStr = " ";
        private Integer branchNo = 0;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String acptBusinKind = " ";
        @SinogramLength(
                min = 1,
                max = 10,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String acptBusinId;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fundAccount = " ";
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId;
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String remark = " ";
        @SinogramLength(
                min = 0,
                max = 180,
                charset = "utf-8"
        )
        private String fullName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character organFlag = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character idKind = ' ';
        @SinogramLength(
                min = 0,
                max = 40,
                charset = "utf-8"
        )
        private String idNo = " ";
        private Integer acptChannel = 0;
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String acptId = " ";
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String acptEnrouteField = " ";
        @SinogramLength(
                min = 1,
                max = 999999999,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String functionData;
        @NotEmpty(
                message = "不能为空"
        )
        private String businessData;
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String columnStr = " ";
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String workflowInitParam = " ";
        @SinogramLength(
                min = 0,
                max = 8000,
                charset = "utf-8"
        )
        private String scanFileStr = " ";

        public PostBpsAcptformRegistInnerInput() {
        }

        public String getOperatorName() {
            if (this.operatorName == null) {
                return " ";
            } else {
                return this.operatorName.isEmpty() ? " " : this.operatorName;
            }
        }

        public Character getUseType() {
            return this.useType != null ? this.useType : ' ';
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getMenuCode() {
            if (this.menuCode == null) {
                return " ";
            } else {
                return this.menuCode.isEmpty() ? " " : this.menuCode;
            }
        }

        public String getFunctionStr() {
            if (this.functionStr == null) {
                return " ";
            } else {
                return this.functionStr.isEmpty() ? " " : this.functionStr;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getAcptBusinKind() {
            if (this.acptBusinKind == null) {
                return " ";
            } else {
                return this.acptBusinKind.isEmpty() ? " " : this.acptBusinKind;
            }
        }

        public String getAcptBusinId() {
            return this.acptBusinId;
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getClientId() {
            return this.clientId;
        }

        public String getRemark() {
            if (this.remark == null) {
                return " ";
            } else {
                return this.remark.isEmpty() ? " " : this.remark;
            }
        }

        public String getFullName() {
            if (this.fullName == null) {
                return " ";
            } else {
                return this.fullName.isEmpty() ? " " : this.fullName;
            }
        }

        public Character getOrganFlag() {
            return this.organFlag != null ? this.organFlag : ' ';
        }

        public Character getIdKind() {
            return this.idKind != null ? this.idKind : ' ';
        }

        public String getIdNo() {
            if (this.idNo == null) {
                return " ";
            } else {
                return this.idNo.isEmpty() ? " " : this.idNo;
            }
        }

        public Integer getAcptChannel() {
            return this.acptChannel != null ? this.acptChannel : 0;
        }

        public String getAcptId() {
            if (this.acptId == null) {
                return " ";
            } else {
                return this.acptId.isEmpty() ? " " : this.acptId;
            }
        }

        public String getAcptEnrouteField() {
            if (this.acptEnrouteField == null) {
                return " ";
            } else {
                return this.acptEnrouteField.isEmpty() ? " " : this.acptEnrouteField;
            }
        }

        public String getFunctionData() {
            return this.functionData;
        }

        public String getBusinessData() {
            return this.businessData;
        }

        public String getColumnStr() {
            if (this.columnStr == null) {
                return " ";
            } else {
                return this.columnStr.isEmpty() ? " " : this.columnStr;
            }
        }

        public String getWorkflowInitParam() {
            if (this.workflowInitParam == null) {
                return " ";
            } else {
                return this.workflowInitParam.isEmpty() ? " " : this.workflowInitParam;
            }
        }

        public String getScanFileStr() {
            if (this.scanFileStr == null) {
                return " ";
            } else {
                return this.scanFileStr.isEmpty() ? " " : this.scanFileStr;
            }
        }

        public void setOperatorName(String operatorName) {
            this.operatorName = operatorName;
        }

        public void setUseType(Character useType) {
            this.useType = useType;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setMenuCode(String menuCode) {
            this.menuCode = menuCode;
        }

        public void setFunctionStr(String functionStr) {
            this.functionStr = functionStr;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setAcptBusinKind(String acptBusinKind) {
            this.acptBusinKind = acptBusinKind;
        }

        public void setAcptBusinId(String acptBusinId) {
            this.acptBusinId = acptBusinId;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public void setFullName(String fullName) {
            this.fullName = fullName;
        }

        public void setOrganFlag(Character organFlag) {
            this.organFlag = organFlag;
        }

        public void setIdKind(Character idKind) {
            this.idKind = idKind;
        }

        public void setIdNo(String idNo) {
            this.idNo = idNo;
        }

        public void setAcptChannel(Integer acptChannel) {
            this.acptChannel = acptChannel;
        }

        public void setAcptId(String acptId) {
            this.acptId = acptId;
        }

        public void setAcptEnrouteField(String acptEnrouteField) {
            this.acptEnrouteField = acptEnrouteField;
        }

        public void setFunctionData(String functionData) {
            this.functionData = functionData;
        }

        public void setBusinessData(String businessData) {
            this.businessData = businessData;
        }

        public void setColumnStr(String columnStr) {
            this.columnStr = columnStr;
        }

        public void setWorkflowInitParam(String workflowInitParam) {
            this.workflowInitParam = workflowInitParam;
        }

        public void setScanFileStr(String scanFileStr) {
            this.scanFileStr = scanFileStr;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostBpsAcptformRegistInnerInput:(");
            buffer.append("operatorName:" + this.operatorName);
            buffer.append(",useType:" + this.useType);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",menuCode:" + this.menuCode);
            buffer.append(",functionStr:" + this.functionStr);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",acptBusinKind:" + this.acptBusinKind);
            buffer.append(",acptBusinId:" + this.acptBusinId);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",remark:" + this.remark);
            buffer.append(",fullName:" + this.fullName);
            buffer.append(",organFlag:" + this.organFlag);
            buffer.append(",idKind:" + this.idKind);
            buffer.append(",idNo:" + this.idNo);
            buffer.append(",acptChannel:" + this.acptChannel);
            buffer.append(",acptId:" + this.acptId);
            buffer.append(",acptEnrouteField:" + this.acptEnrouteField);
            buffer.append(",functionData:" + this.functionData);
            buffer.append(",businessData:" + this.businessData);
            buffer.append(",columnStr:" + this.columnStr);
            buffer.append(",workflowInitParam:" + this.workflowInitParam);
            buffer.append(",scanFileStr:" + this.scanFileStr);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.operatorName);
            builder.append(this.useType);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.menuCode);
            builder.append(this.functionStr);
            builder.append(this.branchNo);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.acptBusinKind);
            builder.append(this.acptBusinId);
            builder.append(this.fundAccount);
            builder.append(this.clientId);
            builder.append(this.remark);
            builder.append(this.fullName);
            builder.append(this.organFlag);
            builder.append(this.idKind);
            builder.append(this.idNo);
            builder.append(this.acptChannel);
            builder.append(this.acptId);
            builder.append(this.acptEnrouteField);
            builder.append(this.functionData);
            builder.append(this.businessData);
            builder.append(this.columnStr);
            builder.append(this.workflowInitParam);
            builder.append(this.scanFileStr);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.PostBpsAcptformRegistInnerInput) {
                InnerBpsService.PostBpsAcptformRegistInnerInput test = (InnerBpsService.PostBpsAcptformRegistInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.operatorName, test.operatorName);
                builder.append(this.useType, test.useType);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.menuCode, test.menuCode);
                builder.append(this.functionStr, test.functionStr);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.acptBusinKind, test.acptBusinKind);
                builder.append(this.acptBusinId, test.acptBusinId);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.clientId, test.clientId);
                builder.append(this.remark, test.remark);
                builder.append(this.fullName, test.fullName);
                builder.append(this.organFlag, test.organFlag);
                builder.append(this.idKind, test.idKind);
                builder.append(this.idNo, test.idNo);
                builder.append(this.acptChannel, test.acptChannel);
                builder.append(this.acptId, test.acptId);
                builder.append(this.acptEnrouteField, test.acptEnrouteField);
                builder.append(this.functionData, test.functionData);
                builder.append(this.businessData, test.businessData);
                builder.append(this.columnStr, test.columnStr);
                builder.append(this.workflowInitParam, test.workflowInitParam);
                builder.append(this.scanFileStr, test.scanFileStr);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostBpsAcptformByOnceInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String acptId = " ";
        private String operatorNo = " ";
        private String operatorName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character acptFormStatus = ' ';
        private Integer branchNo = 0;
        private Integer acceptDate = 0;
        private Integer acceptTime = 0;
        private String opRemark = " ";

        public PostBpsAcptformByOnceInnerOutput() {
        }

        public String getAcptId() {
            if (this.acptId == null) {
                return " ";
            } else {
                return this.acptId.isEmpty() ? " " : this.acptId;
            }
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOperatorName() {
            if (this.operatorName == null) {
                return " ";
            } else {
                return this.operatorName.isEmpty() ? " " : this.operatorName;
            }
        }

        public Character getAcptFormStatus() {
            return this.acptFormStatus != null ? this.acptFormStatus : ' ';
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Integer getAcceptDate() {
            return this.acceptDate != null ? this.acceptDate : 0;
        }

        public Integer getAcceptTime() {
            return this.acceptTime != null ? this.acceptTime : 0;
        }

        public String getOpRemark() {
            if (this.opRemark == null) {
                return " ";
            } else {
                return this.opRemark.isEmpty() ? " " : this.opRemark;
            }
        }

        public void setAcptId(String acptId) {
            this.acptId = acptId;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOperatorName(String operatorName) {
            this.operatorName = operatorName;
        }

        public void setAcptFormStatus(Character acptFormStatus) {
            this.acptFormStatus = acptFormStatus;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setAcceptDate(Integer acceptDate) {
            this.acceptDate = acceptDate;
        }

        public void setAcceptTime(Integer acceptTime) {
            this.acceptTime = acceptTime;
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostBpsAcptformByOnceInnerOutput:(");
            buffer.append("acptId:" + this.acptId);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",operatorName:" + this.operatorName);
            buffer.append(",acptFormStatus:" + this.acptFormStatus);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",acceptDate:" + this.acceptDate);
            buffer.append(",acceptTime:" + this.acceptTime);
            buffer.append(",opRemark:" + this.opRemark);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.acptId);
            builder.append(this.operatorNo);
            builder.append(this.operatorName);
            builder.append(this.acptFormStatus);
            builder.append(this.branchNo);
            builder.append(this.acceptDate);
            builder.append(this.acceptTime);
            builder.append(this.opRemark);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.PostBpsAcptformByOnceInnerOutput) {
                InnerBpsService.PostBpsAcptformByOnceInnerOutput test = (InnerBpsService.PostBpsAcptformByOnceInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.acptId, test.acptId);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.operatorName, test.operatorName);
                builder.append(this.acptFormStatus, test.acptFormStatus);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.acceptDate, test.acceptDate);
                builder.append(this.acceptTime, test.acceptTime);
                builder.append(this.opRemark, test.opRemark);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostBpsAcptformByOnceInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 60,
                charset = "utf-8"
        )
        private String operatorName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character useType = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String menuCode = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String functionStr = " ";
        private Integer branchNo = 0;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String acptBusinKind = " ";
        @SinogramLength(
                min = 1,
                max = 10,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String acptBusinId;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fundAccount = " ";
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId;
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String remark = " ";
        @SinogramLength(
                min = 0,
                max = 180,
                charset = "utf-8"
        )
        private String fullName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character organFlag = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character idKind = ' ';
        @SinogramLength(
                min = 0,
                max = 40,
                charset = "utf-8"
        )
        private String idNo = " ";
        private Integer acptChannel = 0;
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String acptEnrouteField = " ";
        @SinogramLength(
                min = 1,
                max = 999999999,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String functionData;
        @NotEmpty(
                message = "不能为空"
        )
        private String businessData;
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String workflowInitParam = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String columnStr = " ";
        @SinogramLength(
                min = 0,
                max = 8000,
                charset = "utf-8"
        )
        private String scanFileStr = " ";

        public PostBpsAcptformByOnceInnerInput() {
        }

        public String getOperatorName() {
            if (this.operatorName == null) {
                return " ";
            } else {
                return this.operatorName.isEmpty() ? " " : this.operatorName;
            }
        }

        public Character getUseType() {
            return this.useType != null ? this.useType : ' ';
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getMenuCode() {
            if (this.menuCode == null) {
                return " ";
            } else {
                return this.menuCode.isEmpty() ? " " : this.menuCode;
            }
        }

        public String getFunctionStr() {
            if (this.functionStr == null) {
                return " ";
            } else {
                return this.functionStr.isEmpty() ? " " : this.functionStr;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getAcptBusinKind() {
            if (this.acptBusinKind == null) {
                return " ";
            } else {
                return this.acptBusinKind.isEmpty() ? " " : this.acptBusinKind;
            }
        }

        public String getAcptBusinId() {
            return this.acptBusinId;
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getClientId() {
            return this.clientId;
        }

        public String getRemark() {
            if (this.remark == null) {
                return " ";
            } else {
                return this.remark.isEmpty() ? " " : this.remark;
            }
        }

        public String getFullName() {
            if (this.fullName == null) {
                return " ";
            } else {
                return this.fullName.isEmpty() ? " " : this.fullName;
            }
        }

        public Character getOrganFlag() {
            return this.organFlag != null ? this.organFlag : ' ';
        }

        public Character getIdKind() {
            return this.idKind != null ? this.idKind : ' ';
        }

        public String getIdNo() {
            if (this.idNo == null) {
                return " ";
            } else {
                return this.idNo.isEmpty() ? " " : this.idNo;
            }
        }

        public Integer getAcptChannel() {
            return this.acptChannel != null ? this.acptChannel : 0;
        }

        public String getAcptEnrouteField() {
            if (this.acptEnrouteField == null) {
                return " ";
            } else {
                return this.acptEnrouteField.isEmpty() ? " " : this.acptEnrouteField;
            }
        }

        public String getFunctionData() {
            return this.functionData;
        }

        public String getBusinessData() {
            return this.businessData;
        }

        public String getWorkflowInitParam() {
            if (this.workflowInitParam == null) {
                return " ";
            } else {
                return this.workflowInitParam.isEmpty() ? " " : this.workflowInitParam;
            }
        }

        public String getColumnStr() {
            if (this.columnStr == null) {
                return " ";
            } else {
                return this.columnStr.isEmpty() ? " " : this.columnStr;
            }
        }

        public String getScanFileStr() {
            if (this.scanFileStr == null) {
                return " ";
            } else {
                return this.scanFileStr.isEmpty() ? " " : this.scanFileStr;
            }
        }

        public void setOperatorName(String operatorName) {
            this.operatorName = operatorName;
        }

        public void setUseType(Character useType) {
            this.useType = useType;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setMenuCode(String menuCode) {
            this.menuCode = menuCode;
        }

        public void setFunctionStr(String functionStr) {
            this.functionStr = functionStr;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setAcptBusinKind(String acptBusinKind) {
            this.acptBusinKind = acptBusinKind;
        }

        public void setAcptBusinId(String acptBusinId) {
            this.acptBusinId = acptBusinId;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public void setFullName(String fullName) {
            this.fullName = fullName;
        }

        public void setOrganFlag(Character organFlag) {
            this.organFlag = organFlag;
        }

        public void setIdKind(Character idKind) {
            this.idKind = idKind;
        }

        public void setIdNo(String idNo) {
            this.idNo = idNo;
        }

        public void setAcptChannel(Integer acptChannel) {
            this.acptChannel = acptChannel;
        }

        public void setAcptEnrouteField(String acptEnrouteField) {
            this.acptEnrouteField = acptEnrouteField;
        }

        public void setFunctionData(String functionData) {
            this.functionData = functionData;
        }

        public void setBusinessData(String businessData) {
            this.businessData = businessData;
        }

        public void setWorkflowInitParam(String workflowInitParam) {
            this.workflowInitParam = workflowInitParam;
        }

        public void setColumnStr(String columnStr) {
            this.columnStr = columnStr;
        }

        public void setScanFileStr(String scanFileStr) {
            this.scanFileStr = scanFileStr;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostBpsAcptformByOnceInnerInput:(");
            buffer.append("operatorName:" + this.operatorName);
            buffer.append(",useType:" + this.useType);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",menuCode:" + this.menuCode);
            buffer.append(",functionStr:" + this.functionStr);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",acptBusinKind:" + this.acptBusinKind);
            buffer.append(",acptBusinId:" + this.acptBusinId);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",remark:" + this.remark);
            buffer.append(",fullName:" + this.fullName);
            buffer.append(",organFlag:" + this.organFlag);
            buffer.append(",idKind:" + this.idKind);
            buffer.append(",idNo:" + this.idNo);
            buffer.append(",acptChannel:" + this.acptChannel);
            buffer.append(",acptEnrouteField:" + this.acptEnrouteField);
            buffer.append(",functionData:" + this.functionData);
            buffer.append(",businessData:" + this.businessData);
            buffer.append(",workflowInitParam:" + this.workflowInitParam);
            buffer.append(",columnStr:" + this.columnStr);
            buffer.append(",scanFileStr:" + this.scanFileStr);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.operatorName);
            builder.append(this.useType);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.menuCode);
            builder.append(this.functionStr);
            builder.append(this.branchNo);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.acptBusinKind);
            builder.append(this.acptBusinId);
            builder.append(this.fundAccount);
            builder.append(this.clientId);
            builder.append(this.remark);
            builder.append(this.fullName);
            builder.append(this.organFlag);
            builder.append(this.idKind);
            builder.append(this.idNo);
            builder.append(this.acptChannel);
            builder.append(this.acptEnrouteField);
            builder.append(this.functionData);
            builder.append(this.businessData);
            builder.append(this.workflowInitParam);
            builder.append(this.columnStr);
            builder.append(this.scanFileStr);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.PostBpsAcptformByOnceInnerInput) {
                InnerBpsService.PostBpsAcptformByOnceInnerInput test = (InnerBpsService.PostBpsAcptformByOnceInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.operatorName, test.operatorName);
                builder.append(this.useType, test.useType);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.menuCode, test.menuCode);
                builder.append(this.functionStr, test.functionStr);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.acptBusinKind, test.acptBusinKind);
                builder.append(this.acptBusinId, test.acptBusinId);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.clientId, test.clientId);
                builder.append(this.remark, test.remark);
                builder.append(this.fullName, test.fullName);
                builder.append(this.organFlag, test.organFlag);
                builder.append(this.idKind, test.idKind);
                builder.append(this.idNo, test.idNo);
                builder.append(this.acptChannel, test.acptChannel);
                builder.append(this.acptEnrouteField, test.acptEnrouteField);
                builder.append(this.functionData, test.functionData);
                builder.append(this.businessData, test.businessData);
                builder.append(this.workflowInitParam, test.workflowInitParam);
                builder.append(this.columnStr, test.columnStr);
                builder.append(this.scanFileStr, test.scanFileStr);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostBpsAcptbusinSubmitInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String operatorNo = " ";
        private String operatorName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character acptFormStatus = ' ';
        private Integer branchNo = 0;
        private Integer acceptDate = 0;
        private Integer acceptTime = 0;
        private String opRemark = " ";

        public PostBpsAcptbusinSubmitInnerOutput() {
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOperatorName() {
            if (this.operatorName == null) {
                return " ";
            } else {
                return this.operatorName.isEmpty() ? " " : this.operatorName;
            }
        }

        public Character getAcptFormStatus() {
            return this.acptFormStatus != null ? this.acptFormStatus : ' ';
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Integer getAcceptDate() {
            return this.acceptDate != null ? this.acceptDate : 0;
        }

        public Integer getAcceptTime() {
            return this.acceptTime != null ? this.acceptTime : 0;
        }

        public String getOpRemark() {
            if (this.opRemark == null) {
                return " ";
            } else {
                return this.opRemark.isEmpty() ? " " : this.opRemark;
            }
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOperatorName(String operatorName) {
            this.operatorName = operatorName;
        }

        public void setAcptFormStatus(Character acptFormStatus) {
            this.acptFormStatus = acptFormStatus;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setAcceptDate(Integer acceptDate) {
            this.acceptDate = acceptDate;
        }

        public void setAcceptTime(Integer acceptTime) {
            this.acceptTime = acceptTime;
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostBpsAcptbusinSubmitInnerOutput:(");
            buffer.append("operatorNo:" + this.operatorNo);
            buffer.append(",operatorName:" + this.operatorName);
            buffer.append(",acptFormStatus:" + this.acptFormStatus);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",acceptDate:" + this.acceptDate);
            buffer.append(",acceptTime:" + this.acceptTime);
            buffer.append(",opRemark:" + this.opRemark);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.operatorNo);
            builder.append(this.operatorName);
            builder.append(this.acptFormStatus);
            builder.append(this.branchNo);
            builder.append(this.acceptDate);
            builder.append(this.acceptTime);
            builder.append(this.opRemark);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.PostBpsAcptbusinSubmitInnerOutput) {
                InnerBpsService.PostBpsAcptbusinSubmitInnerOutput test = (InnerBpsService.PostBpsAcptbusinSubmitInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.operatorName, test.operatorName);
                builder.append(this.acptFormStatus, test.acptFormStatus);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.acceptDate, test.acceptDate);
                builder.append(this.acceptTime, test.acceptTime);
                builder.append(this.opRemark, test.opRemark);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostBpsAcptbusinSubmitInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 60,
                charset = "utf-8"
        )
        private String operatorName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character useType = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String menuCode = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String functionStr = " ";
        private Integer branchNo = 0;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 32,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String acptId;

        public PostBpsAcptbusinSubmitInnerInput() {
        }

        public String getOperatorName() {
            if (this.operatorName == null) {
                return " ";
            } else {
                return this.operatorName.isEmpty() ? " " : this.operatorName;
            }
        }

        public Character getUseType() {
            return this.useType != null ? this.useType : ' ';
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getMenuCode() {
            if (this.menuCode == null) {
                return " ";
            } else {
                return this.menuCode.isEmpty() ? " " : this.menuCode;
            }
        }

        public String getFunctionStr() {
            if (this.functionStr == null) {
                return " ";
            } else {
                return this.functionStr.isEmpty() ? " " : this.functionStr;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getAcptId() {
            return this.acptId;
        }

        public void setOperatorName(String operatorName) {
            this.operatorName = operatorName;
        }

        public void setUseType(Character useType) {
            this.useType = useType;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setMenuCode(String menuCode) {
            this.menuCode = menuCode;
        }

        public void setFunctionStr(String functionStr) {
            this.functionStr = functionStr;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setAcptId(String acptId) {
            this.acptId = acptId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostBpsAcptbusinSubmitInnerInput:(");
            buffer.append("operatorName:" + this.operatorName);
            buffer.append(",useType:" + this.useType);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",menuCode:" + this.menuCode);
            buffer.append(",functionStr:" + this.functionStr);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",acptId:" + this.acptId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.operatorName);
            builder.append(this.useType);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.menuCode);
            builder.append(this.functionStr);
            builder.append(this.branchNo);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.acptId);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.PostBpsAcptbusinSubmitInnerInput) {
                InnerBpsService.PostBpsAcptbusinSubmitInnerInput test = (InnerBpsService.PostBpsAcptbusinSubmitInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.operatorName, test.operatorName);
                builder.append(this.useType, test.useType);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.menuCode, test.menuCode);
                builder.append(this.functionStr, test.functionStr);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.acptId, test.acptId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostBpsAcptDependInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String opRemark = " ";

        public PostBpsAcptDependInnerOutput() {
        }

        public String getOpRemark() {
            if (this.opRemark == null) {
                return " ";
            } else {
                return this.opRemark.isEmpty() ? " " : this.opRemark;
            }
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostBpsAcptDependInnerOutput:(");
            buffer.append("opRemark:" + this.opRemark);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opRemark);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.PostBpsAcptDependInnerOutput) {
                InnerBpsService.PostBpsAcptDependInnerOutput test = (InnerBpsService.PostBpsAcptDependInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opRemark, test.opRemark);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostBpsAcptDependInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 60,
                charset = "utf-8"
        )
        private String operatorName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character useType = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String menuCode = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String functionStr = " ";
        private Integer branchNo = 0;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String acptId = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String dependAcptId = " ";

        public PostBpsAcptDependInnerInput() {
        }

        public String getOperatorName() {
            if (this.operatorName == null) {
                return " ";
            } else {
                return this.operatorName.isEmpty() ? " " : this.operatorName;
            }
        }

        public Character getUseType() {
            return this.useType != null ? this.useType : ' ';
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getMenuCode() {
            if (this.menuCode == null) {
                return " ";
            } else {
                return this.menuCode.isEmpty() ? " " : this.menuCode;
            }
        }

        public String getFunctionStr() {
            if (this.functionStr == null) {
                return " ";
            } else {
                return this.functionStr.isEmpty() ? " " : this.functionStr;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getAcptId() {
            if (this.acptId == null) {
                return " ";
            } else {
                return this.acptId.isEmpty() ? " " : this.acptId;
            }
        }

        public String getDependAcptId() {
            if (this.dependAcptId == null) {
                return " ";
            } else {
                return this.dependAcptId.isEmpty() ? " " : this.dependAcptId;
            }
        }

        public void setOperatorName(String operatorName) {
            this.operatorName = operatorName;
        }

        public void setUseType(Character useType) {
            this.useType = useType;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setMenuCode(String menuCode) {
            this.menuCode = menuCode;
        }

        public void setFunctionStr(String functionStr) {
            this.functionStr = functionStr;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setAcptId(String acptId) {
            this.acptId = acptId;
        }

        public void setDependAcptId(String dependAcptId) {
            this.dependAcptId = dependAcptId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostBpsAcptDependInnerInput:(");
            buffer.append("operatorName:" + this.operatorName);
            buffer.append(",useType:" + this.useType);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",menuCode:" + this.menuCode);
            buffer.append(",functionStr:" + this.functionStr);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",acptId:" + this.acptId);
            buffer.append(",dependAcptId:" + this.dependAcptId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.operatorName);
            builder.append(this.useType);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.menuCode);
            builder.append(this.functionStr);
            builder.append(this.branchNo);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.acptId);
            builder.append(this.dependAcptId);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.PostBpsAcptDependInnerInput) {
                InnerBpsService.PostBpsAcptDependInnerInput test = (InnerBpsService.PostBpsAcptDependInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.operatorName, test.operatorName);
                builder.append(this.useType, test.useType);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.menuCode, test.menuCode);
                builder.append(this.functionStr, test.functionStr);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.acptId, test.acptId);
                builder.append(this.dependAcptId, test.dependAcptId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostAuditArchInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String acptId;

        public PostAuditArchInnerOutput() {
        }

        public String getAcptId() {
            return this.acptId;
        }

        public void setAcptId(String acptId) {
            this.acptId = acptId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostAuditArchInnerOutput:(");
            buffer.append("acptId:" + this.acptId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.acptId);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.PostAuditArchInnerOutput) {
                InnerBpsService.PostAuditArchInnerOutput test = (InnerBpsService.PostAuditArchInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.acptId, test.acptId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostAuditArchInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 60,
                charset = "utf-8"
        )
        private String operatorName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character useType = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String menuCode = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String functionStr = " ";
        private Integer branchNo = 0;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String custId = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String acptId = " ";
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String acptBusinKind = " ";
        @SinogramLength(
                min = 0,
                max = 10,
                charset = "utf-8"
        )
        private String acptBusinId = " ";
        private Integer archAuditStatus = 0;
        @SinogramLength(
                min = 0,
                max = 6,
                charset = "utf-8"
        )
        private String archFileNo = " ";
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String auditInfo = " ";

        public PostAuditArchInnerInput() {
        }

        public String getOperatorName() {
            if (this.operatorName == null) {
                return " ";
            } else {
                return this.operatorName.isEmpty() ? " " : this.operatorName;
            }
        }

        public Character getUseType() {
            return this.useType != null ? this.useType : ' ';
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getMenuCode() {
            if (this.menuCode == null) {
                return " ";
            } else {
                return this.menuCode.isEmpty() ? " " : this.menuCode;
            }
        }

        public String getFunctionStr() {
            if (this.functionStr == null) {
                return " ";
            } else {
                return this.functionStr.isEmpty() ? " " : this.functionStr;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getCustId() {
            if (this.custId == null) {
                return " ";
            } else {
                return this.custId.isEmpty() ? " " : this.custId;
            }
        }

        public String getAcptId() {
            if (this.acptId == null) {
                return " ";
            } else {
                return this.acptId.isEmpty() ? " " : this.acptId;
            }
        }

        public String getAcptBusinKind() {
            if (this.acptBusinKind == null) {
                return " ";
            } else {
                return this.acptBusinKind.isEmpty() ? " " : this.acptBusinKind;
            }
        }

        public String getAcptBusinId() {
            if (this.acptBusinId == null) {
                return " ";
            } else {
                return this.acptBusinId.isEmpty() ? " " : this.acptBusinId;
            }
        }

        public Integer getArchAuditStatus() {
            return this.archAuditStatus != null ? this.archAuditStatus : 0;
        }

        public String getArchFileNo() {
            if (this.archFileNo == null) {
                return " ";
            } else {
                return this.archFileNo.isEmpty() ? " " : this.archFileNo;
            }
        }

        public String getAuditInfo() {
            if (this.auditInfo == null) {
                return " ";
            } else {
                return this.auditInfo.isEmpty() ? " " : this.auditInfo;
            }
        }

        public void setOperatorName(String operatorName) {
            this.operatorName = operatorName;
        }

        public void setUseType(Character useType) {
            this.useType = useType;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setMenuCode(String menuCode) {
            this.menuCode = menuCode;
        }

        public void setFunctionStr(String functionStr) {
            this.functionStr = functionStr;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setCustId(String custId) {
            this.custId = custId;
        }

        public void setAcptId(String acptId) {
            this.acptId = acptId;
        }

        public void setAcptBusinKind(String acptBusinKind) {
            this.acptBusinKind = acptBusinKind;
        }

        public void setAcptBusinId(String acptBusinId) {
            this.acptBusinId = acptBusinId;
        }

        public void setArchAuditStatus(Integer archAuditStatus) {
            this.archAuditStatus = archAuditStatus;
        }

        public void setArchFileNo(String archFileNo) {
            this.archFileNo = archFileNo;
        }

        public void setAuditInfo(String auditInfo) {
            this.auditInfo = auditInfo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostAuditArchInnerInput:(");
            buffer.append("operatorName:" + this.operatorName);
            buffer.append(",useType:" + this.useType);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",menuCode:" + this.menuCode);
            buffer.append(",functionStr:" + this.functionStr);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",custId:" + this.custId);
            buffer.append(",acptId:" + this.acptId);
            buffer.append(",acptBusinKind:" + this.acptBusinKind);
            buffer.append(",acptBusinId:" + this.acptBusinId);
            buffer.append(",archAuditStatus:" + this.archAuditStatus);
            buffer.append(",archFileNo:" + this.archFileNo);
            buffer.append(",auditInfo:" + this.auditInfo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.operatorName);
            builder.append(this.useType);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.menuCode);
            builder.append(this.functionStr);
            builder.append(this.branchNo);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.custId);
            builder.append(this.acptId);
            builder.append(this.acptBusinKind);
            builder.append(this.acptBusinId);
            builder.append(this.archAuditStatus);
            builder.append(this.archFileNo);
            builder.append(this.auditInfo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.PostAuditArchInnerInput) {
                InnerBpsService.PostAuditArchInnerInput test = (InnerBpsService.PostAuditArchInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.operatorName, test.operatorName);
                builder.append(this.useType, test.useType);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.menuCode, test.menuCode);
                builder.append(this.functionStr, test.functionStr);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.custId, test.custId);
                builder.append(this.acptId, test.acptId);
                builder.append(this.acptBusinKind, test.acptBusinKind);
                builder.append(this.acptBusinId, test.acptBusinId);
                builder.append(this.archAuditStatus, test.archAuditStatus);
                builder.append(this.archFileNo, test.archFileNo);
                builder.append(this.auditInfo, test.auditInfo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetScanConfigListInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private List<InnerBpsService.ArchscanconfiglistDTO> rows;

        public GetScanConfigListInnerOutput() {
        }

        public List<InnerBpsService.ArchscanconfiglistDTO> getRows() {
            return this.rows;
        }

        public void setRows(List<InnerBpsService.ArchscanconfiglistDTO> rows) {
            this.rows = rows;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetScanConfigListInnerOutput:(");
            buffer.append("rows:" + this.rows);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.rows);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.GetScanConfigListInnerOutput) {
                InnerBpsService.GetScanConfigListInnerOutput test = (InnerBpsService.GetScanConfigListInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.rows, test.rows);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetScanConfigListInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 60,
                charset = "utf-8"
        )
        private String operatorName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character useType = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String menuCode = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String functionStr = " ";
        private Integer branchNo = 0;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @NotNull(
                message = "不能为空"
        )
        private Integer archBusinessSysId;
        @SinogramLength(
                min = 1,
                max = 4,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String acptBusinKind;
        @SinogramLength(
                min = 1,
                max = 10,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String acptBusinId;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character organFlag;
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String filterValue = " ";
        @SinogramLength(
                min = 1,
                max = 32,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String acptId;

        public GetScanConfigListInnerInput() {
        }

        public String getOperatorName() {
            if (this.operatorName == null) {
                return " ";
            } else {
                return this.operatorName.isEmpty() ? " " : this.operatorName;
            }
        }

        public Character getUseType() {
            return this.useType != null ? this.useType : ' ';
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getMenuCode() {
            if (this.menuCode == null) {
                return " ";
            } else {
                return this.menuCode.isEmpty() ? " " : this.menuCode;
            }
        }

        public String getFunctionStr() {
            if (this.functionStr == null) {
                return " ";
            } else {
                return this.functionStr.isEmpty() ? " " : this.functionStr;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public Integer getArchBusinessSysId() {
            return this.archBusinessSysId;
        }

        public String getAcptBusinKind() {
            return this.acptBusinKind;
        }

        public String getAcptBusinId() {
            return this.acptBusinId;
        }

        public Character getOrganFlag() {
            return this.organFlag;
        }

        public String getFilterValue() {
            if (this.filterValue == null) {
                return " ";
            } else {
                return this.filterValue.isEmpty() ? " " : this.filterValue;
            }
        }

        public String getAcptId() {
            return this.acptId;
        }

        public void setOperatorName(String operatorName) {
            this.operatorName = operatorName;
        }

        public void setUseType(Character useType) {
            this.useType = useType;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setMenuCode(String menuCode) {
            this.menuCode = menuCode;
        }

        public void setFunctionStr(String functionStr) {
            this.functionStr = functionStr;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setArchBusinessSysId(Integer archBusinessSysId) {
            this.archBusinessSysId = archBusinessSysId;
        }

        public void setAcptBusinKind(String acptBusinKind) {
            this.acptBusinKind = acptBusinKind;
        }

        public void setAcptBusinId(String acptBusinId) {
            this.acptBusinId = acptBusinId;
        }

        public void setOrganFlag(Character organFlag) {
            this.organFlag = organFlag;
        }

        public void setFilterValue(String filterValue) {
            this.filterValue = filterValue;
        }

        public void setAcptId(String acptId) {
            this.acptId = acptId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetScanConfigListInnerInput:(");
            buffer.append("operatorName:" + this.operatorName);
            buffer.append(",useType:" + this.useType);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",menuCode:" + this.menuCode);
            buffer.append(",functionStr:" + this.functionStr);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",archBusinessSysId:" + this.archBusinessSysId);
            buffer.append(",acptBusinKind:" + this.acptBusinKind);
            buffer.append(",acptBusinId:" + this.acptBusinId);
            buffer.append(",organFlag:" + this.organFlag);
            buffer.append(",filterValue:" + this.filterValue);
            buffer.append(",acptId:" + this.acptId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.operatorName);
            builder.append(this.useType);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.menuCode);
            builder.append(this.functionStr);
            builder.append(this.branchNo);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.archBusinessSysId);
            builder.append(this.acptBusinKind);
            builder.append(this.acptBusinId);
            builder.append(this.organFlag);
            builder.append(this.filterValue);
            builder.append(this.acptId);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.GetScanConfigListInnerInput) {
                InnerBpsService.GetScanConfigListInnerInput test = (InnerBpsService.GetScanConfigListInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.operatorName, test.operatorName);
                builder.append(this.useType, test.useType);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.menuCode, test.menuCode);
                builder.append(this.functionStr, test.functionStr);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.archBusinessSysId, test.archBusinessSysId);
                builder.append(this.acptBusinKind, test.acptBusinKind);
                builder.append(this.acptBusinId, test.acptBusinId);
                builder.append(this.organFlag, test.organFlag);
                builder.append(this.filterValue, test.filterValue);
                builder.append(this.acptId, test.acptId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetMixEpaperInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String opRemark = " ";
        private String acptId = " ";

        public GetMixEpaperInnerOutput() {
        }

        public String getOpRemark() {
            if (this.opRemark == null) {
                return " ";
            } else {
                return this.opRemark.isEmpty() ? " " : this.opRemark;
            }
        }

        public String getAcptId() {
            if (this.acptId == null) {
                return " ";
            } else {
                return this.acptId.isEmpty() ? " " : this.acptId;
            }
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public void setAcptId(String acptId) {
            this.acptId = acptId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetMixEpaperInnerOutput:(");
            buffer.append("opRemark:" + this.opRemark);
            buffer.append(",acptId:" + this.acptId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opRemark);
            builder.append(this.acptId);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.GetMixEpaperInnerOutput) {
                InnerBpsService.GetMixEpaperInnerOutput test = (InnerBpsService.GetMixEpaperInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opRemark, test.opRemark);
                builder.append(this.acptId, test.acptId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetMixEpaperInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 60,
                charset = "utf-8"
        )
        private String operatorName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character useType = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String menuCode = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String functionStr = " ";
        private Integer branchNo = 0;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        private String signData = " ";
        private String writeData = " ";
        private String recInfo = " ";
        private String signArea = " ";
        private String writeArea = " ";
        private Integer archBusinessSysId = 0;
        @SinogramLength(
                min = 0,
                max = 6,
                charset = "utf-8"
        )
        private String archFileNo = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String custId = " ";
        @SinogramLength(
                min = 1,
                max = 32,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String acptId;
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String filePath;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character isAllSign = ' ';

        public GetMixEpaperInnerInput() {
        }

        public String getOperatorName() {
            if (this.operatorName == null) {
                return " ";
            } else {
                return this.operatorName.isEmpty() ? " " : this.operatorName;
            }
        }

        public Character getUseType() {
            return this.useType != null ? this.useType : ' ';
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getMenuCode() {
            if (this.menuCode == null) {
                return " ";
            } else {
                return this.menuCode.isEmpty() ? " " : this.menuCode;
            }
        }

        public String getFunctionStr() {
            if (this.functionStr == null) {
                return " ";
            } else {
                return this.functionStr.isEmpty() ? " " : this.functionStr;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getSignData() {
            if (this.signData == null) {
                return " ";
            } else {
                return this.signData.isEmpty() ? " " : this.signData;
            }
        }

        public String getWriteData() {
            if (this.writeData == null) {
                return " ";
            } else {
                return this.writeData.isEmpty() ? " " : this.writeData;
            }
        }

        public String getRecInfo() {
            if (this.recInfo == null) {
                return " ";
            } else {
                return this.recInfo.isEmpty() ? " " : this.recInfo;
            }
        }

        public String getSignArea() {
            if (this.signArea == null) {
                return " ";
            } else {
                return this.signArea.isEmpty() ? " " : this.signArea;
            }
        }

        public String getWriteArea() {
            if (this.writeArea == null) {
                return " ";
            } else {
                return this.writeArea.isEmpty() ? " " : this.writeArea;
            }
        }

        public Integer getArchBusinessSysId() {
            return this.archBusinessSysId != null ? this.archBusinessSysId : 0;
        }

        public String getArchFileNo() {
            if (this.archFileNo == null) {
                return " ";
            } else {
                return this.archFileNo.isEmpty() ? " " : this.archFileNo;
            }
        }

        public String getCustId() {
            if (this.custId == null) {
                return " ";
            } else {
                return this.custId.isEmpty() ? " " : this.custId;
            }
        }

        public String getAcptId() {
            return this.acptId;
        }

        public String getFilePath() {
            return this.filePath;
        }

        public Character getIsAllSign() {
            return this.isAllSign != null ? this.isAllSign : ' ';
        }

        public void setOperatorName(String operatorName) {
            this.operatorName = operatorName;
        }

        public void setUseType(Character useType) {
            this.useType = useType;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setMenuCode(String menuCode) {
            this.menuCode = menuCode;
        }

        public void setFunctionStr(String functionStr) {
            this.functionStr = functionStr;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setSignData(String signData) {
            this.signData = signData;
        }

        public void setWriteData(String writeData) {
            this.writeData = writeData;
        }

        public void setRecInfo(String recInfo) {
            this.recInfo = recInfo;
        }

        public void setSignArea(String signArea) {
            this.signArea = signArea;
        }

        public void setWriteArea(String writeArea) {
            this.writeArea = writeArea;
        }

        public void setArchBusinessSysId(Integer archBusinessSysId) {
            this.archBusinessSysId = archBusinessSysId;
        }

        public void setArchFileNo(String archFileNo) {
            this.archFileNo = archFileNo;
        }

        public void setCustId(String custId) {
            this.custId = custId;
        }

        public void setAcptId(String acptId) {
            this.acptId = acptId;
        }

        public void setFilePath(String filePath) {
            this.filePath = filePath;
        }

        public void setIsAllSign(Character isAllSign) {
            this.isAllSign = isAllSign;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetMixEpaperInnerInput:(");
            buffer.append("operatorName:" + this.operatorName);
            buffer.append(",useType:" + this.useType);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",menuCode:" + this.menuCode);
            buffer.append(",functionStr:" + this.functionStr);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",signData:" + this.signData);
            buffer.append(",writeData:" + this.writeData);
            buffer.append(",recInfo:" + this.recInfo);
            buffer.append(",signArea:" + this.signArea);
            buffer.append(",writeArea:" + this.writeArea);
            buffer.append(",archBusinessSysId:" + this.archBusinessSysId);
            buffer.append(",archFileNo:" + this.archFileNo);
            buffer.append(",custId:" + this.custId);
            buffer.append(",acptId:" + this.acptId);
            buffer.append(",filePath:" + this.filePath);
            buffer.append(",isAllSign:" + this.isAllSign);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.operatorName);
            builder.append(this.useType);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.menuCode);
            builder.append(this.functionStr);
            builder.append(this.branchNo);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.signData);
            builder.append(this.writeData);
            builder.append(this.recInfo);
            builder.append(this.signArea);
            builder.append(this.writeArea);
            builder.append(this.archBusinessSysId);
            builder.append(this.archFileNo);
            builder.append(this.custId);
            builder.append(this.acptId);
            builder.append(this.filePath);
            builder.append(this.isAllSign);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.GetMixEpaperInnerInput) {
                InnerBpsService.GetMixEpaperInnerInput test = (InnerBpsService.GetMixEpaperInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.operatorName, test.operatorName);
                builder.append(this.useType, test.useType);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.menuCode, test.menuCode);
                builder.append(this.functionStr, test.functionStr);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.signData, test.signData);
                builder.append(this.writeData, test.writeData);
                builder.append(this.recInfo, test.recInfo);
                builder.append(this.signArea, test.signArea);
                builder.append(this.writeArea, test.writeArea);
                builder.append(this.archBusinessSysId, test.archBusinessSysId);
                builder.append(this.archFileNo, test.archFileNo);
                builder.append(this.custId, test.custId);
                builder.append(this.acptId, test.acptId);
                builder.append(this.filePath, test.filePath);
                builder.append(this.isAllSign, test.isAllSign);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetEpapertemplateInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String renderField = " ";
        private Long templateId = 0L;
        private String operatorNo = " ";
        private String filePath = " ";

        public GetEpapertemplateInnerOutput() {
        }

        public String getRenderField() {
            if (this.renderField == null) {
                return " ";
            } else {
                return this.renderField.isEmpty() ? " " : this.renderField;
            }
        }

        public Long getTemplateId() {
            return this.templateId != null ? this.templateId : 0L;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getFilePath() {
            if (this.filePath == null) {
                return " ";
            } else {
                return this.filePath.isEmpty() ? " " : this.filePath;
            }
        }

        public void setRenderField(String renderField) {
            this.renderField = renderField;
        }

        public void setTemplateId(Long templateId) {
            this.templateId = templateId;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setFilePath(String filePath) {
            this.filePath = filePath;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetEpapertemplateInnerOutput:(");
            buffer.append("renderField:" + this.renderField);
            buffer.append(",templateId:" + this.templateId);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",filePath:" + this.filePath);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.renderField);
            builder.append(this.templateId);
            builder.append(this.operatorNo);
            builder.append(this.filePath);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.GetEpapertemplateInnerOutput) {
                InnerBpsService.GetEpapertemplateInnerOutput test = (InnerBpsService.GetEpapertemplateInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.renderField, test.renderField);
                builder.append(this.templateId, test.templateId);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.filePath, test.filePath);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetEpapertemplateInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 60,
                charset = "utf-8"
        )
        private String operatorName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character useType = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String menuCode = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String functionStr = " ";
        private Integer branchNo = 0;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @NotNull(
                message = "不能为空"
        )
        private Long templateId;
        @SinogramLength(
                min = 1,
                max = 6,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String archFileNo;
        @SinogramLength(
                min = 1,
                max = 32,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String acptId;
        @SinogramLength(
                min = 1,
                max = 32,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String custId;
        @SinogramLength(
                min = 0,
                max = 16000,
                charset = "utf-8"
        )
        private String renderField = " ";

        public GetEpapertemplateInnerInput() {
        }

        public String getOperatorName() {
            if (this.operatorName == null) {
                return " ";
            } else {
                return this.operatorName.isEmpty() ? " " : this.operatorName;
            }
        }

        public Character getUseType() {
            return this.useType != null ? this.useType : ' ';
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getMenuCode() {
            if (this.menuCode == null) {
                return " ";
            } else {
                return this.menuCode.isEmpty() ? " " : this.menuCode;
            }
        }

        public String getFunctionStr() {
            if (this.functionStr == null) {
                return " ";
            } else {
                return this.functionStr.isEmpty() ? " " : this.functionStr;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public Long getTemplateId() {
            return this.templateId;
        }

        public String getArchFileNo() {
            return this.archFileNo;
        }

        public String getAcptId() {
            return this.acptId;
        }

        public String getCustId() {
            return this.custId;
        }

        public String getRenderField() {
            if (this.renderField == null) {
                return " ";
            } else {
                return this.renderField.isEmpty() ? " " : this.renderField;
            }
        }

        public void setOperatorName(String operatorName) {
            this.operatorName = operatorName;
        }

        public void setUseType(Character useType) {
            this.useType = useType;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setMenuCode(String menuCode) {
            this.menuCode = menuCode;
        }

        public void setFunctionStr(String functionStr) {
            this.functionStr = functionStr;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setTemplateId(Long templateId) {
            this.templateId = templateId;
        }

        public void setArchFileNo(String archFileNo) {
            this.archFileNo = archFileNo;
        }

        public void setAcptId(String acptId) {
            this.acptId = acptId;
        }

        public void setCustId(String custId) {
            this.custId = custId;
        }

        public void setRenderField(String renderField) {
            this.renderField = renderField;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetEpapertemplateInnerInput:(");
            buffer.append("operatorName:" + this.operatorName);
            buffer.append(",useType:" + this.useType);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",menuCode:" + this.menuCode);
            buffer.append(",functionStr:" + this.functionStr);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",templateId:" + this.templateId);
            buffer.append(",archFileNo:" + this.archFileNo);
            buffer.append(",acptId:" + this.acptId);
            buffer.append(",custId:" + this.custId);
            buffer.append(",renderField:" + this.renderField);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.operatorName);
            builder.append(this.useType);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.menuCode);
            builder.append(this.functionStr);
            builder.append(this.branchNo);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.templateId);
            builder.append(this.archFileNo);
            builder.append(this.acptId);
            builder.append(this.custId);
            builder.append(this.renderField);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.GetEpapertemplateInnerInput) {
                InnerBpsService.GetEpapertemplateInnerInput test = (InnerBpsService.GetEpapertemplateInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.operatorName, test.operatorName);
                builder.append(this.useType, test.useType);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.menuCode, test.menuCode);
                builder.append(this.functionStr, test.functionStr);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.templateId, test.templateId);
                builder.append(this.archFileNo, test.archFileNo);
                builder.append(this.acptId, test.acptId);
                builder.append(this.custId, test.custId);
                builder.append(this.renderField, test.renderField);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetBpsTplInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer total = 0;
        private List<InnerBpsService.AcpttplDTO> rows;

        public GetBpsTplInnerOutput() {
        }

        public Integer getTotal() {
            return this.total != null ? this.total : 0;
        }

        public List<InnerBpsService.AcpttplDTO> getRows() {
            return this.rows;
        }

        public void setTotal(Integer total) {
            this.total = total;
        }

        public void setRows(List<InnerBpsService.AcpttplDTO> rows) {
            this.rows = rows;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetBpsTplInnerOutput:(");
            buffer.append("total:" + this.total);
            buffer.append(",rows:" + this.rows);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.total);
            builder.append(this.rows);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.GetBpsTplInnerOutput) {
                InnerBpsService.GetBpsTplInnerOutput test = (InnerBpsService.GetBpsTplInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.total, test.total);
                builder.append(this.rows, test.rows);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetBpsTplInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 60,
                charset = "utf-8"
        )
        private String operatorName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character useType = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String menuCode = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String functionStr = " ";
        private Integer branchNo = 0;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String acptBusinKind = " ";
        @SinogramLength(
                min = 0,
                max = 10,
                charset = "utf-8"
        )
        private String acptBusinId = " ";
        private Integer pageNo = 0;
        private Integer pageSize = 0;
        private Integer requestNum = 0;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String menuCodeQry = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character acptType = ' ';
        @SinogramLength(
                min = 0,
                max = 180,
                charset = "utf-8"
        )
        private String acptCategoryName = " ";

        public GetBpsTplInnerInput() {
        }

        public String getOperatorName() {
            if (this.operatorName == null) {
                return " ";
            } else {
                return this.operatorName.isEmpty() ? " " : this.operatorName;
            }
        }

        public Character getUseType() {
            return this.useType != null ? this.useType : ' ';
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getMenuCode() {
            if (this.menuCode == null) {
                return " ";
            } else {
                return this.menuCode.isEmpty() ? " " : this.menuCode;
            }
        }

        public String getFunctionStr() {
            if (this.functionStr == null) {
                return " ";
            } else {
                return this.functionStr.isEmpty() ? " " : this.functionStr;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getAcptBusinKind() {
            if (this.acptBusinKind == null) {
                return " ";
            } else {
                return this.acptBusinKind.isEmpty() ? " " : this.acptBusinKind;
            }
        }

        public String getAcptBusinId() {
            if (this.acptBusinId == null) {
                return " ";
            } else {
                return this.acptBusinId.isEmpty() ? " " : this.acptBusinId;
            }
        }

        public Integer getPageNo() {
            return this.pageNo != null ? this.pageNo : 0;
        }

        public Integer getPageSize() {
            return this.pageSize != null ? this.pageSize : 0;
        }

        public Integer getRequestNum() {
            return this.requestNum != null ? this.requestNum : 0;
        }

        public String getMenuCodeQry() {
            if (this.menuCodeQry == null) {
                return " ";
            } else {
                return this.menuCodeQry.isEmpty() ? " " : this.menuCodeQry;
            }
        }

        public Character getAcptType() {
            return this.acptType != null ? this.acptType : ' ';
        }

        public String getAcptCategoryName() {
            if (this.acptCategoryName == null) {
                return " ";
            } else {
                return this.acptCategoryName.isEmpty() ? " " : this.acptCategoryName;
            }
        }

        public void setOperatorName(String operatorName) {
            this.operatorName = operatorName;
        }

        public void setUseType(Character useType) {
            this.useType = useType;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setMenuCode(String menuCode) {
            this.menuCode = menuCode;
        }

        public void setFunctionStr(String functionStr) {
            this.functionStr = functionStr;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setAcptBusinKind(String acptBusinKind) {
            this.acptBusinKind = acptBusinKind;
        }

        public void setAcptBusinId(String acptBusinId) {
            this.acptBusinId = acptBusinId;
        }

        public void setPageNo(Integer pageNo) {
            this.pageNo = pageNo;
        }

        public void setPageSize(Integer pageSize) {
            this.pageSize = pageSize;
        }

        public void setRequestNum(Integer requestNum) {
            this.requestNum = requestNum;
        }

        public void setMenuCodeQry(String menuCodeQry) {
            this.menuCodeQry = menuCodeQry;
        }

        public void setAcptType(Character acptType) {
            this.acptType = acptType;
        }

        public void setAcptCategoryName(String acptCategoryName) {
            this.acptCategoryName = acptCategoryName;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetBpsTplInnerInput:(");
            buffer.append("operatorName:" + this.operatorName);
            buffer.append(",useType:" + this.useType);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",menuCode:" + this.menuCode);
            buffer.append(",functionStr:" + this.functionStr);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",acptBusinKind:" + this.acptBusinKind);
            buffer.append(",acptBusinId:" + this.acptBusinId);
            buffer.append(",pageNo:" + this.pageNo);
            buffer.append(",pageSize:" + this.pageSize);
            buffer.append(",requestNum:" + this.requestNum);
            buffer.append(",menuCodeQry:" + this.menuCodeQry);
            buffer.append(",acptType:" + this.acptType);
            buffer.append(",acptCategoryName:" + this.acptCategoryName);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.operatorName);
            builder.append(this.useType);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.menuCode);
            builder.append(this.functionStr);
            builder.append(this.branchNo);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.acptBusinKind);
            builder.append(this.acptBusinId);
            builder.append(this.pageNo);
            builder.append(this.pageSize);
            builder.append(this.requestNum);
            builder.append(this.menuCodeQry);
            builder.append(this.acptType);
            builder.append(this.acptCategoryName);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.GetBpsTplInnerInput) {
                InnerBpsService.GetBpsTplInnerInput test = (InnerBpsService.GetBpsTplInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.operatorName, test.operatorName);
                builder.append(this.useType, test.useType);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.menuCode, test.menuCode);
                builder.append(this.functionStr, test.functionStr);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.acptBusinKind, test.acptBusinKind);
                builder.append(this.acptBusinId, test.acptBusinId);
                builder.append(this.pageNo, test.pageNo);
                builder.append(this.pageSize, test.pageSize);
                builder.append(this.requestNum, test.requestNum);
                builder.append(this.menuCodeQry, test.menuCodeQry);
                builder.append(this.acptType, test.acptType);
                builder.append(this.acptCategoryName, test.acptCategoryName);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetBpsTplDetailsInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String acptBusinKind = " ";
        private String acptBusinId = " ";
        private String acptCategoryName = " ";
        private String processNo = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character upFlag = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character isEsign = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character modifiable = ' ';
        private String enSubOpType = " ";
        private String acptProcessStr = " ";
        private String acptTplFlags = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character agreementStatus = ' ';
        private Integer beginTime = 0;
        private Integer endTime = 0;
        private String acptTip = " ";
        private String menuCode = " ";
        private String enFunctionStr = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character acptType = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character auditFlag = ' ';
        private String acptEnrouteStr = " ";
        private String callbackFunctionStr = " ";
        private String acptTplExt = " ";
        private List<InnerBpsService.AcptsubnodeDTO> subNodes;

        public GetBpsTplDetailsInnerOutput() {
        }

        public String getAcptBusinKind() {
            if (this.acptBusinKind == null) {
                return " ";
            } else {
                return this.acptBusinKind.isEmpty() ? " " : this.acptBusinKind;
            }
        }

        public String getAcptBusinId() {
            if (this.acptBusinId == null) {
                return " ";
            } else {
                return this.acptBusinId.isEmpty() ? " " : this.acptBusinId;
            }
        }

        public String getAcptCategoryName() {
            if (this.acptCategoryName == null) {
                return " ";
            } else {
                return this.acptCategoryName.isEmpty() ? " " : this.acptCategoryName;
            }
        }

        public String getProcessNo() {
            if (this.processNo == null) {
                return " ";
            } else {
                return this.processNo.isEmpty() ? " " : this.processNo;
            }
        }

        public Character getUpFlag() {
            return this.upFlag != null ? this.upFlag : ' ';
        }

        public Character getIsEsign() {
            return this.isEsign != null ? this.isEsign : ' ';
        }

        public Character getModifiable() {
            return this.modifiable != null ? this.modifiable : ' ';
        }

        public String getEnSubOpType() {
            if (this.enSubOpType == null) {
                return " ";
            } else {
                return this.enSubOpType.isEmpty() ? " " : this.enSubOpType;
            }
        }

        public String getAcptProcessStr() {
            if (this.acptProcessStr == null) {
                return " ";
            } else {
                return this.acptProcessStr.isEmpty() ? " " : this.acptProcessStr;
            }
        }

        public String getAcptTplFlags() {
            if (this.acptTplFlags == null) {
                return " ";
            } else {
                return this.acptTplFlags.isEmpty() ? " " : this.acptTplFlags;
            }
        }

        public Character getAgreementStatus() {
            return this.agreementStatus != null ? this.agreementStatus : ' ';
        }

        public Integer getBeginTime() {
            return this.beginTime != null ? this.beginTime : 0;
        }

        public Integer getEndTime() {
            return this.endTime != null ? this.endTime : 0;
        }

        public String getAcptTip() {
            if (this.acptTip == null) {
                return " ";
            } else {
                return this.acptTip.isEmpty() ? " " : this.acptTip;
            }
        }

        public String getMenuCode() {
            if (this.menuCode == null) {
                return " ";
            } else {
                return this.menuCode.isEmpty() ? " " : this.menuCode;
            }
        }

        public String getEnFunctionStr() {
            if (this.enFunctionStr == null) {
                return " ";
            } else {
                return this.enFunctionStr.isEmpty() ? " " : this.enFunctionStr;
            }
        }

        public Character getAcptType() {
            return this.acptType != null ? this.acptType : ' ';
        }

        public Character getAuditFlag() {
            return this.auditFlag != null ? this.auditFlag : ' ';
        }

        public String getAcptEnrouteStr() {
            if (this.acptEnrouteStr == null) {
                return " ";
            } else {
                return this.acptEnrouteStr.isEmpty() ? " " : this.acptEnrouteStr;
            }
        }

        public String getCallbackFunctionStr() {
            if (this.callbackFunctionStr == null) {
                return " ";
            } else {
                return this.callbackFunctionStr.isEmpty() ? " " : this.callbackFunctionStr;
            }
        }

        public String getAcptTplExt() {
            if (this.acptTplExt == null) {
                return " ";
            } else {
                return this.acptTplExt.isEmpty() ? " " : this.acptTplExt;
            }
        }

        public List<InnerBpsService.AcptsubnodeDTO> getSubNodes() {
            return this.subNodes;
        }

        public void setAcptBusinKind(String acptBusinKind) {
            this.acptBusinKind = acptBusinKind;
        }

        public void setAcptBusinId(String acptBusinId) {
            this.acptBusinId = acptBusinId;
        }

        public void setAcptCategoryName(String acptCategoryName) {
            this.acptCategoryName = acptCategoryName;
        }

        public void setProcessNo(String processNo) {
            this.processNo = processNo;
        }

        public void setUpFlag(Character upFlag) {
            this.upFlag = upFlag;
        }

        public void setIsEsign(Character isEsign) {
            this.isEsign = isEsign;
        }

        public void setModifiable(Character modifiable) {
            this.modifiable = modifiable;
        }

        public void setEnSubOpType(String enSubOpType) {
            this.enSubOpType = enSubOpType;
        }

        public void setAcptProcessStr(String acptProcessStr) {
            this.acptProcessStr = acptProcessStr;
        }

        public void setAcptTplFlags(String acptTplFlags) {
            this.acptTplFlags = acptTplFlags;
        }

        public void setAgreementStatus(Character agreementStatus) {
            this.agreementStatus = agreementStatus;
        }

        public void setBeginTime(Integer beginTime) {
            this.beginTime = beginTime;
        }

        public void setEndTime(Integer endTime) {
            this.endTime = endTime;
        }

        public void setAcptTip(String acptTip) {
            this.acptTip = acptTip;
        }

        public void setMenuCode(String menuCode) {
            this.menuCode = menuCode;
        }

        public void setEnFunctionStr(String enFunctionStr) {
            this.enFunctionStr = enFunctionStr;
        }

        public void setAcptType(Character acptType) {
            this.acptType = acptType;
        }

        public void setAuditFlag(Character auditFlag) {
            this.auditFlag = auditFlag;
        }

        public void setAcptEnrouteStr(String acptEnrouteStr) {
            this.acptEnrouteStr = acptEnrouteStr;
        }

        public void setCallbackFunctionStr(String callbackFunctionStr) {
            this.callbackFunctionStr = callbackFunctionStr;
        }

        public void setAcptTplExt(String acptTplExt) {
            this.acptTplExt = acptTplExt;
        }

        public void setSubNodes(List<InnerBpsService.AcptsubnodeDTO> subNodes) {
            this.subNodes = subNodes;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetBpsTplDetailsInnerOutput:(");
            buffer.append("acptBusinKind:" + this.acptBusinKind);
            buffer.append(",acptBusinId:" + this.acptBusinId);
            buffer.append(",acptCategoryName:" + this.acptCategoryName);
            buffer.append(",processNo:" + this.processNo);
            buffer.append(",upFlag:" + this.upFlag);
            buffer.append(",isEsign:" + this.isEsign);
            buffer.append(",modifiable:" + this.modifiable);
            buffer.append(",enSubOpType:" + this.enSubOpType);
            buffer.append(",acptProcessStr:" + this.acptProcessStr);
            buffer.append(",acptTplFlags:" + this.acptTplFlags);
            buffer.append(",agreementStatus:" + this.agreementStatus);
            buffer.append(",beginTime:" + this.beginTime);
            buffer.append(",endTime:" + this.endTime);
            buffer.append(",acptTip:" + this.acptTip);
            buffer.append(",menuCode:" + this.menuCode);
            buffer.append(",enFunctionStr:" + this.enFunctionStr);
            buffer.append(",acptType:" + this.acptType);
            buffer.append(",auditFlag:" + this.auditFlag);
            buffer.append(",acptEnrouteStr:" + this.acptEnrouteStr);
            buffer.append(",callbackFunctionStr:" + this.callbackFunctionStr);
            buffer.append(",acptTplExt:" + this.acptTplExt);
            buffer.append(",subNodes:" + this.subNodes);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.acptBusinKind);
            builder.append(this.acptBusinId);
            builder.append(this.acptCategoryName);
            builder.append(this.processNo);
            builder.append(this.upFlag);
            builder.append(this.isEsign);
            builder.append(this.modifiable);
            builder.append(this.enSubOpType);
            builder.append(this.acptProcessStr);
            builder.append(this.acptTplFlags);
            builder.append(this.agreementStatus);
            builder.append(this.beginTime);
            builder.append(this.endTime);
            builder.append(this.acptTip);
            builder.append(this.menuCode);
            builder.append(this.enFunctionStr);
            builder.append(this.acptType);
            builder.append(this.auditFlag);
            builder.append(this.acptEnrouteStr);
            builder.append(this.callbackFunctionStr);
            builder.append(this.acptTplExt);
            builder.append(this.subNodes);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.GetBpsTplDetailsInnerOutput) {
                InnerBpsService.GetBpsTplDetailsInnerOutput test = (InnerBpsService.GetBpsTplDetailsInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.acptBusinKind, test.acptBusinKind);
                builder.append(this.acptBusinId, test.acptBusinId);
                builder.append(this.acptCategoryName, test.acptCategoryName);
                builder.append(this.processNo, test.processNo);
                builder.append(this.upFlag, test.upFlag);
                builder.append(this.isEsign, test.isEsign);
                builder.append(this.modifiable, test.modifiable);
                builder.append(this.enSubOpType, test.enSubOpType);
                builder.append(this.acptProcessStr, test.acptProcessStr);
                builder.append(this.acptTplFlags, test.acptTplFlags);
                builder.append(this.agreementStatus, test.agreementStatus);
                builder.append(this.beginTime, test.beginTime);
                builder.append(this.endTime, test.endTime);
                builder.append(this.acptTip, test.acptTip);
                builder.append(this.menuCode, test.menuCode);
                builder.append(this.enFunctionStr, test.enFunctionStr);
                builder.append(this.acptType, test.acptType);
                builder.append(this.auditFlag, test.auditFlag);
                builder.append(this.acptEnrouteStr, test.acptEnrouteStr);
                builder.append(this.callbackFunctionStr, test.callbackFunctionStr);
                builder.append(this.acptTplExt, test.acptTplExt);
                builder.append(this.subNodes, test.subNodes);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetBpsTplDetailsInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 60,
                charset = "utf-8"
        )
        private String operatorName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character useType = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String menuCode = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String functionStr = " ";
        private Integer branchNo = 0;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 4,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String acptBusinKind;
        @SinogramLength(
                min = 1,
                max = 10,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String acptBusinId;

        public GetBpsTplDetailsInnerInput() {
        }

        public String getOperatorName() {
            if (this.operatorName == null) {
                return " ";
            } else {
                return this.operatorName.isEmpty() ? " " : this.operatorName;
            }
        }

        public Character getUseType() {
            return this.useType != null ? this.useType : ' ';
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getMenuCode() {
            if (this.menuCode == null) {
                return " ";
            } else {
                return this.menuCode.isEmpty() ? " " : this.menuCode;
            }
        }

        public String getFunctionStr() {
            if (this.functionStr == null) {
                return " ";
            } else {
                return this.functionStr.isEmpty() ? " " : this.functionStr;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getAcptBusinKind() {
            return this.acptBusinKind;
        }

        public String getAcptBusinId() {
            return this.acptBusinId;
        }

        public void setOperatorName(String operatorName) {
            this.operatorName = operatorName;
        }

        public void setUseType(Character useType) {
            this.useType = useType;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setMenuCode(String menuCode) {
            this.menuCode = menuCode;
        }

        public void setFunctionStr(String functionStr) {
            this.functionStr = functionStr;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setAcptBusinKind(String acptBusinKind) {
            this.acptBusinKind = acptBusinKind;
        }

        public void setAcptBusinId(String acptBusinId) {
            this.acptBusinId = acptBusinId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetBpsTplDetailsInnerInput:(");
            buffer.append("operatorName:" + this.operatorName);
            buffer.append(",useType:" + this.useType);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",menuCode:" + this.menuCode);
            buffer.append(",functionStr:" + this.functionStr);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",acptBusinKind:" + this.acptBusinKind);
            buffer.append(",acptBusinId:" + this.acptBusinId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.operatorName);
            builder.append(this.useType);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.menuCode);
            builder.append(this.functionStr);
            builder.append(this.branchNo);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.acptBusinKind);
            builder.append(this.acptBusinId);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.GetBpsTplDetailsInnerInput) {
                InnerBpsService.GetBpsTplDetailsInnerInput test = (InnerBpsService.GetBpsTplDetailsInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.operatorName, test.operatorName);
                builder.append(this.useType, test.useType);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.menuCode, test.menuCode);
                builder.append(this.functionStr, test.functionStr);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.acptBusinKind, test.acptBusinKind);
                builder.append(this.acptBusinId, test.acptBusinId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetBpsOperatorTodoTaskInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private List<InnerBpsService.OperatortaskDTO> rows;
        private Integer total = 0;

        public GetBpsOperatorTodoTaskInnerOutput() {
        }

        public List<InnerBpsService.OperatortaskDTO> getRows() {
            return this.rows;
        }

        public Integer getTotal() {
            return this.total != null ? this.total : 0;
        }

        public void setRows(List<InnerBpsService.OperatortaskDTO> rows) {
            this.rows = rows;
        }

        public void setTotal(Integer total) {
            this.total = total;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetBpsOperatorTodoTaskInnerOutput:(");
            buffer.append("rows:" + this.rows);
            buffer.append(",total:" + this.total);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.rows);
            builder.append(this.total);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.GetBpsOperatorTodoTaskInnerOutput) {
                InnerBpsService.GetBpsOperatorTodoTaskInnerOutput test = (InnerBpsService.GetBpsOperatorTodoTaskInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.rows, test.rows);
                builder.append(this.total, test.total);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetBpsOperatorTodoTaskInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 60,
                charset = "utf-8"
        )
        private String operatorName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character useType = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String menuCode = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String functionStr = " ";
        private Integer branchNo = 0;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String clientId = " ";
        @SinogramLength(
                min = 0,
                max = 180,
                charset = "utf-8"
        )
        private String fullName = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String acptId = " ";
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String acptBusinKind = " ";
        @SinogramLength(
                min = 0,
                max = 10,
                charset = "utf-8"
        )
        private String acptBusinId = " ";
        private Integer beginDate = 0;
        private Integer endDate = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character acptType = ' ';
        private Integer pageNo = 0;
        private Integer pageSize = 0;
        private Integer requestNum = 0;
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String queryStr = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character actionFlag = ' ';

        public GetBpsOperatorTodoTaskInnerInput() {
        }

        public String getOperatorName() {
            if (this.operatorName == null) {
                return " ";
            } else {
                return this.operatorName.isEmpty() ? " " : this.operatorName;
            }
        }

        public Character getUseType() {
            return this.useType != null ? this.useType : ' ';
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getMenuCode() {
            if (this.menuCode == null) {
                return " ";
            } else {
                return this.menuCode.isEmpty() ? " " : this.menuCode;
            }
        }

        public String getFunctionStr() {
            if (this.functionStr == null) {
                return " ";
            } else {
                return this.functionStr.isEmpty() ? " " : this.functionStr;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getFullName() {
            if (this.fullName == null) {
                return " ";
            } else {
                return this.fullName.isEmpty() ? " " : this.fullName;
            }
        }

        public String getAcptId() {
            if (this.acptId == null) {
                return " ";
            } else {
                return this.acptId.isEmpty() ? " " : this.acptId;
            }
        }

        public String getAcptBusinKind() {
            if (this.acptBusinKind == null) {
                return " ";
            } else {
                return this.acptBusinKind.isEmpty() ? " " : this.acptBusinKind;
            }
        }

        public String getAcptBusinId() {
            if (this.acptBusinId == null) {
                return " ";
            } else {
                return this.acptBusinId.isEmpty() ? " " : this.acptBusinId;
            }
        }

        public Integer getBeginDate() {
            return this.beginDate != null ? this.beginDate : 0;
        }

        public Integer getEndDate() {
            return this.endDate != null ? this.endDate : 0;
        }

        public Character getAcptType() {
            return this.acptType != null ? this.acptType : ' ';
        }

        public Integer getPageNo() {
            return this.pageNo != null ? this.pageNo : 0;
        }

        public Integer getPageSize() {
            return this.pageSize != null ? this.pageSize : 0;
        }

        public Integer getRequestNum() {
            return this.requestNum != null ? this.requestNum : 0;
        }

        public String getQueryStr() {
            if (this.queryStr == null) {
                return " ";
            } else {
                return this.queryStr.isEmpty() ? " " : this.queryStr;
            }
        }

        public Character getActionFlag() {
            return this.actionFlag != null ? this.actionFlag : ' ';
        }

        public void setOperatorName(String operatorName) {
            this.operatorName = operatorName;
        }

        public void setUseType(Character useType) {
            this.useType = useType;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setMenuCode(String menuCode) {
            this.menuCode = menuCode;
        }

        public void setFunctionStr(String functionStr) {
            this.functionStr = functionStr;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setFullName(String fullName) {
            this.fullName = fullName;
        }

        public void setAcptId(String acptId) {
            this.acptId = acptId;
        }

        public void setAcptBusinKind(String acptBusinKind) {
            this.acptBusinKind = acptBusinKind;
        }

        public void setAcptBusinId(String acptBusinId) {
            this.acptBusinId = acptBusinId;
        }

        public void setBeginDate(Integer beginDate) {
            this.beginDate = beginDate;
        }

        public void setEndDate(Integer endDate) {
            this.endDate = endDate;
        }

        public void setAcptType(Character acptType) {
            this.acptType = acptType;
        }

        public void setPageNo(Integer pageNo) {
            this.pageNo = pageNo;
        }

        public void setPageSize(Integer pageSize) {
            this.pageSize = pageSize;
        }

        public void setRequestNum(Integer requestNum) {
            this.requestNum = requestNum;
        }

        public void setQueryStr(String queryStr) {
            this.queryStr = queryStr;
        }

        public void setActionFlag(Character actionFlag) {
            this.actionFlag = actionFlag;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetBpsOperatorTodoTaskInnerInput:(");
            buffer.append("operatorName:" + this.operatorName);
            buffer.append(",useType:" + this.useType);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",menuCode:" + this.menuCode);
            buffer.append(",functionStr:" + this.functionStr);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",fullName:" + this.fullName);
            buffer.append(",acptId:" + this.acptId);
            buffer.append(",acptBusinKind:" + this.acptBusinKind);
            buffer.append(",acptBusinId:" + this.acptBusinId);
            buffer.append(",beginDate:" + this.beginDate);
            buffer.append(",endDate:" + this.endDate);
            buffer.append(",acptType:" + this.acptType);
            buffer.append(",pageNo:" + this.pageNo);
            buffer.append(",pageSize:" + this.pageSize);
            buffer.append(",requestNum:" + this.requestNum);
            buffer.append(",queryStr:" + this.queryStr);
            buffer.append(",actionFlag:" + this.actionFlag);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.operatorName);
            builder.append(this.useType);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.menuCode);
            builder.append(this.functionStr);
            builder.append(this.branchNo);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.clientId);
            builder.append(this.fullName);
            builder.append(this.acptId);
            builder.append(this.acptBusinKind);
            builder.append(this.acptBusinId);
            builder.append(this.beginDate);
            builder.append(this.endDate);
            builder.append(this.acptType);
            builder.append(this.pageNo);
            builder.append(this.pageSize);
            builder.append(this.requestNum);
            builder.append(this.queryStr);
            builder.append(this.actionFlag);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.GetBpsOperatorTodoTaskInnerInput) {
                InnerBpsService.GetBpsOperatorTodoTaskInnerInput test = (InnerBpsService.GetBpsOperatorTodoTaskInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.operatorName, test.operatorName);
                builder.append(this.useType, test.useType);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.menuCode, test.menuCode);
                builder.append(this.functionStr, test.functionStr);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.clientId, test.clientId);
                builder.append(this.fullName, test.fullName);
                builder.append(this.acptId, test.acptId);
                builder.append(this.acptBusinKind, test.acptBusinKind);
                builder.append(this.acptBusinId, test.acptBusinId);
                builder.append(this.beginDate, test.beginDate);
                builder.append(this.endDate, test.endDate);
                builder.append(this.acptType, test.acptType);
                builder.append(this.pageNo, test.pageNo);
                builder.append(this.pageSize, test.pageSize);
                builder.append(this.requestNum, test.requestNum);
                builder.append(this.queryStr, test.queryStr);
                builder.append(this.actionFlag, test.actionFlag);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetBpsOperatorToClaimTaskInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private List<InnerBpsService.OperatorToClaimTask> rows;
        private Integer total = 0;

        public GetBpsOperatorToClaimTaskInnerOutput() {
        }

        public List<InnerBpsService.OperatorToClaimTask> getRows() {
            return this.rows;
        }

        public Integer getTotal() {
            return this.total != null ? this.total : 0;
        }

        public void setRows(List<InnerBpsService.OperatorToClaimTask> rows) {
            this.rows = rows;
        }

        public void setTotal(Integer total) {
            this.total = total;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetBpsOperatorToClaimTaskInnerOutput:(");
            buffer.append("rows:" + this.rows);
            buffer.append(",total:" + this.total);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.rows);
            builder.append(this.total);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.GetBpsOperatorToClaimTaskInnerOutput) {
                InnerBpsService.GetBpsOperatorToClaimTaskInnerOutput test = (InnerBpsService.GetBpsOperatorToClaimTaskInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.rows, test.rows);
                builder.append(this.total, test.total);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetBpsOperatorToClaimTaskInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 60,
                charset = "utf-8"
        )
        private String operatorName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character useType = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String menuCode = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String functionStr = " ";
        private Integer branchNo = 0;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String loginAccount = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String clientId = " ";
        @SinogramLength(
                min = 0,
                max = 180,
                charset = "utf-8"
        )
        private String fullName = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String acptId = " ";
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String acptBusinKind = " ";
        @SinogramLength(
                min = 0,
                max = 10,
                charset = "utf-8"
        )
        private String acptBusinId = " ";
        private Integer beginDate = 0;
        private Integer endDate = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character acptType = ' ';
        private Integer pageNo = 0;
        private Integer pageSize = 0;
        private Integer requestNum = 0;
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String queryStr = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character actionFlag = ' ';

        public GetBpsOperatorToClaimTaskInnerInput() {
        }

        public String getOperatorName() {
            if (this.operatorName == null) {
                return " ";
            } else {
                return this.operatorName.isEmpty() ? " " : this.operatorName;
            }
        }

        public Character getUseType() {
            return this.useType != null ? this.useType : ' ';
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getMenuCode() {
            if (this.menuCode == null) {
                return " ";
            } else {
                return this.menuCode.isEmpty() ? " " : this.menuCode;
            }
        }

        public String getFunctionStr() {
            if (this.functionStr == null) {
                return " ";
            } else {
                return this.functionStr.isEmpty() ? " " : this.functionStr;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getLoginAccount() {
            if (this.loginAccount == null) {
                return " ";
            } else {
                return this.loginAccount.isEmpty() ? " " : this.loginAccount;
            }
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getFullName() {
            if (this.fullName == null) {
                return " ";
            } else {
                return this.fullName.isEmpty() ? " " : this.fullName;
            }
        }

        public String getAcptId() {
            if (this.acptId == null) {
                return " ";
            } else {
                return this.acptId.isEmpty() ? " " : this.acptId;
            }
        }

        public String getAcptBusinKind() {
            if (this.acptBusinKind == null) {
                return " ";
            } else {
                return this.acptBusinKind.isEmpty() ? " " : this.acptBusinKind;
            }
        }

        public String getAcptBusinId() {
            if (this.acptBusinId == null) {
                return " ";
            } else {
                return this.acptBusinId.isEmpty() ? " " : this.acptBusinId;
            }
        }

        public Integer getBeginDate() {
            return this.beginDate != null ? this.beginDate : 0;
        }

        public Integer getEndDate() {
            return this.endDate != null ? this.endDate : 0;
        }

        public Character getAcptType() {
            return this.acptType != null ? this.acptType : ' ';
        }

        public Integer getPageNo() {
            return this.pageNo != null ? this.pageNo : 0;
        }

        public Integer getPageSize() {
            return this.pageSize != null ? this.pageSize : 0;
        }

        public Integer getRequestNum() {
            return this.requestNum != null ? this.requestNum : 0;
        }

        public String getQueryStr() {
            if (this.queryStr == null) {
                return " ";
            } else {
                return this.queryStr.isEmpty() ? " " : this.queryStr;
            }
        }

        public Character getActionFlag() {
            return this.actionFlag != null ? this.actionFlag : ' ';
        }

        public void setOperatorName(String operatorName) {
            this.operatorName = operatorName;
        }

        public void setUseType(Character useType) {
            this.useType = useType;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setMenuCode(String menuCode) {
            this.menuCode = menuCode;
        }

        public void setFunctionStr(String functionStr) {
            this.functionStr = functionStr;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setLoginAccount(String loginAccount) {
            this.loginAccount = loginAccount;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setFullName(String fullName) {
            this.fullName = fullName;
        }

        public void setAcptId(String acptId) {
            this.acptId = acptId;
        }

        public void setAcptBusinKind(String acptBusinKind) {
            this.acptBusinKind = acptBusinKind;
        }

        public void setAcptBusinId(String acptBusinId) {
            this.acptBusinId = acptBusinId;
        }

        public void setBeginDate(Integer beginDate) {
            this.beginDate = beginDate;
        }

        public void setEndDate(Integer endDate) {
            this.endDate = endDate;
        }

        public void setAcptType(Character acptType) {
            this.acptType = acptType;
        }

        public void setPageNo(Integer pageNo) {
            this.pageNo = pageNo;
        }

        public void setPageSize(Integer pageSize) {
            this.pageSize = pageSize;
        }

        public void setRequestNum(Integer requestNum) {
            this.requestNum = requestNum;
        }

        public void setQueryStr(String queryStr) {
            this.queryStr = queryStr;
        }

        public void setActionFlag(Character actionFlag) {
            this.actionFlag = actionFlag;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetBpsOperatorToClaimTaskInnerInput:(");
            buffer.append("operatorName:" + this.operatorName);
            buffer.append(",useType:" + this.useType);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",menuCode:" + this.menuCode);
            buffer.append(",functionStr:" + this.functionStr);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",loginAccount:" + this.loginAccount);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",fullName:" + this.fullName);
            buffer.append(",acptId:" + this.acptId);
            buffer.append(",acptBusinKind:" + this.acptBusinKind);
            buffer.append(",acptBusinId:" + this.acptBusinId);
            buffer.append(",beginDate:" + this.beginDate);
            buffer.append(",endDate:" + this.endDate);
            buffer.append(",acptType:" + this.acptType);
            buffer.append(",pageNo:" + this.pageNo);
            buffer.append(",pageSize:" + this.pageSize);
            buffer.append(",requestNum:" + this.requestNum);
            buffer.append(",queryStr:" + this.queryStr);
            buffer.append(",actionFlag:" + this.actionFlag);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.operatorName);
            builder.append(this.useType);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.menuCode);
            builder.append(this.functionStr);
            builder.append(this.branchNo);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.loginAccount);
            builder.append(this.clientId);
            builder.append(this.fullName);
            builder.append(this.acptId);
            builder.append(this.acptBusinKind);
            builder.append(this.acptBusinId);
            builder.append(this.beginDate);
            builder.append(this.endDate);
            builder.append(this.acptType);
            builder.append(this.pageNo);
            builder.append(this.pageSize);
            builder.append(this.requestNum);
            builder.append(this.queryStr);
            builder.append(this.actionFlag);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.GetBpsOperatorToClaimTaskInnerInput) {
                InnerBpsService.GetBpsOperatorToClaimTaskInnerInput test = (InnerBpsService.GetBpsOperatorToClaimTaskInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.operatorName, test.operatorName);
                builder.append(this.useType, test.useType);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.menuCode, test.menuCode);
                builder.append(this.functionStr, test.functionStr);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.loginAccount, test.loginAccount);
                builder.append(this.clientId, test.clientId);
                builder.append(this.fullName, test.fullName);
                builder.append(this.acptId, test.acptId);
                builder.append(this.acptBusinKind, test.acptBusinKind);
                builder.append(this.acptBusinId, test.acptBusinId);
                builder.append(this.beginDate, test.beginDate);
                builder.append(this.endDate, test.endDate);
                builder.append(this.acptType, test.acptType);
                builder.append(this.pageNo, test.pageNo);
                builder.append(this.pageSize, test.pageSize);
                builder.append(this.requestNum, test.requestNum);
                builder.append(this.queryStr, test.queryStr);
                builder.append(this.actionFlag, test.actionFlag);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetBpsOperatorHasDoneTaskInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private List<InnerBpsService.OperatorHasDoneTaskDTO> rows;
        private Integer total = 0;

        public GetBpsOperatorHasDoneTaskInnerOutput() {
        }

        public List<InnerBpsService.OperatorHasDoneTaskDTO> getRows() {
            return this.rows;
        }

        public Integer getTotal() {
            return this.total != null ? this.total : 0;
        }

        public void setRows(List<InnerBpsService.OperatorHasDoneTaskDTO> rows) {
            this.rows = rows;
        }

        public void setTotal(Integer total) {
            this.total = total;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetBpsOperatorHasDoneTaskInnerOutput:(");
            buffer.append("rows:" + this.rows);
            buffer.append(",total:" + this.total);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.rows);
            builder.append(this.total);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.GetBpsOperatorHasDoneTaskInnerOutput) {
                InnerBpsService.GetBpsOperatorHasDoneTaskInnerOutput test = (InnerBpsService.GetBpsOperatorHasDoneTaskInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.rows, test.rows);
                builder.append(this.total, test.total);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetBpsOperatorHasDoneTaskInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 60,
                charset = "utf-8"
        )
        private String operatorName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character useType = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String menuCode = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String functionStr = " ";
        private Integer branchNo = 0;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String acptBusinKind = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String acptId = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String clientId = " ";
        @SinogramLength(
                min = 0,
                max = 180,
                charset = "utf-8"
        )
        private String fullName = " ";
        @SinogramLength(
                min = 0,
                max = 10,
                charset = "utf-8"
        )
        private String acptBusinId = " ";
        private Integer beginDate = 0;
        private Integer endDate = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character acptType = ' ';
        private Integer pageNo = 0;
        private Integer pageSize = 0;
        private Integer requestNum = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character organFlag = ' ';
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String enFormStatus = " ";
        @SinogramLength(
                min = 0,
                max = 20,
                charset = "utf-8"
        )
        private String enDealStatus = " ";

        public GetBpsOperatorHasDoneTaskInnerInput() {
        }

        public String getOperatorName() {
            if (this.operatorName == null) {
                return " ";
            } else {
                return this.operatorName.isEmpty() ? " " : this.operatorName;
            }
        }

        public Character getUseType() {
            return this.useType != null ? this.useType : ' ';
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getMenuCode() {
            if (this.menuCode == null) {
                return " ";
            } else {
                return this.menuCode.isEmpty() ? " " : this.menuCode;
            }
        }

        public String getFunctionStr() {
            if (this.functionStr == null) {
                return " ";
            } else {
                return this.functionStr.isEmpty() ? " " : this.functionStr;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getAcptBusinKind() {
            if (this.acptBusinKind == null) {
                return " ";
            } else {
                return this.acptBusinKind.isEmpty() ? " " : this.acptBusinKind;
            }
        }

        public String getAcptId() {
            if (this.acptId == null) {
                return " ";
            } else {
                return this.acptId.isEmpty() ? " " : this.acptId;
            }
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getFullName() {
            if (this.fullName == null) {
                return " ";
            } else {
                return this.fullName.isEmpty() ? " " : this.fullName;
            }
        }

        public String getAcptBusinId() {
            if (this.acptBusinId == null) {
                return " ";
            } else {
                return this.acptBusinId.isEmpty() ? " " : this.acptBusinId;
            }
        }

        public Integer getBeginDate() {
            return this.beginDate != null ? this.beginDate : 0;
        }

        public Integer getEndDate() {
            return this.endDate != null ? this.endDate : 0;
        }

        public Character getAcptType() {
            return this.acptType != null ? this.acptType : ' ';
        }

        public Integer getPageNo() {
            return this.pageNo != null ? this.pageNo : 0;
        }

        public Integer getPageSize() {
            return this.pageSize != null ? this.pageSize : 0;
        }

        public Integer getRequestNum() {
            return this.requestNum != null ? this.requestNum : 0;
        }

        public Character getOrganFlag() {
            return this.organFlag != null ? this.organFlag : ' ';
        }

        public String getEnFormStatus() {
            if (this.enFormStatus == null) {
                return " ";
            } else {
                return this.enFormStatus.isEmpty() ? " " : this.enFormStatus;
            }
        }

        public String getEnDealStatus() {
            if (this.enDealStatus == null) {
                return " ";
            } else {
                return this.enDealStatus.isEmpty() ? " " : this.enDealStatus;
            }
        }

        public void setOperatorName(String operatorName) {
            this.operatorName = operatorName;
        }

        public void setUseType(Character useType) {
            this.useType = useType;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setMenuCode(String menuCode) {
            this.menuCode = menuCode;
        }

        public void setFunctionStr(String functionStr) {
            this.functionStr = functionStr;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setAcptBusinKind(String acptBusinKind) {
            this.acptBusinKind = acptBusinKind;
        }

        public void setAcptId(String acptId) {
            this.acptId = acptId;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setFullName(String fullName) {
            this.fullName = fullName;
        }

        public void setAcptBusinId(String acptBusinId) {
            this.acptBusinId = acptBusinId;
        }

        public void setBeginDate(Integer beginDate) {
            this.beginDate = beginDate;
        }

        public void setEndDate(Integer endDate) {
            this.endDate = endDate;
        }

        public void setAcptType(Character acptType) {
            this.acptType = acptType;
        }

        public void setPageNo(Integer pageNo) {
            this.pageNo = pageNo;
        }

        public void setPageSize(Integer pageSize) {
            this.pageSize = pageSize;
        }

        public void setRequestNum(Integer requestNum) {
            this.requestNum = requestNum;
        }

        public void setOrganFlag(Character organFlag) {
            this.organFlag = organFlag;
        }

        public void setEnFormStatus(String enFormStatus) {
            this.enFormStatus = enFormStatus;
        }

        public void setEnDealStatus(String enDealStatus) {
            this.enDealStatus = enDealStatus;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetBpsOperatorHasDoneTaskInnerInput:(");
            buffer.append("operatorName:" + this.operatorName);
            buffer.append(",useType:" + this.useType);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",menuCode:" + this.menuCode);
            buffer.append(",functionStr:" + this.functionStr);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",acptBusinKind:" + this.acptBusinKind);
            buffer.append(",acptId:" + this.acptId);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",fullName:" + this.fullName);
            buffer.append(",acptBusinId:" + this.acptBusinId);
            buffer.append(",beginDate:" + this.beginDate);
            buffer.append(",endDate:" + this.endDate);
            buffer.append(",acptType:" + this.acptType);
            buffer.append(",pageNo:" + this.pageNo);
            buffer.append(",pageSize:" + this.pageSize);
            buffer.append(",requestNum:" + this.requestNum);
            buffer.append(",organFlag:" + this.organFlag);
            buffer.append(",enFormStatus:" + this.enFormStatus);
            buffer.append(",enDealStatus:" + this.enDealStatus);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.operatorName);
            builder.append(this.useType);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.menuCode);
            builder.append(this.functionStr);
            builder.append(this.branchNo);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.acptBusinKind);
            builder.append(this.acptId);
            builder.append(this.clientId);
            builder.append(this.fullName);
            builder.append(this.acptBusinId);
            builder.append(this.beginDate);
            builder.append(this.endDate);
            builder.append(this.acptType);
            builder.append(this.pageNo);
            builder.append(this.pageSize);
            builder.append(this.requestNum);
            builder.append(this.organFlag);
            builder.append(this.enFormStatus);
            builder.append(this.enDealStatus);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.GetBpsOperatorHasDoneTaskInnerInput) {
                InnerBpsService.GetBpsOperatorHasDoneTaskInnerInput test = (InnerBpsService.GetBpsOperatorHasDoneTaskInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.operatorName, test.operatorName);
                builder.append(this.useType, test.useType);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.menuCode, test.menuCode);
                builder.append(this.functionStr, test.functionStr);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.acptBusinKind, test.acptBusinKind);
                builder.append(this.acptId, test.acptId);
                builder.append(this.clientId, test.clientId);
                builder.append(this.fullName, test.fullName);
                builder.append(this.acptBusinId, test.acptBusinId);
                builder.append(this.beginDate, test.beginDate);
                builder.append(this.endDate, test.endDate);
                builder.append(this.acptType, test.acptType);
                builder.append(this.pageNo, test.pageNo);
                builder.append(this.pageSize, test.pageSize);
                builder.append(this.requestNum, test.requestNum);
                builder.append(this.organFlag, test.organFlag);
                builder.append(this.enFormStatus, test.enFormStatus);
                builder.append(this.enDealStatus, test.enDealStatus);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetBpsClientPreOpenInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer branchNo = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character idKind = ' ';
        private String idNo = " ";
        private String fullName = " ";
        private String acptId = " ";
        private String paramData = " ";

        public GetBpsClientPreOpenInnerOutput() {
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Character getIdKind() {
            return this.idKind != null ? this.idKind : ' ';
        }

        public String getIdNo() {
            if (this.idNo == null) {
                return " ";
            } else {
                return this.idNo.isEmpty() ? " " : this.idNo;
            }
        }

        public String getFullName() {
            if (this.fullName == null) {
                return " ";
            } else {
                return this.fullName.isEmpty() ? " " : this.fullName;
            }
        }

        public String getAcptId() {
            if (this.acptId == null) {
                return " ";
            } else {
                return this.acptId.isEmpty() ? " " : this.acptId;
            }
        }

        public String getParamData() {
            if (this.paramData == null) {
                return " ";
            } else {
                return this.paramData.isEmpty() ? " " : this.paramData;
            }
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setIdKind(Character idKind) {
            this.idKind = idKind;
        }

        public void setIdNo(String idNo) {
            this.idNo = idNo;
        }

        public void setFullName(String fullName) {
            this.fullName = fullName;
        }

        public void setAcptId(String acptId) {
            this.acptId = acptId;
        }

        public void setParamData(String paramData) {
            this.paramData = paramData;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetBpsClientPreOpenInnerOutput:(");
            buffer.append("branchNo:" + this.branchNo);
            buffer.append(",idKind:" + this.idKind);
            buffer.append(",idNo:" + this.idNo);
            buffer.append(",fullName:" + this.fullName);
            buffer.append(",acptId:" + this.acptId);
            buffer.append(",paramData:" + this.paramData);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.branchNo);
            builder.append(this.idKind);
            builder.append(this.idNo);
            builder.append(this.fullName);
            builder.append(this.acptId);
            builder.append(this.paramData);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.GetBpsClientPreOpenInnerOutput) {
                InnerBpsService.GetBpsClientPreOpenInnerOutput test = (InnerBpsService.GetBpsClientPreOpenInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.idKind, test.idKind);
                builder.append(this.idNo, test.idNo);
                builder.append(this.fullName, test.fullName);
                builder.append(this.acptId, test.acptId);
                builder.append(this.paramData, test.paramData);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetBpsClientPreOpenInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 60,
                charset = "utf-8"
        )
        private String operatorName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character useType = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String menuCode = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String functionStr = " ";
        private Integer branchNo = 0;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String clientId = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character idKind = ' ';
        @SinogramLength(
                min = 0,
                max = 40,
                charset = "utf-8"
        )
        private String idNo = " ";
        @SinogramLength(
                min = 0,
                max = 180,
                charset = "utf-8"
        )
        private String fullName = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String acptId = " ";

        public GetBpsClientPreOpenInnerInput() {
        }

        public String getOperatorName() {
            if (this.operatorName == null) {
                return " ";
            } else {
                return this.operatorName.isEmpty() ? " " : this.operatorName;
            }
        }

        public Character getUseType() {
            return this.useType != null ? this.useType : ' ';
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getMenuCode() {
            if (this.menuCode == null) {
                return " ";
            } else {
                return this.menuCode.isEmpty() ? " " : this.menuCode;
            }
        }

        public String getFunctionStr() {
            if (this.functionStr == null) {
                return " ";
            } else {
                return this.functionStr.isEmpty() ? " " : this.functionStr;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public Character getIdKind() {
            return this.idKind != null ? this.idKind : ' ';
        }

        public String getIdNo() {
            if (this.idNo == null) {
                return " ";
            } else {
                return this.idNo.isEmpty() ? " " : this.idNo;
            }
        }

        public String getFullName() {
            if (this.fullName == null) {
                return " ";
            } else {
                return this.fullName.isEmpty() ? " " : this.fullName;
            }
        }

        public String getAcptId() {
            if (this.acptId == null) {
                return " ";
            } else {
                return this.acptId.isEmpty() ? " " : this.acptId;
            }
        }

        public void setOperatorName(String operatorName) {
            this.operatorName = operatorName;
        }

        public void setUseType(Character useType) {
            this.useType = useType;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setMenuCode(String menuCode) {
            this.menuCode = menuCode;
        }

        public void setFunctionStr(String functionStr) {
            this.functionStr = functionStr;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setIdKind(Character idKind) {
            this.idKind = idKind;
        }

        public void setIdNo(String idNo) {
            this.idNo = idNo;
        }

        public void setFullName(String fullName) {
            this.fullName = fullName;
        }

        public void setAcptId(String acptId) {
            this.acptId = acptId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetBpsClientPreOpenInnerInput:(");
            buffer.append("operatorName:" + this.operatorName);
            buffer.append(",useType:" + this.useType);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",menuCode:" + this.menuCode);
            buffer.append(",functionStr:" + this.functionStr);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",idKind:" + this.idKind);
            buffer.append(",idNo:" + this.idNo);
            buffer.append(",fullName:" + this.fullName);
            buffer.append(",acptId:" + this.acptId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.operatorName);
            builder.append(this.useType);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.menuCode);
            builder.append(this.functionStr);
            builder.append(this.branchNo);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.clientId);
            builder.append(this.idKind);
            builder.append(this.idNo);
            builder.append(this.fullName);
            builder.append(this.acptId);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.GetBpsClientPreOpenInnerInput) {
                InnerBpsService.GetBpsClientPreOpenInnerInput test = (InnerBpsService.GetBpsClientPreOpenInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.operatorName, test.operatorName);
                builder.append(this.useType, test.useType);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.menuCode, test.menuCode);
                builder.append(this.functionStr, test.functionStr);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.clientId, test.clientId);
                builder.append(this.idKind, test.idKind);
                builder.append(this.idNo, test.idNo);
                builder.append(this.fullName, test.fullName);
                builder.append(this.acptId, test.acptId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetBpsAcptformStatusNumInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer statusSuccessNum = 0;
        private Integer statusStopedNum = 0;
        private Integer statusFailedNum = 0;

        public GetBpsAcptformStatusNumInnerOutput() {
        }

        public Integer getStatusSuccessNum() {
            return this.statusSuccessNum != null ? this.statusSuccessNum : 0;
        }

        public Integer getStatusStopedNum() {
            return this.statusStopedNum != null ? this.statusStopedNum : 0;
        }

        public Integer getStatusFailedNum() {
            return this.statusFailedNum != null ? this.statusFailedNum : 0;
        }

        public void setStatusSuccessNum(Integer statusSuccessNum) {
            this.statusSuccessNum = statusSuccessNum;
        }

        public void setStatusStopedNum(Integer statusStopedNum) {
            this.statusStopedNum = statusStopedNum;
        }

        public void setStatusFailedNum(Integer statusFailedNum) {
            this.statusFailedNum = statusFailedNum;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetBpsAcptformStatusNumInnerOutput:(");
            buffer.append("statusSuccessNum:" + this.statusSuccessNum);
            buffer.append(",statusStopedNum:" + this.statusStopedNum);
            buffer.append(",statusFailedNum:" + this.statusFailedNum);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.statusSuccessNum);
            builder.append(this.statusStopedNum);
            builder.append(this.statusFailedNum);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.GetBpsAcptformStatusNumInnerOutput) {
                InnerBpsService.GetBpsAcptformStatusNumInnerOutput test = (InnerBpsService.GetBpsAcptformStatusNumInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.statusSuccessNum, test.statusSuccessNum);
                builder.append(this.statusStopedNum, test.statusStopedNum);
                builder.append(this.statusFailedNum, test.statusFailedNum);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetBpsAcptformStatusNumInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 60,
                charset = "utf-8"
        )
        private String operatorName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character useType = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String menuCode = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String functionStr = " ";
        private Integer branchNo = 0;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String clientId = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNoQ = " ";
        private Integer beginDate = 0;
        private Integer endDate = 0;

        public GetBpsAcptformStatusNumInnerInput() {
        }

        public String getOperatorName() {
            if (this.operatorName == null) {
                return " ";
            } else {
                return this.operatorName.isEmpty() ? " " : this.operatorName;
            }
        }

        public Character getUseType() {
            return this.useType != null ? this.useType : ' ';
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getMenuCode() {
            if (this.menuCode == null) {
                return " ";
            } else {
                return this.menuCode.isEmpty() ? " " : this.menuCode;
            }
        }

        public String getFunctionStr() {
            if (this.functionStr == null) {
                return " ";
            } else {
                return this.functionStr.isEmpty() ? " " : this.functionStr;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getOperatorNoQ() {
            if (this.operatorNoQ == null) {
                return " ";
            } else {
                return this.operatorNoQ.isEmpty() ? " " : this.operatorNoQ;
            }
        }

        public Integer getBeginDate() {
            return this.beginDate != null ? this.beginDate : 0;
        }

        public Integer getEndDate() {
            return this.endDate != null ? this.endDate : 0;
        }

        public void setOperatorName(String operatorName) {
            this.operatorName = operatorName;
        }

        public void setUseType(Character useType) {
            this.useType = useType;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setMenuCode(String menuCode) {
            this.menuCode = menuCode;
        }

        public void setFunctionStr(String functionStr) {
            this.functionStr = functionStr;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setOperatorNoQ(String operatorNoQ) {
            this.operatorNoQ = operatorNoQ;
        }

        public void setBeginDate(Integer beginDate) {
            this.beginDate = beginDate;
        }

        public void setEndDate(Integer endDate) {
            this.endDate = endDate;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetBpsAcptformStatusNumInnerInput:(");
            buffer.append("operatorName:" + this.operatorName);
            buffer.append(",useType:" + this.useType);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",menuCode:" + this.menuCode);
            buffer.append(",functionStr:" + this.functionStr);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",operatorNoQ:" + this.operatorNoQ);
            buffer.append(",beginDate:" + this.beginDate);
            buffer.append(",endDate:" + this.endDate);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.operatorName);
            builder.append(this.useType);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.menuCode);
            builder.append(this.functionStr);
            builder.append(this.branchNo);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.clientId);
            builder.append(this.operatorNoQ);
            builder.append(this.beginDate);
            builder.append(this.endDate);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.GetBpsAcptformStatusNumInnerInput) {
                InnerBpsService.GetBpsAcptformStatusNumInnerInput test = (InnerBpsService.GetBpsAcptformStatusNumInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.operatorName, test.operatorName);
                builder.append(this.useType, test.useType);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.menuCode, test.menuCode);
                builder.append(this.functionStr, test.functionStr);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.clientId, test.clientId);
                builder.append(this.operatorNoQ, test.operatorNoQ);
                builder.append(this.beginDate, test.beginDate);
                builder.append(this.endDate, test.endDate);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetBpsAcptformListInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String acptId = " ";
        private String acptBusinId = " ";
        private String acptBusinKind = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character acptFormStatus = ' ';
        private String workflowOrderId = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private String fundAccount = " ";
        private Integer branchNo = 0;
        private String clientId = " ";
        private String operatorNo = " ";
        private Integer opBranchNo = 0;
        private Integer acceptDate = 0;
        private Integer acceptTime = 0;
        private Integer dealDate = 0;
        private Integer dealTime = 0;
        private Integer dateClear = 0;
        private String positionStr = " ";
        private String remark = " ";
        private Integer errorNoInner = 0;
        private String errorInfoInner = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character resend = ' ';
        private Integer initDate = 0;
        private String columnStr = " ";
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character idKind = ' ';
        private String idNo = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character organFlag = ' ';
        private String acptEnrouteField = " ";
        private String rejectFlagStr = " ";
        private String rejectReason = " ";
        private Integer acptChannel = 0;
        private String operatorName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character acptType = ' ';
        private String custId = " ";
        private Integer count = 0;
        private String acptBusinProve = " ";
        private String fullName = " ";
        private String functionData = " ";
        private String paramData = " ";

        public GetBpsAcptformListInnerOutput() {
        }

        public String getAcptId() {
            if (this.acptId == null) {
                return " ";
            } else {
                return this.acptId.isEmpty() ? " " : this.acptId;
            }
        }

        public String getAcptBusinId() {
            if (this.acptBusinId == null) {
                return " ";
            } else {
                return this.acptBusinId.isEmpty() ? " " : this.acptBusinId;
            }
        }

        public String getAcptBusinKind() {
            if (this.acptBusinKind == null) {
                return " ";
            } else {
                return this.acptBusinKind.isEmpty() ? " " : this.acptBusinKind;
            }
        }

        public Character getAcptFormStatus() {
            return this.acptFormStatus != null ? this.acptFormStatus : ' ';
        }

        public String getWorkflowOrderId() {
            if (this.workflowOrderId == null) {
                return " ";
            } else {
                return this.workflowOrderId.isEmpty() ? " " : this.workflowOrderId;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public Integer getAcceptDate() {
            return this.acceptDate != null ? this.acceptDate : 0;
        }

        public Integer getAcceptTime() {
            return this.acceptTime != null ? this.acceptTime : 0;
        }

        public Integer getDealDate() {
            return this.dealDate != null ? this.dealDate : 0;
        }

        public Integer getDealTime() {
            return this.dealTime != null ? this.dealTime : 0;
        }

        public Integer getDateClear() {
            return this.dateClear != null ? this.dateClear : 0;
        }

        public String getPositionStr() {
            if (this.positionStr == null) {
                return " ";
            } else {
                return this.positionStr.isEmpty() ? " " : this.positionStr;
            }
        }

        public String getRemark() {
            if (this.remark == null) {
                return " ";
            } else {
                return this.remark.isEmpty() ? " " : this.remark;
            }
        }

        public Integer getErrorNoInner() {
            return this.errorNoInner != null ? this.errorNoInner : 0;
        }

        public String getErrorInfoInner() {
            if (this.errorInfoInner == null) {
                return " ";
            } else {
                return this.errorInfoInner.isEmpty() ? " " : this.errorInfoInner;
            }
        }

        public Character getResend() {
            return this.resend != null ? this.resend : ' ';
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public String getColumnStr() {
            if (this.columnStr == null) {
                return " ";
            } else {
                return this.columnStr.isEmpty() ? " " : this.columnStr;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getIdKind() {
            return this.idKind != null ? this.idKind : ' ';
        }

        public String getIdNo() {
            if (this.idNo == null) {
                return " ";
            } else {
                return this.idNo.isEmpty() ? " " : this.idNo;
            }
        }

        public Character getOrganFlag() {
            return this.organFlag != null ? this.organFlag : ' ';
        }

        public String getAcptEnrouteField() {
            if (this.acptEnrouteField == null) {
                return " ";
            } else {
                return this.acptEnrouteField.isEmpty() ? " " : this.acptEnrouteField;
            }
        }

        public String getRejectFlagStr() {
            if (this.rejectFlagStr == null) {
                return " ";
            } else {
                return this.rejectFlagStr.isEmpty() ? " " : this.rejectFlagStr;
            }
        }

        public String getRejectReason() {
            if (this.rejectReason == null) {
                return " ";
            } else {
                return this.rejectReason.isEmpty() ? " " : this.rejectReason;
            }
        }

        public Integer getAcptChannel() {
            return this.acptChannel != null ? this.acptChannel : 0;
        }

        public String getOperatorName() {
            if (this.operatorName == null) {
                return " ";
            } else {
                return this.operatorName.isEmpty() ? " " : this.operatorName;
            }
        }

        public Character getAcptType() {
            return this.acptType != null ? this.acptType : ' ';
        }

        public String getCustId() {
            if (this.custId == null) {
                return " ";
            } else {
                return this.custId.isEmpty() ? " " : this.custId;
            }
        }

        public Integer getCount() {
            return this.count != null ? this.count : 0;
        }

        public String getAcptBusinProve() {
            if (this.acptBusinProve == null) {
                return " ";
            } else {
                return this.acptBusinProve.isEmpty() ? " " : this.acptBusinProve;
            }
        }

        public String getFullName() {
            if (this.fullName == null) {
                return " ";
            } else {
                return this.fullName.isEmpty() ? " " : this.fullName;
            }
        }

        public String getFunctionData() {
            if (this.functionData == null) {
                return " ";
            } else {
                return this.functionData.isEmpty() ? " " : this.functionData;
            }
        }

        public String getParamData() {
            if (this.paramData == null) {
                return " ";
            } else {
                return this.paramData.isEmpty() ? " " : this.paramData;
            }
        }

        public void setAcptId(String acptId) {
            this.acptId = acptId;
        }

        public void setAcptBusinId(String acptBusinId) {
            this.acptBusinId = acptBusinId;
        }

        public void setAcptBusinKind(String acptBusinKind) {
            this.acptBusinKind = acptBusinKind;
        }

        public void setAcptFormStatus(Character acptFormStatus) {
            this.acptFormStatus = acptFormStatus;
        }

        public void setWorkflowOrderId(String workflowOrderId) {
            this.workflowOrderId = workflowOrderId;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setAcceptDate(Integer acceptDate) {
            this.acceptDate = acceptDate;
        }

        public void setAcceptTime(Integer acceptTime) {
            this.acceptTime = acceptTime;
        }

        public void setDealDate(Integer dealDate) {
            this.dealDate = dealDate;
        }

        public void setDealTime(Integer dealTime) {
            this.dealTime = dealTime;
        }

        public void setDateClear(Integer dateClear) {
            this.dateClear = dateClear;
        }

        public void setPositionStr(String positionStr) {
            this.positionStr = positionStr;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public void setErrorNoInner(Integer errorNoInner) {
            this.errorNoInner = errorNoInner;
        }

        public void setErrorInfoInner(String errorInfoInner) {
            this.errorInfoInner = errorInfoInner;
        }

        public void setResend(Character resend) {
            this.resend = resend;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public void setColumnStr(String columnStr) {
            this.columnStr = columnStr;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setIdKind(Character idKind) {
            this.idKind = idKind;
        }

        public void setIdNo(String idNo) {
            this.idNo = idNo;
        }

        public void setOrganFlag(Character organFlag) {
            this.organFlag = organFlag;
        }

        public void setAcptEnrouteField(String acptEnrouteField) {
            this.acptEnrouteField = acptEnrouteField;
        }

        public void setRejectFlagStr(String rejectFlagStr) {
            this.rejectFlagStr = rejectFlagStr;
        }

        public void setRejectReason(String rejectReason) {
            this.rejectReason = rejectReason;
        }

        public void setAcptChannel(Integer acptChannel) {
            this.acptChannel = acptChannel;
        }

        public void setOperatorName(String operatorName) {
            this.operatorName = operatorName;
        }

        public void setAcptType(Character acptType) {
            this.acptType = acptType;
        }

        public void setCustId(String custId) {
            this.custId = custId;
        }

        public void setCount(Integer count) {
            this.count = count;
        }

        public void setAcptBusinProve(String acptBusinProve) {
            this.acptBusinProve = acptBusinProve;
        }

        public void setFullName(String fullName) {
            this.fullName = fullName;
        }

        public void setFunctionData(String functionData) {
            this.functionData = functionData;
        }

        public void setParamData(String paramData) {
            this.paramData = paramData;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetBpsAcptformListInnerOutput:(");
            buffer.append("acptId:" + this.acptId);
            buffer.append(",acptBusinId:" + this.acptBusinId);
            buffer.append(",acptBusinKind:" + this.acptBusinKind);
            buffer.append(",acptFormStatus:" + this.acptFormStatus);
            buffer.append(",workflowOrderId:" + this.workflowOrderId);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",acceptDate:" + this.acceptDate);
            buffer.append(",acceptTime:" + this.acceptTime);
            buffer.append(",dealDate:" + this.dealDate);
            buffer.append(",dealTime:" + this.dealTime);
            buffer.append(",dateClear:" + this.dateClear);
            buffer.append(",positionStr:" + this.positionStr);
            buffer.append(",remark:" + this.remark);
            buffer.append(",errorNoInner:" + this.errorNoInner);
            buffer.append(",errorInfoInner:" + this.errorInfoInner);
            buffer.append(",resend:" + this.resend);
            buffer.append(",initDate:" + this.initDate);
            buffer.append(",columnStr:" + this.columnStr);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",idKind:" + this.idKind);
            buffer.append(",idNo:" + this.idNo);
            buffer.append(",organFlag:" + this.organFlag);
            buffer.append(",acptEnrouteField:" + this.acptEnrouteField);
            buffer.append(",rejectFlagStr:" + this.rejectFlagStr);
            buffer.append(",rejectReason:" + this.rejectReason);
            buffer.append(",acptChannel:" + this.acptChannel);
            buffer.append(",operatorName:" + this.operatorName);
            buffer.append(",acptType:" + this.acptType);
            buffer.append(",custId:" + this.custId);
            buffer.append(",count:" + this.count);
            buffer.append(",acptBusinProve:" + this.acptBusinProve);
            buffer.append(",fullName:" + this.fullName);
            buffer.append(",functionData:" + this.functionData);
            buffer.append(",paramData:" + this.paramData);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.acptId);
            builder.append(this.acptBusinId);
            builder.append(this.acptBusinKind);
            builder.append(this.acptFormStatus);
            builder.append(this.workflowOrderId);
            builder.append(this.opEntrustWay);
            builder.append(this.fundAccount);
            builder.append(this.branchNo);
            builder.append(this.clientId);
            builder.append(this.operatorNo);
            builder.append(this.opBranchNo);
            builder.append(this.acceptDate);
            builder.append(this.acceptTime);
            builder.append(this.dealDate);
            builder.append(this.dealTime);
            builder.append(this.dateClear);
            builder.append(this.positionStr);
            builder.append(this.remark);
            builder.append(this.errorNoInner);
            builder.append(this.errorInfoInner);
            builder.append(this.resend);
            builder.append(this.initDate);
            builder.append(this.columnStr);
            builder.append(this.opStation);
            builder.append(this.idKind);
            builder.append(this.idNo);
            builder.append(this.organFlag);
            builder.append(this.acptEnrouteField);
            builder.append(this.rejectFlagStr);
            builder.append(this.rejectReason);
            builder.append(this.acptChannel);
            builder.append(this.operatorName);
            builder.append(this.acptType);
            builder.append(this.custId);
            builder.append(this.count);
            builder.append(this.acptBusinProve);
            builder.append(this.fullName);
            builder.append(this.functionData);
            builder.append(this.paramData);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.GetBpsAcptformListInnerOutput) {
                InnerBpsService.GetBpsAcptformListInnerOutput test = (InnerBpsService.GetBpsAcptformListInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.acptId, test.acptId);
                builder.append(this.acptBusinId, test.acptBusinId);
                builder.append(this.acptBusinKind, test.acptBusinKind);
                builder.append(this.acptFormStatus, test.acptFormStatus);
                builder.append(this.workflowOrderId, test.workflowOrderId);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.clientId, test.clientId);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.acceptDate, test.acceptDate);
                builder.append(this.acceptTime, test.acceptTime);
                builder.append(this.dealDate, test.dealDate);
                builder.append(this.dealTime, test.dealTime);
                builder.append(this.dateClear, test.dateClear);
                builder.append(this.positionStr, test.positionStr);
                builder.append(this.remark, test.remark);
                builder.append(this.errorNoInner, test.errorNoInner);
                builder.append(this.errorInfoInner, test.errorInfoInner);
                builder.append(this.resend, test.resend);
                builder.append(this.initDate, test.initDate);
                builder.append(this.columnStr, test.columnStr);
                builder.append(this.opStation, test.opStation);
                builder.append(this.idKind, test.idKind);
                builder.append(this.idNo, test.idNo);
                builder.append(this.organFlag, test.organFlag);
                builder.append(this.acptEnrouteField, test.acptEnrouteField);
                builder.append(this.rejectFlagStr, test.rejectFlagStr);
                builder.append(this.rejectReason, test.rejectReason);
                builder.append(this.acptChannel, test.acptChannel);
                builder.append(this.operatorName, test.operatorName);
                builder.append(this.acptType, test.acptType);
                builder.append(this.custId, test.custId);
                builder.append(this.count, test.count);
                builder.append(this.acptBusinProve, test.acptBusinProve);
                builder.append(this.fullName, test.fullName);
                builder.append(this.functionData, test.functionData);
                builder.append(this.paramData, test.paramData);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetBpsAcptformListInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 60,
                charset = "utf-8"
        )
        private String operatorName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character useType = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String menuCode = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String functionStr = " ";
        private Integer branchNo = 0;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String clientId = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String acptId = " ";
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String acptBusinKind = " ";
        @SinogramLength(
                min = 0,
                max = 10,
                charset = "utf-8"
        )
        private String acptBusinId = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String enAcptStatus = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character acptType = ' ';
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fundAccount = " ";
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String acptEnrouteField = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNoQ = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character idKind = ' ';
        @SinogramLength(
                min = 0,
                max = 40,
                charset = "utf-8"
        )
        private String idNo = " ";
        private Integer beginDate = 0;
        private Integer endDate = 0;

        public GetBpsAcptformListInnerInput() {
        }

        public String getOperatorName() {
            if (this.operatorName == null) {
                return " ";
            } else {
                return this.operatorName.isEmpty() ? " " : this.operatorName;
            }
        }

        public Character getUseType() {
            return this.useType != null ? this.useType : ' ';
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getMenuCode() {
            if (this.menuCode == null) {
                return " ";
            } else {
                return this.menuCode.isEmpty() ? " " : this.menuCode;
            }
        }

        public String getFunctionStr() {
            if (this.functionStr == null) {
                return " ";
            } else {
                return this.functionStr.isEmpty() ? " " : this.functionStr;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getAcptId() {
            if (this.acptId == null) {
                return " ";
            } else {
                return this.acptId.isEmpty() ? " " : this.acptId;
            }
        }

        public String getAcptBusinKind() {
            if (this.acptBusinKind == null) {
                return " ";
            } else {
                return this.acptBusinKind.isEmpty() ? " " : this.acptBusinKind;
            }
        }

        public String getAcptBusinId() {
            if (this.acptBusinId == null) {
                return " ";
            } else {
                return this.acptBusinId.isEmpty() ? " " : this.acptBusinId;
            }
        }

        public String getEnAcptStatus() {
            if (this.enAcptStatus == null) {
                return " ";
            } else {
                return this.enAcptStatus.isEmpty() ? " " : this.enAcptStatus;
            }
        }

        public Character getAcptType() {
            return this.acptType != null ? this.acptType : ' ';
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getAcptEnrouteField() {
            if (this.acptEnrouteField == null) {
                return " ";
            } else {
                return this.acptEnrouteField.isEmpty() ? " " : this.acptEnrouteField;
            }
        }

        public String getOperatorNoQ() {
            if (this.operatorNoQ == null) {
                return " ";
            } else {
                return this.operatorNoQ.isEmpty() ? " " : this.operatorNoQ;
            }
        }

        public Character getIdKind() {
            return this.idKind != null ? this.idKind : ' ';
        }

        public String getIdNo() {
            if (this.idNo == null) {
                return " ";
            } else {
                return this.idNo.isEmpty() ? " " : this.idNo;
            }
        }

        public Integer getBeginDate() {
            return this.beginDate != null ? this.beginDate : 0;
        }

        public Integer getEndDate() {
            return this.endDate != null ? this.endDate : 0;
        }

        public void setOperatorName(String operatorName) {
            this.operatorName = operatorName;
        }

        public void setUseType(Character useType) {
            this.useType = useType;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setMenuCode(String menuCode) {
            this.menuCode = menuCode;
        }

        public void setFunctionStr(String functionStr) {
            this.functionStr = functionStr;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setAcptId(String acptId) {
            this.acptId = acptId;
        }

        public void setAcptBusinKind(String acptBusinKind) {
            this.acptBusinKind = acptBusinKind;
        }

        public void setAcptBusinId(String acptBusinId) {
            this.acptBusinId = acptBusinId;
        }

        public void setEnAcptStatus(String enAcptStatus) {
            this.enAcptStatus = enAcptStatus;
        }

        public void setAcptType(Character acptType) {
            this.acptType = acptType;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setAcptEnrouteField(String acptEnrouteField) {
            this.acptEnrouteField = acptEnrouteField;
        }

        public void setOperatorNoQ(String operatorNoQ) {
            this.operatorNoQ = operatorNoQ;
        }

        public void setIdKind(Character idKind) {
            this.idKind = idKind;
        }

        public void setIdNo(String idNo) {
            this.idNo = idNo;
        }

        public void setBeginDate(Integer beginDate) {
            this.beginDate = beginDate;
        }

        public void setEndDate(Integer endDate) {
            this.endDate = endDate;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetBpsAcptformListInnerInput:(");
            buffer.append("operatorName:" + this.operatorName);
            buffer.append(",useType:" + this.useType);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",menuCode:" + this.menuCode);
            buffer.append(",functionStr:" + this.functionStr);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",acptId:" + this.acptId);
            buffer.append(",acptBusinKind:" + this.acptBusinKind);
            buffer.append(",acptBusinId:" + this.acptBusinId);
            buffer.append(",enAcptStatus:" + this.enAcptStatus);
            buffer.append(",acptType:" + this.acptType);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",acptEnrouteField:" + this.acptEnrouteField);
            buffer.append(",operatorNoQ:" + this.operatorNoQ);
            buffer.append(",idKind:" + this.idKind);
            buffer.append(",idNo:" + this.idNo);
            buffer.append(",beginDate:" + this.beginDate);
            buffer.append(",endDate:" + this.endDate);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.operatorName);
            builder.append(this.useType);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.menuCode);
            builder.append(this.functionStr);
            builder.append(this.branchNo);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.clientId);
            builder.append(this.acptId);
            builder.append(this.acptBusinKind);
            builder.append(this.acptBusinId);
            builder.append(this.enAcptStatus);
            builder.append(this.acptType);
            builder.append(this.fundAccount);
            builder.append(this.acptEnrouteField);
            builder.append(this.operatorNoQ);
            builder.append(this.idKind);
            builder.append(this.idNo);
            builder.append(this.beginDate);
            builder.append(this.endDate);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.GetBpsAcptformListInnerInput) {
                InnerBpsService.GetBpsAcptformListInnerInput test = (InnerBpsService.GetBpsAcptformListInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.operatorName, test.operatorName);
                builder.append(this.useType, test.useType);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.menuCode, test.menuCode);
                builder.append(this.functionStr, test.functionStr);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.clientId, test.clientId);
                builder.append(this.acptId, test.acptId);
                builder.append(this.acptBusinKind, test.acptBusinKind);
                builder.append(this.acptBusinId, test.acptBusinId);
                builder.append(this.enAcptStatus, test.enAcptStatus);
                builder.append(this.acptType, test.acptType);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.acptEnrouteField, test.acptEnrouteField);
                builder.append(this.operatorNoQ, test.operatorNoQ);
                builder.append(this.idKind, test.idKind);
                builder.append(this.idNo, test.idNo);
                builder.append(this.beginDate, test.beginDate);
                builder.append(this.endDate, test.endDate);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetBpsAcptformInfoInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer total = 0;
        private List<InnerBpsService.AcptformDTO> rows;

        public GetBpsAcptformInfoInnerOutput() {
        }

        public Integer getTotal() {
            return this.total != null ? this.total : 0;
        }

        public List<InnerBpsService.AcptformDTO> getRows() {
            return this.rows;
        }

        public void setTotal(Integer total) {
            this.total = total;
        }

        public void setRows(List<InnerBpsService.AcptformDTO> rows) {
            this.rows = rows;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetBpsAcptformInfoInnerOutput:(");
            buffer.append("total:" + this.total);
            buffer.append(",rows:" + this.rows);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.total);
            builder.append(this.rows);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.GetBpsAcptformInfoInnerOutput) {
                InnerBpsService.GetBpsAcptformInfoInnerOutput test = (InnerBpsService.GetBpsAcptformInfoInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.total, test.total);
                builder.append(this.rows, test.rows);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetBpsAcptformInfoInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 60,
                charset = "utf-8"
        )
        private String operatorName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character useType = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String menuCode = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String functionStr = " ";
        private Integer branchNo = 0;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String acptId = " ";
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String acptBusinKind = " ";
        @SinogramLength(
                min = 0,
                max = 10,
                charset = "utf-8"
        )
        private String acptBusinId = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String enAcptStatus = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String clientId = " ";
        private Integer pageNo = 0;
        private Integer pageSize = 0;
        private Integer requestNum = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNoQ = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character acptType = ' ';
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fundAccount = " ";
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String acptEnrouteField = " ";
        @SinogramLength(
                min = 0,
                max = 180,
                charset = "utf-8"
        )
        private String fullName = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String enEntrustWay = " ";

        public GetBpsAcptformInfoInnerInput() {
        }

        public String getOperatorName() {
            if (this.operatorName == null) {
                return " ";
            } else {
                return this.operatorName.isEmpty() ? " " : this.operatorName;
            }
        }

        public Character getUseType() {
            return this.useType != null ? this.useType : ' ';
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getMenuCode() {
            if (this.menuCode == null) {
                return " ";
            } else {
                return this.menuCode.isEmpty() ? " " : this.menuCode;
            }
        }

        public String getFunctionStr() {
            if (this.functionStr == null) {
                return " ";
            } else {
                return this.functionStr.isEmpty() ? " " : this.functionStr;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getAcptId() {
            if (this.acptId == null) {
                return " ";
            } else {
                return this.acptId.isEmpty() ? " " : this.acptId;
            }
        }

        public String getAcptBusinKind() {
            if (this.acptBusinKind == null) {
                return " ";
            } else {
                return this.acptBusinKind.isEmpty() ? " " : this.acptBusinKind;
            }
        }

        public String getAcptBusinId() {
            if (this.acptBusinId == null) {
                return " ";
            } else {
                return this.acptBusinId.isEmpty() ? " " : this.acptBusinId;
            }
        }

        public String getEnAcptStatus() {
            if (this.enAcptStatus == null) {
                return " ";
            } else {
                return this.enAcptStatus.isEmpty() ? " " : this.enAcptStatus;
            }
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public Integer getPageNo() {
            return this.pageNo != null ? this.pageNo : 0;
        }

        public Integer getPageSize() {
            return this.pageSize != null ? this.pageSize : 0;
        }

        public Integer getRequestNum() {
            return this.requestNum != null ? this.requestNum : 0;
        }

        public String getOperatorNoQ() {
            if (this.operatorNoQ == null) {
                return " ";
            } else {
                return this.operatorNoQ.isEmpty() ? " " : this.operatorNoQ;
            }
        }

        public Character getAcptType() {
            return this.acptType != null ? this.acptType : ' ';
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getAcptEnrouteField() {
            if (this.acptEnrouteField == null) {
                return " ";
            } else {
                return this.acptEnrouteField.isEmpty() ? " " : this.acptEnrouteField;
            }
        }

        public String getFullName() {
            if (this.fullName == null) {
                return " ";
            } else {
                return this.fullName.isEmpty() ? " " : this.fullName;
            }
        }

        public String getEnEntrustWay() {
            if (this.enEntrustWay == null) {
                return " ";
            } else {
                return this.enEntrustWay.isEmpty() ? " " : this.enEntrustWay;
            }
        }

        public void setOperatorName(String operatorName) {
            this.operatorName = operatorName;
        }

        public void setUseType(Character useType) {
            this.useType = useType;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setMenuCode(String menuCode) {
            this.menuCode = menuCode;
        }

        public void setFunctionStr(String functionStr) {
            this.functionStr = functionStr;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setAcptId(String acptId) {
            this.acptId = acptId;
        }

        public void setAcptBusinKind(String acptBusinKind) {
            this.acptBusinKind = acptBusinKind;
        }

        public void setAcptBusinId(String acptBusinId) {
            this.acptBusinId = acptBusinId;
        }

        public void setEnAcptStatus(String enAcptStatus) {
            this.enAcptStatus = enAcptStatus;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setPageNo(Integer pageNo) {
            this.pageNo = pageNo;
        }

        public void setPageSize(Integer pageSize) {
            this.pageSize = pageSize;
        }

        public void setRequestNum(Integer requestNum) {
            this.requestNum = requestNum;
        }

        public void setOperatorNoQ(String operatorNoQ) {
            this.operatorNoQ = operatorNoQ;
        }

        public void setAcptType(Character acptType) {
            this.acptType = acptType;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setAcptEnrouteField(String acptEnrouteField) {
            this.acptEnrouteField = acptEnrouteField;
        }

        public void setFullName(String fullName) {
            this.fullName = fullName;
        }

        public void setEnEntrustWay(String enEntrustWay) {
            this.enEntrustWay = enEntrustWay;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetBpsAcptformInfoInnerInput:(");
            buffer.append("operatorName:" + this.operatorName);
            buffer.append(",useType:" + this.useType);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",menuCode:" + this.menuCode);
            buffer.append(",functionStr:" + this.functionStr);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",acptId:" + this.acptId);
            buffer.append(",acptBusinKind:" + this.acptBusinKind);
            buffer.append(",acptBusinId:" + this.acptBusinId);
            buffer.append(",enAcptStatus:" + this.enAcptStatus);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",pageNo:" + this.pageNo);
            buffer.append(",pageSize:" + this.pageSize);
            buffer.append(",requestNum:" + this.requestNum);
            buffer.append(",operatorNoQ:" + this.operatorNoQ);
            buffer.append(",acptType:" + this.acptType);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",acptEnrouteField:" + this.acptEnrouteField);
            buffer.append(",fullName:" + this.fullName);
            buffer.append(",enEntrustWay:" + this.enEntrustWay);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.operatorName);
            builder.append(this.useType);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.menuCode);
            builder.append(this.functionStr);
            builder.append(this.branchNo);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.acptId);
            builder.append(this.acptBusinKind);
            builder.append(this.acptBusinId);
            builder.append(this.enAcptStatus);
            builder.append(this.clientId);
            builder.append(this.pageNo);
            builder.append(this.pageSize);
            builder.append(this.requestNum);
            builder.append(this.operatorNoQ);
            builder.append(this.acptType);
            builder.append(this.fundAccount);
            builder.append(this.acptEnrouteField);
            builder.append(this.fullName);
            builder.append(this.enEntrustWay);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.GetBpsAcptformInfoInnerInput) {
                InnerBpsService.GetBpsAcptformInfoInnerInput test = (InnerBpsService.GetBpsAcptformInfoInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.operatorName, test.operatorName);
                builder.append(this.useType, test.useType);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.menuCode, test.menuCode);
                builder.append(this.functionStr, test.functionStr);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.acptId, test.acptId);
                builder.append(this.acptBusinKind, test.acptBusinKind);
                builder.append(this.acptBusinId, test.acptBusinId);
                builder.append(this.enAcptStatus, test.enAcptStatus);
                builder.append(this.clientId, test.clientId);
                builder.append(this.pageNo, test.pageNo);
                builder.append(this.pageSize, test.pageSize);
                builder.append(this.requestNum, test.requestNum);
                builder.append(this.operatorNoQ, test.operatorNoQ);
                builder.append(this.acptType, test.acptType);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.acptEnrouteField, test.acptEnrouteField);
                builder.append(this.fullName, test.fullName);
                builder.append(this.enEntrustWay, test.enEntrustWay);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetBpsAcptformCheckInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String acptId = " ";
        private String acptBusinId = " ";
        private String acptBusinKind = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character acptFormStatus = ' ';

        public GetBpsAcptformCheckInnerOutput() {
        }

        public String getAcptId() {
            if (this.acptId == null) {
                return " ";
            } else {
                return this.acptId.isEmpty() ? " " : this.acptId;
            }
        }

        public String getAcptBusinId() {
            if (this.acptBusinId == null) {
                return " ";
            } else {
                return this.acptBusinId.isEmpty() ? " " : this.acptBusinId;
            }
        }

        public String getAcptBusinKind() {
            if (this.acptBusinKind == null) {
                return " ";
            } else {
                return this.acptBusinKind.isEmpty() ? " " : this.acptBusinKind;
            }
        }

        public Character getAcptFormStatus() {
            return this.acptFormStatus != null ? this.acptFormStatus : ' ';
        }

        public void setAcptId(String acptId) {
            this.acptId = acptId;
        }

        public void setAcptBusinId(String acptBusinId) {
            this.acptBusinId = acptBusinId;
        }

        public void setAcptBusinKind(String acptBusinKind) {
            this.acptBusinKind = acptBusinKind;
        }

        public void setAcptFormStatus(Character acptFormStatus) {
            this.acptFormStatus = acptFormStatus;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetBpsAcptformCheckInnerOutput:(");
            buffer.append("acptId:" + this.acptId);
            buffer.append(",acptBusinId:" + this.acptBusinId);
            buffer.append(",acptBusinKind:" + this.acptBusinKind);
            buffer.append(",acptFormStatus:" + this.acptFormStatus);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.acptId);
            builder.append(this.acptBusinId);
            builder.append(this.acptBusinKind);
            builder.append(this.acptFormStatus);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.GetBpsAcptformCheckInnerOutput) {
                InnerBpsService.GetBpsAcptformCheckInnerOutput test = (InnerBpsService.GetBpsAcptformCheckInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.acptId, test.acptId);
                builder.append(this.acptBusinId, test.acptBusinId);
                builder.append(this.acptBusinKind, test.acptBusinKind);
                builder.append(this.acptFormStatus, test.acptFormStatus);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetBpsAcptformCheckInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 60,
                charset = "utf-8"
        )
        private String operatorName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character useType = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String menuCode = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String functionStr = " ";
        private Integer branchNo = 0;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String clientId = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String acptId = " ";
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String acptBusinKind = " ";
        @SinogramLength(
                min = 0,
                max = 10,
                charset = "utf-8"
        )
        private String acptBusinId = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fundAccount = " ";
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String acptEnrouteField = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character acptType = ' ';

        public GetBpsAcptformCheckInnerInput() {
        }

        public String getOperatorName() {
            if (this.operatorName == null) {
                return " ";
            } else {
                return this.operatorName.isEmpty() ? " " : this.operatorName;
            }
        }

        public Character getUseType() {
            return this.useType != null ? this.useType : ' ';
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getMenuCode() {
            if (this.menuCode == null) {
                return " ";
            } else {
                return this.menuCode.isEmpty() ? " " : this.menuCode;
            }
        }

        public String getFunctionStr() {
            if (this.functionStr == null) {
                return " ";
            } else {
                return this.functionStr.isEmpty() ? " " : this.functionStr;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getAcptId() {
            if (this.acptId == null) {
                return " ";
            } else {
                return this.acptId.isEmpty() ? " " : this.acptId;
            }
        }

        public String getAcptBusinKind() {
            if (this.acptBusinKind == null) {
                return " ";
            } else {
                return this.acptBusinKind.isEmpty() ? " " : this.acptBusinKind;
            }
        }

        public String getAcptBusinId() {
            if (this.acptBusinId == null) {
                return " ";
            } else {
                return this.acptBusinId.isEmpty() ? " " : this.acptBusinId;
            }
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getAcptEnrouteField() {
            if (this.acptEnrouteField == null) {
                return " ";
            } else {
                return this.acptEnrouteField.isEmpty() ? " " : this.acptEnrouteField;
            }
        }

        public Character getAcptType() {
            return this.acptType != null ? this.acptType : ' ';
        }

        public void setOperatorName(String operatorName) {
            this.operatorName = operatorName;
        }

        public void setUseType(Character useType) {
            this.useType = useType;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setMenuCode(String menuCode) {
            this.menuCode = menuCode;
        }

        public void setFunctionStr(String functionStr) {
            this.functionStr = functionStr;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setAcptId(String acptId) {
            this.acptId = acptId;
        }

        public void setAcptBusinKind(String acptBusinKind) {
            this.acptBusinKind = acptBusinKind;
        }

        public void setAcptBusinId(String acptBusinId) {
            this.acptBusinId = acptBusinId;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setAcptEnrouteField(String acptEnrouteField) {
            this.acptEnrouteField = acptEnrouteField;
        }

        public void setAcptType(Character acptType) {
            this.acptType = acptType;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetBpsAcptformCheckInnerInput:(");
            buffer.append("operatorName:" + this.operatorName);
            buffer.append(",useType:" + this.useType);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",menuCode:" + this.menuCode);
            buffer.append(",functionStr:" + this.functionStr);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",acptId:" + this.acptId);
            buffer.append(",acptBusinKind:" + this.acptBusinKind);
            buffer.append(",acptBusinId:" + this.acptBusinId);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",acptEnrouteField:" + this.acptEnrouteField);
            buffer.append(",acptType:" + this.acptType);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.operatorName);
            builder.append(this.useType);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.menuCode);
            builder.append(this.functionStr);
            builder.append(this.branchNo);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.clientId);
            builder.append(this.acptId);
            builder.append(this.acptBusinKind);
            builder.append(this.acptBusinId);
            builder.append(this.fundAccount);
            builder.append(this.acptEnrouteField);
            builder.append(this.acptType);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.GetBpsAcptformCheckInnerInput) {
                InnerBpsService.GetBpsAcptformCheckInnerInput test = (InnerBpsService.GetBpsAcptformCheckInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.operatorName, test.operatorName);
                builder.append(this.useType, test.useType);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.menuCode, test.menuCode);
                builder.append(this.functionStr, test.functionStr);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.clientId, test.clientId);
                builder.append(this.acptId, test.acptId);
                builder.append(this.acptBusinKind, test.acptBusinKind);
                builder.append(this.acptBusinId, test.acptBusinId);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.acptEnrouteField, test.acptEnrouteField);
                builder.append(this.acptType, test.acptType);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetBpsAcptTplInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String acptBusinId = " ";
        private String acptCategoryName = " ";

        public GetBpsAcptTplInnerOutput() {
        }

        public String getAcptBusinId() {
            if (this.acptBusinId == null) {
                return " ";
            } else {
                return this.acptBusinId.isEmpty() ? " " : this.acptBusinId;
            }
        }

        public String getAcptCategoryName() {
            if (this.acptCategoryName == null) {
                return " ";
            } else {
                return this.acptCategoryName.isEmpty() ? " " : this.acptCategoryName;
            }
        }

        public void setAcptBusinId(String acptBusinId) {
            this.acptBusinId = acptBusinId;
        }

        public void setAcptCategoryName(String acptCategoryName) {
            this.acptCategoryName = acptCategoryName;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetBpsAcptTplInnerOutput:(");
            buffer.append("acptBusinId:" + this.acptBusinId);
            buffer.append(",acptCategoryName:" + this.acptCategoryName);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.acptBusinId);
            builder.append(this.acptCategoryName);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.GetBpsAcptTplInnerOutput) {
                InnerBpsService.GetBpsAcptTplInnerOutput test = (InnerBpsService.GetBpsAcptTplInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.acptBusinId, test.acptBusinId);
                builder.append(this.acptCategoryName, test.acptCategoryName);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetBpsAcptTplInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 60,
                charset = "utf-8"
        )
        private String operatorName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character useType = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String menuCode = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String functionStr = " ";
        private Integer branchNo = 0;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";

        public GetBpsAcptTplInnerInput() {
        }

        public String getOperatorName() {
            if (this.operatorName == null) {
                return " ";
            } else {
                return this.operatorName.isEmpty() ? " " : this.operatorName;
            }
        }

        public Character getUseType() {
            return this.useType != null ? this.useType : ' ';
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getMenuCode() {
            if (this.menuCode == null) {
                return " ";
            } else {
                return this.menuCode.isEmpty() ? " " : this.menuCode;
            }
        }

        public String getFunctionStr() {
            if (this.functionStr == null) {
                return " ";
            } else {
                return this.functionStr.isEmpty() ? " " : this.functionStr;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public void setOperatorName(String operatorName) {
            this.operatorName = operatorName;
        }

        public void setUseType(Character useType) {
            this.useType = useType;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setMenuCode(String menuCode) {
            this.menuCode = menuCode;
        }

        public void setFunctionStr(String functionStr) {
            this.functionStr = functionStr;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetBpsAcptTplInnerInput:(");
            buffer.append("operatorName:" + this.operatorName);
            buffer.append(",useType:" + this.useType);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",menuCode:" + this.menuCode);
            buffer.append(",functionStr:" + this.functionStr);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.operatorName);
            builder.append(this.useType);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.menuCode);
            builder.append(this.functionStr);
            builder.append(this.branchNo);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.GetBpsAcptTplInnerInput) {
                InnerBpsService.GetBpsAcptTplInnerInput test = (InnerBpsService.GetBpsAcptTplInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.operatorName, test.operatorName);
                builder.append(this.useType, test.useType);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.menuCode, test.menuCode);
                builder.append(this.functionStr, test.functionStr);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetBpsAcptBusindataInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String functionData = " ";
        private String paramData = " ";

        public GetBpsAcptBusindataInnerOutput() {
        }

        public String getFunctionData() {
            if (this.functionData == null) {
                return " ";
            } else {
                return this.functionData.isEmpty() ? " " : this.functionData;
            }
        }

        public String getParamData() {
            if (this.paramData == null) {
                return " ";
            } else {
                return this.paramData.isEmpty() ? " " : this.paramData;
            }
        }

        public void setFunctionData(String functionData) {
            this.functionData = functionData;
        }

        public void setParamData(String paramData) {
            this.paramData = paramData;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetBpsAcptBusindataInnerOutput:(");
            buffer.append("functionData:" + this.functionData);
            buffer.append(",paramData:" + this.paramData);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.functionData);
            builder.append(this.paramData);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.GetBpsAcptBusindataInnerOutput) {
                InnerBpsService.GetBpsAcptBusindataInnerOutput test = (InnerBpsService.GetBpsAcptBusindataInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.functionData, test.functionData);
                builder.append(this.paramData, test.paramData);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetBpsAcptBusindataInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 60,
                charset = "utf-8"
        )
        private String operatorName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character useType = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String menuCode = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String functionStr = " ";
        private Integer branchNo = 0;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 32,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String acptId;

        public GetBpsAcptBusindataInnerInput() {
        }

        public String getOperatorName() {
            if (this.operatorName == null) {
                return " ";
            } else {
                return this.operatorName.isEmpty() ? " " : this.operatorName;
            }
        }

        public Character getUseType() {
            return this.useType != null ? this.useType : ' ';
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getMenuCode() {
            if (this.menuCode == null) {
                return " ";
            } else {
                return this.menuCode.isEmpty() ? " " : this.menuCode;
            }
        }

        public String getFunctionStr() {
            if (this.functionStr == null) {
                return " ";
            } else {
                return this.functionStr.isEmpty() ? " " : this.functionStr;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getAcptId() {
            return this.acptId;
        }

        public void setOperatorName(String operatorName) {
            this.operatorName = operatorName;
        }

        public void setUseType(Character useType) {
            this.useType = useType;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setMenuCode(String menuCode) {
            this.menuCode = menuCode;
        }

        public void setFunctionStr(String functionStr) {
            this.functionStr = functionStr;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setAcptId(String acptId) {
            this.acptId = acptId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetBpsAcptBusindataInnerInput:(");
            buffer.append("operatorName:" + this.operatorName);
            buffer.append(",useType:" + this.useType);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",menuCode:" + this.menuCode);
            buffer.append(",functionStr:" + this.functionStr);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",acptId:" + this.acptId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.operatorName);
            builder.append(this.useType);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.menuCode);
            builder.append(this.functionStr);
            builder.append(this.branchNo);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.acptId);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.GetBpsAcptBusindataInnerInput) {
                InnerBpsService.GetBpsAcptBusindataInnerInput test = (InnerBpsService.GetBpsAcptBusindataInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.operatorName, test.operatorName);
                builder.append(this.useType, test.useType);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.menuCode, test.menuCode);
                builder.append(this.functionStr, test.functionStr);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.acptId, test.acptId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetArchFileInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private List<InnerBpsService.ArchfilelistDTO> rows;

        public GetArchFileInnerOutput() {
        }

        public List<InnerBpsService.ArchfilelistDTO> getRows() {
            return this.rows;
        }

        public void setRows(List<InnerBpsService.ArchfilelistDTO> rows) {
            this.rows = rows;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetArchFileInnerOutput:(");
            buffer.append("rows:" + this.rows);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.rows);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.GetArchFileInnerOutput) {
                InnerBpsService.GetArchFileInnerOutput test = (InnerBpsService.GetArchFileInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.rows, test.rows);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetArchFileInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 60,
                charset = "utf-8"
        )
        private String operatorName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character useType = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String menuCode = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String functionStr = " ";
        private Integer branchNo = 0;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @NotNull(
                message = "不能为空"
        )
        private Integer queryFlag;
        @NotNull(
                message = "不能为空"
        )
        private Integer archBusinessSysId;
        @SinogramLength(
                min = 1,
                max = 32,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String acptId;

        public GetArchFileInnerInput() {
        }

        public String getOperatorName() {
            if (this.operatorName == null) {
                return " ";
            } else {
                return this.operatorName.isEmpty() ? " " : this.operatorName;
            }
        }

        public Character getUseType() {
            return this.useType != null ? this.useType : ' ';
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getMenuCode() {
            if (this.menuCode == null) {
                return " ";
            } else {
                return this.menuCode.isEmpty() ? " " : this.menuCode;
            }
        }

        public String getFunctionStr() {
            if (this.functionStr == null) {
                return " ";
            } else {
                return this.functionStr.isEmpty() ? " " : this.functionStr;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public Integer getQueryFlag() {
            return this.queryFlag;
        }

        public Integer getArchBusinessSysId() {
            return this.archBusinessSysId;
        }

        public String getAcptId() {
            return this.acptId;
        }

        public void setOperatorName(String operatorName) {
            this.operatorName = operatorName;
        }

        public void setUseType(Character useType) {
            this.useType = useType;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setMenuCode(String menuCode) {
            this.menuCode = menuCode;
        }

        public void setFunctionStr(String functionStr) {
            this.functionStr = functionStr;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setQueryFlag(Integer queryFlag) {
            this.queryFlag = queryFlag;
        }

        public void setArchBusinessSysId(Integer archBusinessSysId) {
            this.archBusinessSysId = archBusinessSysId;
        }

        public void setAcptId(String acptId) {
            this.acptId = acptId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetArchFileInnerInput:(");
            buffer.append("operatorName:" + this.operatorName);
            buffer.append(",useType:" + this.useType);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",menuCode:" + this.menuCode);
            buffer.append(",functionStr:" + this.functionStr);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",queryFlag:" + this.queryFlag);
            buffer.append(",archBusinessSysId:" + this.archBusinessSysId);
            buffer.append(",acptId:" + this.acptId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.operatorName);
            builder.append(this.useType);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.menuCode);
            builder.append(this.functionStr);
            builder.append(this.branchNo);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.queryFlag);
            builder.append(this.archBusinessSysId);
            builder.append(this.acptId);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.GetArchFileInnerInput) {
                InnerBpsService.GetArchFileInnerInput test = (InnerBpsService.GetArchFileInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.operatorName, test.operatorName);
                builder.append(this.useType, test.useType);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.menuCode, test.menuCode);
                builder.append(this.functionStr, test.functionStr);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.queryFlag, test.queryFlag);
                builder.append(this.archBusinessSysId, test.archBusinessSysId);
                builder.append(this.acptId, test.acptId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetAcptInfoPageByAcptIdsInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer total = 0;
        private List<InnerBpsService.AcptTimeAndOperatorInfoDTO> rows;

        public GetAcptInfoPageByAcptIdsInnerOutput() {
        }

        public Integer getTotal() {
            return this.total != null ? this.total : 0;
        }

        public List<InnerBpsService.AcptTimeAndOperatorInfoDTO> getRows() {
            return this.rows;
        }

        public void setTotal(Integer total) {
            this.total = total;
        }

        public void setRows(List<InnerBpsService.AcptTimeAndOperatorInfoDTO> rows) {
            this.rows = rows;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetAcptInfoPageByAcptIdsInnerOutput:(");
            buffer.append("total:" + this.total);
            buffer.append(",rows:" + this.rows);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.total);
            builder.append(this.rows);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.GetAcptInfoPageByAcptIdsInnerOutput) {
                InnerBpsService.GetAcptInfoPageByAcptIdsInnerOutput test = (InnerBpsService.GetAcptInfoPageByAcptIdsInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.total, test.total);
                builder.append(this.rows, test.rows);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetAcptInfoPageByAcptIdsInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 60,
                charset = "utf-8"
        )
        private String operatorName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character useType = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String menuCode = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String functionStr = " ";
        private Integer branchNo = 0;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @NotNull(
                message = "不能为空"
        )
        private List<String> acptIdList;
        private Integer pageNo = 0;
        private Integer pageSize = 0;
        private Integer requestNum = 0;

        public GetAcptInfoPageByAcptIdsInnerInput() {
        }

        public String getOperatorName() {
            if (this.operatorName == null) {
                return " ";
            } else {
                return this.operatorName.isEmpty() ? " " : this.operatorName;
            }
        }

        public Character getUseType() {
            return this.useType != null ? this.useType : ' ';
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getMenuCode() {
            if (this.menuCode == null) {
                return " ";
            } else {
                return this.menuCode.isEmpty() ? " " : this.menuCode;
            }
        }

        public String getFunctionStr() {
            if (this.functionStr == null) {
                return " ";
            } else {
                return this.functionStr.isEmpty() ? " " : this.functionStr;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public List<String> getAcptIdList() {
            return this.acptIdList;
        }

        public Integer getPageNo() {
            return this.pageNo != null ? this.pageNo : 0;
        }

        public Integer getPageSize() {
            return this.pageSize != null ? this.pageSize : 0;
        }

        public Integer getRequestNum() {
            return this.requestNum != null ? this.requestNum : 0;
        }

        public void setOperatorName(String operatorName) {
            this.operatorName = operatorName;
        }

        public void setUseType(Character useType) {
            this.useType = useType;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setMenuCode(String menuCode) {
            this.menuCode = menuCode;
        }

        public void setFunctionStr(String functionStr) {
            this.functionStr = functionStr;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setAcptIdList(List<String> acptIdList) {
            this.acptIdList = acptIdList;
        }

        public void setPageNo(Integer pageNo) {
            this.pageNo = pageNo;
        }

        public void setPageSize(Integer pageSize) {
            this.pageSize = pageSize;
        }

        public void setRequestNum(Integer requestNum) {
            this.requestNum = requestNum;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetAcptInfoPageByAcptIdsInnerInput:(");
            buffer.append("operatorName:" + this.operatorName);
            buffer.append(",useType:" + this.useType);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",menuCode:" + this.menuCode);
            buffer.append(",functionStr:" + this.functionStr);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",acptIdList:" + this.acptIdList);
            buffer.append(",pageNo:" + this.pageNo);
            buffer.append(",pageSize:" + this.pageSize);
            buffer.append(",requestNum:" + this.requestNum);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.operatorName);
            builder.append(this.useType);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.menuCode);
            builder.append(this.functionStr);
            builder.append(this.branchNo);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.acptIdList);
            builder.append(this.pageNo);
            builder.append(this.pageSize);
            builder.append(this.requestNum);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.GetAcptInfoPageByAcptIdsInnerInput) {
                InnerBpsService.GetAcptInfoPageByAcptIdsInnerInput test = (InnerBpsService.GetAcptInfoPageByAcptIdsInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.operatorName, test.operatorName);
                builder.append(this.useType, test.useType);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.menuCode, test.menuCode);
                builder.append(this.functionStr, test.functionStr);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.acptIdList, test.acptIdList);
                builder.append(this.pageNo, test.pageNo);
                builder.append(this.pageSize, test.pageSize);
                builder.append(this.requestNum, test.requestNum);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetAcptFormByPageInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String acptId = " ";
        private String acptBusinId = " ";
        private String acptBusinKind = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character acptFormStatus = ' ';
        private String workflowOrderId = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private String fundAccount = " ";
        private Integer branchNo = 0;
        private String clientId = " ";
        private String operatorNo = " ";
        private Integer opBranchNo = 0;
        private Integer acceptDate = 0;
        private Integer acceptTime = 0;
        private Integer dealDate = 0;
        private Integer dealTime = 0;
        private Integer dateClear = 0;
        private String positionStr = " ";
        private String remark = " ";
        private Integer errorNoInner = 0;
        private String errorInfoInner = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character resend = ' ';
        private Integer initDate = 0;
        private String columnStr = " ";
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character idKind = ' ';
        private String idNo = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character organFlag = ' ';
        private String acptEnrouteField = " ";
        private String rejectFlagStr = " ";
        private String rejectReason = " ";
        private Integer acptChannel = 0;
        private String operatorName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character acptType = ' ';
        private String custId = " ";
        private Integer count = 0;
        private String acptBusinProve = " ";
        private String fullName = " ";
        private String functionData = " ";
        private String paramData = " ";

        public GetAcptFormByPageInnerOutput() {
        }

        public String getAcptId() {
            if (this.acptId == null) {
                return " ";
            } else {
                return this.acptId.isEmpty() ? " " : this.acptId;
            }
        }

        public String getAcptBusinId() {
            if (this.acptBusinId == null) {
                return " ";
            } else {
                return this.acptBusinId.isEmpty() ? " " : this.acptBusinId;
            }
        }

        public String getAcptBusinKind() {
            if (this.acptBusinKind == null) {
                return " ";
            } else {
                return this.acptBusinKind.isEmpty() ? " " : this.acptBusinKind;
            }
        }

        public Character getAcptFormStatus() {
            return this.acptFormStatus != null ? this.acptFormStatus : ' ';
        }

        public String getWorkflowOrderId() {
            if (this.workflowOrderId == null) {
                return " ";
            } else {
                return this.workflowOrderId.isEmpty() ? " " : this.workflowOrderId;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public Integer getAcceptDate() {
            return this.acceptDate != null ? this.acceptDate : 0;
        }

        public Integer getAcceptTime() {
            return this.acceptTime != null ? this.acceptTime : 0;
        }

        public Integer getDealDate() {
            return this.dealDate != null ? this.dealDate : 0;
        }

        public Integer getDealTime() {
            return this.dealTime != null ? this.dealTime : 0;
        }

        public Integer getDateClear() {
            return this.dateClear != null ? this.dateClear : 0;
        }

        public String getPositionStr() {
            if (this.positionStr == null) {
                return " ";
            } else {
                return this.positionStr.isEmpty() ? " " : this.positionStr;
            }
        }

        public String getRemark() {
            if (this.remark == null) {
                return " ";
            } else {
                return this.remark.isEmpty() ? " " : this.remark;
            }
        }

        public Integer getErrorNoInner() {
            return this.errorNoInner != null ? this.errorNoInner : 0;
        }

        public String getErrorInfoInner() {
            if (this.errorInfoInner == null) {
                return " ";
            } else {
                return this.errorInfoInner.isEmpty() ? " " : this.errorInfoInner;
            }
        }

        public Character getResend() {
            return this.resend != null ? this.resend : ' ';
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public String getColumnStr() {
            if (this.columnStr == null) {
                return " ";
            } else {
                return this.columnStr.isEmpty() ? " " : this.columnStr;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getIdKind() {
            return this.idKind != null ? this.idKind : ' ';
        }

        public String getIdNo() {
            if (this.idNo == null) {
                return " ";
            } else {
                return this.idNo.isEmpty() ? " " : this.idNo;
            }
        }

        public Character getOrganFlag() {
            return this.organFlag != null ? this.organFlag : ' ';
        }

        public String getAcptEnrouteField() {
            if (this.acptEnrouteField == null) {
                return " ";
            } else {
                return this.acptEnrouteField.isEmpty() ? " " : this.acptEnrouteField;
            }
        }

        public String getRejectFlagStr() {
            if (this.rejectFlagStr == null) {
                return " ";
            } else {
                return this.rejectFlagStr.isEmpty() ? " " : this.rejectFlagStr;
            }
        }

        public String getRejectReason() {
            if (this.rejectReason == null) {
                return " ";
            } else {
                return this.rejectReason.isEmpty() ? " " : this.rejectReason;
            }
        }

        public Integer getAcptChannel() {
            return this.acptChannel != null ? this.acptChannel : 0;
        }

        public String getOperatorName() {
            if (this.operatorName == null) {
                return " ";
            } else {
                return this.operatorName.isEmpty() ? " " : this.operatorName;
            }
        }

        public Character getAcptType() {
            return this.acptType != null ? this.acptType : ' ';
        }

        public String getCustId() {
            if (this.custId == null) {
                return " ";
            } else {
                return this.custId.isEmpty() ? " " : this.custId;
            }
        }

        public Integer getCount() {
            return this.count != null ? this.count : 0;
        }

        public String getAcptBusinProve() {
            if (this.acptBusinProve == null) {
                return " ";
            } else {
                return this.acptBusinProve.isEmpty() ? " " : this.acptBusinProve;
            }
        }

        public String getFullName() {
            if (this.fullName == null) {
                return " ";
            } else {
                return this.fullName.isEmpty() ? " " : this.fullName;
            }
        }

        public String getFunctionData() {
            if (this.functionData == null) {
                return " ";
            } else {
                return this.functionData.isEmpty() ? " " : this.functionData;
            }
        }

        public String getParamData() {
            if (this.paramData == null) {
                return " ";
            } else {
                return this.paramData.isEmpty() ? " " : this.paramData;
            }
        }

        public void setAcptId(String acptId) {
            this.acptId = acptId;
        }

        public void setAcptBusinId(String acptBusinId) {
            this.acptBusinId = acptBusinId;
        }

        public void setAcptBusinKind(String acptBusinKind) {
            this.acptBusinKind = acptBusinKind;
        }

        public void setAcptFormStatus(Character acptFormStatus) {
            this.acptFormStatus = acptFormStatus;
        }

        public void setWorkflowOrderId(String workflowOrderId) {
            this.workflowOrderId = workflowOrderId;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setAcceptDate(Integer acceptDate) {
            this.acceptDate = acceptDate;
        }

        public void setAcceptTime(Integer acceptTime) {
            this.acceptTime = acceptTime;
        }

        public void setDealDate(Integer dealDate) {
            this.dealDate = dealDate;
        }

        public void setDealTime(Integer dealTime) {
            this.dealTime = dealTime;
        }

        public void setDateClear(Integer dateClear) {
            this.dateClear = dateClear;
        }

        public void setPositionStr(String positionStr) {
            this.positionStr = positionStr;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public void setErrorNoInner(Integer errorNoInner) {
            this.errorNoInner = errorNoInner;
        }

        public void setErrorInfoInner(String errorInfoInner) {
            this.errorInfoInner = errorInfoInner;
        }

        public void setResend(Character resend) {
            this.resend = resend;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public void setColumnStr(String columnStr) {
            this.columnStr = columnStr;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setIdKind(Character idKind) {
            this.idKind = idKind;
        }

        public void setIdNo(String idNo) {
            this.idNo = idNo;
        }

        public void setOrganFlag(Character organFlag) {
            this.organFlag = organFlag;
        }

        public void setAcptEnrouteField(String acptEnrouteField) {
            this.acptEnrouteField = acptEnrouteField;
        }

        public void setRejectFlagStr(String rejectFlagStr) {
            this.rejectFlagStr = rejectFlagStr;
        }

        public void setRejectReason(String rejectReason) {
            this.rejectReason = rejectReason;
        }

        public void setAcptChannel(Integer acptChannel) {
            this.acptChannel = acptChannel;
        }

        public void setOperatorName(String operatorName) {
            this.operatorName = operatorName;
        }

        public void setAcptType(Character acptType) {
            this.acptType = acptType;
        }

        public void setCustId(String custId) {
            this.custId = custId;
        }

        public void setCount(Integer count) {
            this.count = count;
        }

        public void setAcptBusinProve(String acptBusinProve) {
            this.acptBusinProve = acptBusinProve;
        }

        public void setFullName(String fullName) {
            this.fullName = fullName;
        }

        public void setFunctionData(String functionData) {
            this.functionData = functionData;
        }

        public void setParamData(String paramData) {
            this.paramData = paramData;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetAcptFormByPageInnerOutput:(");
            buffer.append("acptId:" + this.acptId);
            buffer.append(",acptBusinId:" + this.acptBusinId);
            buffer.append(",acptBusinKind:" + this.acptBusinKind);
            buffer.append(",acptFormStatus:" + this.acptFormStatus);
            buffer.append(",workflowOrderId:" + this.workflowOrderId);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",acceptDate:" + this.acceptDate);
            buffer.append(",acceptTime:" + this.acceptTime);
            buffer.append(",dealDate:" + this.dealDate);
            buffer.append(",dealTime:" + this.dealTime);
            buffer.append(",dateClear:" + this.dateClear);
            buffer.append(",positionStr:" + this.positionStr);
            buffer.append(",remark:" + this.remark);
            buffer.append(",errorNoInner:" + this.errorNoInner);
            buffer.append(",errorInfoInner:" + this.errorInfoInner);
            buffer.append(",resend:" + this.resend);
            buffer.append(",initDate:" + this.initDate);
            buffer.append(",columnStr:" + this.columnStr);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",idKind:" + this.idKind);
            buffer.append(",idNo:" + this.idNo);
            buffer.append(",organFlag:" + this.organFlag);
            buffer.append(",acptEnrouteField:" + this.acptEnrouteField);
            buffer.append(",rejectFlagStr:" + this.rejectFlagStr);
            buffer.append(",rejectReason:" + this.rejectReason);
            buffer.append(",acptChannel:" + this.acptChannel);
            buffer.append(",operatorName:" + this.operatorName);
            buffer.append(",acptType:" + this.acptType);
            buffer.append(",custId:" + this.custId);
            buffer.append(",count:" + this.count);
            buffer.append(",acptBusinProve:" + this.acptBusinProve);
            buffer.append(",fullName:" + this.fullName);
            buffer.append(",functionData:" + this.functionData);
            buffer.append(",paramData:" + this.paramData);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.acptId);
            builder.append(this.acptBusinId);
            builder.append(this.acptBusinKind);
            builder.append(this.acptFormStatus);
            builder.append(this.workflowOrderId);
            builder.append(this.opEntrustWay);
            builder.append(this.fundAccount);
            builder.append(this.branchNo);
            builder.append(this.clientId);
            builder.append(this.operatorNo);
            builder.append(this.opBranchNo);
            builder.append(this.acceptDate);
            builder.append(this.acceptTime);
            builder.append(this.dealDate);
            builder.append(this.dealTime);
            builder.append(this.dateClear);
            builder.append(this.positionStr);
            builder.append(this.remark);
            builder.append(this.errorNoInner);
            builder.append(this.errorInfoInner);
            builder.append(this.resend);
            builder.append(this.initDate);
            builder.append(this.columnStr);
            builder.append(this.opStation);
            builder.append(this.idKind);
            builder.append(this.idNo);
            builder.append(this.organFlag);
            builder.append(this.acptEnrouteField);
            builder.append(this.rejectFlagStr);
            builder.append(this.rejectReason);
            builder.append(this.acptChannel);
            builder.append(this.operatorName);
            builder.append(this.acptType);
            builder.append(this.custId);
            builder.append(this.count);
            builder.append(this.acptBusinProve);
            builder.append(this.fullName);
            builder.append(this.functionData);
            builder.append(this.paramData);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.GetAcptFormByPageInnerOutput) {
                InnerBpsService.GetAcptFormByPageInnerOutput test = (InnerBpsService.GetAcptFormByPageInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.acptId, test.acptId);
                builder.append(this.acptBusinId, test.acptBusinId);
                builder.append(this.acptBusinKind, test.acptBusinKind);
                builder.append(this.acptFormStatus, test.acptFormStatus);
                builder.append(this.workflowOrderId, test.workflowOrderId);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.clientId, test.clientId);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.acceptDate, test.acceptDate);
                builder.append(this.acceptTime, test.acceptTime);
                builder.append(this.dealDate, test.dealDate);
                builder.append(this.dealTime, test.dealTime);
                builder.append(this.dateClear, test.dateClear);
                builder.append(this.positionStr, test.positionStr);
                builder.append(this.remark, test.remark);
                builder.append(this.errorNoInner, test.errorNoInner);
                builder.append(this.errorInfoInner, test.errorInfoInner);
                builder.append(this.resend, test.resend);
                builder.append(this.initDate, test.initDate);
                builder.append(this.columnStr, test.columnStr);
                builder.append(this.opStation, test.opStation);
                builder.append(this.idKind, test.idKind);
                builder.append(this.idNo, test.idNo);
                builder.append(this.organFlag, test.organFlag);
                builder.append(this.acptEnrouteField, test.acptEnrouteField);
                builder.append(this.rejectFlagStr, test.rejectFlagStr);
                builder.append(this.rejectReason, test.rejectReason);
                builder.append(this.acptChannel, test.acptChannel);
                builder.append(this.operatorName, test.operatorName);
                builder.append(this.acptType, test.acptType);
                builder.append(this.custId, test.custId);
                builder.append(this.count, test.count);
                builder.append(this.acptBusinProve, test.acptBusinProve);
                builder.append(this.fullName, test.fullName);
                builder.append(this.functionData, test.functionData);
                builder.append(this.paramData, test.paramData);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetAcptFormByPageInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 60,
                charset = "utf-8"
        )
        private String operatorName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character useType = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String menuCode = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String functionStr = " ";
        private Integer branchNo = 0;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String clientId = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String acptId = " ";
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String acptBusinKind = " ";
        @SinogramLength(
                min = 0,
                max = 10,
                charset = "utf-8"
        )
        private String acptBusinId = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String enAcptStatus = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character acptType = ' ';
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fundAccount = " ";
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String acptEnrouteField = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNoQ = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character idKind = ' ';
        @SinogramLength(
                min = 0,
                max = 40,
                charset = "utf-8"
        )
        private String idNo = " ";
        private Integer beginDate = 0;
        private Integer endDate = 0;
        private Integer pageNo = 0;
        private Integer pageSize = 0;
        private Integer requestNum = 0;

        public GetAcptFormByPageInnerInput() {
        }

        public String getOperatorName() {
            if (this.operatorName == null) {
                return " ";
            } else {
                return this.operatorName.isEmpty() ? " " : this.operatorName;
            }
        }

        public Character getUseType() {
            return this.useType != null ? this.useType : ' ';
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getMenuCode() {
            if (this.menuCode == null) {
                return " ";
            } else {
                return this.menuCode.isEmpty() ? " " : this.menuCode;
            }
        }

        public String getFunctionStr() {
            if (this.functionStr == null) {
                return " ";
            } else {
                return this.functionStr.isEmpty() ? " " : this.functionStr;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getAcptId() {
            if (this.acptId == null) {
                return " ";
            } else {
                return this.acptId.isEmpty() ? " " : this.acptId;
            }
        }

        public String getAcptBusinKind() {
            if (this.acptBusinKind == null) {
                return " ";
            } else {
                return this.acptBusinKind.isEmpty() ? " " : this.acptBusinKind;
            }
        }

        public String getAcptBusinId() {
            if (this.acptBusinId == null) {
                return " ";
            } else {
                return this.acptBusinId.isEmpty() ? " " : this.acptBusinId;
            }
        }

        public String getEnAcptStatus() {
            if (this.enAcptStatus == null) {
                return " ";
            } else {
                return this.enAcptStatus.isEmpty() ? " " : this.enAcptStatus;
            }
        }

        public Character getAcptType() {
            return this.acptType != null ? this.acptType : ' ';
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getAcptEnrouteField() {
            if (this.acptEnrouteField == null) {
                return " ";
            } else {
                return this.acptEnrouteField.isEmpty() ? " " : this.acptEnrouteField;
            }
        }

        public String getOperatorNoQ() {
            if (this.operatorNoQ == null) {
                return " ";
            } else {
                return this.operatorNoQ.isEmpty() ? " " : this.operatorNoQ;
            }
        }

        public Character getIdKind() {
            return this.idKind != null ? this.idKind : ' ';
        }

        public String getIdNo() {
            if (this.idNo == null) {
                return " ";
            } else {
                return this.idNo.isEmpty() ? " " : this.idNo;
            }
        }

        public Integer getBeginDate() {
            return this.beginDate != null ? this.beginDate : 0;
        }

        public Integer getEndDate() {
            return this.endDate != null ? this.endDate : 0;
        }

        public Integer getPageNo() {
            return this.pageNo != null ? this.pageNo : 0;
        }

        public Integer getPageSize() {
            return this.pageSize != null ? this.pageSize : 0;
        }

        public Integer getRequestNum() {
            return this.requestNum != null ? this.requestNum : 0;
        }

        public void setOperatorName(String operatorName) {
            this.operatorName = operatorName;
        }

        public void setUseType(Character useType) {
            this.useType = useType;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setMenuCode(String menuCode) {
            this.menuCode = menuCode;
        }

        public void setFunctionStr(String functionStr) {
            this.functionStr = functionStr;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setAcptId(String acptId) {
            this.acptId = acptId;
        }

        public void setAcptBusinKind(String acptBusinKind) {
            this.acptBusinKind = acptBusinKind;
        }

        public void setAcptBusinId(String acptBusinId) {
            this.acptBusinId = acptBusinId;
        }

        public void setEnAcptStatus(String enAcptStatus) {
            this.enAcptStatus = enAcptStatus;
        }

        public void setAcptType(Character acptType) {
            this.acptType = acptType;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setAcptEnrouteField(String acptEnrouteField) {
            this.acptEnrouteField = acptEnrouteField;
        }

        public void setOperatorNoQ(String operatorNoQ) {
            this.operatorNoQ = operatorNoQ;
        }

        public void setIdKind(Character idKind) {
            this.idKind = idKind;
        }

        public void setIdNo(String idNo) {
            this.idNo = idNo;
        }

        public void setBeginDate(Integer beginDate) {
            this.beginDate = beginDate;
        }

        public void setEndDate(Integer endDate) {
            this.endDate = endDate;
        }

        public void setPageNo(Integer pageNo) {
            this.pageNo = pageNo;
        }

        public void setPageSize(Integer pageSize) {
            this.pageSize = pageSize;
        }

        public void setRequestNum(Integer requestNum) {
            this.requestNum = requestNum;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetAcptFormByPageInnerInput:(");
            buffer.append("operatorName:" + this.operatorName);
            buffer.append(",useType:" + this.useType);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",menuCode:" + this.menuCode);
            buffer.append(",functionStr:" + this.functionStr);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",acptId:" + this.acptId);
            buffer.append(",acptBusinKind:" + this.acptBusinKind);
            buffer.append(",acptBusinId:" + this.acptBusinId);
            buffer.append(",enAcptStatus:" + this.enAcptStatus);
            buffer.append(",acptType:" + this.acptType);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",acptEnrouteField:" + this.acptEnrouteField);
            buffer.append(",operatorNoQ:" + this.operatorNoQ);
            buffer.append(",idKind:" + this.idKind);
            buffer.append(",idNo:" + this.idNo);
            buffer.append(",beginDate:" + this.beginDate);
            buffer.append(",endDate:" + this.endDate);
            buffer.append(",pageNo:" + this.pageNo);
            buffer.append(",pageSize:" + this.pageSize);
            buffer.append(",requestNum:" + this.requestNum);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.operatorName);
            builder.append(this.useType);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.menuCode);
            builder.append(this.functionStr);
            builder.append(this.branchNo);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.clientId);
            builder.append(this.acptId);
            builder.append(this.acptBusinKind);
            builder.append(this.acptBusinId);
            builder.append(this.enAcptStatus);
            builder.append(this.acptType);
            builder.append(this.fundAccount);
            builder.append(this.acptEnrouteField);
            builder.append(this.operatorNoQ);
            builder.append(this.idKind);
            builder.append(this.idNo);
            builder.append(this.beginDate);
            builder.append(this.endDate);
            builder.append(this.pageNo);
            builder.append(this.pageSize);
            builder.append(this.requestNum);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.GetAcptFormByPageInnerInput) {
                InnerBpsService.GetAcptFormByPageInnerInput test = (InnerBpsService.GetAcptFormByPageInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.operatorName, test.operatorName);
                builder.append(this.useType, test.useType);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.menuCode, test.menuCode);
                builder.append(this.functionStr, test.functionStr);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.clientId, test.clientId);
                builder.append(this.acptId, test.acptId);
                builder.append(this.acptBusinKind, test.acptBusinKind);
                builder.append(this.acptBusinId, test.acptBusinId);
                builder.append(this.enAcptStatus, test.enAcptStatus);
                builder.append(this.acptType, test.acptType);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.acptEnrouteField, test.acptEnrouteField);
                builder.append(this.operatorNoQ, test.operatorNoQ);
                builder.append(this.idKind, test.idKind);
                builder.append(this.idNo, test.idNo);
                builder.append(this.beginDate, test.beginDate);
                builder.append(this.endDate, test.endDate);
                builder.append(this.pageNo, test.pageNo);
                builder.append(this.pageSize, test.pageSize);
                builder.append(this.requestNum, test.requestNum);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class DeleteBpsClientPreOpenInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Long serialNo = 0L;
        private String opRemark = " ";

        public DeleteBpsClientPreOpenInnerOutput() {
        }

        public Long getSerialNo() {
            return this.serialNo != null ? this.serialNo : 0L;
        }

        public String getOpRemark() {
            if (this.opRemark == null) {
                return " ";
            } else {
                return this.opRemark.isEmpty() ? " " : this.opRemark;
            }
        }

        public void setSerialNo(Long serialNo) {
            this.serialNo = serialNo;
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("DeleteBpsClientPreOpenInnerOutput:(");
            buffer.append("serialNo:" + this.serialNo);
            buffer.append(",opRemark:" + this.opRemark);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.serialNo);
            builder.append(this.opRemark);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.DeleteBpsClientPreOpenInnerOutput) {
                InnerBpsService.DeleteBpsClientPreOpenInnerOutput test = (InnerBpsService.DeleteBpsClientPreOpenInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.serialNo, test.serialNo);
                builder.append(this.opRemark, test.opRemark);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class DeleteBpsClientPreOpenInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 60,
                charset = "utf-8"
        )
        private String operatorName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character useType = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String menuCode = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String functionStr = " ";
        private Integer branchNo = 0;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String acptId = " ";

        public DeleteBpsClientPreOpenInnerInput() {
        }

        public String getOperatorName() {
            if (this.operatorName == null) {
                return " ";
            } else {
                return this.operatorName.isEmpty() ? " " : this.operatorName;
            }
        }

        public Character getUseType() {
            return this.useType != null ? this.useType : ' ';
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getMenuCode() {
            if (this.menuCode == null) {
                return " ";
            } else {
                return this.menuCode.isEmpty() ? " " : this.menuCode;
            }
        }

        public String getFunctionStr() {
            if (this.functionStr == null) {
                return " ";
            } else {
                return this.functionStr.isEmpty() ? " " : this.functionStr;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getAcptId() {
            if (this.acptId == null) {
                return " ";
            } else {
                return this.acptId.isEmpty() ? " " : this.acptId;
            }
        }

        public void setOperatorName(String operatorName) {
            this.operatorName = operatorName;
        }

        public void setUseType(Character useType) {
            this.useType = useType;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setMenuCode(String menuCode) {
            this.menuCode = menuCode;
        }

        public void setFunctionStr(String functionStr) {
            this.functionStr = functionStr;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setAcptId(String acptId) {
            this.acptId = acptId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("DeleteBpsClientPreOpenInnerInput:(");
            buffer.append("operatorName:" + this.operatorName);
            buffer.append(",useType:" + this.useType);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",menuCode:" + this.menuCode);
            buffer.append(",functionStr:" + this.functionStr);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",acptId:" + this.acptId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.operatorName);
            builder.append(this.useType);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.menuCode);
            builder.append(this.functionStr);
            builder.append(this.branchNo);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.acptId);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.DeleteBpsClientPreOpenInnerInput) {
                InnerBpsService.DeleteBpsClientPreOpenInnerInput test = (InnerBpsService.DeleteBpsClientPreOpenInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.operatorName, test.operatorName);
                builder.append(this.useType, test.useType);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.menuCode, test.menuCode);
                builder.append(this.functionStr, test.functionStr);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.acptId, test.acptId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class DeleteArgDataInitInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer initDate;

        public DeleteArgDataInitInnerOutput() {
        }

        public Integer getInitDate() {
            return this.initDate;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("DeleteArgDataInitInnerOutput:(");
            buffer.append("initDate:" + this.initDate);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.initDate);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.DeleteArgDataInitInnerOutput) {
                InnerBpsService.DeleteArgDataInitInnerOutput test = (InnerBpsService.DeleteArgDataInitInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.initDate, test.initDate);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class DeleteArgDataInitInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 60,
                charset = "utf-8"
        )
        private String operatorName;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character useType;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword;
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String menuCode;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String functionStr;
        private Integer branchNo;
        private Integer opBranchNo;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo;
        private Integer initDate;

        public DeleteArgDataInitInnerInput() {
        }

        public String getOperatorName() {
            return this.operatorName;
        }

        public Character getUseType() {
            return this.useType;
        }

        public String getOpPassword() {
            return this.opPassword;
        }

        public String getOpStation() {
            return this.opStation;
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay;
        }

        public String getMenuCode() {
            return this.menuCode;
        }

        public String getFunctionStr() {
            return this.functionStr;
        }

        public Integer getBranchNo() {
            return this.branchNo;
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo;
        }

        public String getOperatorNo() {
            return this.operatorNo;
        }

        public Integer getInitDate() {
            return this.initDate;
        }

        public void setOperatorName(String operatorName) {
            this.operatorName = operatorName;
        }

        public void setUseType(Character useType) {
            this.useType = useType;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setMenuCode(String menuCode) {
            this.menuCode = menuCode;
        }

        public void setFunctionStr(String functionStr) {
            this.functionStr = functionStr;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("DeleteArgDataInitInnerInput:(");
            buffer.append("operatorName:" + this.operatorName);
            buffer.append(",useType:" + this.useType);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",menuCode:" + this.menuCode);
            buffer.append(",functionStr:" + this.functionStr);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",initDate:" + this.initDate);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.operatorName);
            builder.append(this.useType);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.menuCode);
            builder.append(this.functionStr);
            builder.append(this.branchNo);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.initDate);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerBpsService.DeleteArgDataInitInnerInput) {
                InnerBpsService.DeleteArgDataInitInnerInput test = (InnerBpsService.DeleteArgDataInitInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.operatorName, test.operatorName);
                builder.append(this.useType, test.useType);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.menuCode, test.menuCode);
                builder.append(this.functionStr, test.functionStr);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.initDate, test.initDate);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }
}
