//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.hundsun.broker.mq.pub.service;

import com.hundsun.broker.base.PublicChecker.PublicParams;
import com.hundsun.jrescloud.rpc.annotation.CloudFunction;
import com.hundsun.jrescloud.rpc.annotation.CloudService;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

@CloudService(
        validation = true,
        validationNull = false,
        application = "hsbroker.rep"
)
public interface InnerMqService {
    @CloudFunction(
            value = "rep.putMqInner",
            desc = "消息发送",
            apiUrl = "/putMqInner"
    )
    InnerMqService.PutMqInnerOutput PutMqInner(InnerMqService.PutMqInnerInput var1);

    public static class PutMqInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private String indexes = " ";
        @NotNull(
                message = "不能为空"
        )
        private String topic = " ";
        @NotNull(
                message = "不能为空"
        )
        private String mqData = " ";
        @NotNull(
                message = "不能为空"
        )
        private String custId = " ";


        public PutMqInnerInput() {
        }

        public String getIndexes() {
            if (this.indexes == null) {
                return " ";
            } else {
                return this.indexes.isEmpty() ? " " : this.indexes;
            }
        }

        public String getTopic() {
            if (this.topic == null) {
                return " ";
            } else {
                return this.topic.isEmpty() ? " " : this.topic;
            }
        }

        public String getMqData() {
            if (this.mqData == null) {
                return " ";
            } else {
                return this.mqData.isEmpty() ? " " : this.mqData;
            }
        }

        public String getCustId() {
            if (this.custId == null) {
                return " ";
            } else {
                return this.custId.isEmpty() ? " " : this.custId;
            }
        }


        public void setIndexes(String indexes) {
            this.indexes = indexes;
        }
        public void setTopic(String topic) {
            this.topic = topic;
        }
        public void setMqData(String mqData) {
            this.mqData = mqData;
        }
        public void setCustId(String custId) {
            this.custId = custId;
        }



        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutMqInnerInput:(");
            buffer.append("indexes:" + this.indexes);
            buffer.append(",topic:" + this.topic);
            buffer.append(",mqData:" + this.mqData);
            buffer.append(",custId:" + this.custId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.indexes);
            builder.append(this.topic);
            builder.append(this.mqData);
            builder.append(this.custId);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerMqService.PutMqInnerInput) {
                InnerMqService.PutMqInnerInput test = (InnerMqService.PutMqInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.indexes, test.indexes);
                builder.append(this.topic, test.topic);
                builder.append(this.mqData, test.mqData);
                builder.append(this.custId, test.custId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutMqInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Long serialNo = 0L;

        public PutMqInnerOutput() {
        }

        public Long getSerialNo() {
            return this.serialNo != null ? this.serialNo : 0L;
        }

        public void setSerialNo(Long serialNo) {
            this.serialNo = serialNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("DeleteClientpreferByIdInnerOutput:(");
            buffer.append("serialNo:" + this.serialNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.serialNo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerMqService.PutMqInnerOutput) {
                InnerMqService.PutMqInnerOutput test = (InnerMqService.PutMqInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.serialNo, test.serialNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }
}
