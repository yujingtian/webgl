/**
 * 系统名称: ITS
 * 模块名称: ias.pub
 * 类  名  称: AdapterService.java
 * 软件版权: 恒生电子股份有限公司
 * 修改记录:
 * 修改人员                    修改说明 <br>
 * ============  ============================================
 * studio-auto      创建
 * ============  ============================================
 */
package com.hundsun.broker.mq.pub.service;

import com.hundsun.broker.base.PublicChecker;
import com.hundsun.broker.base.mq.MessageInfo;
import com.hundsun.jres.studio.annotation.JRESData;
import com.hundsun.jrescloud.rpc.annotation.CloudFunction;
import com.hundsun.jrescloud.rpc.annotation.CloudService;
import com.hundsun.jrescloud.rpc.def.validation.SinogramLength;

import java.io.Serializable;

/**
 * adapter服务接口 
 *
 * @author studio-auto
 * @date
 */
@CloudService(validation = true, validationNull = false)
public interface AdapterMqService {
    @JRESData
    public class

    AdapterReceiveInput implements PublicChecker.PublicParams, Serializable {

        private static final long serialVersionUID = 1L;
        /**
         * 菜单编号
         */
        @SinogramLength(min = 0, max = 64, charset = "utf-8")
        private String menuCode = " ";
        /**
         * 委托方式
         */
        private Character opEntrustWay = ' ';
        /**
         * 站点地址
         */
        @SinogramLength(min = 0, max = 255, charset = "utf-8")
        private String opStation = " ";
        /**
         * 操作员密码
         */
        @SinogramLength(min = 0, max = 64, charset = "utf-8")
        private String opPassword = " ";
        /**
         * 操作员编号
         */
        @SinogramLength(min = 0, max = 18, charset = "utf-8")
        private String operatorNo = " ";
        /**
         * 操作分支机构
         */
        private Integer opBranchNo = 0;
    }

    /**
     * 资产账户开户接收接口
     * 
     * @param messageInfo
     * @return
     */
    @CloudFunction(functionId = "fundaccountOpenMq", desc = "资产账户开户接收接口", partition = "1")
    void fundaccountOpenMq(MessageInfo<Object> messageInfo);

}
