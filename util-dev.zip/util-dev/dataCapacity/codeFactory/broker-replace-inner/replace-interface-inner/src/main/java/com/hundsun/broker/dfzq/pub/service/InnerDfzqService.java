//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.hundsun.broker.dfzq.pub.service;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.hundsun.broker.base.PublicChecker.PublicParams;
import com.hundsun.broker.base.databind.CharacterJsonDeserializer;
import com.hundsun.jrescloud.rpc.annotation.CloudFunction;
import com.hundsun.jrescloud.rpc.annotation.CloudService;
import com.hundsun.jrescloud.rpc.def.json.DoubleJsonDeserializer;
import com.hundsun.jrescloud.rpc.def.json.SerializeDoubleDigit;
import com.hundsun.jrescloud.rpc.def.validation.SinogramLength;
import java.io.Serializable;
import java.util.List;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

@CloudService(
        validation = true,
        validationNull = false,
        application = "hsbroker.adapter-dfzq"
)
public interface InnerDfzqService {
    @CloudFunction(
            value = "adapter-dfzq.getBankaccountInner",
            desc = "银行账户查询",
            apiUrl = "/getBankaccountInner"
    )
    List<InnerDfzqService.GetBankaccountInnerOutput> getBankaccountInner(InnerDfzqService.GetBankaccountInnerInput var1);

    @CloudFunction(
            value = "adapter-dfzq.postBankCtsAcctOpenInner",
            desc = "存管账户开户",
            apiUrl = "/postBankCtsAcctOpenInner"
    )
    InnerDfzqService.PostBankCtsAcctOpenInnerOutput postBankCtsAcctOpenInner(InnerDfzqService.PostBankCtsAcctOpenInnerInput var1);

    @CloudFunction(
            value = "adapter-dfzq.postBankaccountAcctOpenInner",
            desc = "转账账户开户",
            apiUrl = "/postBankaccountAcctOpenInner"
    )
    InnerDfzqService.PostBankaccountAcctOpenInnerOutput postBankaccountAcctOpenInner(InnerDfzqService.PostBankaccountAcctOpenInnerInput var1);

    @CloudFunction(
            value = "adapter-dfzq.getAdviserAccountCancelCheckInner",
            desc = "投顾账户销户检查",
            apiUrl = "/getAdviserAccountCancelCheck"
    )
    List<InnerDfzqService.GetAdviserAccountCancelCheckInnerOutput> getAdviserAccountCancelCheckInner(InnerDfzqService.GetAdviserAccountCancelCheckInnerInput var1);

    @CloudFunction(
            value = "adapter-dfzq.getAdviserTransAccountCancelCheckInner",
            desc = "投顾基金交易账号销户检查",
            apiUrl = "/getAdviserTransAccountCancelCheckInner"
    )
    List<InnerDfzqService.GetAdviserTransAccountCancelCheckInnerOutput> getAdviserTransAccountCancelCheckInner(InnerDfzqService.GetAdviserTransAccountCancelCheckInnerInput var1);

    @CloudFunction(
            value = "adapter-dfzq.getProdHolderListInner",
            desc = "查询产品账户",
            apiUrl = "/getProdHolderListInner"
    )
    List<InnerDfzqService.GetProdHolderListInnerOutput> getProdHolderListInner(InnerDfzqService.GetProdHolderListInnerInput var1);

    @CloudFunction(
            value = "adapter-dfzq.deleteBankCtsAcctInner",
            desc = "存管账户销户",
            apiUrl = "/deleteBankCtsAcctInner"
    )
    InnerDfzqService.DeleteBankCtsAcctInnerOutput deleteBankCtsAcctInner(InnerDfzqService.DeleteBankCtsAcctInnerInput var1);

    @CloudFunction(
            value = "adapter-dfzq.deleteBankaccountAcctInner",
            desc = "转账账户销户",
            apiUrl = "/deleteBankaccountAcctInner"
    )
    InnerDfzqService.DeleteBankaccountAcctInnerOutput deleteBankaccountAcctInner(InnerDfzqService.DeleteBankaccountAcctInnerInput var1);

    @CloudFunction(
            value = "adapter-dfzq.getfundAssetCertificationInner",
            desc = "查询资产数据",
            apiUrl = "/getfundAssetCertificationInner"
    )
    InnerDfzqService.GetfundAssetCertificationInnerOutput getfundAssetCertificationInner(InnerDfzqService.GetfundAssetCertificationInnerInput var1);

    @CloudFunction(
            value = "adapter-dfzq.getBankaccountCtsAcctInner",
            desc = "存管账户查询",
            apiUrl = "/getBankaccountCtsAcctInner"
    )
    List<InnerDfzqService.GetBankaccountCtsAcctInnerOutput> getBankaccountCtsAcctInner(InnerDfzqService.GetBankaccountCtsAcctInnerInput var1);

    @CloudFunction(
            value = "adapter-dfzq.getBankaccountAcctInner",
            desc = "转账账户查询",
            apiUrl = "/getBankaccountAcctInner"
    )
    List<InnerDfzqService.GetBankaccountAcctInnerOutput> getBankaccountAcctInner(InnerDfzqService.GetBankaccountAcctInnerInput var1);

    @CloudFunction(
            value = "adapter-dfzq.getFundCustBalanceInner",
            desc = "客户资金情况查询",
            apiUrl = "/getFundCustBalanceInner"
    )
    List<InnerDfzqService.GetFundCustBalanceInnerOutput> getFundCustBalanceInner(InnerDfzqService.GetFundCustBalanceInnerInput var1);

    @CloudFunction(
            value = "adapter-dfzq.getFundListByFundAccountInner",
            desc = "已开币种查询",
            apiUrl = "/getFundListByFundAccountInner"
    )
    List<InnerDfzqService.GetFundListByFundAccountInnerOutput> getFundListByFundAccountInner(InnerDfzqService.GetFundListByFundAccountInnerInput var1);

    @CloudFunction(
            value = "adapter-dfzq.getSysConfigSesInner",
            desc = "查询金仕达交易系统配置",
            apiUrl = "/getSysConfigSesInner"
    )
    List<InnerDfzqService.GetSysConfigSesInnerOutput> getSysConfigSesInner(InnerDfzqService.GetSysConfigSesInnerInput var1);

    @CloudFunction(
            value = "adapter-dfzq.getBankaccountCancelcheckInner",
            desc = "存管账户销户检查",
            apiUrl = "/getBankaccountCancelcheckInner"
    )
    InnerDfzqService.GetBankaccountCancelcheckInnerOutput getBankaccountCancelcheckInner(InnerDfzqService.GetBankaccountCancelcheckInnerInput var1);

    @CloudFunction(
            value = "adapter-dfzq.getFundaccountCloseCheckInner",
            desc = "资金账户销户检查",
            apiUrl = "/getFundaccountCloseCheckInner"
    )
    InnerDfzqService.GetFundaccountCloseCheckInnerOutput getFundaccountCloseCheckInner(InnerDfzqService.GetFundaccountCloseCheckInnerInput var1);

    @CloudFunction(
            value = "adapter-dfzq.getSysConfigCrtInner",
            desc = "查询金仕达融资融券交易配置",
            apiUrl = "/getSysConfigCrtInner"
    )
    List<InnerDfzqService.GetSysConfigCrtInnerOutput> getSysConfigCrtInner(InnerDfzqService.GetSysConfigCrtInnerInput var1);

    @CloudFunction(
            value = "adapter-dfzq.getSysConfigOptInner",
            desc = "查询金仕达期权交易配置",
            apiUrl = "/getSysConfigOptInner"
    )
    List<InnerDfzqService.GetSysConfigOptInnerOutput> getSysConfigOptInner(InnerDfzqService.GetSysConfigOptInnerInput var1);

    @CloudFunction(
            value = "adapter-dfzq.postFundSaveFromSecuInner",
            desc = "证券发起银行转证券",
            apiUrl = "/postFundSaveFromSecuInner"
    )
    InnerDfzqService.PostFundSaveFromSecuInnerOutput postFundSaveFromSecuInner(InnerDfzqService.PostFundSaveFromSecuInnerInput var1);

    @CloudFunction(
            value = "adapter-dfzq.postShortMessageInner",
            desc = "发送短信",
            apiUrl = "/postShortMessageInner"
    )
    InnerDfzqService.PostShortMessageInnerOutput postShortMessageInner(InnerDfzqService.PostShortMessageInnerInput var1);

    @CloudFunction(
            value = "adapter-dfzq.postSendEmailInner",
            desc = "发送邮件",
            apiUrl = "/postSendEmailInner"
    )
    InnerDfzqService.PostSendEmailInnerOutput postSendEmailInner(InnerDfzqService.PostSendEmailInnerInput var1);

    @CloudFunction(
            value = "adapter-dfzq.postSendEmailByFileInner",
            desc = "发送带附件的邮件",
            apiUrl = "/postSendEmailByFileInner"
    )
    InnerDfzqService.PostSendEmailByFileInnerOutput postSendEmailByFileInner(InnerDfzqService.PostSendEmailByFileInnerInput var1);

    @CloudFunction(
            value = "adapter-dfzq.getJsdCheckPasswordInner",
            desc = "金仕达客户密码验证",
            apiUrl = "/getJsdCheckPasswordInner"
    )
    InnerDfzqService.GetJsdCheckPasswordInnerOutput getJsdCheckPasswordInner(InnerDfzqService.GetJsdCheckPasswordInnerInput var1);

    @CloudFunction(
            value = "adapter-dfzq.getClientInfoEiamsInner",
            desc = "客户资料查询",
            apiUrl = "/getClientInfoEiamsInner"
    )
    List<InnerDfzqService.GetClientInfoEiamsInnerOutput> getClientInfoEiamsInner(InnerDfzqService.GetClientInfoEiamsInnerInput var1);

    @CloudFunction(
            value = "adapter-dfzq.getClientpreferMatchInner",
            desc = "投顾组合适当性查询",
            apiUrl = "/getClientpreferMatchInner"
    )
    InnerDfzqService.GetClientpreferMatchInnerOutput getClientpreferMatchInner(InnerDfzqService.GetClientpreferMatchInnerInput var1);

    @CloudFunction(
            value = "adapter-dfzq.getCodeInner",
            desc = "产品代码查询",
            apiUrl = "/getCodeInner"
    )
    InnerDfzqService.GetCodeInnerOutput getCodeInner(InnerDfzqService.GetCodeInnerInput var1);

    @CloudFunction(
            value = "adapter-dfzq.getFundaccountCancelInner",
            desc = "资产账户销户检查",
            apiUrl = "/getFundaccountCancelInner"
    )
    List<InnerDfzqService.GetFundaccountCancelInnerOutput> getFundaccountCancelInner(InnerDfzqService.GetFundaccountCancelInnerInput var1);

    @CloudFunction(
            value = "adapter-dfzq.getFundaccountInbusinessInner",
            desc = "资产账户在途业务检查",
            apiUrl = "/getFundaccountInbusinessInner"
    )
    List<InnerDfzqService.GetFundaccountInbusinessInnerOutput> getFundaccountInbusinessInner(InnerDfzqService.GetFundaccountInbusinessInnerInput var1);

    @CloudFunction(
            value = "adapter-dfzq.postProdholderAddInner",
            desc = "产品账户委托开户",
            apiUrl = "/postProdholderAddInner"
    )
    InnerDfzqService.PostProdholderAddInnerOutput postProdholderAddInner(InnerDfzqService.PostProdholderAddInnerInput var1);

    @CloudFunction(
            value = "adapter-dfzq.getProdholderQueryInner",
            desc = "产品账户委托查询",
            apiUrl = "/getProdholderQueryInner"
    )
    InnerDfzqService.GetProdholderQueryInnerOutput getProdholderQueryInner(InnerDfzqService.GetProdholderQueryInnerInput var1);

    @CloudFunction(
            value = "adapter-dfzq.getSysConfigZxInner",
            desc = "查询征信合同管理系统配置",
            apiUrl = "/getSysConfigZxInner"
    )
    List<InnerDfzqService.GetSysConfigZxInnerOutput> getSysConfigZxInner(InnerDfzqService.GetSysConfigZxInnerInput var1);

    @CloudFunction(
            value = "adapter-dfzq.putStockHolderOpenFrozen",
            desc = "股东开户费冻结",
            apiUrl = "/putStockHolderOpenFrozen"
    )
    InnerDfzqService.PutStockHolderOpenFrozenOutput putStockHolderOpenFrozen(InnerDfzqService.PutStockHolderOpenFrozenInput var1);

    @CloudFunction(
            value = "adapter-dfzq.deleteProdholderAcctInner",
            desc = "产品账户委托销户",
            apiUrl = "/deleteProdholderAcctInner"
    )
    InnerDfzqService.DeleteProdholderAcctInnerOutput deleteProdholderAcctInner(InnerDfzqService.DeleteProdholderAcctInnerInput var1);

    @CloudFunction(
            value = "adapter-dfzq.getFundInfoInner",
            desc = "账户资金信息查询",
            apiUrl = "/getFundInfoInner"
    )
    InnerDfzqService.GetFundInfoInnerOutput getFundInfoInner(InnerDfzqService.GetFundInfoInnerInput var1);

    @CloudFunction(
            value = "adapter-dfzq.putProdholderSynModInner",
            desc = "产品账户同步修改",
            apiUrl = "/putProdholderSynModInner"
    )
    InnerDfzqService.PutProdholderSynModInnerOutput putProdholderSynModInner(InnerDfzqService.PutProdholderSynModInnerInput var1);

    @CloudFunction(
            value = "adapter-dfzq.putFundaccountInner",
            desc = "资产账户修改",
            apiUrl = "/putFundaccountInner"
    )
    void putFundaccountInner(InnerDfzqService.PutFundaccountInnerInput var1);

    @CloudFunction(
            value = "adapter-dfzq.getProdholderTransCancelInner",
            desc = "交易账号销户检查",
            apiUrl = "/getProdholderTransCancelInner"
    )
    List<InnerDfzqService.GetProdholderTransCancelInnerOutput> getProdholderTransCancelInner(InnerDfzqService.GetProdholderTransCancelInnerInput var1);

    @CloudFunction(
            value = "adapter-dfzq.getProdholderCancelInner",
            desc = "产品账户销户检查",
            apiUrl = "/getProdholderCancelInner"
    )
    List<InnerDfzqService.GetProdholderCancelInnerOutput> getProdholderCancelInner(InnerDfzqService.GetProdholderCancelInnerInput var1);

    @CloudFunction(
            value = "adapter-dfzq.putProdholderFrozenInner",
            desc = "产品账户委托冻结",
            apiUrl = "/putProdholderFrozenInner"
    )
    InnerDfzqService.PutProdholderFrozenInnerOutput putProdholderFrozenInner(InnerDfzqService.PutProdholderFrozenInnerInput var1);

    @CloudFunction(
            value = "adapter-dfzq.postProdVideoInner",
            desc = "视频见证打标",
            apiUrl = "/postProdVideoInner"
    )
    InnerDfzqService.PostProdVideoInnerOutput postProdVideoInner(InnerDfzqService.PostProdVideoInnerInput var1);

    @CloudFunction(
            value = "adapter-dfzq.getBankReturnInfoInner",
            desc = "查询银行返回结果",
            apiUrl = "/getBankReturnInfoInner"
    )
    List<InnerDfzqService.GetBankReturnInfoInnerOutput> getBankReturnInfoInner(InnerDfzqService.GetBankReturnInfoInnerInput var1);

    @CloudFunction(
            value = "adapter-dfzq.getPriceFromInformationCenterInner",
            desc = "资讯中心行情获取",
            apiUrl = "/getPriceFromInformationCenterInner"
    )
    List<InnerDfzqService.GetPriceFromInformationCenterInnerOutput> getPriceFromInformationCenterInner(InnerDfzqService.GetPriceFromInformationCenterInnerInput var1);

    @CloudFunction(
            value = "adapter-dfzq.putPriceJzjyInner",
            desc = "集中交易行情更新",
            apiUrl = "/putPriceJzjyInner"
    )
    void putPriceJzjyInner(InnerDfzqService.PutPriceJzjyInnerInput var1);

    @CloudFunction(
            value = "adapter-dfzq.getFundaccountCancelCheckInner",
            apiUrl = "/getFundaccountCancelCheckInner",
            readWriteControlEnable = true
    )
    List<InnerDfzqService.GetFundaccountCancelCheckInnerOutput> getFundaccountCancelCheckInner(InnerDfzqService.GetFundaccountCancelCheckInnerInput var1);

    @CloudFunction(
            value = "adapter-dfzq.getExchangeclientinfoCancelCheckInner",
            apiUrl = "/getExchangeclientinfoCancelCheckInner",
            readWriteControlEnable = true
    )
    List<InnerDfzqService.GetExchangeclientinfoCancelCheckInnerOutput> getExchangeclientinfoCancelCheckInner(InnerDfzqService.GetExchangeclientinfoCancelCheckInnerInput var1);

    @CloudFunction(
            value = "adapter-dfzq.deleteExchangeclientinfoCancelInner",
            apiUrl = "/deleteExchangeclientinfoCancelInner"
    )
    void deleteExchangeclientinfoCancelInner(InnerDfzqService.DeleteExchangeclientinfoCancelInnerInput var1);

    @CloudFunction(
            value = "adapter-dfzq.putFundaccountCancelInner",
            apiUrl = "/putFundaccountCancelInner"
    )
    void putFundaccountCancelInner(InnerDfzqService.PutFundaccountCancelInnerInput var1);

    public static class PutFundaccountCancelInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String fundAccount;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId;

        public PutFundaccountCancelInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getFundAccount() {
            return this.fundAccount;
        }

        public String getClientId() {
            return this.clientId;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutFundaccountCancelInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.fundAccount);
            builder.append(this.clientId);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.PutFundaccountCancelInnerInput) {
                InnerDfzqService.PutFundaccountCancelInnerInput test = (InnerDfzqService.PutFundaccountCancelInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.clientId, test.clientId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class DeleteExchangeclientinfoCancelInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String fundAccount;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId;
        @SinogramLength(
                min = 1,
                max = 4,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String exchangeType;
        @SinogramLength(
                min = 1,
                max = 20,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String stockAccount;

        public DeleteExchangeclientinfoCancelInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getFundAccount() {
            return this.fundAccount;
        }

        public String getClientId() {
            return this.clientId;
        }

        public String getExchangeType() {
            return this.exchangeType;
        }

        public String getStockAccount() {
            return this.stockAccount;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public void setStockAccount(String stockAccount) {
            this.stockAccount = stockAccount;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("DeleteExchangeclientinfoCancelInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(",stockAccount:" + this.stockAccount);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.fundAccount);
            builder.append(this.clientId);
            builder.append(this.exchangeType);
            builder.append(this.stockAccount);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.DeleteExchangeclientinfoCancelInnerInput) {
                InnerDfzqService.DeleteExchangeclientinfoCancelInnerInput test = (InnerDfzqService.DeleteExchangeclientinfoCancelInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.clientId, test.clientId);
                builder.append(this.exchangeType, test.exchangeType);
                builder.append(this.stockAccount, test.stockAccount);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetExchangeclientinfoCancelCheckInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer noticeNo = 0;
        private String noticeInfo = " ";
        private String checkId = " ";

        public GetExchangeclientinfoCancelCheckInnerOutput() {
        }

        public Integer getNoticeNo() {
            return this.noticeNo != null ? this.noticeNo : 0;
        }

        public String getNoticeInfo() {
            if (this.noticeInfo == null) {
                return " ";
            } else {
                return this.noticeInfo.isEmpty() ? " " : this.noticeInfo;
            }
        }

        public String getCheckId() {
            if (this.checkId == null) {
                return " ";
            } else {
                return this.checkId.isEmpty() ? " " : this.checkId;
            }
        }

        public void setNoticeNo(Integer noticeNo) {
            this.noticeNo = noticeNo;
        }

        public void setNoticeInfo(String noticeInfo) {
            this.noticeInfo = noticeInfo;
        }

        public void setCheckId(String checkId) {
            this.checkId = checkId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetExchangeclientinfoCancelCheckInnerOutput:(");
            buffer.append("noticeNo:" + this.noticeNo);
            buffer.append(",noticeInfo:" + this.noticeInfo);
            buffer.append(",checkId:" + this.checkId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.noticeNo);
            builder.append(this.noticeInfo);
            builder.append(this.checkId);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.GetExchangeclientinfoCancelCheckInnerOutput) {
                InnerDfzqService.GetExchangeclientinfoCancelCheckInnerOutput test = (InnerDfzqService.GetExchangeclientinfoCancelCheckInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.noticeNo, test.noticeNo);
                builder.append(this.noticeInfo, test.noticeInfo);
                builder.append(this.checkId, test.checkId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetExchangeclientinfoCancelCheckInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String fundAccount;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId;
        @SinogramLength(
                min = 1,
                max = 4,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String exchangeType;
        @SinogramLength(
                min = 1,
                max = 20,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String stockAccount;

        public GetExchangeclientinfoCancelCheckInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getFundAccount() {
            return this.fundAccount;
        }

        public String getClientId() {
            return this.clientId;
        }

        public String getExchangeType() {
            return this.exchangeType;
        }

        public String getStockAccount() {
            return this.stockAccount;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public void setStockAccount(String stockAccount) {
            this.stockAccount = stockAccount;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetExchangeclientinfoCancelCheckInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(",stockAccount:" + this.stockAccount);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.fundAccount);
            builder.append(this.clientId);
            builder.append(this.exchangeType);
            builder.append(this.stockAccount);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.GetExchangeclientinfoCancelCheckInnerInput) {
                InnerDfzqService.GetExchangeclientinfoCancelCheckInnerInput test = (InnerDfzqService.GetExchangeclientinfoCancelCheckInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.clientId, test.clientId);
                builder.append(this.exchangeType, test.exchangeType);
                builder.append(this.stockAccount, test.stockAccount);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetFundaccountCancelCheckInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer noticeNo = 0;
        private String noticeInfo = " ";
        private String checkId = " ";

        public GetFundaccountCancelCheckInnerOutput() {
        }

        public Integer getNoticeNo() {
            return this.noticeNo != null ? this.noticeNo : 0;
        }

        public String getNoticeInfo() {
            if (this.noticeInfo == null) {
                return " ";
            } else {
                return this.noticeInfo.isEmpty() ? " " : this.noticeInfo;
            }
        }

        public String getCheckId() {
            if (this.checkId == null) {
                return " ";
            } else {
                return this.checkId.isEmpty() ? " " : this.checkId;
            }
        }

        public void setNoticeNo(Integer noticeNo) {
            this.noticeNo = noticeNo;
        }

        public void setNoticeInfo(String noticeInfo) {
            this.noticeInfo = noticeInfo;
        }

        public void setCheckId(String checkId) {
            this.checkId = checkId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetFundaccountCancelCheckInnerOutput:(");
            buffer.append("noticeNo:" + this.noticeNo);
            buffer.append(",noticeInfo:" + this.noticeInfo);
            buffer.append(",checkId:" + this.checkId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.noticeNo);
            builder.append(this.noticeInfo);
            builder.append(this.checkId);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.GetFundaccountCancelCheckInnerOutput) {
                InnerDfzqService.GetFundaccountCancelCheckInnerOutput test = (InnerDfzqService.GetFundaccountCancelCheckInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.noticeNo, test.noticeNo);
                builder.append(this.noticeInfo, test.noticeInfo);
                builder.append(this.checkId, test.checkId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetFundaccountCancelCheckInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String fundAccount;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId;

        public GetFundaccountCancelCheckInnerInput() {
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getFundAccount() {
            return this.fundAccount;
        }

        public String getClientId() {
            return this.clientId;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetFundaccountCancelCheckInnerInput:(");
            buffer.append("opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.fundAccount);
            builder.append(this.clientId);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.GetFundaccountCancelCheckInnerInput) {
                InnerDfzqService.GetFundaccountCancelCheckInnerInput test = (InnerDfzqService.GetFundaccountCancelCheckInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.clientId, test.clientId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutPriceJzjyInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 24,
                charset = "utf-8"
        )
        private String prodtaNo = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String prodCode = " ";
        @Digits(
                integer = 15,
                fraction = 8,
                message = "净值【netValue】 超出精度范围, 最大整数位为【15】, 小数位为【8】"
        )
        @SerializeDoubleDigit(
                digit = 8
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double netValue = 0.0D;
        private Integer navDate = 0;

        public PutPriceJzjyInnerInput() {
        }

        public String getProdtaNo() {
            if (this.prodtaNo == null) {
                return " ";
            } else {
                return this.prodtaNo.isEmpty() ? " " : this.prodtaNo;
            }
        }

        public String getProdCode() {
            if (this.prodCode == null) {
                return " ";
            } else {
                return this.prodCode.isEmpty() ? " " : this.prodCode;
            }
        }

        public Double getNetValue() {
            return this.netValue != null ? this.netValue : 0.0D;
        }

        public Integer getNavDate() {
            return this.navDate != null ? this.navDate : 0;
        }

        public void setProdtaNo(String prodtaNo) {
            this.prodtaNo = prodtaNo;
        }

        public void setProdCode(String prodCode) {
            this.prodCode = prodCode;
        }

        public void setNetValue(Double netValue) {
            this.netValue = netValue;
        }

        public void setNavDate(Integer navDate) {
            this.navDate = navDate;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutPriceJzjyInnerInput:(");
            buffer.append("prodtaNo:" + this.prodtaNo);
            buffer.append(",prodCode:" + this.prodCode);
            buffer.append(",netValue:" + this.netValue);
            buffer.append(",navDate:" + this.navDate);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.prodtaNo);
            builder.append(this.prodCode);
            builder.append(this.netValue);
            builder.append(this.navDate);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.PutPriceJzjyInnerInput) {
                InnerDfzqService.PutPriceJzjyInnerInput test = (InnerDfzqService.PutPriceJzjyInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.prodtaNo, test.prodtaNo);
                builder.append(this.prodCode, test.prodCode);
                builder.append(this.netValue, test.netValue);
                builder.append(this.navDate, test.navDate);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetPriceFromInformationCenterInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String prodCode = " ";
        private Integer navDate = 0;
        @SerializeDoubleDigit(
                digit = 8
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double netValue = 0.0D;
        @SerializeDoubleDigit(
                digit = 8
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double sevenIncomeRatio = 0.0D;
        @SerializeDoubleDigit(
                digit = 4
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double perMyriadIncome = 0.0D;

        public GetPriceFromInformationCenterInnerOutput() {
        }

        public String getProdCode() {
            if (this.prodCode == null) {
                return " ";
            } else {
                return this.prodCode.isEmpty() ? " " : this.prodCode;
            }
        }

        public Integer getNavDate() {
            return this.navDate != null ? this.navDate : 0;
        }

        public Double getNetValue() {
            return this.netValue != null ? this.netValue : 0.0D;
        }

        public Double getSevenIncomeRatio() {
            return this.sevenIncomeRatio != null ? this.sevenIncomeRatio : 0.0D;
        }

        public Double getPerMyriadIncome() {
            return this.perMyriadIncome != null ? this.perMyriadIncome : 0.0D;
        }

        public void setProdCode(String prodCode) {
            this.prodCode = prodCode;
        }

        public void setNavDate(Integer navDate) {
            this.navDate = navDate;
        }

        public void setNetValue(Double netValue) {
            this.netValue = netValue;
        }

        public void setSevenIncomeRatio(Double sevenIncomeRatio) {
            this.sevenIncomeRatio = sevenIncomeRatio;
        }

        public void setPerMyriadIncome(Double perMyriadIncome) {
            this.perMyriadIncome = perMyriadIncome;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetPriceFromInformationCenterInnerOutput:(");
            buffer.append("prodCode:" + this.prodCode);
            buffer.append(",navDate:" + this.navDate);
            buffer.append(",netValue:" + this.netValue);
            buffer.append(",sevenIncomeRatio:" + this.sevenIncomeRatio);
            buffer.append(",perMyriadIncome:" + this.perMyriadIncome);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.prodCode);
            builder.append(this.navDate);
            builder.append(this.netValue);
            builder.append(this.sevenIncomeRatio);
            builder.append(this.perMyriadIncome);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.GetPriceFromInformationCenterInnerOutput) {
                InnerDfzqService.GetPriceFromInformationCenterInnerOutput test = (InnerDfzqService.GetPriceFromInformationCenterInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.prodCode, test.prodCode);
                builder.append(this.navDate, test.navDate);
                builder.append(this.netValue, test.netValue);
                builder.append(this.sevenIncomeRatio, test.sevenIncomeRatio);
                builder.append(this.perMyriadIncome, test.perMyriadIncome);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetPriceFromInformationCenterInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String prodCode = " ";
        private Integer updateTime = 0;

        public GetPriceFromInformationCenterInnerInput() {
        }

        public String getProdCode() {
            if (this.prodCode == null) {
                return " ";
            } else {
                return this.prodCode.isEmpty() ? " " : this.prodCode;
            }
        }

        public Integer getUpdateTime() {
            return this.updateTime != null ? this.updateTime : 0;
        }

        public void setProdCode(String prodCode) {
            this.prodCode = prodCode;
        }

        public void setUpdateTime(Integer updateTime) {
            this.updateTime = updateTime;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetPriceFromInformationCenterInnerInput:(");
            buffer.append("prodCode:" + this.prodCode);
            buffer.append(",updateTime:" + this.updateTime);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.prodCode);
            builder.append(this.updateTime);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.GetPriceFromInformationCenterInnerInput) {
                InnerDfzqService.GetPriceFromInformationCenterInnerInput test = (InnerDfzqService.GetPriceFromInformationCenterInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.prodCode, test.prodCode);
                builder.append(this.updateTime, test.updateTime);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetBankReturnInfoInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String opRemark = " ";
        private String returnSerialNo = " ";
        private String fundAccount = " ";
        private String moneyType = " ";
        private String bankAccount = " ";
        private String transType = " ";
        private Integer currDate = 0;
        private Integer errorNo = 0;
        private String bankErrorInfo = " ";
        private String bankNo = " ";

        public GetBankReturnInfoInnerOutput() {
        }

        public String getOpRemark() {
            if (this.opRemark == null) {
                return " ";
            } else {
                return this.opRemark.isEmpty() ? " " : this.opRemark;
            }
        }

        public String getReturnSerialNo() {
            if (this.returnSerialNo == null) {
                return " ";
            } else {
                return this.returnSerialNo.isEmpty() ? " " : this.returnSerialNo;
            }
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getMoneyType() {
            if (this.moneyType == null) {
                return " ";
            } else {
                return this.moneyType.isEmpty() ? " " : this.moneyType;
            }
        }

        public String getBankAccount() {
            if (this.bankAccount == null) {
                return " ";
            } else {
                return this.bankAccount.isEmpty() ? " " : this.bankAccount;
            }
        }

        public String getTransType() {
            if (this.transType == null) {
                return " ";
            } else {
                return this.transType.isEmpty() ? " " : this.transType;
            }
        }

        public Integer getCurrDate() {
            return this.currDate != null ? this.currDate : 0;
        }

        public Integer getErrorNo() {
            return this.errorNo != null ? this.errorNo : 0;
        }

        public String getBankErrorInfo() {
            if (this.bankErrorInfo == null) {
                return " ";
            } else {
                return this.bankErrorInfo.isEmpty() ? " " : this.bankErrorInfo;
            }
        }

        public String getBankNo() {
            if (this.bankNo == null) {
                return " ";
            } else {
                return this.bankNo.isEmpty() ? " " : this.bankNo;
            }
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public void setReturnSerialNo(String returnSerialNo) {
            this.returnSerialNo = returnSerialNo;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setMoneyType(String moneyType) {
            this.moneyType = moneyType;
        }

        public void setBankAccount(String bankAccount) {
            this.bankAccount = bankAccount;
        }

        public void setTransType(String transType) {
            this.transType = transType;
        }

        public void setCurrDate(Integer currDate) {
            this.currDate = currDate;
        }

        public void setErrorNo(Integer errorNo) {
            this.errorNo = errorNo;
        }

        public void setBankErrorInfo(String bankErrorInfo) {
            this.bankErrorInfo = bankErrorInfo;
        }

        public void setBankNo(String bankNo) {
            this.bankNo = bankNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetBankReturnInfoInnerOutput:(");
            buffer.append("opRemark:" + this.opRemark);
            buffer.append(",returnSerialNo:" + this.returnSerialNo);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",moneyType:" + this.moneyType);
            buffer.append(",bankAccount:" + this.bankAccount);
            buffer.append(",transType:" + this.transType);
            buffer.append(",currDate:" + this.currDate);
            buffer.append(",errorNo:" + this.errorNo);
            buffer.append(",bankErrorInfo:" + this.bankErrorInfo);
            buffer.append(",bankNo:" + this.bankNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opRemark);
            builder.append(this.returnSerialNo);
            builder.append(this.fundAccount);
            builder.append(this.moneyType);
            builder.append(this.bankAccount);
            builder.append(this.transType);
            builder.append(this.currDate);
            builder.append(this.errorNo);
            builder.append(this.bankErrorInfo);
            builder.append(this.bankNo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.GetBankReturnInfoInnerOutput) {
                InnerDfzqService.GetBankReturnInfoInnerOutput test = (InnerDfzqService.GetBankReturnInfoInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opRemark, test.opRemark);
                builder.append(this.returnSerialNo, test.returnSerialNo);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.moneyType, test.moneyType);
                builder.append(this.bankAccount, test.bankAccount);
                builder.append(this.transType, test.transType);
                builder.append(this.currDate, test.currDate);
                builder.append(this.errorNo, test.errorNo);
                builder.append(this.bankErrorInfo, test.bankErrorInfo);
                builder.append(this.bankNo, test.bankNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetBankReturnInfoInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 16,
                charset = "utf-8"
        )
        private String returnSerialNo = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fundAccount = " ";
        @SinogramLength(
                min = 0,
                max = 6,
                charset = "utf-8"
        )
        private String bankNo = " ";
        @SinogramLength(
                min = 0,
                max = 3,
                charset = "utf-8"
        )
        private String moneyType = " ";
        @SinogramLength(
                min = 0,
                max = 2,
                charset = "utf-8"
        )
        private String transType = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character assetProp = ' ';

        public GetBankReturnInfoInnerInput() {
        }

        public String getReturnSerialNo() {
            if (this.returnSerialNo == null) {
                return " ";
            } else {
                return this.returnSerialNo.isEmpty() ? " " : this.returnSerialNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getBankNo() {
            if (this.bankNo == null) {
                return " ";
            } else {
                return this.bankNo.isEmpty() ? " " : this.bankNo;
            }
        }

        public String getMoneyType() {
            if (this.moneyType == null) {
                return " ";
            } else {
                return this.moneyType.isEmpty() ? " " : this.moneyType;
            }
        }

        public String getTransType() {
            if (this.transType == null) {
                return " ";
            } else {
                return this.transType.isEmpty() ? " " : this.transType;
            }
        }

        public Character getAssetProp() {
            return this.assetProp != null ? this.assetProp : ' ';
        }

        public void setReturnSerialNo(String returnSerialNo) {
            this.returnSerialNo = returnSerialNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setBankNo(String bankNo) {
            this.bankNo = bankNo;
        }

        public void setMoneyType(String moneyType) {
            this.moneyType = moneyType;
        }

        public void setTransType(String transType) {
            this.transType = transType;
        }

        public void setAssetProp(Character assetProp) {
            this.assetProp = assetProp;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetBankReturnInfoInnerInput:(");
            buffer.append("returnSerialNo:" + this.returnSerialNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",bankNo:" + this.bankNo);
            buffer.append(",moneyType:" + this.moneyType);
            buffer.append(",transType:" + this.transType);
            buffer.append(",assetProp:" + this.assetProp);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.returnSerialNo);
            builder.append(this.opStation);
            builder.append(this.operatorNo);
            builder.append(this.fundAccount);
            builder.append(this.bankNo);
            builder.append(this.moneyType);
            builder.append(this.transType);
            builder.append(this.assetProp);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.GetBankReturnInfoInnerInput) {
                InnerDfzqService.GetBankReturnInfoInnerInput test = (InnerDfzqService.GetBankReturnInfoInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.returnSerialNo, test.returnSerialNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.bankNo, test.bankNo);
                builder.append(this.moneyType, test.moneyType);
                builder.append(this.transType, test.transType);
                builder.append(this.assetProp, test.assetProp);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostProdVideoInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String businessSerialNoStr = " ";
        private Integer currDate = 0;
        private Integer currTime = 0;

        public PostProdVideoInnerOutput() {
        }

        public String getBusinessSerialNoStr() {
            if (this.businessSerialNoStr == null) {
                return " ";
            } else {
                return this.businessSerialNoStr.isEmpty() ? " " : this.businessSerialNoStr;
            }
        }

        public Integer getCurrDate() {
            return this.currDate != null ? this.currDate : 0;
        }

        public Integer getCurrTime() {
            return this.currTime != null ? this.currTime : 0;
        }

        public void setBusinessSerialNoStr(String businessSerialNoStr) {
            this.businessSerialNoStr = businessSerialNoStr;
        }

        public void setCurrDate(Integer currDate) {
            this.currDate = currDate;
        }

        public void setCurrTime(Integer currTime) {
            this.currTime = currTime;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostProdVideoInnerOutput:(");
            buffer.append("businessSerialNoStr:" + this.businessSerialNoStr);
            buffer.append(",currDate:" + this.currDate);
            buffer.append(",currTime:" + this.currTime);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.businessSerialNoStr);
            builder.append(this.currDate);
            builder.append(this.currTime);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.PostProdVideoInnerOutput) {
                InnerDfzqService.PostProdVideoInnerOutput test = (InnerDfzqService.PostProdVideoInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.businessSerialNoStr, test.businessSerialNoStr);
                builder.append(this.currDate, test.currDate);
                builder.append(this.currTime, test.currTime);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostProdVideoInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String fundAccount = " ";
        @SinogramLength(
                min = 1,
                max = 32,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String prodCode = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character operType = ' ';

        public PostProdVideoInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getProdCode() {
            if (this.prodCode == null) {
                return " ";
            } else {
                return this.prodCode.isEmpty() ? " " : this.prodCode;
            }
        }

        public Character getOperType() {
            return this.operType != null ? this.operType : ' ';
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setProdCode(String prodCode) {
            this.prodCode = prodCode;
        }

        public void setOperType(Character operType) {
            this.operType = operType;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostProdVideoInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",prodCode:" + this.prodCode);
            buffer.append(",operType:" + this.operType);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.fundAccount);
            builder.append(this.prodCode);
            builder.append(this.operType);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.PostProdVideoInnerInput) {
                InnerDfzqService.PostProdVideoInnerInput test = (InnerDfzqService.PostProdVideoInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.prodCode, test.prodCode);
                builder.append(this.operType, test.operType);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutProdholderFrozenInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer retCode = 0;
        private String retInfo = " ";

        public PutProdholderFrozenInnerOutput() {
        }

        public Integer getRetCode() {
            return this.retCode != null ? this.retCode : 0;
        }

        public String getRetInfo() {
            if (this.retInfo == null) {
                return " ";
            } else {
                return this.retInfo.isEmpty() ? " " : this.retInfo;
            }
        }

        public void setRetCode(Integer retCode) {
            this.retCode = retCode;
        }

        public void setRetInfo(String retInfo) {
            this.retInfo = retInfo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutProdholderFrozenInnerOutput:(");
            buffer.append("retCode:" + this.retCode);
            buffer.append(",retInfo:" + this.retInfo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.retCode);
            builder.append(this.retInfo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.PutProdholderFrozenInnerOutput) {
                InnerDfzqService.PutProdholderFrozenInnerOutput test = (InnerDfzqService.PutProdholderFrozenInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.retCode, test.retCode);
                builder.append(this.retInfo, test.retInfo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutProdholderFrozenInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String prodAccount = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character payKind = ' ';
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character prodholderStatus = ' ';
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character acctOperType = ' ';

        public PutProdholderFrozenInnerInput() {
        }

        public String getProdAccount() {
            if (this.prodAccount == null) {
                return " ";
            } else {
                return this.prodAccount.isEmpty() ? " " : this.prodAccount;
            }
        }

        public Character getPayKind() {
            return this.payKind != null ? this.payKind : ' ';
        }

        public Character getProdholderStatus() {
            return this.prodholderStatus != null ? this.prodholderStatus : ' ';
        }

        public Character getAcctOperType() {
            return this.acctOperType != null ? this.acctOperType : ' ';
        }

        public void setProdAccount(String prodAccount) {
            this.prodAccount = prodAccount;
        }

        public void setPayKind(Character payKind) {
            this.payKind = payKind;
        }

        public void setProdholderStatus(Character prodholderStatus) {
            this.prodholderStatus = prodholderStatus;
        }

        public void setAcctOperType(Character acctOperType) {
            this.acctOperType = acctOperType;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutProdholderFrozenInnerInput:(");
            buffer.append("prodAccount:" + this.prodAccount);
            buffer.append(",payKind:" + this.payKind);
            buffer.append(",prodholderStatus:" + this.prodholderStatus);
            buffer.append(",acctOperType:" + this.acctOperType);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.prodAccount);
            builder.append(this.payKind);
            builder.append(this.prodholderStatus);
            builder.append(this.acctOperType);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.PutProdholderFrozenInnerInput) {
                InnerDfzqService.PutProdholderFrozenInnerInput test = (InnerDfzqService.PutProdholderFrozenInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.prodAccount, test.prodAccount);
                builder.append(this.payKind, test.payKind);
                builder.append(this.prodholderStatus, test.prodholderStatus);
                builder.append(this.acctOperType, test.acctOperType);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetProdholderCancelInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer noticeNo = 0;
        private String noticeInfo = " ";
        private String checkId = " ";

        public GetProdholderCancelInnerOutput() {
        }

        public Integer getNoticeNo() {
            return this.noticeNo != null ? this.noticeNo : 0;
        }

        public String getNoticeInfo() {
            if (this.noticeInfo == null) {
                return " ";
            } else {
                return this.noticeInfo.isEmpty() ? " " : this.noticeInfo;
            }
        }

        public String getCheckId() {
            if (this.checkId == null) {
                return " ";
            } else {
                return this.checkId.isEmpty() ? " " : this.checkId;
            }
        }

        public void setNoticeNo(Integer noticeNo) {
            this.noticeNo = noticeNo;
        }

        public void setNoticeInfo(String noticeInfo) {
            this.noticeInfo = noticeInfo;
        }

        public void setCheckId(String checkId) {
            this.checkId = checkId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetProdholderCancelInnerOutput:(");
            buffer.append("noticeNo:" + this.noticeNo);
            buffer.append(",noticeInfo:" + this.noticeInfo);
            buffer.append(",checkId:" + this.checkId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.noticeNo);
            builder.append(this.noticeInfo);
            builder.append(this.checkId);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.GetProdholderCancelInnerOutput) {
                InnerDfzqService.GetProdholderCancelInnerOutput test = (InnerDfzqService.GetProdholderCancelInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.noticeNo, test.noticeNo);
                builder.append(this.noticeInfo, test.noticeInfo);
                builder.append(this.checkId, test.checkId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetProdholderCancelInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String fundAccount;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String prodAccount;
        @SinogramLength(
                min = 1,
                max = 24,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String prodtaNo;

        public GetProdholderCancelInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getClientId() {
            return this.clientId;
        }

        public String getFundAccount() {
            return this.fundAccount;
        }

        public String getProdAccount() {
            return this.prodAccount;
        }

        public String getProdtaNo() {
            return this.prodtaNo;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setProdAccount(String prodAccount) {
            this.prodAccount = prodAccount;
        }

        public void setProdtaNo(String prodtaNo) {
            this.prodtaNo = prodtaNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetProdholderCancelInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",prodAccount:" + this.prodAccount);
            buffer.append(",prodtaNo:" + this.prodtaNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.clientId);
            builder.append(this.fundAccount);
            builder.append(this.prodAccount);
            builder.append(this.prodtaNo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.GetProdholderCancelInnerInput) {
                InnerDfzqService.GetProdholderCancelInnerInput test = (InnerDfzqService.GetProdholderCancelInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.clientId, test.clientId);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.prodAccount, test.prodAccount);
                builder.append(this.prodtaNo, test.prodtaNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetProdholderTransCancelInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer noticeNo = 0;
        private String noticeInfo = " ";
        private String checkId = " ";

        public GetProdholderTransCancelInnerOutput() {
        }

        public Integer getNoticeNo() {
            return this.noticeNo != null ? this.noticeNo : 0;
        }

        public String getNoticeInfo() {
            if (this.noticeInfo == null) {
                return " ";
            } else {
                return this.noticeInfo.isEmpty() ? " " : this.noticeInfo;
            }
        }

        public String getCheckId() {
            if (this.checkId == null) {
                return " ";
            } else {
                return this.checkId.isEmpty() ? " " : this.checkId;
            }
        }

        public void setNoticeNo(Integer noticeNo) {
            this.noticeNo = noticeNo;
        }

        public void setNoticeInfo(String noticeInfo) {
            this.noticeInfo = noticeInfo;
        }

        public void setCheckId(String checkId) {
            this.checkId = checkId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetProdholderTransCancelInnerOutput:(");
            buffer.append("noticeNo:" + this.noticeNo);
            buffer.append(",noticeInfo:" + this.noticeInfo);
            buffer.append(",checkId:" + this.checkId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.noticeNo);
            builder.append(this.noticeInfo);
            builder.append(this.checkId);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.GetProdholderTransCancelInnerOutput) {
                InnerDfzqService.GetProdholderTransCancelInnerOutput test = (InnerDfzqService.GetProdholderTransCancelInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.noticeNo, test.noticeNo);
                builder.append(this.noticeInfo, test.noticeInfo);
                builder.append(this.checkId, test.checkId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetProdholderTransCancelInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String fundAccount;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String prodAccount;
        @SinogramLength(
                min = 1,
                max = 24,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String prodtaNo;
        @SinogramLength(
                min = 1,
                max = 32,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String transAccount;

        public GetProdholderTransCancelInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getClientId() {
            return this.clientId;
        }

        public String getFundAccount() {
            return this.fundAccount;
        }

        public String getProdAccount() {
            return this.prodAccount;
        }

        public String getProdtaNo() {
            return this.prodtaNo;
        }

        public String getTransAccount() {
            return this.transAccount;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setProdAccount(String prodAccount) {
            this.prodAccount = prodAccount;
        }

        public void setProdtaNo(String prodtaNo) {
            this.prodtaNo = prodtaNo;
        }

        public void setTransAccount(String transAccount) {
            this.transAccount = transAccount;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetProdholderTransCancelInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",prodAccount:" + this.prodAccount);
            buffer.append(",prodtaNo:" + this.prodtaNo);
            buffer.append(",transAccount:" + this.transAccount);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.clientId);
            builder.append(this.fundAccount);
            builder.append(this.prodAccount);
            builder.append(this.prodtaNo);
            builder.append(this.transAccount);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.GetProdholderTransCancelInnerInput) {
                InnerDfzqService.GetProdholderTransCancelInnerInput test = (InnerDfzqService.GetProdholderTransCancelInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.clientId, test.clientId);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.prodAccount, test.prodAccount);
                builder.append(this.prodtaNo, test.prodtaNo);
                builder.append(this.transAccount, test.transAccount);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutFundaccountInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String fundAccount;

        public PutFundaccountInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getClientId() {
            return this.clientId;
        }

        public String getFundAccount() {
            return this.fundAccount;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutFundaccountInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.clientId);
            builder.append(this.fundAccount);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.PutFundaccountInnerInput) {
                InnerDfzqService.PutFundaccountInnerInput test = (InnerDfzqService.PutFundaccountInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.clientId, test.clientId);
                builder.append(this.fundAccount, test.fundAccount);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutProdholderSynModInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer errorNo = 0;
        private String errorInfo = " ";

        public PutProdholderSynModInnerOutput() {
        }

        public Integer getErrorNo() {
            return this.errorNo != null ? this.errorNo : 0;
        }

        public String getErrorInfo() {
            if (this.errorInfo == null) {
                return " ";
            } else {
                return this.errorInfo.isEmpty() ? " " : this.errorInfo;
            }
        }

        public void setErrorNo(Integer errorNo) {
            this.errorNo = errorNo;
        }

        public void setErrorInfo(String errorInfo) {
            this.errorInfo = errorInfo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutProdholderSynModInnerOutput:(");
            buffer.append("errorNo:" + this.errorNo);
            buffer.append(",errorInfo:" + this.errorInfo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.errorNo);
            builder.append(this.errorInfo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.PutProdholderSynModInnerOutput) {
                InnerDfzqService.PutProdholderSynModInnerOutput test = (InnerDfzqService.PutProdholderSynModInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.errorNo, test.errorNo);
                builder.append(this.errorInfo, test.errorInfo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutProdholderSynModInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 1,
                max = 24,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String allotNo = " ";
        @NotNull(
                message = "不能为空"
        )
        private Integer riskEndDate = 0;
        @NotNull(
                message = "不能为空"
        )
        private Integer corpRiskLevel = 0;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character acctOperType = ' ';
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String prodAccount = " ";
        @SinogramLength(
                min = 1,
                max = 32,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String transAccount = " ";
        @NotNull(
                message = "不能为空"
        )
        private Integer entrustDate = 0;
        @NotNull(
                message = "不能为空"
        )
        private Integer entrustTime = 0;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character entrustStatus = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character organFlag = ' ';
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character idKind = ' ';
        @SinogramLength(
                min = 1,
                max = 40,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String idNo = " ";
        private Integer idEnddate = 0;
        @SinogramLength(
                min = 0,
                max = 180,
                charset = "utf-8"
        )
        private String instreprName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character instreprIdKind = ' ';
        @SinogramLength(
                min = 0,
                max = 40,
                charset = "utf-8"
        )
        private String instreprIdNo = " ";
        private Integer instreprIdEnddate = 0;
        @SinogramLength(
                min = 0,
                max = 180,
                charset = "utf-8"
        )
        private String contactName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character contractIdKind = ' ';
        @SinogramLength(
                min = 0,
                max = 40,
                charset = "utf-8"
        )
        private String contactIdNo = " ";
        private Integer contactIdEnddate = 0;
        @SinogramLength(
                min = 0,
                max = 3,
                charset = "utf-8"
        )
        private String nationality = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String addrProvince = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String addrCity = " ";
        @SinogramLength(
                min = 0,
                max = 16,
                charset = "utf-8"
        )
        private String countyName = " ";
        @SinogramLength(
                min = 0,
                max = 6,
                charset = "utf-8"
        )
        private String postcode = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character sex = ' ';
        private Integer birthday = 0;
        @SinogramLength(
                min = 0,
                max = 2,
                charset = "utf-8"
        )
        private String professionCode = " ";
        @SinogramLength(
                min = 0,
                max = 180,
                charset = "utf-8"
        )
        private String address = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String phone = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String fax = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String mobile = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String email = " ";
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String remark = " ";
        private String signData = " ";
        @SinogramLength(
                min = 1,
                max = 48,
                charset = "utf-8"
        )
        private String stockName = " ";
        @SinogramLength(
                min = 0,
                max = 60,
                charset = "utf-8"
        )
        private String shortName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character payKind = ' ';

        public PutProdholderSynModInnerInput() {
        }

        public String getAllotNo() {
            if (this.allotNo == null) {
                return " ";
            } else {
                return this.allotNo.isEmpty() ? " " : this.allotNo;
            }
        }

        public Integer getRiskEndDate() {
            return this.riskEndDate != null ? this.riskEndDate : 0;
        }

        public Integer getCorpRiskLevel() {
            return this.corpRiskLevel != null ? this.corpRiskLevel : 0;
        }

        public Character getAcctOperType() {
            return this.acctOperType != null ? this.acctOperType : ' ';
        }

        public String getProdAccount() {
            if (this.prodAccount == null) {
                return " ";
            } else {
                return this.prodAccount.isEmpty() ? " " : this.prodAccount;
            }
        }

        public String getTransAccount() {
            if (this.transAccount == null) {
                return " ";
            } else {
                return this.transAccount.isEmpty() ? " " : this.transAccount;
            }
        }

        public Integer getEntrustDate() {
            return this.entrustDate != null ? this.entrustDate : 0;
        }

        public Integer getEntrustTime() {
            return this.entrustTime != null ? this.entrustTime : 0;
        }

        public Character getEntrustStatus() {
            return this.entrustStatus != null ? this.entrustStatus : ' ';
        }

        public Character getOrganFlag() {
            return this.organFlag != null ? this.organFlag : ' ';
        }

        public Character getIdKind() {
            return this.idKind != null ? this.idKind : ' ';
        }

        public String getIdNo() {
            if (this.idNo == null) {
                return " ";
            } else {
                return this.idNo.isEmpty() ? " " : this.idNo;
            }
        }

        public Integer getIdEnddate() {
            return this.idEnddate != null ? this.idEnddate : 0;
        }

        public String getInstreprName() {
            if (this.instreprName == null) {
                return " ";
            } else {
                return this.instreprName.isEmpty() ? " " : this.instreprName;
            }
        }

        public Character getInstreprIdKind() {
            return this.instreprIdKind != null ? this.instreprIdKind : ' ';
        }

        public String getInstreprIdNo() {
            if (this.instreprIdNo == null) {
                return " ";
            } else {
                return this.instreprIdNo.isEmpty() ? " " : this.instreprIdNo;
            }
        }

        public Integer getInstreprIdEnddate() {
            return this.instreprIdEnddate != null ? this.instreprIdEnddate : 0;
        }

        public String getContactName() {
            if (this.contactName == null) {
                return " ";
            } else {
                return this.contactName.isEmpty() ? " " : this.contactName;
            }
        }

        public Character getContractIdKind() {
            return this.contractIdKind != null ? this.contractIdKind : ' ';
        }

        public String getContactIdNo() {
            if (this.contactIdNo == null) {
                return " ";
            } else {
                return this.contactIdNo.isEmpty() ? " " : this.contactIdNo;
            }
        }

        public Integer getContactIdEnddate() {
            return this.contactIdEnddate != null ? this.contactIdEnddate : 0;
        }

        public String getNationality() {
            if (this.nationality == null) {
                return " ";
            } else {
                return this.nationality.isEmpty() ? " " : this.nationality;
            }
        }

        public String getAddrProvince() {
            if (this.addrProvince == null) {
                return " ";
            } else {
                return this.addrProvince.isEmpty() ? " " : this.addrProvince;
            }
        }

        public String getAddrCity() {
            if (this.addrCity == null) {
                return " ";
            } else {
                return this.addrCity.isEmpty() ? " " : this.addrCity;
            }
        }

        public String getCountyName() {
            if (this.countyName == null) {
                return " ";
            } else {
                return this.countyName.isEmpty() ? " " : this.countyName;
            }
        }

        public String getPostcode() {
            if (this.postcode == null) {
                return " ";
            } else {
                return this.postcode.isEmpty() ? " " : this.postcode;
            }
        }

        public Character getSex() {
            return this.sex != null ? this.sex : ' ';
        }

        public Integer getBirthday() {
            return this.birthday != null ? this.birthday : 0;
        }

        public String getProfessionCode() {
            if (this.professionCode == null) {
                return " ";
            } else {
                return this.professionCode.isEmpty() ? " " : this.professionCode;
            }
        }

        public String getAddress() {
            if (this.address == null) {
                return " ";
            } else {
                return this.address.isEmpty() ? " " : this.address;
            }
        }

        public String getPhone() {
            if (this.phone == null) {
                return " ";
            } else {
                return this.phone.isEmpty() ? " " : this.phone;
            }
        }

        public String getFax() {
            if (this.fax == null) {
                return " ";
            } else {
                return this.fax.isEmpty() ? " " : this.fax;
            }
        }

        public String getMobile() {
            if (this.mobile == null) {
                return " ";
            } else {
                return this.mobile.isEmpty() ? " " : this.mobile;
            }
        }

        public String getEmail() {
            if (this.email == null) {
                return " ";
            } else {
                return this.email.isEmpty() ? " " : this.email;
            }
        }

        public String getRemark() {
            if (this.remark == null) {
                return " ";
            } else {
                return this.remark.isEmpty() ? " " : this.remark;
            }
        }

        public String getSignData() {
            if (this.signData == null) {
                return " ";
            } else {
                return this.signData.isEmpty() ? " " : this.signData;
            }
        }

        public String getStockName() {
            if (this.stockName == null) {
                return " ";
            } else {
                return this.stockName.isEmpty() ? " " : this.stockName;
            }
        }

        public String getShortName() {
            if (this.shortName == null) {
                return " ";
            } else {
                return this.shortName.isEmpty() ? " " : this.shortName;
            }
        }

        public Character getPayKind() {
            return this.payKind != null ? this.payKind : ' ';
        }

        public void setAllotNo(String allotNo) {
            this.allotNo = allotNo;
        }

        public void setRiskEndDate(Integer riskEndDate) {
            this.riskEndDate = riskEndDate;
        }

        public void setCorpRiskLevel(Integer corpRiskLevel) {
            this.corpRiskLevel = corpRiskLevel;
        }

        public void setAcctOperType(Character acctOperType) {
            this.acctOperType = acctOperType;
        }

        public void setProdAccount(String prodAccount) {
            this.prodAccount = prodAccount;
        }

        public void setTransAccount(String transAccount) {
            this.transAccount = transAccount;
        }

        public void setEntrustDate(Integer entrustDate) {
            this.entrustDate = entrustDate;
        }

        public void setEntrustTime(Integer entrustTime) {
            this.entrustTime = entrustTime;
        }

        public void setEntrustStatus(Character entrustStatus) {
            this.entrustStatus = entrustStatus;
        }

        public void setOrganFlag(Character organFlag) {
            this.organFlag = organFlag;
        }

        public void setIdKind(Character idKind) {
            this.idKind = idKind;
        }

        public void setIdNo(String idNo) {
            this.idNo = idNo;
        }

        public void setIdEnddate(Integer idEnddate) {
            this.idEnddate = idEnddate;
        }

        public void setInstreprName(String instreprName) {
            this.instreprName = instreprName;
        }

        public void setInstreprIdKind(Character instreprIdKind) {
            this.instreprIdKind = instreprIdKind;
        }

        public void setInstreprIdNo(String instreprIdNo) {
            this.instreprIdNo = instreprIdNo;
        }

        public void setInstreprIdEnddate(Integer instreprIdEnddate) {
            this.instreprIdEnddate = instreprIdEnddate;
        }

        public void setContactName(String contactName) {
            this.contactName = contactName;
        }

        public void setContractIdKind(Character contractIdKind) {
            this.contractIdKind = contractIdKind;
        }

        public void setContactIdNo(String contactIdNo) {
            this.contactIdNo = contactIdNo;
        }

        public void setContactIdEnddate(Integer contactIdEnddate) {
            this.contactIdEnddate = contactIdEnddate;
        }

        public void setNationality(String nationality) {
            this.nationality = nationality;
        }

        public void setAddrProvince(String addrProvince) {
            this.addrProvince = addrProvince;
        }

        public void setAddrCity(String addrCity) {
            this.addrCity = addrCity;
        }

        public void setCountyName(String countyName) {
            this.countyName = countyName;
        }

        public void setPostcode(String postcode) {
            this.postcode = postcode;
        }

        public void setSex(Character sex) {
            this.sex = sex;
        }

        public void setBirthday(Integer birthday) {
            this.birthday = birthday;
        }

        public void setProfessionCode(String professionCode) {
            this.professionCode = professionCode;
        }

        public void setAddress(String address) {
            this.address = address;
        }

        public void setPhone(String phone) {
            this.phone = phone;
        }

        public void setFax(String fax) {
            this.fax = fax;
        }

        public void setMobile(String mobile) {
            this.mobile = mobile;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public void setSignData(String signData) {
            this.signData = signData;
        }

        public void setStockName(String stockName) {
            this.stockName = stockName;
        }

        public void setShortName(String shortName) {
            this.shortName = shortName;
        }

        public void setPayKind(Character payKind) {
            this.payKind = payKind;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutProdholderSynModInnerInput:(");
            buffer.append("allotNo:" + this.allotNo);
            buffer.append(",riskEndDate:" + this.riskEndDate);
            buffer.append(",corpRiskLevel:" + this.corpRiskLevel);
            buffer.append(",acctOperType:" + this.acctOperType);
            buffer.append(",prodAccount:" + this.prodAccount);
            buffer.append(",transAccount:" + this.transAccount);
            buffer.append(",entrustDate:" + this.entrustDate);
            buffer.append(",entrustTime:" + this.entrustTime);
            buffer.append(",entrustStatus:" + this.entrustStatus);
            buffer.append(",organFlag:" + this.organFlag);
            buffer.append(",idKind:" + this.idKind);
            buffer.append(",idNo:" + this.idNo);
            buffer.append(",idEnddate:" + this.idEnddate);
            buffer.append(",instreprName:" + this.instreprName);
            buffer.append(",instreprIdKind:" + this.instreprIdKind);
            buffer.append(",instreprIdNo:" + this.instreprIdNo);
            buffer.append(",instreprIdEnddate:" + this.instreprIdEnddate);
            buffer.append(",contactName:" + this.contactName);
            buffer.append(",contractIdKind:" + this.contractIdKind);
            buffer.append(",contactIdNo:" + this.contactIdNo);
            buffer.append(",contactIdEnddate:" + this.contactIdEnddate);
            buffer.append(",nationality:" + this.nationality);
            buffer.append(",addrProvince:" + this.addrProvince);
            buffer.append(",addrCity:" + this.addrCity);
            buffer.append(",countyName:" + this.countyName);
            buffer.append(",postcode:" + this.postcode);
            buffer.append(",sex:" + this.sex);
            buffer.append(",birthday:" + this.birthday);
            buffer.append(",professionCode:" + this.professionCode);
            buffer.append(",address:" + this.address);
            buffer.append(",phone:" + this.phone);
            buffer.append(",fax:" + this.fax);
            buffer.append(",mobile:" + this.mobile);
            buffer.append(",email:" + this.email);
            buffer.append(",remark:" + this.remark);
            buffer.append(",signData:" + this.signData);
            buffer.append(",stockName:" + this.stockName);
            buffer.append(",shortName:" + this.shortName);
            buffer.append(",payKind:" + this.payKind);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.allotNo);
            builder.append(this.riskEndDate);
            builder.append(this.corpRiskLevel);
            builder.append(this.acctOperType);
            builder.append(this.prodAccount);
            builder.append(this.transAccount);
            builder.append(this.entrustDate);
            builder.append(this.entrustTime);
            builder.append(this.entrustStatus);
            builder.append(this.organFlag);
            builder.append(this.idKind);
            builder.append(this.idNo);
            builder.append(this.idEnddate);
            builder.append(this.instreprName);
            builder.append(this.instreprIdKind);
            builder.append(this.instreprIdNo);
            builder.append(this.instreprIdEnddate);
            builder.append(this.contactName);
            builder.append(this.contractIdKind);
            builder.append(this.contactIdNo);
            builder.append(this.contactIdEnddate);
            builder.append(this.nationality);
            builder.append(this.addrProvince);
            builder.append(this.addrCity);
            builder.append(this.countyName);
            builder.append(this.postcode);
            builder.append(this.sex);
            builder.append(this.birthday);
            builder.append(this.professionCode);
            builder.append(this.address);
            builder.append(this.phone);
            builder.append(this.fax);
            builder.append(this.mobile);
            builder.append(this.email);
            builder.append(this.remark);
            builder.append(this.signData);
            builder.append(this.stockName);
            builder.append(this.shortName);
            builder.append(this.payKind);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.PutProdholderSynModInnerInput) {
                InnerDfzqService.PutProdholderSynModInnerInput test = (InnerDfzqService.PutProdholderSynModInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.allotNo, test.allotNo);
                builder.append(this.riskEndDate, test.riskEndDate);
                builder.append(this.corpRiskLevel, test.corpRiskLevel);
                builder.append(this.acctOperType, test.acctOperType);
                builder.append(this.prodAccount, test.prodAccount);
                builder.append(this.transAccount, test.transAccount);
                builder.append(this.entrustDate, test.entrustDate);
                builder.append(this.entrustTime, test.entrustTime);
                builder.append(this.entrustStatus, test.entrustStatus);
                builder.append(this.organFlag, test.organFlag);
                builder.append(this.idKind, test.idKind);
                builder.append(this.idNo, test.idNo);
                builder.append(this.idEnddate, test.idEnddate);
                builder.append(this.instreprName, test.instreprName);
                builder.append(this.instreprIdKind, test.instreprIdKind);
                builder.append(this.instreprIdNo, test.instreprIdNo);
                builder.append(this.instreprIdEnddate, test.instreprIdEnddate);
                builder.append(this.contactName, test.contactName);
                builder.append(this.contractIdKind, test.contractIdKind);
                builder.append(this.contactIdNo, test.contactIdNo);
                builder.append(this.contactIdEnddate, test.contactIdEnddate);
                builder.append(this.nationality, test.nationality);
                builder.append(this.addrProvince, test.addrProvince);
                builder.append(this.addrCity, test.addrCity);
                builder.append(this.countyName, test.countyName);
                builder.append(this.postcode, test.postcode);
                builder.append(this.sex, test.sex);
                builder.append(this.birthday, test.birthday);
                builder.append(this.professionCode, test.professionCode);
                builder.append(this.address, test.address);
                builder.append(this.phone, test.phone);
                builder.append(this.fax, test.fax);
                builder.append(this.mobile, test.mobile);
                builder.append(this.email, test.email);
                builder.append(this.remark, test.remark);
                builder.append(this.signData, test.signData);
                builder.append(this.stockName, test.stockName);
                builder.append(this.shortName, test.shortName);
                builder.append(this.payKind, test.payKind);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetFundInfoInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String fundAccount = " ";
        private String moneyType = " ";
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double currentBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double enableBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double fetchCash = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double frozenBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double businessFrozenBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double businessUnfrozenBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double integralBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double fineIntegral = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double interest = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double fineInterest = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double foregiftBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double mortgageBalance = 0.0D;
        private String opRemark = " ";

        public GetFundInfoInnerOutput() {
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getMoneyType() {
            if (this.moneyType == null) {
                return " ";
            } else {
                return this.moneyType.isEmpty() ? " " : this.moneyType;
            }
        }

        public Double getCurrentBalance() {
            return this.currentBalance != null ? this.currentBalance : 0.0D;
        }

        public Double getEnableBalance() {
            return this.enableBalance != null ? this.enableBalance : 0.0D;
        }

        public Double getFetchCash() {
            return this.fetchCash != null ? this.fetchCash : 0.0D;
        }

        public Double getFrozenBalance() {
            return this.frozenBalance != null ? this.frozenBalance : 0.0D;
        }

        public Double getBusinessFrozenBalance() {
            return this.businessFrozenBalance != null ? this.businessFrozenBalance : 0.0D;
        }

        public Double getBusinessUnfrozenBalance() {
            return this.businessUnfrozenBalance != null ? this.businessUnfrozenBalance : 0.0D;
        }

        public Double getIntegralBalance() {
            return this.integralBalance != null ? this.integralBalance : 0.0D;
        }

        public Double getFineIntegral() {
            return this.fineIntegral != null ? this.fineIntegral : 0.0D;
        }

        public Double getInterest() {
            return this.interest != null ? this.interest : 0.0D;
        }

        public Double getFineInterest() {
            return this.fineInterest != null ? this.fineInterest : 0.0D;
        }

        public Double getForegiftBalance() {
            return this.foregiftBalance != null ? this.foregiftBalance : 0.0D;
        }

        public Double getMortgageBalance() {
            return this.mortgageBalance != null ? this.mortgageBalance : 0.0D;
        }

        public String getOpRemark() {
            if (this.opRemark == null) {
                return " ";
            } else {
                return this.opRemark.isEmpty() ? " " : this.opRemark;
            }
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setMoneyType(String moneyType) {
            this.moneyType = moneyType;
        }

        public void setCurrentBalance(Double currentBalance) {
            this.currentBalance = currentBalance;
        }

        public void setEnableBalance(Double enableBalance) {
            this.enableBalance = enableBalance;
        }

        public void setFetchCash(Double fetchCash) {
            this.fetchCash = fetchCash;
        }

        public void setFrozenBalance(Double frozenBalance) {
            this.frozenBalance = frozenBalance;
        }

        public void setBusinessFrozenBalance(Double businessFrozenBalance) {
            this.businessFrozenBalance = businessFrozenBalance;
        }

        public void setBusinessUnfrozenBalance(Double businessUnfrozenBalance) {
            this.businessUnfrozenBalance = businessUnfrozenBalance;
        }

        public void setIntegralBalance(Double integralBalance) {
            this.integralBalance = integralBalance;
        }

        public void setFineIntegral(Double fineIntegral) {
            this.fineIntegral = fineIntegral;
        }

        public void setInterest(Double interest) {
            this.interest = interest;
        }

        public void setFineInterest(Double fineInterest) {
            this.fineInterest = fineInterest;
        }

        public void setForegiftBalance(Double foregiftBalance) {
            this.foregiftBalance = foregiftBalance;
        }

        public void setMortgageBalance(Double mortgageBalance) {
            this.mortgageBalance = mortgageBalance;
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetFundInfoInnerOutput:(");
            buffer.append("fundAccount:" + this.fundAccount);
            buffer.append(",moneyType:" + this.moneyType);
            buffer.append(",currentBalance:" + this.currentBalance);
            buffer.append(",enableBalance:" + this.enableBalance);
            buffer.append(",fetchCash:" + this.fetchCash);
            buffer.append(",frozenBalance:" + this.frozenBalance);
            buffer.append(",businessFrozenBalance:" + this.businessFrozenBalance);
            buffer.append(",businessUnfrozenBalance:" + this.businessUnfrozenBalance);
            buffer.append(",integralBalance:" + this.integralBalance);
            buffer.append(",fineIntegral:" + this.fineIntegral);
            buffer.append(",interest:" + this.interest);
            buffer.append(",fineInterest:" + this.fineInterest);
            buffer.append(",foregiftBalance:" + this.foregiftBalance);
            buffer.append(",mortgageBalance:" + this.mortgageBalance);
            buffer.append(",opRemark:" + this.opRemark);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.fundAccount);
            builder.append(this.moneyType);
            builder.append(this.currentBalance);
            builder.append(this.enableBalance);
            builder.append(this.fetchCash);
            builder.append(this.frozenBalance);
            builder.append(this.businessFrozenBalance);
            builder.append(this.businessUnfrozenBalance);
            builder.append(this.integralBalance);
            builder.append(this.fineIntegral);
            builder.append(this.interest);
            builder.append(this.fineInterest);
            builder.append(this.foregiftBalance);
            builder.append(this.mortgageBalance);
            builder.append(this.opRemark);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.GetFundInfoInnerOutput) {
                InnerDfzqService.GetFundInfoInnerOutput test = (InnerDfzqService.GetFundInfoInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.moneyType, test.moneyType);
                builder.append(this.currentBalance, test.currentBalance);
                builder.append(this.enableBalance, test.enableBalance);
                builder.append(this.fetchCash, test.fetchCash);
                builder.append(this.frozenBalance, test.frozenBalance);
                builder.append(this.businessFrozenBalance, test.businessFrozenBalance);
                builder.append(this.businessUnfrozenBalance, test.businessUnfrozenBalance);
                builder.append(this.integralBalance, test.integralBalance);
                builder.append(this.fineIntegral, test.fineIntegral);
                builder.append(this.interest, test.interest);
                builder.append(this.fineInterest, test.fineInterest);
                builder.append(this.foregiftBalance, test.foregiftBalance);
                builder.append(this.mortgageBalance, test.mortgageBalance);
                builder.append(this.opRemark, test.opRemark);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetFundInfoInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        private Integer branchNo = 0;
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String auditOperatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        private String fundAccount = " ";
        @SinogramLength(
                min = 1,
                max = 3,
                charset = "utf-8"
        )
        private String moneyType = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character assetProp = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character organFlag = ' ';

        public GetFundInfoInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getAuditOperatorNo() {
            if (this.auditOperatorNo == null) {
                return " ";
            } else {
                return this.auditOperatorNo.isEmpty() ? " " : this.auditOperatorNo;
            }
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getMoneyType() {
            if (this.moneyType == null) {
                return " ";
            } else {
                return this.moneyType.isEmpty() ? " " : this.moneyType;
            }
        }

        public Character getAssetProp() {
            return this.assetProp != null ? this.assetProp : ' ';
        }

        public Character getOrganFlag() {
            return this.organFlag != null ? this.organFlag : ' ';
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setAuditOperatorNo(String auditOperatorNo) {
            this.auditOperatorNo = auditOperatorNo;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setMoneyType(String moneyType) {
            this.moneyType = moneyType;
        }

        public void setAssetProp(Character assetProp) {
            this.assetProp = assetProp;
        }

        public void setOrganFlag(Character organFlag) {
            this.organFlag = organFlag;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetFundInfoInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",auditOperatorNo:" + this.auditOperatorNo);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",moneyType:" + this.moneyType);
            buffer.append(",assetProp:" + this.assetProp);
            buffer.append(",organFlag:" + this.organFlag);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.branchNo);
            builder.append(this.opStation);
            builder.append(this.operatorNo);
            builder.append(this.auditOperatorNo);
            builder.append(this.fundAccount);
            builder.append(this.moneyType);
            builder.append(this.assetProp);
            builder.append(this.organFlag);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.GetFundInfoInnerInput) {
                InnerDfzqService.GetFundInfoInnerInput test = (InnerDfzqService.GetFundInfoInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.auditOperatorNo, test.auditOperatorNo);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.moneyType, test.moneyType);
                builder.append(this.assetProp, test.assetProp);
                builder.append(this.organFlag, test.organFlag);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class DeleteProdholderAcctInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer retCode = 0;
        private String retInfo = " ";

        public DeleteProdholderAcctInnerOutput() {
        }

        public Integer getRetCode() {
            return this.retCode != null ? this.retCode : 0;
        }

        public String getRetInfo() {
            if (this.retInfo == null) {
                return " ";
            } else {
                return this.retInfo.isEmpty() ? " " : this.retInfo;
            }
        }

        public void setRetCode(Integer retCode) {
            this.retCode = retCode;
        }

        public void setRetInfo(String retInfo) {
            this.retInfo = retInfo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("DeleteProdholderAcctInnerOutput:(");
            buffer.append("retCode:" + this.retCode);
            buffer.append(",retInfo:" + this.retInfo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.retCode);
            builder.append(this.retInfo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.DeleteProdholderAcctInnerOutput) {
                InnerDfzqService.DeleteProdholderAcctInnerOutput test = (InnerDfzqService.DeleteProdholderAcctInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.retCode, test.retCode);
                builder.append(this.retInfo, test.retInfo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class DeleteProdholderAcctInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @NotNull(
                message = "不能为空"
        )
        private Integer entrustDate = 0;
        @NotNull(
                message = "不能为空"
        )
        private Integer entrustTime = 0;
        @SinogramLength(
                min = 1,
                max = 24,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String allotNo = " ";
        @SinogramLength(
                min = 1,
                max = 10,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String agencyNo = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character entrustStatus = ' ';
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String prodAccount = " ";
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String remark = " ";

        public DeleteProdholderAcctInnerInput() {
        }

        public Integer getEntrustDate() {
            return this.entrustDate != null ? this.entrustDate : 0;
        }

        public Integer getEntrustTime() {
            return this.entrustTime != null ? this.entrustTime : 0;
        }

        public String getAllotNo() {
            if (this.allotNo == null) {
                return " ";
            } else {
                return this.allotNo.isEmpty() ? " " : this.allotNo;
            }
        }

        public String getAgencyNo() {
            if (this.agencyNo == null) {
                return " ";
            } else {
                return this.agencyNo.isEmpty() ? " " : this.agencyNo;
            }
        }

        public Character getEntrustStatus() {
            return this.entrustStatus != null ? this.entrustStatus : ' ';
        }

        public String getProdAccount() {
            if (this.prodAccount == null) {
                return " ";
            } else {
                return this.prodAccount.isEmpty() ? " " : this.prodAccount;
            }
        }

        public String getRemark() {
            if (this.remark == null) {
                return " ";
            } else {
                return this.remark.isEmpty() ? " " : this.remark;
            }
        }

        public void setEntrustDate(Integer entrustDate) {
            this.entrustDate = entrustDate;
        }

        public void setEntrustTime(Integer entrustTime) {
            this.entrustTime = entrustTime;
        }

        public void setAllotNo(String allotNo) {
            this.allotNo = allotNo;
        }

        public void setAgencyNo(String agencyNo) {
            this.agencyNo = agencyNo;
        }

        public void setEntrustStatus(Character entrustStatus) {
            this.entrustStatus = entrustStatus;
        }

        public void setProdAccount(String prodAccount) {
            this.prodAccount = prodAccount;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("DeleteProdholderAcctInnerInput:(");
            buffer.append("entrustDate:" + this.entrustDate);
            buffer.append(",entrustTime:" + this.entrustTime);
            buffer.append(",allotNo:" + this.allotNo);
            buffer.append(",agencyNo:" + this.agencyNo);
            buffer.append(",entrustStatus:" + this.entrustStatus);
            buffer.append(",prodAccount:" + this.prodAccount);
            buffer.append(",remark:" + this.remark);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.entrustDate);
            builder.append(this.entrustTime);
            builder.append(this.allotNo);
            builder.append(this.agencyNo);
            builder.append(this.entrustStatus);
            builder.append(this.prodAccount);
            builder.append(this.remark);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.DeleteProdholderAcctInnerInput) {
                InnerDfzqService.DeleteProdholderAcctInnerInput test = (InnerDfzqService.DeleteProdholderAcctInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.entrustDate, test.entrustDate);
                builder.append(this.entrustTime, test.entrustTime);
                builder.append(this.allotNo, test.allotNo);
                builder.append(this.agencyNo, test.agencyNo);
                builder.append(this.entrustStatus, test.entrustStatus);
                builder.append(this.prodAccount, test.prodAccount);
                builder.append(this.remark, test.remark);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutStockHolderOpenFrozenOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String returnMsg = " ";

        public PutStockHolderOpenFrozenOutput() {
        }

        public String getReturnMsg() {
            if (this.returnMsg == null) {
                return " ";
            } else {
                return this.returnMsg.isEmpty() ? " " : this.returnMsg;
            }
        }

        public void setReturnMsg(String returnMsg) {
            this.returnMsg = returnMsg;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutStockHolderOpenFrozenOutput:(");
            buffer.append("returnMsg:" + this.returnMsg);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.returnMsg);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.PutStockHolderOpenFrozenOutput) {
                InnerDfzqService.PutStockHolderOpenFrozenOutput test = (InnerDfzqService.PutStockHolderOpenFrozenOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.returnMsg, test.returnMsg);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PutStockHolderOpenFrozenInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fundAccount = " ";
        @SinogramLength(
                min = 0,
                max = 3,
                charset = "utf-8"
        )
        private String moneyType = " ";
        @Digits(
                integer = 13,
                fraction = 2,
                message = "冻结资金【frozenBalance】 超出精度范围, 最大整数位为【13】, 小数位为【2】"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double frozenBalance = 0.0D;
        @Digits(
                integer = 13,
                fraction = 2,
                message = "当前余额【currentBalance】 超出精度范围, 最大整数位为【13】, 小数位为【2】"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double currentBalance = 0.0D;
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String exchangeType = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character assetProp = ' ';
        @SinogramLength(
                min = 0,
                max = 20,
                charset = "utf-8"
        )
        private String stockAccount = " ";

        public PutStockHolderOpenFrozenInput() {
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getMoneyType() {
            if (this.moneyType == null) {
                return " ";
            } else {
                return this.moneyType.isEmpty() ? " " : this.moneyType;
            }
        }

        public Double getFrozenBalance() {
            return this.frozenBalance != null ? this.frozenBalance : 0.0D;
        }

        public Double getCurrentBalance() {
            return this.currentBalance != null ? this.currentBalance : 0.0D;
        }

        public String getExchangeType() {
            if (this.exchangeType == null) {
                return " ";
            } else {
                return this.exchangeType.isEmpty() ? " " : this.exchangeType;
            }
        }

        public Character getAssetProp() {
            return this.assetProp != null ? this.assetProp : ' ';
        }

        public String getStockAccount() {
            if (this.stockAccount == null) {
                return " ";
            } else {
                return this.stockAccount.isEmpty() ? " " : this.stockAccount;
            }
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setMoneyType(String moneyType) {
            this.moneyType = moneyType;
        }

        public void setFrozenBalance(Double frozenBalance) {
            this.frozenBalance = frozenBalance;
        }

        public void setCurrentBalance(Double currentBalance) {
            this.currentBalance = currentBalance;
        }

        public void setExchangeType(String exchangeType) {
            this.exchangeType = exchangeType;
        }

        public void setAssetProp(Character assetProp) {
            this.assetProp = assetProp;
        }

        public void setStockAccount(String stockAccount) {
            this.stockAccount = stockAccount;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PutStockHolderOpenFrozenInput:(");
            buffer.append("operatorNo:" + this.operatorNo);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",moneyType:" + this.moneyType);
            buffer.append(",frozenBalance:" + this.frozenBalance);
            buffer.append(",currentBalance:" + this.currentBalance);
            buffer.append(",exchangeType:" + this.exchangeType);
            buffer.append(",assetProp:" + this.assetProp);
            buffer.append(",stockAccount:" + this.stockAccount);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.operatorNo);
            builder.append(this.fundAccount);
            builder.append(this.moneyType);
            builder.append(this.frozenBalance);
            builder.append(this.currentBalance);
            builder.append(this.exchangeType);
            builder.append(this.assetProp);
            builder.append(this.stockAccount);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.PutStockHolderOpenFrozenInput) {
                InnerDfzqService.PutStockHolderOpenFrozenInput test = (InnerDfzqService.PutStockHolderOpenFrozenInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.moneyType, test.moneyType);
                builder.append(this.frozenBalance, test.frozenBalance);
                builder.append(this.currentBalance, test.currentBalance);
                builder.append(this.exchangeType, test.exchangeType);
                builder.append(this.assetProp, test.assetProp);
                builder.append(this.stockAccount, test.stockAccount);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetSysConfigZxInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String returnCode = " ";
        private String opRemark = " ";
        private String subEntry = " ";
        private String dictPrompt = " ";

        public GetSysConfigZxInnerOutput() {
        }

        public String getReturnCode() {
            if (this.returnCode == null) {
                return " ";
            } else {
                return this.returnCode.isEmpty() ? " " : this.returnCode;
            }
        }

        public String getOpRemark() {
            if (this.opRemark == null) {
                return " ";
            } else {
                return this.opRemark.isEmpty() ? " " : this.opRemark;
            }
        }

        public String getSubEntry() {
            if (this.subEntry == null) {
                return " ";
            } else {
                return this.subEntry.isEmpty() ? " " : this.subEntry;
            }
        }

        public String getDictPrompt() {
            if (this.dictPrompt == null) {
                return " ";
            } else {
                return this.dictPrompt.isEmpty() ? " " : this.dictPrompt;
            }
        }

        public void setReturnCode(String returnCode) {
            this.returnCode = returnCode;
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public void setSubEntry(String subEntry) {
            this.subEntry = subEntry;
        }

        public void setDictPrompt(String dictPrompt) {
            this.dictPrompt = dictPrompt;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetSysConfigZxInnerOutput:(");
            buffer.append("returnCode:" + this.returnCode);
            buffer.append(",opRemark:" + this.opRemark);
            buffer.append(",subEntry:" + this.subEntry);
            buffer.append(",dictPrompt:" + this.dictPrompt);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.returnCode);
            builder.append(this.opRemark);
            builder.append(this.subEntry);
            builder.append(this.dictPrompt);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.GetSysConfigZxInnerOutput) {
                InnerDfzqService.GetSysConfigZxInnerOutput test = (InnerDfzqService.GetSysConfigZxInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.returnCode, test.returnCode);
                builder.append(this.opRemark, test.opRemark);
                builder.append(this.subEntry, test.subEntry);
                builder.append(this.dictPrompt, test.dictPrompt);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetSysConfigZxInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer branchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        private Integer dictEntry = 0;

        public GetSysConfigZxInnerInput() {
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Integer getDictEntry() {
            return this.dictEntry != null ? this.dictEntry : 0;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setDictEntry(Integer dictEntry) {
            this.dictEntry = dictEntry;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetSysConfigZxInnerInput:(");
            buffer.append("branchNo:" + this.branchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",dictEntry:" + this.dictEntry);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.branchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.dictEntry);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.GetSysConfigZxInnerInput) {
                InnerDfzqService.GetSysConfigZxInnerInput test = (InnerDfzqService.GetSysConfigZxInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.dictEntry, test.dictEntry);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetProdholderQueryInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer replyTime = 0;
        private String replyId = " ";
        private Integer entrustDate = 0;
        private Integer entrustTime = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character entrustStatus = ' ';
        private String allotNo = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character acctOperType = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character organFlag = ' ';
        private String prodAccount = " ";
        private String transAccount = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character idKind = ' ';
        private String idNo = " ";
        private Integer idEnddate = 0;
        private String instreprName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character instreprIdKind = ' ';
        private String instreprIdNo = " ";
        private Integer instreprIdEnddate = 0;
        private String contactName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character contractIdKind = ' ';
        private String contactIdNo = " ";
        private Integer contactIdEnddate = 0;
        private String nationality = " ";
        private String addrProvince = " ";
        private String addrCity = " ";
        private String countyName = " ";
        private String postcode = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character sex = ' ';
        private Integer birthday = 0;
        private String professionCode = " ";
        private String address = " ";
        private String phone = " ";
        private String fax = " ";
        private String mobile = " ";
        private String email = " ";
        private String remark = " ";

        public GetProdholderQueryInnerOutput() {
        }

        public Integer getReplyTime() {
            return this.replyTime != null ? this.replyTime : 0;
        }

        public String getReplyId() {
            if (this.replyId == null) {
                return " ";
            } else {
                return this.replyId.isEmpty() ? " " : this.replyId;
            }
        }

        public Integer getEntrustDate() {
            return this.entrustDate != null ? this.entrustDate : 0;
        }

        public Integer getEntrustTime() {
            return this.entrustTime != null ? this.entrustTime : 0;
        }

        public Character getEntrustStatus() {
            return this.entrustStatus != null ? this.entrustStatus : ' ';
        }

        public String getAllotNo() {
            if (this.allotNo == null) {
                return " ";
            } else {
                return this.allotNo.isEmpty() ? " " : this.allotNo;
            }
        }

        public Character getAcctOperType() {
            return this.acctOperType != null ? this.acctOperType : ' ';
        }

        public Character getOrganFlag() {
            return this.organFlag != null ? this.organFlag : ' ';
        }

        public String getProdAccount() {
            if (this.prodAccount == null) {
                return " ";
            } else {
                return this.prodAccount.isEmpty() ? " " : this.prodAccount;
            }
        }

        public String getTransAccount() {
            if (this.transAccount == null) {
                return " ";
            } else {
                return this.transAccount.isEmpty() ? " " : this.transAccount;
            }
        }

        public Character getIdKind() {
            return this.idKind != null ? this.idKind : ' ';
        }

        public String getIdNo() {
            if (this.idNo == null) {
                return " ";
            } else {
                return this.idNo.isEmpty() ? " " : this.idNo;
            }
        }

        public Integer getIdEnddate() {
            return this.idEnddate != null ? this.idEnddate : 0;
        }

        public String getInstreprName() {
            if (this.instreprName == null) {
                return " ";
            } else {
                return this.instreprName.isEmpty() ? " " : this.instreprName;
            }
        }

        public Character getInstreprIdKind() {
            return this.instreprIdKind != null ? this.instreprIdKind : ' ';
        }

        public String getInstreprIdNo() {
            if (this.instreprIdNo == null) {
                return " ";
            } else {
                return this.instreprIdNo.isEmpty() ? " " : this.instreprIdNo;
            }
        }

        public Integer getInstreprIdEnddate() {
            return this.instreprIdEnddate != null ? this.instreprIdEnddate : 0;
        }

        public String getContactName() {
            if (this.contactName == null) {
                return " ";
            } else {
                return this.contactName.isEmpty() ? " " : this.contactName;
            }
        }

        public Character getContractIdKind() {
            return this.contractIdKind != null ? this.contractIdKind : ' ';
        }

        public String getContactIdNo() {
            if (this.contactIdNo == null) {
                return " ";
            } else {
                return this.contactIdNo.isEmpty() ? " " : this.contactIdNo;
            }
        }

        public Integer getContactIdEnddate() {
            return this.contactIdEnddate != null ? this.contactIdEnddate : 0;
        }

        public String getNationality() {
            if (this.nationality == null) {
                return " ";
            } else {
                return this.nationality.isEmpty() ? " " : this.nationality;
            }
        }

        public String getAddrProvince() {
            if (this.addrProvince == null) {
                return " ";
            } else {
                return this.addrProvince.isEmpty() ? " " : this.addrProvince;
            }
        }

        public String getAddrCity() {
            if (this.addrCity == null) {
                return " ";
            } else {
                return this.addrCity.isEmpty() ? " " : this.addrCity;
            }
        }

        public String getCountyName() {
            if (this.countyName == null) {
                return " ";
            } else {
                return this.countyName.isEmpty() ? " " : this.countyName;
            }
        }

        public String getPostcode() {
            if (this.postcode == null) {
                return " ";
            } else {
                return this.postcode.isEmpty() ? " " : this.postcode;
            }
        }

        public Character getSex() {
            return this.sex != null ? this.sex : ' ';
        }

        public Integer getBirthday() {
            return this.birthday != null ? this.birthday : 0;
        }

        public String getProfessionCode() {
            if (this.professionCode == null) {
                return " ";
            } else {
                return this.professionCode.isEmpty() ? " " : this.professionCode;
            }
        }

        public String getAddress() {
            if (this.address == null) {
                return " ";
            } else {
                return this.address.isEmpty() ? " " : this.address;
            }
        }

        public String getPhone() {
            if (this.phone == null) {
                return " ";
            } else {
                return this.phone.isEmpty() ? " " : this.phone;
            }
        }

        public String getFax() {
            if (this.fax == null) {
                return " ";
            } else {
                return this.fax.isEmpty() ? " " : this.fax;
            }
        }

        public String getMobile() {
            if (this.mobile == null) {
                return " ";
            } else {
                return this.mobile.isEmpty() ? " " : this.mobile;
            }
        }

        public String getEmail() {
            if (this.email == null) {
                return " ";
            } else {
                return this.email.isEmpty() ? " " : this.email;
            }
        }

        public String getRemark() {
            if (this.remark == null) {
                return " ";
            } else {
                return this.remark.isEmpty() ? " " : this.remark;
            }
        }

        public void setReplyTime(Integer replyTime) {
            this.replyTime = replyTime;
        }

        public void setReplyId(String replyId) {
            this.replyId = replyId;
        }

        public void setEntrustDate(Integer entrustDate) {
            this.entrustDate = entrustDate;
        }

        public void setEntrustTime(Integer entrustTime) {
            this.entrustTime = entrustTime;
        }

        public void setEntrustStatus(Character entrustStatus) {
            this.entrustStatus = entrustStatus;
        }

        public void setAllotNo(String allotNo) {
            this.allotNo = allotNo;
        }

        public void setAcctOperType(Character acctOperType) {
            this.acctOperType = acctOperType;
        }

        public void setOrganFlag(Character organFlag) {
            this.organFlag = organFlag;
        }

        public void setProdAccount(String prodAccount) {
            this.prodAccount = prodAccount;
        }

        public void setTransAccount(String transAccount) {
            this.transAccount = transAccount;
        }

        public void setIdKind(Character idKind) {
            this.idKind = idKind;
        }

        public void setIdNo(String idNo) {
            this.idNo = idNo;
        }

        public void setIdEnddate(Integer idEnddate) {
            this.idEnddate = idEnddate;
        }

        public void setInstreprName(String instreprName) {
            this.instreprName = instreprName;
        }

        public void setInstreprIdKind(Character instreprIdKind) {
            this.instreprIdKind = instreprIdKind;
        }

        public void setInstreprIdNo(String instreprIdNo) {
            this.instreprIdNo = instreprIdNo;
        }

        public void setInstreprIdEnddate(Integer instreprIdEnddate) {
            this.instreprIdEnddate = instreprIdEnddate;
        }

        public void setContactName(String contactName) {
            this.contactName = contactName;
        }

        public void setContractIdKind(Character contractIdKind) {
            this.contractIdKind = contractIdKind;
        }

        public void setContactIdNo(String contactIdNo) {
            this.contactIdNo = contactIdNo;
        }

        public void setContactIdEnddate(Integer contactIdEnddate) {
            this.contactIdEnddate = contactIdEnddate;
        }

        public void setNationality(String nationality) {
            this.nationality = nationality;
        }

        public void setAddrProvince(String addrProvince) {
            this.addrProvince = addrProvince;
        }

        public void setAddrCity(String addrCity) {
            this.addrCity = addrCity;
        }

        public void setCountyName(String countyName) {
            this.countyName = countyName;
        }

        public void setPostcode(String postcode) {
            this.postcode = postcode;
        }

        public void setSex(Character sex) {
            this.sex = sex;
        }

        public void setBirthday(Integer birthday) {
            this.birthday = birthday;
        }

        public void setProfessionCode(String professionCode) {
            this.professionCode = professionCode;
        }

        public void setAddress(String address) {
            this.address = address;
        }

        public void setPhone(String phone) {
            this.phone = phone;
        }

        public void setFax(String fax) {
            this.fax = fax;
        }

        public void setMobile(String mobile) {
            this.mobile = mobile;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetProdholderQueryInnerOutput:(");
            buffer.append("replyTime:" + this.replyTime);
            buffer.append(",replyId:" + this.replyId);
            buffer.append(",entrustDate:" + this.entrustDate);
            buffer.append(",entrustTime:" + this.entrustTime);
            buffer.append(",entrustStatus:" + this.entrustStatus);
            buffer.append(",allotNo:" + this.allotNo);
            buffer.append(",acctOperType:" + this.acctOperType);
            buffer.append(",organFlag:" + this.organFlag);
            buffer.append(",prodAccount:" + this.prodAccount);
            buffer.append(",transAccount:" + this.transAccount);
            buffer.append(",idKind:" + this.idKind);
            buffer.append(",idNo:" + this.idNo);
            buffer.append(",idEnddate:" + this.idEnddate);
            buffer.append(",instreprName:" + this.instreprName);
            buffer.append(",instreprIdKind:" + this.instreprIdKind);
            buffer.append(",instreprIdNo:" + this.instreprIdNo);
            buffer.append(",instreprIdEnddate:" + this.instreprIdEnddate);
            buffer.append(",contactName:" + this.contactName);
            buffer.append(",contractIdKind:" + this.contractIdKind);
            buffer.append(",contactIdNo:" + this.contactIdNo);
            buffer.append(",contactIdEnddate:" + this.contactIdEnddate);
            buffer.append(",nationality:" + this.nationality);
            buffer.append(",addrProvince:" + this.addrProvince);
            buffer.append(",addrCity:" + this.addrCity);
            buffer.append(",countyName:" + this.countyName);
            buffer.append(",postcode:" + this.postcode);
            buffer.append(",sex:" + this.sex);
            buffer.append(",birthday:" + this.birthday);
            buffer.append(",professionCode:" + this.professionCode);
            buffer.append(",address:" + this.address);
            buffer.append(",phone:" + this.phone);
            buffer.append(",fax:" + this.fax);
            buffer.append(",mobile:" + this.mobile);
            buffer.append(",email:" + this.email);
            buffer.append(",remark:" + this.remark);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.replyTime);
            builder.append(this.replyId);
            builder.append(this.entrustDate);
            builder.append(this.entrustTime);
            builder.append(this.entrustStatus);
            builder.append(this.allotNo);
            builder.append(this.acctOperType);
            builder.append(this.organFlag);
            builder.append(this.prodAccount);
            builder.append(this.transAccount);
            builder.append(this.idKind);
            builder.append(this.idNo);
            builder.append(this.idEnddate);
            builder.append(this.instreprName);
            builder.append(this.instreprIdKind);
            builder.append(this.instreprIdNo);
            builder.append(this.instreprIdEnddate);
            builder.append(this.contactName);
            builder.append(this.contractIdKind);
            builder.append(this.contactIdNo);
            builder.append(this.contactIdEnddate);
            builder.append(this.nationality);
            builder.append(this.addrProvince);
            builder.append(this.addrCity);
            builder.append(this.countyName);
            builder.append(this.postcode);
            builder.append(this.sex);
            builder.append(this.birthday);
            builder.append(this.professionCode);
            builder.append(this.address);
            builder.append(this.phone);
            builder.append(this.fax);
            builder.append(this.mobile);
            builder.append(this.email);
            builder.append(this.remark);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.GetProdholderQueryInnerOutput) {
                InnerDfzqService.GetProdholderQueryInnerOutput test = (InnerDfzqService.GetProdholderQueryInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.replyTime, test.replyTime);
                builder.append(this.replyId, test.replyId);
                builder.append(this.entrustDate, test.entrustDate);
                builder.append(this.entrustTime, test.entrustTime);
                builder.append(this.entrustStatus, test.entrustStatus);
                builder.append(this.allotNo, test.allotNo);
                builder.append(this.acctOperType, test.acctOperType);
                builder.append(this.organFlag, test.organFlag);
                builder.append(this.prodAccount, test.prodAccount);
                builder.append(this.transAccount, test.transAccount);
                builder.append(this.idKind, test.idKind);
                builder.append(this.idNo, test.idNo);
                builder.append(this.idEnddate, test.idEnddate);
                builder.append(this.instreprName, test.instreprName);
                builder.append(this.instreprIdKind, test.instreprIdKind);
                builder.append(this.instreprIdNo, test.instreprIdNo);
                builder.append(this.instreprIdEnddate, test.instreprIdEnddate);
                builder.append(this.contactName, test.contactName);
                builder.append(this.contractIdKind, test.contractIdKind);
                builder.append(this.contactIdNo, test.contactIdNo);
                builder.append(this.contactIdEnddate, test.contactIdEnddate);
                builder.append(this.nationality, test.nationality);
                builder.append(this.addrProvince, test.addrProvince);
                builder.append(this.addrCity, test.addrCity);
                builder.append(this.countyName, test.countyName);
                builder.append(this.postcode, test.postcode);
                builder.append(this.sex, test.sex);
                builder.append(this.birthday, test.birthday);
                builder.append(this.professionCode, test.professionCode);
                builder.append(this.address, test.address);
                builder.append(this.phone, test.phone);
                builder.append(this.fax, test.fax);
                builder.append(this.mobile, test.mobile);
                builder.append(this.email, test.email);
                builder.append(this.remark, test.remark);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetProdholderQueryInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 1,
                max = 24,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String allotNo = " ";

        public GetProdholderQueryInnerInput() {
        }

        public String getAllotNo() {
            if (this.allotNo == null) {
                return " ";
            } else {
                return this.allotNo.isEmpty() ? " " : this.allotNo;
            }
        }

        public void setAllotNo(String allotNo) {
            this.allotNo = allotNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetProdholderQueryInnerInput:(");
            buffer.append("allotNo:" + this.allotNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.allotNo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.GetProdholderQueryInnerInput) {
                InnerDfzqService.GetProdholderQueryInnerInput test = (InnerDfzqService.GetProdholderQueryInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.allotNo, test.allotNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostProdholderAddInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer retCode = 0;
        private String retInfo = " ";

        public PostProdholderAddInnerOutput() {
        }

        public Integer getRetCode() {
            return this.retCode != null ? this.retCode : 0;
        }

        public String getRetInfo() {
            if (this.retInfo == null) {
                return " ";
            } else {
                return this.retInfo.isEmpty() ? " " : this.retInfo;
            }
        }

        public void setRetCode(Integer retCode) {
            this.retCode = retCode;
        }

        public void setRetInfo(String retInfo) {
            this.retInfo = retInfo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostProdholderAddInnerOutput:(");
            buffer.append("retCode:" + this.retCode);
            buffer.append(",retInfo:" + this.retInfo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.retCode);
            builder.append(this.retInfo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.PostProdholderAddInnerOutput) {
                InnerDfzqService.PostProdholderAddInnerOutput test = (InnerDfzqService.PostProdholderAddInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.retCode, test.retCode);
                builder.append(this.retInfo, test.retInfo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostProdholderAddInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 1,
                max = 24,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String allotNo = " ";
        @NotNull(
                message = "不能为空"
        )
        private Integer riskEndDate = 0;
        @NotNull(
                message = "不能为空"
        )
        private Integer corpRiskLevel = 0;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character acctOperType = ' ';
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String prodAccount = " ";
        @SinogramLength(
                min = 1,
                max = 32,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String transAccount = " ";
        @NotNull(
                message = "不能为空"
        )
        private Integer entrustDate = 0;
        @NotNull(
                message = "不能为空"
        )
        private Integer entrustTime = 0;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character entrustStatus = ' ';
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character organFlag = ' ';
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character idKind = ' ';
        @SinogramLength(
                min = 1,
                max = 40,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String idNo = " ";
        private Integer idEnddate = 0;
        @SinogramLength(
                min = 0,
                max = 180,
                charset = "utf-8"
        )
        private String instreprName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character instreprIdKind = ' ';
        @SinogramLength(
                min = 0,
                max = 40,
                charset = "utf-8"
        )
        private String instreprIdNo = " ";
        private Integer instreprIdEnddate = 0;
        @SinogramLength(
                min = 0,
                max = 180,
                charset = "utf-8"
        )
        private String contactName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character contractIdKind = ' ';
        @SinogramLength(
                min = 0,
                max = 40,
                charset = "utf-8"
        )
        private String contactIdNo = " ";
        private Integer contactIdEnddate = 0;
        @SinogramLength(
                min = 0,
                max = 3,
                charset = "utf-8"
        )
        private String nationality = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String addrProvince = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String addrCity = " ";
        @SinogramLength(
                min = 0,
                max = 16,
                charset = "utf-8"
        )
        private String countyName = " ";
        @SinogramLength(
                min = 0,
                max = 6,
                charset = "utf-8"
        )
        private String postcode = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character sex = ' ';
        private Integer birthday = 0;
        @SinogramLength(
                min = 0,
                max = 2,
                charset = "utf-8"
        )
        private String professionCode = " ";
        @SinogramLength(
                min = 0,
                max = 180,
                charset = "utf-8"
        )
        private String address = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String phone = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String fax = " ";
        @SinogramLength(
                min = 1,
                max = 32,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String mobile = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String email = " ";
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String remark = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character payKind = ' ';
        private String signData = " ";
        @SinogramLength(
                min = 1,
                max = 48,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String stockName = " ";
        @SinogramLength(
                min = 0,
                max = 60,
                charset = "utf-8"
        )
        private String shortName = " ";

        public PostProdholderAddInnerInput() {
        }

        public String getAllotNo() {
            if (this.allotNo == null) {
                return " ";
            } else {
                return this.allotNo.isEmpty() ? " " : this.allotNo;
            }
        }

        public Integer getRiskEndDate() {
            return this.riskEndDate != null ? this.riskEndDate : 0;
        }

        public Integer getCorpRiskLevel() {
            return this.corpRiskLevel != null ? this.corpRiskLevel : 0;
        }

        public Character getAcctOperType() {
            return this.acctOperType != null ? this.acctOperType : ' ';
        }

        public String getProdAccount() {
            if (this.prodAccount == null) {
                return " ";
            } else {
                return this.prodAccount.isEmpty() ? " " : this.prodAccount;
            }
        }

        public String getTransAccount() {
            if (this.transAccount == null) {
                return " ";
            } else {
                return this.transAccount.isEmpty() ? " " : this.transAccount;
            }
        }

        public Integer getEntrustDate() {
            return this.entrustDate != null ? this.entrustDate : 0;
        }

        public Integer getEntrustTime() {
            return this.entrustTime != null ? this.entrustTime : 0;
        }

        public Character getEntrustStatus() {
            return this.entrustStatus != null ? this.entrustStatus : ' ';
        }

        public Character getOrganFlag() {
            return this.organFlag != null ? this.organFlag : ' ';
        }

        public Character getIdKind() {
            return this.idKind != null ? this.idKind : ' ';
        }

        public String getIdNo() {
            if (this.idNo == null) {
                return " ";
            } else {
                return this.idNo.isEmpty() ? " " : this.idNo;
            }
        }

        public Integer getIdEnddate() {
            return this.idEnddate != null ? this.idEnddate : 0;
        }

        public String getInstreprName() {
            if (this.instreprName == null) {
                return " ";
            } else {
                return this.instreprName.isEmpty() ? " " : this.instreprName;
            }
        }

        public Character getInstreprIdKind() {
            return this.instreprIdKind != null ? this.instreprIdKind : ' ';
        }

        public String getInstreprIdNo() {
            if (this.instreprIdNo == null) {
                return " ";
            } else {
                return this.instreprIdNo.isEmpty() ? " " : this.instreprIdNo;
            }
        }

        public Integer getInstreprIdEnddate() {
            return this.instreprIdEnddate != null ? this.instreprIdEnddate : 0;
        }

        public String getContactName() {
            if (this.contactName == null) {
                return " ";
            } else {
                return this.contactName.isEmpty() ? " " : this.contactName;
            }
        }

        public Character getContractIdKind() {
            return this.contractIdKind != null ? this.contractIdKind : ' ';
        }

        public String getContactIdNo() {
            if (this.contactIdNo == null) {
                return " ";
            } else {
                return this.contactIdNo.isEmpty() ? " " : this.contactIdNo;
            }
        }

        public Integer getContactIdEnddate() {
            return this.contactIdEnddate != null ? this.contactIdEnddate : 0;
        }

        public String getNationality() {
            if (this.nationality == null) {
                return " ";
            } else {
                return this.nationality.isEmpty() ? " " : this.nationality;
            }
        }

        public String getAddrProvince() {
            if (this.addrProvince == null) {
                return " ";
            } else {
                return this.addrProvince.isEmpty() ? " " : this.addrProvince;
            }
        }

        public String getAddrCity() {
            if (this.addrCity == null) {
                return " ";
            } else {
                return this.addrCity.isEmpty() ? " " : this.addrCity;
            }
        }

        public String getCountyName() {
            if (this.countyName == null) {
                return " ";
            } else {
                return this.countyName.isEmpty() ? " " : this.countyName;
            }
        }

        public String getPostcode() {
            if (this.postcode == null) {
                return " ";
            } else {
                return this.postcode.isEmpty() ? " " : this.postcode;
            }
        }

        public Character getSex() {
            return this.sex != null ? this.sex : ' ';
        }

        public Integer getBirthday() {
            return this.birthday != null ? this.birthday : 0;
        }

        public String getProfessionCode() {
            if (this.professionCode == null) {
                return " ";
            } else {
                return this.professionCode.isEmpty() ? " " : this.professionCode;
            }
        }

        public String getAddress() {
            if (this.address == null) {
                return " ";
            } else {
                return this.address.isEmpty() ? " " : this.address;
            }
        }

        public String getPhone() {
            if (this.phone == null) {
                return " ";
            } else {
                return this.phone.isEmpty() ? " " : this.phone;
            }
        }

        public String getFax() {
            if (this.fax == null) {
                return " ";
            } else {
                return this.fax.isEmpty() ? " " : this.fax;
            }
        }

        public String getMobile() {
            if (this.mobile == null) {
                return " ";
            } else {
                return this.mobile.isEmpty() ? " " : this.mobile;
            }
        }

        public String getEmail() {
            if (this.email == null) {
                return " ";
            } else {
                return this.email.isEmpty() ? " " : this.email;
            }
        }

        public String getRemark() {
            if (this.remark == null) {
                return " ";
            } else {
                return this.remark.isEmpty() ? " " : this.remark;
            }
        }

        public Character getPayKind() {
            return this.payKind != null ? this.payKind : ' ';
        }

        public String getSignData() {
            if (this.signData == null) {
                return " ";
            } else {
                return this.signData.isEmpty() ? " " : this.signData;
            }
        }

        public String getStockName() {
            if (this.stockName == null) {
                return " ";
            } else {
                return this.stockName.isEmpty() ? " " : this.stockName;
            }
        }

        public String getShortName() {
            if (this.shortName == null) {
                return " ";
            } else {
                return this.shortName.isEmpty() ? " " : this.shortName;
            }
        }

        public void setAllotNo(String allotNo) {
            this.allotNo = allotNo;
        }

        public void setRiskEndDate(Integer riskEndDate) {
            this.riskEndDate = riskEndDate;
        }

        public void setCorpRiskLevel(Integer corpRiskLevel) {
            this.corpRiskLevel = corpRiskLevel;
        }

        public void setAcctOperType(Character acctOperType) {
            this.acctOperType = acctOperType;
        }

        public void setProdAccount(String prodAccount) {
            this.prodAccount = prodAccount;
        }

        public void setTransAccount(String transAccount) {
            this.transAccount = transAccount;
        }

        public void setEntrustDate(Integer entrustDate) {
            this.entrustDate = entrustDate;
        }

        public void setEntrustTime(Integer entrustTime) {
            this.entrustTime = entrustTime;
        }

        public void setEntrustStatus(Character entrustStatus) {
            this.entrustStatus = entrustStatus;
        }

        public void setOrganFlag(Character organFlag) {
            this.organFlag = organFlag;
        }

        public void setIdKind(Character idKind) {
            this.idKind = idKind;
        }

        public void setIdNo(String idNo) {
            this.idNo = idNo;
        }

        public void setIdEnddate(Integer idEnddate) {
            this.idEnddate = idEnddate;
        }

        public void setInstreprName(String instreprName) {
            this.instreprName = instreprName;
        }

        public void setInstreprIdKind(Character instreprIdKind) {
            this.instreprIdKind = instreprIdKind;
        }

        public void setInstreprIdNo(String instreprIdNo) {
            this.instreprIdNo = instreprIdNo;
        }

        public void setInstreprIdEnddate(Integer instreprIdEnddate) {
            this.instreprIdEnddate = instreprIdEnddate;
        }

        public void setContactName(String contactName) {
            this.contactName = contactName;
        }

        public void setContractIdKind(Character contractIdKind) {
            this.contractIdKind = contractIdKind;
        }

        public void setContactIdNo(String contactIdNo) {
            this.contactIdNo = contactIdNo;
        }

        public void setContactIdEnddate(Integer contactIdEnddate) {
            this.contactIdEnddate = contactIdEnddate;
        }

        public void setNationality(String nationality) {
            this.nationality = nationality;
        }

        public void setAddrProvince(String addrProvince) {
            this.addrProvince = addrProvince;
        }

        public void setAddrCity(String addrCity) {
            this.addrCity = addrCity;
        }

        public void setCountyName(String countyName) {
            this.countyName = countyName;
        }

        public void setPostcode(String postcode) {
            this.postcode = postcode;
        }

        public void setSex(Character sex) {
            this.sex = sex;
        }

        public void setBirthday(Integer birthday) {
            this.birthday = birthday;
        }

        public void setProfessionCode(String professionCode) {
            this.professionCode = professionCode;
        }

        public void setAddress(String address) {
            this.address = address;
        }

        public void setPhone(String phone) {
            this.phone = phone;
        }

        public void setFax(String fax) {
            this.fax = fax;
        }

        public void setMobile(String mobile) {
            this.mobile = mobile;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public void setPayKind(Character payKind) {
            this.payKind = payKind;
        }

        public void setSignData(String signData) {
            this.signData = signData;
        }

        public void setStockName(String stockName) {
            this.stockName = stockName;
        }

        public void setShortName(String shortName) {
            this.shortName = shortName;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostProdholderAddInnerInput:(");
            buffer.append("allotNo:" + this.allotNo);
            buffer.append(",riskEndDate:" + this.riskEndDate);
            buffer.append(",corpRiskLevel:" + this.corpRiskLevel);
            buffer.append(",acctOperType:" + this.acctOperType);
            buffer.append(",prodAccount:" + this.prodAccount);
            buffer.append(",transAccount:" + this.transAccount);
            buffer.append(",entrustDate:" + this.entrustDate);
            buffer.append(",entrustTime:" + this.entrustTime);
            buffer.append(",entrustStatus:" + this.entrustStatus);
            buffer.append(",organFlag:" + this.organFlag);
            buffer.append(",idKind:" + this.idKind);
            buffer.append(",idNo:" + this.idNo);
            buffer.append(",idEnddate:" + this.idEnddate);
            buffer.append(",instreprName:" + this.instreprName);
            buffer.append(",instreprIdKind:" + this.instreprIdKind);
            buffer.append(",instreprIdNo:" + this.instreprIdNo);
            buffer.append(",instreprIdEnddate:" + this.instreprIdEnddate);
            buffer.append(",contactName:" + this.contactName);
            buffer.append(",contractIdKind:" + this.contractIdKind);
            buffer.append(",contactIdNo:" + this.contactIdNo);
            buffer.append(",contactIdEnddate:" + this.contactIdEnddate);
            buffer.append(",nationality:" + this.nationality);
            buffer.append(",addrProvince:" + this.addrProvince);
            buffer.append(",addrCity:" + this.addrCity);
            buffer.append(",countyName:" + this.countyName);
            buffer.append(",postcode:" + this.postcode);
            buffer.append(",sex:" + this.sex);
            buffer.append(",birthday:" + this.birthday);
            buffer.append(",professionCode:" + this.professionCode);
            buffer.append(",address:" + this.address);
            buffer.append(",phone:" + this.phone);
            buffer.append(",fax:" + this.fax);
            buffer.append(",mobile:" + this.mobile);
            buffer.append(",email:" + this.email);
            buffer.append(",remark:" + this.remark);
            buffer.append(",payKind:" + this.payKind);
            buffer.append(",signData:" + this.signData);
            buffer.append(",stockName:" + this.stockName);
            buffer.append(",shortName:" + this.shortName);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.allotNo);
            builder.append(this.riskEndDate);
            builder.append(this.corpRiskLevel);
            builder.append(this.acctOperType);
            builder.append(this.prodAccount);
            builder.append(this.transAccount);
            builder.append(this.entrustDate);
            builder.append(this.entrustTime);
            builder.append(this.entrustStatus);
            builder.append(this.organFlag);
            builder.append(this.idKind);
            builder.append(this.idNo);
            builder.append(this.idEnddate);
            builder.append(this.instreprName);
            builder.append(this.instreprIdKind);
            builder.append(this.instreprIdNo);
            builder.append(this.instreprIdEnddate);
            builder.append(this.contactName);
            builder.append(this.contractIdKind);
            builder.append(this.contactIdNo);
            builder.append(this.contactIdEnddate);
            builder.append(this.nationality);
            builder.append(this.addrProvince);
            builder.append(this.addrCity);
            builder.append(this.countyName);
            builder.append(this.postcode);
            builder.append(this.sex);
            builder.append(this.birthday);
            builder.append(this.professionCode);
            builder.append(this.address);
            builder.append(this.phone);
            builder.append(this.fax);
            builder.append(this.mobile);
            builder.append(this.email);
            builder.append(this.remark);
            builder.append(this.payKind);
            builder.append(this.signData);
            builder.append(this.stockName);
            builder.append(this.shortName);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.PostProdholderAddInnerInput) {
                InnerDfzqService.PostProdholderAddInnerInput test = (InnerDfzqService.PostProdholderAddInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.allotNo, test.allotNo);
                builder.append(this.riskEndDate, test.riskEndDate);
                builder.append(this.corpRiskLevel, test.corpRiskLevel);
                builder.append(this.acctOperType, test.acctOperType);
                builder.append(this.prodAccount, test.prodAccount);
                builder.append(this.transAccount, test.transAccount);
                builder.append(this.entrustDate, test.entrustDate);
                builder.append(this.entrustTime, test.entrustTime);
                builder.append(this.entrustStatus, test.entrustStatus);
                builder.append(this.organFlag, test.organFlag);
                builder.append(this.idKind, test.idKind);
                builder.append(this.idNo, test.idNo);
                builder.append(this.idEnddate, test.idEnddate);
                builder.append(this.instreprName, test.instreprName);
                builder.append(this.instreprIdKind, test.instreprIdKind);
                builder.append(this.instreprIdNo, test.instreprIdNo);
                builder.append(this.instreprIdEnddate, test.instreprIdEnddate);
                builder.append(this.contactName, test.contactName);
                builder.append(this.contractIdKind, test.contractIdKind);
                builder.append(this.contactIdNo, test.contactIdNo);
                builder.append(this.contactIdEnddate, test.contactIdEnddate);
                builder.append(this.nationality, test.nationality);
                builder.append(this.addrProvince, test.addrProvince);
                builder.append(this.addrCity, test.addrCity);
                builder.append(this.countyName, test.countyName);
                builder.append(this.postcode, test.postcode);
                builder.append(this.sex, test.sex);
                builder.append(this.birthday, test.birthday);
                builder.append(this.professionCode, test.professionCode);
                builder.append(this.address, test.address);
                builder.append(this.phone, test.phone);
                builder.append(this.fax, test.fax);
                builder.append(this.mobile, test.mobile);
                builder.append(this.email, test.email);
                builder.append(this.remark, test.remark);
                builder.append(this.payKind, test.payKind);
                builder.append(this.signData, test.signData);
                builder.append(this.stockName, test.stockName);
                builder.append(this.shortName, test.shortName);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetFundaccountInbusinessInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer noticeNo = 0;
        private String noticeInfo = " ";
        private String checkId = " ";

        public GetFundaccountInbusinessInnerOutput() {
        }

        public Integer getNoticeNo() {
            return this.noticeNo != null ? this.noticeNo : 0;
        }

        public String getNoticeInfo() {
            if (this.noticeInfo == null) {
                return " ";
            } else {
                return this.noticeInfo.isEmpty() ? " " : this.noticeInfo;
            }
        }

        public String getCheckId() {
            if (this.checkId == null) {
                return " ";
            } else {
                return this.checkId.isEmpty() ? " " : this.checkId;
            }
        }

        public void setNoticeNo(Integer noticeNo) {
            this.noticeNo = noticeNo;
        }

        public void setNoticeInfo(String noticeInfo) {
            this.noticeInfo = noticeInfo;
        }

        public void setCheckId(String checkId) {
            this.checkId = checkId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetFundaccountInbusinessInnerOutput:(");
            buffer.append("noticeNo:" + this.noticeNo);
            buffer.append(",noticeInfo:" + this.noticeInfo);
            buffer.append(",checkId:" + this.checkId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.noticeNo);
            builder.append(this.noticeInfo);
            builder.append(this.checkId);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.GetFundaccountInbusinessInnerOutput) {
                InnerDfzqService.GetFundaccountInbusinessInnerOutput test = (InnerDfzqService.GetFundaccountInbusinessInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.noticeNo, test.noticeNo);
                builder.append(this.noticeInfo, test.noticeInfo);
                builder.append(this.checkId, test.checkId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetFundaccountInbusinessInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String fundAccount;

        public GetFundaccountInbusinessInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getClientId() {
            return this.clientId;
        }

        public String getFundAccount() {
            return this.fundAccount;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetFundaccountInbusinessInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.clientId);
            builder.append(this.fundAccount);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.GetFundaccountInbusinessInnerInput) {
                InnerDfzqService.GetFundaccountInbusinessInnerInput test = (InnerDfzqService.GetFundaccountInbusinessInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.clientId, test.clientId);
                builder.append(this.fundAccount, test.fundAccount);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetFundaccountCancelInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer noticeNo = 0;
        private String noticeInfo = " ";
        private String checkId = " ";

        public GetFundaccountCancelInnerOutput() {
        }

        public Integer getNoticeNo() {
            return this.noticeNo != null ? this.noticeNo : 0;
        }

        public String getNoticeInfo() {
            if (this.noticeInfo == null) {
                return " ";
            } else {
                return this.noticeInfo.isEmpty() ? " " : this.noticeInfo;
            }
        }

        public String getCheckId() {
            if (this.checkId == null) {
                return " ";
            } else {
                return this.checkId.isEmpty() ? " " : this.checkId;
            }
        }

        public void setNoticeNo(Integer noticeNo) {
            this.noticeNo = noticeNo;
        }

        public void setNoticeInfo(String noticeInfo) {
            this.noticeInfo = noticeInfo;
        }

        public void setCheckId(String checkId) {
            this.checkId = checkId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetFundaccountCancelInnerOutput:(");
            buffer.append("noticeNo:" + this.noticeNo);
            buffer.append(",noticeInfo:" + this.noticeInfo);
            buffer.append(",checkId:" + this.checkId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.noticeNo);
            builder.append(this.noticeInfo);
            builder.append(this.checkId);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.GetFundaccountCancelInnerOutput) {
                InnerDfzqService.GetFundaccountCancelInnerOutput test = (InnerDfzqService.GetFundaccountCancelInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.noticeNo, test.noticeNo);
                builder.append(this.noticeInfo, test.noticeInfo);
                builder.append(this.checkId, test.checkId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetFundaccountCancelInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String fundAccount;

        public GetFundaccountCancelInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getClientId() {
            return this.clientId;
        }

        public String getFundAccount() {
            return this.fundAccount;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetFundaccountCancelInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.clientId);
            builder.append(this.fundAccount);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.GetFundaccountCancelInnerInput) {
                InnerDfzqService.GetFundaccountCancelInnerInput test = (InnerDfzqService.GetFundaccountCancelInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.clientId, test.clientId);
                builder.append(this.fundAccount, test.fundAccount);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetCodeInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String prodtaNo = " ";
        private String prodCode = " ";
        private Integer updateDate = 0;
        private Integer updateTime = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character taType = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character prodcodeType = ' ';
        private String prodcodeSubType = " ";
        private String prodTypeAss = " ";
        private String prodName = " ";
        private String prodFullName = " ";
        private String prodcompanyName = " ";
        private String prodrelativeCode = " ";
        private Integer refereeValue = 0;
        private Integer prodRange = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character prodStatus = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character prodShelfStatus = ' ';
        private String moneyType = " ";
        private Integer issueDate = 0;
        @SerializeDoubleDigit(
                digit = 8
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double prodpreRatio = 0.0D;
        private Integer prodBeginDate = 0;
        private Integer prodEndDate = 0;
        private Integer ipoBeginDate = 0;
        private Integer ipoEndDate = 0;
        private Integer ipoBeginTime = 0;
        private Integer ipoEndTime = 0;
        private Integer interestBeginDate = 0;
        private Integer interestEndDate = 0;
        private Integer dividDate = 0;
        private Integer drDate = 0;
        private Integer cashDate = 0;
        @SerializeDoubleDigit(
                digit = 8
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double issuePrice = 0.0D;
        @SerializeDoubleDigit(
                digit = 8
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double parValue = 0.0D;
        private String prodSponsor = " ";
        private String prodManager = " ";
        private String prodTrustee = " ";
        private String trusteeBank = " ";
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double prodMinBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double prodMaxBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double perSubUnit = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double orgSubUnit = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double perAppUnit = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double orgAppUnit = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double minPerfsubBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double minOrgfsubBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double minPerfappBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double minOrgfappBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double minPersubBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double appendPersubBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double minOrgsubBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double appendOrgsubBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double minPerappBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double appendPerappBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double minOrgappBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double appendOrgappBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double perOnesubMaxBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double orgOnesubMaxBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double perOneappMaxBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double orgOneappMaxBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double perOneredMaxShare = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double orgOneredMaxShare = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double perSumsubBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double orgSumsubBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double perSumappBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double orgSumappBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double maxPerdsubBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double maxOrgdsubBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double maxPerdappBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double maxOrgdappBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double maxPerdredShare = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double maxOrgdredShare = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double perholdUpLimit = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double orgholdUpLimit = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double minTimerBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double maxTimerBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double redeemLimitshare = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double redeemUnit = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double transLimitshare = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double switchUnit = 0.0D;
        private String enChangeCode = " ";
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double currentAmountLow = 0.0D;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character dividendWay = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character chargeType = ' ';
        private Integer yearDays = 0;
        private Integer prodTerm = 0;
        private Integer coolingPeriod = 0;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double minSwitchInBalance = 0.0D;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character prodtransStatus = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character periodStatus = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character retrusteeStatus = ' ';
        @SerializeDoubleDigit(
                digit = 4
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double prodScale = 0.0D;
        private String preIncomeDesc = " ";
        private String agentFlag = " ";
        @SerializeDoubleDigit(
                digit = 8
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double netValue = 0.0D;
        private String enSmartRationType = " ";
        private String prodaliasName = " ";
        private String svrProdType = " ";
        private Integer trialDays = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character refundKind = ' ';
        private Integer trialReorderMaxTime = 0;
        private Integer formalReorderMaxTime = 0;
        private String prodcodeSubTypeAlias = " ";

        public GetCodeInnerOutput() {
        }

        public String getProdtaNo() {
            if (this.prodtaNo == null) {
                return " ";
            } else {
                return this.prodtaNo.isEmpty() ? " " : this.prodtaNo;
            }
        }

        public String getProdCode() {
            if (this.prodCode == null) {
                return " ";
            } else {
                return this.prodCode.isEmpty() ? " " : this.prodCode;
            }
        }

        public Integer getUpdateDate() {
            return this.updateDate != null ? this.updateDate : 0;
        }

        public Integer getUpdateTime() {
            return this.updateTime != null ? this.updateTime : 0;
        }

        public Character getTaType() {
            return this.taType != null ? this.taType : ' ';
        }

        public Character getProdcodeType() {
            return this.prodcodeType != null ? this.prodcodeType : ' ';
        }

        public String getProdcodeSubType() {
            if (this.prodcodeSubType == null) {
                return " ";
            } else {
                return this.prodcodeSubType.isEmpty() ? " " : this.prodcodeSubType;
            }
        }

        public String getProdTypeAss() {
            if (this.prodTypeAss == null) {
                return " ";
            } else {
                return this.prodTypeAss.isEmpty() ? " " : this.prodTypeAss;
            }
        }

        public String getProdName() {
            if (this.prodName == null) {
                return " ";
            } else {
                return this.prodName.isEmpty() ? " " : this.prodName;
            }
        }

        public String getProdFullName() {
            if (this.prodFullName == null) {
                return " ";
            } else {
                return this.prodFullName.isEmpty() ? " " : this.prodFullName;
            }
        }

        public String getProdcompanyName() {
            if (this.prodcompanyName == null) {
                return " ";
            } else {
                return this.prodcompanyName.isEmpty() ? " " : this.prodcompanyName;
            }
        }

        public String getProdrelativeCode() {
            if (this.prodrelativeCode == null) {
                return " ";
            } else {
                return this.prodrelativeCode.isEmpty() ? " " : this.prodrelativeCode;
            }
        }

        public Integer getRefereeValue() {
            return this.refereeValue != null ? this.refereeValue : 0;
        }

        public Integer getProdRange() {
            return this.prodRange != null ? this.prodRange : 0;
        }

        public Character getProdStatus() {
            return this.prodStatus != null ? this.prodStatus : ' ';
        }

        public Character getProdShelfStatus() {
            return this.prodShelfStatus != null ? this.prodShelfStatus : ' ';
        }

        public String getMoneyType() {
            if (this.moneyType == null) {
                return " ";
            } else {
                return this.moneyType.isEmpty() ? " " : this.moneyType;
            }
        }

        public Integer getIssueDate() {
            return this.issueDate != null ? this.issueDate : 0;
        }

        public Double getProdpreRatio() {
            return this.prodpreRatio != null ? this.prodpreRatio : 0.0D;
        }

        public Integer getProdBeginDate() {
            return this.prodBeginDate != null ? this.prodBeginDate : 0;
        }

        public Integer getProdEndDate() {
            return this.prodEndDate != null ? this.prodEndDate : 0;
        }

        public Integer getIpoBeginDate() {
            return this.ipoBeginDate != null ? this.ipoBeginDate : 0;
        }

        public Integer getIpoEndDate() {
            return this.ipoEndDate != null ? this.ipoEndDate : 0;
        }

        public Integer getIpoBeginTime() {
            return this.ipoBeginTime != null ? this.ipoBeginTime : 0;
        }

        public Integer getIpoEndTime() {
            return this.ipoEndTime != null ? this.ipoEndTime : 0;
        }

        public Integer getInterestBeginDate() {
            return this.interestBeginDate != null ? this.interestBeginDate : 0;
        }

        public Integer getInterestEndDate() {
            return this.interestEndDate != null ? this.interestEndDate : 0;
        }

        public Integer getDividDate() {
            return this.dividDate != null ? this.dividDate : 0;
        }

        public Integer getDrDate() {
            return this.drDate != null ? this.drDate : 0;
        }

        public Integer getCashDate() {
            return this.cashDate != null ? this.cashDate : 0;
        }

        public Double getIssuePrice() {
            return this.issuePrice != null ? this.issuePrice : 0.0D;
        }

        public Double getParValue() {
            return this.parValue != null ? this.parValue : 0.0D;
        }

        public String getProdSponsor() {
            if (this.prodSponsor == null) {
                return " ";
            } else {
                return this.prodSponsor.isEmpty() ? " " : this.prodSponsor;
            }
        }

        public String getProdManager() {
            if (this.prodManager == null) {
                return " ";
            } else {
                return this.prodManager.isEmpty() ? " " : this.prodManager;
            }
        }

        public String getProdTrustee() {
            if (this.prodTrustee == null) {
                return " ";
            } else {
                return this.prodTrustee.isEmpty() ? " " : this.prodTrustee;
            }
        }

        public String getTrusteeBank() {
            if (this.trusteeBank == null) {
                return " ";
            } else {
                return this.trusteeBank.isEmpty() ? " " : this.trusteeBank;
            }
        }

        public Double getProdMinBalance() {
            return this.prodMinBalance != null ? this.prodMinBalance : 0.0D;
        }

        public Double getProdMaxBalance() {
            return this.prodMaxBalance != null ? this.prodMaxBalance : 0.0D;
        }

        public Double getPerSubUnit() {
            return this.perSubUnit != null ? this.perSubUnit : 0.0D;
        }

        public Double getOrgSubUnit() {
            return this.orgSubUnit != null ? this.orgSubUnit : 0.0D;
        }

        public Double getPerAppUnit() {
            return this.perAppUnit != null ? this.perAppUnit : 0.0D;
        }

        public Double getOrgAppUnit() {
            return this.orgAppUnit != null ? this.orgAppUnit : 0.0D;
        }

        public Double getMinPerfsubBalance() {
            return this.minPerfsubBalance != null ? this.minPerfsubBalance : 0.0D;
        }

        public Double getMinOrgfsubBalance() {
            return this.minOrgfsubBalance != null ? this.minOrgfsubBalance : 0.0D;
        }

        public Double getMinPerfappBalance() {
            return this.minPerfappBalance != null ? this.minPerfappBalance : 0.0D;
        }

        public Double getMinOrgfappBalance() {
            return this.minOrgfappBalance != null ? this.minOrgfappBalance : 0.0D;
        }

        public Double getMinPersubBalance() {
            return this.minPersubBalance != null ? this.minPersubBalance : 0.0D;
        }

        public Double getAppendPersubBalance() {
            return this.appendPersubBalance != null ? this.appendPersubBalance : 0.0D;
        }

        public Double getMinOrgsubBalance() {
            return this.minOrgsubBalance != null ? this.minOrgsubBalance : 0.0D;
        }

        public Double getAppendOrgsubBalance() {
            return this.appendOrgsubBalance != null ? this.appendOrgsubBalance : 0.0D;
        }

        public Double getMinPerappBalance() {
            return this.minPerappBalance != null ? this.minPerappBalance : 0.0D;
        }

        public Double getAppendPerappBalance() {
            return this.appendPerappBalance != null ? this.appendPerappBalance : 0.0D;
        }

        public Double getMinOrgappBalance() {
            return this.minOrgappBalance != null ? this.minOrgappBalance : 0.0D;
        }

        public Double getAppendOrgappBalance() {
            return this.appendOrgappBalance != null ? this.appendOrgappBalance : 0.0D;
        }

        public Double getPerOnesubMaxBalance() {
            return this.perOnesubMaxBalance != null ? this.perOnesubMaxBalance : 0.0D;
        }

        public Double getOrgOnesubMaxBalance() {
            return this.orgOnesubMaxBalance != null ? this.orgOnesubMaxBalance : 0.0D;
        }

        public Double getPerOneappMaxBalance() {
            return this.perOneappMaxBalance != null ? this.perOneappMaxBalance : 0.0D;
        }

        public Double getOrgOneappMaxBalance() {
            return this.orgOneappMaxBalance != null ? this.orgOneappMaxBalance : 0.0D;
        }

        public Double getPerOneredMaxShare() {
            return this.perOneredMaxShare != null ? this.perOneredMaxShare : 0.0D;
        }

        public Double getOrgOneredMaxShare() {
            return this.orgOneredMaxShare != null ? this.orgOneredMaxShare : 0.0D;
        }

        public Double getPerSumsubBalance() {
            return this.perSumsubBalance != null ? this.perSumsubBalance : 0.0D;
        }

        public Double getOrgSumsubBalance() {
            return this.orgSumsubBalance != null ? this.orgSumsubBalance : 0.0D;
        }

        public Double getPerSumappBalance() {
            return this.perSumappBalance != null ? this.perSumappBalance : 0.0D;
        }

        public Double getOrgSumappBalance() {
            return this.orgSumappBalance != null ? this.orgSumappBalance : 0.0D;
        }

        public Double getMaxPerdsubBalance() {
            return this.maxPerdsubBalance != null ? this.maxPerdsubBalance : 0.0D;
        }

        public Double getMaxOrgdsubBalance() {
            return this.maxOrgdsubBalance != null ? this.maxOrgdsubBalance : 0.0D;
        }

        public Double getMaxPerdappBalance() {
            return this.maxPerdappBalance != null ? this.maxPerdappBalance : 0.0D;
        }

        public Double getMaxOrgdappBalance() {
            return this.maxOrgdappBalance != null ? this.maxOrgdappBalance : 0.0D;
        }

        public Double getMaxPerdredShare() {
            return this.maxPerdredShare != null ? this.maxPerdredShare : 0.0D;
        }

        public Double getMaxOrgdredShare() {
            return this.maxOrgdredShare != null ? this.maxOrgdredShare : 0.0D;
        }

        public Double getPerholdUpLimit() {
            return this.perholdUpLimit != null ? this.perholdUpLimit : 0.0D;
        }

        public Double getOrgholdUpLimit() {
            return this.orgholdUpLimit != null ? this.orgholdUpLimit : 0.0D;
        }

        public Double getMinTimerBalance() {
            return this.minTimerBalance != null ? this.minTimerBalance : 0.0D;
        }

        public Double getMaxTimerBalance() {
            return this.maxTimerBalance != null ? this.maxTimerBalance : 0.0D;
        }

        public Double getRedeemLimitshare() {
            return this.redeemLimitshare != null ? this.redeemLimitshare : 0.0D;
        }

        public Double getRedeemUnit() {
            return this.redeemUnit != null ? this.redeemUnit : 0.0D;
        }

        public Double getTransLimitshare() {
            return this.transLimitshare != null ? this.transLimitshare : 0.0D;
        }

        public Double getSwitchUnit() {
            return this.switchUnit != null ? this.switchUnit : 0.0D;
        }

        public String getEnChangeCode() {
            if (this.enChangeCode == null) {
                return " ";
            } else {
                return this.enChangeCode.isEmpty() ? " " : this.enChangeCode;
            }
        }

        public Double getCurrentAmountLow() {
            return this.currentAmountLow != null ? this.currentAmountLow : 0.0D;
        }

        public Character getDividendWay() {
            return this.dividendWay != null ? this.dividendWay : ' ';
        }

        public Character getChargeType() {
            return this.chargeType != null ? this.chargeType : ' ';
        }

        public Integer getYearDays() {
            return this.yearDays != null ? this.yearDays : 0;
        }

        public Integer getProdTerm() {
            return this.prodTerm != null ? this.prodTerm : 0;
        }

        public Integer getCoolingPeriod() {
            return this.coolingPeriod != null ? this.coolingPeriod : 0;
        }

        public Double getMinSwitchInBalance() {
            return this.minSwitchInBalance != null ? this.minSwitchInBalance : 0.0D;
        }

        public Character getProdtransStatus() {
            return this.prodtransStatus != null ? this.prodtransStatus : ' ';
        }

        public Character getPeriodStatus() {
            return this.periodStatus != null ? this.periodStatus : ' ';
        }

        public Character getRetrusteeStatus() {
            return this.retrusteeStatus != null ? this.retrusteeStatus : ' ';
        }

        public Double getProdScale() {
            return this.prodScale != null ? this.prodScale : 0.0D;
        }

        public String getPreIncomeDesc() {
            if (this.preIncomeDesc == null) {
                return " ";
            } else {
                return this.preIncomeDesc.isEmpty() ? " " : this.preIncomeDesc;
            }
        }

        public String getAgentFlag() {
            if (this.agentFlag == null) {
                return " ";
            } else {
                return this.agentFlag.isEmpty() ? " " : this.agentFlag;
            }
        }

        public Double getNetValue() {
            return this.netValue != null ? this.netValue : 0.0D;
        }

        public String getEnSmartRationType() {
            if (this.enSmartRationType == null) {
                return " ";
            } else {
                return this.enSmartRationType.isEmpty() ? " " : this.enSmartRationType;
            }
        }

        public String getProdaliasName() {
            if (this.prodaliasName == null) {
                return " ";
            } else {
                return this.prodaliasName.isEmpty() ? " " : this.prodaliasName;
            }
        }

        public String getSvrProdType() {
            if (this.svrProdType == null) {
                return " ";
            } else {
                return this.svrProdType.isEmpty() ? " " : this.svrProdType;
            }
        }

        public Integer getTrialDays() {
            return this.trialDays != null ? this.trialDays : 0;
        }

        public Character getRefundKind() {
            return this.refundKind != null ? this.refundKind : ' ';
        }

        public Integer getTrialReorderMaxTime() {
            return this.trialReorderMaxTime != null ? this.trialReorderMaxTime : 0;
        }

        public Integer getFormalReorderMaxTime() {
            return this.formalReorderMaxTime != null ? this.formalReorderMaxTime : 0;
        }

        public String getProdcodeSubTypeAlias() {
            if (this.prodcodeSubTypeAlias == null) {
                return " ";
            } else {
                return this.prodcodeSubTypeAlias.isEmpty() ? " " : this.prodcodeSubTypeAlias;
            }
        }

        public void setProdtaNo(String prodtaNo) {
            this.prodtaNo = prodtaNo;
        }

        public void setProdCode(String prodCode) {
            this.prodCode = prodCode;
        }

        public void setUpdateDate(Integer updateDate) {
            this.updateDate = updateDate;
        }

        public void setUpdateTime(Integer updateTime) {
            this.updateTime = updateTime;
        }

        public void setTaType(Character taType) {
            this.taType = taType;
        }

        public void setProdcodeType(Character prodcodeType) {
            this.prodcodeType = prodcodeType;
        }

        public void setProdcodeSubType(String prodcodeSubType) {
            this.prodcodeSubType = prodcodeSubType;
        }

        public void setProdTypeAss(String prodTypeAss) {
            this.prodTypeAss = prodTypeAss;
        }

        public void setProdName(String prodName) {
            this.prodName = prodName;
        }

        public void setProdFullName(String prodFullName) {
            this.prodFullName = prodFullName;
        }

        public void setProdcompanyName(String prodcompanyName) {
            this.prodcompanyName = prodcompanyName;
        }

        public void setProdrelativeCode(String prodrelativeCode) {
            this.prodrelativeCode = prodrelativeCode;
        }

        public void setRefereeValue(Integer refereeValue) {
            this.refereeValue = refereeValue;
        }

        public void setProdRange(Integer prodRange) {
            this.prodRange = prodRange;
        }

        public void setProdStatus(Character prodStatus) {
            this.prodStatus = prodStatus;
        }

        public void setProdShelfStatus(Character prodShelfStatus) {
            this.prodShelfStatus = prodShelfStatus;
        }

        public void setMoneyType(String moneyType) {
            this.moneyType = moneyType;
        }

        public void setIssueDate(Integer issueDate) {
            this.issueDate = issueDate;
        }

        public void setProdpreRatio(Double prodpreRatio) {
            this.prodpreRatio = prodpreRatio;
        }

        public void setProdBeginDate(Integer prodBeginDate) {
            this.prodBeginDate = prodBeginDate;
        }

        public void setProdEndDate(Integer prodEndDate) {
            this.prodEndDate = prodEndDate;
        }

        public void setIpoBeginDate(Integer ipoBeginDate) {
            this.ipoBeginDate = ipoBeginDate;
        }

        public void setIpoEndDate(Integer ipoEndDate) {
            this.ipoEndDate = ipoEndDate;
        }

        public void setIpoBeginTime(Integer ipoBeginTime) {
            this.ipoBeginTime = ipoBeginTime;
        }

        public void setIpoEndTime(Integer ipoEndTime) {
            this.ipoEndTime = ipoEndTime;
        }

        public void setInterestBeginDate(Integer interestBeginDate) {
            this.interestBeginDate = interestBeginDate;
        }

        public void setInterestEndDate(Integer interestEndDate) {
            this.interestEndDate = interestEndDate;
        }

        public void setDividDate(Integer dividDate) {
            this.dividDate = dividDate;
        }

        public void setDrDate(Integer drDate) {
            this.drDate = drDate;
        }

        public void setCashDate(Integer cashDate) {
            this.cashDate = cashDate;
        }

        public void setIssuePrice(Double issuePrice) {
            this.issuePrice = issuePrice;
        }

        public void setParValue(Double parValue) {
            this.parValue = parValue;
        }

        public void setProdSponsor(String prodSponsor) {
            this.prodSponsor = prodSponsor;
        }

        public void setProdManager(String prodManager) {
            this.prodManager = prodManager;
        }

        public void setProdTrustee(String prodTrustee) {
            this.prodTrustee = prodTrustee;
        }

        public void setTrusteeBank(String trusteeBank) {
            this.trusteeBank = trusteeBank;
        }

        public void setProdMinBalance(Double prodMinBalance) {
            this.prodMinBalance = prodMinBalance;
        }

        public void setProdMaxBalance(Double prodMaxBalance) {
            this.prodMaxBalance = prodMaxBalance;
        }

        public void setPerSubUnit(Double perSubUnit) {
            this.perSubUnit = perSubUnit;
        }

        public void setOrgSubUnit(Double orgSubUnit) {
            this.orgSubUnit = orgSubUnit;
        }

        public void setPerAppUnit(Double perAppUnit) {
            this.perAppUnit = perAppUnit;
        }

        public void setOrgAppUnit(Double orgAppUnit) {
            this.orgAppUnit = orgAppUnit;
        }

        public void setMinPerfsubBalance(Double minPerfsubBalance) {
            this.minPerfsubBalance = minPerfsubBalance;
        }

        public void setMinOrgfsubBalance(Double minOrgfsubBalance) {
            this.minOrgfsubBalance = minOrgfsubBalance;
        }

        public void setMinPerfappBalance(Double minPerfappBalance) {
            this.minPerfappBalance = minPerfappBalance;
        }

        public void setMinOrgfappBalance(Double minOrgfappBalance) {
            this.minOrgfappBalance = minOrgfappBalance;
        }

        public void setMinPersubBalance(Double minPersubBalance) {
            this.minPersubBalance = minPersubBalance;
        }

        public void setAppendPersubBalance(Double appendPersubBalance) {
            this.appendPersubBalance = appendPersubBalance;
        }

        public void setMinOrgsubBalance(Double minOrgsubBalance) {
            this.minOrgsubBalance = minOrgsubBalance;
        }

        public void setAppendOrgsubBalance(Double appendOrgsubBalance) {
            this.appendOrgsubBalance = appendOrgsubBalance;
        }

        public void setMinPerappBalance(Double minPerappBalance) {
            this.minPerappBalance = minPerappBalance;
        }

        public void setAppendPerappBalance(Double appendPerappBalance) {
            this.appendPerappBalance = appendPerappBalance;
        }

        public void setMinOrgappBalance(Double minOrgappBalance) {
            this.minOrgappBalance = minOrgappBalance;
        }

        public void setAppendOrgappBalance(Double appendOrgappBalance) {
            this.appendOrgappBalance = appendOrgappBalance;
        }

        public void setPerOnesubMaxBalance(Double perOnesubMaxBalance) {
            this.perOnesubMaxBalance = perOnesubMaxBalance;
        }

        public void setOrgOnesubMaxBalance(Double orgOnesubMaxBalance) {
            this.orgOnesubMaxBalance = orgOnesubMaxBalance;
        }

        public void setPerOneappMaxBalance(Double perOneappMaxBalance) {
            this.perOneappMaxBalance = perOneappMaxBalance;
        }

        public void setOrgOneappMaxBalance(Double orgOneappMaxBalance) {
            this.orgOneappMaxBalance = orgOneappMaxBalance;
        }

        public void setPerOneredMaxShare(Double perOneredMaxShare) {
            this.perOneredMaxShare = perOneredMaxShare;
        }

        public void setOrgOneredMaxShare(Double orgOneredMaxShare) {
            this.orgOneredMaxShare = orgOneredMaxShare;
        }

        public void setPerSumsubBalance(Double perSumsubBalance) {
            this.perSumsubBalance = perSumsubBalance;
        }

        public void setOrgSumsubBalance(Double orgSumsubBalance) {
            this.orgSumsubBalance = orgSumsubBalance;
        }

        public void setPerSumappBalance(Double perSumappBalance) {
            this.perSumappBalance = perSumappBalance;
        }

        public void setOrgSumappBalance(Double orgSumappBalance) {
            this.orgSumappBalance = orgSumappBalance;
        }

        public void setMaxPerdsubBalance(Double maxPerdsubBalance) {
            this.maxPerdsubBalance = maxPerdsubBalance;
        }

        public void setMaxOrgdsubBalance(Double maxOrgdsubBalance) {
            this.maxOrgdsubBalance = maxOrgdsubBalance;
        }

        public void setMaxPerdappBalance(Double maxPerdappBalance) {
            this.maxPerdappBalance = maxPerdappBalance;
        }

        public void setMaxOrgdappBalance(Double maxOrgdappBalance) {
            this.maxOrgdappBalance = maxOrgdappBalance;
        }

        public void setMaxPerdredShare(Double maxPerdredShare) {
            this.maxPerdredShare = maxPerdredShare;
        }

        public void setMaxOrgdredShare(Double maxOrgdredShare) {
            this.maxOrgdredShare = maxOrgdredShare;
        }

        public void setPerholdUpLimit(Double perholdUpLimit) {
            this.perholdUpLimit = perholdUpLimit;
        }

        public void setOrgholdUpLimit(Double orgholdUpLimit) {
            this.orgholdUpLimit = orgholdUpLimit;
        }

        public void setMinTimerBalance(Double minTimerBalance) {
            this.minTimerBalance = minTimerBalance;
        }

        public void setMaxTimerBalance(Double maxTimerBalance) {
            this.maxTimerBalance = maxTimerBalance;
        }

        public void setRedeemLimitshare(Double redeemLimitshare) {
            this.redeemLimitshare = redeemLimitshare;
        }

        public void setRedeemUnit(Double redeemUnit) {
            this.redeemUnit = redeemUnit;
        }

        public void setTransLimitshare(Double transLimitshare) {
            this.transLimitshare = transLimitshare;
        }

        public void setSwitchUnit(Double switchUnit) {
            this.switchUnit = switchUnit;
        }

        public void setEnChangeCode(String enChangeCode) {
            this.enChangeCode = enChangeCode;
        }

        public void setCurrentAmountLow(Double currentAmountLow) {
            this.currentAmountLow = currentAmountLow;
        }

        public void setDividendWay(Character dividendWay) {
            this.dividendWay = dividendWay;
        }

        public void setChargeType(Character chargeType) {
            this.chargeType = chargeType;
        }

        public void setYearDays(Integer yearDays) {
            this.yearDays = yearDays;
        }

        public void setProdTerm(Integer prodTerm) {
            this.prodTerm = prodTerm;
        }

        public void setCoolingPeriod(Integer coolingPeriod) {
            this.coolingPeriod = coolingPeriod;
        }

        public void setMinSwitchInBalance(Double minSwitchInBalance) {
            this.minSwitchInBalance = minSwitchInBalance;
        }

        public void setProdtransStatus(Character prodtransStatus) {
            this.prodtransStatus = prodtransStatus;
        }

        public void setPeriodStatus(Character periodStatus) {
            this.periodStatus = periodStatus;
        }

        public void setRetrusteeStatus(Character retrusteeStatus) {
            this.retrusteeStatus = retrusteeStatus;
        }

        public void setProdScale(Double prodScale) {
            this.prodScale = prodScale;
        }

        public void setPreIncomeDesc(String preIncomeDesc) {
            this.preIncomeDesc = preIncomeDesc;
        }

        public void setAgentFlag(String agentFlag) {
            this.agentFlag = agentFlag;
        }

        public void setNetValue(Double netValue) {
            this.netValue = netValue;
        }

        public void setEnSmartRationType(String enSmartRationType) {
            this.enSmartRationType = enSmartRationType;
        }

        public void setProdaliasName(String prodaliasName) {
            this.prodaliasName = prodaliasName;
        }

        public void setSvrProdType(String svrProdType) {
            this.svrProdType = svrProdType;
        }

        public void setTrialDays(Integer trialDays) {
            this.trialDays = trialDays;
        }

        public void setRefundKind(Character refundKind) {
            this.refundKind = refundKind;
        }

        public void setTrialReorderMaxTime(Integer trialReorderMaxTime) {
            this.trialReorderMaxTime = trialReorderMaxTime;
        }

        public void setFormalReorderMaxTime(Integer formalReorderMaxTime) {
            this.formalReorderMaxTime = formalReorderMaxTime;
        }

        public void setProdcodeSubTypeAlias(String prodcodeSubTypeAlias) {
            this.prodcodeSubTypeAlias = prodcodeSubTypeAlias;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetCodeInnerOutput:(");
            buffer.append("prodtaNo:" + this.prodtaNo);
            buffer.append(",prodCode:" + this.prodCode);
            buffer.append(",updateDate:" + this.updateDate);
            buffer.append(",updateTime:" + this.updateTime);
            buffer.append(",taType:" + this.taType);
            buffer.append(",prodcodeType:" + this.prodcodeType);
            buffer.append(",prodcodeSubType:" + this.prodcodeSubType);
            buffer.append(",prodTypeAss:" + this.prodTypeAss);
            buffer.append(",prodName:" + this.prodName);
            buffer.append(",prodFullName:" + this.prodFullName);
            buffer.append(",prodcompanyName:" + this.prodcompanyName);
            buffer.append(",prodrelativeCode:" + this.prodrelativeCode);
            buffer.append(",refereeValue:" + this.refereeValue);
            buffer.append(",prodRange:" + this.prodRange);
            buffer.append(",prodStatus:" + this.prodStatus);
            buffer.append(",prodShelfStatus:" + this.prodShelfStatus);
            buffer.append(",moneyType:" + this.moneyType);
            buffer.append(",issueDate:" + this.issueDate);
            buffer.append(",prodpreRatio:" + this.prodpreRatio);
            buffer.append(",prodBeginDate:" + this.prodBeginDate);
            buffer.append(",prodEndDate:" + this.prodEndDate);
            buffer.append(",ipoBeginDate:" + this.ipoBeginDate);
            buffer.append(",ipoEndDate:" + this.ipoEndDate);
            buffer.append(",ipoBeginTime:" + this.ipoBeginTime);
            buffer.append(",ipoEndTime:" + this.ipoEndTime);
            buffer.append(",interestBeginDate:" + this.interestBeginDate);
            buffer.append(",interestEndDate:" + this.interestEndDate);
            buffer.append(",dividDate:" + this.dividDate);
            buffer.append(",drDate:" + this.drDate);
            buffer.append(",cashDate:" + this.cashDate);
            buffer.append(",issuePrice:" + this.issuePrice);
            buffer.append(",parValue:" + this.parValue);
            buffer.append(",prodSponsor:" + this.prodSponsor);
            buffer.append(",prodManager:" + this.prodManager);
            buffer.append(",prodTrustee:" + this.prodTrustee);
            buffer.append(",trusteeBank:" + this.trusteeBank);
            buffer.append(",prodMinBalance:" + this.prodMinBalance);
            buffer.append(",prodMaxBalance:" + this.prodMaxBalance);
            buffer.append(",perSubUnit:" + this.perSubUnit);
            buffer.append(",orgSubUnit:" + this.orgSubUnit);
            buffer.append(",perAppUnit:" + this.perAppUnit);
            buffer.append(",orgAppUnit:" + this.orgAppUnit);
            buffer.append(",minPerfsubBalance:" + this.minPerfsubBalance);
            buffer.append(",minOrgfsubBalance:" + this.minOrgfsubBalance);
            buffer.append(",minPerfappBalance:" + this.minPerfappBalance);
            buffer.append(",minOrgfappBalance:" + this.minOrgfappBalance);
            buffer.append(",minPersubBalance:" + this.minPersubBalance);
            buffer.append(",appendPersubBalance:" + this.appendPersubBalance);
            buffer.append(",minOrgsubBalance:" + this.minOrgsubBalance);
            buffer.append(",appendOrgsubBalance:" + this.appendOrgsubBalance);
            buffer.append(",minPerappBalance:" + this.minPerappBalance);
            buffer.append(",appendPerappBalance:" + this.appendPerappBalance);
            buffer.append(",minOrgappBalance:" + this.minOrgappBalance);
            buffer.append(",appendOrgappBalance:" + this.appendOrgappBalance);
            buffer.append(",perOnesubMaxBalance:" + this.perOnesubMaxBalance);
            buffer.append(",orgOnesubMaxBalance:" + this.orgOnesubMaxBalance);
            buffer.append(",perOneappMaxBalance:" + this.perOneappMaxBalance);
            buffer.append(",orgOneappMaxBalance:" + this.orgOneappMaxBalance);
            buffer.append(",perOneredMaxShare:" + this.perOneredMaxShare);
            buffer.append(",orgOneredMaxShare:" + this.orgOneredMaxShare);
            buffer.append(",perSumsubBalance:" + this.perSumsubBalance);
            buffer.append(",orgSumsubBalance:" + this.orgSumsubBalance);
            buffer.append(",perSumappBalance:" + this.perSumappBalance);
            buffer.append(",orgSumappBalance:" + this.orgSumappBalance);
            buffer.append(",maxPerdsubBalance:" + this.maxPerdsubBalance);
            buffer.append(",maxOrgdsubBalance:" + this.maxOrgdsubBalance);
            buffer.append(",maxPerdappBalance:" + this.maxPerdappBalance);
            buffer.append(",maxOrgdappBalance:" + this.maxOrgdappBalance);
            buffer.append(",maxPerdredShare:" + this.maxPerdredShare);
            buffer.append(",maxOrgdredShare:" + this.maxOrgdredShare);
            buffer.append(",perholdUpLimit:" + this.perholdUpLimit);
            buffer.append(",orgholdUpLimit:" + this.orgholdUpLimit);
            buffer.append(",minTimerBalance:" + this.minTimerBalance);
            buffer.append(",maxTimerBalance:" + this.maxTimerBalance);
            buffer.append(",redeemLimitshare:" + this.redeemLimitshare);
            buffer.append(",redeemUnit:" + this.redeemUnit);
            buffer.append(",transLimitshare:" + this.transLimitshare);
            buffer.append(",switchUnit:" + this.switchUnit);
            buffer.append(",enChangeCode:" + this.enChangeCode);
            buffer.append(",currentAmountLow:" + this.currentAmountLow);
            buffer.append(",dividendWay:" + this.dividendWay);
            buffer.append(",chargeType:" + this.chargeType);
            buffer.append(",yearDays:" + this.yearDays);
            buffer.append(",prodTerm:" + this.prodTerm);
            buffer.append(",coolingPeriod:" + this.coolingPeriod);
            buffer.append(",minSwitchInBalance:" + this.minSwitchInBalance);
            buffer.append(",prodtransStatus:" + this.prodtransStatus);
            buffer.append(",periodStatus:" + this.periodStatus);
            buffer.append(",retrusteeStatus:" + this.retrusteeStatus);
            buffer.append(",prodScale:" + this.prodScale);
            buffer.append(",preIncomeDesc:" + this.preIncomeDesc);
            buffer.append(",agentFlag:" + this.agentFlag);
            buffer.append(",netValue:" + this.netValue);
            buffer.append(",enSmartRationType:" + this.enSmartRationType);
            buffer.append(",prodaliasName:" + this.prodaliasName);
            buffer.append(",svrProdType:" + this.svrProdType);
            buffer.append(",trialDays:" + this.trialDays);
            buffer.append(",refundKind:" + this.refundKind);
            buffer.append(",trialReorderMaxTime:" + this.trialReorderMaxTime);
            buffer.append(",formalReorderMaxTime:" + this.formalReorderMaxTime);
            buffer.append(",prodcodeSubTypeAlias:" + this.prodcodeSubTypeAlias);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.prodtaNo);
            builder.append(this.prodCode);
            builder.append(this.updateDate);
            builder.append(this.updateTime);
            builder.append(this.taType);
            builder.append(this.prodcodeType);
            builder.append(this.prodcodeSubType);
            builder.append(this.prodTypeAss);
            builder.append(this.prodName);
            builder.append(this.prodFullName);
            builder.append(this.prodcompanyName);
            builder.append(this.prodrelativeCode);
            builder.append(this.refereeValue);
            builder.append(this.prodRange);
            builder.append(this.prodStatus);
            builder.append(this.prodShelfStatus);
            builder.append(this.moneyType);
            builder.append(this.issueDate);
            builder.append(this.prodpreRatio);
            builder.append(this.prodBeginDate);
            builder.append(this.prodEndDate);
            builder.append(this.ipoBeginDate);
            builder.append(this.ipoEndDate);
            builder.append(this.ipoBeginTime);
            builder.append(this.ipoEndTime);
            builder.append(this.interestBeginDate);
            builder.append(this.interestEndDate);
            builder.append(this.dividDate);
            builder.append(this.drDate);
            builder.append(this.cashDate);
            builder.append(this.issuePrice);
            builder.append(this.parValue);
            builder.append(this.prodSponsor);
            builder.append(this.prodManager);
            builder.append(this.prodTrustee);
            builder.append(this.trusteeBank);
            builder.append(this.prodMinBalance);
            builder.append(this.prodMaxBalance);
            builder.append(this.perSubUnit);
            builder.append(this.orgSubUnit);
            builder.append(this.perAppUnit);
            builder.append(this.orgAppUnit);
            builder.append(this.minPerfsubBalance);
            builder.append(this.minOrgfsubBalance);
            builder.append(this.minPerfappBalance);
            builder.append(this.minOrgfappBalance);
            builder.append(this.minPersubBalance);
            builder.append(this.appendPersubBalance);
            builder.append(this.minOrgsubBalance);
            builder.append(this.appendOrgsubBalance);
            builder.append(this.minPerappBalance);
            builder.append(this.appendPerappBalance);
            builder.append(this.minOrgappBalance);
            builder.append(this.appendOrgappBalance);
            builder.append(this.perOnesubMaxBalance);
            builder.append(this.orgOnesubMaxBalance);
            builder.append(this.perOneappMaxBalance);
            builder.append(this.orgOneappMaxBalance);
            builder.append(this.perOneredMaxShare);
            builder.append(this.orgOneredMaxShare);
            builder.append(this.perSumsubBalance);
            builder.append(this.orgSumsubBalance);
            builder.append(this.perSumappBalance);
            builder.append(this.orgSumappBalance);
            builder.append(this.maxPerdsubBalance);
            builder.append(this.maxOrgdsubBalance);
            builder.append(this.maxPerdappBalance);
            builder.append(this.maxOrgdappBalance);
            builder.append(this.maxPerdredShare);
            builder.append(this.maxOrgdredShare);
            builder.append(this.perholdUpLimit);
            builder.append(this.orgholdUpLimit);
            builder.append(this.minTimerBalance);
            builder.append(this.maxTimerBalance);
            builder.append(this.redeemLimitshare);
            builder.append(this.redeemUnit);
            builder.append(this.transLimitshare);
            builder.append(this.switchUnit);
            builder.append(this.enChangeCode);
            builder.append(this.currentAmountLow);
            builder.append(this.dividendWay);
            builder.append(this.chargeType);
            builder.append(this.yearDays);
            builder.append(this.prodTerm);
            builder.append(this.coolingPeriod);
            builder.append(this.minSwitchInBalance);
            builder.append(this.prodtransStatus);
            builder.append(this.periodStatus);
            builder.append(this.retrusteeStatus);
            builder.append(this.prodScale);
            builder.append(this.preIncomeDesc);
            builder.append(this.agentFlag);
            builder.append(this.netValue);
            builder.append(this.enSmartRationType);
            builder.append(this.prodaliasName);
            builder.append(this.svrProdType);
            builder.append(this.trialDays);
            builder.append(this.refundKind);
            builder.append(this.trialReorderMaxTime);
            builder.append(this.formalReorderMaxTime);
            builder.append(this.prodcodeSubTypeAlias);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.GetCodeInnerOutput) {
                InnerDfzqService.GetCodeInnerOutput test = (InnerDfzqService.GetCodeInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.prodtaNo, test.prodtaNo);
                builder.append(this.prodCode, test.prodCode);
                builder.append(this.updateDate, test.updateDate);
                builder.append(this.updateTime, test.updateTime);
                builder.append(this.taType, test.taType);
                builder.append(this.prodcodeType, test.prodcodeType);
                builder.append(this.prodcodeSubType, test.prodcodeSubType);
                builder.append(this.prodTypeAss, test.prodTypeAss);
                builder.append(this.prodName, test.prodName);
                builder.append(this.prodFullName, test.prodFullName);
                builder.append(this.prodcompanyName, test.prodcompanyName);
                builder.append(this.prodrelativeCode, test.prodrelativeCode);
                builder.append(this.refereeValue, test.refereeValue);
                builder.append(this.prodRange, test.prodRange);
                builder.append(this.prodStatus, test.prodStatus);
                builder.append(this.prodShelfStatus, test.prodShelfStatus);
                builder.append(this.moneyType, test.moneyType);
                builder.append(this.issueDate, test.issueDate);
                builder.append(this.prodpreRatio, test.prodpreRatio);
                builder.append(this.prodBeginDate, test.prodBeginDate);
                builder.append(this.prodEndDate, test.prodEndDate);
                builder.append(this.ipoBeginDate, test.ipoBeginDate);
                builder.append(this.ipoEndDate, test.ipoEndDate);
                builder.append(this.ipoBeginTime, test.ipoBeginTime);
                builder.append(this.ipoEndTime, test.ipoEndTime);
                builder.append(this.interestBeginDate, test.interestBeginDate);
                builder.append(this.interestEndDate, test.interestEndDate);
                builder.append(this.dividDate, test.dividDate);
                builder.append(this.drDate, test.drDate);
                builder.append(this.cashDate, test.cashDate);
                builder.append(this.issuePrice, test.issuePrice);
                builder.append(this.parValue, test.parValue);
                builder.append(this.prodSponsor, test.prodSponsor);
                builder.append(this.prodManager, test.prodManager);
                builder.append(this.prodTrustee, test.prodTrustee);
                builder.append(this.trusteeBank, test.trusteeBank);
                builder.append(this.prodMinBalance, test.prodMinBalance);
                builder.append(this.prodMaxBalance, test.prodMaxBalance);
                builder.append(this.perSubUnit, test.perSubUnit);
                builder.append(this.orgSubUnit, test.orgSubUnit);
                builder.append(this.perAppUnit, test.perAppUnit);
                builder.append(this.orgAppUnit, test.orgAppUnit);
                builder.append(this.minPerfsubBalance, test.minPerfsubBalance);
                builder.append(this.minOrgfsubBalance, test.minOrgfsubBalance);
                builder.append(this.minPerfappBalance, test.minPerfappBalance);
                builder.append(this.minOrgfappBalance, test.minOrgfappBalance);
                builder.append(this.minPersubBalance, test.minPersubBalance);
                builder.append(this.appendPersubBalance, test.appendPersubBalance);
                builder.append(this.minOrgsubBalance, test.minOrgsubBalance);
                builder.append(this.appendOrgsubBalance, test.appendOrgsubBalance);
                builder.append(this.minPerappBalance, test.minPerappBalance);
                builder.append(this.appendPerappBalance, test.appendPerappBalance);
                builder.append(this.minOrgappBalance, test.minOrgappBalance);
                builder.append(this.appendOrgappBalance, test.appendOrgappBalance);
                builder.append(this.perOnesubMaxBalance, test.perOnesubMaxBalance);
                builder.append(this.orgOnesubMaxBalance, test.orgOnesubMaxBalance);
                builder.append(this.perOneappMaxBalance, test.perOneappMaxBalance);
                builder.append(this.orgOneappMaxBalance, test.orgOneappMaxBalance);
                builder.append(this.perOneredMaxShare, test.perOneredMaxShare);
                builder.append(this.orgOneredMaxShare, test.orgOneredMaxShare);
                builder.append(this.perSumsubBalance, test.perSumsubBalance);
                builder.append(this.orgSumsubBalance, test.orgSumsubBalance);
                builder.append(this.perSumappBalance, test.perSumappBalance);
                builder.append(this.orgSumappBalance, test.orgSumappBalance);
                builder.append(this.maxPerdsubBalance, test.maxPerdsubBalance);
                builder.append(this.maxOrgdsubBalance, test.maxOrgdsubBalance);
                builder.append(this.maxPerdappBalance, test.maxPerdappBalance);
                builder.append(this.maxOrgdappBalance, test.maxOrgdappBalance);
                builder.append(this.maxPerdredShare, test.maxPerdredShare);
                builder.append(this.maxOrgdredShare, test.maxOrgdredShare);
                builder.append(this.perholdUpLimit, test.perholdUpLimit);
                builder.append(this.orgholdUpLimit, test.orgholdUpLimit);
                builder.append(this.minTimerBalance, test.minTimerBalance);
                builder.append(this.maxTimerBalance, test.maxTimerBalance);
                builder.append(this.redeemLimitshare, test.redeemLimitshare);
                builder.append(this.redeemUnit, test.redeemUnit);
                builder.append(this.transLimitshare, test.transLimitshare);
                builder.append(this.switchUnit, test.switchUnit);
                builder.append(this.enChangeCode, test.enChangeCode);
                builder.append(this.currentAmountLow, test.currentAmountLow);
                builder.append(this.dividendWay, test.dividendWay);
                builder.append(this.chargeType, test.chargeType);
                builder.append(this.yearDays, test.yearDays);
                builder.append(this.prodTerm, test.prodTerm);
                builder.append(this.coolingPeriod, test.coolingPeriod);
                builder.append(this.minSwitchInBalance, test.minSwitchInBalance);
                builder.append(this.prodtransStatus, test.prodtransStatus);
                builder.append(this.periodStatus, test.periodStatus);
                builder.append(this.retrusteeStatus, test.retrusteeStatus);
                builder.append(this.prodScale, test.prodScale);
                builder.append(this.preIncomeDesc, test.preIncomeDesc);
                builder.append(this.agentFlag, test.agentFlag);
                builder.append(this.netValue, test.netValue);
                builder.append(this.enSmartRationType, test.enSmartRationType);
                builder.append(this.prodaliasName, test.prodaliasName);
                builder.append(this.svrProdType, test.svrProdType);
                builder.append(this.trialDays, test.trialDays);
                builder.append(this.refundKind, test.refundKind);
                builder.append(this.trialReorderMaxTime, test.trialReorderMaxTime);
                builder.append(this.formalReorderMaxTime, test.formalReorderMaxTime);
                builder.append(this.prodcodeSubTypeAlias, test.prodcodeSubTypeAlias);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetCodeInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 1,
                max = 32,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String prodCode;

        public GetCodeInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getProdCode() {
            return this.prodCode;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setProdCode(String prodCode) {
            this.prodCode = prodCode;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetCodeInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",prodCode:" + this.prodCode);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.prodCode);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.GetCodeInnerInput) {
                InnerDfzqService.GetCodeInnerInput test = (InnerDfzqService.GetCodeInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.prodCode, test.prodCode);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetClientpreferMatchInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String agreementData = " ";
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double assetBalance = 0.0D;
        private String clientId = " ";
        private Integer coolingPeriod = 0;
        private Integer corpBeginDate = 0;
        private Integer corpEndDate = 0;
        private Integer corpRiskLevel = 0;
        private String eligCtrlstr = " ";
        private String enInvestKind = " ";
        private String enInvestTerm = " ";
        private String enProdriskLevel = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character enableFlag = ' ';
        private String fundAccount = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character investTerm = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character investKind = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character minRankFlag = ' ';
        private String prodCode = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character prodriskFlag = ' ';
        private Integer prodriskLevel = 0;
        private String prodtaNo = " ";
        private Integer profBeginDate = 0;
        private Integer profEndDate = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character profType = ' ';
        private Integer taRiskLevel = 0;
        private Integer riskEnddate = 0;
        private String eligCheckStr = " ";
        private String eligRemark = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character needVideoFlag = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character qualifiedInvestorFlag = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character cmsEligMatchFlag = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character profFlag = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character forceRiskMatchflag = ' ';
        private Integer bankRiskLevel = 0;
        private String riskMatchStr = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character spsurveyFlag = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character nominalHoldFlag = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character eligRiskFlag = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character eligInvestkindFlag = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character eligTermFlag = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character incomeType = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character eligIncomeFlag = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character clientIncomeType = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character senileFlag = ' ';
        private Integer pfRiskLevel = 0;
        private String enPfInvestKind = " ";
        private String enPfInvestTerm = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character forceRiskMatchflagBank = ' ';
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double minAssetNeed = 0.0D;
        private String enEntrustWay = " ";
        private String prodName = " ";
        private Integer prodTerm = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character prodcodeType = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character eligAssetFlag = ' ';

        public GetClientpreferMatchInnerOutput() {
        }

        public String getAgreementData() {
            if (this.agreementData == null) {
                return " ";
            } else {
                return this.agreementData.isEmpty() ? " " : this.agreementData;
            }
        }

        public Double getAssetBalance() {
            return this.assetBalance != null ? this.assetBalance : 0.0D;
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public Integer getCoolingPeriod() {
            return this.coolingPeriod != null ? this.coolingPeriod : 0;
        }

        public Integer getCorpBeginDate() {
            return this.corpBeginDate != null ? this.corpBeginDate : 0;
        }

        public Integer getCorpEndDate() {
            return this.corpEndDate != null ? this.corpEndDate : 0;
        }

        public Integer getCorpRiskLevel() {
            return this.corpRiskLevel != null ? this.corpRiskLevel : 0;
        }

        public String getEligCtrlstr() {
            if (this.eligCtrlstr == null) {
                return " ";
            } else {
                return this.eligCtrlstr.isEmpty() ? " " : this.eligCtrlstr;
            }
        }

        public String getEnInvestKind() {
            if (this.enInvestKind == null) {
                return " ";
            } else {
                return this.enInvestKind.isEmpty() ? " " : this.enInvestKind;
            }
        }

        public String getEnInvestTerm() {
            if (this.enInvestTerm == null) {
                return " ";
            } else {
                return this.enInvestTerm.isEmpty() ? " " : this.enInvestTerm;
            }
        }

        public String getEnProdriskLevel() {
            if (this.enProdriskLevel == null) {
                return " ";
            } else {
                return this.enProdriskLevel.isEmpty() ? " " : this.enProdriskLevel;
            }
        }

        public Character getEnableFlag() {
            return this.enableFlag != null ? this.enableFlag : ' ';
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public Character getInvestTerm() {
            return this.investTerm != null ? this.investTerm : ' ';
        }

        public Character getInvestKind() {
            return this.investKind != null ? this.investKind : ' ';
        }

        public Character getMinRankFlag() {
            return this.minRankFlag != null ? this.minRankFlag : ' ';
        }

        public String getProdCode() {
            if (this.prodCode == null) {
                return " ";
            } else {
                return this.prodCode.isEmpty() ? " " : this.prodCode;
            }
        }

        public Character getProdriskFlag() {
            return this.prodriskFlag != null ? this.prodriskFlag : ' ';
        }

        public Integer getProdriskLevel() {
            return this.prodriskLevel != null ? this.prodriskLevel : 0;
        }

        public String getProdtaNo() {
            if (this.prodtaNo == null) {
                return " ";
            } else {
                return this.prodtaNo.isEmpty() ? " " : this.prodtaNo;
            }
        }

        public Integer getProfBeginDate() {
            return this.profBeginDate != null ? this.profBeginDate : 0;
        }

        public Integer getProfEndDate() {
            return this.profEndDate != null ? this.profEndDate : 0;
        }

        public Character getProfType() {
            return this.profType != null ? this.profType : ' ';
        }

        public Integer getTaRiskLevel() {
            return this.taRiskLevel != null ? this.taRiskLevel : 0;
        }

        public Integer getRiskEnddate() {
            return this.riskEnddate != null ? this.riskEnddate : 0;
        }

        public String getEligCheckStr() {
            if (this.eligCheckStr == null) {
                return " ";
            } else {
                return this.eligCheckStr.isEmpty() ? " " : this.eligCheckStr;
            }
        }

        public String getEligRemark() {
            if (this.eligRemark == null) {
                return " ";
            } else {
                return this.eligRemark.isEmpty() ? " " : this.eligRemark;
            }
        }

        public Character getNeedVideoFlag() {
            return this.needVideoFlag != null ? this.needVideoFlag : ' ';
        }

        public Character getQualifiedInvestorFlag() {
            return this.qualifiedInvestorFlag != null ? this.qualifiedInvestorFlag : ' ';
        }

        public Character getCmsEligMatchFlag() {
            return this.cmsEligMatchFlag != null ? this.cmsEligMatchFlag : ' ';
        }

        public Character getProfFlag() {
            return this.profFlag != null ? this.profFlag : ' ';
        }

        public Character getForceRiskMatchflag() {
            return this.forceRiskMatchflag != null ? this.forceRiskMatchflag : ' ';
        }

        public Integer getBankRiskLevel() {
            return this.bankRiskLevel != null ? this.bankRiskLevel : 0;
        }

        public String getRiskMatchStr() {
            if (this.riskMatchStr == null) {
                return " ";
            } else {
                return this.riskMatchStr.isEmpty() ? " " : this.riskMatchStr;
            }
        }

        public Character getSpsurveyFlag() {
            return this.spsurveyFlag != null ? this.spsurveyFlag : ' ';
        }

        public Character getNominalHoldFlag() {
            return this.nominalHoldFlag != null ? this.nominalHoldFlag : ' ';
        }

        public Character getEligRiskFlag() {
            return this.eligRiskFlag != null ? this.eligRiskFlag : ' ';
        }

        public Character getEligInvestkindFlag() {
            return this.eligInvestkindFlag != null ? this.eligInvestkindFlag : ' ';
        }

        public Character getEligTermFlag() {
            return this.eligTermFlag != null ? this.eligTermFlag : ' ';
        }

        public Character getIncomeType() {
            return this.incomeType != null ? this.incomeType : ' ';
        }

        public Character getEligIncomeFlag() {
            return this.eligIncomeFlag != null ? this.eligIncomeFlag : ' ';
        }

        public Character getClientIncomeType() {
            return this.clientIncomeType != null ? this.clientIncomeType : ' ';
        }

        public Character getSenileFlag() {
            return this.senileFlag != null ? this.senileFlag : ' ';
        }

        public Integer getPfRiskLevel() {
            return this.pfRiskLevel != null ? this.pfRiskLevel : 0;
        }

        public String getEnPfInvestKind() {
            if (this.enPfInvestKind == null) {
                return " ";
            } else {
                return this.enPfInvestKind.isEmpty() ? " " : this.enPfInvestKind;
            }
        }

        public String getEnPfInvestTerm() {
            if (this.enPfInvestTerm == null) {
                return " ";
            } else {
                return this.enPfInvestTerm.isEmpty() ? " " : this.enPfInvestTerm;
            }
        }

        public Character getForceRiskMatchflagBank() {
            return this.forceRiskMatchflagBank != null ? this.forceRiskMatchflagBank : ' ';
        }

        public Double getMinAssetNeed() {
            return this.minAssetNeed != null ? this.minAssetNeed : 0.0D;
        }

        public String getEnEntrustWay() {
            if (this.enEntrustWay == null) {
                return " ";
            } else {
                return this.enEntrustWay.isEmpty() ? " " : this.enEntrustWay;
            }
        }

        public String getProdName() {
            if (this.prodName == null) {
                return " ";
            } else {
                return this.prodName.isEmpty() ? " " : this.prodName;
            }
        }

        public Integer getProdTerm() {
            return this.prodTerm != null ? this.prodTerm : 0;
        }

        public Character getProdcodeType() {
            return this.prodcodeType != null ? this.prodcodeType : ' ';
        }

        public Character getEligAssetFlag() {
            return this.eligAssetFlag != null ? this.eligAssetFlag : ' ';
        }

        public void setAgreementData(String agreementData) {
            this.agreementData = agreementData;
        }

        public void setAssetBalance(Double assetBalance) {
            this.assetBalance = assetBalance;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setCoolingPeriod(Integer coolingPeriod) {
            this.coolingPeriod = coolingPeriod;
        }

        public void setCorpBeginDate(Integer corpBeginDate) {
            this.corpBeginDate = corpBeginDate;
        }

        public void setCorpEndDate(Integer corpEndDate) {
            this.corpEndDate = corpEndDate;
        }

        public void setCorpRiskLevel(Integer corpRiskLevel) {
            this.corpRiskLevel = corpRiskLevel;
        }

        public void setEligCtrlstr(String eligCtrlstr) {
            this.eligCtrlstr = eligCtrlstr;
        }

        public void setEnInvestKind(String enInvestKind) {
            this.enInvestKind = enInvestKind;
        }

        public void setEnInvestTerm(String enInvestTerm) {
            this.enInvestTerm = enInvestTerm;
        }

        public void setEnProdriskLevel(String enProdriskLevel) {
            this.enProdriskLevel = enProdriskLevel;
        }

        public void setEnableFlag(Character enableFlag) {
            this.enableFlag = enableFlag;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setInvestTerm(Character investTerm) {
            this.investTerm = investTerm;
        }

        public void setInvestKind(Character investKind) {
            this.investKind = investKind;
        }

        public void setMinRankFlag(Character minRankFlag) {
            this.minRankFlag = minRankFlag;
        }

        public void setProdCode(String prodCode) {
            this.prodCode = prodCode;
        }

        public void setProdriskFlag(Character prodriskFlag) {
            this.prodriskFlag = prodriskFlag;
        }

        public void setProdriskLevel(Integer prodriskLevel) {
            this.prodriskLevel = prodriskLevel;
        }

        public void setProdtaNo(String prodtaNo) {
            this.prodtaNo = prodtaNo;
        }

        public void setProfBeginDate(Integer profBeginDate) {
            this.profBeginDate = profBeginDate;
        }

        public void setProfEndDate(Integer profEndDate) {
            this.profEndDate = profEndDate;
        }

        public void setProfType(Character profType) {
            this.profType = profType;
        }

        public void setTaRiskLevel(Integer taRiskLevel) {
            this.taRiskLevel = taRiskLevel;
        }

        public void setRiskEnddate(Integer riskEnddate) {
            this.riskEnddate = riskEnddate;
        }

        public void setEligCheckStr(String eligCheckStr) {
            this.eligCheckStr = eligCheckStr;
        }

        public void setEligRemark(String eligRemark) {
            this.eligRemark = eligRemark;
        }

        public void setNeedVideoFlag(Character needVideoFlag) {
            this.needVideoFlag = needVideoFlag;
        }

        public void setQualifiedInvestorFlag(Character qualifiedInvestorFlag) {
            this.qualifiedInvestorFlag = qualifiedInvestorFlag;
        }

        public void setCmsEligMatchFlag(Character cmsEligMatchFlag) {
            this.cmsEligMatchFlag = cmsEligMatchFlag;
        }

        public void setProfFlag(Character profFlag) {
            this.profFlag = profFlag;
        }

        public void setForceRiskMatchflag(Character forceRiskMatchflag) {
            this.forceRiskMatchflag = forceRiskMatchflag;
        }

        public void setBankRiskLevel(Integer bankRiskLevel) {
            this.bankRiskLevel = bankRiskLevel;
        }

        public void setRiskMatchStr(String riskMatchStr) {
            this.riskMatchStr = riskMatchStr;
        }

        public void setSpsurveyFlag(Character spsurveyFlag) {
            this.spsurveyFlag = spsurveyFlag;
        }

        public void setNominalHoldFlag(Character nominalHoldFlag) {
            this.nominalHoldFlag = nominalHoldFlag;
        }

        public void setEligRiskFlag(Character eligRiskFlag) {
            this.eligRiskFlag = eligRiskFlag;
        }

        public void setEligInvestkindFlag(Character eligInvestkindFlag) {
            this.eligInvestkindFlag = eligInvestkindFlag;
        }

        public void setEligTermFlag(Character eligTermFlag) {
            this.eligTermFlag = eligTermFlag;
        }

        public void setIncomeType(Character incomeType) {
            this.incomeType = incomeType;
        }

        public void setEligIncomeFlag(Character eligIncomeFlag) {
            this.eligIncomeFlag = eligIncomeFlag;
        }

        public void setClientIncomeType(Character clientIncomeType) {
            this.clientIncomeType = clientIncomeType;
        }

        public void setSenileFlag(Character senileFlag) {
            this.senileFlag = senileFlag;
        }

        public void setPfRiskLevel(Integer pfRiskLevel) {
            this.pfRiskLevel = pfRiskLevel;
        }

        public void setEnPfInvestKind(String enPfInvestKind) {
            this.enPfInvestKind = enPfInvestKind;
        }

        public void setEnPfInvestTerm(String enPfInvestTerm) {
            this.enPfInvestTerm = enPfInvestTerm;
        }

        public void setForceRiskMatchflagBank(Character forceRiskMatchflagBank) {
            this.forceRiskMatchflagBank = forceRiskMatchflagBank;
        }

        public void setMinAssetNeed(Double minAssetNeed) {
            this.minAssetNeed = minAssetNeed;
        }

        public void setEnEntrustWay(String enEntrustWay) {
            this.enEntrustWay = enEntrustWay;
        }

        public void setProdName(String prodName) {
            this.prodName = prodName;
        }

        public void setProdTerm(Integer prodTerm) {
            this.prodTerm = prodTerm;
        }

        public void setProdcodeType(Character prodcodeType) {
            this.prodcodeType = prodcodeType;
        }

        public void setEligAssetFlag(Character eligAssetFlag) {
            this.eligAssetFlag = eligAssetFlag;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetClientpreferMatchInnerOutput:(");
            buffer.append("agreementData:" + this.agreementData);
            buffer.append(",assetBalance:" + this.assetBalance);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",coolingPeriod:" + this.coolingPeriod);
            buffer.append(",corpBeginDate:" + this.corpBeginDate);
            buffer.append(",corpEndDate:" + this.corpEndDate);
            buffer.append(",corpRiskLevel:" + this.corpRiskLevel);
            buffer.append(",eligCtrlstr:" + this.eligCtrlstr);
            buffer.append(",enInvestKind:" + this.enInvestKind);
            buffer.append(",enInvestTerm:" + this.enInvestTerm);
            buffer.append(",enProdriskLevel:" + this.enProdriskLevel);
            buffer.append(",enableFlag:" + this.enableFlag);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",investTerm:" + this.investTerm);
            buffer.append(",investKind:" + this.investKind);
            buffer.append(",minRankFlag:" + this.minRankFlag);
            buffer.append(",prodCode:" + this.prodCode);
            buffer.append(",prodriskFlag:" + this.prodriskFlag);
            buffer.append(",prodriskLevel:" + this.prodriskLevel);
            buffer.append(",prodtaNo:" + this.prodtaNo);
            buffer.append(",profBeginDate:" + this.profBeginDate);
            buffer.append(",profEndDate:" + this.profEndDate);
            buffer.append(",profType:" + this.profType);
            buffer.append(",taRiskLevel:" + this.taRiskLevel);
            buffer.append(",riskEnddate:" + this.riskEnddate);
            buffer.append(",eligCheckStr:" + this.eligCheckStr);
            buffer.append(",eligRemark:" + this.eligRemark);
            buffer.append(",needVideoFlag:" + this.needVideoFlag);
            buffer.append(",qualifiedInvestorFlag:" + this.qualifiedInvestorFlag);
            buffer.append(",cmsEligMatchFlag:" + this.cmsEligMatchFlag);
            buffer.append(",profFlag:" + this.profFlag);
            buffer.append(",forceRiskMatchflag:" + this.forceRiskMatchflag);
            buffer.append(",bankRiskLevel:" + this.bankRiskLevel);
            buffer.append(",riskMatchStr:" + this.riskMatchStr);
            buffer.append(",spsurveyFlag:" + this.spsurveyFlag);
            buffer.append(",nominalHoldFlag:" + this.nominalHoldFlag);
            buffer.append(",eligRiskFlag:" + this.eligRiskFlag);
            buffer.append(",eligInvestkindFlag:" + this.eligInvestkindFlag);
            buffer.append(",eligTermFlag:" + this.eligTermFlag);
            buffer.append(",incomeType:" + this.incomeType);
            buffer.append(",eligIncomeFlag:" + this.eligIncomeFlag);
            buffer.append(",clientIncomeType:" + this.clientIncomeType);
            buffer.append(",senileFlag:" + this.senileFlag);
            buffer.append(",pfRiskLevel:" + this.pfRiskLevel);
            buffer.append(",enPfInvestKind:" + this.enPfInvestKind);
            buffer.append(",enPfInvestTerm:" + this.enPfInvestTerm);
            buffer.append(",forceRiskMatchflagBank:" + this.forceRiskMatchflagBank);
            buffer.append(",minAssetNeed:" + this.minAssetNeed);
            buffer.append(",enEntrustWay:" + this.enEntrustWay);
            buffer.append(",prodName:" + this.prodName);
            buffer.append(",prodTerm:" + this.prodTerm);
            buffer.append(",prodcodeType:" + this.prodcodeType);
            buffer.append(",eligAssetFlag:" + this.eligAssetFlag);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.agreementData);
            builder.append(this.assetBalance);
            builder.append(this.clientId);
            builder.append(this.coolingPeriod);
            builder.append(this.corpBeginDate);
            builder.append(this.corpEndDate);
            builder.append(this.corpRiskLevel);
            builder.append(this.eligCtrlstr);
            builder.append(this.enInvestKind);
            builder.append(this.enInvestTerm);
            builder.append(this.enProdriskLevel);
            builder.append(this.enableFlag);
            builder.append(this.fundAccount);
            builder.append(this.investTerm);
            builder.append(this.investKind);
            builder.append(this.minRankFlag);
            builder.append(this.prodCode);
            builder.append(this.prodriskFlag);
            builder.append(this.prodriskLevel);
            builder.append(this.prodtaNo);
            builder.append(this.profBeginDate);
            builder.append(this.profEndDate);
            builder.append(this.profType);
            builder.append(this.taRiskLevel);
            builder.append(this.riskEnddate);
            builder.append(this.eligCheckStr);
            builder.append(this.eligRemark);
            builder.append(this.needVideoFlag);
            builder.append(this.qualifiedInvestorFlag);
            builder.append(this.cmsEligMatchFlag);
            builder.append(this.profFlag);
            builder.append(this.forceRiskMatchflag);
            builder.append(this.bankRiskLevel);
            builder.append(this.riskMatchStr);
            builder.append(this.spsurveyFlag);
            builder.append(this.nominalHoldFlag);
            builder.append(this.eligRiskFlag);
            builder.append(this.eligInvestkindFlag);
            builder.append(this.eligTermFlag);
            builder.append(this.incomeType);
            builder.append(this.eligIncomeFlag);
            builder.append(this.clientIncomeType);
            builder.append(this.senileFlag);
            builder.append(this.pfRiskLevel);
            builder.append(this.enPfInvestKind);
            builder.append(this.enPfInvestTerm);
            builder.append(this.forceRiskMatchflagBank);
            builder.append(this.minAssetNeed);
            builder.append(this.enEntrustWay);
            builder.append(this.prodName);
            builder.append(this.prodTerm);
            builder.append(this.prodcodeType);
            builder.append(this.eligAssetFlag);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.GetClientpreferMatchInnerOutput) {
                InnerDfzqService.GetClientpreferMatchInnerOutput test = (InnerDfzqService.GetClientpreferMatchInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.agreementData, test.agreementData);
                builder.append(this.assetBalance, test.assetBalance);
                builder.append(this.clientId, test.clientId);
                builder.append(this.coolingPeriod, test.coolingPeriod);
                builder.append(this.corpBeginDate, test.corpBeginDate);
                builder.append(this.corpEndDate, test.corpEndDate);
                builder.append(this.corpRiskLevel, test.corpRiskLevel);
                builder.append(this.eligCtrlstr, test.eligCtrlstr);
                builder.append(this.enInvestKind, test.enInvestKind);
                builder.append(this.enInvestTerm, test.enInvestTerm);
                builder.append(this.enProdriskLevel, test.enProdriskLevel);
                builder.append(this.enableFlag, test.enableFlag);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.investTerm, test.investTerm);
                builder.append(this.investKind, test.investKind);
                builder.append(this.minRankFlag, test.minRankFlag);
                builder.append(this.prodCode, test.prodCode);
                builder.append(this.prodriskFlag, test.prodriskFlag);
                builder.append(this.prodriskLevel, test.prodriskLevel);
                builder.append(this.prodtaNo, test.prodtaNo);
                builder.append(this.profBeginDate, test.profBeginDate);
                builder.append(this.profEndDate, test.profEndDate);
                builder.append(this.profType, test.profType);
                builder.append(this.taRiskLevel, test.taRiskLevel);
                builder.append(this.riskEnddate, test.riskEnddate);
                builder.append(this.eligCheckStr, test.eligCheckStr);
                builder.append(this.eligRemark, test.eligRemark);
                builder.append(this.needVideoFlag, test.needVideoFlag);
                builder.append(this.qualifiedInvestorFlag, test.qualifiedInvestorFlag);
                builder.append(this.cmsEligMatchFlag, test.cmsEligMatchFlag);
                builder.append(this.profFlag, test.profFlag);
                builder.append(this.forceRiskMatchflag, test.forceRiskMatchflag);
                builder.append(this.bankRiskLevel, test.bankRiskLevel);
                builder.append(this.riskMatchStr, test.riskMatchStr);
                builder.append(this.spsurveyFlag, test.spsurveyFlag);
                builder.append(this.nominalHoldFlag, test.nominalHoldFlag);
                builder.append(this.eligRiskFlag, test.eligRiskFlag);
                builder.append(this.eligInvestkindFlag, test.eligInvestkindFlag);
                builder.append(this.eligTermFlag, test.eligTermFlag);
                builder.append(this.incomeType, test.incomeType);
                builder.append(this.eligIncomeFlag, test.eligIncomeFlag);
                builder.append(this.clientIncomeType, test.clientIncomeType);
                builder.append(this.senileFlag, test.senileFlag);
                builder.append(this.pfRiskLevel, test.pfRiskLevel);
                builder.append(this.enPfInvestKind, test.enPfInvestKind);
                builder.append(this.enPfInvestTerm, test.enPfInvestTerm);
                builder.append(this.forceRiskMatchflagBank, test.forceRiskMatchflagBank);
                builder.append(this.minAssetNeed, test.minAssetNeed);
                builder.append(this.enEntrustWay, test.enEntrustWay);
                builder.append(this.prodName, test.prodName);
                builder.append(this.prodTerm, test.prodTerm);
                builder.append(this.prodcodeType, test.prodcodeType);
                builder.append(this.eligAssetFlag, test.eligAssetFlag);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetClientpreferMatchInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fundAccount = " ";
        @SinogramLength(
                min = 0,
                max = 24,
                charset = "utf-8"
        )
        private String prodtaNo = " ";
        @SinogramLength(
                min = 1,
                max = 32,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String prodCode;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId;

        public GetClientpreferMatchInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getProdtaNo() {
            if (this.prodtaNo == null) {
                return " ";
            } else {
                return this.prodtaNo.isEmpty() ? " " : this.prodtaNo;
            }
        }

        public String getProdCode() {
            return this.prodCode;
        }

        public String getClientId() {
            return this.clientId;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setProdtaNo(String prodtaNo) {
            this.prodtaNo = prodtaNo;
        }

        public void setProdCode(String prodCode) {
            this.prodCode = prodCode;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetClientpreferMatchInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",prodtaNo:" + this.prodtaNo);
            buffer.append(",prodCode:" + this.prodCode);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.fundAccount);
            builder.append(this.prodtaNo);
            builder.append(this.prodCode);
            builder.append(this.clientId);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.GetClientpreferMatchInnerInput) {
                InnerDfzqService.GetClientpreferMatchInnerInput test = (InnerDfzqService.GetClientpreferMatchInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.prodtaNo, test.prodtaNo);
                builder.append(this.prodCode, test.prodCode);
                builder.append(this.clientId, test.clientId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetClientInfoEiamsInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String custId = " ";
        private String fullName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character idKind = ' ';
        private String idNo = " ";
        private String clientShortName = " ";
        private Integer birthday = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character organFlag = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character clientGender = ' ';
        private String eMail = " ";
        private String mobileTel = " ";

        public GetClientInfoEiamsInnerOutput() {
        }

        public String getCustId() {
            if (this.custId == null) {
                return " ";
            } else {
                return this.custId.isEmpty() ? " " : this.custId;
            }
        }

        public String getFullName() {
            if (this.fullName == null) {
                return " ";
            } else {
                return this.fullName.isEmpty() ? " " : this.fullName;
            }
        }

        public Character getIdKind() {
            return this.idKind != null ? this.idKind : ' ';
        }

        public String getIdNo() {
            if (this.idNo == null) {
                return " ";
            } else {
                return this.idNo.isEmpty() ? " " : this.idNo;
            }
        }

        public String getClientShortName() {
            if (this.clientShortName == null) {
                return " ";
            } else {
                return this.clientShortName.isEmpty() ? " " : this.clientShortName;
            }
        }

        public Integer getBirthday() {
            return this.birthday != null ? this.birthday : 0;
        }

        public Character getOrganFlag() {
            return this.organFlag != null ? this.organFlag : ' ';
        }

        public Character getClientGender() {
            return this.clientGender != null ? this.clientGender : ' ';
        }

        public String geteMail() {
            if (this.eMail == null) {
                return " ";
            } else {
                return this.eMail.isEmpty() ? " " : this.eMail;
            }
        }

        public String getMobileTel() {
            if (this.mobileTel == null) {
                return " ";
            } else {
                return this.mobileTel.isEmpty() ? " " : this.mobileTel;
            }
        }

        public void setCustId(String custId) {
            this.custId = custId;
        }

        public void setFullName(String fullName) {
            this.fullName = fullName;
        }

        public void setIdKind(Character idKind) {
            this.idKind = idKind;
        }

        public void setIdNo(String idNo) {
            this.idNo = idNo;
        }

        public void setClientShortName(String clientShortName) {
            this.clientShortName = clientShortName;
        }

        public void setBirthday(Integer birthday) {
            this.birthday = birthday;
        }

        public void setOrganFlag(Character organFlag) {
            this.organFlag = organFlag;
        }

        public void setClientGender(Character clientGender) {
            this.clientGender = clientGender;
        }

        public void seteMail(String eMail) {
            this.eMail = eMail;
        }

        public void setMobileTel(String mobileTel) {
            this.mobileTel = mobileTel;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetClientInfoEiamsInnerOutput:(");
            buffer.append("custId:" + this.custId);
            buffer.append(",fullName:" + this.fullName);
            buffer.append(",idKind:" + this.idKind);
            buffer.append(",idNo:" + this.idNo);
            buffer.append(",clientShortName:" + this.clientShortName);
            buffer.append(",birthday:" + this.birthday);
            buffer.append(",organFlag:" + this.organFlag);
            buffer.append(",clientGender:" + this.clientGender);
            buffer.append(",eMail:" + this.eMail);
            buffer.append(",mobileTel:" + this.mobileTel);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.custId);
            builder.append(this.fullName);
            builder.append(this.idKind);
            builder.append(this.idNo);
            builder.append(this.clientShortName);
            builder.append(this.birthday);
            builder.append(this.organFlag);
            builder.append(this.clientGender);
            builder.append(this.eMail);
            builder.append(this.mobileTel);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.GetClientInfoEiamsInnerOutput) {
                InnerDfzqService.GetClientInfoEiamsInnerOutput test = (InnerDfzqService.GetClientInfoEiamsInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.custId, test.custId);
                builder.append(this.fullName, test.fullName);
                builder.append(this.idKind, test.idKind);
                builder.append(this.idNo, test.idNo);
                builder.append(this.clientShortName, test.clientShortName);
                builder.append(this.birthday, test.birthday);
                builder.append(this.organFlag, test.organFlag);
                builder.append(this.clientGender, test.clientGender);
                builder.append(this.eMail, test.eMail);
                builder.append(this.mobileTel, test.mobileTel);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetClientInfoEiamsInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character userType = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String functionStr = " ";
        private Integer branchNo = 0;
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String custId = " ";
        @SinogramLength(
                min = 0,
                max = 180,
                charset = "utf-8"
        )
        private String fullName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character idKind = ' ';
        @SinogramLength(
                min = 0,
                max = 40,
                charset = "utf-8"
        )
        private String idNo = " ";

        public GetClientInfoEiamsInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public Character getUserType() {
            return this.userType != null ? this.userType : ' ';
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getFunctionStr() {
            if (this.functionStr == null) {
                return " ";
            } else {
                return this.functionStr.isEmpty() ? " " : this.functionStr;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getCustId() {
            if (this.custId == null) {
                return " ";
            } else {
                return this.custId.isEmpty() ? " " : this.custId;
            }
        }

        public String getFullName() {
            if (this.fullName == null) {
                return " ";
            } else {
                return this.fullName.isEmpty() ? " " : this.fullName;
            }
        }

        public Character getIdKind() {
            return this.idKind != null ? this.idKind : ' ';
        }

        public String getIdNo() {
            if (this.idNo == null) {
                return " ";
            } else {
                return this.idNo.isEmpty() ? " " : this.idNo;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setUserType(Character userType) {
            this.userType = userType;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setFunctionStr(String functionStr) {
            this.functionStr = functionStr;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setCustId(String custId) {
            this.custId = custId;
        }

        public void setFullName(String fullName) {
            this.fullName = fullName;
        }

        public void setIdKind(Character idKind) {
            this.idKind = idKind;
        }

        public void setIdNo(String idNo) {
            this.idNo = idNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetClientInfoEiamsInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",userType:" + this.userType);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",functionStr:" + this.functionStr);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",custId:" + this.custId);
            buffer.append(",fullName:" + this.fullName);
            buffer.append(",idKind:" + this.idKind);
            buffer.append(",idNo:" + this.idNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.userType);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.functionStr);
            builder.append(this.branchNo);
            builder.append(this.custId);
            builder.append(this.fullName);
            builder.append(this.idKind);
            builder.append(this.idNo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.GetClientInfoEiamsInnerInput) {
                InnerDfzqService.GetClientInfoEiamsInnerInput test = (InnerDfzqService.GetClientInfoEiamsInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.userType, test.userType);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.functionStr, test.functionStr);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.custId, test.custId);
                builder.append(this.fullName, test.fullName);
                builder.append(this.idKind, test.idKind);
                builder.append(this.idNo, test.idNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetJsdCheckPasswordInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String opRemark = " ";
        private Long serialNo = 0L;
        private String returnCode = " ";

        public GetJsdCheckPasswordInnerOutput() {
        }

        public String getOpRemark() {
            if (this.opRemark == null) {
                return " ";
            } else {
                return this.opRemark.isEmpty() ? " " : this.opRemark;
            }
        }

        public Long getSerialNo() {
            return this.serialNo != null ? this.serialNo : 0L;
        }

        public String getReturnCode() {
            if (this.returnCode == null) {
                return " ";
            } else {
                return this.returnCode.isEmpty() ? " " : this.returnCode;
            }
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public void setSerialNo(Long serialNo) {
            this.serialNo = serialNo;
        }

        public void setReturnCode(String returnCode) {
            this.returnCode = returnCode;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetJsdCheckPasswordInnerOutput:(");
            buffer.append("opRemark:" + this.opRemark);
            buffer.append(",serialNo:" + this.serialNo);
            buffer.append(",returnCode:" + this.returnCode);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opRemark);
            builder.append(this.serialNo);
            builder.append(this.returnCode);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.GetJsdCheckPasswordInnerOutput) {
                InnerDfzqService.GetJsdCheckPasswordInnerOutput test = (InnerDfzqService.GetJsdCheckPasswordInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opRemark, test.opRemark);
                builder.append(this.serialNo, test.serialNo);
                builder.append(this.returnCode, test.returnCode);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetJsdCheckPasswordInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @SinogramLength(
                min = 1,
                max = 2000,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String remark = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String auditOperatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String fundAccount = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character passwordType = ' ';
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character encryptType = ' ';
        @SinogramLength(
                min = 1,
                max = 64,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String password = " ";
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId = " ";

        public GetJsdCheckPasswordInnerInput() {
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public String getRemark() {
            if (this.remark == null) {
                return " ";
            } else {
                return this.remark.isEmpty() ? " " : this.remark;
            }
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getAuditOperatorNo() {
            if (this.auditOperatorNo == null) {
                return " ";
            } else {
                return this.auditOperatorNo.isEmpty() ? " " : this.auditOperatorNo;
            }
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public Character getPasswordType() {
            return this.passwordType != null ? this.passwordType : ' ';
        }

        public Character getEncryptType() {
            return this.encryptType != null ? this.encryptType : ' ';
        }

        public String getPassword() {
            if (this.password == null) {
                return " ";
            } else {
                return this.password.isEmpty() ? " " : this.password;
            }
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setAuditOperatorNo(String auditOperatorNo) {
            this.auditOperatorNo = auditOperatorNo;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setPasswordType(Character passwordType) {
            this.passwordType = passwordType;
        }

        public void setEncryptType(Character encryptType) {
            this.encryptType = encryptType;
        }

        public void setPassword(String password) {
            this.password = password;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetJsdCheckPasswordInnerInput:(");
            buffer.append("opStation:" + this.opStation);
            buffer.append(",remark:" + this.remark);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",auditOperatorNo:" + this.auditOperatorNo);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",passwordType:" + this.passwordType);
            buffer.append(",encryptType:" + this.encryptType);
            buffer.append(",password:" + this.password);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opStation);
            builder.append(this.remark);
            builder.append(this.operatorNo);
            builder.append(this.auditOperatorNo);
            builder.append(this.fundAccount);
            builder.append(this.passwordType);
            builder.append(this.encryptType);
            builder.append(this.password);
            builder.append(this.clientId);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.GetJsdCheckPasswordInnerInput) {
                InnerDfzqService.GetJsdCheckPasswordInnerInput test = (InnerDfzqService.GetJsdCheckPasswordInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opStation, test.opStation);
                builder.append(this.remark, test.remark);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.auditOperatorNo, test.auditOperatorNo);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.passwordType, test.passwordType);
                builder.append(this.encryptType, test.encryptType);
                builder.append(this.password, test.password);
                builder.append(this.clientId, test.clientId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostSendEmailByFileInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character status = ' ';

        public PostSendEmailByFileInnerOutput() {
        }

        public Character getStatus() {
            return this.status != null ? this.status : ' ';
        }

        public void setStatus(Character status) {
            this.status = status;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostSendEmailByFileInnerOutput:(");
            buffer.append("status:" + this.status);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.status);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.PostSendEmailByFileInnerOutput) {
                InnerDfzqService.PostSendEmailByFileInnerOutput test = (InnerDfzqService.PostSendEmailByFileInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.status, test.status);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostSendEmailByFileInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character userType = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String functionStr = " ";
        private Integer branchNo = 0;
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String noticeAddress = " ";
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String noticeCaddress = " ";
        @SinogramLength(
                min = 0,
                max = 32000,
                charset = "utf-8"
        )
        private String noticeContent = " ";
        @SinogramLength(
                min = 0,
                max = 999999999,
                charset = "utf-8"
        )
        private String fileData = " ";
        @SinogramLength(
                min = 0,
                max = 16000,
                charset = "utf-8"
        )
        private String fileName = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String clientId = " ";
        @SinogramLength(
                min = 0,
                max = 90,
                charset = "utf-8"
        )
        private String clientName = " ";
        private Long serialNo = 0L;
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String noticeCaption = " ";
        private Integer initDate = 0;
        private Character expfileType = ' ';

        public PostSendEmailByFileInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public Character getUserType() {
            return this.userType != null ? this.userType : ' ';
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getFunctionStr() {
            if (this.functionStr == null) {
                return " ";
            } else {
                return this.functionStr.isEmpty() ? " " : this.functionStr;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getNoticeAddress() {
            if (this.noticeAddress == null) {
                return " ";
            } else {
                return this.noticeAddress.isEmpty() ? " " : this.noticeAddress;
            }
        }

        public String getNoticeCaddress() {
            if (this.noticeCaddress == null) {
                return " ";
            } else {
                return this.noticeCaddress.isEmpty() ? " " : this.noticeCaddress;
            }
        }

        public String getNoticeContent() {
            if (this.noticeContent == null) {
                return " ";
            } else {
                return this.noticeContent.isEmpty() ? " " : this.noticeContent;
            }
        }

        public String getFileData() {
            if (this.fileData == null) {
                return " ";
            } else {
                return this.fileData.isEmpty() ? " " : this.fileData;
            }
        }

        public String getFileName() {
            if (this.fileName == null) {
                return " ";
            } else {
                return this.fileName.isEmpty() ? " " : this.fileName;
            }
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getClientName() {
            if (this.clientName == null) {
                return " ";
            } else {
                return this.clientName.isEmpty() ? " " : this.clientName;
            }
        }

        public Long getSerialNo() {
            return this.serialNo != null ? this.serialNo : 0L;
        }

        public String getNoticeCaption() {
            if (this.noticeCaption == null) {
                return " ";
            } else {
                return this.noticeCaption.isEmpty() ? " " : this.noticeCaption;
            }
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public Character getExpfileType() {
            return this.expfileType != null ? this.expfileType : ' ';
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setUserType(Character userType) {
            this.userType = userType;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setFunctionStr(String functionStr) {
            this.functionStr = functionStr;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setNoticeAddress(String noticeAddress) {
            this.noticeAddress = noticeAddress;
        }

        public void setNoticeCaddress(String noticeCaddress) {
            this.noticeCaddress = noticeCaddress;
        }

        public void setNoticeContent(String noticeContent) {
            this.noticeContent = noticeContent;
        }

        public void setFileData(String fileData) {
            this.fileData = fileData;
        }

        public void setFileName(String fileName) {
            this.fileName = fileName;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setClientName(String clientName) {
            this.clientName = clientName;
        }

        public void setSerialNo(Long serialNo) {
            this.serialNo = serialNo;
        }

        public void setNoticeCaption(String noticeCaption) {
            this.noticeCaption = noticeCaption;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public void setExpfileType(Character expfileType) {
            this.expfileType = expfileType;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostSendEmailByFileInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",userType:" + this.userType);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",functionStr:" + this.functionStr);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",noticeAddress:" + this.noticeAddress);
            buffer.append(",noticeCaddress:" + this.noticeCaddress);
            buffer.append(",noticeContent:" + this.noticeContent);
            buffer.append(",fileData:" + this.fileData);
            buffer.append(",fileName:" + this.fileName);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",clientName:" + this.clientName);
            buffer.append(",serialNo:" + this.serialNo);
            buffer.append(",noticeCaption:" + this.noticeCaption);
            buffer.append(",initDate:" + this.initDate);
            buffer.append(",expfileType:" + this.expfileType);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.userType);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.functionStr);
            builder.append(this.branchNo);
            builder.append(this.noticeAddress);
            builder.append(this.noticeCaddress);
            builder.append(this.noticeContent);
            builder.append(this.fileData);
            builder.append(this.fileName);
            builder.append(this.clientId);
            builder.append(this.clientName);
            builder.append(this.serialNo);
            builder.append(this.noticeCaption);
            builder.append(this.initDate);
            builder.append(this.expfileType);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.PostSendEmailByFileInnerInput) {
                InnerDfzqService.PostSendEmailByFileInnerInput test = (InnerDfzqService.PostSendEmailByFileInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.userType, test.userType);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.functionStr, test.functionStr);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.noticeAddress, test.noticeAddress);
                builder.append(this.noticeCaddress, test.noticeCaddress);
                builder.append(this.noticeContent, test.noticeContent);
                builder.append(this.fileData, test.fileData);
                builder.append(this.fileName, test.fileName);
                builder.append(this.clientId, test.clientId);
                builder.append(this.clientName, test.clientName);
                builder.append(this.serialNo, test.serialNo);
                builder.append(this.noticeCaption, test.noticeCaption);
                builder.append(this.initDate, test.initDate);
                builder.append(this.expfileType, test.expfileType);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostSendEmailInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character status = ' ';

        public PostSendEmailInnerOutput() {
        }

        public Character getStatus() {
            return this.status != null ? this.status : ' ';
        }

        public void setStatus(Character status) {
            this.status = status;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostSendEmailInnerOutput:(");
            buffer.append("status:" + this.status);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.status);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.PostSendEmailInnerOutput) {
                InnerDfzqService.PostSendEmailInnerOutput test = (InnerDfzqService.PostSendEmailInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.status, test.status);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostSendEmailInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character userType = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String functionStr = " ";
        private Integer branchNo = 0;
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String noticeAddress = " ";
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String noticeCaddress = " ";
        @SinogramLength(
                min = 0,
                max = 32000,
                charset = "utf-8"
        )
        private String noticeContent = " ";
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String attachPath = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String clientId = " ";
        @SinogramLength(
                min = 0,
                max = 90,
                charset = "utf-8"
        )
        private String clientName = " ";
        private Long serialNo = 0L;
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String noticeCaption = " ";
        private Integer initDate = 0;

        public PostSendEmailInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public Character getUserType() {
            return this.userType != null ? this.userType : ' ';
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getFunctionStr() {
            if (this.functionStr == null) {
                return " ";
            } else {
                return this.functionStr.isEmpty() ? " " : this.functionStr;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getNoticeAddress() {
            if (this.noticeAddress == null) {
                return " ";
            } else {
                return this.noticeAddress.isEmpty() ? " " : this.noticeAddress;
            }
        }

        public String getNoticeCaddress() {
            if (this.noticeCaddress == null) {
                return " ";
            } else {
                return this.noticeCaddress.isEmpty() ? " " : this.noticeCaddress;
            }
        }

        public String getNoticeContent() {
            if (this.noticeContent == null) {
                return " ";
            } else {
                return this.noticeContent.isEmpty() ? " " : this.noticeContent;
            }
        }

        public String getAttachPath() {
            if (this.attachPath == null) {
                return " ";
            } else {
                return this.attachPath.isEmpty() ? " " : this.attachPath;
            }
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getClientName() {
            if (this.clientName == null) {
                return " ";
            } else {
                return this.clientName.isEmpty() ? " " : this.clientName;
            }
        }

        public Long getSerialNo() {
            return this.serialNo != null ? this.serialNo : 0L;
        }

        public String getNoticeCaption() {
            if (this.noticeCaption == null) {
                return " ";
            } else {
                return this.noticeCaption.isEmpty() ? " " : this.noticeCaption;
            }
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setUserType(Character userType) {
            this.userType = userType;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setFunctionStr(String functionStr) {
            this.functionStr = functionStr;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setNoticeAddress(String noticeAddress) {
            this.noticeAddress = noticeAddress;
        }

        public void setNoticeCaddress(String noticeCaddress) {
            this.noticeCaddress = noticeCaddress;
        }

        public void setNoticeContent(String noticeContent) {
            this.noticeContent = noticeContent;
        }

        public void setAttachPath(String attachPath) {
            this.attachPath = attachPath;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setClientName(String clientName) {
            this.clientName = clientName;
        }

        public void setSerialNo(Long serialNo) {
            this.serialNo = serialNo;
        }

        public void setNoticeCaption(String noticeCaption) {
            this.noticeCaption = noticeCaption;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostSendEmailInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",userType:" + this.userType);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",functionStr:" + this.functionStr);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",noticeAddress:" + this.noticeAddress);
            buffer.append(",noticeCaddress:" + this.noticeCaddress);
            buffer.append(",noticeContent:" + this.noticeContent);
            buffer.append(",attachPath:" + this.attachPath);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",clientName:" + this.clientName);
            buffer.append(",serialNo:" + this.serialNo);
            buffer.append(",noticeCaption:" + this.noticeCaption);
            buffer.append(",initDate:" + this.initDate);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.userType);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.functionStr);
            builder.append(this.branchNo);
            builder.append(this.noticeAddress);
            builder.append(this.noticeCaddress);
            builder.append(this.noticeContent);
            builder.append(this.attachPath);
            builder.append(this.clientId);
            builder.append(this.clientName);
            builder.append(this.serialNo);
            builder.append(this.noticeCaption);
            builder.append(this.initDate);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.PostSendEmailInnerInput) {
                InnerDfzqService.PostSendEmailInnerInput test = (InnerDfzqService.PostSendEmailInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.userType, test.userType);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.functionStr, test.functionStr);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.noticeAddress, test.noticeAddress);
                builder.append(this.noticeCaddress, test.noticeCaddress);
                builder.append(this.noticeContent, test.noticeContent);
                builder.append(this.attachPath, test.attachPath);
                builder.append(this.clientId, test.clientId);
                builder.append(this.clientName, test.clientName);
                builder.append(this.serialNo, test.serialNo);
                builder.append(this.noticeCaption, test.noticeCaption);
                builder.append(this.initDate, test.initDate);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostShortMessageInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character status = ' ';
        private Long serialNo = 0L;
        private String message = " ";

        public PostShortMessageInnerOutput() {
        }

        public Character getStatus() {
            return this.status != null ? this.status : ' ';
        }

        public Long getSerialNo() {
            return this.serialNo != null ? this.serialNo : 0L;
        }

        public String getMessage() {
            if (this.message == null) {
                return " ";
            } else {
                return this.message.isEmpty() ? " " : this.message;
            }
        }

        public void setStatus(Character status) {
            this.status = status;
        }

        public void setSerialNo(Long serialNo) {
            this.serialNo = serialNo;
        }

        public void setMessage(String message) {
            this.message = message;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostShortMessageInnerOutput:(");
            buffer.append("status:" + this.status);
            buffer.append(",serialNo:" + this.serialNo);
            buffer.append(",message:" + this.message);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.status);
            builder.append(this.serialNo);
            builder.append(this.message);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.PostShortMessageInnerOutput) {
                InnerDfzqService.PostShortMessageInnerOutput test = (InnerDfzqService.PostShortMessageInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.status, test.status);
                builder.append(this.serialNo, test.serialNo);
                builder.append(this.message, test.message);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostShortMessageInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character userType = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String functionStr = " ";
        private Integer branchNo = 0;
        @SinogramLength(
                min = 1,
                max = 32000,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String noticeContent = " ";
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String noticeCaddress = " ";
        @SinogramLength(
                min = 1,
                max = 180,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String address = " ";
        @NotNull(
                message = "不能为空"
        )
        private Long templateId = 0L;

        public PostShortMessageInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public Character getUserType() {
            return this.userType != null ? this.userType : ' ';
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getFunctionStr() {
            if (this.functionStr == null) {
                return " ";
            } else {
                return this.functionStr.isEmpty() ? " " : this.functionStr;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getNoticeContent() {
            if (this.noticeContent == null) {
                return " ";
            } else {
                return this.noticeContent.isEmpty() ? " " : this.noticeContent;
            }
        }

        public String getNoticeCaddress() {
            if (this.noticeCaddress == null) {
                return " ";
            } else {
                return this.noticeCaddress.isEmpty() ? " " : this.noticeCaddress;
            }
        }

        public String getAddress() {
            if (this.address == null) {
                return " ";
            } else {
                return this.address.isEmpty() ? " " : this.address;
            }
        }

        public Long getTemplateId() {
            return this.templateId != null ? this.templateId : 0L;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setUserType(Character userType) {
            this.userType = userType;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setFunctionStr(String functionStr) {
            this.functionStr = functionStr;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setNoticeContent(String noticeContent) {
            this.noticeContent = noticeContent;
        }

        public void setNoticeCaddress(String noticeCaddress) {
            this.noticeCaddress = noticeCaddress;
        }

        public void setAddress(String address) {
            this.address = address;
        }

        public void setTemplateId(Long templateId) {
            this.templateId = templateId;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostShortMessageInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",userType:" + this.userType);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",functionStr:" + this.functionStr);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",noticeContent:" + this.noticeContent);
            buffer.append(",noticeCaddress:" + this.noticeCaddress);
            buffer.append(",address:" + this.address);
            buffer.append(",templateId:" + this.templateId);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.userType);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.functionStr);
            builder.append(this.branchNo);
            builder.append(this.noticeContent);
            builder.append(this.noticeCaddress);
            builder.append(this.address);
            builder.append(this.templateId);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.PostShortMessageInnerInput) {
                InnerDfzqService.PostShortMessageInnerInput test = (InnerDfzqService.PostShortMessageInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.userType, test.userType);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.functionStr, test.functionStr);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.noticeContent, test.noticeContent);
                builder.append(this.noticeCaddress, test.noticeCaddress);
                builder.append(this.address, test.address);
                builder.append(this.templateId, test.templateId);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostFundSaveFromSecuInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Long paySerialNo = 0L;
        private String returnCode = " ";
        private String returnMsg = " ";

        public PostFundSaveFromSecuInnerOutput() {
        }

        public Long getPaySerialNo() {
            return this.paySerialNo != null ? this.paySerialNo : 0L;
        }

        public String getReturnCode() {
            if (this.returnCode == null) {
                return " ";
            } else {
                return this.returnCode.isEmpty() ? " " : this.returnCode;
            }
        }

        public String getReturnMsg() {
            if (this.returnMsg == null) {
                return " ";
            } else {
                return this.returnMsg.isEmpty() ? " " : this.returnMsg;
            }
        }

        public void setPaySerialNo(Long paySerialNo) {
            this.paySerialNo = paySerialNo;
        }

        public void setReturnCode(String returnCode) {
            this.returnCode = returnCode;
        }

        public void setReturnMsg(String returnMsg) {
            this.returnMsg = returnMsg;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostFundSaveFromSecuInnerOutput:(");
            buffer.append("paySerialNo:" + this.paySerialNo);
            buffer.append(",returnCode:" + this.returnCode);
            buffer.append(",returnMsg:" + this.returnMsg);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.paySerialNo);
            builder.append(this.returnCode);
            builder.append(this.returnMsg);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.PostFundSaveFromSecuInnerOutput) {
                InnerDfzqService.PostFundSaveFromSecuInnerOutput test = (InnerDfzqService.PostFundSaveFromSecuInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.paySerialNo, test.paySerialNo);
                builder.append(this.returnCode, test.returnCode);
                builder.append(this.returnMsg, test.returnMsg);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostFundSaveFromSecuInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @NotNull(
                message = "不能为空"
        )
        private Integer initDate = 0;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String fundAccount = " ";
        @SinogramLength(
                min = 1,
                max = 128,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String cancelSerialNo = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @SinogramLength(
                min = 1,
                max = 6,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String bankNo = " ";
        @NotNull(
                message = "不能为空"
        )
        @Digits(
                integer = 13,
                fraction = 2,
                message = "发生金额【occurBalance】 超出精度范围, 最大整数位为【13】, 小数位为【2】"
        )
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double occurBalance = 0.0D;

        public PostFundSaveFromSecuInnerInput() {
        }

        public Integer getInitDate() {
            return this.initDate != null ? this.initDate : 0;
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getCancelSerialNo() {
            if (this.cancelSerialNo == null) {
                return " ";
            } else {
                return this.cancelSerialNo.isEmpty() ? " " : this.cancelSerialNo;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public String getBankNo() {
            if (this.bankNo == null) {
                return " ";
            } else {
                return this.bankNo.isEmpty() ? " " : this.bankNo;
            }
        }

        public Double getOccurBalance() {
            return this.occurBalance != null ? this.occurBalance : 0.0D;
        }

        public void setInitDate(Integer initDate) {
            this.initDate = initDate;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setCancelSerialNo(String cancelSerialNo) {
            this.cancelSerialNo = cancelSerialNo;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setBankNo(String bankNo) {
            this.bankNo = bankNo;
        }

        public void setOccurBalance(Double occurBalance) {
            this.occurBalance = occurBalance;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostFundSaveFromSecuInnerInput:(");
            buffer.append("initDate:" + this.initDate);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",cancelSerialNo:" + this.cancelSerialNo);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",bankNo:" + this.bankNo);
            buffer.append(",occurBalance:" + this.occurBalance);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.initDate);
            builder.append(this.fundAccount);
            builder.append(this.cancelSerialNo);
            builder.append(this.opStation);
            builder.append(this.bankNo);
            builder.append(this.occurBalance);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.PostFundSaveFromSecuInnerInput) {
                InnerDfzqService.PostFundSaveFromSecuInnerInput test = (InnerDfzqService.PostFundSaveFromSecuInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.initDate, test.initDate);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.cancelSerialNo, test.cancelSerialNo);
                builder.append(this.opStation, test.opStation);
                builder.append(this.bankNo, test.bankNo);
                builder.append(this.occurBalance, test.occurBalance);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetSysConfigOptInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String branchCode = " ";
        private Integer dictEntry = 0;
        private String subEntry = " ";
        private String dictPrompt = " ";
        private String opRemark = " ";

        public GetSysConfigOptInnerOutput() {
        }

        public String getBranchCode() {
            if (this.branchCode == null) {
                return " ";
            } else {
                return this.branchCode.isEmpty() ? " " : this.branchCode;
            }
        }

        public Integer getDictEntry() {
            return this.dictEntry != null ? this.dictEntry : 0;
        }

        public String getSubEntry() {
            if (this.subEntry == null) {
                return " ";
            } else {
                return this.subEntry.isEmpty() ? " " : this.subEntry;
            }
        }

        public String getDictPrompt() {
            if (this.dictPrompt == null) {
                return " ";
            } else {
                return this.dictPrompt.isEmpty() ? " " : this.dictPrompt;
            }
        }

        public String getOpRemark() {
            if (this.opRemark == null) {
                return " ";
            } else {
                return this.opRemark.isEmpty() ? " " : this.opRemark;
            }
        }

        public void setBranchCode(String branchCode) {
            this.branchCode = branchCode;
        }

        public void setDictEntry(Integer dictEntry) {
            this.dictEntry = dictEntry;
        }

        public void setSubEntry(String subEntry) {
            this.subEntry = subEntry;
        }

        public void setDictPrompt(String dictPrompt) {
            this.dictPrompt = dictPrompt;
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetSysConfigOptInnerOutput:(");
            buffer.append("branchCode:" + this.branchCode);
            buffer.append(",dictEntry:" + this.dictEntry);
            buffer.append(",subEntry:" + this.subEntry);
            buffer.append(",dictPrompt:" + this.dictPrompt);
            buffer.append(",opRemark:" + this.opRemark);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.branchCode);
            builder.append(this.dictEntry);
            builder.append(this.subEntry);
            builder.append(this.dictPrompt);
            builder.append(this.opRemark);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.GetSysConfigOptInnerOutput) {
                InnerDfzqService.GetSysConfigOptInnerOutput test = (InnerDfzqService.GetSysConfigOptInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.branchCode, test.branchCode);
                builder.append(this.dictEntry, test.dictEntry);
                builder.append(this.subEntry, test.subEntry);
                builder.append(this.dictPrompt, test.dictPrompt);
                builder.append(this.opRemark, test.opRemark);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetSysConfigOptInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 1,
                max = 32,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String branchCode = " ";
        @NotNull(
                message = "不能为空"
        )
        private Integer dictEntry = 0;

        public GetSysConfigOptInnerInput() {
        }

        public String getBranchCode() {
            if (this.branchCode == null) {
                return " ";
            } else {
                return this.branchCode.isEmpty() ? " " : this.branchCode;
            }
        }

        public Integer getDictEntry() {
            return this.dictEntry != null ? this.dictEntry : 0;
        }

        public void setBranchCode(String branchCode) {
            this.branchCode = branchCode;
        }

        public void setDictEntry(Integer dictEntry) {
            this.dictEntry = dictEntry;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetSysConfigOptInnerInput:(");
            buffer.append("branchCode:" + this.branchCode);
            buffer.append(",dictEntry:" + this.dictEntry);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.branchCode);
            builder.append(this.dictEntry);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.GetSysConfigOptInnerInput) {
                InnerDfzqService.GetSysConfigOptInnerInput test = (InnerDfzqService.GetSysConfigOptInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.branchCode, test.branchCode);
                builder.append(this.dictEntry, test.dictEntry);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetSysConfigCrtInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String branchCode = " ";
        private Integer dictEntry = 0;
        private String subEntry = " ";
        private String dictPrompt = " ";
        private String opRemark = " ";

        public GetSysConfigCrtInnerOutput() {
        }

        public String getBranchCode() {
            if (this.branchCode == null) {
                return " ";
            } else {
                return this.branchCode.isEmpty() ? " " : this.branchCode;
            }
        }

        public Integer getDictEntry() {
            return this.dictEntry != null ? this.dictEntry : 0;
        }

        public String getSubEntry() {
            if (this.subEntry == null) {
                return " ";
            } else {
                return this.subEntry.isEmpty() ? " " : this.subEntry;
            }
        }

        public String getDictPrompt() {
            if (this.dictPrompt == null) {
                return " ";
            } else {
                return this.dictPrompt.isEmpty() ? " " : this.dictPrompt;
            }
        }

        public String getOpRemark() {
            if (this.opRemark == null) {
                return " ";
            } else {
                return this.opRemark.isEmpty() ? " " : this.opRemark;
            }
        }

        public void setBranchCode(String branchCode) {
            this.branchCode = branchCode;
        }

        public void setDictEntry(Integer dictEntry) {
            this.dictEntry = dictEntry;
        }

        public void setSubEntry(String subEntry) {
            this.subEntry = subEntry;
        }

        public void setDictPrompt(String dictPrompt) {
            this.dictPrompt = dictPrompt;
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetSysConfigCrtInnerOutput:(");
            buffer.append("branchCode:" + this.branchCode);
            buffer.append(",dictEntry:" + this.dictEntry);
            buffer.append(",subEntry:" + this.subEntry);
            buffer.append(",dictPrompt:" + this.dictPrompt);
            buffer.append(",opRemark:" + this.opRemark);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.branchCode);
            builder.append(this.dictEntry);
            builder.append(this.subEntry);
            builder.append(this.dictPrompt);
            builder.append(this.opRemark);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.GetSysConfigCrtInnerOutput) {
                InnerDfzqService.GetSysConfigCrtInnerOutput test = (InnerDfzqService.GetSysConfigCrtInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.branchCode, test.branchCode);
                builder.append(this.dictEntry, test.dictEntry);
                builder.append(this.subEntry, test.subEntry);
                builder.append(this.dictPrompt, test.dictPrompt);
                builder.append(this.opRemark, test.opRemark);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetSysConfigCrtInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 1,
                max = 32,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String branchCode = " ";
        @NotNull(
                message = "不能为空"
        )
        private Integer dictEntry = 0;

        public GetSysConfigCrtInnerInput() {
        }

        public String getBranchCode() {
            if (this.branchCode == null) {
                return " ";
            } else {
                return this.branchCode.isEmpty() ? " " : this.branchCode;
            }
        }

        public Integer getDictEntry() {
            return this.dictEntry != null ? this.dictEntry : 0;
        }

        public void setBranchCode(String branchCode) {
            this.branchCode = branchCode;
        }

        public void setDictEntry(Integer dictEntry) {
            this.dictEntry = dictEntry;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetSysConfigCrtInnerInput:(");
            buffer.append("branchCode:" + this.branchCode);
            buffer.append(",dictEntry:" + this.dictEntry);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.branchCode);
            builder.append(this.dictEntry);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.GetSysConfigCrtInnerInput) {
                InnerDfzqService.GetSysConfigCrtInnerInput test = (InnerDfzqService.GetSysConfigCrtInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.branchCode, test.branchCode);
                builder.append(this.dictEntry, test.dictEntry);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetFundaccountCloseCheckInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String checkStr = " ";

        public GetFundaccountCloseCheckInnerOutput() {
        }

        public String getCheckStr() {
            if (this.checkStr == null) {
                return " ";
            } else {
                return this.checkStr.isEmpty() ? " " : this.checkStr;
            }
        }

        public void setCheckStr(String checkStr) {
            this.checkStr = checkStr;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetFundaccountCloseCheckInnerOutput:(");
            buffer.append("checkStr:" + this.checkStr);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.checkStr);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.GetFundaccountCloseCheckInnerOutput) {
                InnerDfzqService.GetFundaccountCloseCheckInnerOutput test = (InnerDfzqService.GetFundaccountCloseCheckInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.checkStr, test.checkStr);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetFundaccountCloseCheckInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String fundAccount;

        public GetFundaccountCloseCheckInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            return this.opStation;
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay;
        }

        public String getClientId() {
            return this.clientId;
        }

        public String getFundAccount() {
            return this.fundAccount;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetFundaccountCloseCheckInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.clientId);
            builder.append(this.fundAccount);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.GetFundaccountCloseCheckInnerInput) {
                InnerDfzqService.GetFundaccountCloseCheckInnerInput test = (InnerDfzqService.GetFundaccountCloseCheckInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.clientId, test.clientId);
                builder.append(this.fundAccount, test.fundAccount);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetBankaccountCancelcheckInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String checkStr = " ";

        public GetBankaccountCancelcheckInnerOutput() {
        }

        public String getCheckStr() {
            if (this.checkStr == null) {
                return " ";
            } else {
                return this.checkStr.isEmpty() ? " " : this.checkStr;
            }
        }

        public void setCheckStr(String checkStr) {
            this.checkStr = checkStr;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetBankaccountCancelcheckInnerOutput:(");
            buffer.append("checkStr:" + this.checkStr);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.checkStr);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.GetBankaccountCancelcheckInnerOutput) {
                InnerDfzqService.GetBankaccountCancelcheckInnerOutput test = (InnerDfzqService.GetBankaccountCancelcheckInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.checkStr, test.checkStr);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetBankaccountCancelcheckInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String clientId;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String fundAccount;
        @SinogramLength(
                min = 0,
                max = 20,
                charset = "utf-8"
        )
        private String fundbkNo = " ";
        @SinogramLength(
                min = 0,
                max = 3,
                charset = "utf-8"
        )
        private String moneyType = " ";
        @SinogramLength(
                min = 0,
                max = 6,
                charset = "utf-8"
        )
        private String bankNo = " ";
        private Integer actionInT = 0;

        public GetBankaccountCancelcheckInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            return this.opStation;
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay;
        }

        public String getClientId() {
            return this.clientId;
        }

        public String getFundAccount() {
            return this.fundAccount;
        }

        public String getFundbkNo() {
            if (this.fundbkNo == null) {
                return " ";
            } else {
                return this.fundbkNo.isEmpty() ? " " : this.fundbkNo;
            }
        }

        public String getMoneyType() {
            if (this.moneyType == null) {
                return " ";
            } else {
                return this.moneyType.isEmpty() ? " " : this.moneyType;
            }
        }

        public String getBankNo() {
            if (this.bankNo == null) {
                return " ";
            } else {
                return this.bankNo.isEmpty() ? " " : this.bankNo;
            }
        }

        public Integer getActionInT() {
            return this.actionInT != null ? this.actionInT : 0;
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setFundbkNo(String fundbkNo) {
            this.fundbkNo = fundbkNo;
        }

        public void setMoneyType(String moneyType) {
            this.moneyType = moneyType;
        }

        public void setBankNo(String bankNo) {
            this.bankNo = bankNo;
        }

        public void setActionInT(Integer actionInT) {
            this.actionInT = actionInT;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetBankaccountCancelcheckInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",fundbkNo:" + this.fundbkNo);
            buffer.append(",moneyType:" + this.moneyType);
            buffer.append(",bankNo:" + this.bankNo);
            buffer.append(",actionInT:" + this.actionInT);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.clientId);
            builder.append(this.fundAccount);
            builder.append(this.fundbkNo);
            builder.append(this.moneyType);
            builder.append(this.bankNo);
            builder.append(this.actionInT);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.GetBankaccountCancelcheckInnerInput) {
                InnerDfzqService.GetBankaccountCancelcheckInnerInput test = (InnerDfzqService.GetBankaccountCancelcheckInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.clientId, test.clientId);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.fundbkNo, test.fundbkNo);
                builder.append(this.moneyType, test.moneyType);
                builder.append(this.bankNo, test.bankNo);
                builder.append(this.actionInT, test.actionInT);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetSysConfigSesInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String branchCode = " ";
        private Integer dictEntry = 0;
        private String subEntry = " ";
        private String dictPrompt = " ";
        private String opRemark = " ";

        public GetSysConfigSesInnerOutput() {
        }

        public String getBranchCode() {
            if (this.branchCode == null) {
                return " ";
            } else {
                return this.branchCode.isEmpty() ? " " : this.branchCode;
            }
        }

        public Integer getDictEntry() {
            return this.dictEntry != null ? this.dictEntry : 0;
        }

        public String getSubEntry() {
            if (this.subEntry == null) {
                return " ";
            } else {
                return this.subEntry.isEmpty() ? " " : this.subEntry;
            }
        }

        public String getDictPrompt() {
            if (this.dictPrompt == null) {
                return " ";
            } else {
                return this.dictPrompt.isEmpty() ? " " : this.dictPrompt;
            }
        }

        public String getOpRemark() {
            if (this.opRemark == null) {
                return " ";
            } else {
                return this.opRemark.isEmpty() ? " " : this.opRemark;
            }
        }

        public void setBranchCode(String branchCode) {
            this.branchCode = branchCode;
        }

        public void setDictEntry(Integer dictEntry) {
            this.dictEntry = dictEntry;
        }

        public void setSubEntry(String subEntry) {
            this.subEntry = subEntry;
        }

        public void setDictPrompt(String dictPrompt) {
            this.dictPrompt = dictPrompt;
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetSysConfigSesInnerOutput:(");
            buffer.append("branchCode:" + this.branchCode);
            buffer.append(",dictEntry:" + this.dictEntry);
            buffer.append(",subEntry:" + this.subEntry);
            buffer.append(",dictPrompt:" + this.dictPrompt);
            buffer.append(",opRemark:" + this.opRemark);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.branchCode);
            builder.append(this.dictEntry);
            builder.append(this.subEntry);
            builder.append(this.dictPrompt);
            builder.append(this.opRemark);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.GetSysConfigSesInnerOutput) {
                InnerDfzqService.GetSysConfigSesInnerOutput test = (InnerDfzqService.GetSysConfigSesInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.branchCode, test.branchCode);
                builder.append(this.dictEntry, test.dictEntry);
                builder.append(this.subEntry, test.subEntry);
                builder.append(this.dictPrompt, test.dictPrompt);
                builder.append(this.opRemark, test.opRemark);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetSysConfigSesInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 1,
                max = 32,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String branchCode = " ";
        @NotNull(
                message = "不能为空"
        )
        private Integer dictEntry = 0;

        public GetSysConfigSesInnerInput() {
        }

        public String getBranchCode() {
            if (this.branchCode == null) {
                return " ";
            } else {
                return this.branchCode.isEmpty() ? " " : this.branchCode;
            }
        }

        public Integer getDictEntry() {
            return this.dictEntry != null ? this.dictEntry : 0;
        }

        public void setBranchCode(String branchCode) {
            this.branchCode = branchCode;
        }

        public void setDictEntry(Integer dictEntry) {
            this.dictEntry = dictEntry;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetSysConfigSesInnerInput:(");
            buffer.append("branchCode:" + this.branchCode);
            buffer.append(",dictEntry:" + this.dictEntry);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.branchCode);
            builder.append(this.dictEntry);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.GetSysConfigSesInnerInput) {
                InnerDfzqService.GetSysConfigSesInnerInput test = (InnerDfzqService.GetSysConfigSesInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.branchCode, test.branchCode);
                builder.append(this.dictEntry, test.dictEntry);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetFundListByFundAccountInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String fundAccount = " ";
        private String moneyType = " ";
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double currentBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double enableBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double fetchCash = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double frozenBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double businessFrozenBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double businessUnfrozenBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double integralBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double interest = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double fineInterest = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double foregiftBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double mortgageBalance = 0.0D;
        private String opRemark = " ";

        public GetFundListByFundAccountInnerOutput() {
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getMoneyType() {
            if (this.moneyType == null) {
                return " ";
            } else {
                return this.moneyType.isEmpty() ? " " : this.moneyType;
            }
        }

        public Double getCurrentBalance() {
            return this.currentBalance != null ? this.currentBalance : 0.0D;
        }

        public Double getEnableBalance() {
            return this.enableBalance != null ? this.enableBalance : 0.0D;
        }

        public Double getFetchCash() {
            return this.fetchCash != null ? this.fetchCash : 0.0D;
        }

        public Double getFrozenBalance() {
            return this.frozenBalance != null ? this.frozenBalance : 0.0D;
        }

        public Double getBusinessFrozenBalance() {
            return this.businessFrozenBalance != null ? this.businessFrozenBalance : 0.0D;
        }

        public Double getBusinessUnfrozenBalance() {
            return this.businessUnfrozenBalance != null ? this.businessUnfrozenBalance : 0.0D;
        }

        public Double getIntegralBalance() {
            return this.integralBalance != null ? this.integralBalance : 0.0D;
        }

        public Double getInterest() {
            return this.interest != null ? this.interest : 0.0D;
        }

        public Double getFineInterest() {
            return this.fineInterest != null ? this.fineInterest : 0.0D;
        }

        public Double getForegiftBalance() {
            return this.foregiftBalance != null ? this.foregiftBalance : 0.0D;
        }

        public Double getMortgageBalance() {
            return this.mortgageBalance != null ? this.mortgageBalance : 0.0D;
        }

        public String getOpRemark() {
            if (this.opRemark == null) {
                return " ";
            } else {
                return this.opRemark.isEmpty() ? " " : this.opRemark;
            }
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setMoneyType(String moneyType) {
            this.moneyType = moneyType;
        }

        public void setCurrentBalance(Double currentBalance) {
            this.currentBalance = currentBalance;
        }

        public void setEnableBalance(Double enableBalance) {
            this.enableBalance = enableBalance;
        }

        public void setFetchCash(Double fetchCash) {
            this.fetchCash = fetchCash;
        }

        public void setFrozenBalance(Double frozenBalance) {
            this.frozenBalance = frozenBalance;
        }

        public void setBusinessFrozenBalance(Double businessFrozenBalance) {
            this.businessFrozenBalance = businessFrozenBalance;
        }

        public void setBusinessUnfrozenBalance(Double businessUnfrozenBalance) {
            this.businessUnfrozenBalance = businessUnfrozenBalance;
        }

        public void setIntegralBalance(Double integralBalance) {
            this.integralBalance = integralBalance;
        }

        public void setInterest(Double interest) {
            this.interest = interest;
        }

        public void setFineInterest(Double fineInterest) {
            this.fineInterest = fineInterest;
        }

        public void setForegiftBalance(Double foregiftBalance) {
            this.foregiftBalance = foregiftBalance;
        }

        public void setMortgageBalance(Double mortgageBalance) {
            this.mortgageBalance = mortgageBalance;
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetFundListByFundAccountInnerOutput:(");
            buffer.append("fundAccount:" + this.fundAccount);
            buffer.append(",moneyType:" + this.moneyType);
            buffer.append(",currentBalance:" + this.currentBalance);
            buffer.append(",enableBalance:" + this.enableBalance);
            buffer.append(",fetchCash:" + this.fetchCash);
            buffer.append(",frozenBalance:" + this.frozenBalance);
            buffer.append(",businessFrozenBalance:" + this.businessFrozenBalance);
            buffer.append(",businessUnfrozenBalance:" + this.businessUnfrozenBalance);
            buffer.append(",integralBalance:" + this.integralBalance);
            buffer.append(",interest:" + this.interest);
            buffer.append(",fineInterest:" + this.fineInterest);
            buffer.append(",foregiftBalance:" + this.foregiftBalance);
            buffer.append(",mortgageBalance:" + this.mortgageBalance);
            buffer.append(",opRemark:" + this.opRemark);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.fundAccount);
            builder.append(this.moneyType);
            builder.append(this.currentBalance);
            builder.append(this.enableBalance);
            builder.append(this.fetchCash);
            builder.append(this.frozenBalance);
            builder.append(this.businessFrozenBalance);
            builder.append(this.businessUnfrozenBalance);
            builder.append(this.integralBalance);
            builder.append(this.interest);
            builder.append(this.fineInterest);
            builder.append(this.foregiftBalance);
            builder.append(this.mortgageBalance);
            builder.append(this.opRemark);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.GetFundListByFundAccountInnerOutput) {
                InnerDfzqService.GetFundListByFundAccountInnerOutput test = (InnerDfzqService.GetFundListByFundAccountInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.moneyType, test.moneyType);
                builder.append(this.currentBalance, test.currentBalance);
                builder.append(this.enableBalance, test.enableBalance);
                builder.append(this.fetchCash, test.fetchCash);
                builder.append(this.frozenBalance, test.frozenBalance);
                builder.append(this.businessFrozenBalance, test.businessFrozenBalance);
                builder.append(this.businessUnfrozenBalance, test.businessUnfrozenBalance);
                builder.append(this.integralBalance, test.integralBalance);
                builder.append(this.interest, test.interest);
                builder.append(this.fineInterest, test.fineInterest);
                builder.append(this.foregiftBalance, test.foregiftBalance);
                builder.append(this.mortgageBalance, test.mortgageBalance);
                builder.append(this.opRemark, test.opRemark);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetFundListByFundAccountInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String operatorNo;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String auditOperatorNo;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String fundAccount;
        @SinogramLength(
                min = 1,
                max = 3,
                charset = "utf-8"
        )
        private String moneyType;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character assetProp;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character organFlag;

        public GetFundListByFundAccountInnerInput() {
        }

        public String getOpStation() {
            return this.opStation;
        }

        public String getOperatorNo() {
            return this.operatorNo;
        }

        public String getAuditOperatorNo() {
            return this.auditOperatorNo;
        }

        public String getFundAccount() {
            return this.fundAccount;
        }

        public String getMoneyType() {
            return this.moneyType;
        }

        public Character getAssetProp() {
            return this.assetProp;
        }

        public Character getOrganFlag() {
            return this.organFlag;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setAuditOperatorNo(String auditOperatorNo) {
            this.auditOperatorNo = auditOperatorNo;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setMoneyType(String moneyType) {
            this.moneyType = moneyType;
        }

        public void setAssetProp(Character assetProp) {
            this.assetProp = assetProp;
        }

        public void setOrganFlag(Character organFlag) {
            this.organFlag = organFlag;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetFundListByFundAccountInnerInput:(");
            buffer.append("opStation:" + this.opStation);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",auditOperatorNo:" + this.auditOperatorNo);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",moneyType:" + this.moneyType);
            buffer.append(",assetProp:" + this.assetProp);
            buffer.append(",organFlag:" + this.organFlag);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opStation);
            builder.append(this.operatorNo);
            builder.append(this.auditOperatorNo);
            builder.append(this.fundAccount);
            builder.append(this.moneyType);
            builder.append(this.assetProp);
            builder.append(this.organFlag);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.GetFundListByFundAccountInnerInput) {
                InnerDfzqService.GetFundListByFundAccountInnerInput test = (InnerDfzqService.GetFundListByFundAccountInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opStation, test.opStation);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.auditOperatorNo, test.auditOperatorNo);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.moneyType, test.moneyType);
                builder.append(this.assetProp, test.assetProp);
                builder.append(this.organFlag, test.organFlag);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetFundCustBalanceInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String fundAccount = " ";
        private String moneyType = " ";
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double currentBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double enableBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double fetchCash = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double frozenBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double businessFrozenBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double businessUnfrozenBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double integralBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double interest = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double fineInterest = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double foregiftBalance = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double mortgageBalance = 0.0D;
        private String opRemark = " ";

        public GetFundCustBalanceInnerOutput() {
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getMoneyType() {
            if (this.moneyType == null) {
                return " ";
            } else {
                return this.moneyType.isEmpty() ? " " : this.moneyType;
            }
        }

        public Double getCurrentBalance() {
            return this.currentBalance != null ? this.currentBalance : 0.0D;
        }

        public Double getEnableBalance() {
            return this.enableBalance != null ? this.enableBalance : 0.0D;
        }

        public Double getFetchCash() {
            return this.fetchCash != null ? this.fetchCash : 0.0D;
        }

        public Double getFrozenBalance() {
            return this.frozenBalance != null ? this.frozenBalance : 0.0D;
        }

        public Double getBusinessFrozenBalance() {
            return this.businessFrozenBalance != null ? this.businessFrozenBalance : 0.0D;
        }

        public Double getBusinessUnfrozenBalance() {
            return this.businessUnfrozenBalance != null ? this.businessUnfrozenBalance : 0.0D;
        }

        public Double getIntegralBalance() {
            return this.integralBalance != null ? this.integralBalance : 0.0D;
        }

        public Double getInterest() {
            return this.interest != null ? this.interest : 0.0D;
        }

        public Double getFineInterest() {
            return this.fineInterest != null ? this.fineInterest : 0.0D;
        }

        public Double getForegiftBalance() {
            return this.foregiftBalance != null ? this.foregiftBalance : 0.0D;
        }

        public Double getMortgageBalance() {
            return this.mortgageBalance != null ? this.mortgageBalance : 0.0D;
        }

        public String getOpRemark() {
            if (this.opRemark == null) {
                return " ";
            } else {
                return this.opRemark.isEmpty() ? " " : this.opRemark;
            }
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setMoneyType(String moneyType) {
            this.moneyType = moneyType;
        }

        public void setCurrentBalance(Double currentBalance) {
            this.currentBalance = currentBalance;
        }

        public void setEnableBalance(Double enableBalance) {
            this.enableBalance = enableBalance;
        }

        public void setFetchCash(Double fetchCash) {
            this.fetchCash = fetchCash;
        }

        public void setFrozenBalance(Double frozenBalance) {
            this.frozenBalance = frozenBalance;
        }

        public void setBusinessFrozenBalance(Double businessFrozenBalance) {
            this.businessFrozenBalance = businessFrozenBalance;
        }

        public void setBusinessUnfrozenBalance(Double businessUnfrozenBalance) {
            this.businessUnfrozenBalance = businessUnfrozenBalance;
        }

        public void setIntegralBalance(Double integralBalance) {
            this.integralBalance = integralBalance;
        }

        public void setInterest(Double interest) {
            this.interest = interest;
        }

        public void setFineInterest(Double fineInterest) {
            this.fineInterest = fineInterest;
        }

        public void setForegiftBalance(Double foregiftBalance) {
            this.foregiftBalance = foregiftBalance;
        }

        public void setMortgageBalance(Double mortgageBalance) {
            this.mortgageBalance = mortgageBalance;
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetFundCustBalanceInnerOutput:(");
            buffer.append("fundAccount:" + this.fundAccount);
            buffer.append(",moneyType:" + this.moneyType);
            buffer.append(",currentBalance:" + this.currentBalance);
            buffer.append(",enableBalance:" + this.enableBalance);
            buffer.append(",fetchCash:" + this.fetchCash);
            buffer.append(",frozenBalance:" + this.frozenBalance);
            buffer.append(",businessFrozenBalance:" + this.businessFrozenBalance);
            buffer.append(",businessUnfrozenBalance:" + this.businessUnfrozenBalance);
            buffer.append(",integralBalance:" + this.integralBalance);
            buffer.append(",interest:" + this.interest);
            buffer.append(",fineInterest:" + this.fineInterest);
            buffer.append(",foregiftBalance:" + this.foregiftBalance);
            buffer.append(",mortgageBalance:" + this.mortgageBalance);
            buffer.append(",opRemark:" + this.opRemark);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.fundAccount);
            builder.append(this.moneyType);
            builder.append(this.currentBalance);
            builder.append(this.enableBalance);
            builder.append(this.fetchCash);
            builder.append(this.frozenBalance);
            builder.append(this.businessFrozenBalance);
            builder.append(this.businessUnfrozenBalance);
            builder.append(this.integralBalance);
            builder.append(this.interest);
            builder.append(this.fineInterest);
            builder.append(this.foregiftBalance);
            builder.append(this.mortgageBalance);
            builder.append(this.opRemark);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.GetFundCustBalanceInnerOutput) {
                InnerDfzqService.GetFundCustBalanceInnerOutput test = (InnerDfzqService.GetFundCustBalanceInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.moneyType, test.moneyType);
                builder.append(this.currentBalance, test.currentBalance);
                builder.append(this.enableBalance, test.enableBalance);
                builder.append(this.fetchCash, test.fetchCash);
                builder.append(this.frozenBalance, test.frozenBalance);
                builder.append(this.businessFrozenBalance, test.businessFrozenBalance);
                builder.append(this.businessUnfrozenBalance, test.businessUnfrozenBalance);
                builder.append(this.integralBalance, test.integralBalance);
                builder.append(this.interest, test.interest);
                builder.append(this.fineInterest, test.fineInterest);
                builder.append(this.foregiftBalance, test.foregiftBalance);
                builder.append(this.mortgageBalance, test.mortgageBalance);
                builder.append(this.opRemark, test.opRemark);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetFundCustBalanceInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String operatorNo;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String auditOperatorNo;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String fundAccount;
        @SinogramLength(
                min = 1,
                max = 3,
                charset = "utf-8"
        )
        private String moneyType;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character assetProp;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character organFlag;

        public GetFundCustBalanceInnerInput() {
        }

        public String getOpStation() {
            return this.opStation;
        }

        public String getOperatorNo() {
            return this.operatorNo;
        }

        public String getAuditOperatorNo() {
            return this.auditOperatorNo;
        }

        public String getFundAccount() {
            return this.fundAccount;
        }

        public String getMoneyType() {
            return this.moneyType;
        }

        public Character getAssetProp() {
            return this.assetProp;
        }

        public Character getOrganFlag() {
            return this.organFlag;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setAuditOperatorNo(String auditOperatorNo) {
            this.auditOperatorNo = auditOperatorNo;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setMoneyType(String moneyType) {
            this.moneyType = moneyType;
        }

        public void setAssetProp(Character assetProp) {
            this.assetProp = assetProp;
        }

        public void setOrganFlag(Character organFlag) {
            this.organFlag = organFlag;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetFundCustBalanceInnerInput:(");
            buffer.append("opStation:" + this.opStation);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",auditOperatorNo:" + this.auditOperatorNo);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",moneyType:" + this.moneyType);
            buffer.append(",assetProp:" + this.assetProp);
            buffer.append(",organFlag:" + this.organFlag);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opStation);
            builder.append(this.operatorNo);
            builder.append(this.auditOperatorNo);
            builder.append(this.fundAccount);
            builder.append(this.moneyType);
            builder.append(this.assetProp);
            builder.append(this.organFlag);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.GetFundCustBalanceInnerInput) {
                InnerDfzqService.GetFundCustBalanceInnerInput test = (InnerDfzqService.GetFundCustBalanceInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opStation, test.opStation);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.auditOperatorNo, test.auditOperatorNo);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.moneyType, test.moneyType);
                builder.append(this.assetProp, test.assetProp);
                builder.append(this.organFlag, test.organFlag);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetBankaccountAcctInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String opRemark = " ";
        private String fundAccount = " ";
        private String bankNo = " ";
        private String moneyType = " ";
        private String bankAccount = " ";
        private Integer passwordErrors = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character bankFlag = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character bkaccountStatus = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character mainFlag = ' ';
        private String mainFundAccount = " ";
        private String fundbkNo = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character bkaccountRegflag = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character accountType = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character subType = ' ';

        public GetBankaccountAcctInnerOutput() {
        }

        public String getOpRemark() {
            if (this.opRemark == null) {
                return " ";
            } else {
                return this.opRemark.isEmpty() ? " " : this.opRemark;
            }
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getBankNo() {
            if (this.bankNo == null) {
                return " ";
            } else {
                return this.bankNo.isEmpty() ? " " : this.bankNo;
            }
        }

        public String getMoneyType() {
            if (this.moneyType == null) {
                return " ";
            } else {
                return this.moneyType.isEmpty() ? " " : this.moneyType;
            }
        }

        public String getBankAccount() {
            if (this.bankAccount == null) {
                return " ";
            } else {
                return this.bankAccount.isEmpty() ? " " : this.bankAccount;
            }
        }

        public Integer getPasswordErrors() {
            return this.passwordErrors != null ? this.passwordErrors : 0;
        }

        public Character getBankFlag() {
            return this.bankFlag != null ? this.bankFlag : ' ';
        }

        public Character getBkaccountStatus() {
            return this.bkaccountStatus != null ? this.bkaccountStatus : ' ';
        }

        public Character getMainFlag() {
            return this.mainFlag != null ? this.mainFlag : ' ';
        }

        public String getMainFundAccount() {
            if (this.mainFundAccount == null) {
                return " ";
            } else {
                return this.mainFundAccount.isEmpty() ? " " : this.mainFundAccount;
            }
        }

        public String getFundbkNo() {
            if (this.fundbkNo == null) {
                return " ";
            } else {
                return this.fundbkNo.isEmpty() ? " " : this.fundbkNo;
            }
        }

        public Character getBkaccountRegflag() {
            return this.bkaccountRegflag != null ? this.bkaccountRegflag : ' ';
        }

        public Character getAccountType() {
            return this.accountType != null ? this.accountType : ' ';
        }

        public Character getSubType() {
            return this.subType != null ? this.subType : ' ';
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setBankNo(String bankNo) {
            this.bankNo = bankNo;
        }

        public void setMoneyType(String moneyType) {
            this.moneyType = moneyType;
        }

        public void setBankAccount(String bankAccount) {
            this.bankAccount = bankAccount;
        }

        public void setPasswordErrors(Integer passwordErrors) {
            this.passwordErrors = passwordErrors;
        }

        public void setBankFlag(Character bankFlag) {
            this.bankFlag = bankFlag;
        }

        public void setBkaccountStatus(Character bkaccountStatus) {
            this.bkaccountStatus = bkaccountStatus;
        }

        public void setMainFlag(Character mainFlag) {
            this.mainFlag = mainFlag;
        }

        public void setMainFundAccount(String mainFundAccount) {
            this.mainFundAccount = mainFundAccount;
        }

        public void setFundbkNo(String fundbkNo) {
            this.fundbkNo = fundbkNo;
        }

        public void setBkaccountRegflag(Character bkaccountRegflag) {
            this.bkaccountRegflag = bkaccountRegflag;
        }

        public void setAccountType(Character accountType) {
            this.accountType = accountType;
        }

        public void setSubType(Character subType) {
            this.subType = subType;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetBankaccountAcctInnerOutput:(");
            buffer.append("opRemark:" + this.opRemark);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",bankNo:" + this.bankNo);
            buffer.append(",moneyType:" + this.moneyType);
            buffer.append(",bankAccount:" + this.bankAccount);
            buffer.append(",passwordErrors:" + this.passwordErrors);
            buffer.append(",bankFlag:" + this.bankFlag);
            buffer.append(",bkaccountStatus:" + this.bkaccountStatus);
            buffer.append(",mainFlag:" + this.mainFlag);
            buffer.append(",mainFundAccount:" + this.mainFundAccount);
            buffer.append(",fundbkNo:" + this.fundbkNo);
            buffer.append(",bkaccountRegflag:" + this.bkaccountRegflag);
            buffer.append(",accountType:" + this.accountType);
            buffer.append(",subType:" + this.subType);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opRemark);
            builder.append(this.fundAccount);
            builder.append(this.bankNo);
            builder.append(this.moneyType);
            builder.append(this.bankAccount);
            builder.append(this.passwordErrors);
            builder.append(this.bankFlag);
            builder.append(this.bkaccountStatus);
            builder.append(this.mainFlag);
            builder.append(this.mainFundAccount);
            builder.append(this.fundbkNo);
            builder.append(this.bkaccountRegflag);
            builder.append(this.accountType);
            builder.append(this.subType);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.GetBankaccountAcctInnerOutput) {
                InnerDfzqService.GetBankaccountAcctInnerOutput test = (InnerDfzqService.GetBankaccountAcctInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opRemark, test.opRemark);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.bankNo, test.bankNo);
                builder.append(this.moneyType, test.moneyType);
                builder.append(this.bankAccount, test.bankAccount);
                builder.append(this.passwordErrors, test.passwordErrors);
                builder.append(this.bankFlag, test.bankFlag);
                builder.append(this.bkaccountStatus, test.bkaccountStatus);
                builder.append(this.mainFlag, test.mainFlag);
                builder.append(this.mainFundAccount, test.mainFundAccount);
                builder.append(this.fundbkNo, test.fundbkNo);
                builder.append(this.bkaccountRegflag, test.bkaccountRegflag);
                builder.append(this.accountType, test.accountType);
                builder.append(this.subType, test.subType);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetBankaccountAcctInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String fundAccount = " ";
        @SinogramLength(
                min = 0,
                max = 6,
                charset = "utf-8"
        )
        private String bankNo = " ";
        @SinogramLength(
                min = 0,
                max = 3,
                charset = "utf-8"
        )
        private String moneyType = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String bankAccount = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character assetProp;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character organFlag;

        public GetBankaccountAcctInnerInput() {
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getBankNo() {
            if (this.bankNo == null) {
                return " ";
            } else {
                return this.bankNo.isEmpty() ? " " : this.bankNo;
            }
        }

        public String getMoneyType() {
            if (this.moneyType == null) {
                return " ";
            } else {
                return this.moneyType.isEmpty() ? " " : this.moneyType;
            }
        }

        public String getBankAccount() {
            if (this.bankAccount == null) {
                return " ";
            } else {
                return this.bankAccount.isEmpty() ? " " : this.bankAccount;
            }
        }

        public Character getAssetProp() {
            return this.assetProp;
        }

        public Character getOrganFlag() {
            return this.organFlag;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setBankNo(String bankNo) {
            this.bankNo = bankNo;
        }

        public void setMoneyType(String moneyType) {
            this.moneyType = moneyType;
        }

        public void setBankAccount(String bankAccount) {
            this.bankAccount = bankAccount;
        }

        public void setAssetProp(Character assetProp) {
            this.assetProp = assetProp;
        }

        public void setOrganFlag(Character organFlag) {
            this.organFlag = organFlag;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetBankaccountAcctInnerInput:(");
            buffer.append("fundAccount:" + this.fundAccount);
            buffer.append(",bankNo:" + this.bankNo);
            buffer.append(",moneyType:" + this.moneyType);
            buffer.append(",bankAccount:" + this.bankAccount);
            buffer.append(",assetProp:" + this.assetProp);
            buffer.append(",organFlag:" + this.organFlag);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.fundAccount);
            builder.append(this.bankNo);
            builder.append(this.moneyType);
            builder.append(this.bankAccount);
            builder.append(this.assetProp);
            builder.append(this.organFlag);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.GetBankaccountAcctInnerInput) {
                InnerDfzqService.GetBankaccountAcctInnerInput test = (InnerDfzqService.GetBankaccountAcctInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.bankNo, test.bankNo);
                builder.append(this.moneyType, test.moneyType);
                builder.append(this.bankAccount, test.bankAccount);
                builder.append(this.assetProp, test.assetProp);
                builder.append(this.organFlag, test.organFlag);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetBankaccountCtsAcctInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String opRemark = " ";
        private String fundAccount = " ";
        private String bankNo = " ";
        private String moneyType = " ";
        private String bankAccount = " ";
        private Integer passwordErrors = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character bankFlag = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character bkaccountStatus = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character mainFlag = ' ';
        private String mainFundAccount = " ";
        private String fundbkNo = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character bkaccountRegflag = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character accountType = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character subType = ' ';
        private Integer openDate = 0;
        private Character bkaccountType = ' ';

        public GetBankaccountCtsAcctInnerOutput() {
        }

        public String getOpRemark() {
            if (this.opRemark == null) {
                return " ";
            } else {
                return this.opRemark.isEmpty() ? " " : this.opRemark;
            }
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getBankNo() {
            if (this.bankNo == null) {
                return " ";
            } else {
                return this.bankNo.isEmpty() ? " " : this.bankNo;
            }
        }

        public String getMoneyType() {
            if (this.moneyType == null) {
                return " ";
            } else {
                return this.moneyType.isEmpty() ? " " : this.moneyType;
            }
        }

        public String getBankAccount() {
            if (this.bankAccount == null) {
                return " ";
            } else {
                return this.bankAccount.isEmpty() ? " " : this.bankAccount;
            }
        }

        public Integer getPasswordErrors() {
            return this.passwordErrors != null ? this.passwordErrors : 0;
        }

        public Character getBankFlag() {
            return this.bankFlag != null ? this.bankFlag : ' ';
        }

        public Character getBkaccountStatus() {
            return this.bkaccountStatus != null ? this.bkaccountStatus : ' ';
        }

        public Character getMainFlag() {
            return this.mainFlag != null ? this.mainFlag : ' ';
        }

        public String getMainFundAccount() {
            if (this.mainFundAccount == null) {
                return " ";
            } else {
                return this.mainFundAccount.isEmpty() ? " " : this.mainFundAccount;
            }
        }

        public String getFundbkNo() {
            if (this.fundbkNo == null) {
                return " ";
            } else {
                return this.fundbkNo.isEmpty() ? " " : this.fundbkNo;
            }
        }

        public Character getBkaccountRegflag() {
            return this.bkaccountRegflag != null ? this.bkaccountRegflag : ' ';
        }

        public Character getAccountType() {
            return this.accountType != null ? this.accountType : ' ';
        }

        public Character getSubType() {
            return this.subType != null ? this.subType : ' ';
        }

        public Integer getOpenDate() {
            return this.openDate != null ? this.openDate : 0;
        }

        public Character getBkaccountType() {
            return this.bkaccountType != null ? this.bkaccountType : ' ';
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setBankNo(String bankNo) {
            this.bankNo = bankNo;
        }

        public void setMoneyType(String moneyType) {
            this.moneyType = moneyType;
        }

        public void setBankAccount(String bankAccount) {
            this.bankAccount = bankAccount;
        }

        public void setPasswordErrors(Integer passwordErrors) {
            this.passwordErrors = passwordErrors;
        }

        public void setBankFlag(Character bankFlag) {
            this.bankFlag = bankFlag;
        }

        public void setBkaccountStatus(Character bkaccountStatus) {
            this.bkaccountStatus = bkaccountStatus;
        }

        public void setMainFlag(Character mainFlag) {
            this.mainFlag = mainFlag;
        }

        public void setMainFundAccount(String mainFundAccount) {
            this.mainFundAccount = mainFundAccount;
        }

        public void setFundbkNo(String fundbkNo) {
            this.fundbkNo = fundbkNo;
        }

        public void setBkaccountRegflag(Character bkaccountRegflag) {
            this.bkaccountRegflag = bkaccountRegflag;
        }

        public void setAccountType(Character accountType) {
            this.accountType = accountType;
        }

        public void setSubType(Character subType) {
            this.subType = subType;
        }

        public void setOpenDate(Integer openDate) {
            this.openDate = openDate;
        }

        public void setBkaccountType(Character bkaccountType) {
            this.bkaccountType = bkaccountType;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetBankaccountCtsAcctInnerOutput:(");
            buffer.append("opRemark:" + this.opRemark);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",bankNo:" + this.bankNo);
            buffer.append(",moneyType:" + this.moneyType);
            buffer.append(",bankAccount:" + this.bankAccount);
            buffer.append(",passwordErrors:" + this.passwordErrors);
            buffer.append(",bankFlag:" + this.bankFlag);
            buffer.append(",bkaccountStatus:" + this.bkaccountStatus);
            buffer.append(",mainFlag:" + this.mainFlag);
            buffer.append(",mainFundAccount:" + this.mainFundAccount);
            buffer.append(",fundbkNo:" + this.fundbkNo);
            buffer.append(",bkaccountRegflag:" + this.bkaccountRegflag);
            buffer.append(",accountType:" + this.accountType);
            buffer.append(",subType:" + this.subType);
            buffer.append(",openDate:" + this.openDate);
            buffer.append(",bkaccountType:" + this.bkaccountType);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opRemark);
            builder.append(this.fundAccount);
            builder.append(this.bankNo);
            builder.append(this.moneyType);
            builder.append(this.bankAccount);
            builder.append(this.passwordErrors);
            builder.append(this.bankFlag);
            builder.append(this.bkaccountStatus);
            builder.append(this.mainFlag);
            builder.append(this.mainFundAccount);
            builder.append(this.fundbkNo);
            builder.append(this.bkaccountRegflag);
            builder.append(this.accountType);
            builder.append(this.subType);
            builder.append(this.openDate);
            builder.append(this.bkaccountType);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.GetBankaccountCtsAcctInnerOutput) {
                InnerDfzqService.GetBankaccountCtsAcctInnerOutput test = (InnerDfzqService.GetBankaccountCtsAcctInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opRemark, test.opRemark);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.bankNo, test.bankNo);
                builder.append(this.moneyType, test.moneyType);
                builder.append(this.bankAccount, test.bankAccount);
                builder.append(this.passwordErrors, test.passwordErrors);
                builder.append(this.bankFlag, test.bankFlag);
                builder.append(this.bkaccountStatus, test.bkaccountStatus);
                builder.append(this.mainFlag, test.mainFlag);
                builder.append(this.mainFundAccount, test.mainFundAccount);
                builder.append(this.fundbkNo, test.fundbkNo);
                builder.append(this.bkaccountRegflag, test.bkaccountRegflag);
                builder.append(this.accountType, test.accountType);
                builder.append(this.subType, test.subType);
                builder.append(this.openDate, test.openDate);
                builder.append(this.bkaccountType, test.bkaccountType);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetBankaccountCtsAcctInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String fundAccount;
        @SinogramLength(
                min = 0,
                max = 6,
                charset = "utf-8"
        )
        private String bankNo = " ";
        @SinogramLength(
                min = 0,
                max = 3,
                charset = "utf-8"
        )
        private String moneyType = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String bankAccount = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character assetProp;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character organFlag;

        public GetBankaccountCtsAcctInnerInput() {
        }

        public String getFundAccount() {
            return this.fundAccount;
        }

        public String getBankNo() {
            if (this.bankNo == null) {
                return " ";
            } else {
                return this.bankNo.isEmpty() ? " " : this.bankNo;
            }
        }

        public String getMoneyType() {
            if (this.moneyType == null) {
                return " ";
            } else {
                return this.moneyType.isEmpty() ? " " : this.moneyType;
            }
        }

        public String getBankAccount() {
            if (this.bankAccount == null) {
                return " ";
            } else {
                return this.bankAccount.isEmpty() ? " " : this.bankAccount;
            }
        }

        public Character getAssetProp() {
            return this.assetProp;
        }

        public Character getOrganFlag() {
            return this.organFlag;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setBankNo(String bankNo) {
            this.bankNo = bankNo;
        }

        public void setMoneyType(String moneyType) {
            this.moneyType = moneyType;
        }

        public void setBankAccount(String bankAccount) {
            this.bankAccount = bankAccount;
        }

        public void setAssetProp(Character assetProp) {
            this.assetProp = assetProp;
        }

        public void setOrganFlag(Character organFlag) {
            this.organFlag = organFlag;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetBankaccountCtsAcctInnerInput:(");
            buffer.append("fundAccount:" + this.fundAccount);
            buffer.append(",bankNo:" + this.bankNo);
            buffer.append(",moneyType:" + this.moneyType);
            buffer.append(",bankAccount:" + this.bankAccount);
            buffer.append(",assetProp:" + this.assetProp);
            buffer.append(",organFlag:" + this.organFlag);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.fundAccount);
            builder.append(this.bankNo);
            builder.append(this.moneyType);
            builder.append(this.bankAccount);
            builder.append(this.assetProp);
            builder.append(this.organFlag);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.GetBankaccountCtsAcctInnerInput) {
                InnerDfzqService.GetBankaccountCtsAcctInnerInput test = (InnerDfzqService.GetBankaccountCtsAcctInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.bankNo, test.bankNo);
                builder.append(this.moneyType, test.moneyType);
                builder.append(this.bankAccount, test.bankAccount);
                builder.append(this.assetProp, test.assetProp);
                builder.append(this.organFlag, test.organFlag);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetfundAssetCertificationInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer businessDate = 0;
        private String fundAccountStr = " ";
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double rmbAsset = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double rmbMarketValue = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double currRmbTotalFinDebit = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double rmbTotal = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double usdAsset = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double usdMarketValue = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double usdTotal = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double hksAsset = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double hksMarketValue = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double hksTotal = 0.0D;
        private Integer printDate = 0;
        private Integer printTime = 0;
        private String errorCode = " ";
        private String errorMsg = " ";

        public GetfundAssetCertificationInnerOutput() {
        }

        public Integer getBusinessDate() {
            return this.businessDate != null ? this.businessDate : 0;
        }

        public String getFundAccountStr() {
            if (this.fundAccountStr == null) {
                return " ";
            } else {
                return this.fundAccountStr.isEmpty() ? " " : this.fundAccountStr;
            }
        }

        public Double getRmbAsset() {
            return this.rmbAsset != null ? this.rmbAsset : 0.0D;
        }

        public Double getRmbMarketValue() {
            return this.rmbMarketValue != null ? this.rmbMarketValue : 0.0D;
        }

        public Double getCurrRmbTotalFinDebit() {
            return this.currRmbTotalFinDebit != null ? this.currRmbTotalFinDebit : 0.0D;
        }

        public Double getRmbTotal() {
            return this.rmbTotal != null ? this.rmbTotal : 0.0D;
        }

        public Double getUsdAsset() {
            return this.usdAsset != null ? this.usdAsset : 0.0D;
        }

        public Double getUsdMarketValue() {
            return this.usdMarketValue != null ? this.usdMarketValue : 0.0D;
        }

        public Double getUsdTotal() {
            return this.usdTotal != null ? this.usdTotal : 0.0D;
        }

        public Double getHksAsset() {
            return this.hksAsset != null ? this.hksAsset : 0.0D;
        }

        public Double getHksMarketValue() {
            return this.hksMarketValue != null ? this.hksMarketValue : 0.0D;
        }

        public Double getHksTotal() {
            return this.hksTotal != null ? this.hksTotal : 0.0D;
        }

        public Integer getPrintDate() {
            return this.printDate != null ? this.printDate : 0;
        }

        public Integer getPrintTime() {
            return this.printTime != null ? this.printTime : 0;
        }

        public String getErrorCode() {
            if (this.errorCode == null) {
                return " ";
            } else {
                return this.errorCode.isEmpty() ? " " : this.errorCode;
            }
        }

        public String getErrorMsg() {
            if (this.errorMsg == null) {
                return " ";
            } else {
                return this.errorMsg.isEmpty() ? " " : this.errorMsg;
            }
        }

        public void setBusinessDate(Integer businessDate) {
            this.businessDate = businessDate;
        }

        public void setFundAccountStr(String fundAccountStr) {
            this.fundAccountStr = fundAccountStr;
        }

        public void setRmbAsset(Double rmbAsset) {
            this.rmbAsset = rmbAsset;
        }

        public void setRmbMarketValue(Double rmbMarketValue) {
            this.rmbMarketValue = rmbMarketValue;
        }

        public void setCurrRmbTotalFinDebit(Double currRmbTotalFinDebit) {
            this.currRmbTotalFinDebit = currRmbTotalFinDebit;
        }

        public void setRmbTotal(Double rmbTotal) {
            this.rmbTotal = rmbTotal;
        }

        public void setUsdAsset(Double usdAsset) {
            this.usdAsset = usdAsset;
        }

        public void setUsdMarketValue(Double usdMarketValue) {
            this.usdMarketValue = usdMarketValue;
        }

        public void setUsdTotal(Double usdTotal) {
            this.usdTotal = usdTotal;
        }

        public void setHksAsset(Double hksAsset) {
            this.hksAsset = hksAsset;
        }

        public void setHksMarketValue(Double hksMarketValue) {
            this.hksMarketValue = hksMarketValue;
        }

        public void setHksTotal(Double hksTotal) {
            this.hksTotal = hksTotal;
        }

        public void setPrintDate(Integer printDate) {
            this.printDate = printDate;
        }

        public void setPrintTime(Integer printTime) {
            this.printTime = printTime;
        }

        public void setErrorCode(String errorCode) {
            this.errorCode = errorCode;
        }

        public void setErrorMsg(String errorMsg) {
            this.errorMsg = errorMsg;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetfundAssetCertificationInnerOutput:(");
            buffer.append("businessDate:" + this.businessDate);
            buffer.append(",fundAccountStr:" + this.fundAccountStr);
            buffer.append(",rmbAsset:" + this.rmbAsset);
            buffer.append(",rmbMarketValue:" + this.rmbMarketValue);
            buffer.append(",currRmbTotalFinDebit:" + this.currRmbTotalFinDebit);
            buffer.append(",rmbTotal:" + this.rmbTotal);
            buffer.append(",usdAsset:" + this.usdAsset);
            buffer.append(",usdMarketValue:" + this.usdMarketValue);
            buffer.append(",usdTotal:" + this.usdTotal);
            buffer.append(",hksAsset:" + this.hksAsset);
            buffer.append(",hksMarketValue:" + this.hksMarketValue);
            buffer.append(",hksTotal:" + this.hksTotal);
            buffer.append(",printDate:" + this.printDate);
            buffer.append(",printTime:" + this.printTime);
            buffer.append(",errorCode:" + this.errorCode);
            buffer.append(",errorMsg:" + this.errorMsg);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.businessDate);
            builder.append(this.fundAccountStr);
            builder.append(this.rmbAsset);
            builder.append(this.rmbMarketValue);
            builder.append(this.currRmbTotalFinDebit);
            builder.append(this.rmbTotal);
            builder.append(this.usdAsset);
            builder.append(this.usdMarketValue);
            builder.append(this.usdTotal);
            builder.append(this.hksAsset);
            builder.append(this.hksMarketValue);
            builder.append(this.hksTotal);
            builder.append(this.printDate);
            builder.append(this.printTime);
            builder.append(this.errorCode);
            builder.append(this.errorMsg);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.GetfundAssetCertificationInnerOutput) {
                InnerDfzqService.GetfundAssetCertificationInnerOutput test = (InnerDfzqService.GetfundAssetCertificationInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.businessDate, test.businessDate);
                builder.append(this.fundAccountStr, test.fundAccountStr);
                builder.append(this.rmbAsset, test.rmbAsset);
                builder.append(this.rmbMarketValue, test.rmbMarketValue);
                builder.append(this.currRmbTotalFinDebit, test.currRmbTotalFinDebit);
                builder.append(this.rmbTotal, test.rmbTotal);
                builder.append(this.usdAsset, test.usdAsset);
                builder.append(this.usdMarketValue, test.usdMarketValue);
                builder.append(this.usdTotal, test.usdTotal);
                builder.append(this.hksAsset, test.hksAsset);
                builder.append(this.hksMarketValue, test.hksMarketValue);
                builder.append(this.hksTotal, test.hksTotal);
                builder.append(this.printDate, test.printDate);
                builder.append(this.printTime, test.printTime);
                builder.append(this.errorCode, test.errorCode);
                builder.append(this.errorMsg, test.errorMsg);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetfundAssetCertificationInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character userType = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String functionStr = " ";
        private Integer branchNo = 0;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String fundAccount = " ";

        public GetfundAssetCertificationInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public Character getUserType() {
            return this.userType != null ? this.userType : ' ';
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getFunctionStr() {
            if (this.functionStr == null) {
                return " ";
            } else {
                return this.functionStr.isEmpty() ? " " : this.functionStr;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setUserType(Character userType) {
            this.userType = userType;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setFunctionStr(String functionStr) {
            this.functionStr = functionStr;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetfundAssetCertificationInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",userType:" + this.userType);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",functionStr:" + this.functionStr);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.userType);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.functionStr);
            builder.append(this.branchNo);
            builder.append(this.fundAccount);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.GetfundAssetCertificationInnerInput) {
                InnerDfzqService.GetfundAssetCertificationInnerInput test = (InnerDfzqService.GetfundAssetCertificationInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.userType, test.userType);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.functionStr, test.functionStr);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.fundAccount, test.fundAccount);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class DeleteBankaccountAcctInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String opRemark = " ";
        private String returnSerialNo = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character subAccountFlag = ' ';
        private String fundAccount = " ";
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double interest = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double interestTax = 0.0D;
        private String fundAccountDest = " ";
        private String cancelMark = " ";

        public DeleteBankaccountAcctInnerOutput() {
        }

        public String getOpRemark() {
            if (this.opRemark == null) {
                return " ";
            } else {
                return this.opRemark.isEmpty() ? " " : this.opRemark;
            }
        }

        public String getReturnSerialNo() {
            if (this.returnSerialNo == null) {
                return " ";
            } else {
                return this.returnSerialNo.isEmpty() ? " " : this.returnSerialNo;
            }
        }

        public Character getSubAccountFlag() {
            return this.subAccountFlag != null ? this.subAccountFlag : ' ';
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public Double getInterest() {
            return this.interest != null ? this.interest : 0.0D;
        }

        public Double getInterestTax() {
            return this.interestTax != null ? this.interestTax : 0.0D;
        }

        public String getFundAccountDest() {
            if (this.fundAccountDest == null) {
                return " ";
            } else {
                return this.fundAccountDest.isEmpty() ? " " : this.fundAccountDest;
            }
        }

        public String getCancelMark() {
            if (this.cancelMark == null) {
                return " ";
            } else {
                return this.cancelMark.isEmpty() ? " " : this.cancelMark;
            }
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public void setReturnSerialNo(String returnSerialNo) {
            this.returnSerialNo = returnSerialNo;
        }

        public void setSubAccountFlag(Character subAccountFlag) {
            this.subAccountFlag = subAccountFlag;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setInterest(Double interest) {
            this.interest = interest;
        }

        public void setInterestTax(Double interestTax) {
            this.interestTax = interestTax;
        }

        public void setFundAccountDest(String fundAccountDest) {
            this.fundAccountDest = fundAccountDest;
        }

        public void setCancelMark(String cancelMark) {
            this.cancelMark = cancelMark;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("DeleteBankaccountAcctInnerOutput:(");
            buffer.append("opRemark:" + this.opRemark);
            buffer.append(",returnSerialNo:" + this.returnSerialNo);
            buffer.append(",subAccountFlag:" + this.subAccountFlag);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",interest:" + this.interest);
            buffer.append(",interestTax:" + this.interestTax);
            buffer.append(",fundAccountDest:" + this.fundAccountDest);
            buffer.append(",cancelMark:" + this.cancelMark);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opRemark);
            builder.append(this.returnSerialNo);
            builder.append(this.subAccountFlag);
            builder.append(this.fundAccount);
            builder.append(this.interest);
            builder.append(this.interestTax);
            builder.append(this.fundAccountDest);
            builder.append(this.cancelMark);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.DeleteBankaccountAcctInnerOutput) {
                InnerDfzqService.DeleteBankaccountAcctInnerOutput test = (InnerDfzqService.DeleteBankaccountAcctInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opRemark, test.opRemark);
                builder.append(this.returnSerialNo, test.returnSerialNo);
                builder.append(this.subAccountFlag, test.subAccountFlag);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.interest, test.interest);
                builder.append(this.interestTax, test.interestTax);
                builder.append(this.fundAccountDest, test.fundAccountDest);
                builder.append(this.cancelMark, test.cancelMark);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class DeleteBankaccountAcctInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation;
        @SinogramLength(
                min = 1,
                max = 2000,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String remark;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String auditOperatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String fundAccount;
        @SinogramLength(
                min = 1,
                max = 6,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String bankNo;
        @SinogramLength(
                min = 1,
                max = 3,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String moneyType;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String bkPassword = " ";
        private Integer passwordErrors = 0;
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String localMark = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character subAccountFlag = ' ';
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character assetProp;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character organFlag;
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String bankAccount = " ";

        public DeleteBankaccountAcctInnerInput() {
        }

        public String getOpStation() {
            return this.opStation;
        }

        public String getRemark() {
            return this.remark;
        }

        public String getOperatorNo() {
            return this.operatorNo;
        }

        public String getAuditOperatorNo() {
            if (this.auditOperatorNo == null) {
                return " ";
            } else {
                return this.auditOperatorNo.isEmpty() ? " " : this.auditOperatorNo;
            }
        }

        public String getFundAccount() {
            return this.fundAccount;
        }

        public String getBankNo() {
            return this.bankNo;
        }

        public String getMoneyType() {
            return this.moneyType;
        }

        public String getBkPassword() {
            if (this.bkPassword == null) {
                return " ";
            } else {
                return this.bkPassword.isEmpty() ? " " : this.bkPassword;
            }
        }

        public Integer getPasswordErrors() {
            return this.passwordErrors != null ? this.passwordErrors : 0;
        }

        public String getLocalMark() {
            if (this.localMark == null) {
                return " ";
            } else {
                return this.localMark.isEmpty() ? " " : this.localMark;
            }
        }

        public Character getSubAccountFlag() {
            return this.subAccountFlag != null ? this.subAccountFlag : ' ';
        }

        public Character getAssetProp() {
            return this.assetProp;
        }

        public Character getOrganFlag() {
            return this.organFlag;
        }

        public String getBankAccount() {
            if (this.bankAccount == null) {
                return " ";
            } else {
                return this.bankAccount.isEmpty() ? " " : this.bankAccount;
            }
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setAuditOperatorNo(String auditOperatorNo) {
            this.auditOperatorNo = auditOperatorNo;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setBankNo(String bankNo) {
            this.bankNo = bankNo;
        }

        public void setMoneyType(String moneyType) {
            this.moneyType = moneyType;
        }

        public void setBkPassword(String bkPassword) {
            this.bkPassword = bkPassword;
        }

        public void setPasswordErrors(Integer passwordErrors) {
            this.passwordErrors = passwordErrors;
        }

        public void setLocalMark(String localMark) {
            this.localMark = localMark;
        }

        public void setSubAccountFlag(Character subAccountFlag) {
            this.subAccountFlag = subAccountFlag;
        }

        public void setAssetProp(Character assetProp) {
            this.assetProp = assetProp;
        }

        public void setOrganFlag(Character organFlag) {
            this.organFlag = organFlag;
        }

        public void setBankAccount(String bankAccount) {
            this.bankAccount = bankAccount;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("DeleteBankaccountAcctInnerInput:(");
            buffer.append("opStation:" + this.opStation);
            buffer.append(",remark:" + this.remark);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",auditOperatorNo:" + this.auditOperatorNo);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",bankNo:" + this.bankNo);
            buffer.append(",moneyType:" + this.moneyType);
            buffer.append(",bkPassword:" + this.bkPassword);
            buffer.append(",passwordErrors:" + this.passwordErrors);
            buffer.append(",localMark:" + this.localMark);
            buffer.append(",subAccountFlag:" + this.subAccountFlag);
            buffer.append(",assetProp:" + this.assetProp);
            buffer.append(",organFlag:" + this.organFlag);
            buffer.append(",bankAccount:" + this.bankAccount);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opStation);
            builder.append(this.remark);
            builder.append(this.operatorNo);
            builder.append(this.auditOperatorNo);
            builder.append(this.fundAccount);
            builder.append(this.bankNo);
            builder.append(this.moneyType);
            builder.append(this.bkPassword);
            builder.append(this.passwordErrors);
            builder.append(this.localMark);
            builder.append(this.subAccountFlag);
            builder.append(this.assetProp);
            builder.append(this.organFlag);
            builder.append(this.bankAccount);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.DeleteBankaccountAcctInnerInput) {
                InnerDfzqService.DeleteBankaccountAcctInnerInput test = (InnerDfzqService.DeleteBankaccountAcctInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opStation, test.opStation);
                builder.append(this.remark, test.remark);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.auditOperatorNo, test.auditOperatorNo);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.bankNo, test.bankNo);
                builder.append(this.moneyType, test.moneyType);
                builder.append(this.bkPassword, test.bkPassword);
                builder.append(this.passwordErrors, test.passwordErrors);
                builder.append(this.localMark, test.localMark);
                builder.append(this.subAccountFlag, test.subAccountFlag);
                builder.append(this.assetProp, test.assetProp);
                builder.append(this.organFlag, test.organFlag);
                builder.append(this.bankAccount, test.bankAccount);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class DeleteBankCtsAcctInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String opRemark = " ";
        private String returnSerialNo = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character subAccountFlag = ' ';
        private String fundAccount = " ";
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double interest = 0.0D;
        @SerializeDoubleDigit(
                digit = 2
        )
        @JsonDeserialize(
                using = DoubleJsonDeserializer.class
        )
        private Double interestTax = 0.0D;
        private String fundAccountDest = " ";
        private String cancelMark = " ";

        public DeleteBankCtsAcctInnerOutput() {
        }

        public String getOpRemark() {
            if (this.opRemark == null) {
                return " ";
            } else {
                return this.opRemark.isEmpty() ? " " : this.opRemark;
            }
        }

        public String getReturnSerialNo() {
            if (this.returnSerialNo == null) {
                return " ";
            } else {
                return this.returnSerialNo.isEmpty() ? " " : this.returnSerialNo;
            }
        }

        public Character getSubAccountFlag() {
            return this.subAccountFlag != null ? this.subAccountFlag : ' ';
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public Double getInterest() {
            return this.interest != null ? this.interest : 0.0D;
        }

        public Double getInterestTax() {
            return this.interestTax != null ? this.interestTax : 0.0D;
        }

        public String getFundAccountDest() {
            if (this.fundAccountDest == null) {
                return " ";
            } else {
                return this.fundAccountDest.isEmpty() ? " " : this.fundAccountDest;
            }
        }

        public String getCancelMark() {
            if (this.cancelMark == null) {
                return " ";
            } else {
                return this.cancelMark.isEmpty() ? " " : this.cancelMark;
            }
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public void setReturnSerialNo(String returnSerialNo) {
            this.returnSerialNo = returnSerialNo;
        }

        public void setSubAccountFlag(Character subAccountFlag) {
            this.subAccountFlag = subAccountFlag;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setInterest(Double interest) {
            this.interest = interest;
        }

        public void setInterestTax(Double interestTax) {
            this.interestTax = interestTax;
        }

        public void setFundAccountDest(String fundAccountDest) {
            this.fundAccountDest = fundAccountDest;
        }

        public void setCancelMark(String cancelMark) {
            this.cancelMark = cancelMark;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("DeleteBankCtsAcctInnerOutput:(");
            buffer.append("opRemark:" + this.opRemark);
            buffer.append(",returnSerialNo:" + this.returnSerialNo);
            buffer.append(",subAccountFlag:" + this.subAccountFlag);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",interest:" + this.interest);
            buffer.append(",interestTax:" + this.interestTax);
            buffer.append(",fundAccountDest:" + this.fundAccountDest);
            buffer.append(",cancelMark:" + this.cancelMark);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opRemark);
            builder.append(this.returnSerialNo);
            builder.append(this.subAccountFlag);
            builder.append(this.fundAccount);
            builder.append(this.interest);
            builder.append(this.interestTax);
            builder.append(this.fundAccountDest);
            builder.append(this.cancelMark);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.DeleteBankCtsAcctInnerOutput) {
                InnerDfzqService.DeleteBankCtsAcctInnerOutput test = (InnerDfzqService.DeleteBankCtsAcctInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opRemark, test.opRemark);
                builder.append(this.returnSerialNo, test.returnSerialNo);
                builder.append(this.subAccountFlag, test.subAccountFlag);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.interest, test.interest);
                builder.append(this.interestTax, test.interestTax);
                builder.append(this.fundAccountDest, test.fundAccountDest);
                builder.append(this.cancelMark, test.cancelMark);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class DeleteBankCtsAcctInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation;
        @SinogramLength(
                min = 1,
                max = 2000,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String remark;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String auditOperatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String fundAccount;
        @SinogramLength(
                min = 1,
                max = 6,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String bankNo;
        @SinogramLength(
                min = 1,
                max = 3,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String moneyType;
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String bkPassword = " ";
        private Integer passwordErrors = 0;
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String localMark = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character subAccountFlag = ' ';
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character assetProp;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character organFlag;
        @SinogramLength(
                min = 0,
                max = 2,
                charset = "utf-8"
        )
        private String cancelPurpose = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String bankAccount = " ";

        public DeleteBankCtsAcctInnerInput() {
        }

        public String getOpStation() {
            return this.opStation;
        }

        public String getRemark() {
            return this.remark;
        }

        public String getOperatorNo() {
            return this.operatorNo;
        }

        public String getAuditOperatorNo() {
            if (this.auditOperatorNo == null) {
                return " ";
            } else {
                return this.auditOperatorNo.isEmpty() ? " " : this.auditOperatorNo;
            }
        }

        public String getFundAccount() {
            return this.fundAccount;
        }

        public String getBankNo() {
            return this.bankNo;
        }

        public String getMoneyType() {
            return this.moneyType;
        }

        public String getBkPassword() {
            if (this.bkPassword == null) {
                return " ";
            } else {
                return this.bkPassword.isEmpty() ? " " : this.bkPassword;
            }
        }

        public Integer getPasswordErrors() {
            return this.passwordErrors != null ? this.passwordErrors : 0;
        }

        public String getLocalMark() {
            if (this.localMark == null) {
                return " ";
            } else {
                return this.localMark.isEmpty() ? " " : this.localMark;
            }
        }

        public Character getSubAccountFlag() {
            return this.subAccountFlag != null ? this.subAccountFlag : ' ';
        }

        public Character getAssetProp() {
            return this.assetProp;
        }

        public Character getOrganFlag() {
            return this.organFlag;
        }

        public String getCancelPurpose() {
            if (this.cancelPurpose == null) {
                return " ";
            } else {
                return this.cancelPurpose.isEmpty() ? " " : this.cancelPurpose;
            }
        }

        public String getBankAccount() {
            if (this.bankAccount == null) {
                return " ";
            } else {
                return this.bankAccount.isEmpty() ? " " : this.bankAccount;
            }
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setAuditOperatorNo(String auditOperatorNo) {
            this.auditOperatorNo = auditOperatorNo;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setBankNo(String bankNo) {
            this.bankNo = bankNo;
        }

        public void setMoneyType(String moneyType) {
            this.moneyType = moneyType;
        }

        public void setBkPassword(String bkPassword) {
            this.bkPassword = bkPassword;
        }

        public void setPasswordErrors(Integer passwordErrors) {
            this.passwordErrors = passwordErrors;
        }

        public void setLocalMark(String localMark) {
            this.localMark = localMark;
        }

        public void setSubAccountFlag(Character subAccountFlag) {
            this.subAccountFlag = subAccountFlag;
        }

        public void setAssetProp(Character assetProp) {
            this.assetProp = assetProp;
        }

        public void setOrganFlag(Character organFlag) {
            this.organFlag = organFlag;
        }

        public void setCancelPurpose(String cancelPurpose) {
            this.cancelPurpose = cancelPurpose;
        }

        public void setBankAccount(String bankAccount) {
            this.bankAccount = bankAccount;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("DeleteBankCtsAcctInnerInput:(");
            buffer.append("opStation:" + this.opStation);
            buffer.append(",remark:" + this.remark);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",auditOperatorNo:" + this.auditOperatorNo);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",bankNo:" + this.bankNo);
            buffer.append(",moneyType:" + this.moneyType);
            buffer.append(",bkPassword:" + this.bkPassword);
            buffer.append(",passwordErrors:" + this.passwordErrors);
            buffer.append(",localMark:" + this.localMark);
            buffer.append(",subAccountFlag:" + this.subAccountFlag);
            buffer.append(",assetProp:" + this.assetProp);
            buffer.append(",organFlag:" + this.organFlag);
            buffer.append(",cancelPurpose:" + this.cancelPurpose);
            buffer.append(",bankAccount:" + this.bankAccount);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opStation);
            builder.append(this.remark);
            builder.append(this.operatorNo);
            builder.append(this.auditOperatorNo);
            builder.append(this.fundAccount);
            builder.append(this.bankNo);
            builder.append(this.moneyType);
            builder.append(this.bkPassword);
            builder.append(this.passwordErrors);
            builder.append(this.localMark);
            builder.append(this.subAccountFlag);
            builder.append(this.assetProp);
            builder.append(this.organFlag);
            builder.append(this.cancelPurpose);
            builder.append(this.bankAccount);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.DeleteBankCtsAcctInnerInput) {
                InnerDfzqService.DeleteBankCtsAcctInnerInput test = (InnerDfzqService.DeleteBankCtsAcctInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opStation, test.opStation);
                builder.append(this.remark, test.remark);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.auditOperatorNo, test.auditOperatorNo);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.bankNo, test.bankNo);
                builder.append(this.moneyType, test.moneyType);
                builder.append(this.bkPassword, test.bkPassword);
                builder.append(this.passwordErrors, test.passwordErrors);
                builder.append(this.localMark, test.localMark);
                builder.append(this.subAccountFlag, test.subAccountFlag);
                builder.append(this.assetProp, test.assetProp);
                builder.append(this.organFlag, test.organFlag);
                builder.append(this.cancelPurpose, test.cancelPurpose);
                builder.append(this.bankAccount, test.bankAccount);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetProdHolderListInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private Integer branchNo = 0;
        private String clientId = " ";
        private String fundAccount = " ";
        private String prodtaNo = " ";
        private String prodAccount = " ";
        private String transAccount = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character idKind = ' ';
        private String idNo = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character prodholderStatus = ' ';
        private Integer openDate = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character payKind = ' ';
        private String payAccount = " ";
        private String prodholderRights = " ";
        private String prodholderRestriction = " ";
        private String positionStr = " ";
        private String taName = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character prodholderKind = ' ';
        private String fullName = " ";

        public GetProdHolderListInnerOutput() {
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getProdtaNo() {
            if (this.prodtaNo == null) {
                return " ";
            } else {
                return this.prodtaNo.isEmpty() ? " " : this.prodtaNo;
            }
        }

        public String getProdAccount() {
            if (this.prodAccount == null) {
                return " ";
            } else {
                return this.prodAccount.isEmpty() ? " " : this.prodAccount;
            }
        }

        public String getTransAccount() {
            if (this.transAccount == null) {
                return " ";
            } else {
                return this.transAccount.isEmpty() ? " " : this.transAccount;
            }
        }

        public Character getIdKind() {
            return this.idKind != null ? this.idKind : ' ';
        }

        public String getIdNo() {
            if (this.idNo == null) {
                return " ";
            } else {
                return this.idNo.isEmpty() ? " " : this.idNo;
            }
        }

        public Character getProdholderStatus() {
            return this.prodholderStatus != null ? this.prodholderStatus : ' ';
        }

        public Integer getOpenDate() {
            return this.openDate != null ? this.openDate : 0;
        }

        public Character getPayKind() {
            return this.payKind != null ? this.payKind : ' ';
        }

        public String getPayAccount() {
            if (this.payAccount == null) {
                return " ";
            } else {
                return this.payAccount.isEmpty() ? " " : this.payAccount;
            }
        }

        public String getProdholderRights() {
            if (this.prodholderRights == null) {
                return " ";
            } else {
                return this.prodholderRights.isEmpty() ? " " : this.prodholderRights;
            }
        }

        public String getProdholderRestriction() {
            if (this.prodholderRestriction == null) {
                return " ";
            } else {
                return this.prodholderRestriction.isEmpty() ? " " : this.prodholderRestriction;
            }
        }

        public String getPositionStr() {
            if (this.positionStr == null) {
                return " ";
            } else {
                return this.positionStr.isEmpty() ? " " : this.positionStr;
            }
        }

        public String getTaName() {
            if (this.taName == null) {
                return " ";
            } else {
                return this.taName.isEmpty() ? " " : this.taName;
            }
        }

        public Character getProdholderKind() {
            return this.prodholderKind != null ? this.prodholderKind : ' ';
        }

        public String getFullName() {
            if (this.fullName == null) {
                return " ";
            } else {
                return this.fullName.isEmpty() ? " " : this.fullName;
            }
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setProdtaNo(String prodtaNo) {
            this.prodtaNo = prodtaNo;
        }

        public void setProdAccount(String prodAccount) {
            this.prodAccount = prodAccount;
        }

        public void setTransAccount(String transAccount) {
            this.transAccount = transAccount;
        }

        public void setIdKind(Character idKind) {
            this.idKind = idKind;
        }

        public void setIdNo(String idNo) {
            this.idNo = idNo;
        }

        public void setProdholderStatus(Character prodholderStatus) {
            this.prodholderStatus = prodholderStatus;
        }

        public void setOpenDate(Integer openDate) {
            this.openDate = openDate;
        }

        public void setPayKind(Character payKind) {
            this.payKind = payKind;
        }

        public void setPayAccount(String payAccount) {
            this.payAccount = payAccount;
        }

        public void setProdholderRights(String prodholderRights) {
            this.prodholderRights = prodholderRights;
        }

        public void setProdholderRestriction(String prodholderRestriction) {
            this.prodholderRestriction = prodholderRestriction;
        }

        public void setPositionStr(String positionStr) {
            this.positionStr = positionStr;
        }

        public void setTaName(String taName) {
            this.taName = taName;
        }

        public void setProdholderKind(Character prodholderKind) {
            this.prodholderKind = prodholderKind;
        }

        public void setFullName(String fullName) {
            this.fullName = fullName;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetProdHolderListInnerOutput:(");
            buffer.append("branchNo:" + this.branchNo);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",prodtaNo:" + this.prodtaNo);
            buffer.append(",prodAccount:" + this.prodAccount);
            buffer.append(",transAccount:" + this.transAccount);
            buffer.append(",idKind:" + this.idKind);
            buffer.append(",idNo:" + this.idNo);
            buffer.append(",prodholderStatus:" + this.prodholderStatus);
            buffer.append(",openDate:" + this.openDate);
            buffer.append(",payKind:" + this.payKind);
            buffer.append(",payAccount:" + this.payAccount);
            buffer.append(",prodholderRights:" + this.prodholderRights);
            buffer.append(",prodholderRestriction:" + this.prodholderRestriction);
            buffer.append(",positionStr:" + this.positionStr);
            buffer.append(",taName:" + this.taName);
            buffer.append(",prodholderKind:" + this.prodholderKind);
            buffer.append(",fullName:" + this.fullName);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.branchNo);
            builder.append(this.clientId);
            builder.append(this.fundAccount);
            builder.append(this.prodtaNo);
            builder.append(this.prodAccount);
            builder.append(this.transAccount);
            builder.append(this.idKind);
            builder.append(this.idNo);
            builder.append(this.prodholderStatus);
            builder.append(this.openDate);
            builder.append(this.payKind);
            builder.append(this.payAccount);
            builder.append(this.prodholderRights);
            builder.append(this.prodholderRestriction);
            builder.append(this.positionStr);
            builder.append(this.taName);
            builder.append(this.prodholderKind);
            builder.append(this.fullName);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.GetProdHolderListInnerOutput) {
                InnerDfzqService.GetProdHolderListInnerOutput test = (InnerDfzqService.GetProdHolderListInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.clientId, test.clientId);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.prodtaNo, test.prodtaNo);
                builder.append(this.prodAccount, test.prodAccount);
                builder.append(this.transAccount, test.transAccount);
                builder.append(this.idKind, test.idKind);
                builder.append(this.idNo, test.idNo);
                builder.append(this.prodholderStatus, test.prodholderStatus);
                builder.append(this.openDate, test.openDate);
                builder.append(this.payKind, test.payKind);
                builder.append(this.payAccount, test.payAccount);
                builder.append(this.prodholderRights, test.prodholderRights);
                builder.append(this.prodholderRestriction, test.prodholderRestriction);
                builder.append(this.positionStr, test.positionStr);
                builder.append(this.taName, test.taName);
                builder.append(this.prodholderKind, test.prodholderKind);
                builder.append(this.fullName, test.fullName);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetProdHolderListInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 255,
                charset = "utf-8"
        )
        private String opStation = " ";
        private Integer branchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String clientId = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String fundAccount = " ";
        @SinogramLength(
                min = 0,
                max = 24,
                charset = "utf-8"
        )
        private String prodtaNo = " ";
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String prodAccount = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character prodholderKind = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character payKind = ' ';
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String payAccount = " ";
        private Integer requestNum = 0;
        @SinogramLength(
                min = 0,
                max = 100,
                charset = "utf-8"
        )
        private String positionStr = " ";
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String enTaType = " ";
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String enProdholderStatus = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character idKind = ' ';
        @SinogramLength(
                min = 0,
                max = 40,
                charset = "utf-8"
        )
        private String idNo = " ";
        @SinogramLength(
                min = 0,
                max = 180,
                charset = "utf-8"
        )
        private String fullName = " ";
        @SinogramLength(
                min = 0,
                max = 2000,
                charset = "utf-8"
        )
        private String enProdtaNo = " ";

        public GetProdHolderListInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getClientId() {
            if (this.clientId == null) {
                return " ";
            } else {
                return this.clientId.isEmpty() ? " " : this.clientId;
            }
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getProdtaNo() {
            if (this.prodtaNo == null) {
                return " ";
            } else {
                return this.prodtaNo.isEmpty() ? " " : this.prodtaNo;
            }
        }

        public String getProdAccount() {
            if (this.prodAccount == null) {
                return " ";
            } else {
                return this.prodAccount.isEmpty() ? " " : this.prodAccount;
            }
        }

        public Character getProdholderKind() {
            return this.prodholderKind != null ? this.prodholderKind : ' ';
        }

        public Character getPayKind() {
            return this.payKind != null ? this.payKind : ' ';
        }

        public String getPayAccount() {
            if (this.payAccount == null) {
                return " ";
            } else {
                return this.payAccount.isEmpty() ? " " : this.payAccount;
            }
        }

        public Integer getRequestNum() {
            return this.requestNum != null ? this.requestNum : 0;
        }

        public String getPositionStr() {
            if (this.positionStr == null) {
                return " ";
            } else {
                return this.positionStr.isEmpty() ? " " : this.positionStr;
            }
        }

        public String getEnTaType() {
            if (this.enTaType == null) {
                return " ";
            } else {
                return this.enTaType.isEmpty() ? " " : this.enTaType;
            }
        }

        public String getEnProdholderStatus() {
            if (this.enProdholderStatus == null) {
                return " ";
            } else {
                return this.enProdholderStatus.isEmpty() ? " " : this.enProdholderStatus;
            }
        }

        public Character getIdKind() {
            return this.idKind != null ? this.idKind : ' ';
        }

        public String getIdNo() {
            if (this.idNo == null) {
                return " ";
            } else {
                return this.idNo.isEmpty() ? " " : this.idNo;
            }
        }

        public String getFullName() {
            if (this.fullName == null) {
                return " ";
            } else {
                return this.fullName.isEmpty() ? " " : this.fullName;
            }
        }

        public String getEnProdtaNo() {
            if (this.enProdtaNo == null) {
                return " ";
            } else {
                return this.enProdtaNo.isEmpty() ? " " : this.enProdtaNo;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setClientId(String clientId) {
            this.clientId = clientId;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setProdtaNo(String prodtaNo) {
            this.prodtaNo = prodtaNo;
        }

        public void setProdAccount(String prodAccount) {
            this.prodAccount = prodAccount;
        }

        public void setProdholderKind(Character prodholderKind) {
            this.prodholderKind = prodholderKind;
        }

        public void setPayKind(Character payKind) {
            this.payKind = payKind;
        }

        public void setPayAccount(String payAccount) {
            this.payAccount = payAccount;
        }

        public void setRequestNum(Integer requestNum) {
            this.requestNum = requestNum;
        }

        public void setPositionStr(String positionStr) {
            this.positionStr = positionStr;
        }

        public void setEnTaType(String enTaType) {
            this.enTaType = enTaType;
        }

        public void setEnProdholderStatus(String enProdholderStatus) {
            this.enProdholderStatus = enProdholderStatus;
        }

        public void setIdKind(Character idKind) {
            this.idKind = idKind;
        }

        public void setIdNo(String idNo) {
            this.idNo = idNo;
        }

        public void setFullName(String fullName) {
            this.fullName = fullName;
        }

        public void setEnProdtaNo(String enProdtaNo) {
            this.enProdtaNo = enProdtaNo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetProdHolderListInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",clientId:" + this.clientId);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",prodtaNo:" + this.prodtaNo);
            buffer.append(",prodAccount:" + this.prodAccount);
            buffer.append(",prodholderKind:" + this.prodholderKind);
            buffer.append(",payKind:" + this.payKind);
            buffer.append(",payAccount:" + this.payAccount);
            buffer.append(",requestNum:" + this.requestNum);
            buffer.append(",positionStr:" + this.positionStr);
            buffer.append(",enTaType:" + this.enTaType);
            buffer.append(",enProdholderStatus:" + this.enProdholderStatus);
            buffer.append(",idKind:" + this.idKind);
            buffer.append(",idNo:" + this.idNo);
            buffer.append(",fullName:" + this.fullName);
            buffer.append(",enProdtaNo:" + this.enProdtaNo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.opEntrustWay);
            builder.append(this.opStation);
            builder.append(this.branchNo);
            builder.append(this.clientId);
            builder.append(this.fundAccount);
            builder.append(this.prodtaNo);
            builder.append(this.prodAccount);
            builder.append(this.prodholderKind);
            builder.append(this.payKind);
            builder.append(this.payAccount);
            builder.append(this.requestNum);
            builder.append(this.positionStr);
            builder.append(this.enTaType);
            builder.append(this.enProdholderStatus);
            builder.append(this.idKind);
            builder.append(this.idNo);
            builder.append(this.fullName);
            builder.append(this.enProdtaNo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.GetProdHolderListInnerInput) {
                InnerDfzqService.GetProdHolderListInnerInput test = (InnerDfzqService.GetProdHolderListInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.opStation, test.opStation);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.clientId, test.clientId);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.prodtaNo, test.prodtaNo);
                builder.append(this.prodAccount, test.prodAccount);
                builder.append(this.prodholderKind, test.prodholderKind);
                builder.append(this.payKind, test.payKind);
                builder.append(this.payAccount, test.payAccount);
                builder.append(this.requestNum, test.requestNum);
                builder.append(this.positionStr, test.positionStr);
                builder.append(this.enTaType, test.enTaType);
                builder.append(this.enProdholderStatus, test.enProdholderStatus);
                builder.append(this.idKind, test.idKind);
                builder.append(this.idNo, test.idNo);
                builder.append(this.fullName, test.fullName);
                builder.append(this.enProdtaNo, test.enProdtaNo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetAdviserTransAccountCancelCheckInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String checkId = " ";
        private Integer noticeNo = 0;
        private String noticeInfo = " ";

        public GetAdviserTransAccountCancelCheckInnerOutput() {
        }

        public String getCheckId() {
            if (this.checkId == null) {
                return " ";
            } else {
                return this.checkId.isEmpty() ? " " : this.checkId;
            }
        }

        public Integer getNoticeNo() {
            return this.noticeNo != null ? this.noticeNo : 0;
        }

        public String getNoticeInfo() {
            if (this.noticeInfo == null) {
                return " ";
            } else {
                return this.noticeInfo.isEmpty() ? " " : this.noticeInfo;
            }
        }

        public void setCheckId(String checkId) {
            this.checkId = checkId;
        }

        public void setNoticeNo(Integer noticeNo) {
            this.noticeNo = noticeNo;
        }

        public void setNoticeInfo(String noticeInfo) {
            this.noticeInfo = noticeInfo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetAdviserTransAccountCancelCheckInnerOutput:(");
            buffer.append("checkId:" + this.checkId);
            buffer.append(",noticeNo:" + this.noticeNo);
            buffer.append(",noticeInfo:" + this.noticeInfo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.checkId);
            builder.append(this.noticeNo);
            builder.append(this.noticeInfo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.GetAdviserTransAccountCancelCheckInnerOutput) {
                InnerDfzqService.GetAdviserTransAccountCancelCheckInnerOutput test = (InnerDfzqService.GetAdviserTransAccountCancelCheckInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.checkId, test.checkId);
                builder.append(this.noticeNo, test.noticeNo);
                builder.append(this.noticeInfo, test.noticeInfo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetAdviserTransAccountCancelCheckInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character userType = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String functionStr = " ";
        private Integer branchNo = 0;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String fundAccount = " ";
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String adviserAccount = " ";
        @SinogramLength(
                min = 1,
                max = 32,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String transAccount = " ";

        public GetAdviserTransAccountCancelCheckInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public Character getUserType() {
            return this.userType != null ? this.userType : ' ';
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getFunctionStr() {
            if (this.functionStr == null) {
                return " ";
            } else {
                return this.functionStr.isEmpty() ? " " : this.functionStr;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getAdviserAccount() {
            if (this.adviserAccount == null) {
                return " ";
            } else {
                return this.adviserAccount.isEmpty() ? " " : this.adviserAccount;
            }
        }

        public String getTransAccount() {
            if (this.transAccount == null) {
                return " ";
            } else {
                return this.transAccount.isEmpty() ? " " : this.transAccount;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setUserType(Character userType) {
            this.userType = userType;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setFunctionStr(String functionStr) {
            this.functionStr = functionStr;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setAdviserAccount(String adviserAccount) {
            this.adviserAccount = adviserAccount;
        }

        public void setTransAccount(String transAccount) {
            this.transAccount = transAccount;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetAdviserTransAccountCancelCheckInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",userType:" + this.userType);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",functionStr:" + this.functionStr);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",adviserAccount:" + this.adviserAccount);
            buffer.append(",transAccount:" + this.transAccount);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.userType);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.functionStr);
            builder.append(this.branchNo);
            builder.append(this.fundAccount);
            builder.append(this.adviserAccount);
            builder.append(this.transAccount);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.GetAdviserTransAccountCancelCheckInnerInput) {
                InnerDfzqService.GetAdviserTransAccountCancelCheckInnerInput test = (InnerDfzqService.GetAdviserTransAccountCancelCheckInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.userType, test.userType);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.functionStr, test.functionStr);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.adviserAccount, test.adviserAccount);
                builder.append(this.transAccount, test.transAccount);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetAdviserAccountCancelCheckInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String checkId = " ";
        private Integer noticeNo = 0;
        private String noticeInfo = " ";

        public GetAdviserAccountCancelCheckInnerOutput() {
        }

        public String getCheckId() {
            if (this.checkId == null) {
                return " ";
            } else {
                return this.checkId.isEmpty() ? " " : this.checkId;
            }
        }

        public Integer getNoticeNo() {
            return this.noticeNo != null ? this.noticeNo : 0;
        }

        public String getNoticeInfo() {
            if (this.noticeInfo == null) {
                return " ";
            } else {
                return this.noticeInfo.isEmpty() ? " " : this.noticeInfo;
            }
        }

        public void setCheckId(String checkId) {
            this.checkId = checkId;
        }

        public void setNoticeNo(Integer noticeNo) {
            this.noticeNo = noticeNo;
        }

        public void setNoticeInfo(String noticeInfo) {
            this.noticeInfo = noticeInfo;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetAdviserAccountCancelCheckInnerOutput:(");
            buffer.append("checkId:" + this.checkId);
            buffer.append(",noticeNo:" + this.noticeNo);
            buffer.append(",noticeInfo:" + this.noticeInfo);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.checkId);
            builder.append(this.noticeNo);
            builder.append(this.noticeInfo);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.GetAdviserAccountCancelCheckInnerOutput) {
                InnerDfzqService.GetAdviserAccountCancelCheckInnerOutput test = (InnerDfzqService.GetAdviserAccountCancelCheckInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.checkId, test.checkId);
                builder.append(this.noticeNo, test.noticeNo);
                builder.append(this.noticeInfo, test.noticeInfo);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetAdviserAccountCancelCheckInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        private Integer opBranchNo = 0;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character userType = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String opPassword = " ";
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character opEntrustWay = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String functionStr = " ";
        private Integer branchNo = 0;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String fundAccount = " ";
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String adviserAccount = " ";

        public GetAdviserAccountCancelCheckInnerInput() {
        }

        public Integer getOpBranchNo() {
            return this.opBranchNo != null ? this.opBranchNo : 0;
        }

        public String getOperatorNo() {
            if (this.operatorNo == null) {
                return " ";
            } else {
                return this.operatorNo.isEmpty() ? " " : this.operatorNo;
            }
        }

        public Character getUserType() {
            return this.userType != null ? this.userType : ' ';
        }

        public String getOpPassword() {
            if (this.opPassword == null) {
                return " ";
            } else {
                return this.opPassword.isEmpty() ? " " : this.opPassword;
            }
        }

        public String getOpStation() {
            if (this.opStation == null) {
                return " ";
            } else {
                return this.opStation.isEmpty() ? " " : this.opStation;
            }
        }

        public Character getOpEntrustWay() {
            return this.opEntrustWay != null ? this.opEntrustWay : ' ';
        }

        public String getFunctionStr() {
            if (this.functionStr == null) {
                return " ";
            } else {
                return this.functionStr.isEmpty() ? " " : this.functionStr;
            }
        }

        public Integer getBranchNo() {
            return this.branchNo != null ? this.branchNo : 0;
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getAdviserAccount() {
            if (this.adviserAccount == null) {
                return " ";
            } else {
                return this.adviserAccount.isEmpty() ? " " : this.adviserAccount;
            }
        }

        public void setOpBranchNo(Integer opBranchNo) {
            this.opBranchNo = opBranchNo;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setUserType(Character userType) {
            this.userType = userType;
        }

        public void setOpPassword(String opPassword) {
            this.opPassword = opPassword;
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setOpEntrustWay(Character opEntrustWay) {
            this.opEntrustWay = opEntrustWay;
        }

        public void setFunctionStr(String functionStr) {
            this.functionStr = functionStr;
        }

        public void setBranchNo(Integer branchNo) {
            this.branchNo = branchNo;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setAdviserAccount(String adviserAccount) {
            this.adviserAccount = adviserAccount;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetAdviserAccountCancelCheckInnerInput:(");
            buffer.append("opBranchNo:" + this.opBranchNo);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",userType:" + this.userType);
            buffer.append(",opPassword:" + this.opPassword);
            buffer.append(",opStation:" + this.opStation);
            buffer.append(",opEntrustWay:" + this.opEntrustWay);
            buffer.append(",functionStr:" + this.functionStr);
            buffer.append(",branchNo:" + this.branchNo);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",adviserAccount:" + this.adviserAccount);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opBranchNo);
            builder.append(this.operatorNo);
            builder.append(this.userType);
            builder.append(this.opPassword);
            builder.append(this.opStation);
            builder.append(this.opEntrustWay);
            builder.append(this.functionStr);
            builder.append(this.branchNo);
            builder.append(this.fundAccount);
            builder.append(this.adviserAccount);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.GetAdviserAccountCancelCheckInnerInput) {
                InnerDfzqService.GetAdviserAccountCancelCheckInnerInput test = (InnerDfzqService.GetAdviserAccountCancelCheckInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opBranchNo, test.opBranchNo);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.userType, test.userType);
                builder.append(this.opPassword, test.opPassword);
                builder.append(this.opStation, test.opStation);
                builder.append(this.opEntrustWay, test.opEntrustWay);
                builder.append(this.functionStr, test.functionStr);
                builder.append(this.branchNo, test.branchNo);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.adviserAccount, test.adviserAccount);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostBankaccountAcctOpenInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String opRemark = " ";
        private String returnSerialNo = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character subAccountFlag = ' ';
        private String fundAccount = " ";

        public PostBankaccountAcctOpenInnerOutput() {
        }

        public String getOpRemark() {
            if (this.opRemark == null) {
                return " ";
            } else {
                return this.opRemark.isEmpty() ? " " : this.opRemark;
            }
        }

        public String getReturnSerialNo() {
            if (this.returnSerialNo == null) {
                return " ";
            } else {
                return this.returnSerialNo.isEmpty() ? " " : this.returnSerialNo;
            }
        }

        public Character getSubAccountFlag() {
            return this.subAccountFlag != null ? this.subAccountFlag : ' ';
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public void setReturnSerialNo(String returnSerialNo) {
            this.returnSerialNo = returnSerialNo;
        }

        public void setSubAccountFlag(Character subAccountFlag) {
            this.subAccountFlag = subAccountFlag;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostBankaccountAcctOpenInnerOutput:(");
            buffer.append("opRemark:" + this.opRemark);
            buffer.append(",returnSerialNo:" + this.returnSerialNo);
            buffer.append(",subAccountFlag:" + this.subAccountFlag);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opRemark);
            builder.append(this.returnSerialNo);
            builder.append(this.subAccountFlag);
            builder.append(this.fundAccount);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.PostBankaccountAcctOpenInnerOutput) {
                InnerDfzqService.PostBankaccountAcctOpenInnerOutput test = (InnerDfzqService.PostBankaccountAcctOpenInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opRemark, test.opRemark);
                builder.append(this.returnSerialNo, test.returnSerialNo);
                builder.append(this.subAccountFlag, test.subAccountFlag);
                builder.append(this.fundAccount, test.fundAccount);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostBankaccountAcctOpenInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation;
        @SinogramLength(
                min = 1,
                max = 2000,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String remark;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String auditOperatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String fundAccount;
        @SinogramLength(
                min = 1,
                max = 6,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String bankNo;
        @SinogramLength(
                min = 1,
                max = 3,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String moneyType;
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String bankAccount = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character mainFlag = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character encryptType = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String bkPassword = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character bankFlag = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character realbackFlag = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character accountType = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character secuAccountType = ' ';
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character assetProp;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character organFlag;
        @SinogramLength(
                min = 0,
                max = 4,
                charset = "utf-8"
        )
        private String localMark = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character idKind = ' ';
        @SinogramLength(
                min = 0,
                max = 40,
                charset = "utf-8"
        )
        private String idNo = " ";
        @SinogramLength(
                min = 0,
                max = 180,
                charset = "utf-8"
        )
        private String bankClientName = " ";
        @SinogramLength(
                min = 0,
                max = 90,
                charset = "utf-8"
        )
        private String clientName = " ";

        public PostBankaccountAcctOpenInnerInput() {
        }

        public String getOpStation() {
            return this.opStation;
        }

        public String getRemark() {
            return this.remark;
        }

        public String getOperatorNo() {
            return this.operatorNo;
        }

        public String getAuditOperatorNo() {
            if (this.auditOperatorNo == null) {
                return " ";
            } else {
                return this.auditOperatorNo.isEmpty() ? " " : this.auditOperatorNo;
            }
        }

        public String getFundAccount() {
            return this.fundAccount;
        }

        public String getBankNo() {
            return this.bankNo;
        }

        public String getMoneyType() {
            return this.moneyType;
        }

        public String getBankAccount() {
            if (this.bankAccount == null) {
                return " ";
            } else {
                return this.bankAccount.isEmpty() ? " " : this.bankAccount;
            }
        }

        public Character getMainFlag() {
            return this.mainFlag != null ? this.mainFlag : ' ';
        }

        public Character getEncryptType() {
            return this.encryptType != null ? this.encryptType : ' ';
        }

        public String getBkPassword() {
            if (this.bkPassword == null) {
                return " ";
            } else {
                return this.bkPassword.isEmpty() ? " " : this.bkPassword;
            }
        }

        public Character getBankFlag() {
            return this.bankFlag != null ? this.bankFlag : ' ';
        }

        public Character getRealbackFlag() {
            return this.realbackFlag != null ? this.realbackFlag : ' ';
        }

        public Character getAccountType() {
            return this.accountType != null ? this.accountType : ' ';
        }

        public Character getSecuAccountType() {
            return this.secuAccountType != null ? this.secuAccountType : ' ';
        }

        public Character getAssetProp() {
            return this.assetProp;
        }

        public Character getOrganFlag() {
            return this.organFlag;
        }

        public String getLocalMark() {
            if (this.localMark == null) {
                return " ";
            } else {
                return this.localMark.isEmpty() ? " " : this.localMark;
            }
        }

        public Character getIdKind() {
            return this.idKind != null ? this.idKind : ' ';
        }

        public String getIdNo() {
            if (this.idNo == null) {
                return " ";
            } else {
                return this.idNo.isEmpty() ? " " : this.idNo;
            }
        }

        public String getBankClientName() {
            if (this.bankClientName == null) {
                return " ";
            } else {
                return this.bankClientName.isEmpty() ? " " : this.bankClientName;
            }
        }

        public String getClientName() {
            if (this.clientName == null) {
                return " ";
            } else {
                return this.clientName.isEmpty() ? " " : this.clientName;
            }
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setAuditOperatorNo(String auditOperatorNo) {
            this.auditOperatorNo = auditOperatorNo;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setBankNo(String bankNo) {
            this.bankNo = bankNo;
        }

        public void setMoneyType(String moneyType) {
            this.moneyType = moneyType;
        }

        public void setBankAccount(String bankAccount) {
            this.bankAccount = bankAccount;
        }

        public void setMainFlag(Character mainFlag) {
            this.mainFlag = mainFlag;
        }

        public void setEncryptType(Character encryptType) {
            this.encryptType = encryptType;
        }

        public void setBkPassword(String bkPassword) {
            this.bkPassword = bkPassword;
        }

        public void setBankFlag(Character bankFlag) {
            this.bankFlag = bankFlag;
        }

        public void setRealbackFlag(Character realbackFlag) {
            this.realbackFlag = realbackFlag;
        }

        public void setAccountType(Character accountType) {
            this.accountType = accountType;
        }

        public void setSecuAccountType(Character secuAccountType) {
            this.secuAccountType = secuAccountType;
        }

        public void setAssetProp(Character assetProp) {
            this.assetProp = assetProp;
        }

        public void setOrganFlag(Character organFlag) {
            this.organFlag = organFlag;
        }

        public void setLocalMark(String localMark) {
            this.localMark = localMark;
        }

        public void setIdKind(Character idKind) {
            this.idKind = idKind;
        }

        public void setIdNo(String idNo) {
            this.idNo = idNo;
        }

        public void setBankClientName(String bankClientName) {
            this.bankClientName = bankClientName;
        }

        public void setClientName(String clientName) {
            this.clientName = clientName;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostBankaccountAcctOpenInnerInput:(");
            buffer.append("opStation:" + this.opStation);
            buffer.append(",remark:" + this.remark);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",auditOperatorNo:" + this.auditOperatorNo);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",bankNo:" + this.bankNo);
            buffer.append(",moneyType:" + this.moneyType);
            buffer.append(",bankAccount:" + this.bankAccount);
            buffer.append(",mainFlag:" + this.mainFlag);
            buffer.append(",encryptType:" + this.encryptType);
            buffer.append(",bkPassword:" + this.bkPassword);
            buffer.append(",bankFlag:" + this.bankFlag);
            buffer.append(",realbackFlag:" + this.realbackFlag);
            buffer.append(",accountType:" + this.accountType);
            buffer.append(",secuAccountType:" + this.secuAccountType);
            buffer.append(",assetProp:" + this.assetProp);
            buffer.append(",organFlag:" + this.organFlag);
            buffer.append(",localMark:" + this.localMark);
            buffer.append(",idKind:" + this.idKind);
            buffer.append(",idNo:" + this.idNo);
            buffer.append(",bankClientName:" + this.bankClientName);
            buffer.append(",clientName:" + this.clientName);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opStation);
            builder.append(this.remark);
            builder.append(this.operatorNo);
            builder.append(this.auditOperatorNo);
            builder.append(this.fundAccount);
            builder.append(this.bankNo);
            builder.append(this.moneyType);
            builder.append(this.bankAccount);
            builder.append(this.mainFlag);
            builder.append(this.encryptType);
            builder.append(this.bkPassword);
            builder.append(this.bankFlag);
            builder.append(this.realbackFlag);
            builder.append(this.accountType);
            builder.append(this.secuAccountType);
            builder.append(this.assetProp);
            builder.append(this.organFlag);
            builder.append(this.localMark);
            builder.append(this.idKind);
            builder.append(this.idNo);
            builder.append(this.bankClientName);
            builder.append(this.clientName);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.PostBankaccountAcctOpenInnerInput) {
                InnerDfzqService.PostBankaccountAcctOpenInnerInput test = (InnerDfzqService.PostBankaccountAcctOpenInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opStation, test.opStation);
                builder.append(this.remark, test.remark);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.auditOperatorNo, test.auditOperatorNo);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.bankNo, test.bankNo);
                builder.append(this.moneyType, test.moneyType);
                builder.append(this.bankAccount, test.bankAccount);
                builder.append(this.mainFlag, test.mainFlag);
                builder.append(this.encryptType, test.encryptType);
                builder.append(this.bkPassword, test.bkPassword);
                builder.append(this.bankFlag, test.bankFlag);
                builder.append(this.realbackFlag, test.realbackFlag);
                builder.append(this.accountType, test.accountType);
                builder.append(this.secuAccountType, test.secuAccountType);
                builder.append(this.assetProp, test.assetProp);
                builder.append(this.organFlag, test.organFlag);
                builder.append(this.localMark, test.localMark);
                builder.append(this.idKind, test.idKind);
                builder.append(this.idNo, test.idNo);
                builder.append(this.bankClientName, test.bankClientName);
                builder.append(this.clientName, test.clientName);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostBankCtsAcctOpenInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String opRemark = " ";
        private String returnSerialNo = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character subAccountFlag = ' ';
        private String fundAccount = " ";

        public PostBankCtsAcctOpenInnerOutput() {
        }

        public String getOpRemark() {
            if (this.opRemark == null) {
                return " ";
            } else {
                return this.opRemark.isEmpty() ? " " : this.opRemark;
            }
        }

        public String getReturnSerialNo() {
            if (this.returnSerialNo == null) {
                return " ";
            } else {
                return this.returnSerialNo.isEmpty() ? " " : this.returnSerialNo;
            }
        }

        public Character getSubAccountFlag() {
            return this.subAccountFlag != null ? this.subAccountFlag : ' ';
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public void setReturnSerialNo(String returnSerialNo) {
            this.returnSerialNo = returnSerialNo;
        }

        public void setSubAccountFlag(Character subAccountFlag) {
            this.subAccountFlag = subAccountFlag;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostBankCtsAcctOpenInnerOutput:(");
            buffer.append("opRemark:" + this.opRemark);
            buffer.append(",returnSerialNo:" + this.returnSerialNo);
            buffer.append(",subAccountFlag:" + this.subAccountFlag);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opRemark);
            builder.append(this.returnSerialNo);
            builder.append(this.subAccountFlag);
            builder.append(this.fundAccount);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.PostBankCtsAcctOpenInnerOutput) {
                InnerDfzqService.PostBankCtsAcctOpenInnerOutput test = (InnerDfzqService.PostBankCtsAcctOpenInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opRemark, test.opRemark);
                builder.append(this.returnSerialNo, test.returnSerialNo);
                builder.append(this.subAccountFlag, test.subAccountFlag);
                builder.append(this.fundAccount, test.fundAccount);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class PostBankCtsAcctOpenInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 1,
                max = 255,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String opStation;
        @SinogramLength(
                min = 1,
                max = 2000,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String remark;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        private String operatorNo;
        @SinogramLength(
                min = 0,
                max = 18,
                charset = "utf-8"
        )
        private String auditOperatorNo = " ";
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String fundAccount;
        @SinogramLength(
                min = 1,
                max = 6,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String bankNo;
        @SinogramLength(
                min = 1,
                max = 3,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String moneyType;
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String bankAccount = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character mainFlag = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character encryptType = ' ';
        @SinogramLength(
                min = 0,
                max = 64,
                charset = "utf-8"
        )
        private String bkPassword = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character bankFlag = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character realbackFlag = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character accountType = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character secuAccountType = ' ';
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character assetProp;
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character organFlag;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character bkaccountType = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character idKind = ' ';
        @SinogramLength(
                min = 0,
                max = 40,
                charset = "utf-8"
        )
        private String idNo = " ";
        @SinogramLength(
                min = 0,
                max = 180,
                charset = "utf-8"
        )
        private String bankClientName = " ";
        @SinogramLength(
                min = 0,
                max = 90,
                charset = "utf-8"
        )
        private String clientName = " ";

        public PostBankCtsAcctOpenInnerInput() {
        }

        public String getOpStation() {
            return this.opStation;
        }

        public String getRemark() {
            return this.remark;
        }

        public String getOperatorNo() {
            return this.operatorNo;
        }

        public String getAuditOperatorNo() {
            if (this.auditOperatorNo == null) {
                return " ";
            } else {
                return this.auditOperatorNo.isEmpty() ? " " : this.auditOperatorNo;
            }
        }

        public String getFundAccount() {
            return this.fundAccount;
        }

        public String getBankNo() {
            return this.bankNo;
        }

        public String getMoneyType() {
            return this.moneyType;
        }

        public String getBankAccount() {
            if (this.bankAccount == null) {
                return " ";
            } else {
                return this.bankAccount.isEmpty() ? " " : this.bankAccount;
            }
        }

        public Character getMainFlag() {
            return this.mainFlag != null ? this.mainFlag : ' ';
        }

        public Character getEncryptType() {
            return this.encryptType != null ? this.encryptType : ' ';
        }

        public String getBkPassword() {
            if (this.bkPassword == null) {
                return " ";
            } else {
                return this.bkPassword.isEmpty() ? " " : this.bkPassword;
            }
        }

        public Character getBankFlag() {
            return this.bankFlag != null ? this.bankFlag : ' ';
        }

        public Character getRealbackFlag() {
            return this.realbackFlag != null ? this.realbackFlag : ' ';
        }

        public Character getAccountType() {
            return this.accountType != null ? this.accountType : ' ';
        }

        public Character getSecuAccountType() {
            return this.secuAccountType != null ? this.secuAccountType : ' ';
        }

        public Character getAssetProp() {
            return this.assetProp;
        }

        public Character getOrganFlag() {
            return this.organFlag;
        }

        public Character getBkaccountType() {
            return this.bkaccountType != null ? this.bkaccountType : ' ';
        }

        public Character getIdKind() {
            return this.idKind != null ? this.idKind : ' ';
        }

        public String getIdNo() {
            if (this.idNo == null) {
                return " ";
            } else {
                return this.idNo.isEmpty() ? " " : this.idNo;
            }
        }

        public String getBankClientName() {
            if (this.bankClientName == null) {
                return " ";
            } else {
                return this.bankClientName.isEmpty() ? " " : this.bankClientName;
            }
        }

        public String getClientName() {
            if (this.clientName == null) {
                return " ";
            } else {
                return this.clientName.isEmpty() ? " " : this.clientName;
            }
        }

        public void setOpStation(String opStation) {
            this.opStation = opStation;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public void setOperatorNo(String operatorNo) {
            this.operatorNo = operatorNo;
        }

        public void setAuditOperatorNo(String auditOperatorNo) {
            this.auditOperatorNo = auditOperatorNo;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setBankNo(String bankNo) {
            this.bankNo = bankNo;
        }

        public void setMoneyType(String moneyType) {
            this.moneyType = moneyType;
        }

        public void setBankAccount(String bankAccount) {
            this.bankAccount = bankAccount;
        }

        public void setMainFlag(Character mainFlag) {
            this.mainFlag = mainFlag;
        }

        public void setEncryptType(Character encryptType) {
            this.encryptType = encryptType;
        }

        public void setBkPassword(String bkPassword) {
            this.bkPassword = bkPassword;
        }

        public void setBankFlag(Character bankFlag) {
            this.bankFlag = bankFlag;
        }

        public void setRealbackFlag(Character realbackFlag) {
            this.realbackFlag = realbackFlag;
        }

        public void setAccountType(Character accountType) {
            this.accountType = accountType;
        }

        public void setSecuAccountType(Character secuAccountType) {
            this.secuAccountType = secuAccountType;
        }

        public void setAssetProp(Character assetProp) {
            this.assetProp = assetProp;
        }

        public void setOrganFlag(Character organFlag) {
            this.organFlag = organFlag;
        }

        public void setBkaccountType(Character bkaccountType) {
            this.bkaccountType = bkaccountType;
        }

        public void setIdKind(Character idKind) {
            this.idKind = idKind;
        }

        public void setIdNo(String idNo) {
            this.idNo = idNo;
        }

        public void setBankClientName(String bankClientName) {
            this.bankClientName = bankClientName;
        }

        public void setClientName(String clientName) {
            this.clientName = clientName;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("PostBankCtsAcctOpenInnerInput:(");
            buffer.append("opStation:" + this.opStation);
            buffer.append(",remark:" + this.remark);
            buffer.append(",operatorNo:" + this.operatorNo);
            buffer.append(",auditOperatorNo:" + this.auditOperatorNo);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",bankNo:" + this.bankNo);
            buffer.append(",moneyType:" + this.moneyType);
            buffer.append(",bankAccount:" + this.bankAccount);
            buffer.append(",mainFlag:" + this.mainFlag);
            buffer.append(",encryptType:" + this.encryptType);
            buffer.append(",bkPassword:" + this.bkPassword);
            buffer.append(",bankFlag:" + this.bankFlag);
            buffer.append(",realbackFlag:" + this.realbackFlag);
            buffer.append(",accountType:" + this.accountType);
            buffer.append(",secuAccountType:" + this.secuAccountType);
            buffer.append(",assetProp:" + this.assetProp);
            buffer.append(",organFlag:" + this.organFlag);
            buffer.append(",bkaccountType:" + this.bkaccountType);
            buffer.append(",idKind:" + this.idKind);
            buffer.append(",idNo:" + this.idNo);
            buffer.append(",bankClientName:" + this.bankClientName);
            buffer.append(",clientName:" + this.clientName);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opStation);
            builder.append(this.remark);
            builder.append(this.operatorNo);
            builder.append(this.auditOperatorNo);
            builder.append(this.fundAccount);
            builder.append(this.bankNo);
            builder.append(this.moneyType);
            builder.append(this.bankAccount);
            builder.append(this.mainFlag);
            builder.append(this.encryptType);
            builder.append(this.bkPassword);
            builder.append(this.bankFlag);
            builder.append(this.realbackFlag);
            builder.append(this.accountType);
            builder.append(this.secuAccountType);
            builder.append(this.assetProp);
            builder.append(this.organFlag);
            builder.append(this.bkaccountType);
            builder.append(this.idKind);
            builder.append(this.idNo);
            builder.append(this.bankClientName);
            builder.append(this.clientName);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.PostBankCtsAcctOpenInnerInput) {
                InnerDfzqService.PostBankCtsAcctOpenInnerInput test = (InnerDfzqService.PostBankCtsAcctOpenInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opStation, test.opStation);
                builder.append(this.remark, test.remark);
                builder.append(this.operatorNo, test.operatorNo);
                builder.append(this.auditOperatorNo, test.auditOperatorNo);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.bankNo, test.bankNo);
                builder.append(this.moneyType, test.moneyType);
                builder.append(this.bankAccount, test.bankAccount);
                builder.append(this.mainFlag, test.mainFlag);
                builder.append(this.encryptType, test.encryptType);
                builder.append(this.bkPassword, test.bkPassword);
                builder.append(this.bankFlag, test.bankFlag);
                builder.append(this.realbackFlag, test.realbackFlag);
                builder.append(this.accountType, test.accountType);
                builder.append(this.secuAccountType, test.secuAccountType);
                builder.append(this.assetProp, test.assetProp);
                builder.append(this.organFlag, test.organFlag);
                builder.append(this.bkaccountType, test.bkaccountType);
                builder.append(this.idKind, test.idKind);
                builder.append(this.idNo, test.idNo);
                builder.append(this.bankClientName, test.bankClientName);
                builder.append(this.clientName, test.clientName);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetBankaccountInnerOutput implements Serializable {
        private static final long serialVersionUID = 1L;
        private String opRemark = " ";
        private String fundAccount = " ";
        private Integer openDate = 0;
        private String bankNo = " ";
        private String moneyType = " ";
        private String bankAccount = " ";
        private Integer passwordErrors = 0;
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character bankFlag = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character bkaccountStatus = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character mainFlag = ' ';
        private String mainFundAccount = " ";
        private String fundbkNo = " ";
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character bkaccountRegflag = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character accountType = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character subType = ' ';
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character bkaccountType = ' ';

        public GetBankaccountInnerOutput() {
        }

        public String getOpRemark() {
            if (this.opRemark == null) {
                return " ";
            } else {
                return this.opRemark.isEmpty() ? " " : this.opRemark;
            }
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public Integer getOpenDate() {
            return this.openDate != null ? this.openDate : 0;
        }

        public String getBankNo() {
            if (this.bankNo == null) {
                return " ";
            } else {
                return this.bankNo.isEmpty() ? " " : this.bankNo;
            }
        }

        public String getMoneyType() {
            if (this.moneyType == null) {
                return " ";
            } else {
                return this.moneyType.isEmpty() ? " " : this.moneyType;
            }
        }

        public String getBankAccount() {
            if (this.bankAccount == null) {
                return " ";
            } else {
                return this.bankAccount.isEmpty() ? " " : this.bankAccount;
            }
        }

        public Integer getPasswordErrors() {
            return this.passwordErrors != null ? this.passwordErrors : 0;
        }

        public Character getBankFlag() {
            return this.bankFlag != null ? this.bankFlag : ' ';
        }

        public Character getBkaccountStatus() {
            return this.bkaccountStatus != null ? this.bkaccountStatus : ' ';
        }

        public Character getMainFlag() {
            return this.mainFlag != null ? this.mainFlag : ' ';
        }

        public String getMainFundAccount() {
            if (this.mainFundAccount == null) {
                return " ";
            } else {
                return this.mainFundAccount.isEmpty() ? " " : this.mainFundAccount;
            }
        }

        public String getFundbkNo() {
            if (this.fundbkNo == null) {
                return " ";
            } else {
                return this.fundbkNo.isEmpty() ? " " : this.fundbkNo;
            }
        }

        public Character getBkaccountRegflag() {
            return this.bkaccountRegflag != null ? this.bkaccountRegflag : ' ';
        }

        public Character getAccountType() {
            return this.accountType != null ? this.accountType : ' ';
        }

        public Character getSubType() {
            return this.subType != null ? this.subType : ' ';
        }

        public Character getBkaccountType() {
            return this.bkaccountType != null ? this.bkaccountType : ' ';
        }

        public void setOpRemark(String opRemark) {
            this.opRemark = opRemark;
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setOpenDate(Integer openDate) {
            this.openDate = openDate;
        }

        public void setBankNo(String bankNo) {
            this.bankNo = bankNo;
        }

        public void setMoneyType(String moneyType) {
            this.moneyType = moneyType;
        }

        public void setBankAccount(String bankAccount) {
            this.bankAccount = bankAccount;
        }

        public void setPasswordErrors(Integer passwordErrors) {
            this.passwordErrors = passwordErrors;
        }

        public void setBankFlag(Character bankFlag) {
            this.bankFlag = bankFlag;
        }

        public void setBkaccountStatus(Character bkaccountStatus) {
            this.bkaccountStatus = bkaccountStatus;
        }

        public void setMainFlag(Character mainFlag) {
            this.mainFlag = mainFlag;
        }

        public void setMainFundAccount(String mainFundAccount) {
            this.mainFundAccount = mainFundAccount;
        }

        public void setFundbkNo(String fundbkNo) {
            this.fundbkNo = fundbkNo;
        }

        public void setBkaccountRegflag(Character bkaccountRegflag) {
            this.bkaccountRegflag = bkaccountRegflag;
        }

        public void setAccountType(Character accountType) {
            this.accountType = accountType;
        }

        public void setSubType(Character subType) {
            this.subType = subType;
        }

        public void setBkaccountType(Character bkaccountType) {
            this.bkaccountType = bkaccountType;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetBankaccountInnerOutput:(");
            buffer.append("opRemark:" + this.opRemark);
            buffer.append(",fundAccount:" + this.fundAccount);
            buffer.append(",openDate:" + this.openDate);
            buffer.append(",bankNo:" + this.bankNo);
            buffer.append(",moneyType:" + this.moneyType);
            buffer.append(",bankAccount:" + this.bankAccount);
            buffer.append(",passwordErrors:" + this.passwordErrors);
            buffer.append(",bankFlag:" + this.bankFlag);
            buffer.append(",bkaccountStatus:" + this.bkaccountStatus);
            buffer.append(",mainFlag:" + this.mainFlag);
            buffer.append(",mainFundAccount:" + this.mainFundAccount);
            buffer.append(",fundbkNo:" + this.fundbkNo);
            buffer.append(",bkaccountRegflag:" + this.bkaccountRegflag);
            buffer.append(",accountType:" + this.accountType);
            buffer.append(",subType:" + this.subType);
            buffer.append(",bkaccountType:" + this.bkaccountType);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.opRemark);
            builder.append(this.fundAccount);
            builder.append(this.openDate);
            builder.append(this.bankNo);
            builder.append(this.moneyType);
            builder.append(this.bankAccount);
            builder.append(this.passwordErrors);
            builder.append(this.bankFlag);
            builder.append(this.bkaccountStatus);
            builder.append(this.mainFlag);
            builder.append(this.mainFundAccount);
            builder.append(this.fundbkNo);
            builder.append(this.bkaccountRegflag);
            builder.append(this.accountType);
            builder.append(this.subType);
            builder.append(this.bkaccountType);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.GetBankaccountInnerOutput) {
                InnerDfzqService.GetBankaccountInnerOutput test = (InnerDfzqService.GetBankaccountInnerOutput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.opRemark, test.opRemark);
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.openDate, test.openDate);
                builder.append(this.bankNo, test.bankNo);
                builder.append(this.moneyType, test.moneyType);
                builder.append(this.bankAccount, test.bankAccount);
                builder.append(this.passwordErrors, test.passwordErrors);
                builder.append(this.bankFlag, test.bankFlag);
                builder.append(this.bkaccountStatus, test.bkaccountStatus);
                builder.append(this.mainFlag, test.mainFlag);
                builder.append(this.mainFundAccount, test.mainFundAccount);
                builder.append(this.fundbkNo, test.fundbkNo);
                builder.append(this.bkaccountRegflag, test.bkaccountRegflag);
                builder.append(this.accountType, test.accountType);
                builder.append(this.subType, test.subType);
                builder.append(this.bkaccountType, test.bkaccountType);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }

    public static class GetBankaccountInnerInput implements PublicParams, Serializable {
        private static final long serialVersionUID = 1L;
        @SinogramLength(
                min = 1,
                max = 18,
                charset = "utf-8"
        )
        @NotNull(
                message = "不能为空"
        )
        private String fundAccount = " ";
        @SinogramLength(
                min = 0,
                max = 6,
                charset = "utf-8"
        )
        private String bankNo = " ";
        @SinogramLength(
                min = 0,
                max = 3,
                charset = "utf-8"
        )
        private String moneyType = " ";
        @SinogramLength(
                min = 0,
                max = 32,
                charset = "utf-8"
        )
        private String bankAccount = " ";
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character assetProp = ' ';
        @NotNull(
                message = "不能为空"
        )
        @JsonDeserialize(
                using = CharacterJsonDeserializer.class
        )
        private Character organFlag = ' ';

        public GetBankaccountInnerInput() {
        }

        public String getFundAccount() {
            if (this.fundAccount == null) {
                return " ";
            } else {
                return this.fundAccount.isEmpty() ? " " : this.fundAccount;
            }
        }

        public String getBankNo() {
            if (this.bankNo == null) {
                return " ";
            } else {
                return this.bankNo.isEmpty() ? " " : this.bankNo;
            }
        }

        public String getMoneyType() {
            if (this.moneyType == null) {
                return " ";
            } else {
                return this.moneyType.isEmpty() ? " " : this.moneyType;
            }
        }

        public String getBankAccount() {
            if (this.bankAccount == null) {
                return " ";
            } else {
                return this.bankAccount.isEmpty() ? " " : this.bankAccount;
            }
        }

        public Character getAssetProp() {
            return this.assetProp != null ? this.assetProp : ' ';
        }

        public Character getOrganFlag() {
            return this.organFlag != null ? this.organFlag : ' ';
        }

        public void setFundAccount(String fundAccount) {
            this.fundAccount = fundAccount;
        }

        public void setBankNo(String bankNo) {
            this.bankNo = bankNo;
        }

        public void setMoneyType(String moneyType) {
            this.moneyType = moneyType;
        }

        public void setBankAccount(String bankAccount) {
            this.bankAccount = bankAccount;
        }

        public void setAssetProp(Character assetProp) {
            this.assetProp = assetProp;
        }

        public void setOrganFlag(Character organFlag) {
            this.organFlag = organFlag;
        }

        public String toString() {
            StringBuffer buffer = new StringBuffer();
            buffer.append("GetBankaccountInnerInput:(");
            buffer.append("fundAccount:" + this.fundAccount);
            buffer.append(",bankNo:" + this.bankNo);
            buffer.append(",moneyType:" + this.moneyType);
            buffer.append(",bankAccount:" + this.bankAccount);
            buffer.append(",assetProp:" + this.assetProp);
            buffer.append(",organFlag:" + this.organFlag);
            buffer.append(")");
            return buffer.toString();
        }

        public int hashCode() {
            HashCodeBuilder builder = new HashCodeBuilder();
            builder.append(this.fundAccount);
            builder.append(this.bankNo);
            builder.append(this.moneyType);
            builder.append(this.bankAccount);
            builder.append(this.assetProp);
            builder.append(this.organFlag);
            return builder.toHashCode();
        }

        public boolean equals(Object obj) {
            if (obj instanceof InnerDfzqService.GetBankaccountInnerInput) {
                InnerDfzqService.GetBankaccountInnerInput test = (InnerDfzqService.GetBankaccountInnerInput)obj;
                EqualsBuilder builder = new EqualsBuilder();
                builder.append(this.fundAccount, test.fundAccount);
                builder.append(this.bankNo, test.bankNo);
                builder.append(this.moneyType, test.moneyType);
                builder.append(this.bankAccount, test.bankAccount);
                builder.append(this.assetProp, test.assetProp);
                builder.append(this.organFlag, test.organFlag);
                return builder.isEquals();
            } else {
                return false;
            }
        }
    }
}
