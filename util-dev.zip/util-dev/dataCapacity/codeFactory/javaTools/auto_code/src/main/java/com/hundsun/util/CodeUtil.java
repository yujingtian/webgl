package com.hundsun.util;

import com.hundsun.constant.AutoCodeConstant;
import com.hundsun.exception.XmlContentErrorException;
import org.dom4j.DocumentException;

import java.io.*;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.*;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.FutureTask;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.logging.Logger;

/**
 * 单例模式，线程安全的懒汉模式
 * @author Star_King
 */
public class CodeUtil {
    private static CodeUtil codeUtil;
    private static final Logger LOGGER = Logger.getLogger("com.hundsun.util.CodeUtil");

    /**
     * 项目存放的路径
     */
    private String projectPath;

    /**
     * 任务目标，例如键为act.getOmnibusaccountCMS，值为search，
     * 表示act.getOmnibusaccountCMS-客户中和账务服务查询
     */
    private Map<String, String> target;

    private static final String ROOT_PATH = System.getProperty("user.dir");

    /**
     * xml文件的位置，必须与jar包同级
     */
    private static final String CONFIG_PATH = CodeUtil.class.getResource("/config.xml").getPath();

    /**
     * 执行任务所需要修改文件的文件名
     */
    private final Map<String, List<String>> FILES = new HashMap<>(16);

    private CodeUtil() {
    }

    /**
     * 单例模式
     * @return 唯一的CodeUtil对象
     */
    public static synchronized CodeUtil getCodeUtil() {
        if (codeUtil == null) {
            codeUtil = new CodeUtil();
        }
        return codeUtil;
    }

    /**
     * 生成代码入口函数
     */
    public void generateCode() {
        try {
            // 搭建环境
            FileUtil fileUtil = new FileUtil(CONFIG_PATH);
            // 获取项目路径
            this.projectPath = fileUtil.getProjectPath();
            // 获取目标任务
            this.target = fileUtil.getTARGET();
            // 打印上述解析结果
            printXmlResult();
            // 解析任务
            parseTarget();
            // 分配任务
            boolean taskSuccess = assignTask();
            if (taskSuccess) {
                LOGGER.info(AutoCodeConstant.EXECUTE_TASK_SUCCESS);
            } else {
                LOGGER.warning(AutoCodeConstant.EXECUTE_TASK_FAILED);
            }
            // 打印日志
        } catch (DocumentException e) {
            LOGGER.warning(AutoCodeConstant.READ_FILE_FAIL_MESSAGE);
        } catch (XmlContentErrorException e) {
            LOGGER.warning(AutoCodeConstant.XML_FILE_ERROR_MESSAGE);
        } catch (ExecutionException | InterruptedException e) {
            LOGGER.warning(AutoCodeConstant.EXECUTE_TASK_FAILED);
        }
    }

    /**
     * 打印xml文件的解析结果
     */
    private void printXmlResult() {
        System.out.println("XML文件解析结果:");
        System.out.println("projectPath : " + "\n\t" + projectPath);
        Set<String> stringSet = target.keySet();
        System.out.println("target : ");
        for (String s : stringSet) {
            System.out.println("\t" + s + " : " + target.get(s));
        }
        System.out.println();
    }

    /**
     * 解析完成任务所需要修改的文件
     */
    private void parseTarget() {
        Set<String> stringSet = target.keySet();
        for (String s : stringSet) {
            String[] split = s.split("\\.");
            String functionName = split[1];
            List<String> fileNames;
            if (functionName.endsWith("CMS")) {
                fileNames = new ArrayList<>(Arrays.asList(
                        "CmsService.java", "CmsServiceImpl.java", "CmsController.java", "BusinacctOutercmsController.java"));
            } else if (functionName.endsWith("EXT")){
                fileNames = new ArrayList<>(Arrays.asList(
                        "ExtService.java", "ExtServiceImpl.java", "ExtController.java", "BusinacctExtController.java"));
            } else {
                fileNames = new ArrayList<>(Arrays.asList(
                        "OutService.java", "OutServiceImpl.java", "OutController.java", "BusinacctOuterController.java"));
            }
            FILES.put(s, fileNames);
        }
    }

    /**
     * 解析字符串，如输入为act.getOmnibusaccountCMS，输出则为OmnibusaccountCMS
     */
    private String parseString(String str) {
        if (str.startsWith("post")) {
            return str.substring(4);
        } else {
            return str.substring(3);
        }
    }

    /**
     * 分配任务
     * return 执行任务成功标志，成功返回true，失败返回false
     */
    private boolean assignTask() throws ExecutionException, InterruptedException {
        CountDownLatch countDownLatch = new CountDownLatch(FILES.size());
        List<String> messages = new ArrayList<>(10);
        List<FutureTask<String>> tasks = new ArrayList<>(10);
        Set<String> stringSet = FILES.keySet();
        for (String s : stringSet) {
            // 创建任务并执行
            FutureTask<String> task = new FutureTask<>(() -> {
                LOGGER.info(Thread.currentThread().getName() + "线程开始执行" + s +"代码生成任务！");
                List<File> absoluteFiles = new ArrayList<>(10);
                List<String> fileNames = FILES.get(s);
                findFile(projectPath, fileNames, absoluteFiles);
                LOGGER.info(Thread.currentThread().getName() + "成功获取到了要修改的文件！");
                boolean success = generate(s, absoluteFiles);
                if (!success) {
                    LOGGER.warning(Thread.currentThread().getName() + "执行代码生成任务" + s +"失败！");
                    countDownLatch.countDown();
                    return "";
                } else {
                    LOGGER.info(Thread.currentThread().getName() + "执行代码生成任务" + s +"完成！");
                    countDownLatch.countDown();
                    return "success";
                }
            });
            tasks.add(task);
            AutoCodeConstant.THREAD_POOL.execute(task);
        }
        countDownLatch.await();
        for (FutureTask<String> task : tasks) {
            String message = task.get();
            messages.add(message);
        }
        // 关闭线程池
        AutoCodeConstant.THREAD_POOL.shutdownNow();
        for (String message : messages) {
            if (!"success".equals(message)) {
                return false;
            }
        }
        return true;
    }

    /**
     * 根据文件名，在项目中查找出文件的绝对路径
     *
     * @param fileNames 文件名数组
     */
    private void findFile(String projectPath, List<String> fileNames, List<File> absoluteFiles) {
        File project = new File(projectPath);
        if (project.exists()) {
            File[] files = project.listFiles();
            if (files != null && files.length != 0) {
                for (File file2 : files) {
                    if (file2.isDirectory()) {
                        findFile(file2.getAbsolutePath(), fileNames, absoluteFiles);
                    } else {
                        if (isLegalFile(file2.getName(), fileNames)) {
                            absoluteFiles.add(file2);
                        }
                    }
                }
            }
        } else {
            LOGGER.warning("文件不存在!");
        }
    }

    /**
     * 在遍历目录过程中判断某个文件是否为所需文件
     * @param fileName 文件名
     * @return 如果是返回true，不是返回false
     */
    private boolean isLegalFile(String fileName, List<String> fileNames) {
        for (String name : fileNames) {
            if (fileName.equals(name)) {
                return true;
            }
        }
        return false;
    }

    /**
     * 负责识别文件名和要修改的内容，具体对某个文件的修改方式，放在了各自的方法中
     *
     * @param methodName    要完成的任务，即微服务别名
     * @param absoluteFiles 文件的绝对路径
     * @return 修改文件成功标志，成功返回true，失败返回false
     */
    private boolean generate(String methodName, List<File> absoluteFiles) {
        String[] split = methodName.split("\\.");
        String functionName = split[1];
        String str = parseString(functionName);
        String str1 = target.get(methodName);
        if (functionName.startsWith("post") && str.endsWith("CMS")) {
            for (File absoluteFile : absoluteFiles) {
                boolean success = false;
                if (absoluteFile.getName().contains("CmsService.java")) {
                    success = executeService(absoluteFile, getTemplate("ServicePost.txt"), str, str1);
                } else if (absoluteFile.getName().contains("CmsServiceImpl.java")) {
                    success = executeServiceImpl(absoluteFile, getTemplate("ServiceImplPost.txt"), str);
                } else if (absoluteFile.getName().contains("CmsController.java")) {
                    success = executeController(absoluteFile, getTemplate("ControllerPost.txt"), str, "businacctOutercms");
                } else if (absoluteFile.getName().contains("BusinacctOutercmsController.java")) {
                    success = executeBusinacctOutercmsController(absoluteFile, getTemplate("BusinacctControllerPost.txt"), str);
                }
                if (!success) {
                    return false;
                }
            }
        } else if (functionName.startsWith("get") && str.endsWith("CMS")) {
            for (File absoluteFile : absoluteFiles) {
                boolean success = false;
                if (absoluteFile.getName().contains("CmsService.java")) {
                    success = executeService(absoluteFile, getTemplate("ServiceGet.txt"), str, str1);
                } else if (absoluteFile.getName().contains("CmsServiceImpl.java")) {
                    success = executeServiceImpl(absoluteFile, getTemplate("ServiceImplGet.txt"), str);
                } else if (absoluteFile.getName().contains("CmsController.java")) {
                    success = executeController(absoluteFile, getTemplate("ControllerGet.txt"), str, "businacctOutercms");
                } else if (absoluteFile.getName().contains("BusinacctOutercmsController.java")) {
                    success = executeBusinacctOutercmsController(absoluteFile, getTemplate("BusinacctControllerGet.txt"), str);
                }
                if (!success) {
                    return false;
                }
            }
        } else if (functionName.startsWith("post") && str.endsWith("Ext")) {
            for (File absoluteFile : absoluteFiles) {
                boolean success = false;
                if (absoluteFile.getName().contains("ExtService.java")) {
                    success = executeService(absoluteFile, getTemplate("ServicePost.txt"), str, str1);
                } else if (absoluteFile.getName().contains("ExtServiceImpl.java")) {
                    success = executeServiceImpl(absoluteFile, getTemplate("ServiceImplPost.txt"), str);
                } else if (absoluteFile.getName().contains("ExtController.java")) {
                    success = executeController(absoluteFile, getTemplate("ControllerPost.txt"), str, "businacctExt");
                } else if (absoluteFile.getName().contains("BusinacctExtController.java")) {
                    success = executeBusinacctOutercmsController(absoluteFile, getTemplate("BusinacctControllerPost.txt"), str);
                }
                if (!success) {
                    return false;
                }
            }
        } else if (functionName.startsWith("get") && str.endsWith("Ext")) {
            for (File absoluteFile : absoluteFiles) {
                boolean success = false;
                if (absoluteFile.getName().contains("ExtService.java")) {
                    success = executeService(absoluteFile, getTemplate("ServiceGet.txt"), str, str1);
                } else if (absoluteFile.getName().contains("ExtServiceImpl.java")) {
                    success = executeServiceImpl(absoluteFile, getTemplate("ServiceImplGet.txt"), str);
                } else if (absoluteFile.getName().contains("ExtController.java")) {
                    success = executeController(absoluteFile, getTemplate("ControllerGet.txt"), str, "businacctExt");
                } else if (absoluteFile.getName().contains("BusinacctExtController.java")) {
                    success = executeBusinacctOutercmsController(absoluteFile, getTemplate("BusinacctControllerGet.txt"), str);
                }
                if (!success) {
                    return false;
                }
            }
        } else if (functionName.startsWith("post") && str.endsWith("Out")) {
            for (File absoluteFile : absoluteFiles) {
                boolean success = false;
                if (absoluteFile.getName().contains("OutService.java")) {
                    success = executeService(absoluteFile, getTemplate("ServicePost.txt"), str, str1);
                } else if (absoluteFile.getName().contains("OutServiceImpl.java")) {
                    success = executeServiceImpl(absoluteFile, getTemplate("ServiceImplPost.txt"), str);
                } else if (absoluteFile.getName().contains("OutController.java")) {
                    success = executeController(absoluteFile, getTemplate("ControllerPost.txt"), str, "businacctOuter");
                } else if (absoluteFile.getName().contains("BusinacctOuterController.java")) {
                    success = executeBusinacctOutercmsController(absoluteFile, getTemplate("BusinacctControllerPost.txt"), str);
                }
                if (!success) {
                    return false;
                }
            }
        } else if (functionName.startsWith("get") && str.endsWith("Out")) {
            for (File absoluteFile : absoluteFiles) {
                boolean success = false;
                if (absoluteFile.getName().contains("OutService.java")) {
                    success = executeService(absoluteFile, getTemplate("ServiceGet.txt"), str, str1);
                } else if (absoluteFile.getName().contains("OutServiceImpl.java")) {
                    success = executeServiceImpl(absoluteFile, getTemplate("ServiceImplGet.txt"), str);
                } else if (absoluteFile.getName().contains("OutController.java")) {
                    success = executeController(absoluteFile, getTemplate("ControllerGet.txt"), str, "businacctOuter");
                } else if (absoluteFile.getName().contains("BusinacctOuterController.java")) {
                    success = executeBusinacctOutercmsController(absoluteFile, getTemplate("BusinacctControllerGet.txt"), str);
                }
                if (!success) {
                    return false;
                }
            }
        }
        return true;
    }

    /**
     * 根据模板文件名，获取模板文件
     */
    private InputStream getTemplate(String templateName) {
        return this.getClass().getClassLoader().getResourceAsStream(templateName);
    }

    /**
     * 对CmsService.java文件的锁
     */
    private static final Lock CMS_SERVICE_LOCK = new ReentrantLock();
    /**
     * 对ExtService.java文件的锁
     */
    private static final Lock EXT_SERVICE_LOCK = new ReentrantLock();
    /**
     * 对OutService.java文件的锁
     */
    private static final Lock OUT_SERVICE_LOCK = new ReentrantLock();
    /**
     * 在XXXService.java文件中写内容
     */
    private boolean executeService(File origin, InputStream templateStream, String str, String str1) {
        boolean success = false;
        if (origin.getName().contains("CmsService.java")) {
            CMS_SERVICE_LOCK.lock();
            try {
                success = execute(origin, templateStream, str, str1);
            } finally {
                CMS_SERVICE_LOCK.unlock();
            }
        } else if (origin.getName().contains("ExtService.java")) {
            EXT_SERVICE_LOCK.lock();
            try {
                success = execute(origin, templateStream, str, str1);
            } finally {
                EXT_SERVICE_LOCK.unlock();
            }
        } else if (origin.getName().contains("OutService.java")) {
            OUT_SERVICE_LOCK.lock();
            try {
                success = execute(origin, templateStream, str, str1);
            } finally {
                OUT_SERVICE_LOCK.unlock();
            }
        }
        return success;
    }

    /**
     * 对CmsServiceImpl.java文件的锁
     */
    private static final Lock CMS_SERVICE_IMPL_LOCK = new ReentrantLock();
    /**
     * 对ExtServiceImpl.java文件的锁
     */
    private static final Lock EXT_SERVICE_IMPL_LOCK = new ReentrantLock();
    /**
     * 对OutServiceImpl.java文件的锁
     */
    private static final Lock OUT_SERVICE_IMPL_LOCK = new ReentrantLock();
    /**
     * 在XXXServiceImpl.java文件中写内容
     */
    private boolean executeServiceImpl(File origin, InputStream templateStream, String str) {
        boolean success = false;
        if (origin.getName().contains("CmsServiceImpl.java")) {
            CMS_SERVICE_IMPL_LOCK.lock();
            try {
                success = execute(origin, templateStream, str, "");
            } finally {
                CMS_SERVICE_IMPL_LOCK.unlock();
            }
        } else if (origin.getName().contains("ExtServiceImpl.java")) {
            EXT_SERVICE_IMPL_LOCK.lock();
            try {
                success = execute(origin, templateStream, str, "");
            } finally {
                EXT_SERVICE_IMPL_LOCK.unlock();
            }
        } else if (origin.getName().contains("OutServiceImpl.java")) {
            OUT_SERVICE_IMPL_LOCK.lock();
            try {
                success = execute(origin, templateStream, str, "");
            } finally {
                OUT_SERVICE_IMPL_LOCK.unlock();
            }
        }
        return success;
    }

    /**
     * 对CmsController.java文件的锁
     */
    private static final Lock CMS_CONTROLLER_LOCK = new ReentrantLock();
    /**
     * 对ExtController.java文件的锁
     */
    private static final Lock EXT_CONTROLLER_LOCK = new ReentrantLock();
    /**
     * 对CmsController.java文件的锁
     */
    private static final Lock OUT_CONTROLLER_LOCK = new ReentrantLock();
    /**
     * 在XXXController.java文件中写内容
     */
    private boolean executeController(File origin, InputStream templateStream, String str, String str1) {
        boolean success = false;
        if (origin.getName().contains("CmsController.java")) {
            CMS_CONTROLLER_LOCK.lock();
            try {
                success = execute(origin, templateStream, str, str1);
            } finally {
                CMS_CONTROLLER_LOCK.unlock();
            }
        } else if (origin.getName().contains("ExtController.java")) {
            EXT_CONTROLLER_LOCK.lock();
            try {
                success = execute(origin, templateStream, str, str1);
            } finally {
                EXT_CONTROLLER_LOCK.unlock();
            }
        } else if (origin.getName().contains("OutController.java")) {
            OUT_CONTROLLER_LOCK.lock();
            try {
                success = execute(origin, templateStream, str, str1);
            } finally {
                OUT_CONTROLLER_LOCK.unlock();
            }
        }
        return success;
    }

    /**
     * 对BusinacctOutercmsController.java文件的锁
     */
    private static final Lock BUSINACCT_OUTERCMS_CONTROLLER_LOCK = new ReentrantLock();
    /**
     * 对BusinacctExtController.java文件的锁
     */
    private static final Lock BUSINACCT_EXT_CONTROLLER_LOCK = new ReentrantLock();
    /**
     * 对BusinacctOutController.java文件的锁
     */
    private static final Lock BUSINACCT_OUT_CONTROLLER_LOCK = new ReentrantLock();
    /**
     * 在BusinacctXXXController.java中追加代码
     */
    private boolean executeBusinacctOutercmsController(File origin, InputStream templateStream, String str) {
        boolean success = false;
        if (origin.getName().contains("BusinacctOutercmsController.java")) {
            BUSINACCT_OUTERCMS_CONTROLLER_LOCK.lock();
            try {
                success = execute(origin, templateStream, str, "");
            } finally {
                BUSINACCT_OUTERCMS_CONTROLLER_LOCK.unlock();
            }
        } else if (origin.getName().contains("BusinacctExtController.java")) {
            BUSINACCT_EXT_CONTROLLER_LOCK.lock();
            try {
                success = execute(origin, templateStream, str, "");
            } finally {
                BUSINACCT_EXT_CONTROLLER_LOCK.unlock();
            }
        } else if (origin.getName().contains("BusinacctOutController.java")) {
            BUSINACCT_OUT_CONTROLLER_LOCK.lock();
            try {
                success = execute(origin, templateStream, str, "");
            } finally {
                BUSINACCT_OUT_CONTROLLER_LOCK.unlock();
            }
        }
        return success;
    }

    /**
     * 将模板文件内容追加到源文件中
     */
    private boolean execute(File origin, InputStream templateStream, String str, String str1) {
        StringBuilder originContent = new StringBuilder();
        StringBuilder templateContent = new StringBuilder();
        try {
            InputStream originStream = new FileInputStream(origin);
            readFile(originStream, originContent);
            readFile(templateStream, templateContent);
        } catch (FileNotFoundException e) {
            LOGGER.warning("读文件时源文件" + origin.getName() +"不存在！");
            return false;
        } catch (IOException e) {
            LOGGER.warning("读取源文件" + origin.getName() + "失败！");
            return false;
        }
        originContent.deleteCharAt(originContent.length() - 2);
        String temp = templateContent.toString().replace("${str}", str).replace("${str1}", str1);
        templateContent = new StringBuilder(temp);
        originContent.append("\n").append(templateContent).append("\n").append("}");
        try {
            writeFile(origin, originContent);
            return true;
        } catch (FileNotFoundException e) {
            LOGGER.warning("写文件时源文件" + origin.getName() +"不存在！");
            return false;
        } catch (IOException e) {
            LOGGER.warning("写入源文件" + origin.getName() + "失败！");
            return false;
        }
    }

    /**
     * 读取某个文件内容
     */
    private void readFile(InputStream inputStream, StringBuilder content) throws IOException {
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
        String str;
        while ((str = bufferedReader.readLine()) != null) {
            content.append(str).append("\n");
        }
        bufferedReader.close();
        inputStream.close();
    }

    /**
     * 将内容写入某个文件
     */
    private void writeFile(File origin, StringBuilder originContent) throws IOException {
        FileOutputStream outputStream = new FileOutputStream(origin);
        byte[] bytesArray = originContent.toString().getBytes();
        outputStream.write(bytesArray);
        outputStream.flush();
        outputStream.close();
    }
}
