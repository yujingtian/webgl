package com.hundsun.exception;

/**
 * @author Star_King
 */
public class XmlContentErrorException extends RuntimeException {
    public XmlContentErrorException() {
    }

    public XmlContentErrorException(String message) {
        super(message);
    }

    public XmlContentErrorException(String message, Throwable cause) {
        super(message, cause);
    }

    public XmlContentErrorException(Throwable cause) {
        super(cause);
    }

    public XmlContentErrorException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
