package com.hundsun.constant;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * 项目中用到的一些常量
 * @author Star_King
 */
public class AutoCodeConstant {
    public static final String READ_FILE_FAIL_MESSAGE = "配置文件不存在！";
    public static final String XML_FILE_ERROR_MESSAGE = "配置文件内容出错！";
    public static final String EXECUTE_TASK_SUCCESS = "执行任务成功！";
    public static final String EXECUTE_TASK_FAILED = "执行任务失败！";

    private static final int CORE_NUM = Runtime.getRuntime().availableProcessors();

    public static final ThreadPoolExecutor THREAD_POOL = new ThreadPoolExecutor(CORE_NUM, 10, 300,
            TimeUnit.SECONDS, new ArrayBlockingQueue<Runnable>(5), new ThreadPoolExecutor.DiscardOldestPolicy());

    public static final List<String> POST_CMS = new ArrayList<>(Arrays.asList(
            "CmsService.java", "CmsServiceImpl.java", "CmsController.java"));
    public static final List<String> POST_EXT = new ArrayList<>(Arrays.asList(
            "ExtService.java", "ExtServiceImpl.java", "ExtController.java"));
    public static final List<String> POST_OUT = new ArrayList<>(Arrays.asList(
            "OutService.java", "OutServiceImpl.java", "OutController.java"));
    public static final List<String> GET_CMS = new ArrayList<>(Arrays.asList(
            "CmsService.java", "CmsServiceImpl.java", "CmsController.java"));
    public static final List<String> GET_EXT = new ArrayList<>(Arrays.asList(
            "ExtService.java", "ExtServiceImpl.java", "ExtController.java"));
    public static final List<String> GET_OUT = new ArrayList<>(Arrays.asList(
            "OutService.java", "OutServiceImpl.java", "OutController.java"));
}
