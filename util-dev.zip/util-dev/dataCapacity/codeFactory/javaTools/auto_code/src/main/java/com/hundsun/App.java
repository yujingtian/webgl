package com.hundsun;

import com.hundsun.util.CodeUtil;

/**
 * 主启动方法
 *
 * @author Star_King
 */
public class App {
    public static void main( String[] args ) {
        CodeUtil codeUtil = CodeUtil.getCodeUtil();
        codeUtil.generateCode();
    }
}
