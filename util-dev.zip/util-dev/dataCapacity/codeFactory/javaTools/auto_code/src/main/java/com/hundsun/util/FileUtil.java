package com.hundsun.util;

import com.hundsun.constant.AutoCodeConstant;
import com.hundsun.exception.XmlContentErrorException;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import java.io.File;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * @author Star_King
 */
public class FileUtil {
    private final Document DOC;

    private String projectPath;

    private final Map<String, String> TARGET = new HashMap<>(16);

    public String getProjectPath() {
        return projectPath;
    }

    public Map<String, String> getTARGET() {
        return TARGET;
    }

    public FileUtil(String iniConfigPath) throws DocumentException, XmlContentErrorException {
        SAXReader reader = new SAXReader();
        this.DOC = reader.read(new File(iniConfigPath));
        readConfiguration();
    }

    public void readConfiguration() {
        Element rootElement = DOC.getRootElement();
        if ("configuration".equals(rootElement.getName())) {
            Iterator<Element> rootIterator = rootElement.elementIterator();
            while (rootIterator.hasNext()) {
                Element next = rootIterator.next();
                String name = next.getName();
                if ("project".equals(name)) {
                    Element projectPath = next.element("projectPath");
                    this.projectPath = projectPath.attribute("path").getStringValue();
                } else if ("config".equals(name)) {
                    Iterator<Element> serviceIterator = next.elementIterator();
                    while (serviceIterator.hasNext()) {
                        Element service = serviceIterator.next();
                        String serviceName = service.attribute("name").getStringValue();
                        Element description = service.element("description");
                        String info = description.attribute("info").getStringValue();
                        TARGET.put(serviceName, info);
                    }
                } else {
                    throw new XmlContentErrorException(AutoCodeConstant.XML_FILE_ERROR_MESSAGE);
                }
            }
        } else {
            throw new XmlContentErrorException(AutoCodeConstant.XML_FILE_ERROR_MESSAGE);
        }
    }
}
