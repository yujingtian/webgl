# 本文件用来产生数据
import wmi
import time
import random
import string
import tools
import creatName
import buildID
import IDCheckOrBuild
import datetime
import getFiledInfo
import OracleDB
from dateutil.relativedelta import relativedelta
from faker import Faker

sUser = 'uf3'
sPwd = 'uf3uf3'
sIP = '10.20.26.67'
sPort = 33061
sSerName = 'hs_efficiency'


# 返回指定字典的随机值
def returnRandomDict(sDictEntry: str):
    if sDictEntry == '100':
        return str(random.randint(1, 100))
    else:
        OracleDB.GetDB()
        one, title = OracleDB.SelectDB(
            "select a.sub_entry,a.dict_prompt from hep_std_sub_dict_dept_tbl a \
                where exists(select 1 from hep_std_dict_dept_tbl b where b.uuid = a.dict_uuid and b.belong_id = 'hsbroker' and b.dict_entry='"
            + sDictEntry + "') ")
        OracleDB.CloseDB
        one = tools.FormatDBToList(one, title, isLower=True)
        if len(one) == 0:
            return ''
        else:
            iIndex = random.randint(0, len(one) - 1)
            return one[iIndex]['sub_entry']


# 返回C的数据类型
def getCType(sFiledType: str):
    if sFiledType in ['HsRate']:
        return 'N1'
    elif sFiledType in [
            'HsNumID', 'HsDate', 'HsTime', 'HsClientGroup', 'HsQuantity',
            'HsFutuCodeType', 'HsNum'
    ]:
        return 'N8'
    elif sFiledType in [
            'HsAmount', 'HsFunctionID', 'HsFunctionNo', 'HsHighPrice2',
            'HsHighPrice', 'HsSerialNo'
    ]:
        return 'N10'
    elif sFiledType in ['HsType', 'HsFlag', 'HsStatus']:
        return 'C1'
    elif sFiledType in ['HsMoneyType', 'HsType', 'HsFlag']:
        return 'C3'
    elif sFiledType in [
            'HsExchangeType', 'HsOtcType', 'HsStockType', 'HsMchType'
    ]:
        return 'C4'
    elif sFiledType in ['HsBankID']:
        return 'C6'
    elif sFiledType in ['HsOptCode', 'HsStockCode']:
        return 'C8'
    elif sFiledType in ['HsBondCode']:
        return 'C12'
    elif sFiledType in ['HsBondAccount', 'HsClientID', 'HsFundAccount']:
        return 'C18'
    elif sFiledType in ['HsBankSerialID', 'HsDateTime', 'HsStockAccount']:
        return 'C20'
    elif sFiledType in ['HsBankClientID']:
        return 'C22'
    elif sFiledType in [
            'HsBankAccount', 'HsCardID', 'HsFundstkAccount', 'HsOptName',
            'HsOtcAccount', 'HsOtcCode', 'HsOtcName', 'HsSchemeCode',
            'HsSdcAccount', 'HsSdcCode', 'HsSdcName', 'HsStockName',
            'HsIDENTITY', 'HsMchAccount', 'HsMchCode', 'HsPhone'
    ]:
        return 'C32'
    elif sFiledType in ['HsIDNo']:
        return 'C40'
    elif sFiledType in ['HsName']:
        return 'C60'
    elif sFiledType in ['HsName2']:
        return 'C64'
    elif sFiledType in ['HsName5']:
        return 'C90'
    elif sFiledType in ['HsName3', 'HsAddress']:
        return 'C120'
    elif sFiledType in ['HsName4', 'HsAddress1']:
        return 'C180'
    elif sFiledType in ['HsStation']:
        return 'C255'
    elif sFiledType in ['HsJson']:
        return 'C4000'
    elif 'HsChar' in sFiledType:
        return 'C' + sFiledType.replace('HsChar', '').replace('List', '')
    elif sFiledType in stdTypeInfo:
        return stdTypeInfo[sFiledType]
    else:
        print('不识别类型:' + sFiledType)
        return ' '


# 返回字典编号
def GetDictNo(sFiledName: str):
    OracleDB.GetDB()
    one, title = OracleDB.SelectDB(
        "select dict_id from standard_field_dept a where a.field_name='" +
        sFiledName + "' and belong_id = 'T20150180'")
    OracleDB.CloseDB()
    one = tools.FormatDBToList(one, title, isLower=True)
    if len(one) == 0:
        return '0'
    elif one[0]['dict_id'] == None:
        return '0'
    else:
        return one[0]['dict_id']


# 返回DTO对象
def returnDTO(sDTOName: str, svrName: str):
    OracleDB.GetDB()
    one, title = OracleDB.SelectDB(
        "select a.object_name,a.param_type from hep_object_tbl a where a.parent_name='"
        + sDTOName + "' and a.micro_service='" + svrName +
        "' order by a.param_sort")
    OracleDB.CloseDB()
    one = tools.FormatDBToList(one, title, isLower=True)
    yzItem = {}
    for item in one:
        sFieldName = item['object_name']
        sFiledType = getCType(item['param_type'])
        sDictEntry = GetDictNo(sFieldName)
        sFiledValue = ''
        if sDictEntry != '0':
            sFiledValue = returnRandomDict(sDictEntry)
        elif sFiledType != ' ':
            sFiledValue = getFiledValue(sFieldName, sFiledType, 0)
        yzItem[sFieldName] = sFiledValue
    return yzItem


# 返回随机日期
def returnData():
    a1 = (1976, 1, 1, 0, 0, 0, 0, 0, 0)  #设置开始日期时间元组
    a2 = (2021, 5, 19, 23, 59, 59, 0, 0, 0)  #设置结束日期时间元组
    start = time.mktime(a1)  #生成开始时间戳
    end = time.mktime(a2)  #生成结束时间戳

    t = random.randint(start, end)  #在开始和结束时间戳中随机取出一个
    date_touple = time.localtime(t)  #将时间戳生成时间元组
    date = time.strftime("%Y%m%d", date_touple)  #将时间元组转成格式化字符串
    return date


# 返回随机时间
def returnTime():
    a1 = (1976, 1, 1, 0, 0, 0, 0, 0, 0)  #设置开始日期时间元组
    a2 = (2021, 5, 19, 23, 59, 59, 0, 0, 0)  #设置结束日期时间元组
    start = time.mktime(a1)  #生成开始时间戳
    end = time.mktime(a2)  #生成结束时间戳

    t = random.randint(start, end)  #在开始和结束时间戳中随机取出一个
    date_touple = time.localtime(t)  #将时间戳生成时间元组
    sTime = time.strftime("%H%M%S", date_touple)  #将时间元组转成格式化字符串
    return sTime


# 返回随机字符串
def returnStr(num1=1, num2=1):
    if num1 >= num2:
        num = num1
    else:
        num = random.randint(num1, num2)
    letters = ''
    while num > 0:
        s = string.ascii_uppercase
        letter = random.choice(s)
        num -= 1
        letters = letters + letter
    return letters


# 返回座机
def returnHomeTel():
    list = cityCodeList
    str = '0123456789'
    return random.choice(list) + '-8' + "".join(
        random.choice(str) for i in range(7))


# 根据规则返回值
def getRuleValue(sRuleName: str, sFiledType: str, iRownum: int):
    if sRuleName == 'id_term':
        if random.randint(0, 1) == 0:
            dBeginDate = fake2.past_date(start_date="-5y", tzinfo=None)
            sBeginDate = str(dBeginDate).replace('-', '')
            sEndDate = str(dBeginDate + relativedelta(years=+5)).replace(
                '-', '')
        else:
            dBeginDate = fake2.past_date(start_date="-10y", tzinfo=None)
            sBeginDate = str(dBeginDate).replace('-', '')
            sEndDate = str(dBeginDate + relativedelta(years=+10)).replace(
                '-', '')
        return [int(sBeginDate), int(sEndDate)]
    else:  #没有匹配规则的用标准字段那套去兜底
        sFiledInfo = getFiledInfo.getUF30FiledInfo(sRuleName)
        if sFiledInfo != None:
            if sFiledInfo['dictNo'] > 0:
                return returnRandomDict(str(sFiledInfo['dictNo']))
            else:
                sFiledType = getCType(sFiledInfo['hsType'])
                return getFiledValue(sRuleName, sFiledType, 1)
        else:
            return getFiledValue(sRuleName, sFiledType, iRownum)


# 返回字段值
def getFiledValue(sFiledName: str, sFiledType: str, iRownum: int):
    if sFiledName in ['param_data']:
        sFiledType = 'C800'
    if sFiledName in ['qq', 'wechat_id', 'skype_id']:
        sFiledType = 'N8'
    if sFiledName in ['client_id']:
        sFiledType = 'N7'
    if sFiledName in ['register_fund', 'product_net_value']:
        sFiledType = 'N6'

    if sFiledName == 'nationality':
        return 'CHN'
    elif sFiledName == 'current_page':
        return 1
    elif sFiledName == 'update_date':
        return returnData()
    elif sFiledName == 'update_time':
        return returnTime()
    elif sFiledName == 'agency_no':
        return str(random.randint(1, 99))
    elif sFiledName == 'total':
        return random.randint(1, 10)
    elif sFiledName == 'company_no':
        return 0
    elif sFiledName == 'enable':
        iSecect = random.randint(0, 1)
        if iSecect == 0:
            return 'true'
        else:
            return 'false'
    elif sFiledName in [
            'prodtrustee_id_kind', 'acct_realoper_id_kind', 'contact_id_kind',
            'relation_id_kind', 'control_id_kind', 'instrepr_id_kind',
            'investadv_id_kind', 'duty_id_kind', 'investadv_rep_id_kind'
    ]:
        return '0'
    elif sFiledName in [
            'prodtrustee_id_no', 'acct_realoper_id_no', 'contact_id_no',
            'relation_id_no', 'control_id_no', 'instrepr_id_no', 'duty_id_no',
            'investadv_id_no', 'investadv_rep_id_no'
    ]:
        return buildID.creatID()
    elif sFiledName == 'business_licence':
        return IDCheckOrBuild.BuildBusinessCode15()
    elif sFiledName == 'share_reg_organ_code':
        return IDCheckOrBuild.BuildSocialCredit()
    elif sFiledName == 'home_page':
        return fake2.url(schemes=None)
    elif sFiledName == 'organ_code':
        return IDCheckOrBuild.CreateOrganization()
    elif sFiledName == 'nativeplace':
        return fake2.city_name()
    elif sFiledName in ['auxi_card_issuer', 'issued_depart']:
        return fake2.province() + '公安局'
    elif sFiledName == 'zipcode':
        return fake2.postcode()
    elif sFiledName == 'company_name':
        return fake2.company()
    elif sFiledName == 'operator_no':
        return str(random.randint(1, 100))
    elif sFiledName == 'op_station':
        return macAddress + ' IPv4=' + tools.GetIp() + ' HD=' + HD
    elif sFiledName == 'market_place':
        return random.choice(['上交所', '深交所', '港交所', '北交所'])
    elif sFiledName == 'open_date':
        return datetime.datetime.strftime(datetime.datetime.now(), '%Y%m%d')
    elif sFiledName in [
            'established_date', 'register_date', 'birthday',
            'product_nav_date', 'business_audit_date', 'organ_audit_date',
            'init_date'
    ]:
        return str(fake2.past_date(start_date="-5y",
                                   tzinfo=None)).replace('-', '')
    elif sFiledName == 'english_name':
        sResult = getFiledValue('full_name', sFiledType, iRownum)
        return tools.ChineseToEnglish(sResult)
    elif sFiledName == 'organ_english_name':
        sResult = getFiledValue('organ_name', sFiledType, iRownum)
        return tools.ChineseToEnglish(sResult)
    elif '_name' in sFiledName:
        sResult = creatName.random_name()
        if 'company_' in sFiledName or 'organ_' in sFiledName:
            sResult = sResult[0] + '有限公司'
        elif 'agency_' in sFiledName:
            sResult = sResult[0] + '基金公司'
        if type(sResult) == tuple:
            sResult = sResult[0]
        return sResult
    elif sFiledName == 'fax' or sFiledName == 'home_tel' or sFiledName == 'office_tel':
        return returnHomeTel()
    elif sFiledName[-4:] == '_tel' or sFiledName[
            -7:] == '_mobile' or sFiledName[
                -6:] == '_phone' or sFiledName == 'phonecode':
        return fake2.phone_number()
    elif sFiledName[
            -6:] == '_email' or sFiledName == 'e_mail' or sFiledName == 'email':
        return fake2.free_email()
    elif sFiledName[-10:] == '_begindate' or sFiledName[-11:] == '_begin_date':
        return str(fake2.past_date(start_date="-5y",
                                   tzinfo=None)).replace('-', '')
    elif sFiledName[-8:] == '_enddate' or sFiledName[-9:] == '_end_date':
        return str(fake2.future_date(end_date="+5y",
                                     tzinfo=None)).replace('-', '')
    elif sFiledName[-8:] == '_address' or sFiledName in [
            'address', 'officeaddress', 'homeplace'
    ]:
        return fake2.address()
    else:
        # 数字类型
        if sFiledType[:1] == 'N':
            iFiledLen = float(sFiledType[1:])
            if iFiledLen > 1:
                s = '9'
                iEnd = int(s.zfill(10).replace('0', '9'))
                return random.randint(1, iEnd)
            else:
                return random.randint(1, 100) / 100
        # 字符串类型
        elif sFiledType[:1] == 'C':
            iFiledLen = int(sFiledType[1:])
            if sFiledName in ['name', 'desp', 'value']:
                return '自助系统测试' + returnStr(iFiledLen)
            else:
                return returnStr(iFiledLen)


fake2 = Faker("zh_CN")
c = wmi.WMI()

# # 硬盘序列号
HD = str(c.Win32_DiskDrive()[0].SerialNumber).strip().replace('WD-', '')

# mac地址
for mac in c.Win32_NetworkAdapter():
    if mac.MACAddress != None:
        break
macAddress = str(mac.MACAddress).replace(':', '')

cityCodeList = tools.LoadDict('cityCodeList')
stdTypeInfo = tools.LoadDict('stdTypeInfo')

if __name__ == "__main__":
    print(getCType('HsAbstract'))
