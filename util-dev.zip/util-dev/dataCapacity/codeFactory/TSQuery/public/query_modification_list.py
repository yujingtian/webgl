from sys import stdout
from typing import SupportsRound
import requests
import re
import time
import json
import os
import random
import logging
import datetime
import xlwt
import ast

class queryModificationList():
    def __init__(self):
        self._logger = logging.getLogger('test')
        self._logger.setLevel(level=logging.DEBUG)

        formatter = logging.Formatter(
            '%(asctime)s - %(filename)s[line:%(lineno)d] - %(levelname)s: %(message)s')

        stream_handler = logging.StreamHandler()
        stream_handler.setLevel(logging.DEBUG)
        stream_handler.setFormatter(formatter)

        self._logger.addHandler(stream_handler)

        self._username = ""
        self._password = ""
        self._session = requests.session()
        self._cookies = {}
        self._sessionID = ""
        self._token = ''
        self._currentgroup = ''
        self._islogin = False
        # 增加一个需要等待登录的标志
        self._needwait = False
        self._header = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.63 Safari/537.36',
            'Accept': '*/*',
            'Connection': 'keep-alive',
            'Referer': 'https://hs-cas.hundsun.com/cas/login?service=https%3A%2F%2Fts.hundsun.com%2Fse%2Fj_spring_cas_security_check'
        }

    # 设置TS的域账号和密码
    @property
    def username(self):
        return self._username

    @username.setter
    def username(self, user_name):
        if isinstance(user_name, str) and len(user_name) > 0:
            self._username = user_name
        else:
            raise ValueError('账号格式不正确')

    @property
    def password(self):
        return self._password

    @password.setter
    def password(self, passwd):
        if isinstance(passwd, str) and len(passwd) > 0:
            self._password = passwd
        else:
            raise ValueError('密码格式不正确')

    # 设置浏览器头部信息
    @property
    def url_header(self):
        return self._header

    @url_header.setter
    def url_header(self, header):
        self._header = header

    @property
    def cookies(self):
        return self._cookies

    @cookies.setter
    def cookies(self, cookies):
        if isinstance(cookies, str) and len(cookies) > 0:
            self._cookies = cookies
        else:
            raise ValueError('密码格式不正确')

    @property
    def islogin(self):
        return self._islogin

    @property
    def session(self):
        return self._session

    # 判断是否登录

    def _is_login(self):
        r = self._session.get(
            "https://ts.hundsun.com/se/portal/SupportPortal.htm")
        self._islogin = not re.match(
            r'^https://hs-cas.hundsun.com/cas/login', r.url)
        if self._islogin:
            print('login ok')
        else:
            print('have not login ')
        return self._islogin, r

    # 登录

    def login_in(self):
        _is_login, _res = self._is_login()
        if not _is_login:
            # 模拟登录
            # 获取登录链接
            try:
                _response = self._session.get(
                    "https://ts.hundsun.com/se", headers=self._header, verify=False)
                lt = re.findall('name="lt" value="(.*?)" />',
                                _response.text)[0]
                execution = re.findall(
                    'name="execution" value="(.*?)" />', _response.text)[0]
                _data = {"username":  self._username, "password": self._password, "lt": lt, "execution": execution,
                         "_eventId": "submit", "submit": ""}

                # 2. 登陆
                _response = self._session.post(
                    _response.url, _data, headers=self._header)
                # 会话连接上之后获得cookies
                self._cookies = requests.utils.dict_from_cookiejar(
                    self._session.cookies)

                # print(_response.text)
                if _response.cookies.get_dict():
                    self._session.cookies.update(_response.cookies)
                _islogin_ok, _res = self._is_login()
                if _islogin_ok:
                    self._needwait = False
                    self._token = re.findall(
                        'se.SEConfig.token = "(.*?)";', _res.text)[0]
                    self._currentgroup = re.findall(
                        'se.SEConfig.currentGroup			= "(.*?)";', _res.text)[0]
                else:
                    _errors = re.findall(
                        '<div id="errors">(.*?)</div>', _res.text)
                    if len(_errors) > 0:
                        if _errors[0] == '您提供的凭证有误。':
                            raise Exception('您提供的凭证有误，账号密码错误！')
                        else:
                            raise Exception('登录TS出现错误！')
            except:
                self._islogin = False
                self._needwait = True
                self._logger.debug('需要再等等才让登录')


    def TS_getinfo(self, tsparam):

        # 访问隐私页面
        response = self._session.get(
            "https://ts.hundsun.com/se/portal/SupportPortal.htm", headers=self._header)
        
        try:
            token = re.findall(
                'se.SEConfig.token = "(.*?)";', response.text)[0]
            currentgroup = re.findall(
                'se.SEConfig.currentGroup			= "(.*?)";', response.text)[0]
            current_pennanter = re.findall(
                'se.SEConfig.pennanter.*?= "(.*?)";', response.text)[0]
            param_userId = re.findall('se.SEConfig.UserId			= "(.*?)";', response.text)[0]
            department = re.findall('se.SEConfig.Department		= "(.*?)";', response.text)[0]
            buId = re.findall('se.SEConfig.BuId		= "(.*?)";', response.text)[0]
            orgId = re.findall('se.SEConfig.OrgId		= "(.*?)";', response.text)[0]

            data = {
              "groupId": currentgroup,
	            "currentGroup": currentgroup,
	            "token": token,
	            "arhinoceros": 1,
	            "pennanter": current_pennanter
            }

            response = self.session.post("https://ts.hundsun.com/se/userGroup/UserGroupAction.htm",
            data,headers=self._header)

            aaa = {'modifyNum': '修改单编号', 'taskNum': '任务编号', 'reqNums': '需求编号', 'patchNum': '补丁申请单编号', 'bugNum': '缺陷编号', 'modifyStatus': '修改单状态', 'completedStatus': '任务完成状态', 'versionNO': '修改的版本', 'productId': '产品名称', 'customername': '需求提出方', 'promiseDate': '承诺日期', 'modifyType': '来源', 'workAccount': '总工作量(h)', 'commitDate': '开发完成日期', 'lastCommitDate': '末次开发完成日期', 'firstModifyDate': '首次要求开发完成日期', 'modifyDate': '要求开发完成日期', 'delay_reason': '延期主要原因', 'onlineTest': '需要联测', 'lineTestDesc': '联测内容', 'unitTest': '单元测试', 'modifyFile': '修改的文件', 'document': '开关/菜单配置', 'returnCount': '打回次数', 'tableModify': '表结构变更', 'moduleNames': '模块', 'receiver': '接收人', 'compatibleDesc': '兼容性说明', 'publishDesc': '发放说明', 'outProgram': '输出程序', 'modifyReason': '修改原因', 'modifyDesc': '修改说明', 'auditor': '代码审核人', 'auditingDate': '代码审核日期', 'lastAuditingDate': '末次代码审核日期', 'auditingAccount': '代码审核工作量(h)', 'auditingDesc': '审核说明', 'auditingBackDesc': '审核退回说明', 'auditingResult': '审核结果', 'testAssigner': '测试分配人', 'tester': '测试执行人', 'testResult': '测试结果', 'testCallBackReason': '测试打回原因', 'testDate': '测试完成日期', 'testAmount': '测试工作量(h)', 'testAccomplishDate': '要求测试完成日期', 'testType': '测试类型', 'testReason': '现场测试原因', 'testStyle': '测试方式', 'testProblem': '发现的缺陷编号', 'testContent': '测试内容', 'testMemo': '测试发现问题及备注', 'memo': '备注', 'testSuggestion': '测试建议', 'integationMan': '集成人', 'integationDesc': '集成说明', 'integationDate': '集成日期', 'lastIntegationDate': '末次集成日期', 'createDate': '创建日期', 'extTxt5': '退回说明', 'integationCount': '集成通过次数', 'integationCallbackCount': '集成退回次数', 'integationCallBackReason': '集成退回原因', 'testPackageName': '测试包版本号', 'selfTestDesc': '自测说明', 'verifier': '验证人', 'verifyDate': '验证时间', 'verifyDesc': '验证说明', 'verifyResult': '验证结果', 'publishVerName': '发布版本', 'isProgramArchive': '是否归档', 'archDate': '归档日期', 'extTxt7': '发布状态', 'modifier': '修改人', 'modifierGroup': '修改人所属团队', 'director': '责任人', 'extTxt6': '代码审核', 'publicPortion': '公共部分', 'unitTestDate': '单元测试完成日期', 'unitTestDesc': '单元测试环境说明', 'unitTestPoint': '单元测试要点', 'unitTestType': '单元测试类型', 'modifySummary': '修改补充说明', 'modifyDifficulty': '修改难度', 'severityLevel': '严重等级', 'findDifficulty': '发现难度', 'modifyPriority': '修改单优先级', 'cancelDate': '作废日期', 'integrationDesc': '集成注意', 'taskType': '需求类型', 'verifyAmount': '验证工作量(h)', 'verifyBackTimes': '验证打回次数', 'verifyCallBackReason': '验证打回原因', 'auditBackReason': '审核退回原因', 'testModifyType': '前后台修改', 'appreciationIs': '增值模块', 'stopSubmitDate': '封版日期', 'expectedReleaseDate': '版本预计发布日期', 'phase': '服务阶段', 'fieldDevelopment': '项目部开发', 'isSmokeTesting': '冒烟测试', 'compilationPassed': '编译通过', 'displayFields': '附件', 'testWarn': '测试未完成'}

            outParam = ["displayFields","modifyDate","modifyNum","modifyStatus","versionNO","receiver","modifier","productId","promiseDate","workAccount","modifyFile","firstModifyDate","commitDate","lastCommitDate","delay_reason","testAccomplishDate","onlineTest","lineTestDesc","completedStatus","testType","testReason","unitTest","document","returnCount","tableModify","moduleNames","compatibleDesc","publishDesc","outProgram","modifyReason","modifyDesc","modifySummary","memo","auditor","auditingDate","lastAuditingDate","auditingAccount","auditingDesc","auditingBackDesc","auditingResult","testAssigner","tester","testResult","testCallBackReason","testStyle","testDate","testAmount","testProblem","testContent","testMemo","testSuggestion","integationMan","integationDate","lastIntegationDate","createDate","integationDesc","extTxt5","integationCallbackCount","integationCallBackReason","testPackageName","selfTestDesc","publishVerName","isProgramArchive","archDate","extTxt7","extTxt6","publicPortion","verifier","verifyDate","verifyDesc","verifyResult","unitTestType","unitTestDate","unitTestDesc","unitTestPoint","modifyDifficulty","severityLevel","findDifficulty","modifyPriority","cancelDate","integrationDesc","taskType","verifyCallBackReason","verifyBackTimes","verifyAmount","testModifyType","auditBackReason","expectedReleaseDate","appreciationIs","stopSubmitDate","phase","integationCount","fieldDevelopment","reqNums","taskNum","patchNum","bugNum","customername","modifyType","isSmokeTesting","compilationPassed","director","testWarn"]

            data = {
                "queryId": 20210723172139005711009025191644,
	            "queryType": 5,
	            "currentGroup": currentgroup,
	            "token": token,
	            "arhinoceros": 1,
	            "pennanter": current_pennanter
            }

            self.session.post("https://ts.hundsun.com/se/reqmSupport/conditions4DB.htm",data,headers=self._header)

            data = {
                "param": tsparam,
	            "start": 0,
	            "limit": 1,
	            "isUserDataValidity": "Y",
	            "page": 1,
	            "currentGroup": currentgroup,
	            "token": token,
	            "arhinoceros": 1,
	            "pennanter": current_pennanter
            }

            response = self.session.post("https://ts.hundsun.com/se/services/modify/fetchModifyByUserdefinedModluePaginatedLucene.htm?_dc="+str(round(time.time()*1000)),data,headers=self._header)

            TS_dict = json.loads(response.text)

            recordsCount = TS_dict["recordsCount"]

            data = {
                "param": tsparam,
	            "start": 0,
	            "limit": recordsCount,
	            "isUserDataValidity": "Y",
	            "page": 1,
	            "currentGroup": currentgroup,
	            "token": token,
	            "arhinoceros": 1,
	            "pennanter": current_pennanter
            }

            response = self.session.post("https://ts.hundsun.com/se/services/modify/fetchModifyByUserdefinedModluePaginatedLucene.htm?_dc="+str(round(time.time()*1000)),data,headers=self._header)

            workbook = xlwt.Workbook(encoding = 'ascii')
            worksheet = workbook.add_sheet('sheet1')
            style = xlwt.XFStyle() # 初始化样式
            font = xlwt.Font() # 为样式创建字体
            font.name = 'Times New Roman' 
            style.font = font # 设定样式

            TS_dict = json.loads(response.text)
            resultBOListDict = TS_dict['resultBOList']

            for index in range(len(outParam)):
                if outParam[index] in aaa:
                    worksheet.write(0,index, aaa[(outParam[index])])

            for indexA in range(len(resultBOListDict)):
                for indexB in range(len(outParam)):
                    outP = resultBOListDict[indexA]
                    if outParam[indexB] in outP:
                        worksheet.write(indexA+1,indexB,outP[outParam[indexB]])
            
            workbook.save('Excel_test.xls')
            print("生成excle文件成功！！！！！")

            return response.text
        except:
            self._logger.error(response.text)
            return response.text

if __name__ == "__main__":
    # 读取配置表信息
    ts = queryModificationList()
    header = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36',
        'Accept': '*/*',
        'Connection': 'keep-alive'
    }

    ts.URLheader = header
    ts.reportlet = 'req/smd/product/reqNumInfoForProduct.cpt'
    ts.username = 'xuke41647'
    ts.password = 'xuke201010,.'
    ts.login_in()

    if ts.islogin:
        tsparam = {"productId":"20190601","modifyNum":"","bugNum":"","reqNum":"","taskNum":"","patchNum":"","modifyStatus":"2,3,4,5,6,7,8,9,10,11,12,1","relationModifyNum":"","relationType":"","completedStatus":"","taskType":"","phase":"","isProgramArchive":"","extTxt7":"","createDate":"","createDate2":"","createDateCondition1":"","createDateCondition2":"","modifyType":"","customername":"","onlineTest":"","screenCollator":"2","publicPortion":"","modifyDifficulty":"","modifyPriority":"","receiver":"","testAssigner":"","tester":"","integationMan":"","auditor":"","modifier":"","verifier":"","testType":"","testSuggestion":"","testResult":"","testModifyType":"","integationCallBackReason":"","testCallBackReason":"","testStyle":"","auditingResult":"","auditBackReason":"","verifyResult":"","verifyDate":"","verifyDate2":"","verifyDateCondition1":"","verifyDateCondition2":"","verifyBackTimes":"","verifyBackTimes2":"","promiseDate":"","promiseDate2":"","promiseDateCondition1":"","promiseDateCondition2":"","integationDate":"","integationDate2":"","integationDateCondition1":"","integationDateCondition2":"","modifyDate":"","modifyDate2":"","modifyDateCondition1":"","modifyDateCondition2":"","testAccomplishDate":"","testAccomplishDate2":"","accomplishDateCondition1":"","accomplishDateCondition2":"","commitDate":"","commitDate2":"","commitDateCondition1":"","commitDateCondition2":"","lastCommitDate":"","lastCommitDate2":"","lastCommitDateCondition1":"","lastCommitDateCondition2":"","testDate":"","testDate2":"","testDateCondition1":"","testDateCondition2":"","archDate1":"","archDate2":"","archDateCondition1":"","archDateCondition2":"","versionNo":"UF3.0V202101.07.000","productVersionType":"","productVersionSource":"","allowResult":"","extTxt8":"","moduleName":"","packageName":"","returnCount":"","returnCount2":"","modifyFile":"","modifyReason":"","modifyDesc":"","modifySummary":"\u4f9d\u8d56%M2","memo":"","outProgram":"","integationDesc":"","stopSubmitDate1":"","stopSubmitDate2":"","stopSubmitDateCondition1":"","stopSubmitDateCondition2":"","expectedReleaseDate1":"","expectedReleaseDate2":"","expectedReleaseDateCondition1":"","expectedReleaseDateCondition2":"","lastIntegationDate":"","lastIntegationDate2":"","lastIntegationDateCondition1":"","lastIntegationDateCondition2":"","lastUpdateDttm1":"","lastUpdateDttm2":"","lastUpdateDttmCondition1":"","lastUpdateDttmCondition2":"","isSmokeTesting":"","compilationPassed":"","director":"","hiddenDirector":""}
	
        tsparam = json.dumps(tsparam)

        TSinfo = ts.TS_getinfo(tsparam)

        TS_dict = json.loads(TSinfo)

        # print(TS_dict)

