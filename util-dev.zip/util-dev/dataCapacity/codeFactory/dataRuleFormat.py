# 本文件用来处理一个json包中的键值勾稽
import buildID
import random
import IDCheckOrBuild
import tools
from pypinyin import lazy_pinyin


def ruleCityTel(sTelName: str, dataMap: dict):
    if 'address' in dataMap and sTelName in dataMap:
        sAddress = dataMap['address']
        if '省' in sAddress and '市' in sAddress:
            sCityName = sAddress[sAddress.find('省') + len('省'):]
            sCityName = sCityName[:sCityName.find('市') + len('市')]
            if sCityName in cityInfoMap:
                return cityInfoMap[sCityName]['city_code'] + dataMap[sTelName][
                    4:]
        elif '省' in sAddress and '县' in sAddress:
            sCityName = sAddress[sAddress.find('省') + len('省'):]
            sCityName = sCityName[:sCityName.find('县')]
            if sCityName in cityInfoMap:
                return cityInfoMap[sCityName]['city_code'] + dataMap[sTelName][
                    4:]
    elif sTelName in dataMap:
        return dataMap[sTelName]
    else:
        return ''


# 按恒生经纪规则处理结果数据
def FormatDataForHS(dataMap):
    if 'organ_flag' in dataMap and 'id_kind' in dataMap and 'id_no' in dataMap:
        sOrganFlag = dataMap['organ_flag']
        if sOrganFlag == '0' and dataMap['id_kind'] != '0':  #个人户证件类型用身份证
            dataMap['id_kind'] = '0'
            dataMap['id_no'] = buildID.creatID()
        elif sOrganFlag != '0' and dataMap['id_kind'] == '0':  #机构户不能用身份证
            dataMap['id_kind'] = random.choice(['2', 'P', 'm'])
            if dataMap['id_kind'] == '2':  #营业执照
                dataMap['id_no'] = IDCheckOrBuild.BuildBusinessCode15()
            elif dataMap['id_kind'] == 'P':  #组织机构代码
                dataMap['id_no'] = IDCheckOrBuild.CreateOrganization()
            elif dataMap['id_kind'] == 'm':  #统一社会信用代码
                dataMap['id_no'] = IDCheckOrBuild.BuildSocialCredit()
    elif 'id_kind' in dataMap and 'id_no' in dataMap:
        if dataMap['id_kind'] == '0':
            dataMap['id_no'] = buildID.creatID()
        elif dataMap['id_kind'] == '2':  #营业执照
            dataMap['id_no'] = IDCheckOrBuild.BuildBusinessCode15()
        elif dataMap['id_kind'] == 'P':  #组织机构代码
            dataMap['id_no'] = IDCheckOrBuild.CreateOrganization()
        elif dataMap['id_kind'] == 'm':  #统一社会信用代码
            dataMap['id_no'] = IDCheckOrBuild.BuildSocialCredit()

    if 'client_name' in dataMap and 'full_name' in dataMap:  #同时存在简称和全称时，两者的值得一致
        dataMap['client_name'] = dataMap['full_name']

    if 'holder_name' in dataMap and 'full_name' in dataMap:  #同时存在简称和全称时，两者的值得一致
        dataMap['holder_name'] = dataMap['full_name']

    if 'prodmana_name' in dataMap and 'prodmana_full_name' in dataMap:  #同时存在产品资产管理人简称和产品资产管理人全称时，两者的值得一致
        dataMap['prodmana_name'] = dataMap['prodmana_full_name']

    if 'prodtrustee_name' in dataMap and 'prodtrustee_full_name' in dataMap:  #同时存在产品资产托管人简称和产品资产托管人全称时，两者的值得一致
        dataMap['prodtrustee_name'] = dataMap['prodtrustee_full_name']

    if 'prod_name' in dataMap and 'prod_full_name' in dataMap:  #同时存在产品简称和产品全称时，两者的值得一致
        dataMap['prod_name'] = dataMap['prod_full_name']

    if 'id_kind' in dataMap and 'birthday' in dataMap and 'id_no' in dataMap:  #同时存在身份证和生日的，生日从身份证号中取
        sIdKind = dataMap['id_kind']
        if sIdKind == '0':
            dataMap['birthday'] = dataMap['id_no'][6:14]

    if 'confirm_date' in dataMap and 'open_date' in dataMap:  #同时存在回访日期和开户日期的，两者需保持一致
        dataMap['confirm_date'] = dataMap['open_date']

    if 'sign_date' in dataMap and 'open_date' in dataMap:  #同时存在签约日期和开户日期的，两者需保持一致
        dataMap['sign_date'] = dataMap['open_date']

    if 'exchange_type' in dataMap and 'stock_account' in dataMap:  #同时存在市场类别和股东账户的，股东账户要符合市场类别
        sExchangeType = dataMap['exchange_type']
        if sExchangeType == '1':
            dataMap['stock_account'] = 'A' + str(dataMap['stock_account'])
        else:
            dataMap['stock_account'] = '0' + str(dataMap['stock_account'])

    if 'exchange_type' in dataMap and 'asset_prop' in dataMap and 'szdc_use_flag' in dataMap:  #通过市场类别和资产数据重置深圳使用信息标志
        sExchangeType = dataMap['exchange_type']
        sAssetProp = dataMap['asset_prop']
        if sExchangeType in ['1', 'H'] and sAssetProp == '0':
            dataMap['szdc_use_flag'] = '1'
        else:
            dataMap['szdc_use_flag'] = '0'

    if 'qq' in dataMap and 'wechat_id' in dataMap:  #qq和微信同时存在时，两者账号需一致
        dataMap['wechat_id'] = dataMap['qq']

    if 'organ_code_begindate' in dataMap and 'organ_audit_date' in dataMap:  #组织机构年审日期和组织机构开始日期同时出现时，两个日期是同一天
        dataMap['organ_audit_date'] = dataMap['organ_code_begindate']

    if 'business_licence_begindate' in dataMap and 'business_audit_date' in dataMap:  #营业执照年审日期和营业执照开始日期同时出现时，两个日期是同一天
        dataMap['business_audit_date'] = dataMap['business_licence_begindate']

    if 'id_address' in dataMap and 'issued_depart' in dataMap:  #地址和颁发机构同时出现，两者需匹配
        sIdAddress = dataMap['id_address']
        if '省' in sIdAddress:
            dataMap['issued_depart'] = sIdAddress[:sIdAddress.find('省') +
                                                  1] + '公安局'

    if 'auxi_id_address' in dataMap and 'auxi_card_issuer' in dataMap:  #辅助证件地址和辅助证件颁发机构同时出现，两者需匹配
        sIdAddress = dataMap['auxi_id_address']
        if '省' in sIdAddress:
            dataMap['auxi_card_issuer'] = sIdAddress[:sIdAddress.find('省') +
                                                     1] + '公安局'

    if 'nativeplace' in dataMap and 'homeplace' in dataMap:  #籍贯和出生地同时存在，两者需要有关系
        sHomePlace = dataMap['homeplace']
        if '市' in sHomePlace:
            dataMap['nativeplace'] = sHomePlace[:sHomePlace.find('市')]
        elif '区' in sHomePlace:
            dataMap['nativeplace'] = sHomePlace[:sHomePlace.find('区')]
        elif '省' in sHomePlace:
            dataMap['nativeplace'] = sHomePlace[:sHomePlace.find('省')]

    if 'full_name' in dataMap and 'organ_english_name' in dataMap:  #全称和英文名同时存在，英文名根据全称的拼音转换
        zh_name = dataMap['full_name']
        name_list = lazy_pinyin(zh_name)
        ming_list = name_list
        en_name = ""
        for y in ming_list:
            en_name = en_name + y

        en_name = en_name.title().lstrip()
        dataMap['organ_english_name'] = en_name

    if 'zipcode' in dataMap and 'address' in dataMap:  #邮编和地址需匹配
        sAddress = dataMap['address']
        if '省' in sAddress and '市' in sAddress:
            sCityName = sAddress[sAddress.find('省') + len('省'):]
            sCityName = sCityName[:sCityName.find('市') + len('市')]
            if sCityName in cityInfoMap:
                dataMap['zipcode'] = cityInfoMap[sCityName]['zipcode']
        elif '省' in sAddress and '县' in sAddress:
            sCityName = sAddress[sAddress.find('省') + len('省'):]
            sCityName = sCityName[:sCityName.find('县')]
            if sCityName in cityInfoMap:
                dataMap['zipcode'] = cityInfoMap[sCityName]['zipcode']

    if 'full_name' in dataMap and 'english_name' in dataMap:
        dataMap['english_name'] = tools.ChineseToEnglish(dataMap['full_name'])
    if 'organ_name' in dataMap and 'organ_english_name' in dataMap and 'full_name' not in dataMap:
        dataMap['organ_english_name'] = tools.ChineseToEnglish(
            dataMap['organ_name'])

    for sRuleKeyName in ['fax', 'home_tel', 'office_tel']:  #座机前四位和地址需匹配
        sRuleCityTel = ruleCityTel(sRuleKeyName, dataMap)
        if sRuleCityTel != '':
            dataMap[sRuleKeyName] = sRuleCityTel

    return dataMap


cityInfoMap = tools.LoadDict('cityInfo')