from configparser import ConfigParser
import os


def GetConfig(section='', option='', fileName='config.ini'):

    # 用os模块来读取
    curpath = os.path.dirname(os.path.realpath(__file__))
    if 'mockServer' in curpath:
        curpath = curpath[:-1 * len('mockServer') - 1] + '/HSData'
    elif 'codeFactory' in curpath:
        curpath = curpath[:-1 * len('codeFactory') - 1] + '/HSData'
    conf = ConfigParser()
    conf.read(curpath + '/' + fileName)
    if section not in conf:
        sReturn = ''
    else:
        # 调用get方法，然后获取配置的数据
        if option in conf[section]:
            sReturn = conf.get(section, option)
        else:
            sReturn = ''
    return sReturn


def WriteConfig(section='', option='', optionValue='', fileName='config.ini'):
    # 用os模块来读取
    curpath = os.path.dirname(os.path.realpath(__file__))
    conf = ConfigParser()
    conf.read(curpath + '/' + fileName)
    if section not in conf.sections():
        conf.add_section(section)

    conf.set(section, option, optionValue)
    conf.write(open(curpath + '/' + fileName, "r+"))


def ReadOption(section=''):
    curpath = os.path.dirname(os.path.realpath(__file__))
    conf = ConfigParser()
    conf.read(curpath + '/config.ini')
    return conf[section]


def CleanSection(section='', fileName='config.ini'):
    curpath = os.path.dirname(os.path.realpath(__file__))
    with open(curpath + '/' + fileName, 'r', encoding='gbk') as rFile:
        sLines = rFile.read()
    isDel = False
    with open(curpath + '/' + fileName, 'w', encoding='gbk') as wFile:
        for sLine in sLines.splitlines():
            if '[' + section + ']' == sLine.strip():
                isDel = True
            elif isDel:
                if sLine[:1] == '[':
                    wFile.write(sLine + '\n')
                    isDel = False
            elif not isDel:
                wFile.write(sLine + '\n')


if __name__ == "__main__":
    # WriteConfig('config','sqlpath','12')
    print(GetConfig('userInfo', 'u'))
    CleanSection('20210518', 'timeOutLog.ini')
