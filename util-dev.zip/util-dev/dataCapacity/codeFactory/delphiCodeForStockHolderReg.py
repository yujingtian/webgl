# 本文件用来生成delphi版的统一账户业务流水代码
import readStdfield
import getConfig
import tools


# 返回rep的构建代码
def GetRepCode(sFiledInfoMap, sAbbName, repList):
    sVar = ''
    sReturnCode = ''
    iLoop = 199
    iVarLoop = 0
    for sFiledName in repList:
        sFiledCName = sFiledInfoMap[sFiledName]['name']
        sReturnCode = sReturnCode + '  //' + sFiledCName + '\n'
        iLoop = iLoop + 1
        sReturnCode = sReturnCode + '  lb' + str(
            iLoop) + ".Caption := '" + sFiledCName + "';\n  lb" + str(
                iLoop) + ".Visible := True;\n"
        if 'dict' in sFiledInfoMap[sFiledName]:
            iLoop = iLoop + 1
            iVarLoop = iVarLoop + 1
            if iVarLoop % 5 == 0:
                sVar = sVar + ',\n' + '  s' + sFiledName
            else:
                sVar = sVar + ',' + 's' + sFiledName
            sReturnCode = sReturnCode + "  s%(filedName)s := dataswap.GetRepFieldValue('%(filedName)s');\n" % {
                'filedName': sFiledName
            }
            sDictMap = sFiledInfoMap[sFiledName]['dict']
            sDictStr = ''
            for sDictItem in sDictMap:
                if sDictStr.strip() != '':
                    sDictStr = sDictStr + '\n'
                sDictStr = sDictStr + "  else if s%(filedName)s = '%(dictItem)s' then\n     lb%(iLoop)s.Caption:= '%(dictDesc)s'" % {
                    'filedName': sFiledName,
                    'dictItem': sDictItem,
                    'iLoop': str(iLoop),
                    'dictDesc': sDictMap[sDictItem]
                }
            if sDictStr != '':
                sReturnCode = sReturnCode + '  ' + sDictStr[
                    7:] + ';\n  lb' + str(iLoop) + '.Visible := True;\n'
        elif 'dictNo' in sFiledInfoMap[sFiledName]:
            iLoop = iLoop + 1
            sReturnCode = sReturnCode + '''\
  lb%(iLoop)s.Caption := InterCommObj.Dictionary.GetPrompt('%(filedName)s', dataswap.GetRepFieldValue('%(filedName)s'), False);
  lb%(iLoop)s.Visible := True;
''' % {
                'iLoop': str(iLoop),
                'filedName': sFiledName
            }
        else:
            iLoop = iLoop + 1
            sReturnCode = sReturnCode + '''\
  lb%(iLoop)s.Caption := dataswap.GetRepFieldValue('%(filedName)s');
  lb%(iLoop)s.Visible := True;
''' % {
                'iLoop': str(iLoop),
                'filedName': sFiledName
            }
    if sVar.strip() != '':
        sVar = 'var\n  ' + sVar[1:] + ': string;\n'

    sReturnText = '''\
procedure TfrmStockHolderRegQuery.Show%(AbbName)sRep(dataswap: TDataswapNew);
%(sVar)sbegin
%(returnCode)send;
''' % {
        'sVar': sVar,
        'AbbName': sAbbName,
        'returnCode': sReturnCode
    }
    return sReturnText


# 返回req的构建代码
def GetReqCode(sFiledInfoMap, sAbbName, reqList):
    sVar = ''
    sReturnCode = ''
    iLoop = 99
    iVarLoop = 0
    for sFiledName in reqList:
        sFiledCName = sFiledInfoMap[sFiledName]['name']
        sReturnCode = sReturnCode + '  //' + sFiledCName + '\n'
        iLoop = iLoop + 1
        sReturnCode = sReturnCode + '  lb' + str(
            iLoop) + ".Caption := '" + sFiledCName + "';\n  lb" + str(
                iLoop) + ".Visible := True;\n"
        if 'dict' in sFiledInfoMap[sFiledName]:
            iLoop = iLoop + 1
            iVarLoop = iVarLoop + 1
            if iVarLoop % 5 == 0:
                sVar = sVar + ',\n' + '  s' + sFiledName
            else:
                sVar = sVar + ',' + 's' + sFiledName
            sReturnCode = sReturnCode + "  s%(filedName)s := dataswap.GetFieldValue('%(filedName)s');\n" % {
                'filedName': sFiledName
            }
            sDictMap = sFiledInfoMap[sFiledName]['dict']
            sDictStr = ''
            for sDictItem in sDictMap:
                if sDictStr.strip() != '':
                    sDictStr = sDictStr + '\n'
                sDictStr = sDictStr + "  else if s%(filedName)s = '%(dictItem)s' then\n     lb%(iLoop)s.Caption:= '%(dictDesc)s'" % {
                    'filedName': sFiledName,
                    'dictItem': sDictItem,
                    'iLoop': str(iLoop),
                    'dictDesc': sDictMap[sDictItem]
                }
            if sDictStr != '':
                sReturnCode = sReturnCode + '  ' + sDictStr[
                    7:] + ';\n  lb' + str(iLoop) + '.Visible := True;\n'
        elif 'dictNo' in sFiledInfoMap[sFiledName]:
            iLoop = iLoop + 1
            sReturnCode = sReturnCode + '''\
  lb%(iLoop)s.Caption := InterCommObj.Dictionary.GetPrompt('%(filedName)s', dataswap.GetFieldValue('%(filedName)s'), False);
  lb%(iLoop)s.Visible := True;
''' % {
                'iLoop': str(iLoop),
                'filedName': sFiledName
            }
        else:
            iLoop = iLoop + 1
            sReturnCode = sReturnCode + '''\
  lb%(iLoop)s.Caption := dataswap.GetFieldValue('%(filedName)s');
  lb%(iLoop)s.Visible := True;
''' % {
                'iLoop': str(iLoop),
                'filedName': sFiledName
            }
    if sVar.strip() != '':
        sVar = 'var\n  ' + sVar[1:] + ': string;\n'

    sReturnText = '''\
procedure TfrmStockHolderRegQuery.Show%(AbbName)sReq(dataswap: TDataswapNew);
%(sVar)sbegin
%(returnCode)send;
''' % {
        'sVar': sVar,
        'AbbName': sAbbName,
        'returnCode': sReturnCode
    }
    return sReturnText


# 开始处理StockHolderRegQuery.pas
def CreateStockHolderRegQueryPas(sFiledInfoMap, sAbbName, IntefaceInfo,
                                 sZhCode, sOutPath, vIntefaceName):
    print('开始处理StockHolderRegQuery.pas')
    sCsdcEntrustType = IntefaceInfo['CsdcEntrustType']
    reqList = IntefaceInfo['hsStdFiledInfo']['req']
    repList = IntefaceInfo['hsStdFiledInfo']['rep']

    sSrcFilePath = sZhCode + 'Subsys_Acct/SecuAcct_New/StockHolderRegQuery.pas'
    sDestFilePath = sOutPath + 'StockHolderRegQuery.pas'

    sRepCode = GetRepCode(sFiledInfoMap, sAbbName, repList)
    sReqCode = GetReqCode(sFiledInfoMap, sAbbName, reqList)

    sShowReqCode = ''
    sShowRepCode = ''

    # 处理rep和req
    if ',' in sCsdcEntrustType:
        sShowReqCode = '''\
else if pos(',' + dataswap.CsdcEntrustType + ',','%s') > 0 then
    begin
      self.Show%sReq(dataswap);
    end
''' % (',' + sCsdcEntrustType + ',', sAbbName)
        sShowRepCode = '''\
else if pos(',' + dataswap.CsdcEntrustType + ',','%s') > 0 then
    begin
      self.Show%sRep(dataswap);
    end
''' % (',' + sCsdcEntrustType + ',', sAbbName)
    else:
        sShowReqCode = '''\
else if dataswap.CsdcEntrustType = '%s' then
    begin
      self.Show%sReq(dataswap);
    end''' % (sCsdcEntrustType, sAbbName)
        sShowRepCode = '''\
else if dataswap.CsdcEntrustType = '%s' then
    begin
      self.Show%sRep(dataswap);
    end''' % (sCsdcEntrustType, sAbbName)

    sText, sEncoding = tools.LoadSrcCode(sSrcFilePath)

    vDestText = ''
    for sLine in sText:
        if '  protected' in sLine:
            vDestText = vDestText + '''\
    //%(IntefaceName)s申报
    procedure Show%(AbbName)sReq(dataswap: TDataswapNew);
    //%(IntefaceName)s回报
    procedure Show%(AbbName)sRep(dataswap: TDataswapNew);

''' % {
                'IntefaceName': vIntefaceName,
                'AbbName': sAbbName
            }
        elif "lbPageInfoReport.Caption := '第' + IntToStr(dataswap.GetCurrentIndex()) + '条/共' + IntToStr(dataswap.GetRecordCount()) + '条' ;" in sLine:
            sTmpStr = vDestText[vDestText.rfind('    ;'):]
            vDestText = vDestText[:vDestText.rfind('    ;')]
            sTmpStr = sTmpStr.replace(';', sShowReqCode + '    ;')
            vDestText = vDestText + sTmpStr
        elif "lbPageInfoReturn.Caption := '第' + IntToStr(dataswap.GetRepCurrentIndex()) + '条/共' + IntToStr(dataswap.GetRepRecordCount()) + '条' ;" in sLine:
            sTmpStr = vDestText[vDestText.rfind('    ;'):]
            vDestText = vDestText[:vDestText.rfind('    ;')]
            sTmpStr = sTmpStr.replace(';', sShowRepCode + '    ;')
            vDestText = vDestText + sTmpStr
        elif 'end.' in sLine:
            vDestText = vDestText + sRepCode + '\n' + sReqCode + '\n'
        vDestText = vDestText + sLine + '\n'
    with open(sDestFilePath, 'w', encoding=sEncoding) as wFile:
        wFile.write(vDestText)


# 代码生成
def BuildCode(hsIntefaceMap, sOutPath):
    sPubResource = getConfig.GetConfig('UF20', 'pubResource',
                                       'codefactoryConfig.ini')
    sZhCode = getConfig.GetConfig('UF20', 'ZHCode', 'codefactoryConfig.ini')

    sHSStdfieldMap = readStdfield.ReadHSStdfield(sPubResource +
                                                 'stdfields.xml')
    for sIntefaceName in hsIntefaceMap:
        # 获取接口名简称
        vIntefaceName = sIntefaceName
        if '-' in vIntefaceName:
            vIntefaceName = vIntefaceName[vIntefaceName.find('-') + 1:]
            vIntefaceName = vIntefaceName.strip()
        sAbbName = tools.GetInteFaceAbbName(vIntefaceName)

        # 重新清洗接口用到的字段信息
        sFiledInfoMap = {}
        sFiledInfoList = hsIntefaceMap[sIntefaceName]['hsStdFiledInfo'][
            'filedInfoList']
        for sFiledName in sFiledInfoList:
            sFiledInfo = sFiledInfoList[sFiledName]
            sFiledCName = ''
            if 'name' not in sFiledInfo:
                sFiledCName = sHSStdfieldMap[sFiledName]['cname']
            else:
                sFiledCName = sFiledInfo['name']

            sDictNo = ''
            if 'dict' not in sFiledInfo:
                if sFiledName in sHSStdfieldMap:
                    sDictNo = sHSStdfieldMap[sFiledName]['dict']
                else:
                    sDictNo = ''

            yzItem = {'name': sFiledCName}
            if 'dict' in sFiledInfo:
                yzItem['dict'] = sFiledInfo['dict']
            if sDictNo.strip() != '':
                yzItem['dictNo'] = sDictNo

            sFiledInfoMap[sFiledName] = yzItem

        CreateStockHolderRegQueryPas(sFiledInfoMap, sAbbName,
                                     hsIntefaceMap[sIntefaceName], sZhCode,
                                     sOutPath, vIntefaceName)


if __name__ == "__main__":
    sOutPath = 'F:/hundsun/svn/util/testFile/'
    hsIntefaceMap = {
        '消息接口 - 跨市场转登记账户及托管单元对应关系维护': {
            'CsdcEntrustType': 'j',
            'zxywlb': 'j',
            'time_kind': 'X',
            'functionNo': '2340230',
            'LsFunction': {
                '152050': {
                    'csdc_busi_kind': '01',
                    'name': '转板账户对应关系申报',
                    'abbName': 'EXCHBOARDACCT_REPORT'
                },
                '152051': {
                    'csdc_busi_kind': '02',
                    'name': '转板账户对应关系修改',
                    'abbName': 'EXCHBOARDACCT_MOD'
                },
                '152052': {
                    'csdc_busi_kind': '03',
                    'name': '转板账户对应关系查询',
                    'abbName': 'EXCHBOARDACCT_QRY'
                },
                '152053': {
                    'csdc_busi_kind': '04',
                    'name': '转板配发账户交易限制查询',
                    'abbName': 'EBACCTTRADELIMIT_QRY'
                }
            },
            'module_id': '465',
            'stdFiled': {
                'ZBLB': 'csdc_eb_busin_type',  #转板类别
                'ZQDM': 'csdc_stock_code',  #转板证券代码
                'GCZQZH': 'csdc_stock_account_src',  #过出证券账户
                'GCTGDY': 'csdc_seat_no_out',  #过出托管单元
                'GRZQZH': 'csdc_stock_account_dest',  #过入证券账户
                'GRTGDY': 'csdc_seat_no_dest_deal',  #过入托管单元
                'BYZD4': 'csdc_reserve4',  #备用字段4
                'GRZHBS': 'csdc_acct_mark_dest',  #过入账户标识
                'ZBXMBS': 'csdc_acct_limit_buy_mark',  #转板配发账户限买标识
                'ZDGXBS': 'csdc_reg_seat_mark',  #指定/托管关系标识
                'GRSYBS': 'csdc_stk_usedinfo_src',  #过入使用信息标识
                'YWRQ': 'csdc_busi_date',  #业务日期
                'YWPZBS': 'csdc_scan_flag'  #业务凭证报送标识
            },
            'hsStdFiledInfo': {
                'filedInfoList': {
                    'csdc_report_no': {},
                    'csdc_busi_kind': {
                        'dict': {
                            '01': '对应关系申报',
                            '02': '对应关系修改',
                            '03': '对应关系查询',
                            '04': '配发账户交易限制查询'
                        }
                    },
                    'csdc_eb_busin_type': {
                        'name': '转板类别',
                        'dict': {
                            '01': '新三板市场转板至沪市',
                            '02': '新三板市场转板至深市'
                        }
                    },
                    'csdc_stock_code': {
                        'name': '转板证券代码',
                        'must': [{
                            'csdc_busi_kind': ['01', '02', '03']
                        }]
                    },
                    'csdc_stock_account_src': {
                        'name': '过出证券账户号码',
                        'must': [{
                            'csdc_busi_kind': ['01', '02', '03']
                        }]
                    },
                    'csdc_seat_no_out': {
                        'name': '过出托管单元',
                        'must': [{
                            'csdc_busi_kind': ['01', '02', '03']
                        }]
                    },
                    'csdc_stock_account_dest': {
                        'name':
                        '过入证券账户号码',
                        'must': [{
                            'csdc_busi_kind': ['01', '02'],
                            'csdc_eb_busin_type': ['01']
                        }, {
                            'csdc_busi_kind': ['01', '02'],
                            'csdc_eb_busin_type': ['02'],
                            'csdc_spec_acct_mark_src': {
                                'c[4]': '1'
                            }
                        }]
                    },
                    'csdc_seat_no_dest_deal': {
                        'name':
                        '过入托管单元',
                        'must': [{
                            'csdc_busi_kind': ['01', '02'],
                            'csdc_eb_busin_type': ['02']
                        }]
                    },
                    'csdc_openorgan_code': {},
                    'csdc_opennet_code': {},
                    'report_date': {
                        'name': '申请日期'
                    },
                    'csdc_reserve1': {
                        'name': '备用字段1'
                    },
                    'csdc_reserve2': {
                        'name': '备用字段2'
                    },
                    'csdc_reserve3': {
                        'name': '备用字段3'
                    },
                    'csdc_reserve4': {
                        'name': '备用字段4'
                    },
                    'csdc_acct_mark_dest': {
                        'name': '过入账户标识',
                        'dict': {
                            '01': '中国结算选择的存量账户',
                            '02': '投资者申报的账户',
                            '03': '中国结算配发的新开账户'
                        }
                    },
                    'csdc_acct_limit_buy_mark': {
                        'name': '转板配发账户限买标识',
                        'dict': {
                            '1': '过入证券账户因转板配发被设置了禁止买入的交易限制',
                            '0': '过入证券账户未因转板配发被设置禁止买入的交易限制'
                        }
                    },
                    'csdc_reg_seat_mark': {
                        'name': '指定/托管关系标识',
                        'dict': {
                            '00': '过入证券账户无指定交易',
                            '01': '过入证券账户存在指定交易，其指定交易申报机构与过出托管单元所属机构一致',
                            '02': '过入证券账户存在指定交易，其指定交易申报机构与过出托管单元所属机构不一致',
                            '11': '过入托管单元与过出托管单元属于同一机构',
                            '12': '过入托管单元与过出托管单元属于不同机构'
                        }
                    },
                    'csdc_stk_usedinfo_src': {
                        'name': '过入使用信息标识',
                        'dict': {
                            '01': '过入托管单元所属机构为过入账户申报了使用信息',
                            '02': '过入托管单元所属机构没有为过入账户申报使用信息'
                        }
                    },
                    'csdc_busi_date': {},
                    'csdc_scan_flag': {},
                    'result_code': {},
                    'deal_info': {},
                    'csdc_spec_acct_mark_src': {
                        'name': '特殊过出账户标识'
                    }
                },
                'req': [
                    'csdc_report_no', 'csdc_busi_kind', 'csdc_eb_busin_type',
                    'csdc_stock_code', 'csdc_stock_account_src',
                    'csdc_seat_no_out', 'csdc_stock_account_dest',
                    'csdc_seat_no_dest_deal', 'csdc_openorgan_code',
                    'csdc_opennet_code', 'report_date', 'csdc_reserve1',
                    'csdc_reserve2', 'csdc_reserve3', 'csdc_reserve4'
                ],
                'rep': [
                    'csdc_report_no', 'csdc_busi_kind', 'csdc_eb_busin_type',
                    'csdc_stock_code', 'csdc_stock_account_src',
                    'csdc_seat_no_out', 'csdc_stock_account_dest',
                    'csdc_seat_no_dest_deal', 'csdc_openorgan_code',
                    'csdc_opennet_code', 'report_date', 'csdc_reserve1',
                    'csdc_reserve2', 'csdc_reserve3', 'csdc_reserve4',
                    'csdc_acct_mark_dest', 'csdc_acct_limit_buy_mark',
                    'csdc_reg_seat_mark', 'csdc_stk_usedinfo_src',
                    'csdc_busi_date', 'csdc_scan_flag', 'result_code',
                    'deal_info'
                ]
            },
            'DBSpecialFiled': {}
        }
    }
    BuildCode(hsIntefaceMap, sOutPath)
