package hundsun.tools;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.util.CellRangeAddress;

import java.io.FileOutputStream;
import java.util.ArrayList;

public class BuildExcle {

    public void buildExcle(ArrayList faildFileName,ArrayList faildFileParam,String path){

        //创建工作薄对象
        HSSFWorkbook workbook=new HSSFWorkbook();
        //创建工作表对象
        HSSFSheet sheet = workbook.createSheet();

        int max = 0;
        //每一个faildFileName 独占一行，后跟 faildFileParam 中的值，依次写入
        for (int i = 0;i<faildFileName.size();i++){
            HSSFRow row = sheet.createRow(i+1);
            row.createCell(0).setCellValue(String.valueOf(faildFileName.get(i)));
            ArrayList faileParamArray = (ArrayList)faildFileParam.get(i);
            max = faileParamArray.size() > max ? faileParamArray.size():max;
            for (int j = 0;j < faileParamArray.size();j++){

                row.createCell(j+1).setCellValue((String) faileParamArray.get(j));
            }
        }
        HSSFRow row = sheet.createRow(0);
        row.createCell(0).setCellValue("文件名");
        row.createCell(1).setCellValue("参数名");
        CellRangeAddress region = new CellRangeAddress(0, 0, 1,max);
        sheet.addMergedRegion(region);

        workbook.setSheetName(0,"出参缺失");

        //文档输出
        FileOutputStream out = null;
        try {
            out = new FileOutputStream(path+"\\出参丢失.xls");
            workbook.write(out);
            out.close();
            System.out.println("excle写入完成。");
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

}
