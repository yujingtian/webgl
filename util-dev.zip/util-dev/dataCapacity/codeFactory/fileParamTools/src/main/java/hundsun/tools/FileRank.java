package hundsun.tools;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class FileRank {

    public Map buildFileRank(Map<String, String> fileNameMap){

        Map rankFileMap = new HashMap();

        for(Map.Entry<String, String> entry : fileNameMap.entrySet()) {

            Map fileContentMap = new HashMap();
            fileContentMap.put("returnResultSet", "");
            ArrayList<String> stdFieldQuoteArray = new ArrayList<>();
            fileContentMap.put("stdFieldQuoteArray", stdFieldQuoteArray);
            ArrayList<String> codeArray = new ArrayList<>();
            fileContentMap.put("codeArray", codeArray);

            XmlAnalysis xmlAnalysis = new XmlAnalysis();

            //xml文件读取
            fileContentMap = xmlAnalysis.xmlAnalysisRoot(entry.getValue(), fileContentMap, stdFieldQuoteArray, codeArray);

            String returnResultSet = (String) fileContentMap.get("returnResultSet");
            stdFieldQuoteArray = (ArrayList<String>) fileContentMap.get("stdFieldQuoteArray");
            codeArray = (ArrayList<String>) fileContentMap.get("codeArray");

            for (int i = 0; i < codeArray.size(); i++){

                if (rankFileMap.containsKey(codeArray.get(i))) {
                    ArrayList rankUpName = (ArrayList) rankFileMap.get(codeArray.get(i));
                    if (rankUpName.contains(entry.getKey())){
                        continue;
                    }
                    rankUpName.add(entry.getKey());
                    rankFileMap.put(codeArray.get(i), rankUpName);
                } else {
                    ArrayList rankUpName = new ArrayList();
                    rankUpName.add(entry.getKey());
                    rankFileMap.put(codeArray.get(i), rankUpName);
                }

            }
        }
        return rankFileMap;
    }

}
