package hundsun.tools;

import java.io.File;
import java.util.Map;

public class BuildFileName {

    public Map<String,String> buildFileMap(String path,Map<String,String> fileMapList){

        File file = new File(path);
        File[] fileArray = file.listFiles();

        Map<String,String> fileMap = fileMapList;

        for (int i = 0; i < fileArray.length; i++) {
            File fs = fileArray[i];
            if (fs.isDirectory()) {
                //排除不需要读取的文件目录
                if ((fs.getName().equals("公共资源")) ||(fs.getName().equals("脚本")) ||(fs.getName().equals("数据库")) ||(fs.getName().equals("通用数据"))||(fs.getName().equals("fileParamTools"))){
                    continue;
                }
                //排除业务逻辑下不需要读取但原子目录下需要读取的目录
                if( (fs.getName().equals("外部测试")) || (fs.getName().equals("外部接口(不用编译)")) &&(file.getName().equals("业务逻辑")) )
                    continue;
                buildFileMap(path+ "\\" +fs.getName(),fileMap);

            } else {

                //特定文件不需要读取
                if (fs.getName().equals("module.xml") || fs.getName().equals(".project")|| fs.getName().equals("出参丢失.xls")||(fs.getName().equals("fileParamTools-1.0-SNAPSHOT.jar")))
                    continue;

                //只获取文件名，去除后缀
                String fileName = fs.getName().replace(".afunction_design","");
                fileName = fileName.replace(".aservice_design","");
                fileName = fileName.replace(".service_design","");
                fileName = fileName.replace(".function_design","");
                fileName = fileName.replace(".procedure_design","");

                fileMap.put(fileName,path + "\\" +fs.getName());
            }
        }

        return fileMap;
    }

}
