package hundsun.tools;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class OutScreen {

    public Map outParamScreen(Map out){

        ArrayList outFile = (ArrayList) out.get("name");
        ArrayList outParamName = (ArrayList) out.get("param");

        ArrayList file = new ArrayList();
        ArrayList param = new ArrayList();

        for (int i=0;i<outFile.size();i++){

            String fileName = (String) outFile.get(i);
            char a = fileName.charAt(0);
            char b = fileName.charAt(1);

            if( a=='L' && b=='S'){

                file.add(outFile.get(i));
                param.add(outParamName.get(i));
            }
        }

        Map outMap = new HashMap();

        outMap.put("name",file);
        outMap.put("param",param);

        return outMap;


    }

}
