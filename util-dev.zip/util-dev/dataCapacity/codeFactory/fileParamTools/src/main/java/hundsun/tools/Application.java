package hundsun.tools;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Application {

    public static void main(String[] args) {

        //读取文件夹，并将文件夹中的所有函数与服务文件以   文件名=文件地址   的形式进行存储入filenameMap中
        FileChooser fileChooser = new FileChooser();
        String path = fileChooser.chooseFile();

        System.out.println(path);

        if (path.equals(null)){
            return;
        }
        path = path.substring(0,path.lastIndexOf("\\"));

        Map<String,String> fileNameMap = new HashMap<String,String>();
        BuildFileName buildFileName = new BuildFileName();
        fileNameMap = buildFileName.buildFileMap(path,fileNameMap);

        //遍历fileNameMap，获取每一个xml文件的 returnResultSet stdFieldQuote Code 的值，并进行判断
        //符合条件的将 文件名 存储入faildFileName  未返回的  出参 存储入faildFileParam
        FindFaildParam findFaildParamA = new FindFaildParam();
        Map outParam = findFaildParamA.fondFaildParam(fileNameMap);

        ArrayList faildFileName = (ArrayList) outParam.get("faildFileName");
        ArrayList faildFileParam = (ArrayList) outParam.get("faildFileParam");
        System.out.println(faildFileParam.size());

        // 获取文件的上下引用关系
        FileRank rank = new FileRank();
        Map rankFileMap = rank.buildFileRank(fileNameMap);

        //更具引用关系对结果进行调整
        OutParam outParamA = new OutParam();
        Map out = outParamA.outParamBuild(faildFileName,faildFileParam,rankFileMap,fileNameMap);

        // 对最终结果进行处理，去除非 LS 开头的文件
        OutScreen outScreen = new OutScreen();
        out = outScreen.outParamScreen(out);
        ArrayList outFile = (ArrayList) out.get("name");
        ArrayList outParamName = (ArrayList) out.get("param");

        // 将返回的    和   faildFileParam  存储进excle文件
        System.out.println("开始写入excle");
        System.out.println("文件总条数："+fileNameMap.size());
        System.out.println("返回参数不足文件条数："+outFile.size());
        BuildExcle buildExcleA = new BuildExcle();
        buildExcleA.buildExcle(outFile,outParamName,path);
    }

}
