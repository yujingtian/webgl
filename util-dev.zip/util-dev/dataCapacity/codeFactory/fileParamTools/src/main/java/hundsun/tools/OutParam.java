package hundsun.tools;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class OutParam {


    public Map outParamBuild(ArrayList faildFileName, ArrayList faildFileParam, Map rankFileMap,Map fileNameMap){

        ArrayList faildFileOutName = faildFileName;
        ArrayList faildFileOutParam = faildFileParam;

        for (int i=0;i<faildFileOutName.size();i++){

            String fileName = (String) faildFileName.get(i);
            ArrayList faileParamArray = (ArrayList) faildFileParam.get(i);


            ArrayList rankUpName = (ArrayList) rankFileMap.get(fileName);
            if (rankUpName == null){
                continue;
            }

            if (fileName.equals("LF_账户平台调用_证券理财账户开户")){
                System.out.println();
            }

            for (int j=0;j<rankUpName.size();j++){

                Map fileContentMap = new HashMap();
                fileContentMap.put("returnResultSet","");
                ArrayList<String> stdFieldQuoteArray = new ArrayList<>();
                fileContentMap.put("stdFieldQuoteArray",stdFieldQuoteArray);
                ArrayList<String> codeArray = new ArrayList<>();
                fileContentMap.put("codeArray",codeArray);

                XmlAnalysis xmlAnalysis = new XmlAnalysis();

                //xml文件读取
                fileContentMap = xmlAnalysis.xmlAnalysisRoot((String) fileNameMap.get(rankUpName.get(j)),fileContentMap,stdFieldQuoteArray,codeArray);

                String returnResultSet = (String) fileContentMap.get("returnResultSet");
                stdFieldQuoteArray = (ArrayList<String>) fileContentMap.get("stdFieldQuoteArray");
                codeArray = (ArrayList<String>) fileContentMap.get("codeArray");

                if (returnResultSet.equals("true")){
                    continue;
                }

                stdFieldQuoteArray.retainAll(faileParamArray);

                String a = (String) rankUpName.get(j);

                if (faildFileOutName.contains(rankUpName.get(j))){
                    int b = faildFileOutName.lastIndexOf(rankUpName.get(j));
                    ArrayList cc = (ArrayList) faildFileOutParam.get(b);

                    for (int k=0;k<stdFieldQuoteArray.size();k++){
                        if (cc.lastIndexOf(stdFieldQuoteArray.get(k)) < 0){
                            cc.add(stdFieldQuoteArray.get(k));
                        }
                    }

                    faildFileOutParam.remove(b);
                    faildFileOutParam.add(b,cc);
                    continue;
                }

                if (stdFieldQuoteArray.size() > 0){
                    faildFileOutName.add(rankUpName.get(j));
                    faildFileOutParam.add(stdFieldQuoteArray);
                }
            }
        }

        Map out = new HashMap();
        out.put("name",faildFileOutName);
        out.put("param",faildFileOutParam);

        return out;
    }

}
