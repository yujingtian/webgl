package hundsun.tools;

import javax.swing.*;
import javax.swing.filechooser.FileFilter;
import java.io.File;

public class FileChooser extends JFrame {

    //选择文件
    public String chooseFile(){
        JFileChooser jfc=new JFileChooser();//构造一个指向用户默认目录的JFileChooser对象
        jfc.setFileSelectionMode(JFileChooser.FILES_ONLY);//只读取文件
        jfc.setFileFilter(new FileFilter() {
            @Override
            public boolean accept(File f) {
                if (f.isDirectory())return true;
                return f.getName().endsWith(".project");  //设置为选择以.project为后缀的文件
            }
            @Override
            public String getDescription() {
                return ".project";
            }
        });
        jfc.showDialog(new JLabel(), "选择需要扫描文件夹下的 .project文件");//弹出一个文件选择框
        File file=jfc.getSelectedFile();//返回选中的文件
        if (file.equals(null)){
            return null;
        }
        String path = file.getPath();
        return path;
    }
}