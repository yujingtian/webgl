package hundsun.tools;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class FindFaildParam {

    public Map fondFaildParam(Map<String,String> fileNameMap){

        ArrayList faildFileName = new ArrayList();
        ArrayList faildFileParam = new ArrayList();

        //遍历文件，进行处理
        for(Map.Entry<String, String> entry : fileNameMap.entrySet()){

            Map fileContentMap = new HashMap();
            fileContentMap.put("returnResultSet","");
            ArrayList<String> stdFieldQuoteArray = new ArrayList<>();
            fileContentMap.put("stdFieldQuoteArray",stdFieldQuoteArray);
            ArrayList<String> codeArray = new ArrayList<>();
            fileContentMap.put("codeArray",codeArray);

            XmlAnalysis xmlAnalysis = new XmlAnalysis();

            //xml文件读取
            fileContentMap = xmlAnalysis.xmlAnalysisRoot(entry.getValue(),fileContentMap,stdFieldQuoteArray,codeArray);

            String returnResultSet = (String) fileContentMap.get("returnResultSet");
            stdFieldQuoteArray = (ArrayList<String>) fileContentMap.get("stdFieldQuoteArray");
            codeArray = (ArrayList<String>) fileContentMap.get("codeArray");

            if (stdFieldQuoteArray.size() == 0){
                System.out.println(entry.getKey());
                System.out.println("无返回值。");
                System.out.println("=======================================");
                continue;
            }

            if (returnResultSet.equals("true")){
                System.out.println(entry.getKey());
                System.out.println("返回值为假，不需要返回。");
                System.out.println("=======================================");
                continue;
            }

            if (entry.getValue().indexOf("不用编译") > 0){
                System.out.println(entry.getKey());
                System.out.println("不用编译，默认可以返回参数。");
                continue;

            }

            //保存所有code中文件所有可以返回的出参
            ArrayList<String> childStdFieldQuoteArrayOut = new ArrayList();

            // 保存单个code中文件所有可以返回的出参
            Map childFileContentMap = new HashMap();
            childFileContentMap.put("returnResultSet","");
            ArrayList<String> childStdFieldQuoteArray = new ArrayList<>();
            fileContentMap.put("stdFieldQuoteArray",childStdFieldQuoteArray);
            ArrayList<String> childCodeArray = new ArrayList<>();
            fileContentMap.put("codeArray",childCodeArray);

            for (int i = 0;i<codeArray.size();i++){

                if (fileNameMap.get(codeArray.get(i)) != null){
                    childFileContentMap = xmlAnalysis.xmlAnalysisRoot(fileNameMap.get(codeArray.get(i)),childFileContentMap,childStdFieldQuoteArray,childCodeArray);
                    if (childFileContentMap.get("returnResultSet").equals("false") && (ArrayList)childFileContentMap.get("stdFieldQuoteArray") != null){
                        childStdFieldQuoteArrayOut.addAll(childStdFieldQuoteArrayOut.size(),(ArrayList)childFileContentMap.get("stdFieldQuoteArray"));
                    }
                }
            }

            //保存最终没有返回的出参
            ArrayList<String> faileParamArray = new ArrayList();

            if (childStdFieldQuoteArrayOut.containsAll(stdFieldQuoteArray)){
                System.out.println(entry.getKey());
                System.out.println("返回参数齐全");
                System.out.println("=======================================");
            }else{

                faileParamArray = (ArrayList)stdFieldQuoteArray.clone();

                for (int i = 0;i<stdFieldQuoteArray.size();i++){

                    for (int j = 0;j<childStdFieldQuoteArrayOut.size();j++){

                        if (stdFieldQuoteArray.get(i).equals(childStdFieldQuoteArrayOut.get(j))){

                            faileParamArray.remove(stdFieldQuoteArray.get(i));
                        }
                    }
                }

                System.out.println(entry.getKey());
                System.out.println("返回参数不全");
                System.out.println("未返回参数" + faileParamArray);
                System.out.println("=======================================");

                // 同时存储，两者下标一致，可同步取出
                faildFileName.add(entry.getKey());
                faildFileParam.add(faileParamArray);
            }

        }

        // 所有结果的综合，输出
        Map outParam = new HashMap();
        outParam.put("faildFileName",faildFileName);
        outParam.put("faildFileParam",faildFileParam);

        return outParam;

    }

}
