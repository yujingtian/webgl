package hundsun.tools;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import java.io.*;
import java.util.*;


public class XmlAnalysis {

    public static String codeString(String fileName) throws Exception {
        BufferedInputStream bin = new BufferedInputStream(new FileInputStream(fileName));
        int p = (bin.read() << 8) + bin.read();
        bin.close();
        String code = null;

        switch (p) {
            case 0xefbb:
                code = "UTF-8";
                break;
            case 0xfffe:
                code = "Unicode";
                break;
            case 0xfeff:
                code = "UTF-16BE";
                break;
            default:
                code = "GBK";
        }

        return code;
    }

    public Map xmlAnalysisRoot(String path, Map fileContentMap, ArrayList stdFieldQuoteArray, ArrayList codeArray){

        //1.创建Reader对象
        SAXReader reader = new SAXReader();
        //2.加载xml
        Document document = null;
//        System.out.println(path);
        try {
//            document = reader.read(new File(path));
            File file = new File(path);
            String code = codeString(path);
            document = reader.read( new BufferedReader( new InputStreamReader( new FileInputStream(file), code )));
        } catch (Exception e) {
            e.printStackTrace();
        }
        //3.获取根节点
        Element rootElement = document.getRootElement();
        fileContentMap = childElement(rootElement,fileContentMap,stdFieldQuoteArray,codeArray);
        return fileContentMap;
    }

    public Map childElement(Element element,Map fileContentMap,ArrayList stdFieldQuoteArray,ArrayList codeArray){

        //获取同级标签
        Iterator iterator = element.elementIterator();

        while (iterator.hasNext()){

            Element element1 = (Element) iterator.next();

            if (element1.getName() == "basic" && element.getName() == "basic"){
                String returnResultSet = element1.attributeValue("returnResultSet");
                fileContentMap.put("returnResultSet",returnResultSet);
            }

            if (element1.getName() == "stdFieldQuote" && element.getName() == "export"){
                String stdFieldQuote = element1.attributeValue("name");
                stdFieldQuoteArray.add(stdFieldQuote);
                fileContentMap.put("stdFieldQuoteArray",stdFieldQuoteArray);
            }

            // 去除空行，空格，[ 后，判断前两个字符是否满足条件，满足条件 去除 ] 存储
            if (element1.getName() == "code"){
                String code = element1.getText().replaceAll(" ","");
                code = code.replaceAll("((\r\n)|\n)[\\s\t ]*(\\1)+", "$1").replaceAll("^((\r\n)|\n)", "");

                for (int i=0;i<code.length();){

                    int start = code.indexOf("//");
                    int end = code.indexOf("\n",start);
                    String replacecode = "";
                    if (start < 0){
                        break;
                    }
                    if (end < 0){
                        replacecode = code.substring(start,code.length());
                    }else {
                        replacecode = code.substring(start, end + 1);
                    }
                    code = code.replace(replacecode,"");
                    i = start;

                }

                List<String> codeList = Arrays.asList(code.split("\\["));
                for (int i = 0;i<codeList.size();i++){

                    if(codeList.get(i).length() < 2){
                        continue;
                    }
                    String codeListChild = codeList.get(i).replaceAll("((\r\n)|\n)[\\s\t ]*(\\1)+", "$1").replaceAll("^((\r\n)|\n)", "");
                    char charA = codeListChild.charAt(0);
                    char charB = codeListChild.charAt(1);
                    if ((charA == 'A'&& charB == 'S')||(charA == 'A'&&charB == 'P')||(charA == 'L'&&charB == 'F')||(charA == 'A'&&charB == 'F')||(charA == 'L'&&charB == 'S')){
                        String code1 = Arrays.asList(codeListChild.split("\\]")).get(0);
                        codeArray.add(code1);
                        fileContentMap.put("codeArray",codeArray);
                    }

                }
            }
            //获取下一级标签
            childElement(element1,fileContentMap,stdFieldQuoteArray,codeArray);
        }

        return fileContentMap;

    }

}
