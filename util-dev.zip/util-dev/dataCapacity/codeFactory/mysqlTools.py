import pymysql


##获取数据库连接
def GetDB(sUser: str, sPwd: str, sIP: str, sPort: int, sSerName: str):
    global db
    db = pymysql.connect(user=sUser,
                         password=sPwd,
                         host=sIP,
                         port=sPort,
                         db=sSerName)
    global cursor
    cursor = db.cursor()


##关闭数据库连接
def CloseDB():
    db.close()


##查询sql语句
def SelectDB(vSqlStr):
    cursor.execute(vSqlStr)
    one = cursor.fetchall()
    title = cursor.description
    sResultList = []
    for item in one:
        yzItem = {}
        for iLoop in range(len(item)):
            if item[iLoop] is None:
                yzItem[title[iLoop][0]] = ''
            else:
                yzItem[title[iLoop][0]] = item[iLoop]
        sResultList.append(yzItem)

    return sResultList


if __name__ == "__main__":
    GetDB(sUser='uf3',
          sPwd='uf3uf3uf3',
          sIP='10.20.26.67',
          sPort=33061,
          sSerName='hs_efficiency')
    one = SelectDB(
        "select a.sub_entry,a.dict_prompt from hep_std_sub_dict_dept_tbl a where exists(select 1 from hep_std_dict_dept_tbl b where b.uuid = a.dict_uuid and b.belong_id = 'hsbroker' and b.dict_entry='41009') "
    )
    print(one)
    CloseDB()
