package com.hundsun.broker.replace.inner;

import com.hundsun.jrescloud.common.boot.CloudApplication;
import com.hundsun.jrescloud.common.boot.CloudBootstrap;
import com.hundsun.jrescloud.common.license.EnableLicenseCenter;
import com.hundsun.jrescloud.common.web.CloudServletInitializer;
import com.hundsun.jrescloud.db.core.configuration.EnableCloudDataSource;
import com.hundsun.jrescloud.rpc.def.licensesdk.validation.pattern.EnableLicensePattern;
import com.hundsun.jrescloud.rpc.def.licensesdk.validation.pattern.LicensePattern;

@CloudApplication(scanBasePackages = { "com.hundsun.broker.base.config", "com.hundsun.jrescloud.hslocalcache", "com.hundsun.jrescloud.rpc.def.licensesdk" })
@EnableLicenseCenter
@EnableLicensePattern(LicensePattern.GROUP)
public class Provider extends CloudServletInitializer {
    public static void main(String[] args) {
        CloudBootstrap.run(Provider.class, args);
    }
}
