package com.hundsun.broker.ses.pub.service.impl;

import com.hundsun.broker.ses.pub.service.InnerSesService;
import com.hundsun.jrescloud.rpc.annotation.CloudComponent;

import java.util.ArrayList;
import java.util.List;

@CloudComponent
public class InnerSesServiceImpl implements InnerSesService {
    @Override
    public List<GetFundaccountCancelCheckInnerOutput> getFundaccountCancelCheckInner(GetFundaccountCancelCheckInnerInput var1) {
        return new ArrayList<>();
    }

    @Override
    public List<GetStockholderCancelCheckInnerOutput> getStockholderCancelCheckInner(GetStockholderCancelCheckInnerInput var1) {
        return new ArrayList<>();
    }
}
