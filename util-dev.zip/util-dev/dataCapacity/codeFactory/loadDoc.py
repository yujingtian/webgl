# 本文件用来处理识别doc版接口
from docx import Document

sTitleKeyList = ['消息接口', '通信接口', '数据接口', '文件接口', '应答']


# 判断是否是接口标题
def isIntefaceTitle(sLines: str):
    for sTitleKey in sTitleKeyList:
        if sTitleKey in sLines:
            if sLines.find(sTitleKey) < 10:
                return True
    return False


# 读取doc中的接口信息
def LoadDoc(sFilePath: str):
    intefaceMap = {}
    resultJsonMap = {}
    document = Document(sFilePath)
    isInteface = False
    isGS = False
    sTitleList = []
    sServiceTypeMap = {}
    sServiceNameMap = {}
    sTitle = ''
    for paragraph in document.paragraphs:
        if '一、概述' == paragraph.text:
            isGS = True
        if '数据接口' in paragraph.text and isGS and paragraph.text.find(
                '数据接口') < 10:
            isInteface = True
            continue
        if isIntefaceTitle(paragraph.text) and isInteface:
            sLine = paragraph.text.replace('）', ')').replace('：', ':')
            sLastTitle = sTitle
            sTitle = sLine
            if ')' in sLine:
                sTitle = sLine[sLine.find(')') + 1:]
            if ':' in sTitle:
                sTitle = sTitle.replace(':', '')
            if sTitle == '应答':
                sTitle = sTitle + '-' + sLastTitle[sLastTitle.find('-') +
                                                   1:].strip()
            print(sTitle)
            sTitleList.append(sTitle)
        elif 'ServiceType ' in paragraph.text:
            sServiceType = paragraph.text
            sServiceType = sServiceType[sServiceType.find('“') + 1:]
            sServiceType = sServiceType[:sServiceType.find('”')]
            sServiceTypeMap[sTitle] = sServiceType.strip()
        elif 'ServiceName ' in paragraph.text:
            sServiceName = paragraph.text
            sServiceName = sServiceName[sServiceName.find('“') + 1:]
            sServiceName = sServiceName[:sServiceName.find('”')]
            sServiceNameMap[sTitle] = sServiceName.strip()

    tables = document.tables  # 获取文件中的表格集

    for iLoop in range(0, len(tables)):
        table = tables[iLoop]

        colMap = {}
        if table.cell(0, 1).text == '字段':  #说明是接口表格
            colMap['字段'] = 1
            colMap['类型'] = 2
            colMap['长度'] = 3
            colMap['字段名称'] = 4
            colMap['填写描述'] = 5

            sTableName = sTitleList[iLoop]
            filedInfoList = []

            for i in range(1, len(table.rows)):  # 从表格第一行开始循环读取表格数据
                sFiledName = table.cell(i, colMap['字段']).text
                sFiledType = table.cell(i, colMap['类型']).text
                sFiledLen = table.cell(i, colMap['长度']).text
                sFiledCName = table.cell(i, colMap['字段名称']).text
                sFiledDesc = table.cell(i, colMap['填写描述']).text

                yzItem = {}
                yzItem['filedName'] = sFiledName
                yzItem['filedType'] = sFiledType
                yzItem['filedLen'] = sFiledLen
                yzItem['filedCName'] = sFiledCName
                yzItem['filedDesc'] = sFiledDesc
                filedInfoList.append(yzItem)

            intefaceMap[sTableName] = {'filedInfo': filedInfoList}
            if sTableName in sServiceTypeMap:
                intefaceMap[sTableName]['ServiceType'] = sServiceTypeMap[
                    sTableName]
            if sTableName in sServiceNameMap:
                intefaceMap[sTableName]['ServiceName'] = sServiceNameMap[
                    sTableName]
        elif table.cell(0, 1).text == '结果代码':  #说明是结果代码
            sTableName = '结果代码'

            colMap['结果代码'] = 1
            colMap['结果说明'] = 2

            for i in range(1, len(table.rows)):  # 从表格第一行开始循环读取表格数据
                sResultCode = table.cell(i, colMap['结果代码']).text
                sResultDesc = table.cell(i, colMap['结果说明']).text

                resultJsonMap[sResultCode] = sResultDesc
    return intefaceMap, resultJsonMap


if __name__ == "__main__":
    sFilePath = 'F:/hundsun/svn/util/testFile/统一账户平台关于为转板上市证券跨市场转登记维护账户及托管单元对应关系的接口修订说明 （开发参考稿） - 20210525.docx'
    intefaceMap, resultJsonMap = LoadDoc(sFilePath)
    print(intefaceMap)