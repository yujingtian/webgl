import re
import random
from datetime import datetime

# 统一社会信用代码最后一位：代码字符集
check_dict = {
    "0": 0,
    "1": 1,
    "2": 2,
    "3": 3,
    "4": 4,
    "5": 5,
    "6": 6,
    "7": 7,
    "8": 8,
    "9": 9,
    "A": 10,
    "B": 11,
    "C": 12,
    "D": 13,
    "E": 14,
    "F": 15,
    "G": 16,
    "H": 17,
    "J": 18,
    "K": 19,
    "L": 20,
    "M": 21,
    "N": 22,
    "P": 23,
    "Q": 24,
    "R": 25,
    "T": 26,
    "U": 27,
    "W": 28,
    "X": 29,
    "Y": 30
}
dict_check = {value: key for key, value in check_dict.items()}


# 校验三大运营商和虚拟运营商的号码
def check_phone(phone):
    '''三大运营商和虚拟运营商的号码'''
    regex_phone = r'^1(3\d|4[579]|5[0-35-9]|66|7[0135-8]|8\d|9[89])\d{8}$'
    if re.search(regex_phone, phone, re.S):
        return True
    return False


# 校验15位营业执照
def check_yingye(yinye_str):
    '''营业执照号码，使用了校验位算法'''
    # 15位纯数字
    if re.search(r'^\d{15}$', yinye_str, re.S):
        verify_code = 10
        for index in range(14):
            verify_code_t = verify_code
            verify_code = ((
                (verify_code % 11 + int(yinye_str[index])) % 10 or 10) *
                           2) % 11
        verify_code = (11 - (verify_code % 10)) % 10
        return yinye_str if str(verify_code) == yinye_str[-1] else False
    return False


# 校验统一社会信用代码
def check_xinyong(xinyong_str):
    '''统一社会信用代码，使用了校验位算法'''
    xinyong_str = xinyong_str.upper()
    if len(xinyong_str) != 18:
        return False
    search = re.search(
        r'^(1[129]|5[1239]|9[123]|Y1)\d{6}[\dA-Z]{8}[X\d][\dA-Z]$',
        xinyong_str, re.S)
    if search:
        if check_zuzhi(xinyong_str[8:17]):
            str_to_num = {
                'A': 10,
                'B': 11,
                'C': 12,
                'D': 13,
                'E': 14,
                'F': 15,
                'G': 16,
                'H': 17,
                'J': 18,
                'K': 19,
                'L': 20,
                'M': 21,
                'N': 22,
                'P': 23,
                'Q': 24,
                'R': 25,
                'T': 26,
                'U': 27,
                'W': 28,
                'X': 29,
                'Y': 30
            }
            num_to_str = {
                10: 'A',
                11: 'B',
                12: 'C',
                13: 'D',
                14: 'E',
                15: 'F',
                16: 'G',
                17: 'H',
                18: 'J',
                19: 'K',
                20: 'L',
                21: 'M',
                22: 'N',
                23: 'P',
                24: 'Q',
                25: 'R',
                26: 'T',
                27: 'U',
                28: 'W',
                29: 'X',
                30: 'Y',
                31: '0'
            }
            verify_code = [
                1, 3, 9, 27, 19, 26, 16, 17, 20, 29, 25, 13, 8, 24, 10, 30, 28
            ]
            verify_code = 31 - sum(
                [(str_to_num.get(xinyong_str[index], 0) if xinyong_str[index].
                  isalpha() else int(xinyong_str[index])) * verify_code[index]
                 for index in range(17)]) % 31
            verify_code = num_to_str.get(
                verify_code, '') if verify_code > 9 else verify_code
            return xinyong_str if verify_code == xinyong_str[-1] else False
    return False


# 校验身份证号码
def check_ssn(ssn_str):
    '''身份证号码，使用了校验位算法'''
    ssn = ssn_str.upper()
    regex_ssn = r'^[1-9]\d{5}(18|19|[23]\d)\d{2}(0[1-9]|1[0-2])([0-2][1-9]|10|20|30|31)\d{3}[\dX]$|^[1-9]\d{5}\d{2}(0[1-9]|1[0-2])([0-2][1-9]|10|20|30|31)\d{3}$'
    if not re.search(regex_ssn, ssn, re.S):
        return False
    if len(ssn) != 18:
        return False
    try:
        birth_time = datetime(int(ssn[6:10]), int(ssn[10:12]), int(ssn[12:14]))
        if birth_time >= datetime.now():
            return False
    except:
        return False
    verify_code = [7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2]
    verify_index = sum(
        [int(ssn[index]) * verify_code[index] for index in range(17)]) % 11
    verify_code = ['1', '0', 'X', '9', '8', '7', '6', '5', '4', '3', '2']
    return ssn if verify_code[verify_index] == ssn[-1] else False


# 校验组织机构代码
def check_zuzhi(zuzhi_str):
    '''组织机构代码，使用了校验位算法'''
    zuzhi_str = zuzhi_str.upper().replace('-', '')
    search = re.search(r'^[\dA-Z]{8}[X\d]$', zuzhi_str, re.S)
    if search:
        verify_code = [3, 7, 9, 10, 5, 8, 4, 2]
        verify_code = 11 - sum([
            int((ord(zuzhi_str[index]) - 55) if zuzhi_str[index].isalpha(
            ) else zuzhi_str[index]) * verify_code[index] for index in range(8)
        ]) % 11
        verify_code = 'X' if verify_code == 10 else (
            '0' if verify_code == 11 else str(verify_code))
        return zuzhi_str if verify_code == zuzhi_str[-1] else False
    return False


# 校验中国税务登记号
def check_shuiwu(shuiwu_str):
    '''税务登记证号码，使用了校验位算法'''
    shuiwu_str = shuiwu_str.upper()
    if len(shuiwu_str) == 20:
        if check_ssn(shuiwu_str[:15]):
            if re.search(r'^[A-Z\d]{5}$', shuiwu_str[15:], re.S):
                return shuiwu_str
        if check_ssn(shuiwu_str[:18]):
            if re.search(r'^[A-Z\d]{2}$', shuiwu_str[18:], re.S):
                return shuiwu_str
        return False
    else:
        shuiwu_str = shuiwu_str.replace('-', '')
        search = re.search(r'^\d{6}[\dA-Z]{8}[X\d]$', shuiwu_str, re.S)
        return (shuiwu_str
                if check_zuzhi(shuiwu_str[6:]) else False) if search else False


# 校验非营利企业登记证号码
def check_feiyingli(feiyingli_str):
    '''非营利企业登记证号码'''
    feiyingli_str = feiyingli_str.upper().replace('-', '')
    if len(feiyingli_str) == 9:
        return check_zuzhi(feiyingli_str)
    elif len(feiyingli_str) == 18:
        return check_xinyong(feiyingli_str)
    return False


# 生成15位营业执照
def BuildBusinessCode15(sCityCode='110108',
                        sOrganType='0',
                        sCorparate='0',
                        sLimitType='0'):
    sNo = (str)(random.randrange(10000, 99999))
    sBusinessCode = sCityCode + sOrganType + sCorparate + sLimitType + sNo
    verify_code = 10
    for index in range(14):
        verify_code = ((
            (verify_code % 11 + int(sBusinessCode[index])) % 10 or 10) *
                       2) % 11
    verify_code = (11 - (verify_code % 10)) % 10
    sBusinessCode = sBusinessCode + str(verify_code)
    return sBusinessCode


# 生成组织机构代码9位
def CreateOrganization():
    ww = [3, 7, 9, 10, 5, 8, 4, 2]  #算法因子
    cc = []
    dd = 0

    for i in range(8):  #给 CC 赋值
        cc.append(random.randint(1, 9))
        dd = dd + cc[i] * ww[i]
    for i in range(len(cc)):
        cc[i] = str(cc[i])
    C9 = 11 - dd % 11
    if C9 == 10:
        C9 = 'X'
    else:
        if C9 == 11:
            C9 = '0'
        else:
            C9 = str(C9)
    cc.append('-' + C9)
    return "".join(cc)


# 生成统一社会信用代码 18位
def BuildSocialCredit():
    manage_code = [9]  # 登记管理部门代码：9-工商
    type_code = [1, 2, 3, 9]  # 9-1-企业，9-2-个体工商户，9-3-农民专业合作社，9-9-其他
    area_code = '100000'  # 登记管理机关行政区划码：100000-国家用
    org_code = CreateOrganization().replace('-', '')  # 组织机构代码
    sum = 0
    weight_code = [
        1, 3, 9, 27, 19, 26, 16, 17, 20, 29, 25, 13, 8, 24, 10, 30, 28
    ]  # Wi 代表第i位上的加权因子=pow(3,i-1)%31
    code = str(random.choice(manage_code)) + str(
        random.choice(type_code)) + area_code + org_code
    for i in range(17):
        sum = sum + check_dict[code[i:i + 1]] * weight_code[i]
    C18 = dict_check[31 - sum % 31]
    social_code = code + C18
    return social_code


if __name__ == "__main__":
    # print('15位营业执照:' + BuildBusinessCode15('110108','0','0','0'))
    # print('组织机构代码:' + CreateOrganization())
    # print('统一社会信用代码:' + BuildSocialCredit())
    print(check_zuzhi(CreateOrganization()))
