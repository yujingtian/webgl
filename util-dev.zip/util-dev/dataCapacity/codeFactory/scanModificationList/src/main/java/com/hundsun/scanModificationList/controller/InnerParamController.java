package com.hundsun.scanModificationList.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.hundsun.scanModificationList.entity.*;
import com.hundsun.scanModificationList.service.ParamService;
import com.hundsun.scanModificationList.util.ResultEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;

@CrossOrigin
@RestController
@RequestMapping(value = "/param")
public class InnerParamController {

    @Autowired
    private ParamService paramService;

    @PostMapping(value = "/innerParam")
    public void GetParam(@RequestBody Map innerParam, HttpServletResponse response){

        /*
            获取入参：
            modificationList：修改单列表；
            distributedObject：发放对象；
            baseOnPatch：基于版本   例：HSACCT2.0V202101.00.013升级
         */
        String modificationStr = (String) innerParam.get("modificationList");
        modificationStr = modificationStr.replace("，",",");
        List<String> modificationList =  Arrays.asList(modificationStr.trim().split(","));
        String distributedObject = (String) innerParam.get("distributedObject");
        String baseOnPatch = (String) innerParam.get("baseOnPatch");

        //截取基于版本的字符串，得到数字类型的增量版本号 (incrementNumber)与补丁版本号(patchNumber)
        String versionNum = baseOnPatch;
        versionNum = versionNum.toUpperCase();

        String productName = versionNum.substring(0,versionNum.indexOf("V")+7);

        String incrementNum = versionNum.substring(versionNum.indexOf("V")+8,versionNum.lastIndexOf("."));
        int incrementNumber = Integer.parseInt(incrementNum);

        String patchNum = versionNum.substring(versionNum.lastIndexOf(".")+1,versionNum.length());
        patchNum = patchNum.replaceAll("[\u4e00-\u9fa5]", "");
        int patchNumber = Integer.parseInt(patchNum);

        //调用service方法，获得出参，并将修改单列表，发放对象，基于版本保存在出参中，方便最后的保存工作
        Map map = paramService.scanOutParam(modificationList,productName,incrementNumber,patchNumber);

        map.put("modificationList",modificationList);
        map.put("distributedObject",distributedObject);
        map.put("baseOnPatch",baseOnPatch);

        //出参转换为json格式，保留汉字，保留值为null的属性
        String out = JSONObject.toJSONString(map, SerializerFeature.DisableCircularReferenceDetect ,SerializerFeature.WriteMapNullValue);
        try {

            response.setCharacterEncoding("utf-8");
            response.getWriter().write(out);

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    @PostMapping("/outerParam")
    public void OutParam(@RequestBody Map innerParam ,HttpServletResponse response){

        /*
            获取入参并将json发送的数据，转换为对象数组的格式
            programItem：程序项列表
            fildName：中间版本未找到的程序项，预处理界面添加 reworkingIdList，保存添加的数据
            modificationList：修改单列表；
            distributedObject：发放对象；
            baseOnPatch：基于版本  例：HSACCT2.0V202101.00.013升级
            citeFrom：引入修改单列表
            minVersionNotFound：最低版本未找到的程序项，与处理界面添加 minprover

         */
        ArrayList<ArrayList<tsproinfo>> programItem = (ArrayList) innerParam.get("programItem");
        ArrayList<ArrayList<tsproinfo>> programItem2 = new ArrayList<>();
        for (int i=0;i<programItem.size();i++){
            ArrayList<tsproinfo> arrayList = new ArrayList<>();
            for (Object object : programItem.get(i)) {
                JSONObject jsonObject = JSON.parseObject(JSON.toJSONString(object));
                tsproinfo entityVo = jsonObject.toJavaObject(tsproinfo.class);
                arrayList.add(entityVo);
            }

            programItem2.add(arrayList);
        }

        ArrayList<tsproinfoout> fildName = (ArrayList) innerParam.get("fildName");
        ArrayList<tsproinfoout> fildName2 = new ArrayList<>();
        for (Object object : fildName) {
            JSONObject jsonObject = JSON.parseObject(JSON.toJSONString(object));
            tsproinfoout entityVo = jsonObject.toJavaObject(tsproinfoout.class);
            fildName2.add(entityVo);
        }

        ArrayList modificationList = (ArrayList) innerParam.get("modificationList");

        String baseOnPatch = (String) innerParam.get("baseOnPatch");

        ArrayList citeFrom = (ArrayList) innerParam.get("citeFrom");

        ArrayList<Map> minVersionNotFound = (ArrayList) innerParam.get("minVersionNotFound");

        String versionNum = baseOnPatch;
        String distributedObject = (String) innerParam.get("distributedObject");

        //调用service方法，获取结果
        Map map = paramService.buildOutParam(programItem2,fildName2,citeFrom,minVersionNotFound,versionNum, modificationList);

        map.put("modificationList",modificationList);
        map.put("distributedObject",distributedObject);
        map.put("baseOnPatch",baseOnPatch);

        //出参转换为json格式，保留汉字，保留值为null的属性
        String out = JSONObject.toJSONString(map, SerializerFeature.DisableCircularReferenceDetect ,SerializerFeature.WriteMapNullValue);
        response.setCharacterEncoding("utf-8");
        try {
            response.getWriter().write(out);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    @PostMapping("/saveData")
    public void buildExcle(@RequestBody Map innerParam ,HttpServletResponse response){

        /*

            获取入参并将json发送的数据，转换为对象数组的格式
            programItem：程序项列表
            distributedObject：发放对象；
            baseOnPatch：基于版本  例：HSACCT2.0V202101.00.013升级
            finalModificationList：最终引入修改单
            moificationNotTest：引入但不需要测试的修改单
            introduceNotManifest：引入不体现修改单（不需要保存在Excle文件中）

         */

        ArrayList<ArrayList<tsproinfo>> programItem = (ArrayList) innerParam.get("programItem");
        ArrayList<ArrayList<tsproinfo>> programItem2 = new ArrayList<>();
        for (int i=0;i<programItem.size();i++){
            ArrayList<tsproinfo> arrayList = new ArrayList<>();
            for (Object object : programItem.get(i)) {
                JSONObject jsonObject = JSON.parseObject(JSON.toJSONString(object));
                tsproinfo entityVo = jsonObject.toJavaObject(tsproinfo.class);
                arrayList.add(entityVo);
            }

            programItem2.add(arrayList);
        }

        String distributedObject = (String) innerParam.get("distributedObject");

        String baseOnPatch = (String) innerParam.get("baseOnPatch");

        ArrayList finalModificationList = (ArrayList) innerParam.get("finalModificationList");

        ArrayList<MoificationNotTest> moificationNotTest = (ArrayList<MoificationNotTest>) innerParam.get("moificationNotTest");

        ArrayList<MoificationNotTest> moificationNotTest2 = new ArrayList<>();

        for (Object object : moificationNotTest) {
            JSONObject jsonObject = JSON.parseObject(JSON.toJSONString(object));
            MoificationNotTest entityVo = jsonObject.toJavaObject(MoificationNotTest.class);
            moificationNotTest2.add(entityVo);
        }

        ArrayList introduceNotManifest = (ArrayList) innerParam.get("introduceNotManifest");


        // 调用service方法，获取需要下载的excle文件的信息
        response = paramService.saveFinalData(programItem2,distributedObject,baseOnPatch,finalModificationList,moificationNotTest2,response);
        response.setCharacterEncoding("utf-8");
        try {
            response.getWriter().write("成功生成Excle文件");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @PostMapping("/saveTempData")
    public String  saveTempData(@RequestBody Map innerParam) throws JsonProcessingException {
        String userID = (String) innerParam.get("userID");

        ArrayList<ArrayList<tsproinfo>> programItem = (ArrayList) innerParam.get("programItem");
        ArrayList<ArrayList<tsproinfo>> programItem2 = new ArrayList<>();
        for (int i=0; i < programItem.size(); i++){
            ArrayList<tsproinfo> arrayList = new ArrayList<>();
            for (Object object : programItem.get(i)) {
                JSONObject jsonObject = JSON.parseObject(JSON.toJSONString(object));
                tsproinfo entityVo = jsonObject.toJavaObject(tsproinfo.class);
                arrayList.add(entityVo);
            }

            programItem2.add(arrayList);
        }

        java.util.Date date = new java.util.Date(System.currentTimeMillis());
        SimpleDateFormat format = new SimpleDateFormat("yyyyMMddHHmmss");
        String submitTime = format.format(date);

        String baseOnPatch = (String) innerParam.get("baseOnPatch");
        if (baseOnPatch == null){
            baseOnPatch = "";
        }

        String distributedObject = (String) innerParam.get("distributedObject");
        if (distributedObject == null){
            distributedObject = "";
        }

        ArrayList<String> finalModificationList = (ArrayList<String>) innerParam.get("finalModificationList");

        ArrayList<MoificationNotTest> moificationNotTest = (ArrayList<MoificationNotTest>) innerParam.get("moificationNotTest");

        ArrayList<MoificationNotTest> moificationNotTest2 = new ArrayList<>();

        ArrayList<String> initModificationList = (ArrayList<String>) innerParam.get("initModificationList");

        ArrayList<String> deleteGroup = (ArrayList<String>) innerParam.get("deleteGroup");

        // tableData
//        Map<String, Object> originalTableData = (Map<String, Object>) innerParam.get("tableData");
        ArrayList<TableData> tableData = new ArrayList<>();
        ArrayList<Map<String, Object>> originalTableData = (ArrayList<Map<String, Object>>) innerParam.get("tableData");
        for (Map<String, Object> tableDataMap : originalTableData){
            TableData td = new TableData();
            td.setLastversion(String.valueOf(tableDataMap.get("lastversion")));
            td.setMidVersionLength(Integer.parseInt(String.valueOf(tableDataMap.get("midVersionLength"))));
            td.setProname(String.valueOf(tableDataMap.get("proname")));

            List<String> reworking = new ArrayList<>();
            for (int i = 0; ; i++){
                if (tableDataMap.get("reworkingId" + i) != null){
                    reworking.add(String.valueOf(tableDataMap.get("reworkingId" + i)));
                } else {
                    td.setReworkingIdList(reworking);
                    break;
                }
            }

            List<ArrayList<tsproinfo>> oritsproinfo = new ArrayList<>();
            for (int i = 0; ; i++){
                if (tableDataMap.get("tsproInfoList" + i) != null){
                    ArrayList<tsproinfo> tsproInfoList = new ArrayList<>();
                    for (Object object : (ArrayList) tableDataMap.get("tsproInfoList" + i)) {
                        JSONObject jsonObject = JSON.parseObject(JSON.toJSONString(object));
                        tsproinfo entityVo = jsonObject.toJavaObject(tsproinfo.class);
                        tsproInfoList.add(entityVo);
                    }
                    oritsproinfo.add(tsproInfoList);
                } else {
                    td.setTsproInfoList(oritsproinfo);
                    break;
                }
            }

            List<String> version = new ArrayList<>();
            for (int i = 0; ;i++){
                if (tableDataMap.get("version" + i) != null){
                    version.add(String.valueOf(tableDataMap.get("version" + i)));
                } else {
                    td.setVersionList(version);
                    break;
                }
            }
            tableData.add(td);
        }

        // versionColor
        ArrayList<VersionColor> versionColor = new ArrayList<>();
        ArrayList<Map<String, Object>> originalVersionColor = (ArrayList<Map<String, Object>>) innerParam.get("versionColor");
        for (Map<String, Object> versionColorMap : originalVersionColor){
            VersionColor vc = new VersionColor();
            List<Character> confirm = new ArrayList<>();
            for (int i = 0; ; i++){
                if (versionColorMap.get("confirm" + i) != null){
                    if ((Boolean) versionColorMap.get("confirm" + i)){
                        confirm.add('1');
                    } else {
                        confirm.add('0');
                    }
                } else {
                    vc.setConfirmList(confirm);
                    break;
                }
            }

            List<Character> selfconfirm = new ArrayList<>();
            for (int i = 0; ; i++){
                if (versionColorMap.get("selfconfirm" + i) != null){
                    if ((Boolean) versionColorMap.get("selfconfirm" + i)){
                        selfconfirm.add('1');
                    } else {
                        selfconfirm.add('0');
                    }
                } else {
                    vc.setSelfconfirmList(selfconfirm);
                    break;
                }
            }

            List<String> state = new ArrayList<>();
            for (int i = 0; ; i++){
                if (versionColorMap.get("state" + i) != null){
                    state.add(String.valueOf(versionColorMap.get("state" + i)));
                } else {
                    vc.setStateList(state);
                    break;
                }
            }

            versionColor.add(vc);
        }


        // moificationNotTest
        for (Object object : moificationNotTest) {
            JSONObject jsonObject = JSON.parseObject(JSON.toJSONString(object));
            MoificationNotTest entityVo = jsonObject.toJavaObject(MoificationNotTest.class);
            moificationNotTest2.add(entityVo);
        }

        ArrayList<String> introduceNotManifest = (ArrayList<String>) innerParam.get("introduceNotManifest");

        ArrayList<String> citeFrom = (ArrayList<String>) innerParam.get("citeFrom");

        boolean success = paramService.saveTempDate(userID, submitTime, programItem2, distributedObject, baseOnPatch, finalModificationList, moificationNotTest2, introduceNotManifest, initModificationList, deleteGroup, tableData, versionColor, citeFrom);

        if (success){
            System.out.println("临时数据存储成功");
            return ResultEntity.successWithData("submitTime为" + submitTime).returnResult();
        } else {
            System.out.println("临时数据存储失败");
            return ResultEntity.failWithoutData("临时数据存储失败").returnResult();
        }
    }

    @PostMapping("/getTempData")
    public String getTempData(@RequestParam(value = "userID", defaultValue = "") String userID,
                              @RequestParam(value = "submitTime", defaultValue = "") String submitTime) throws JsonProcessingException {

        if (userID == null || userID.equals("")){
            System.out.println("userID为空");
            ResultEntity.failWithoutData("userID为空").returnResult();
        }
        if (submitTime == null || submitTime.equals("")){
            System.out.println("submitTime为空");
            ResultEntity.failWithoutData("submitTime为空").returnResult();
        }

        Map<String, Object> result = paramService.getTempData(userID, submitTime);

        return ResultEntity.successWithData(result).returnResult();

    }

    @PostMapping("/getBasicTemp")
    public String getBasicTemp(@RequestParam(value = "userID", defaultValue = "") String userID) throws JsonProcessingException {
        if (userID == null || userID.equals("")){
            System.out.println("userID为空");
            ResultEntity.failWithoutData("userID为空").returnResult();
        }

        List<TsBasicTemp> tsBasicTempList = paramService.getTsBasicTemp(userID);

        return ResultEntity.successWithData(tsBasicTempList).returnResult();
    }

    @PostMapping("/deleteTempData")
    public String deleteTempData(@RequestParam(value = "userID", defaultValue = "") String userID,
                                 @RequestParam(value = "submitTime", defaultValue = "") String submitTime) throws JsonProcessingException {

        if (userID == null || userID.equals("")){
            System.out.println("userID为空");
            return ResultEntity.failWithoutData("userID为空").returnResult();
        }
        if (submitTime == null || submitTime.equals("")){
            System.out.println("submitTime为空");
            return ResultEntity.failWithoutData("submitTime为空").returnResult();
        }

        if (paramService.selectBasicById(userID).size() == 0) {
            System.out.println("该userID无临时数据");
            return ResultEntity.failWithoutData("该userID无临时数据").returnResult();
        } else if (paramService.selectBasicByIdAndTime(userID, submitTime).size() == 0){
            System.out.println("该用户无该临时数据");
            return ResultEntity.failWithoutData("该用户无该临时数据").returnResult();
        }

        boolean success = paramService.deleteTempData(userID, submitTime);

        if (success){
            return ResultEntity.successWithDataMsg("删除成功", null).returnResult();
        } else {
            return ResultEntity.failWithoutData("删除失败").returnResult();
        }
    }
}
