package com.hundsun.scanModificationList.mapper;

import com.hundsun.scanModificationList.entity.TsSubTemp;
import com.hundsun.scanModificationList.entity.tsproinfo;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

/**
 * @Author: kcaumber
 * @Date: 9/26/21 7:12 PM
 */
@Mapper
@Repository("TsSubTempMapper")
public interface TsSubTempMapper {

    int insertTsSubTemp(TsSubTemp tsSubTemp);

    List<TsSubTemp> selectTsproinfoByPII(String PII);

    List<TsSubTemp> selectByPIIAndProName(String PII, String proName);

    List<String> selectTsproinfoByFMI(String FMI);

    List<TsSubTemp> selectTsproinfoByMNTI(String MNTI);

    List<String> selectTsproinfoByINMI(String INMI);

    int deleteByIdAndTime(String PII, String FMI, String MNTI, String INMI, String IMFL, String DG, String TD, String VC, String CF);

    List<String> selectTsproinfoByIMFL(String IMFL);

    List<String> selectTsproinfoByDG(String DG);

    int selectTsproinfoByTD(String TD);

    List<TsSubTemp> selectTsproinfoFirstByTD(String TD, int arrayOrder);

    List<TsSubTemp> selectTsproinfoSecondByTD(String TD, int arrayOrder);

    List<TsSubTemp> selectTsproinfoThridByTD(String TD, int arrayOrder, String flag);

    List<TsSubTemp> selectTsproinfoByVC(String VC, int arrayOrder);

    List<String> selectTsproinfoByCF(String CF);

    int selectTsproinfoNumByVC(String VC);
}
