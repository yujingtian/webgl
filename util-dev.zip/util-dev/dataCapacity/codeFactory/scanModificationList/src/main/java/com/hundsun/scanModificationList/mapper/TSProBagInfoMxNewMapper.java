package com.hundsun.scanModificationList.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hundsun.scanModificationList.entity.tsprobaginfomxNew;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
@Repository("TSProBagInfoMxNewMapper")
public interface TSProBagInfoMxNewMapper extends BaseMapper<tsprobaginfomxNew> {

    tsprobaginfomxNew selectReworkingId(@Param("bagId") String bagId ,@Param("pName") String pName);

    List<tsprobaginfomxNew> selectByBagIdAndProname(String bagId, String proname);
}
