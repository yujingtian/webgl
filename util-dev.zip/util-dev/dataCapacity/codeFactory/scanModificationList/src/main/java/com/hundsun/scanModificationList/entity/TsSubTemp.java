package com.hundsun.scanModificationList.entity;

/**
 * @Author: kcaumber
 * @Date: 9/26/21 3:31 PM
 */
public class TsSubTemp {

    private String subID;
    private String proName;
    private String prover;
    private String reworkingId;
    private String flag;
    private String remark;
    private Integer midVersionLength;
    private String sxOrder;
    private Character confirm;
    private Character selfconfirm;
    private String state;
    private Integer arrayOrder;

    public TsSubTemp() {
    }

    public TsSubTemp(String subID, String proName, String prover, String reworkingId, String flag, String remark, Integer midVersionLength, String sxOrder, Character confirm, Character selfconfirm, String state, Integer arrayOrder) {
        this.subID = subID;
        this.proName = proName;
        this.prover = prover;
        this.reworkingId = reworkingId;
        this.flag = flag;
        this.remark = remark;
        this.midVersionLength = midVersionLength;
        this.sxOrder = sxOrder;
        this.confirm = confirm;
        this.selfconfirm = selfconfirm;
        this.state = state;
        this.arrayOrder = arrayOrder;
    }

    public String getSubID() {
        return subID;
    }

    public void setSubID(String subID) {
        this.subID = subID;
    }

    public String getProName() {
        return proName;
    }

    public void setProName(String proName) {
        this.proName = proName;
    }

    public String getProver() {
        return prover;
    }

    public void setProver(String prover) {
        this.prover = prover;
    }

    public String getReworkingId() {
        return reworkingId;
    }

    public void setReworkingId(String reworkingId) {
        this.reworkingId = reworkingId;
    }

    public String getFlag() {
        return flag;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public Integer getMidVersionLength() {
        return midVersionLength;
    }

    public void setMidVersionLength(Integer midVersionLength) {
        this.midVersionLength = midVersionLength;
    }

    public String getSxOrder() {
        return sxOrder;
    }

    public void setSxOrder(String sxOrder) {
        this.sxOrder = sxOrder;
    }

    public Character getConfirm() {
        return confirm;
    }

    public void setConfirm(Character confirm) {
        this.confirm = confirm;
    }

    public Character getSelfconfirm() {
        return selfconfirm;
    }

    public void setSelfconfirm(Character selfconfirm) {
        this.selfconfirm = selfconfirm;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public Integer getArrayOrder() {
        return arrayOrder;
    }

    public void setArrayOrder(Integer arrayOrder) {
        this.arrayOrder = arrayOrder;
    }

    @Override
    public String toString() {
        return "TsSubTemp{" +
                "subID='" + subID + '\'' +
                ", proName='" + proName + '\'' +
                ", prover='" + prover + '\'' +
                ", reworkingId='" + reworkingId + '\'' +
                ", flag='" + flag + '\'' +
                ", remark='" + remark + '\'' +
                ", midVersionLength=" + midVersionLength +
                ", sxOrder='" + sxOrder + '\'' +
                ", confirm=" + confirm +
                ", selfconfirm=" + selfconfirm +
                ", state='" + state + '\'' +
                ", arrayOrder=" + arrayOrder +
                '}';
    }
}
