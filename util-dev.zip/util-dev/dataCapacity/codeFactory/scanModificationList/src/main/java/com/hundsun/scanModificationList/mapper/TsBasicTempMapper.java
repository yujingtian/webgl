package com.hundsun.scanModificationList.mapper;

import com.hundsun.scanModificationList.entity.TsBasicTemp;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @Author: kcaumber
 * @Date: 9/26/21 3:45 PM
 */
@Mapper
@Repository("TsBasicTempMapper")
public interface TsBasicTempMapper {

    int insertTsBasicTemp(TsBasicTemp t);

    List<TsBasicTemp> selectTsBasicTempByIDAndTime(String userID, String submitTime);

    List<TsBasicTemp> selectTsBasicTempByID(String userID);

    int deleteTsBasicTempByIdAndTime(String userID, String submitTime);
}
