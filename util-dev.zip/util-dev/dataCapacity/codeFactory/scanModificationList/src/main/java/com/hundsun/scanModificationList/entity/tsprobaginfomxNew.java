package com.hundsun.scanModificationList.entity;

import lombok.Data;

@Data
public class tsprobaginfomxNew {

    private String bagid;

    private String proname;

    private String prover;

    public String getBagid() {
        return bagid;
    }

    public void setBagid(String bagid) {
        this.bagid = bagid;
    }

    public String getProname() {
        return proname;
    }

    public void setProname(String proname) {
        this.proname = proname;
    }

    public String getProver() {
        return prover;
    }

    public void setProver(String prover) {
        this.prover = prover;
    }
}
