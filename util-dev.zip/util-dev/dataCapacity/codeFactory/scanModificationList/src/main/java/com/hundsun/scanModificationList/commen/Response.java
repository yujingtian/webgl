package com.hundsun.scanModificationList.commen;

import lombok.Data;

@Data
public class Response {

    private String msg = "成功";//响应信息
    private Object data;//响应数据

    public Response msg(String msg){
        this.msg = msg;
        return this;
    }

    public Response data(Object data){
        this.data = data;
        return this;
    }

}
