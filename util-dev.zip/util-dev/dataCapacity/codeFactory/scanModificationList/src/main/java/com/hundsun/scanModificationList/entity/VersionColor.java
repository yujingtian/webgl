package com.hundsun.scanModificationList.entity;

import java.util.List;

/**
 * @Author: kcaumber
 * @Date: 10/9/21 1:14 PM
 */
public class VersionColor {

    private List<Character> confirmList;
    private List<Character> selfconfirmList;
    private List<String> stateList;

    public VersionColor() {
    }

    public VersionColor(List<Character> confirmList, List<Character> selfconfirmList, List<String> stateList) {
        this.confirmList = confirmList;
        this.selfconfirmList = selfconfirmList;
        this.stateList = stateList;
    }

    public List<Character> getConfirmList() {
        return confirmList;
    }

    public void setConfirmList(List<Character> confirmList) {
        this.confirmList = confirmList;
    }

    public List<Character> getSelfconfirmList() {
        return selfconfirmList;
    }

    public void setSelfconfirmList(List<Character> selfconfirmList) {
        this.selfconfirmList = selfconfirmList;
    }

    public List<String> getStateList() {
        return stateList;
    }

    public void setStateList(List<String> stateList) {
        this.stateList = stateList;
    }

    @Override
    public String toString() {
        return "VersionColor{" +
                "confirmList=" + confirmList +
                ", selfconfirmList=" + selfconfirmList +
                ", stateList=" + stateList +
                '}';
    }
}
