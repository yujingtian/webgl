package com.hundsun.scanModificationList.entity;

import lombok.Data;

@Data
public class dctsprospecialprogramitem {

    private String reworkingId;

    private String proname;

    private String prover;

    public String getReworkingId() {
        return reworkingId;
    }

    public void setReworkingId(String reworkingId) {
        this.reworkingId = reworkingId;
    }

    public String getProname() {
        return proname;
    }

    public void setProname(String proname) {
        this.proname = proname;
    }

    public String getProver() {
        return prover;
    }

    public void setProver(String prover) {
        this.prover = prover;
    }
}
