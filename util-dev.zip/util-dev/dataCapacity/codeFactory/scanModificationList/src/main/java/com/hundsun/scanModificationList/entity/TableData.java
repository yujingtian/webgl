package com.hundsun.scanModificationList.entity;

import java.util.ArrayList;
import java.util.List;

/**
 * @Author: kcaumber
 * @Date: 10/9/21 11:10 AM
 */
public class TableData {

    private String lastversion;
    private Integer midVersionLength;
    private String proname;
    private List<String> reworkingIdList;
    private List<ArrayList<tsproinfo>> tsproInfoList;
    private List<String> versionList;

    public TableData() {
    }

    public TableData(String lastversion, Integer midVersionLength, String proname, List<String> reworkingIdList, List<ArrayList<tsproinfo>> tsproInfoList, List<String> versionList) {
        this.lastversion = lastversion;
        this.midVersionLength = midVersionLength;
        this.proname = proname;
        this.reworkingIdList = reworkingIdList;
        this.tsproInfoList = tsproInfoList;
        this.versionList = versionList;
    }

    public String getLastversion() {
        return lastversion;
    }

    public void setLastversion(String lastversion) {
        this.lastversion = lastversion;
    }

    public Integer getMidVersionLength() {
        return midVersionLength;
    }

    public void setMidVersionLength(Integer midVersionLength) {
        this.midVersionLength = midVersionLength;
    }

    public String getProname() {
        return proname;
    }

    public void setProname(String proname) {
        this.proname = proname;
    }

    public List<String> getReworkingIdList() {
        return reworkingIdList;
    }

    public void setReworkingIdList(List<String> reworkingIdList) {
        this.reworkingIdList = reworkingIdList;
    }

    public List<ArrayList<tsproinfo>> getTsproInfoList() {
        return tsproInfoList;
    }

    public void setTsproInfoList(List<ArrayList<tsproinfo>> tsproInfoList) {
        this.tsproInfoList = tsproInfoList;
    }

    public List<String> getVersionList() {
        return versionList;
    }

    public void setVersionList(List<String> versionList) {
        this.versionList = versionList;
    }

    @Override
    public String toString() {
        return "TableData{" +
                "lastversion='" + lastversion + '\'' +
                ", midVersionLength=" + midVersionLength +
                ", proname='" + proname + '\'' +
                ", reworkingIdList=" + reworkingIdList +
                ", tsproInfoList=" + tsproInfoList +
                ", versionList=" + versionList +
                '}';
    }
}
