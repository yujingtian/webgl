package com.hundsun.scanModificationList.service;

import com.hundsun.scanModificationList.entity.*;
import com.hundsun.scanModificationList.mapper.*;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.formula.functions.T;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.OutputStream;
import java.util.*;

@Service
public class ParamService {

    @Autowired
    private TSProInfoMapper tSProInfoMapper;

    @Autowired
    private TSProBagNameMangerMapper tsProBagNameMangerMapper;

    @Autowired
    private TSProBagInfoMxNewMapper tsProBagInfoMxNewMapper;

    @Autowired
    private DCTSProSpecialProgramItemMapper dctsProSpecialProgramItemMapper;

    @Autowired
    private TsBasicTempMapper tsBasicTempMapper;

    @Autowired
    private TsSubTempMapper tsSubTempMapper;

    public Map<String, Object> scanOutParam(List<String> modificationList, String productName,int incrementNumber,int patchNumber){
        // 调用方法，获取修改单列表的全部不重复程序项及其最高版本,此时并不将特殊情况作为一个程序项，而是俩
        // 存在xml里的程序项如果他的低版本在此次的修改单列表中，是否应该先是在programItem中
        ArrayList<ArrayList<tsproinfo>> programItem = selectModificationList(modificationList);

        ArrayList<tsproinfoout> fildName = new ArrayList<>(); // 缺少的程序项
        ArrayList<String> citeForm = new ArrayList<>();
        ArrayList<tsproinfo> minVersionNotFound = new ArrayList<>(); // 遍历所有补丁包后未找到最低版本的程序项

        // 遍历所有以获取到最高版本的程序项,寻找最低基于版本，寻找中间跳过的程序项
        for (int i = 0; i < programItem.size(); i++){
            // 查看是否属于 fieldname.xml 特殊程序项，根据其 修改单号，程序项名称，程序向版本查询，如果查到，即为特殊程序项，无需前挑
            List<tsproinfo> listFN = dctsProSpecialProgramItemMapper.selectByAllFactor(programItem.get(i).get(0).getReworkingId().trim(), programItem.get(i).get(0).getProver().trim(), programItem.get(i).get(0).getProname().trim());
            if (listFN.size() != 0){
                continue;
            }

            // 每次将补丁包版本回到参数给出版
            int patchNumberA = patchNumber; // 001
            int incrementNumberA = incrementNumber; // 01
            String productNameA = productName; // HS

            List<tsprobaginfomxNew> bagInfoMxNewList = new ArrayList<>();
            //查询当前programItem中的程序项的最低版本直到查到为止，或之前全部补丁包都无此程序项，则放入 minVersionNotFound ，预处理界面手工填入
            while (true){
                // 根据基于补丁包版本查看是否存在补丁包，并获取BAGID
                List<tsprobagnamemanger> bagList = tsProBagNameMangerMapper.selectByAllFactor(incrementNumberA, patchNumberA, productNameA);

                // 若补丁包不存在，则补丁版本降低
                if (bagList == null || bagList.size() == 0){
                    patchNumberA = patchNumberA - 1;
                } else {
                    // 补丁包存在，根据补丁包包名与程序项名称，查看该补丁包中是否存在当前programItem中的程序项
                    bagInfoMxNewList = tsProBagInfoMxNewMapper.selectByBagIdAndProname(bagList.get(0).getBagid().trim(), programItem.get(i).get(0).getProname().trim());

                    // 查询到有补丁包中存在当前程序项，查看程序项版本，如果最低程序项版本 > 当前程序项版本，则继续查询，否则跳出最低版本查询的循环
                    if (bagInfoMxNewList != null && bagInfoMxNewList.size() > 0){
                        int bagProver = Integer.parseInt(bagInfoMxNewList.get(0).getProver().substring(bagInfoMxNewList.get(0).getProver().lastIndexOf(".") + 1));
                        int currProver = Integer.parseInt(programItem.get(i).get(0).getProver().substring(programItem.get(i).get(0).getProver().lastIndexOf(".") + 1));
                        if (bagProver < currProver){
                            break;
                        }
                    }

                    // 基线升级后的第一个补丁包，查询到此如果没有查询到，则将程序项放入 minVersionNotFound ，预处理界面手工处理
                    if (productNameA.equals("HSACCT2.0V202001") && incrementNumberA == 0 && patchNumberA == 1){
                        minVersionNotFound.add(programItem.get(i).get(0));
                        patchNumberA = -1;
                        break;
                    }
                    patchNumberA = patchNumberA - 1;

                }

                //判断补丁版本大小，如果小于0，则需要跳入上一个主推增量的最高补丁版本
                if (patchNumberA < 0){
                    while (true){
                        if (incrementNumberA == 0){
                            String productName1 = productNameA;
                            String productName2 = productNameA;
                            productName1 = productName1.substring(0,productName1.indexOf("V")+1);
                            String a = productName2.substring(productName2.indexOf("V")+1,productName2.indexOf("V")+5);
                            int aNum = Integer.parseInt(a)-1;
                            String aStr = String.valueOf(aNum);
                            productName2 = productName2.substring(productName2.indexOf("V")+5,productName2.length());
                            productNameA = productName1+aStr+productName2;

                            if (productNameA.equals("HSACCT2.0V201901")){
                                patchNumberA = -1;
                                minVersionNotFound.add(programItem.get(i).get(0));
                                break;
                            }
                            //查询基于年份的增量号
                            incrementNumberA = tsProBagNameMangerMapper.selectIncrement(productNameA)+1;
                        } else {
                            // 根据增量号与基于年份，查询补丁版本
                            incrementNumberA = incrementNumberA-1;

                            bagList = tsProBagNameMangerMapper.selectByIncreAndProdu(incrementNumberA, productNameA);

                            // 问题：为什么当前增量号与基于年份，查询补丁版本失败直接就说他找不到了啊，理论上来说有问题，实际上没问题，因为不可能整个增量包消失
                            if (bagList == null || bagList.size() == 0){
                                patchNumberA = -1;
                                minVersionNotFound.add(programItem.get(i).get(0));
                                break;
                            }
                            //有多个补丁版本，则默认为主推增量，查询最大补丁版本
                            if (bagList.size() > 1){
                                patchNumberA = tsProBagNameMangerMapper.selectPatch(productNameA,incrementNumberA);
                                break;
                            }
//                            新增的逻辑
                            patchNumberA = bagList.get(0).getSpecialno();
                            break;
                        }
                    }
                    //  判断是否存在最低版本不存在的现象
                    if (patchNumberA == -1){
                        break;
                    }
                }
            }

            if (patchNumberA < 0){
                continue;
            }

            String PIProver = programItem.get(i).get(0).getProver().trim(); // 获取当前程序向的版本
            int PIProverNum = Integer.parseInt(PIProver.substring(PIProver.lastIndexOf(".")+1));
            PIProver = PIProver.substring(0, PIProver.lastIndexOf(".")+1);
            // 这里获取到了前一版本
            PIProver = PIProver + String.valueOf(PIProverNum-1);

            // 这里获取到出现有版本最高版本的后缀
            String prover = bagInfoMxNewList.get(0).getProver().substring(bagInfoMxNewList.get(0).getProver().lastIndexOf(".") + 1);

            String proname = bagInfoMxNewList.get(0).getProname();
            String lowProver = bagInfoMxNewList.get(0).getProver();
            tsproinfo tsproinfo = new tsproinfo();

            tsproinfo.setProname(proname);
            tsproinfo.setProver(lowProver);
            programItem.get(i).add(1, tsproinfo);

            int lowProverNum = Integer.parseInt(prover);

            //判断 当前推送版本与最低版本的差距，如果最低版本+1等于当前推送版本，则没有发生跳版本现象，跳过此程序项
            if (lowProverNum + 1 == PIProverNum){
                continue;
            } else {
                // 发生跳版本，查询中间版本
                String proverA = bagInfoMxNewList.get(0).getProver();
                while (!proverA.equals(PIProver)){

                    // 获取比低版本高一版本的prover
                    int p1 = Integer.parseInt(proverA.substring(proverA.lastIndexOf(".")+1));
                    String proverA1 = proverA.substring(0, proverA.lastIndexOf(".")+1);
                    proverA = proverA1 + String.valueOf(p1+1);
                    //默认最高程序项版本为999，如果大于，则需要跳基线升级
                    if (p1 + 1 > 999){
                        proverA1 = proverA.substring(0, proverA.lastIndexOf("."));
                        int b = Integer.parseInt(proverA1.substring(proverA1.lastIndexOf(".")+1));
                        proverA1 = proverA1.substring(0,proverA1.lastIndexOf(".")+1);
                        p1 = 1;

                        proverA = proverA1 + String.valueOf(b) + "." +String.valueOf(p1);
                    }

                    List<tsproinfo> tsproinfoListByPNAndPR = tSProInfoMapper.selectByPronameAndProver(proname, proverA);

                    // 判断二合一特殊情况是否在数据库tSProInfo中，代码应在此处

                    //如果查询结果为空，则中间版本程序项未找到，程序项信息加入 fildName，预处理界面手工处理
                    if (tsproinfoListByPNAndPR.size() == 0){
                        tsproinfoout tsproinfoout = new tsproinfoout();
                        tsproinfoout.setPronameA(proname);
                        tsproinfoout.setProverA(proverA);
                        fildName.remove(tsproinfoout);
                        fildName.add(tsproinfoout);
                        continue;
                    }

                    //查询有结果，判断结果数量
                    tsproinfo a = tsproinfoListByPNAndPR.get(0);
                    if (tsproinfoListByPNAndPR.size() == 1){
                        programItem.get(i).add(1, a);
                        citeForm.remove(a.getReworkingId());
                        citeForm.add(a.getReworkingId());
                    } else if (tsproinfoListByPNAndPR.size() > 1){
                        tsproinfoListByPNAndPR.remove(0);
                        a.setTsproInfoList((ArrayList<tsproinfo>) tsproinfoListByPNAndPR);
                        for (tsproinfo cc : tsproinfoListByPNAndPR){
                            citeForm.remove(cc.getReworkingId());
                            citeForm.add(cc.getReworkingId());
                        }

                        citeForm.remove(a.getReworkingId());
                        citeForm.add(a.getReworkingId());
                        programItem.get(i).add(1,a);
                    }


                    List<tsproinfo> listByReworkingId = tSProInfoMapper.selectByReworkingId(a.getReworkingId());
//二合一
                    int cc = 0;
                    for (int aa = 0; aa < listByReworkingId.size(); aa++){

                        for (int bb = 0; bb < programItem.size(); bb++){
                            if (listByReworkingId.get(aa).getProname().trim().equals(programItem.get(bb).get(0).getProname().trim())){
                                // 获取数据库中与programItem中的prover，并比较
                                String proverAA = listByReworkingId.get(aa).getProver();
                                int pa = Integer.parseInt(proverAA.substring(proverAA.lastIndexOf(".")+1));
                                String proverBB = programItem.get(bb).get(0).getProver();
                                int pb = Integer.parseInt(proverBB.substring(proverBB.lastIndexOf(".")+1));

                                //  判断列表中的程序项版本与要插入的程序项版本
                                if (pa <= pb){
                                    break;
                                } else {
                                    programItem.remove(bb);
                                    cc = programItem.size()-1;
                                    break;
                                }
                            }

                            // 二合一

                            cc = bb;
                        }
                        if (cc == programItem.size() - 1){
                            ArrayList<tsproinfo> ac = new ArrayList();
                            ac.add(listByReworkingId.get(aa));
                            citeForm.remove(listByReworkingId.get(aa).getReworkingId());
                            citeForm.add(listByReworkingId.get(aa).getReworkingId());
                            programItem.add(ac);
                        }
                    }
                }
            }
        }

        // 将程序项中特殊情况接放入fildName中
        for (int i = 0; i < programItem.size(); i++){
            if (programItem.get(i).get(0).getProname().trim().matches("(.*)_or.sql") || programItem.get(i).get(0).getProname().trim().matches("libs_as_(.*)flow.10.so")) {

                // 若fildName中有值就获取到oraginFildName
                List<tsproinfoout> oraginFildName = new ArrayList<>();

                for (int j = 0; j < fildName.size(); j++){
                    if (fildName.get(j).getPronameA().trim().equals(programItem.get(i).get(0).getProname().trim())) {
                        oraginFildName.add(fildName.get(j));
                        fildName.remove(j);
                        j--;
                    }
                }
                for (tsproinfoout tsproinfoout : fildName) {
                    if (tsproinfoout.getPronameA().trim().equals(programItem.get(i).get(0).getProname().trim())) {
                        oraginFildName.add(tsproinfoout);
                        fildName.remove(tsproinfoout);
                    }
                }

                // 将program中的值放入，缺少的中间项用fildName中的补齐，若只剩一项，直接添加至fildName
                for (int j = 0; j < programItem.get(i).size() - 1; j++){

                    tsproinfoout fdTs = new tsproinfoout();
                    fdTs.setPronameA(programItem.get(i).get(j).getProname().trim());
                    fdTs.setProverA(programItem.get(i).get(j).getProver().trim());

                    ArrayList<String> temp = new ArrayList<>();
                    temp.add(programItem.get(i).get(j).getReworkingId());

                    if (programItem.get(i).get(j).getTsproInfoList() != null && programItem.get(i).get(j).getTsproInfoList().size() !=0) {
                        for (int k = 0; k < programItem.get(i).get(j).getTsproInfoList().size(); k++){
                            temp.add(programItem.get(i).get(j).getTsproInfoList().get(k).getReworkingId());
                        }
                    }

                    fdTs.setReworkingIdList(temp);

                    fildName.add(fdTs);

                    if (Integer.parseInt(programItem.get(i).get(j).getProver().trim().substring(programItem.get(i).get(j).getProver().trim().lastIndexOf(".") + 1)) - 1 !=
                            Integer.parseInt(programItem.get(i).get(j).getProver().trim().substring(programItem.get(i).get(j + 1).getProver().trim().lastIndexOf(".") + 1))){
                        fildName.addAll(oraginFildName);
                    }
                }

                tsproinfoout fdTs = new tsproinfoout();
                fdTs.setPronameA(programItem.get(i).get(programItem.get(i).size() - 1).getProname().trim());
                fdTs.setProverA(programItem.get(i).get(programItem.get(i).size() - 1).getProver().trim());

                ArrayList<String> temp = new ArrayList<>();
                temp.add(programItem.get(i).get(programItem.get(i).size() - 1).getReworkingId());
                System.out.println(temp);
                if (programItem.get(i).get(programItem.get(i).size() - 1).getTsproInfoList() != null && programItem.get(i).get(programItem.get(i).size() - 1).getTsproInfoList().size() !=0) {
                    for (int k = 0; k < programItem.get(i).get(programItem.get(i).size() - 1).getTsproInfoList().size(); k++){
                        temp.add(programItem.get(i).get(programItem.get(i).size() - 1).getTsproInfoList().get(k).getReworkingId());
                    }
                }

                fdTs.setReworkingIdList(temp);
                fildName.add(fdTs);

                minVersionNotFound.remove(programItem.get(i).get(0));
                programItem.remove(programItem.get(i));
                i--;
            }
        }

        /*
                返回结果集合：
                citeForm：引入修改单
                fildName：中间版本未找到的程序项
                programItem ： 程序项列表
                minVersionNotFound ：最低版本未找到的程序项
         */

        citeForm.removeAll(modificationList);
        Map map = new HashMap();
        map.put("citeFrom",citeForm);
        map.put("fildName",fildName);
        map.put("programItem",programItem);
        map.put("minVersionNotFound",minVersionNotFound);

        return map;
    }

    public ArrayList<ArrayList<tsproinfo>> selectModificationList(List<String> modificationList){
        ArrayList<ArrayList<tsproinfo>> programItem = new ArrayList();

        // 遍历修改单列表，根据修改单名查询修改单所包含的程序项
        for (String reworkingId : modificationList){

            // 获取当前修改单涉及的所有程序项
            List<tsproinfo> tsproinfosOfOneReworkingId = tSProInfoMapper.selectByReworkingId(reworkingId);

            // 对程序项进行去重，取最高版本操作
            // tsproinfo为每个list的单个tsproinfo
            for (tsproinfo tsproinfo : tsproinfosOfOneReworkingId){

                //防止数据库中数据存在空格
                tsproinfo.setProname(tsproinfo.getProname().trim());
                tsproinfo.setProver(tsproinfo.getProver().trim());

                // 第一个程序项直接加入，不用判断去重
                if (programItem.size() == 0){
                    ArrayList<tsproinfo> a = new ArrayList<>();
                    a.add(tsproinfo);
                    programItem.add(a);
                    continue;
                }

                //判断有无重复的程序项，如果存在，保留最高版本
                boolean repeat = false;
                for (ArrayList<tsproinfo> existTsproinfo : programItem){

                    // 将已经在programItem中的tsproinfo取出
                    String existTsproinfoProname = existTsproinfo.get(0).getProname();
                    String existTsproinfoProver = existTsproinfo.get(0).getProver();

                    // 当当前tsproinfo的程序项与现存的相同时，判断那个版本更高，取最高版本
                    if (existTsproinfoProname.equals(tsproinfo.getProname())){
                        int existEdition = Integer.parseInt(existTsproinfoProver.substring(existTsproinfoProver.lastIndexOf(".") + 1));
                        int currentEdition = Integer.parseInt(tsproinfo.getProver().substring(tsproinfo.getProver().lastIndexOf(".") + 1));

                        // 当当前的比现存的高时，更换programItem中的值
                        if (currentEdition > existEdition){
                            programItem.remove(existTsproinfo);
                            ArrayList<tsproinfo> a = new ArrayList<>();
                            a.add(tsproinfo);
                            programItem.add(a);
                        }
                        repeat = true;
                        break;
                    }
                    // 此处可能需注释 原因为特殊情况判断根据前端反馈在下一步进行操作
                }

                // 判断一个循环是否不正常跳出，若无不正常跳出即为无重复项，将当前程序项插入programItem中
                if (!repeat){
                    ArrayList<tsproinfo> a = new ArrayList<>();
                    a.add(tsproinfo);
                    programItem.add(a);
                }
            }
        }
        return programItem;
    }

    public Map buildOutParam(ArrayList<ArrayList<tsproinfo>> programItem, ArrayList<tsproinfoout> fildName, ArrayList citeFrom, ArrayList<Map> minVersionNotFound, String versionNum, ArrayList modificationList) {

        //  保存中间版本未找到的程序项在预处理界面输入的修改单列表
        ArrayList<String> fileName = new ArrayList<>();

        boolean fildNameEmpty = fildName.size() <= 0;

        for (int i = 0; i < programItem.size(); i++){

            if (fildName.size() == 0){
                fildNameEmpty = true;
                break;
            }

            for (int j = 0; j < fildName.size(); j++){
                if (programItem.get(i).get(0).getProname().trim().equals(fildName.get(j).getPronameA().trim())){
                    for (int k = 0; k < programItem.get(i).size(); k++){
                        if (Integer.parseInt(programItem.get(i).get(k).getProver().trim().substring(programItem.get(i).get(k).getProver().trim().lastIndexOf(".") + 1)) -1 ==
                                Integer.parseInt(fildName.get(j).getProverA().substring(fildName.get(j).getProverA().lastIndexOf(".") + 1))){

                            tsproinfo tsproinfo = new tsproinfo();
                            tsproinfo.setProver(fildName.get(j).getProverA().trim());
                            tsproinfo.setProname(fildName.get(j).getPronameA().trim());
                            ArrayList<String> arrayList = fildName.get(j).getReworkingIdList();
                            tsproinfo.setReworkingId(arrayList.get(0));
                            ArrayList<tsproinfo> tsproinfos = new ArrayList<>();

                            for (int aa = 1; aa < arrayList.size(); aa++) {

                                tsproinfo tsproinfoA = new tsproinfo();
                                tsproinfoA.setProver(fildName.get(j).getProverA().trim());
                                tsproinfoA.setProname(fildName.get(j).getPronameA().trim());
                                tsproinfoA.setReworkingId(arrayList.get(aa));
                                tsproinfos.add(tsproinfoA);
                            }

                            if (tsproinfos.size() > 0)
                                tsproinfo.setTsproInfoList(tsproinfos);

                            programItem.get(i).add(k + 1, tsproinfo);
                            fileName.removeAll(fildName.get(j).getReworkingIdList());
                            fileName.addAll(fildName.get(j).getReworkingIdList());
                            fildName.remove(j);
                            j--;
                            break;
                        }
                    }
                }
            }

            for (int j = 0; j < minVersionNotFound.size(); j++){
                if (String.valueOf(minVersionNotFound.get(j).get("proname")).trim().equals(programItem.get(i).get(0).getProname().trim())){
                    if (!IsContainChinese(String.valueOf(minVersionNotFound.get(j).get("minprover")).trim())){
                        tsproinfo tsproinfo = new tsproinfo();
                        tsproinfo.setProname(String.valueOf(minVersionNotFound.get(j).get("proname")).trim());
                        tsproinfo.setProver(String.valueOf(minVersionNotFound.get(j).get("minprover")).trim());
                        programItem.get(i).add(tsproinfo);
                    }
                }
            }
        }

        if (!fildNameEmpty){

            ArrayList<tsproinfo> tsproinfos = new ArrayList<>();

            tsproinfo tsproinfo = new tsproinfo();
            tsproinfo.setProname(fildName.get(0).getPronameA().trim());
            tsproinfo.setProver(fildName.get(0).getProverA().trim());
            ArrayList<String> arrayList = fildName.get(0).getReworkingIdList();
            tsproinfo.setReworkingId(arrayList.get(0));
            ArrayList<tsproinfo> tsproinfoArrayList = new ArrayList<>();
            for (int i = 1; i < arrayList.size(); i++){
                tsproinfo tsproinfoA = new tsproinfo();
                tsproinfoA.setProver(fildName.get(0).getProverA().trim());
                tsproinfoA.setProname(fildName.get(0).getPronameA().trim());
                tsproinfoA.setReworkingId(arrayList.get(i));
                tsproinfoArrayList.add(tsproinfoA);
            }

            if (tsproinfoArrayList.size() > 0){
                tsproinfo.setTsproInfoList(tsproinfoArrayList);
            }
            tsproinfos.add(tsproinfo);

            for (int i = 1; i < fildName.size(); i++){
                if (!fildName.get(i).getPronameA().trim().equals(fildName.get(i - 1).getPronameA().trim())){
                    programItem.add(tsproinfos);
                    tsproinfos = new ArrayList<>();
                }
                tsproinfo = new tsproinfo();
                tsproinfo.setProname(fildName.get(i).getPronameA().trim());
                tsproinfo.setProver(fildName.get(i).getProverA().trim());
                arrayList = fildName.get(i).getReworkingIdList();
                tsproinfo.setReworkingId(arrayList.get(0));
                tsproinfoArrayList = new ArrayList<>();

                for (int j = 1; j < arrayList.size(); j++){
                    tsproinfo tsproinfoA = new tsproinfo();
                    tsproinfoA.setProver(fildName.get(i).getProverA().trim());
                    tsproinfoA.setProname(fildName.get(i).getPronameA().trim());
                    tsproinfoA.setReworkingId(arrayList.get(j));
                    tsproinfoArrayList.add(tsproinfoA);
                }

                if (tsproinfoArrayList.size() > 0){
                    tsproinfo.setTsproInfoList(tsproinfoArrayList);
                }
                tsproinfos.add(tsproinfo);

            }
            programItem.add(tsproinfos);
        }

        //  截取基于版本的信息
        versionNum = versionNum.toUpperCase();

        String productName = versionNum.substring(0, versionNum.indexOf("V") + 7);

        String incrementNum = versionNum.substring(versionNum.indexOf("V") + 8, versionNum.lastIndexOf("."));
        int incrementNumber = Integer.parseInt(incrementNum);

        String patchNum = versionNum.substring(versionNum.lastIndexOf(".") + 1, versionNum.length());
        patchNum = patchNum.replaceAll("[\u4e00-\u9fa5]", "");
        int patchNumber = Integer.parseInt(patchNum);

        //  查询由于中间版本未找到的程序项而加入的修改单
        Map map = scanOutParam(fileName, productName, incrementNumber, patchNumber);

        //  获取查询信息
        ArrayList<ArrayList<tsproinfo>> programItemA = (ArrayList<ArrayList<tsproinfo>>) map.get("programItem");

        ArrayList<tsproinfoout> fildNameA = (ArrayList<tsproinfoout>) map.get("fildName");

        ArrayList<tsproinfo> minVersionNotFoundA = (ArrayList<tsproinfo>) map.get("minVersionNotFound");

        //  遍历程序项列表，不存在的程序项加入，存在的程序项比较版本
        for (int a = 0; a < programItemA.size(); a++) {

            boolean aaa = false;

            for (int b = 0; b < programItem.size(); b++) {

                if (programItem.get(b).get(0).getProname().trim().equals(programItemA.get(a).get(0).getProname().trim())) {

                    String prover = programItem.get(b).get(0).getProver().trim();
                    String proverA = programItemA.get(a).get(0).getProver().trim();

                    int p1 = Integer.parseInt(prover.substring(prover.lastIndexOf(".") + 1));
                    int p2 = Integer.parseInt(proverA.substring(proverA.lastIndexOf(".") + 1));

                    //  同名程序项，新程序项版本 > 旧版本程序项 ，将新程序项从最新版本获取，插入到旧版本程序项对应位置
                    if (p1 < p2) {
                        for (int x = 0; x < programItemA.get(a).size(); x++) {

                            proverA = programItemA.get(a).get(x).getProver().trim();
                            p2 = Integer.parseInt(proverA.substring(proverA.lastIndexOf(".") + 1));

                            if (p2 > p1) {
                                programItem.get(b).add(x, programItemA.get(a).get(x));
                                continue;
                            }

                            break;
                        }
                    }
                    aaa = true;
                }
            }

            //未找到同名程序项，将程序项加入至旧程序项列表尾部
            if (aaa == false) {
                programItem.add(programItemA.get(a));
            }

        }

        if (fildNameA != null && fildNameA.size() != 0){

            for (int a = 0; a < fildName.size(); a++){

                for (int b = 0; b < fildNameA.size(); b++){

                    //  因以加入此程序项，中间版本的程序项已加入，删除对应的失败程序项
                    if (fildName.get(a).getPronameA().trim().equals(fildNameA.get(b).getPronameA().trim())){

                        if (fildName.get(a).getProverA().trim().equals(fildNameA.get(b).getProverA().trim())){

                            fildNameA.remove(b);

                        }

                    }

                }
            }

        }

        //  处理查询后的未找到最低版本的程序项
        if (minVersionNotFoundA != null && minVersionNotFoundA.size() != 0){

            for (int a=0;a<minVersionNotFound.size();a++){

                for (int b=0;b<minVersionNotFoundA.size();b++){

                    //  因以加入此程序项，最低版本的程序项已加入，删除对应的失败程序项
                    if (String.valueOf(minVersionNotFound.get(a).get("proname")).trim().equals(String.valueOf(minVersionNotFoundA.get(b).getProname()).trim())){

                        minVersionNotFoundA.remove(b);

                    }
                }
            }
        }

        // 引入程序项中添加 新的查询修改单
        citeFrom.removeAll(fileName);
        citeFrom.addAll(fileName);

        ArrayList citeFromA = (ArrayList) map.get("citeFrom");

        //  引入程序项中添加 新的查询所引入的修改单
        citeFrom.removeAll(citeFromA);
        citeFrom.addAll(citeFromA);
        citeFrom.remove("*");

        citeFrom.removeAll(modificationList);
        Map mapA = new HashMap();

        /*
                返回结果集合：
                citeForm：引入修改单
                fildNameA：中间版本未找到的程序项A
                programItem ： 程序项列表
                minVersionNotFoundA ：最低版本未找到的程序项
         */
        mapA.put("programItem", programItem);
        mapA.put("fildName", fildNameA);
        mapA.put("citeFrom", citeFrom);
        mapA.put("minVersionNotFound", minVersionNotFoundA);

        return mapA;
    }

    //  处理新添加的最低版本，如果出现汉字的处理方式，有汉字返回 true  ，无汉字返回  false
    public static boolean IsContainChinese (String str){
        boolean bflag = false;
        if (str == null) {
            return bflag;
        }
        char[] c = str.toCharArray();
        for (int i = 0; i < c.length; i++) {
            if (c[i] >= 0x4E00 && c[i] <= 0x29FA5) {
                bflag = true;
                return bflag;// 有一个中文字符就返回
            }
        }
        return bflag;
    }


    public HttpServletResponse saveFinalData(ArrayList<ArrayList<tsproinfo>> programItem, String distributedObject, String baseOnPatch, ArrayList finalModificationList, ArrayList<MoificationNotTest> moificationNotTest, HttpServletResponse response){

        //创建工作薄对象
        XSSFWorkbook workbook=new XSSFWorkbook();

        //创建sheet1工作表对象,存储  程序项名-程序项版本-所属修改单
        XSSFSheet sheet1 = workbook.createSheet("sheet1");

        int max = 0;
        for (int i = 0;i<programItem.size();i++) {
            XSSFRow row = sheet1.createRow(i);
            row.createCell(0).setCellValue(String.valueOf(programItem.get(i).get(0).getProname()).trim());
            row.createCell(1).setCellValue(String.valueOf(programItem.get(i).get(0).getProver()).trim());
            row.createCell(2).setCellValue(String.valueOf(programItem.get(i).get(0).getReworkingId()).trim());
        }
        workbook.setSheetName(0,"sheet1");



        //创建sheet2工作表对象,存储  所有最终引入修改单
        XSSFSheet sheet2 = workbook.createSheet("sheet2");

        max = 0;
        XSSFRow row1 = sheet2.createRow(0);
        row1.createCell(0).setCellValue("主修改单");
        row1.createCell(1).setCellValue("发放说明的修改单");
        for (int i = 0;i<finalModificationList.size();i++){
            XSSFRow row = sheet2.createRow(i+1);
            row.createCell(0).setCellValue(String.valueOf(finalModificationList.get(i)).trim());
        }

        XSSFRow row = sheet2.createRow(finalModificationList.size()+4);
        row.createCell(0).setCellValue("发放对象：" + distributedObject);
        row = sheet2.createRow(finalModificationList.size()+5);
        row.createCell(0).setCellValue("基于补丁" + baseOnPatch);

        workbook.setSheetName(1,"sheet2");



        //创建sheet3工作表对象,存储  引入   可以不用测试的程序项-备注信息
        XSSFSheet sheet3 = workbook.createSheet("sheet3");

        max = 0;
        row1 = sheet3.createRow(0);
        row1.createCell(0).setCellValue("引入修改单");
        row1.createCell(1).setCellValue("是否必须测完");
        row1.createCell(2).setCellValue("备注");
        for (int i = 0;i<moificationNotTest.size();i++){
            row = sheet3.createRow(i+1);
            row.createCell(0).setCellValue(moificationNotTest.get(i).getReworkingId().trim());
            row.createCell(1).setCellValue("否");
            row.createCell(2).setCellValue((String) moificationNotTest.get(i).getRemark().trim());
        }

        workbook.setSheetName(2,"sheet3");


        //创建sheet4工作表对象,存储  补丁包信息： 产品简称-年份-基线-增量-补丁-分支-用户测试
        XSSFSheet sheet4 = workbook.createSheet("sheet4");
        row = sheet4.createRow(0);
        row.createCell(0).setCellValue("产品简称");
        row.createCell(1).setCellValue(baseOnPatch.substring(0,baseOnPatch.indexOf("V")).trim());

        row = sheet4.createRow(1);
        row.createCell(0).setCellValue("年份");
        row.createCell(1).setCellValue(baseOnPatch.substring(baseOnPatch.indexOf("V")+1,baseOnPatch.indexOf("V")+5).trim());

        row = sheet4.createRow(2);
        row.createCell(0).setCellValue("基线");
        row.createCell(1).setCellValue(baseOnPatch.substring(baseOnPatch.indexOf("V")+5,baseOnPatch.indexOf("V")+7).trim());

        row = sheet4.createRow(3);
        row.createCell(0).setCellValue("增量");
        row.createCell(1).setCellValue(baseOnPatch.substring(baseOnPatch.indexOf(".",15)+1,baseOnPatch.lastIndexOf(".")).trim());

        row = sheet4.createRow(4);
        row.createCell(0).setCellValue("补丁");
        row.createCell(1).setCellValue(baseOnPatch.substring(baseOnPatch.lastIndexOf(".")+1).replaceAll("[\u4e00-\u9fa5]", "").trim());

        row = sheet4.createRow(5);
        row.createCell(0).setCellValue("分支");
        row.createCell(2).setCellValue("有1000就加A");

        row = sheet4.createRow(6);
        row.createCell(0).setCellValue("用户测试");
        row.createCell(1).setCellValue("否");

        workbook.setSheetName(3,"sheet4");


        OutputStream output;
        try {
            output = response.getOutputStream();
            //清空缓存
            response.reset();

            //  修改基于版本的结果，作为文件名输出
            baseOnPatch = baseOnPatch.replaceAll("[\u4e00-\u9fa5]", "");
            baseOnPatch = baseOnPatch.replaceAll("\\.","-");

            int patchNum = Integer.parseInt(baseOnPatch.substring(baseOnPatch.lastIndexOf("-")+1))+1;

            baseOnPatch = baseOnPatch.substring(0,baseOnPatch.lastIndexOf("-")+1);

            if (patchNum >= 100){
                baseOnPatch = baseOnPatch + String.valueOf(patchNum);
            }else if (patchNum >= 10){
                baseOnPatch = baseOnPatch + "0" + String.valueOf(patchNum);
            }else {
                baseOnPatch = baseOnPatch + "00" + String.valueOf(patchNum);
            }

            baseOnPatch = baseOnPatch.replace("-","");

            // 清空response
            response.reset();
            //定义浏览器响应表头，顺带定义下载名
            response.setHeader("Content-disposition", "attachment;filename=" + new String(baseOnPatch.getBytes(), "iso-8859-1") + ".xlsx");
            response.addHeader("Access-Control-Allow-Origin", "*");
            //定义下载的类型，标明是excel文件
            response.setContentType("application/vnd.ms-excel");
            //这时候把创建好的excel写入到输出流
            workbook.write(output);
            //养成好习惯，出门记得随手关门
            output.close();
            return response;
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }

    /**
     * 将programItem暂时存储至数据库
     *
     * @param userID
     * @param submitTime
     * @param programItem
     * @param userID
     * @param submitTime
     * @param programItem
     * @param moificationNotTest
     * @return
     */
    public boolean saveTempDate(String userID, String submitTime,
                                ArrayList<ArrayList<tsproinfo>> programItem,
                                String distributedObject, String baseOnPatch,
                                ArrayList<String> finalModificationList,
                                ArrayList<MoificationNotTest> moificationNotTest,
                                ArrayList<String> introduceNotManifest,
                                ArrayList<String> initModificationList,
                                ArrayList<String> deleteGroup,
                                ArrayList<TableData> tableData,
                                ArrayList<VersionColor> versionColor,
                                ArrayList<String> citeFrom) {


        String PII = "PII" + userID + submitTime;
        String FMI = "FMI" + userID + submitTime;
        String MNTI = "MNTI" + userID + submitTime;
        String INMI = "INMI" + userID + submitTime;
        String IMFL = "IMFL" + userID + submitTime;
        String DG = "DG" + userID + submitTime;
        String TD = "TD" + userID + submitTime;
        String VC = "VC" + userID + submitTime;
        String CF = "CF" + userID + submitTime;

        int basicSuccess = tsBasicTempMapper.insertTsBasicTemp(new TsBasicTemp(userID, submitTime, baseOnPatch, distributedObject));

        if (basicSuccess <= 0){
            System.out.println("插入临时总表失败");
            return false;
        }
//        将programItem插入子表
        int arrayNo = 0;
        for (ArrayList<tsproinfo> tsproinfos : programItem){
            for (tsproinfo tsproinfo : tsproinfos) {

                if (tsproinfo.getTsproInfoList() != null) {
                    // 若programItem有TsproInfoList，那么存储是将其标注为二级Item，flag为1
                    for (tsproinfo tsproinfo2 : tsproinfo.getTsproInfoList()){
                        if (tsproinfo2.getReworkingId() == null){
                            tsproinfo2.setReworkingId("");
                        }
                        int SubSuccess = tsSubTempMapper.insertTsSubTemp(new TsSubTemp(PII,  tsproinfo2.getProname().trim(), tsproinfo2.getProver().trim(), tsproinfo2.getReworkingId().trim(),"1", "", 0, "", " ".charAt(0), " ".charAt(0), "", arrayNo));
                        if (SubSuccess <= 0) {
                            System.out.println("插入临时子表失败");
                            return false;
                        }
                    }
                }
                // 将以及Item存入tsProInfoTempList，Flag为0
                if (tsproinfo.getReworkingId() == null){
                    tsproinfo.setReworkingId("");
                }
                int SubSuccess = tsSubTempMapper.insertTsSubTemp(new TsSubTemp(PII, tsproinfo.getProname().trim(), tsproinfo.getProver().trim(), tsproinfo.getReworkingId().trim(),"0", "", 0, "", " ".charAt(0), " ".charAt(0), "", arrayNo));
                if (SubSuccess <= 0) {
                    System.out.println("插入临时子表失败");
                    return false;
                }
            }
            arrayNo++;
        }

//        将finalModificationList插入子表
        arrayNo = 0;
        for (String reworkingId : finalModificationList){
            int SubSuccess = tsSubTempMapper.insertTsSubTemp(new TsSubTemp(FMI, "", "", reworkingId.trim(),"", "",0, "", " ".charAt(0), " ".charAt(0), "", arrayNo));
            if (SubSuccess <= 0) {
                System.out.println("插入临时子表失败");
                return false;
            }
            arrayNo++;
        }

//        将moificationNotTest插入子表
        arrayNo = 0;
        for (MoificationNotTest mnt : moificationNotTest){
            int SubSuccess = tsSubTempMapper.insertTsSubTemp(new TsSubTemp(MNTI, "", "", mnt.getReworkingId().trim(),"", mnt.getRemark().trim(), 0, "", " ".charAt(0), " ".charAt(0), "", arrayNo));
            if (SubSuccess <= 0) {
                System.out.println("插入临时子表失败");
                return false;
            }
            arrayNo++;
        }

//        将introduceNotManifest 插入子表
        arrayNo = 0;
        for (String reworkingId : introduceNotManifest){
            int SubSuccess = tsSubTempMapper.insertTsSubTemp(new TsSubTemp(INMI, "", "", reworkingId.trim(),"", "", 0, "", " ".charAt(0), " ".charAt(0), "", arrayNo));
            if (SubSuccess <= 0) {
                System.out.println("插入临时子表失败");
                return false;
            }
            arrayNo++;
        }

//        将initModificationList插入子表
        arrayNo = 0;
        for (String reworkingId : initModificationList){
            int SubSuccess = tsSubTempMapper.insertTsSubTemp(new TsSubTemp(IMFL, "", "", reworkingId.trim(), "", "", 0, "", " ".charAt(0), " ".charAt(0), "", arrayNo));
            if (SubSuccess <= 0) {
                System.out.println("插入临时子表失败");
                return false;
            }
            arrayNo++;
        }

//        将deleteGroup 插入子表
        arrayNo = 0;
        for (String reworkingId : deleteGroup){
            int SubSuccess = tsSubTempMapper.insertTsSubTemp(new TsSubTemp(DG, "", "", reworkingId.trim(), "", "", 0, "", " ".charAt(0), " ".charAt(0), "", arrayNo));
            if (SubSuccess <= 0) {
                System.out.println("插入临时子表失败");
                return false;
            }
            arrayNo++;
        }

//        将citeForm插入子表
        arrayNo = 0;
        for (String reworkingId : citeFrom){
            int SubSuccess = tsSubTempMapper.insertTsSubTemp(new TsSubTemp(CF, "", "", reworkingId.trim(), "", "", 0, "", " ".charAt(0), " ".charAt(0), "", arrayNo));
            if (SubSuccess <= 0) {
                System.out.println("插入临时子表失败");
                return false;
            }
            arrayNo++;
        }

//        将tableData插入子表
        arrayNo = 0;
        for (TableData td : tableData){
            if (tsSubTempMapper.insertTsSubTemp(new TsSubTemp(TD, td.getProname().trim(), td.getLastversion().trim(), "", "0", "", td.getMidVersionLength(), "", " ".charAt(0), " ".charAt(0), "", arrayNo)) <= 0){
                System.out.println("插入临时子表失败");
                return false;
            }

            for (int i = 0; i < td.getReworkingIdList().size(); i++){
                if (tsSubTempMapper.insertTsSubTemp(new TsSubTemp(TD, td.getProname().trim(), td.getVersionList().get(i).trim(), td.getReworkingIdList().get(i).trim(), "", "", 0, String.valueOf(i).trim(), " ".charAt(0), " ".charAt(0), "", arrayNo)) <= 0) {
                    System.out.println("插入临时子表失败");
                    return false;
                }
                if (!(td.getTsproInfoList() == null || td.getTsproInfoList().isEmpty())){
                    for (int j = 0; j < td.getTsproInfoList().get(i).size(); j++){
                        if (tsSubTempMapper.insertTsSubTemp(new TsSubTemp(TD, td.getTsproInfoList().get(i).get(j).getProname() == null ? "":td.getTsproInfoList().get(i).get(j).getProname().trim(),
                                td.getTsproInfoList().get(i).get(j).getProver() == null ? "":td.getTsproInfoList().get(i).get(j).getProver().trim(),
                                td.getTsproInfoList().get(i).get(j).getReworkingId() == null ? "":td.getTsproInfoList().get(i).get(j).getReworkingId().trim(),
                                "1", "", 0, String.valueOf(i), " ".charAt(0), " ".charAt(0), "", arrayNo)) <= 0) {
                            System.out.println("插入临时子表失败");
                            return false;
                        }
                    }
                }
            }
            arrayNo++;
        }


//        将versionColor 插入子表
        arrayNo = 0;
        for (VersionColor vc : versionColor){
            for (int i = 0; i < vc.getConfirmList().size(); i++){
                if (tsSubTempMapper.insertTsSubTemp(new TsSubTemp(VC, "", "", "", "", "", 0, String.valueOf(i).trim(), vc.getConfirmList().get(i), vc.getSelfconfirmList().get(i), vc.getStateList().get(i), arrayNo)) <= 0){
                    System.out.println("插入临时子表失败");
                    return false;
                }
            }
            arrayNo++;
        }

        return true;

    }

    public Map<String, Object> getTempData(String userID, String submitTime) {

        Map<String, Object> result = new HashMap<>();

        String PII = "PII" + userID + submitTime;
        String FMI = "FMI" + userID + submitTime;
        String MNTI = "MNTI" + userID + submitTime;
        String INMI = "INMI" + userID + submitTime;
        String IMFL = "IMFL" + userID + submitTime;
        String DG = "DG" + userID + submitTime;
        String TD = "TD" + userID + submitTime;
        String VC = "VC" + userID + submitTime;
        String CF = "CF" + userID + submitTime;

        TsBasicTemp tsBasicTemp = tsBasicTempMapper.selectTsBasicTempByIDAndTime(userID, submitTime).get(0);

        // 安装userID
        result.put("userID", userID);

        // 组装programItem
        List<TsSubTemp> tsPIIList = tsSubTempMapper.selectTsproinfoByPII(PII);
        List<String> proNameList = new LinkedList<>();
        for (TsSubTemp t : tsPIIList){
            if (!proNameList.contains(t.getProName().trim())){
                proNameList.add(t.getProName().trim());
            }
        }

        ArrayList<ArrayList<tsproinfo>> content = new ArrayList<>(proNameList.size());

        for (String proName : proNameList){
            ArrayList<tsproinfo> newArrayTsProInfo = new ArrayList<>();
            List<TsSubTemp> tsPIIProNameList = tsSubTempMapper.selectByPIIAndProName(PII, proName.trim());
            ArrayList<tsproinfo> tsSubProInfoList = new ArrayList<>();
            for (TsSubTemp ts : tsPIIProNameList){
                if ("1".equals(ts.getFlag())){
                    tsproinfo proInfo = new tsproinfo(ts.getProName() == null ? "" : ts.getProName().trim(), ts.getProver() == null ? "" : ts.getProver().trim(), ts.getReworkingId() == null ? "":ts.getReworkingId().trim(), null);
                    tsSubProInfoList.add(proInfo);
                } else {
                    if (tsSubProInfoList.size() == 0){
                        tsSubProInfoList = null;
                    }
                    tsproinfo basic = new tsproinfo(ts.getProName() == null ? "" : ts.getProName().trim(), ts.getProver() == null ? "" : ts.getProver().trim(), ts.getReworkingId() == null ? "":ts.getReworkingId().trim(), tsSubProInfoList);
                    newArrayTsProInfo.add(basic);
                    tsSubProInfoList = new ArrayList<>();
                }
            }
            content.add(newArrayTsProInfo);
        }
        result.put("programItem", content);
        // 组装baseOnPatch，distributedObject
        result.put("baseOnPatch", tsBasicTemp.getBaseOnPatch());
        result.put("distributedObject", tsBasicTemp.getDistributedObject());

        //组装finalModificationList
        List<String> finalModificationList = tsSubTempMapper.selectTsproinfoByFMI(FMI);
        result.put("finalModificationList", finalModificationList);

        List<String> initModificationList = tsSubTempMapper.selectTsproinfoByIMFL(IMFL);
        result.put("initModificationList", initModificationList);

        List<String> deleteGroup = tsSubTempMapper.selectTsproinfoByDG(DG);
        result.put("deleteGroup", deleteGroup);

        // 组装tableData
        List<Map<String, Object>> tableData = new ArrayList<>();
        int TDArrayNum = tsSubTempMapper.selectTsproinfoByTD(TD);
        for (int i = 0; i <= TDArrayNum; i++){
            Map<String, Object> tableDataMap = new HashMap<>();
            TsSubTemp tableDataFirst = tsSubTempMapper.selectTsproinfoFirstByTD(TD, i).get(0);
            tableDataMap.put("lastversion", tableDataFirst.getProver() == null ? "": tableDataFirst.getProver().trim());
            tableDataMap.put("midVersionLength", tableDataFirst.getMidVersionLength());
            tableDataMap.put("proname", tableDataFirst.getProName().trim());

            // 组装tableData的reworkingId、version
            List<TsSubTemp> reveTableData = tsSubTempMapper.selectTsproinfoSecondByTD(TD, i);
            for (int j = 0; j < reveTableData.size(); j++){
                tableDataMap.put("reworkingId" + j, reveTableData.get(j).getReworkingId().trim());
                tableDataMap.put("version" + j, reveTableData.get(j).getProver().trim());
            }

            // 组装tableData的tsproInfoList
            List<TsSubTemp> tsTableData = tsSubTempMapper.selectTsproinfoThridByTD(TD, i, "1");
            List<tsproinfo> tsproinfoList = new ArrayList<>();
            int sx_order = 0;
            for (TsSubTemp tsTableDatum : tsTableData) {
                if (Integer.parseInt(tsTableDatum.getSxOrder()) != sx_order) {
                    tableDataMap.put("tsproInfoList" + sx_order, tsproinfoList);
                    sx_order++;
                    tsproinfoList = new ArrayList<>();
                }
                tsproinfo tsproinfo = new tsproinfo(tsTableDatum.getProName() == null ? "" : tsTableDatum.getProName().trim(), tsTableDatum.getProver() == null ? "" : tsTableDatum.getProver().trim(), tsTableDatum.getReworkingId() == null ? "" : tsTableDatum.getReworkingId().trim(), null);
                tsproinfoList.add(tsproinfo);

                tableDataMap.put("tsproInfoList" + sx_order, tsproinfoList);
            }

            tableData.add(tableDataMap);
        }

        result.put("tableData", tableData);

//        组装versionColor
        List<Map<String, Object>> versionColor = new ArrayList<>();
        int VCArrayNum = tsSubTempMapper.selectTsproinfoNumByVC(VC);
        for (int i = 0; i <= VCArrayNum; i++){
            Map<String, Object> versionColorMap = new HashMap<>();
            List<TsSubTemp> versionColorList = tsSubTempMapper.selectTsproinfoByVC(VC, i);
            for (int j = 0; j < versionColorList.size(); j++){
                boolean bConfirm = true;
                if (versionColorList.get(j).getConfirm() == '0') {
                    bConfirm = false;
                }
                versionColorMap.put("confirm" + j, bConfirm);
                boolean bSelfconfirm = true;
                if (versionColorList.get(j).getSelfconfirm() == '0'){
                    bSelfconfirm = false;
                }
                versionColorMap.put("selfconfirm" + j, bSelfconfirm);
                versionColorMap.put("state" + j, versionColorList.get(j).getState());
            }
            versionColor.add(versionColorMap);
        }

        result.put("versionColor", versionColor);

//        组装moificationNotTest
        ArrayList<MoificationNotTest> moificationNotTest = new ArrayList<>();
        List<TsSubTemp> tsMNTIList = tsSubTempMapper.selectTsproinfoByMNTI(MNTI);
        for (TsSubTemp ts : tsMNTIList){
            MoificationNotTest mNT = new MoificationNotTest(ts.getReworkingId().trim(), ts.getRemark().trim());

            moificationNotTest.add(mNT);
        }
        result.put("moificationNotTest", moificationNotTest);

        List<String> introduceNotManifest = tsSubTempMapper.selectTsproinfoByINMI(INMI);
        result.put("introduceNotManifest", introduceNotManifest);

        List<String> citeForm = tsSubTempMapper.selectTsproinfoByCF(CF);
        result.put("citeForm", citeForm);

        return result;
    }

    public List<TsBasicTemp> getTsBasicTemp(String userID) {

        return tsBasicTempMapper.selectTsBasicTempByID(userID);
    }

    public boolean deleteTempData(String userID, String submitTime) {

        int b1 = tsBasicTempMapper.deleteTsBasicTempByIdAndTime(userID, submitTime);

        String PII = "PII" + userID + submitTime;
        String FMI = "FMI" + userID + submitTime;
        String MNTI = "MNTI" + userID + submitTime;
        String INMI = "INMI" + userID + submitTime;
        String IMFL = "IMFL" + userID + submitTime;
        String DG = "DG" + userID + submitTime;
        String TD = "TD" + userID + submitTime;
        String VC = "VC" + userID + submitTime;
        String CF = "CF" + userID + submitTime;

        int b2 = tsSubTempMapper.deleteByIdAndTime(PII, FMI, MNTI, INMI, IMFL, DG, TD, VC, CF);

        if (b1 + b2 > 0){
            return true;
        } else {
            return false;
        }
    }

    public List<TsBasicTemp> selectBasicById(String userID) {

        return tsBasicTempMapper.selectTsBasicTempByID(userID);

    }


    public List<TsBasicTemp> selectBasicByIdAndTime(String userID, String submitTime) {

        return tsBasicTempMapper.selectTsBasicTempByIDAndTime(userID, submitTime);
    }
}
