package com.hundsun.scanModificationList.entity;

/**
 * @Author: kcaumber
 * @Date: 9/26/21 5:41 PM
 */
public class TsBasicTemp {

    private String userID;
    private String submitTime;
    private String baseOnPatch;
    private String distributedObject;

    public TsBasicTemp() {
    }

    public TsBasicTemp(String userID, String submitTime, String baseOnPatch, String distributedObject) {
        this.userID = userID;
        this.submitTime = submitTime;
        this.baseOnPatch = baseOnPatch;
        this.distributedObject = distributedObject;
    }

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public String getSubmitTime() {
        return submitTime;
    }

    public void setSubmitTime(String submitTime) {
        this.submitTime = submitTime;
    }

    public String getBaseOnPatch() {
        return baseOnPatch;
    }

    public void setBaseOnPatch(String baseOnPatch) {
        this.baseOnPatch = baseOnPatch;
    }

    public String getDistributedObject() {
        return distributedObject;
    }

    public void setDistributedObject(String distributedObject) {
        this.distributedObject = distributedObject;
    }

    @Override
    public String toString() {
        return "TsBasicTemp{" +
                "userID='" + userID + '\'' +
                ", submitTime='" + submitTime + '\'' +
                ", baseOnPatch='" + baseOnPatch + '\'' +
                ", distributedObject='" + distributedObject + '\'' +
                '}';
    }
}
