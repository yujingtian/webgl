package com.hundsun.scanModificationList.entity;

public class MoificationNotTest {

    private String reworkingId;

    private String remark;

    public MoificationNotTest() {
    }

    public MoificationNotTest(String reworkingId, String remark) {
        this.reworkingId = reworkingId;
        this.remark = remark;
    }

    public String getReworkingId() {
        return reworkingId;
    }

    public void setReworkingId(String reworkingId) {
        this.reworkingId = reworkingId;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }
}
