package com.hundsun.scanModificationList.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import lombok.Data;

import java.util.ArrayList;

@Data
public class tsproinfo {


    private String proname;

    private String prover;

    private String reworkingId;

    @TableField(exist = false)
    private ArrayList<tsproinfo> tsproInfoList;

    public tsproinfo() {
    }

    public tsproinfo(String proname, String prover, String reworkingId, ArrayList<tsproinfo> tsproInfoList) {
        this.proname = proname;
        this.prover = prover;
        this.reworkingId = reworkingId;
        this.tsproInfoList = tsproInfoList;
    }

    public String getReworkingId() {
        return reworkingId;
    }

    public void setReworkingId(String reworkingId) {
        this.reworkingId = reworkingId;
    }

    public String getProname() {
        return proname;
    }

    public void setProname(String proname) {
        this.proname = proname;
    }

    public String getProver() {
        return prover;
    }

    public void setProver(String prover) {
        this.prover = prover;
    }

    public ArrayList<tsproinfo> getTsproInfoList() {
        return tsproInfoList;
    }

    public void setTsproInfoList(ArrayList<tsproinfo> tsproInfoList) {
        this.tsproInfoList = tsproInfoList;
    }
}
