package com.hundsun.scanModificationList.entity;

import lombok.Data;

@Data
public class tsprobagnamemanger {

    private String bagid;

    private String basename;

    private int bagadd;

    private int specialno;

    private String remark;

    private String clientId;

    private  char istest;

    private char ismain;

    public String getBagid() {
        return bagid;
    }

    public void setBagid(String bagid) {
        this.bagid = bagid;
    }

    public String getBasename() {
        return basename;
    }

    public void setBasename(String basename) {
        this.basename = basename;
    }

    public int getBagadd() {
        return bagadd;
    }

    public void setBagadd(int bagadd) {
        this.bagadd = bagadd;
    }

    public int getSpecialno() {
        return specialno;
    }

    public void setSpecialno(int specialno) {
        this.specialno = specialno;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public char getIstest() {
        return istest;
    }

    public void setIstest(char istest) {
        this.istest = istest;
    }

    public char getIsmain() {
        return ismain;
    }

    public void setIsmain(char ismain) {
        this.ismain = ismain;
    }
}
