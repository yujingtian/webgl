package com.hundsun.scanModificationList.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hundsun.scanModificationList.entity.tsproinfo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
@Repository("TSProInfoMapper")
public interface TSProInfoMapper extends BaseMapper<tsproinfo> {

    List<tsproinfo> selectReworkingId(@Param("prover") String prover, @Param("proName") String pName);

    List<tsproinfo> selectByReworkingId(String ReworkingId);

    List<tsproinfo> selectByPronameAndProver(String proname, String prover);
}
