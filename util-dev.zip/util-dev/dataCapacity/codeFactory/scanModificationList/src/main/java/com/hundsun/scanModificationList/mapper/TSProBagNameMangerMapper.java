package com.hundsun.scanModificationList.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hundsun.scanModificationList.entity.tsprobagnamemanger;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
@Repository("TSProBagNameMangerMapper")
public interface TSProBagNameMangerMapper {

    int selectIncrement(@Param("productName") String productName);

    int selectPatch(@Param("productName") String productName,@Param("incrementNumber") int incrementNumber);

    List<tsprobagnamemanger> selectByAllFactor(int incrementNumber, int patchNumber, String productName);

    List<tsprobagnamemanger> selectByIncreAndProdu(int incrementNumber, String productName);
}
