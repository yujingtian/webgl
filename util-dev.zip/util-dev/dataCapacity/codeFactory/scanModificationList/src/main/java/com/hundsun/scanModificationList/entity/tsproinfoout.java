package com.hundsun.scanModificationList.entity;

import lombok.Data;

import java.util.ArrayList;

@Data
public class tsproinfoout {

    private ArrayList<String> reworkingIdList;

    private String pronameA;

    private String proverA;


    public ArrayList<String> getReworkingIdList() {
        return reworkingIdList;
    }

    public void setReworkingIdList(ArrayList<String> reworkingIdList) {
        this.reworkingIdList = reworkingIdList;
    }

    public String getProverA() {
        return proverA;
    }

    public void setProverA(String proverA) {
        this.proverA = proverA;
    }

    public String getPronameA() {
        return pronameA;
    }

    public void setPronameA(String pronameA) {
        this.pronameA = pronameA;
    }
}
