package com.hundsun.scanModificationList.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hundsun.scanModificationList.entity.dctsprospecialprogramitem;
import com.hundsun.scanModificationList.entity.tsproinfo;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
@Repository("DCTSProSpecialProgramItemMapper")
public interface DCTSProSpecialProgramItemMapper{

    List<tsproinfo> selectByAllFactor(String reworkingId, String prover, String proname);
}
