# 本代码用来生成测试用例
import tools
import createData
import dataRuleFormat
from xml.dom import minidom


# 创建T3Admin测试用例
def CreateTestXml(hepIntefaceMap: map, sFunctionNo: str, saveFile: str):
    # 创建dom文档
    doc = minidom.Document()
    # 创建根节点
    testPacklist = doc.createElement('TEST_PACK')
    testNode = doc.createElement('Test')
    testPacklist.appendChild(testNode)

    if 'hsbroker.' not in sFunctionNo:
        if '.' in sFunctionNo:
            svrName = sFunctionNo[:sFunctionNo.find('.')]
            sFunctionNo = 'hsbroker.%s/v/%s' % (
                svrName, sFunctionNo[sFunctionNo.find('.') + 1:])
    print(hepIntefaceMap[sFunctionNo])
    if sFunctionNo in hepIntefaceMap:
        subNode = doc.createElement('sub')
        svrName = hepIntefaceMap[sFunctionNo]['svrName']
        sfunctionName = hepIntefaceMap[sFunctionNo]['functionName']
        service = 'hsbroker.' + svrName
        subNode.setAttribute(
            'id', svrName + '.' + sFunctionNo[sFunctionNo.rfind('/') + 1:])
        subNode.setAttribute('note', sfunctionName)
        testNode.appendChild(subNode)

        routeNode = doc.createElement('route')
        routeNode.setAttribute('shardingInfo', '{"cust_id":""}')
        routeNode.setAttribute('security', '')
        routeNode.setAttribute('group', '')
        routeNode.setAttribute('service', service)
        routeNode.setAttribute('version', '')
        subNode.appendChild(routeNode)

        inparamsNode = doc.createElement('inparams')
        inparamsNode.setAttribute('note', '')
        inparamsNode.setAttribute('type', 'obj')
        subNode.appendChild(inparamsNode)

        inFiledList = hepIntefaceMap[sFunctionNo]['inFiled']
        dataMap = {}
        for inFiledItem in inFiledList:
            sFiledName = str(inFiledItem['filedName']).lower()
            sFiledType = inFiledItem['filedDocType']
            sFiledDict = inFiledItem['dictEntry']
            if sFiledName == 'function_str':
                sFiledValue = svrName + '.' + sFunctionNo[sFunctionNo.
                                                          rfind('/') + 1:]
            elif 'DTO' in sFiledType:
                continue
            elif sFiledDict != '0' and sFiledDict.strip(
            ) != '' and sFiledName not in [
                    'prodtrustee_id_kind', 'acct_realoper_id_kind',
                    'contact_id_kind', 'relation_id_kind', 'control_id_kind',
                    'instrepr_id_kind', 'duty_id_kind', 'investadv_id_kind',
                    'investadv_rep_id_kind'
            ]:
                sFiledValue = str(createData.returnRandomDict(sFiledDict))
            else:
                sFiledValue = str(
                    createData.getFiledValue(sFiledName, sFiledType, 0))
            dataMap[sFiledName] = sFiledValue

        dataMap = dataRuleFormat.FormatDataForHS(dataMap)
        for sFiledName in dataMap:
            sFiledValue = dataMap[sFiledName]
            inNode = doc.createElement('in')
            inNode.setAttribute('name', sFiledName)
            inNode.setAttribute('value', sFiledValue)
            inparamsNode.appendChild(inNode)
    doc.appendChild(testPacklist)

    #写好之后，就需要保存文档了
    f = open(saveFile, 'w', encoding='utf-8')
    sXmlStr = str(doc.toprettyxml(encoding='UTF-8'), encoding='utf-8')
    sXmlStr = sXmlStr.replace('	', '  ').replace('&amp;', '&').replace(
        '"', "'").replace('&quot;', '"')
    f.write(sXmlStr)
    f.close()


if __name__ == "__main__":
    hepIntefaceMap = tools.LoadDict('hepInteface')
    CreateTestXml(hepIntefaceMap, 'act.postClientOpen',
                  'F:/hundsun/安装文件/T3admin/Debug/Test/数据能力接口.xml')
