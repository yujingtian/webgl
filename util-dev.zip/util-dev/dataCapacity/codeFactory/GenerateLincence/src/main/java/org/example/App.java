package org.example;

import com.hundsun.broker.base.biz.util.T3Sdk;

import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.Enumeration;

/**
 * Hello world!
 *
 */
public class App 
{

    /**
     * 加密参数，固定值
     */
    private static final String AUTH_ID_NO = "600570";

    /**
     * 认证类别：固定为1
     */
    private static final char AUTH_TYPE = '3';

    /**
     * 加密类别：AES
     */
    private static final char ENCODE_TYPE_AES = '0';

    public static void main(String[] args) throws SocketException {
        StringBuilder sb = new StringBuilder();
        Enumeration<NetworkInterface> allNetInterfaces = NetworkInterface.getNetworkInterfaces();
        byte[] mac = null;
        while (allNetInterfaces.hasMoreElements()) {
            NetworkInterface netInterface = allNetInterfaces.nextElement();
            if (netInterface.isLoopback() || netInterface.isVirtual() || netInterface.isPointToPoint() || !netInterface.isUp()) {
                continue;
            } else {
                mac = netInterface.getHardwareAddress();
                if (mac != null) {
                    for (int i = 0; i < mac.length; i++) {
                        sb.append(String.format("%02X%s", mac[i], (i < mac.length - 1) ? "-" : "\n"));
                    }
                }
            }
        }
        String macAdr = sb.toString();
        System.out.println(macAdr);
//        macAdr = "28-6E-E4-89-85-35";
        macAdr = "60-E3-2B-7B-D5-B8";
        String keyStr = macAdr.replace("-","").replace("\n","") + "20231231";

        String clearPassword = T3Sdk.encode(AUTH_ID_NO, AUTH_TYPE, ENCODE_TYPE_AES, keyStr);
        int i = 0;
        System.out.println(clearPassword);


//        System.out.println(T3Sdk.encode("admin", '3', '0', "admin@123456789"));
//        System.out.println(T3Sdk.encode("yangxl41671", '1', '0', "1"));
//        System.out.println(T3Sdk.encode("admin", '1', '1', "1"));

    }
}
