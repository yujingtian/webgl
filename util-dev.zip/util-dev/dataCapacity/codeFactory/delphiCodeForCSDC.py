# 本文件用来生成中登模拟器的delphi代码
import loadDoc
import os
import tools


# 查找ClasTestThread.pas的路径
def FindClasTestThread(sCodePath):
    for root, dirs, files in os.walk(sCodePath):
        for fileName in files:
            sFilePath = root + fileName
            if fileName == 'ClasTestThread.pas':
                return sFilePath


# 查找UFrmConfig.dfm的路径
def FindDFMUFrmConfig(sCodePath):
    for root, dirs, files in os.walk(sCodePath):
        for fileName in files:
            sFilePath = root + fileName
            if fileName == 'UFrmConfig.dfm':
                return sFilePath





# 处理创建应答结果DBF的代码
def CreateResultDbfCode(sAbbName, filedInfo, vIntefaceName):
    sCodes = '''\
function TCSRegSimRequestThread.Create%sDbf: string;
var
  FileName : string;
  Hour, Min, Sec, MSec : Word;
  lFieldList : TStringList;
begin
  DecodeTime(Now, Hour, Min, Sec, MSec);
  FileName := SubRepPath + 'CS' + Copy(GetGuid, 1, 5) + IntToStr(Hour) +
    IntToStr(Min)
    + IntToStr(Sec) + IntToStr(MSec) + '.dbf';
  lFieldList := TStringList.Create;
  try
''' % (sAbbName)
    for sFiledItem in filedInfo:
        sFiledName = sFiledItem['filedName']
        sFiledType = sFiledItem['filedType']
        if sFiledType == 'Character':
            sFiledType = 'C'
        sFiledLen = sFiledItem['filedLen']
        sFiledCName = sFiledItem['filedCName']
        sCodes = sCodes + "    lFieldList.Add('%s|%s|%s|0'); //%s\n" % (
            sFiledName, sFiledType, sFiledLen, sFiledCName)
    sCodes = sCodes + '''
    if CreateDBF(FileName, lFieldList) then
      Result := FileName
    else
      raise Exception.Create('创建%sDBF失败[' + FileName + ']');
  finally
    FreeAndNil(lFieldList);
  end;
end;
''' % (vIntefaceName)
    return sCodes


def CreateResultDo(sAbbName, filedInfo, vIntefaceName, intefaceMap):
    sCode = '''\
function TCSRegSimRequestThread.Do%(AbbName)s : Boolean;
var
  jgdm, clsm  : string; //结果代码，处理说明
  FileName : string;
  SubFile, ResponseDbf : THsdbf;
  ywlb : string;
  bFindYMT : Boolean;
  ywlsh :string;
  Ymth : string; //一码通账号，若SubFile的请求中该字段为空，则从zqlig.dbf中取
begin
  Result := False;
  if not ValidReqDbf then    //Req文件校验：请求主文件是否存在，并且有记录
  begin
    Result := True;
    Exit;
  end;

  SubFile := THsdbf.Create;
  ResponseDbf := THsdbf.Create;
  try
    //先生成子文件 然后添加rep 最后把req状态置为d
    FileName := Create%(AbbName)sDbf;   //创建回报子文件
    ResponseDbf.TableName := FileName;
    ResponseDbf.Open;
    SubFile.TableName := SubReqPath + SubFileName;
    SubFile.Exclusive := False;
    SubFile.Open;
    SubFile.First;
    while not SubFile.Eof do
    begin
      jgdm := FConfig.CSSDCLCode;
      if FConfig.CSSDCL and (FConfig.CSSDCLCode <> '0000') and (FConfig.IsCheckYwlb(CheckYwlb))then  //全局配置的结果代码检查
      begin
        clsm := GetFHXX(jgdm);
        ResponseDbf.Append;
        CopyDbf(SubFile, ResponseDbf);
        ResponseDbf.FieldByName('YWRQ').AsString := FConfig.CSywrq;     //业务日期，取配置的业务日期
        ResponseDbf.FieldByName('YWPZBS').AsString := FConfig.CSYWPZBS; //业务凭证报送标识
        ResponseDbf.FieldByName('JGDM').AsString := jgdm; //结果代码，取配置的返回标志
        ResponseDbf.FieldByName('JGSM').AsString := clsm; //结果说明，取配置的返回信息
        ResponseDbf.Post;
        
        ywlsh := SubFile.FieldByName('YWLSH').AsString ;  //业务流水号
        DoDealInfo(itError,StrtoIntdef(ywlsh,0),clsm);       //记录info型的日志
        DoLog(ltError, clsm);    
      end
      else
      begin
        jgdm := Treate%(AbbName)s(SubFile);   //业务字段检查
        if jgdm <> '0000' then
        begin
          clsm := GetFHXX(jgdm);
          ResponseDbf.Append;
          CopyDbf(SubFile, ResponseDbf);
          ResponseDbf.FieldByName('YWRQ').AsString := FConfig.CSywrq;     //业务日期，取配置的业务日期
          ResponseDbf.FieldByName('YWPZBS').AsString := FConfig.CSYWPZBS; //业务凭证报送标识
          ResponseDbf.FieldByName('JGDM').AsString := jgdm; //结果代码，取配置的返回标志
          ResponseDbf.FieldByName('JGSM').AsString := clsm; //结果说明，取配置的返回信息
          ResponseDbf.Post;
        
          ywlsh := SubFile.FieldByName('YWLSH').AsString ;  //业务流水号
          DoDealInfo(itError,StrtoIntdef(ywlsh,0),clsm);       //记录info型的日志
          DoLog(ltError, clsm);    
        end
        else
        begin
          ResponseDbf.Append;
          CopyDbf(SubFile, ResponseDbf);
          clsm := '%(intefaceName)s成功';
''' % {
        'AbbName': sAbbName,
        'intefaceName': vIntefaceName
    }

    sReqTitle = '消息接口 - ' + vIntefaceName
    if sReqTitle in intefaceMap:
        sReqFiledList = intefaceMap[sReqTitle]['filedInfo']
        sRepFiledList = intefaceMap['应答-' + vIntefaceName]['filedInfo']

        for sRepFiledItem in sRepFiledList:
            sRepFiledName = sRepFiledItem['filedName']
            isFind = False
            for sReqFiledItem in sReqFiledList:
                if sRepFiledName == sReqFiledItem['filedName']:
                    isFind = True
                    break
            if not isFind:
                if sRepFiledName == 'SBRQ':
                    sCode = sCode + "          ResponseDbf.FieldByName('SBRQ').AsString := IntToStr(DateToInt(Now)); //申报日期\n"
                elif sRepFiledName == 'YWRQ':
                    sCode = sCode + "          ResponseDbf.FieldByName('YWRQ').AsString := IntToStr(DateToInt(Now)); //业务日期\n"
                elif sRepFiledName == 'SLBH':
                    sCode = sCode + "          Inc(iSerialNo);"
                    sCode = sCode + "          ResponseDbf.FieldByName('SLBH').AsString := IntToStr(iSerialNo); //受理编号\n"
                elif sRepFiledName == 'GRZHBS':
                    sCode = sCode + "          ResponseDbf.FieldByName('GRZHBS').AsString := '03'; //过入账户标识\n"
                elif sRepFiledName == 'ZBXMBS':
                    sCode = sCode + "          ResponseDbf.FieldByName('ZBXMBS').AsString := '0'; //转板配发账户限买标识\n"
                elif sRepFiledName == 'ZDGXBS':
                    sCode = sCode + '''\
          if (SubFile.FieldByName('ZBLB').AsString = '01') then
          begin
            if (trim(SubFile.FieldByName('GRZQZH').AsString) = '') then
            begin
              ResponseDbf.FieldByName('ZDGXBS').AsString := ' '; //指定/托管关系标识
            end
            else
            begin
              ResponseDbf.FieldByName('ZDGXBS').AsString := '01'; //指定/托管关系标识
            end;
          end
          else if (SubFile.FieldByName('ZBLB').AsString = '02') then
          begin
            if (trim(SubFile.FieldByName('GRTGDY').AsString) = '') then
            begin
              ResponseDbf.FieldByName('ZDGXBS').AsString := ' '; //指定/托管关系标识
            end
            else
            begin
              ResponseDbf.FieldByName('ZDGXBS').AsString := '11'; //指定/托管关系标识
            end;
          end;
'''
                elif sRepFiledName == 'GRSYBS':
                    sCode = sCode + '''\
          if (SubFile.FieldByName('ZBLB').AsString = '01') then
          begin
            ResponseDbf.FieldByName('GRSYBS').AsString := ' '; //过入使用信息标识
          end
          else if (SubFile.FieldByName('ZBLB').AsString = '02') then
          begin
            if (trim(SubFile.FieldByName('GRTGDY').AsString) = '') then
            begin
              ResponseDbf.FieldByName('GRSYBS').AsString := ' '; //过入使用信息标识
            end
            else
            begin
              ResponseDbf.FieldByName('GRSYBS').AsString := '01'; //过入使用信息标识
            end;
          end;
'''
                elif sRepFiledName == 'JGDM':
                    sCode = sCode + "          ResponseDbf.FieldByName('JGDM').AsString := jgdm; //结果代码\n"
                elif sRepFiledName == 'JGSM':
                    sCode = sCode + "          ResponseDbf.FieldByName('JGSM').AsString := clsm; //结果说明\n"
                else:
                    sCode = sCode + "          ResponseDbf.FieldByName('%s').AsString := ' '; //%s\n" % (
                        sRepFiledName, sRepFiledItem['filedCName'])
        sCode = sCode + '''          ResponseDbf.Post;

        end;
      end;
      SubFile.Next;
    end;
    SubFile.Close;
    GenRepDbfRecord(jgdm, FileName, clsm);
    Result := True;
  finally
    FreeAndNil(ResponseDbf);
    FreeAndNil(SubFile);
  end;
end;
'''
    return sCode


def CreateSubTreate(conditionItem, sKeyName, sFiledInfo, sErrorCode,
                    sErrorMsg):
    sCodes = ''
    sTmpCode = ''
    if len(conditionItem) > 1:
        sCodes = sCodes + "  and (   "
        for vkeyname in conditionItem:
            sValueList = conditionItem[vkeyname]
            if len(sValueList) == 1:
                if sTmpCode.strip() != '':
                    sCodes = sCodes + '\n'
                sCodes = sCodes + '''  and (Trim(Treatedbf.FieldByName('%s').AsString) = '%s')''' % (
                    vkeyname, sValueList[0])
            else:
                sTmpCode = ''
                for sValue in sValueList:
                    sTmpCode = sTmpCode + "\n       or (Trim(Treatedbf.FieldByName('%s').AsString) = '%s')" % (
                        sKeyName, sValue)
                sTmpCode = '(' + sTmpCode[12:] + '\n       )'
                sCodes = sCodes + sTmpCode

        sCodes = sCodes + ''' then   //%s
    begin
    Result := '%s';     //%s
    exit;
    end;
''' % (sFiledInfo, sErrorCode, sErrorMsg)
    else:
        sValueList = conditionItem[sKeyName]
        if len(sValueList) == 1:
            sCodes = sCodes + '''\
    and (Trim(Treatedbf.FieldByName('%s').AsString) = '%s') then   //%s
    begin
    Result := '%s';     //%s
    exit;
    end;
''' % (sKeyName, sValueList[0], sFiledInfo, sErrorCode, sErrorMsg)
        else:
            sTmpCode = ''
            sCodes = sCodes + "  and (   "
            for sValue in sValueList:
                sTmpCode = sTmpCode + "\n       or (Trim(Treatedbf.FieldByName('%s').AsString) = '%s')" % (
                    sKeyName, sValue)
                sTmpCode = sTmpCode[12:]
                sCodes = sCodes + sTmpCode
            sCodes = sCodes + ''' then   //%s
    begin
    Result := '%s';     //%s
    exit;
    end;
''' % (sFiledInfo, sErrorCode, sErrorMsg)
    return sCodes


def CreateTreate(sAbbName, filedInfo, vIntefaceName):
    sCodes = '''\
function TCSRegSimRequestThread.Treate%s(Treatedbf:THsdbf): String;
begin
  Result := '0000';
''' % (sAbbName)
    if vIntefaceName in TreateMap:
        sTreate = TreateMap[vIntefaceName]
    for sFiledItem in filedInfo:
        sFiledName = sFiledItem['filedName']
        if sFiledName in sTreate:
            sErrorCode = sTreate[sFiledName]['code']
            sFiledInfo = sTreate[sFiledName]['info']
            sErrorMsg = sTreate[sFiledName]['errorMsg']
            if 'condition' in sTreate[sFiledName]:
                conditionList = sTreate[sFiledName]['condition']
                for conditionItem in conditionList:
                    sCodes = sCodes + '''\
  if (Trim(Treatedbf.FieldByName('%s').AsString) = '')
''' % (sFiledName)
                    sCodes = sCodes + CreateSubTreate(
                        conditionItem,
                        list(conditionItem.keys())[0], sFiledInfo, sErrorCode,
                        sErrorMsg)
            else:
                sCodes = sCodes + '''\
  if (Trim(Treatedbf.FieldByName('%s').AsString) = '') then   //%s
  begin
    Result := '%s';    //%s
    exit;
  end;
''' % (sFiledName, sFiledInfo, sErrorCode, sErrorMsg)
    sCodes = sCodes + 'end;\n'
    return sCodes


# 返回dfm中的中文
def getDfmText(intefaceName: str):
    sResult = str(intefaceName.encode('unicode_escape'), 'utf-8')
    sResultList = sResult.split('\\u')
    sResultList.pop(0)
    sResult = ''
    for i in sResultList:
        sResult = sResult + '#' + str(int(i, 16))
    return sResult


# 代码生成
def BuildCode(sCodePath, intefaceMap, intefaceName, sOutCodePath, zxywlb):
    vIntefaceName = intefaceName
    if vIntefaceName in intefaceMap:
        # 处理pas
        if '-' in vIntefaceName:
            vIntefaceName = vIntefaceName[vIntefaceName.find('-') + 1:]
            vIntefaceName = vIntefaceName.strip()
        vReqIntefaceName = ''
        if '消息接口 - ' + vIntefaceName in intefaceMap:
            vReqIntefaceName = '消息接口 - ' + vIntefaceName

        sAbbName = tools.GetInteFaceAbbName(vIntefaceName)
        sClasTestThreadPath = FindClasTestThread(sCodePath)
        sText, sEncoding = tools.LoadSrcCode(sClasTestThreadPath)
        hasServiceName = 'ServiceName' in intefaceMap[intefaceName]
        sServiceNameFlag = "if (Trim(ServiceName) = '%s') then" % intefaceMap[
            intefaceName]['ServiceName']
        with open(sOutCodePath, 'w', encoding=sEncoding) as wFile:
            isCSRegSimRequestThread = False
            isCSCreate = False
            isCSDo = False
            isCSTreate = False
            isDoRequest = False
            isServiceNameBegin = False
            isGetRequest = False
            isServiceType = False
            for sLine in sText:
                if hasServiceName and 'function TCSRegSimRequestThread.DoRequest : Boolean;' in sLine:
                    isDoRequest = True
                elif sLine.strip(
                ) == 'TCSRegSimRequestThread = class(TRequestThread)':
                    isCSRegSimRequestThread = True
                elif 'function TSHRegSimRequestThread.AddStkAccount(' in sLine:
                    wFile.write(
                        CreateResultDbfCode(
                            sAbbName, intefaceMap['应答-' + vIntefaceName]
                            ['filedInfo'], vIntefaceName) + '\n')
                    wFile.write(
                        CreateTreate(
                            sAbbName, intefaceMap['应答-' + vIntefaceName]
                            ['filedInfo'], vIntefaceName) + '\n')
                    wFile.write(
                        CreateResultDo(
                            sAbbName, intefaceMap['应答-' + vIntefaceName]
                            ['filedInfo'], vIntefaceName, intefaceMap) + '\n')
                elif 'function TCSRegSimRequestThread.GetRequest : Boolean;' in sLine:
                    isGetRequest = True
                elif isGetRequest and "(Trim(ServiceName) = '%s')" % (
                        intefaceMap[vReqIntefaceName]['ServiceName']) in sLine:
                    isGetRequest = False
                    if 'Pos(ServiceType,' in sLine:
                        sLine = sLine[:sLine.find("')>0")] + ',' + str(
                            intefaceMap[vReqIntefaceName]
                            ['ServiceType']) + sLine[sLine.find("')>0"):]
                    else:
                        isServiceType = True
                elif isServiceType and 'Pos(ServiceType,' in sLine:
                    isServiceType = False
                    sLine = sLine[:sLine.find("')>0")] + ',' + str(
                        intefaceMap[vReqIntefaceName]
                        ['ServiceType']) + sLine[sLine.find("')>0"):]

                elif isCSRegSimRequestThread and sLine.strip() == '//校验必填字段':
                    isCSTreate = True
                    isCSDo = False
                    isCSCreate = False
                elif isCSRegSimRequestThread and sLine.strip() == '//创建回报子文件':
                    isCSCreate = True
                    isCSTreate = False
                    isCSDo = False
                elif isCSRegSimRequestThread and sLine.strip(
                ) == '//申报/回报解析打包处理':
                    isCSDo = True
                    isCSCreate = False
                    isCSTreate = False
                    isCSRegSimRequestThread = False
                elif isCSTreate and '////////////////////////////////////////////////////////////' in sLine:
                    wFile.write(
                        '    function Treate%s(Treatedbf:THsdbf): String;       //%s字段校验'
                        % (sAbbName, vIntefaceName) + '\n')
                    isCSTreate = False
                elif isCSCreate and '////////////////////////////////////////////////////////////' in sLine:
                    wFile.write(
                        '    function Create%sDbf:string;       //%s回报子文件' %
                        (sAbbName, vIntefaceName) + '\n')
                    isCSCreate = False
                elif isCSDo and '////////////////////////////////////////////////////////////' in sLine:
                    wFile.write('    function Do%s:Boolean;       //%s' %
                                (sAbbName, vIntefaceName) + '\n')
                    isCSDo = False
                elif isDoRequest and sServiceNameFlag in sLine:
                    isServiceNameBegin = True
                elif isServiceNameBegin and ' end' in sLine:
                    sCode = '''\n      if ServiceType = '%s' then //%s
        Result := DO%s;''' % (intefaceMap[intefaceName]['ServiceType'],
                              vIntefaceName, sAbbName)
                    wFile.write(sCode + '\n')
                    isServiceNameBegin = False
                    isDoRequest = False

                wFile.write(sLine + '\n')
        # 处理dfm
        sDFMUFrmConfigPath = FindDFMUFrmConfig(sCodePath)
        sText, sEncoding = tools.LoadSrcCode(sDFMUFrmConfigPath)
        with open(sDFMUFrmConfigPath, 'w', encoding=sEncoding) as wFile:
            isRczxywlb = False
            isRczxywlbItem = False
            for sLine in sText:
                if sLine.strip() == 'object rczxywlb: TRzCheckList':
                    isRczxywlb = True
                elif isRczxywlb and 'Items.Strings = (' == sLine.strip():
                    isRczxywlbItem = True
                    isRczxywlb = False
                elif isRczxywlbItem and ')' in sLine:
                    isRczxywlbItem = False
                    sLine = sLine.replace(
                        ')', "\n            '" + zxywlb + " '" +
                        getDfmText(vIntefaceName) + ")")

                wFile.write(sLine + '\n')


if __name__ == "__main__":
    sFilePath = 'F:/hundsun/svn/util/testFile/统一账户平台关于为转板上市证券跨市场转登记维护账户及托管单元对应关系的接口修订说明 （开发参考稿） - 20210525.docx'
    intefaceMap, resultJsonMap = loadDoc.LoadDoc(sFilePath)
    sCodePath = 'F:/hundsun/svn/hstrade20/sourcesEx/SimulateTools/SimulateExch/'
    sOutCodePath = 'F:/hundsun/svn/util/testFile/ClasTestThread2.pas'
    TreateMap = {
        '跨市场转登记账户及托管单元对应关系维护': {
            'YWLSH': {
                'code': '0109',
                'info': '业务流水号',
                'errorMsg': '错误码,业务流水号重复'
            },
            'YWLB': {
                'code': '1049',
                'info': '业务类别',
                'errorMsg': '错误码,业务类别不合法'
            },
            'KHJGDM': {
                'code': '0107',
                'info': '业务发起开户代理机构代码',
                'errorMsg': '错误码,业务发起开户代理机构不合法'
            },
            'KHWDDM': {
                'code': '0108',
                'info': '业务发起开户代理网点代码',
                'errorMsg': '错误码,业务发起开户代理网点不合法'
            },
            'SQRQ': {
                'code': '0106',
                'info': '申请日期',
                'errorMsg': '错误码,申请日期不合法'
            },
            'GRTGDY': {
                'code': '3114',
                'info': '过入托管单元',
                'errorMsg': '错误码,过入托管单元不合法',
                'condition': [{
                    'YWLB': ['01', '02'],
                    'ZBLB': ['02']
                }]
            },
            'GRZQZH': {
                'code':
                '3113',
                'info':
                '过入证券账户',
                'errorMsg':
                '错误码,过入证券账户不合法',
                'condition': [{
                    'YWLB': ['01', '02'],
                    'ZBLB': ['01']
                }, {
                    'YWLB': ['04']
                }]
            }
        }
    }
    BuildCode(sCodePath, intefaceMap, '消息接口 - 跨市场转登记账户及托管单元对应关系维护',
              sOutCodePath, 'j')
