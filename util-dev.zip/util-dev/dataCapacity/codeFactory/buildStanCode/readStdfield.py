import xml.dom.minidom
import os


def ReadHSStdfield(sFilePath=''):
    resultList = {}
    if not os.path.exists(sFilePath):
        print(sFilePath + '文件不存在!')
        return resultList
    print('加载' + sFilePath)
    # 打开xml文档
    dom = xml.dom.minidom.parse(sFilePath)
    # 得到文档元素对象
    root = dom.documentElement
    stdfielditemList = root.getElementsByTagName('stdfield')
    for stdfieldItem in stdfielditemList:
        sFieldName = stdfieldItem.getAttribute('name')
        sCname = stdfieldItem.getAttribute('cname')
        sType = stdfieldItem.getAttribute('type')
        sDesc = stdfieldItem.getAttribute('desc')
        sDictId = stdfieldItem.getAttribute('dict')

        yzItem = {}
        yzItem['name'] = sFieldName
        yzItem['cname'] = sCname
        yzItem['type'] = sType
        yzItem['desc'] = sDesc
        yzItem['dict'] = sDictId
        resultList[sFieldName] = yzItem

    return resultList


def ReadHSARESStdfield(sFilePath=''):
    resultList = {}
    if not os.path.exists(sFilePath):
        print(sFilePath + '文件不存在!')
        return resultList
    print('加载' + sFilePath)
    # 打开xml文档
    dom = xml.dom.minidom.parse(sFilePath)
    # 得到文档元素对象
    root = dom.documentElement
    itemsList = root.getElementsByTagName('items')
    for items in itemsList:
        sFiledName = items.getAttribute('name')
        sFiledCaption = items.getAttribute('chineseName')
        sFiledType = items.getAttribute('dataType')
        sFiledDesc = items.getAttribute('description')
        sFiledDict = items.getAttribute('dictionaryType')
        if sFiledDict == None:
            sFiledDict = '0'
        if sFiledDesc == None:
            sFiledDesc = ''

        yzItem = {}
        yzItem['name'] = sFiledName
        yzItem['cname'] = sFiledCaption
        yzItem['type'] = sFiledType
        yzItem['desc'] = sFiledDesc
        yzItem['dict'] = sFiledDict
        resultList[sFiledName] = yzItem
    return resultList


if __name__ == "__main__":
    sStdfieldsPath = 'E:/HundSunCode/AccountSystem/客户账户管理系统V22/公共资源/stdfields.xml'
    print(ReadHSStdfield(sStdfieldsPath)['open_start_date'])
