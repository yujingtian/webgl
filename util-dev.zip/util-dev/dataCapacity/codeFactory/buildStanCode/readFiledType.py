import os
import xml.dom.minidom

def ReadHSDataType(sFilePath = ''):
    resultList = {}
    if not os.path.exists(sFilePath):
        print(sFilePath + '文件不存在!')
        return resultList
    print('加载' + sFilePath)
    #打开xml文档
    dom = xml.dom.minidom.parse(sFilePath)
    #得到文档元素对象
    root = dom.documentElement
    userTypeList = root.getElementsByTagName('userType')
    for userType in userTypeList:
        sType = userType.getAttribute('name')
        mapList = userType.getElementsByTagName('map')
        yzItem = {}
        for mapItem in mapList:
            sID = mapItem.getAttribute('id')
            sValue = mapItem.getAttribute('value')
            if sID == 'com.hundsun.hdt.core.pro*c':
                yzItem['c'] = sValue
            elif sID == 'com.hundsun.hdt.core.oracle':
                yzItem['oracle'] = sValue
        resultList[sType] = yzItem

    return resultList

def ReadHSARESDataType(sFilePath = ''):
    resultList = {}
    if not os.path.exists(sFilePath):
        print(sFilePath + '文件不存在!')
        return resultList
    print('加载' + sFilePath)
    #打开xml文档
    dom = xml.dom.minidom.parse(sFilePath)
    #得到文档元素对象
    root = dom.documentElement
    itemsList = root.getElementsByTagName('items')
    for items in itemsList:
        sType = items.getAttribute('name')
        sDescription = items.getAttribute('description')
        sStdType = items.getAttribute('stdType')

        yzItem = {}
        yzItem['c'] = sStdType
        yzItem['oracle'] = sDescription

        resultList[sType] = yzItem
    
    return resultList


if __name__ == "__main__":
    sPath = 'E:/HundSunCode/AccountSystem/客户账户管理系统V22/公共资源/datatypes.xml'
    print(ReadHSDataType(sPath)['HsChar8000'])
