from openpyxl.utils.exceptions import InvalidFileException
import easygui
import tools
import re

reMatchExcel = r'sExcelPath = r.*?\n'
reMatchRoot = r'sRootPath = r.*?\n'
if __name__ == "__main__":
    breRun = True
    sEncoding = tools.GetEncoding('cresCodeGenStdCodeFromExcel.py')
    sRead = open('cresCodeGenStdCodeFromExcel.py', 'r', encoding=sEncoding)
    sText = sRead.read()
    sRead.close()
    while breRun:
        try:
            exec(sText)
        except InvalidFileException as msg:
            fin = easygui.multenterbox(
                msg="路径错误，请输入路径：\n例如 E:\\HundSunCode\\util\\dataCapacity\\HSData\\标准代码生成模板.xlsx\nE:\\HundSunCode\\AccountSystem\\客户账户管理系统V22",
                title="初始化", fields=['Excel', 'Root'])
            while fin is None:
                fin = easygui.multenterbox(
                    msg="路径错误，请输入路径：\n例如 E:\\HundSunCode\\util\\dataCapacity\\HSData\\标准代码生成模板.xlsx\nE:\\HundSunCode\\AccountSystem\\客户账户管理系统V22",
                    title="初始化", fields=['Excel', 'Root'])

            sText = re.sub(reMatchExcel, f"sExcelPath = r'{fin[0]}'\n", sText)
            sText = re.sub(reMatchRoot, f"sRootPath = r'{fin[1]}'\n", sText)
            sText = sText.replace(str(msg).split(' ')[-1].replace('/', '\\'), "'" + fin[0] + "'")
            with open('cresCodeGenStdCodeFromExcel.py', 'w', encoding=sEncoding) as f:
                f.write(sText)
            breRun = True
        else:
            breRun = False
