import multiprocessing

import openpyxl
import copy
import sys
import os
import time
import tools
import re
import readStdfield as rstds
import readFiledType as rftype
from typing import Dict, Tuple, Union, List
from threading import Thread

sExcelPath = r'E:\HundSunCode\util\dataCapacity\HSData\标准代码生成模板.xlsx'
sRootPath = r'E:\HundSunCode\AccountSystem\客户账户管理系统V22'
sStdfieldsPath = '/公共资源/stdfields.xml'
sFiledTypePath = '/公共资源/datatypes.xml'
sExcelSheet = ['表结构', '功能目录', '业务标志', '档案增加', '标准字段', '常量列表', 'Bop查询']

# excel中的标准字段
ExcelStdMap = {'字段名': 'name', '字段类型': 'type',
               '字段名称': 'cname', '字段说明': 'desc',
               '字段缺省值': 'dv', '字典条目': 'dict'}
StdInfoMapAll = {}
# 标准字段
ReadHSStdfieldMap = {}
# 数据类型
ReadHSDataTypeMap = {}
################################################
# 表结构
ExcelTableMap = {'对象号': 'id', '版本号': 'version', '表名': 'tableName', '表类型': 'tableType', '所在数据库': 'schema',
                 '中文名': 'CNtableName', '是否自定义表分区': 'cur_partition', '表分区字段': 'partition_field',
                 '分区个数': 'partition_amount',
                 '分区开始日期': 'partition_date', '存在历史表': 'history', '存在冗余表': 'rtable', '存在清算表': 'sett',
                 '说明': 'configString', '修改记录': 'Modify', '模块名': 'moduleName'}
TableInfoMap = {'moduleName': '', 'CNtableName': '', 'id': '', 'version': '', 'tableName': '', 'schema': '',
                'indexSchema': '',
                'historySchema': '',
                'historyIndexSchema': '', 'configString': '', 'history': 'false', 'sett': 'false',
                'rtable': 'false', 'partition_field': '', 'partition_amount': '', 'partition_date': '',
                'cur_partition': 'false', 'currentTableNeedPartition': 'false', 'tableType': '',
                'flag': [], 'name': [], 'cannull': [], 'isprimary': [], 'comment': [],
                'flag2': [], 'name2': [], 'unique': [], 'cluster': [], 'columnNames': [],
                'Modify': [],
                'reverse': 'false'}
TableInfoMapAll = {}  # {'tableName':{TableInfoMap}...}
################################################
# 功能目录
ExcelFcnMap = {'模块名称': 'moduleName', '功能名称（建议“名+动”）': 'fcnName', '表名': 'tableName', '功能类型': 'fcnType', '接口标志': 'flag',
               '服务名称': 'englishName', 'position_str': 'p_str', '功能编号（现）': 'objectId', '增值编号': 'module_id',
               '账户公用校验': '账户公用校验'}

FcnInfoMapAll = {}
# 含有一些默认传入值
DefaultInfoMap = {'description': '', 'updateDate': '20180126', 'version': 'V8.0.8.1',
                  'checkLicence': 'true', 'dataBaseName': '', 'functionId': '', 'serviceNo': '',
                  'requirementNo': '', 'requirementType': '', 'requirementLevel': '', 'auditNeed': 'false',
                  'auditType': '',
                  'auditLevel': '', 'operator': '', 'subSystemId': '', 'needTransMonitor': 'false',
                  'noCallAS': 'false', 'defaultCallAS': ''}
basicInfoMap = {'qry': {'returnResultSet': 'true', 'timeout': '30000'},
                'default': {'returnResultSet': 'false', 'timeout': '5000'}}
qrybasicInfoMap = {'报送查询': {'timeout': '5000'}}
defaultImports = ['op_branch_no', 'operator_no', 'user_type', 'op_password', 'op_station', 'op_entrust_way', 'menu_id',
                  'function_id', 'branch_no', 'audit_action']
excludeImportMap = {'qry': ['init_date', 'curr_date', 'curr_time'],
                    'default': ['curr_date', 'curr_time', 'position_str']  # 记录：DEL 'init_date'
                    }
# 一定会出现在imports中的入参
extraImportMap = {
    'p2': {  # default == qry 二期只会出现qry
        'AS': {'default': ['en_branch_no', 'sort_direction', 'total_action', 'position_str', 'request_num',
                           'page_no',
                           'groupby_string', 'group_columns', 'en_business_flag',
                           'client_id']},  # , 'start_date', 'end_date'
        'LS': {'default': ['en_branch_no', 'sort_direction', 'total_action', 'position_str', 'request_num',
                           'page_no',
                           'groupby_string', 'group_columns', 'en_business_flag',
                           'client_id']}  # , 'start_date', 'end_date'
    },
    'p1': {'AS': {'qry': ['request_num'],
                  'default': ['action_in']},
           'LS': {'qry': [],
                  'default': []}
           }
}
exportMap = {
    'p2': {  # default == qry 二期只会出现qry
        'default': []},
    'p1': {'qry': [], 'default': ['remark', 'serial_no']}}
variableMap = {'p2': [{'name': 'sort_way', 'type': 'HsChar6', 'dv': '',
                       'cname': '排序方式', 'desc': ''},
                      {'name': 'row_max', 'type': 'HsNum', 'dv': '',
                       'cname': '翻页最大行', 'desc': ''},
                      {'name': 'row_min', 'type': 'HsNum', 'dv': '',
                       'cname': '翻页最小行', 'desc': ''},
                      ],
               'p1': []
               }
########################
# Bop查询
ExcelBopMap = {'查询类型': 'qryType', '表名': 'tableName', '功能号': 'objectId', '历史功能号': 'HISobjectId', 'menu_id': 'menu_id',
               '查询标签名': 'text', '查询条件字段': 'qryname', '查询条件字段描述': 'fieldText', '查询条件限定范围': 'verify'}
BopInfoMapAll = {}

################################################
# 业务标志 用于AS
ExcelBusMap = {'业务标志': 'business_flag', '服务名称': 'englishName', '业务备注': 'remark', '中文名': 'CNtableName',
               '查询表名': 'tableName', '业务类别': 'busType'}
BusInfoMapAll = {}
################################################
# 档案增加
ExcelArchMap = {'操作标志': 'sub_op_type', '备注': 'remark', '服务名称': 'englishName'}
ArchInfoMapAll = {}
################################################
# 常量列表
ExcelCnstMap = {'宏定义': 'macro', '表名': 'tableName'}
CnstInfoMapAll = {}
################################################
# 模块：对象号字典
IdListMap = {}
################################################
action_inMap = {'add': '1', 'del': '2', 'mod': '3', 'qry': ''}
fcn_typeMap = {'qry': '查询', 'default': '设置'}
fcn_InfoMap = {'add': {'cn': '增加', 'en': 'ADD', 'AS': '设置', 'ASEN': 'SET'},
               'qry': {'cn': '查询', 'en': 'GET', 'AS': '查询', 'ASEN': 'GET'},
               'del': {'cn': '删除', 'en': 'DEL', 'AS': '设置', 'ASEN': 'SET'},
               'mod': {'cn': '修改', 'en': 'MOD', 'AS': '设置', 'ASEN': 'SET'}
               }
moduleidCheckMap = {None: '', '': '',
                    'default': '''  [AS_用户公用_业务许可证检查][module_id = %(module_id)s, license_type = '4']'''}
# 会进行更改 需要创建副本以免多线程使用混淆
CategoryInfoMap = {
    'AS': {'ENName': '', 'exName': '.aservice_design', 'prefix': '2', 'ASName': '', 'flag': '', 'jour': '_GET'},
    'AF': {}, 'AP': {}, 'LF': {}}
reMatchId = r'objectId="(.*?)"'
categoryModDirMap = {'LS': {'dir': '/服务', 'mod': '/业务逻辑'},
                     'LF': {'dir': '/函数', 'mod': '/业务逻辑'},
                     'AF': {'dir': '/函数', 'mod': '/原子'},
                     'AS': {'dir': '/服务', 'mod': '/原子'},
                     'AP': {'dir': '/过程', 'mod': '/原子'},
                     'TAB': {'dir': '/ ', 'mod': '/数据库'}  # 'TAB' 只会单独传入FindModulePath
                     }
# 二期 特殊处理模块
phaseMap = {('公司查询(账户)', '公司历史查询(账户)',
             '客户查询(账户)', '客户历史查询(账户)'): 'p2',
            ('default',): 'p1'}
# 数据库
dataBaseMap = {'公司查询(账户)': 'DATADB', '公司历史查询(账户)': 'HISDB',
               '客户查询(账户)': 'ASSETDB', '客户历史查询(账户)': 'HISDB'}
# code
sbasicCode = '''<?xml version="1.0" encoding="UTF-8"?>

<hsdoc version="1.1.0">
  <basic>
    <basic objectId="%(objectId)s" version="%(version)s" updateDate="%(updateDate)s" description="%(description)s" englishName="%(englishName)s" flag="%(flag)s" returnResultSet="%(returnResultSet)s" checkLicence="%(checkLicence)s" dataBaseName="%(dataBaseName)s" functionId="%(functionId)s" serviceNo="%(serviceNo)s" requirementNo="%(requirementNo)s" requirementType="%(requirementType)s" requirementLevel="%(requirementLevel)s" auditNeed="%(auditNeed)s" auditType="%(auditType)s" auditLevel="%(auditLevel)s" operator="%(operator)s" subSystemId="%(subSystemId)s" timeout="%(timeout)s" needTransMonitor="%(needTransMonitor)s" noCallAS="%(noCallAS)s" defaultCallAS="%(defaultCallAS)s"/>
  </basic>
  <parameter>
    <import>'''
macro_stdqryMap = {
    'en_': {
        'char': '''[标准可选查询条件字符存在instr][@{}][{}][a.]''',
        'string': '''[标准可选查询条件字符串存在instr][@{}][{}][a.]''',
        'int': '''[标准可选查询条件整数存在instr][@{}][{}][a.]'''},
    'default': {
        'string': '''[标准可选查询条件字符串][@{}][{}][=][a.]''',
        'char': '''[标准可选查询条件字符][@{}][{}][=][a.]''',
        'int': '''[标准可选查询条件整数][@{}][{}][[&gt;=][a.]''',
        'double': '''[标准可选查询条件实数exact][@{}][{}][[&gt;=][a.]'''}
}
LS_CodeMap = {
    'p1': {
        'qry': '''  [AS_用户公用_用户可操作分支获取]

  [%(ASName)s]''',
        'del': '''  [AS_用户公用_系统状态和用户权限检查][check_str = "01"]

  [复核业务标志]

  [AS_账户公用_账户基本参数信息获取]

  [%(ASName)s][action_in = %(action_in)s]

  [AS_用户公用_用户操作日志记录][operator_action='5', join_serial_no = @serial_no, op_remark = @remark]''',
        'default': '''  [AS_用户公用_系统状态和用户权限检查][check_str = "01"]

  [复核业务标志]

  [AS_账户公用_账户基本参数信息获取]

  [%(ASName)s][action_in = %(action_in)s]

  [LF_账户公用_档案采集任务增加][sub_op_type = "%(sub_op_type)s", remark = "%(remark)s"]

  [AS_用户公用_用户操作日志记录][operator_action='5', join_serial_no = @serial_no, op_remark = @remark]'''
    },
    'p2': {'default': '''  //1：客户类别,2：客户室,3：币种,4：交易类别,5：证券类别,6：委托方式,7：银行编号
  //[AS_用户公用_查询权限检查][op_limit_type=0000000]

  //[AS_客户查询(用户)_用户查询权限检查][op_limit_type=1100000001]

  //[AS_客户查询(用户)_用户查询权限检查][op_limit_type=1100000]

  [AS_用户公用_用户权限检查]

  [AS_用户公用_用户可操作分支获取]
  
  [AS_客户查询(账户)_证券基金账户关系查询]'''}
}
AS_CodeMap = {
    'p1': {
        'qry': {  # default->'信息查询,...'
            'default': ''''  if (isnull(trim(@position_str)) == 0)
  {
    hs_strncpy(@position_str, "0", sizeof(@position_str) - 1);
  }
 
  if (@request_num &lt;= 0)
  {
    @request_num = 50;
  }
  ''',
            '报送查询': '''  if (isnull(trim(@position_str)) == 0)
  {
    hs_strncpy(@position_str, "0", sizeof(@position_str) - 1);
  }
 
  if (@request_num &lt;= 0)
  {
    @request_num = 50;
  }
  
  hs_strncpy(@table_name,"%(CNtableName)s:%(tableName)s", sizeof(@table_name) - 1);
   
  [PRO*C结果集语句][select * 
                    from (select a.* 
                            from %(tableName)s a
                           where'''
        },  # 信息设置
        'default': '''  //action_in 1 新增； 2 删除； 3 修改； 4-同步扩展信息中的非居民信息； 5-批量调整收入信息
  hs_strncpy(@table_name,"%(CNtableName)s:%(tableName)s", sizeof(@table_name) - 1);
  
  [PRO*C语句块开始]
    [事务处理开始]
      @rowcount := 1;
      begin 
        select %(importsList)s
        into %(varsList)s
          from %(tableName)s
         where client_id = @client_id;
      exception
        when NO_DATA_FOUND then
          @rowcount := 0;
        when others then
          [PRO*C语句块报错返回][ERR_ASSET_QRY_TABLERECORD_FAIL][查询表记录失败][@table_name,@client_id]
      end;
      
      if @action_in = 1 then //新增;
        [AP_账户公用_子系统流水号获取][branch_no = &lt;CNST_DEFAULT_SERIAL_BRANCH_NO&gt;, serial_counter_no = &lt;CNST_%(macro)s_%(tableNameJouraddU)s&gt;, serial_no = @serial_no] 
        @position_str  := lpad(@init_date, 8, '0') || lpad(@serial_no, 10, '0');
        
        begin
          [插入表记录][%(tableName)s]
        exception
          when others then
            [PRO*C语句块事务内报错返回][ERR_ASSET_ADD_TABLERECORD_FAIL][增加表记录失败][@table_name,@client_id]
        end;

        //记录流水
        @business_flag := %(business_flagadd)s;
        @remark := '%(remarkadd)s ' || @remark;
        @table_name := '%(CNtableNameJouradd)s:%(tableNameJouradd)s';

        begin
          [select插入表记录][%(tableNameJouradd)s][%(tableName)s][remark = @remark, position_str = @position_str]
             where client_id = @client_id;
        exception
          when others then
            [PRO*C语句块事务内报错返回][ERR_USER_ADD_TABLERECORD_FAIL][增加表记录失败][@table_name,@client_id]
        end;
        
      elsif @action_in = 2 then //删除;

        if @rowcount &lt;= 0 then
          [PRO*C语句块报错返回][ERR_ASSET_TABLERECORD_NOTEXISTS][表记录不存在][@table_name, @client_id]
        end if;
        
        //记录流水
        @business_flag := %(business_flagdel)s;
        @remark := '%(remarkdel)s ' || @remark;
        @table_name := '%(CNtableNameJourdel)s:%(tableNameJourdel)s';
        [AP_账户公用_子系统流水号获取][branch_no = &lt;CNST_DEFAULT_SERIAL_BRANCH_NO&gt;, serial_counter_no = &lt;CNST_%(macro)s_%(tableNameJourdelU)s&gt;, serial_no = @serial_no] 
        @position_str  := lpad(@init_date, 8, '0') || lpad(@serial_no, 10, '0');
        begin
          [select插入表记录][%(tableNameJourdel)s][%(tableName)s][remark = @remark, position_str = @position_str]
             where client_id = @client_id;
        exception
          when others then
            [PRO*C语句块事务内报错返回][ERR_USER_ADD_TABLERECORD_FAIL][增加表记录失败][@table_name,@client_id]
        end;
        
        begin
          delete from %(tableName)s
           where client_id = @client_id;
        exception
          when others then
            [PRO*C语句块事务内报错返回][ERR_ASSET_DEL_TABLERECORD_FAIL][删除表记录失败][@table_name, @client_id]
        end;
        
      elsif @action_in = 3 then //修改;
      
        if @rowcount &lt;= 0 then
          [PRO*C语句块报错返回][ERR_ASSET_TABLERECORD_NOTEXISTS][表记录不存在][@table_name, @client_id]
        end if;
        
        %(IFList)s
        if (trim(@remark) is null) then
          [PRO*C语句块正常返回]
        end if;
        
        begin
          update %(tableName)s
             set %(SETList)s
             where client_id = @client_id;
        exception
          when others then
            [PRO*C语句块事务内报错返回][ERR_ASSET_MOD_TABLERECORD_FAIL][修改表记录失败][@table_name, @client_id]
        end;
        
        //记录流水
        @business_flag := %(business_flagmod)s;
        @remark := '%(remarkmod)s ' || @remark;
        @table_name := '%(CNtableNameJourmod)s:%(tableNameJourmod)s';
        [AP_账户公用_子系统流水号获取][branch_no = &lt;CNST_DEFAULT_SERIAL_BRANCH_NO&gt;, serial_counter_no = &lt;CNST_%(macro)s_%(tableNameJourmodU)s&gt;, serial_no = @serial_no] 
        @position_str  := lpad(@init_date, 8, '0') || lpad(@serial_no, 10, '0');
        begin
          [select插入表记录][%(tableNameJourmod)s][%(tableName)s][remark = @remark, position_str = @position_str]
             where client_id = @client_id;
        exception
          when others then
            [PRO*C语句块事务内报错返回][ERR_USER_ADD_TABLERECORD_FAIL][增加表记录失败][@table_name,@client_id]
        end;
        
      end if;
      
    [事务处理结束]
  [PRO*C语句块结束]'''
    },
    'p2': {  # atom value: 'p_str':p_str,'tableName':tableName,'macro_stdqry':macro_stdqry

        'main': r'''  [AF_系统公用_系统配置信息获取][config_no=1140,char_config=@char_config]

  if (@request_num == 0)
  {{
    @request_num_reset = 1000;
  }}
  else
  {{
    @request_num_reset = @request_num;
  }}
  
  if (isnull(trim(@position_str)) == 0)
  {{
    hs_strncpy(@position_str, "0", sizeof(@position_str) - 1);
  }}
  hs_snprintf(@sSql, 32000,"%s","");

  if (@total_action == 0)
  {{
    if ( @page_no &gt; 0 )
    {{
      if ( @sort_direction == CNST_CHAR_DEFAULTVALUE || @sort_direction == '1' )
      {{
        hs_strncpy(@sort_way,"desc",sizeof(@sort_way) - 1);
      }}
      else
      {{
        hs_strncpy(@sort_way,"asc",sizeof(@sort_way) - 1);
      }}
      @row_max = @request_num * @page_no;
      @row_min = @request_num * (@page_no - 1);
      hs_snprintf(@sSql,32000," %s \n %s ",@sSql,"select * from (");
      hs_snprintf(@sSql,32000," %s \n %s ",@sSql,"select * from (");
      hs_snprintf(@sSql,32000," %s \n %s ",@sSql,"select f.*,rownum as rn from (");
      if ( isnull(trim(@sort_name)) != 0)
      {{
        hs_snprintf(@sSql,32000," %s \n %s ",@sSql,"select * from (");
      }} 
    }}
    else
    {{
      hs_snprintf(@sSql, 32000,"%s \n %s",        @sSql,"select   * from (");
    }}
  }}
  else
  {{
    if (isnull(trim(@group_columns)) == 0)
    {{
      hs_snprintf(@sSql, 32000,"%s \n %s%s%s",@sSql,"select   count(*) as rowcount ", @compute_columns, " from (");
    }}
    else
    {{
      hs_snprintf(@sSql, 32000,"%s \n %s%s%s%s%s",@sSql,"select  ", @group_columns, ", count(*) as rowcount ", @compute_columns, " from (");
    }}
  }}

  {statement_position_str0}

  hs_snprintf(@sSql, 32000,"%s \n %s",        @sSql,"  where 1=1 ");
 
  {statement_oper_branches}
  {macro_stdqry}
  
  if (@total_action==0)
  {{
    {statement_position_str1}
    {statement_sort_name}
  
  //printf("======\n[%s]\n====== ", @sSql);
  [通用SELECT][@sSql]
  {{
    [标准结果集返回]
  }}
  else
  {{
    [数据库报错返回]
  }}''',
        'macro_stdqry': {('公司查询(账户)', '客户查询(账户)'): ('start_date', 'end_date'),  # 不进行宏语句的字段
                         ('公司历史查询(账户)', '客户历史查询(账户)'): ()},
        'oper_branches': {'公司查询(账户)': {'statement_oper_branches': r'''if (isnull(trim(@oper_branches)) != 0)
  {
    hs_snprintf(@sSql,32000,"%s \n %s%s%s",    @sSql,"    and ((instr(',' || '",@oper_branches,"' || ',', ',' ||  a.branch_no || ',') &gt; 0))");
  }'''},
                          '客户查询(账户)': {'statement_oper_branches': r'''if (isnull(trim(@oper_branches)) != 0)
  {
    hs_snprintf(@sSql,32000,"%s \n %s%s%s",    @sSql,"    and ((instr(',' || '",@oper_branches,"' || ',', ',' ||  a.branch_no || ',') &gt; 0))");
  }'''},
                          '公司历史查询(账户)': {'statement_oper_branches': r'''if (isnull(trim(@oper_branches)) != 0)
  {
    hs_snprintf(@sSql,32000,"%s \n %s%s%s%d%s",    @sSql,"    and ((instr(',' || '",@oper_branches,"' || ',', ',' ||  a.branch_no || ',') &gt; 0) or (a.op_branch_no = ",@op_branch_no, "))");
  }'''},
                          '客户历史查询(账户)': {
                              'statement_oper_branches': r'''hs_snprintf(@sSql, 32000,"%s \n and (instr('%s', ',' || a.branch_no || ',') &gt; 0)",  @sSql, @oper_branches);'''}
                          },
        'p_str': {
            'default': {
                'statement_position_str0': {
                    ('公司查询(账户)', '客户查询(账户)'): r'''hs_snprintf(@sSql, 32000,"%s \n %s",        @sSql,"  select a.*, lpad(to_char(a.{p_str}),18,'0') as position_str");

  if('1' == @char_config)
  {{
    hs_snprintf(@sSql, 32000,"%s \n %s",        @sSql,"  from hs_acct.{tableName} a  ");
  }}
  else
  {{
    hs_snprintf(@sSql, 32000,"%s \n %s",        @sSql,"  from hs_asset.{tableName} a  ");
  }}''',
                    ('公司历史查询(账户)', '客户历史查询(账户)'): r'''hs_snprintf(@sSql, 32000,"%s \n %s",        @sSql,"  select a.*, lpad(to_char(a.{p_str}),18,'0') as position_str");
  if('1' == @char_config)
  {{}}
  else
  {{}}
  hs_snprintf(@sSql, 32000,"%s \n %s",        @sSql,"  from hs_his.his_{tableName} a  ");'''},
                'statement_position_str1': r'''hs_snprintf(@sSql, 32000,"%s \n %s%s%s",    @sSql,"    and lpad(to_char(a.{p_str}),18,'0') &gt; '", @position_str, "'");''',
                'statement_sort_name': {'main': r'''{statement_position_str2}
    if ( @page_no &gt; 0 )
    {{
      if ( isnull(trim(@sort_name)) != 0 )
      {{
         hs_snprintf(@sSql,32000," %s \n %s%s %s",@sSql,") order by ",@sort_name,@sort_way);
      }}
      hs_snprintf(@sSql,32000,"%s \n %s %d %s",@sSql,") f ) g where g.rn &lt;= ",@row_max,") h");
      hs_snprintf(@sSql,32000,"%s \n %s%d",@sSql," where h.rn &gt; ",@row_min);
      if (isnull(trim(@sort_name)) == 0)
      {{
        hs_snprintf(@sSql,32000,"%s \n %s ",@sSql," order by h.{p_str}");
      }}
      else
      {{
        hs_snprintf(@sSql,32000," %s \n %s%s %s",@sSql," order by ",@sort_name,@sort_way);
      }}
    }}
    else
    {{
      hs_snprintf(@sSql, 32000,"%s \n %s%d",      @sSql,") where rownum &lt;=",@request_num_reset);
    }}
  }}
  else
  {{
    if ( isnull(trim(@groupby_string)) == 0 )
    {{
      hs_snprintf(@sSql, 32000,"%s \n %s",      @sSql,") ");
    }}
    else
    {{
      hs_snprintf(@sSql, 32000,"%s \n %s%s",      @sSql,") group by ",@groupby_string);
    }}
  }}''',
                                        'statement_position_str2': r'''if (isnull(trim(@sort_name)) == 0)
    {{
      hs_snprintf(@sSql, 32000,"%s \n %s",        @sSql,"  order by lpad(to_char(a.{p_str}),18,'0')");
    }}
    else 
    {{
      hs_snprintf(@sSql, 32000,"%s \n %s%s %s",        @sSql,"  order by  ",@sort_name,@sort_way);
    }}'''}
            },
            # 若position_str单元格为空，将p_str='position_str'
            'position_str': {
                'statement_position_str0': {
                    ('公司查询(账户)', '客户查询(账户)'): r'''hs_snprintf(@sSql, 32000,"%s \n %s",        @sSql,"  select a.*  ");

  if('1' == @char_config)
  {{
    hs_snprintf(@sSql, 32000,"%s \n %s",        @sSql,"  from hs_acct.{tableName} a  ");
  }}
  else
  {{
    hs_snprintf(@sSql, 32000,"%s \n %s",        @sSql,"  from hs_asset.{tableName} a  ");
  }}''',
                    ('公司历史查询(账户)', '客户历史查询(账户)'): r'''hs_snprintf(@sSql, 32000,"%s \n %s",        @sSql,"  select a.* ");
  if('1' == @char_config)
  {{
  }}
  else
  {{
  }}
  hs_snprintf(@sSql, 32000,"%s \n %s",        @sSql,"  from hs_his.his_{tableName} a  ");'''},
                'statement_position_str1': r'''hs_snprintf(@sSql, 32000,"%s \n %s%s%s",    @sSql,"    and a.position_str &gt; '", @position_str, "'");''',
                'statement_sort_name': {'main': r'''hs_snprintf(@sSql, 32000,"%s \n %s",        @sSql,"  order by a.position_str");
    hs_snprintf(@sSql, 32000,"%s \n %s%d ",      @sSql,") where rownum &lt;= ",@request_num_reset);
  }}
  else
  {{
    hs_snprintf(@sSql, 32000,"%s \n %s%s",      @sSql,") group by ",@groupby_string);
  }}''',
                                        'statement_position_str2': r'''if (isnull(trim(@sort_name)) == 0)
                     {{
                       hs_snprintf(@sSql, 32000,"%s \n %s",        @sSql,"  order by a.position_str");
                     }}
                     else
                     {{
                       hs_snprintf(@sSql, 32000,"%s \n %s%s %s",        @sSql,"  order by  ",@sort_name,@sort_way);
                     }}'''}
            }
        }
    }

}
# 三期
sMergedBar = '|'
sBopRootPath = 'E:/HundSunCode/AccountSystem/bop2.0/bop-biz-platform/bop-query/bop-biz-query/src/main/resources/query'
sBopfieldnameXmlPath = 'E:/HundSunCode/AccountSystem/bop2.0/bop-biz-platform/bop-resource-ext/src/main/resources/fieldname.xml'
MenutypeXmlMap = {'单客户查询': '70031001', '多客户查询': '70031002',
                  '归档客户查询': '70031401', '归档公司查询': '70031402'}
reMatchBopId = r'id="(.*?)"'
reMatchBopOrder = r'order="(.*?)"'
reMatchBopFcnId = r'functionId="(.*?)"'
reMatchBopENname = r'english_name="(.*?)"'
bBuildBopFiles = False
bBuildFiles = False


def readTableStruct(excel):
    """表结构文件生成函数

    因为表结构Sheet特殊性，特别的为单独函数"""
    global bBuildFiles
    sheetTS = excel.get_sheet_by_name(sExcelSheet[0])
    bStd = False
    bIndexStd = False
    bModify = False
    mapTmp = {}

    def WriteBool(bstr):
        if bstr is None:
            bstr = ''
        if bstr == 'Y':
            return 'true'
        else:
            return 'false'

    def JudgeName(name):
        if name is None or name == '':
            sys.exit('字段名/索引名/索引字段为空')
        else:
            return name

    if sheetTS['B1'].value == 'Y':
        bBuildFiles = True
    for row in sheetTS.rows:
        if bStd:
            if row[1].value == '索引标志':
                bStd = False
                bIndexStd = True
            else:
                mapTmp['name'].append(JudgeName(row[2].value))
                mapTmp['flag'].append('' if row[3].value is None else row[2].value)
                mapTmp['cannull'].append(WriteBool(row[4].value))
                mapTmp['isprimary'].append(WriteBool(row[5].value))
                mapTmp['comment'].append('' if row[6].value is None else row[6].value)
            continue
        elif bIndexStd:
            if row[1].value == '修改记录':
                bIndexStd = False
                bModify = True
            else:
                mapTmp['flag2'].append('' if row[1].value is None else row[1].value)
                mapTmp['name2'].append(JudgeName(row[2].value))
                mapTmp['unique'].append(WriteBool(row[3].value))
                mapTmp['cluster'].append(WriteBool(row[4].value))
                mapTmp['columnNames'].append(JudgeName(row[5].value))
                continue
        if bModify:
            if row[1].value == 'end':
                bModify = False
                TableInfoMapAll[mapTmp['tableName']] = copy.deepcopy(mapTmp)
            else:
                mapTmp['Modify'].append([row[2].value, row[6].value])
            continue

        for index, cell in enumerate(row):
            if cell.value == '对象号':
                mapTmp = copy.deepcopy(TableInfoMap)
            if cell.value == '字段':
                bStd = True
                continue
            if cell.value in ExcelTableMap.keys():
                cellNext = row[index + 1].value
                if cellNext == 'Y':
                    mapTmp[ExcelTableMap[cell.value]] = 'true'
                elif cellNext is not None and cellNext != '':
                    mapTmp[ExcelTableMap[cell.value]] = cellNext


def readSheet(sheet, ExcelNameMap: dict, minrow: int, NameInfoMapAll: dict, flagName: str, flagName2=''):
    """sheet读取函数

    可以读取表头行+数据 类型的表格，支持二级分组"""
    attributeNameMap = {}
    InfoMapTmp = {}
    InfoMapTmp2 = {}
    for index, cell in enumerate(sheet[minrow]):
        _cellVal = cell.value
        if _cellVal is not None and _cellVal.strip() in ExcelNameMap.keys():
            attributeNameMap[index] = _cellVal.strip()
    for row in sheet.iter_rows(min_row=minrow + 1):
        bMergedFlag = any(isinstance(cell, openpyxl.cell.MergedCell) for cell in row)
        for index, cell in enumerate(row):
            if index in attributeNameMap.keys() and not isinstance(cell, openpyxl.cell.MergedCell):
                cellVal = cell.value
                if cellVal is None:
                    cellVal = ''
                cellVal = str(cellVal).strip()
                attributeName = ExcelNameMap[attributeNameMap[index]]
                if bMergedFlag:  # 若该行有合并单元格。特性：合并单元格左上角单元格不为MergedCell类型
                    InfoMapTmp[attributeName] += sMergedBar + cellVal
                else:
                    InfoMapTmp[attributeName] = cellVal

        if flagName2:
            InfoMapTmp2[InfoMapTmp[flagName2]] = InfoMapTmp.copy()
            NameInfoMapAll[InfoMapTmp[flagName]] = copy.deepcopy(InfoMapTmp2)
        else:
            NameInfoMapAll[InfoMapTmp[flagName]] = copy.deepcopy(InfoMapTmp)
    if '' in NameInfoMapAll.keys():
        NameInfoMapAll.pop('')


# eg: ./客户账户管理系统V22-2/业务逻辑/账户/BOP组合业务/服务
def findModulePath(moduleName: str, categorys: list) -> dict:
    sModulePath = {}

    for root, dirs, files in os.walk(sRootPath + categoryModDirMap[categorys[0]]['mod']):
        if moduleName in dirs:
            sModulePath[categorys[0]] = root + '/' + moduleName + categoryModDirMap[categorys[0]]['dir']
            break
    if not sModulePath:
        sys.exit('意料之外的模块名')
    for cate in categorys:
        sModulePath[cate] = sModulePath[categorys[0]].replace(
            categoryModDirMap[categorys[0]]['mod'],
            categoryModDirMap[cate]['mod']).replace(
            categoryModDirMap[categorys[0]]['dir'],
            categoryModDirMap[cate]['dir'])

    return sModulePath


def calId(_CategoryInfoMap: dict, moduleName: str, category: str, prefix_Id: str) -> int:
    """计算带前缀的对象号
        :category:文件类别，AS，LS...
        :prefix_Id:LS文件对象号
    若对象号未占用则返回带有前缀的对象号，若已存在则返回模块下最大值加1"""
    prefix_Id = _CategoryInfoMap['AS']['prefix'] + prefix_Id
    if moduleName in IdListMap.keys():
        IdList = IdListMap[moduleName]
    else:
        IdList: List[int] = []
        sModulePath = findModulePath(moduleName, [category])
        filedirPath = sModulePath[category]
        for file in os.listdir(filedirPath):
            sText, _ = tools.LoadSrcCode(filedirPath + '/' + file)
            for sLine in sText:
                if 'objectId="' in sLine:
                    IdList.append(int(re.search(reMatchId, sLine).group(1)))
                    break
    if int(prefix_Id) in IdList:
        IdList.sort()
        prefix_Id = IdList[-1] + 1
    IdList.append(int(prefix_Id))
    IdListMap[moduleName] = IdList
    return prefix_Id


# Category:AS LS...
def buildCategoryName(_CategoryInfoMap: dict, category, fcnType, englishName: str, moduleName, fcnName: str):
    if fcnName.endswith(fcn_InfoMap[fcnType]['cn']):
        _CategoryInfoMap[category][category + 'Name'] = category + '_' + moduleName + '_' + fcnName[:-2] + \
                                                        fcn_InfoMap[fcnType][category]
    else:
        _CategoryInfoMap[category][
            category + 'Name'] = category + '_' + moduleName + '_' + \
                                 fcnName + fcn_typeMap.get(fcnType, fcn_typeMap['default'])

    if englishName.endswith(fcn_InfoMap[fcnType]['en']):
        _CategoryInfoMap[category]['ENName'] = category + englishName[2:-3] + fcn_InfoMap[fcnType][category + 'EN']
    else:
        _CategoryInfoMap[category]['ENName'] = category + englishName[2:] + '_GET'


def BuildFunctionFiles(fcninfomapList):
    """生成相应操作文件
    :期号:
    :p1:[表结构文件,非居民金融账户_非居民金融账户个人信息[增删改查].[LS,AS]文件]
    :p2:[公司查询(账户),公司历史查询(账户),客户查询(账户),客户历史查询(账户) 模块 .[LS,AS]文件]
    目前生成LS，AS文件"""
    # fcninfomap = {'moduleName': '', 'fcnName': '', 'tableName': '', 'fcnType': '', 'flag': '', 'englishName': '',
    #               'p_str': '', 'objectId': '', 'module_id': '', '账户公用校验': ''}
    _CategoryInfoMap = CategoryInfoMap.copy()
    for fcninfomap in fcninfomapList:
        sText = ''
        sTextAS = ''
        ASNamesuffix = ''
        fcnType = fcninfomap['fcnType']  # qry add...
        englishName = fcninfomap['englishName']
        for phase in phaseMap.keys():
            if fcninfomap['moduleName'] in phase:
                phaseFlag = phaseMap[phase]
                break
        else:
            phaseFlag = phaseMap[('default',)]
        buildCategoryName(_CategoryInfoMap, 'AS', fcnType, englishName, fcninfomap['moduleName'],
                          fcninfomap['fcnName'])
        sModulePath = findModulePath(fcninfomap['moduleName'], ['LS', 'AS'])
        sfilepath = sModulePath['LS'] + '/LS_' + fcninfomap['moduleName'] + '_' + fcninfomap[
            'fcnName'] + '.service_design'
        sfilepathAS = sModulePath['AS'] + '/' + _CategoryInfoMap['AS']['ASName'] + _CategoryInfoMap['AS']['exName']

        # basicCode
        mapTmp = fcninfomap.copy()
        mapTmp.update(DefaultInfoMap)
        mapTmp.update(basicInfoMap.get(fcnType, basicInfoMap['default']))
        if fcninfomap['moduleName'] in dataBaseMap.keys():
            mapTmp['dataBaseName'] = dataBaseMap[fcninfomap['moduleName']]
        vLine = sbasicCode % mapTmp
        sText += vLine + '\n'

        mapTmp.update(_CategoryInfoMap['AS'])
        mapTmp['objectId'] = calId(_CategoryInfoMap, fcninfomap['moduleName'], 'AS', str(fcninfomap['objectId']))
        mapTmp['englishName'] = _CategoryInfoMap['AS']['ENName']

        ASNamesuffix += _CategoryInfoMap['AS']['ASName'][-4:]
        if ASNamesuffix in qrybasicInfoMap.keys():
            mapTmp.update(qrybasicInfoMap[ASNamesuffix])
        vLine = sbasicCode % mapTmp
        sTextAS += vLine + '\n'

        # DefaultImports
        for dfimport in defaultImports:
            sLine = '''      <stdFieldQuote name="%s" flag="D" comment=""/>''' % dfimport
            sText += sLine + '\n'
            sTextAS += sLine + '\n'

        # Imports
        excludes = excludeImportMap.get(fcnType, excludeImportMap['default'])
        exports = exportMap[phaseFlag].get(fcnType, exportMap[phaseFlag]['default'])
        extras = extraImportMap[phaseFlag]['LS'].get(
            fcnType, extraImportMap[phaseFlag]['LS']['default'])
        imports = []
        macro_std = []
        if phaseFlag == 'p1':
            imports = TableInfoMapAll[fcninfomap['tableName']]['name']
        elif phaseFlag == 'p2':
            if fcninfomap['tableName'] in BopInfoMapAll.keys():
                Bops = BopInfoMapAll[fcninfomap['tableName']]
                for bop in Bops.values():
                    if fcninfomap['objectId'] in (bop['objectId'], bop['HISobjectId']):
                        imports += bop['qryname'].split(sMergedBar)
                        break
            else:
                print('SheetBop查询 查询字段缺失 导入表结构索引字段')
                for column in TableInfoMapAll[fcninfomap['tableName']]['columnNames']:
                    imports += column.split(',')
            macro_std += imports
        else:
            sys.exit('意料之外的模块和所属工程周期')

        imports = list(set(imports) - set(defaultImports) - set(excludes) - set(exports)
                       | set(extras))
        extrasAS = extraImportMap[phaseFlag]['AS'].get(
            fcnType, extraImportMap[phaseFlag]['AS']['default'])
        importsAS = list(set(imports) | set(extrasAS))
        for stdfield, stdfieldAS in zip(imports, importsAS):
            strField = '''      <stdFieldQuote name="%s" flag="" comment=""/>'''
            sLine = strField % stdfield
            sLineAS = strField % stdfieldAS
            sText += sLine + '\n'
            sTextAS += sLineAS + '\n'

        vLine = '''    </import>
    <export>'''
        sText += vLine + '\n'
        sTextAS += vLine + '\n'

        # Exports
        for export in exports:
            sLine = '''      <stdFieldQuote name="%s" flag="" comment=""/>''' % export
            sText += sLine + '\n'
            sTextAS += sLine + '\n'

        vLine = '''    </export>
    <variable>'''
        sText += vLine + '\n'
        sTextAS += vLine + '\n'

        # Varibales
        if fcnType != 'qry' or phaseFlag != 'p1':
            variables = variableMap[phaseFlag]
            if variables:
                for varmap in variables:
                    sLine = '''      <variableField name="%(name)s" type="%(type)s" dv="%(dv)s" cname="%(cname)s" desc="%(desc)s"/>''' % varmap
                    sTextAS += sLine + '\n'
            else:  # p1
                for var in importsAS:
                    if var in StdInfoMapAll.keys():
                        varMapTmp = StdInfoMapAll[var]
                    else:
                        varMapTmp = ReadHSStdfieldMap[var]
                        varMapTmp['dv'] = ''
                    sLine = '''      <variableField name="%(name)s_t" type="%(type)s" dv="%(dv)s" cname="%(cname)s" desc="%(desc)s"/>''' % varMapTmp
                    sTextAS += sLine + '\n'

        vLine = '''    </variable>
  </parameter>
  <extend/>
  <code>'''
        sText += vLine + '\n'
        sTextAS += vLine + '\n'

        # moduleIdCheck
        vLine = moduleidCheckMap.get(fcninfomap['module_id'], moduleidCheckMap['default']) % {
            'module_id': fcninfomap['module_id']}
        if fcninfomap['账户公用校验'] == 'Y':
            vLine = vLine.replace('用户公用', '账户公用')
        sText += vLine + '\n'

        # LS Code
        codeMapTmp = {
            'ASName': _CategoryInfoMap['AS']['ASName'],
            'action_in': action_inMap[fcnType]
        }
        if fcnType in ['mod', 'add']:
            try:
                codeMapTmp.update(ArchInfoMapAll[englishName])
            except KeyError as msg:
                print('KeyError:' + str(msg))
                print('sheet档案增加 无此服务名条目')
            except:
                print('未知错误')
                raise
        vLine = LS_CodeMap[phaseFlag].get(fcnType, LS_CodeMap[phaseFlag]['default']) % codeMapTmp
        sText += vLine + '\n'

        AScodeMapTmp = {'tableName': fcninfomap['tableName'],
                        'CNtableName': TableInfoMapAll[fcninfomap['tableName']]['CNtableName']}
        if phaseFlag == 'p1':
            if fcnType in AS_CodeMap[phaseFlag].keys():
                if fcnType == 'qry':  # 日后修改或加入其他key
                    vLine = AS_CodeMap[phaseFlag]['qry'].get(ASNamesuffix, AS_CodeMap[phaseFlag]['qry']['default'])
                else:
                    vLine = AS_CodeMap[phaseFlag][fcnType] % AScodeMapTmp
            else:  # default
                AScodeAttriTmp = {'importsList': '', 'varsList': '', 'IFList': '', 'SETList': ''}
                for index, impor in enumerate(importsAS):
                    AScodeAttriTmp['importsList'] += impor
                    AScodeAttriTmp['varsList'] += '@' + impor + '_t'
                    AScodeAttriTmp['IFList'] += '''        if @%(impor)s_t &lt;&gt; @%(impor)s then
              @remark := @remark || '[%(impor)s=' || @%(impor)s_t || '-&gt;' || @%(impor)s || ']';
            end if;
            \n''' % {'impor': impor}
                    AScodeAttriTmp['SETList'] += '''%(impor)s = @%(impor)s''' % {'impor': impor}
                    if index != len(importsAS) - 1:
                        AScodeAttriTmp['importsList'] += ','
                        AScodeAttriTmp['varsList'] += ','
                        AScodeAttriTmp['SETList'] += ',\n                 '
                        if index != 0 and index % 3 == 0:
                            AScodeAttriTmp['importsList'] += '\n          '
                            AScodeAttriTmp['varsList'] += '\n          '
                AScodeAttriTmp['IFList'] = AScodeAttriTmp['IFList'].lstrip()
                AScodeAttriTmp['macro'] = CnstInfoMapAll[fcninfomap['tableName']]['macro'].split('(')[1].split(')')[0]
                AScodeAttriTmp['business_flagadd'] = BusInfoMapAll[englishName]['add']['business_flag']
                AScodeAttriTmp['remarkadd'] = BusInfoMapAll[englishName]['add']['remark']
                AScodeAttriTmp['CNtableNameJouradd'] = BusInfoMapAll[englishName]['add']['CNtableName']
                AScodeAttriTmp['tableNameJouradd'] = BusInfoMapAll[englishName]['add']['tableName']
                AScodeAttriTmp['tableNameJouraddU'] = BusInfoMapAll[englishName]['add']['tableName'].replace('acct',
                                                                                                             'a').upper()

                AScodeAttriTmp['business_flagdel'] = BusInfoMapAll[englishName]['del']['business_flag']
                AScodeAttriTmp['remarkdel'] = BusInfoMapAll[englishName]['del']['remark']
                AScodeAttriTmp['CNtableNameJourdel'] = BusInfoMapAll[englishName]['del']['CNtableName']
                AScodeAttriTmp['tableNameJourdel'] = BusInfoMapAll[englishName]['del']['tableName']
                AScodeAttriTmp['tableNameJourdelU'] = BusInfoMapAll[englishName]['del']['tableName'].replace('acct',
                                                                                                             'a').upper()

                AScodeAttriTmp['business_flagmod'] = BusInfoMapAll[englishName]['mod']['business_flag']
                AScodeAttriTmp['remarkmod'] = BusInfoMapAll[englishName]['mod']['remark']
                AScodeAttriTmp['CNtableNameJourmod'] = BusInfoMapAll[englishName]['mod']['CNtableName']
                AScodeAttriTmp['tableNameJourmod'] = BusInfoMapAll[englishName]['mod']['tableName']
                AScodeAttriTmp['tableNameJourmodU'] = BusInfoMapAll[englishName]['mod']['tableName'].replace('acct',
                                                                                                             'a').upper()

                AScodeMapTmp.update(AScodeAttriTmp)

                vLine = AS_CodeMap[phaseFlag]['default'] % AScodeMapTmp
        elif phaseFlag == 'p2':
            p_str = fcninfomap['p_str']
            AScodeMapTmp['p_str'] = p_str
            if 'oper_branches' in importsAS:
                AScodeMapTmp.update(AS_CodeMap[phaseFlag]['oper_branches'][fcninfomap['modulename']])
            else:
                AScodeMapTmp['statement_oper_branches'] = ''
            p_strMap: Dict[str, Union[Dict[Tuple[str, str], str], str, Dict[str, str]]] = AS_CodeMap[phaseFlag][
                'p_str'].get(p_str, AS_CodeMap[phaseFlag]['p_str']['default'])
            for _ in p_strMap['statement_position_str0'].keys():
                if fcninfomap['moduleName'] in _:
                    AScodeMapTmp['statement_position_str0'] = p_strMap['statement_position_str0'][_].format(
                        **AScodeMapTmp)
                    break
            AScodeMapTmp['statement_position_str1'] = p_strMap['statement_position_str1'].format(**AScodeMapTmp)
            statement_position_str2 = p_strMap['statement_sort_name']['statement_position_str2'].format(**AScodeMapTmp)
            AScodeMapTmp['statement_sort_name'] = p_strMap['statement_sort_name']['main'].format(
                **{'statement_position_str2': statement_position_str2, 'p_str': p_str})
            macro_stdqry = ''
            for _ in AS_CodeMap[phaseFlag]['macro_stdqry'].keys():
                if fcninfomap['moduleName'] in _:
                    macro_std = list(set(macro_std) - set(AS_CodeMap[phaseFlag]['macro_stdqry'][_]))
            for std in macro_std:
                if std[:3] == 'en_':
                    std2nd = std[3:]
                    _HsType2nd = ReadHSStdfieldMap[std2nd]['type']
                    CType2nd = ReadHSDataTypeMap[_HsType2nd]['c'].lower()
                else:
                    std2nd = std
                    _HsType2nd = ReadHSStdfieldMap[std2nd]['type']
                    CType2nd = ReadHSDataTypeMap[_HsType2nd]['c'].lower()
                if 'char[' in CType2nd:
                    CType2nd = 'string'
                macro_stdqry += macro_stdqryMap.get(std[:3], macro_stdqryMap['default'])[CType2nd].format(std, std2nd)
                macro_stdqry += '\n  '
            AScodeMapTmp['macro_stdqry'] = macro_stdqry
            vLine = AS_CodeMap[phaseFlag]['main'].format(**AScodeMapTmp)
        sTextAS += vLine + '\n'

        vLine = '''  </code>
  <ModifyLog>
  </ModifyLog>
  <test/>
</hsdoc>'''
        sText += vLine + '\n'
        sTextAS += vLine + '\n'

        wFile = open(sfilepath, 'w', encoding='UTF-8', newline='\n')
        wFileAS = open(sfilepathAS, 'w', encoding='UTF-8', newline='\n')
        wFile.write(sText)
        wFileAS.write(sTextAS)
        wFile.close()
        wFileAS.close()
        print('成功生成文件：\n' + sfilepath.replace('\\', '/') + '\n' + sfilepathAS.replace('\\', '/') + '\n')


def BuildTableStructFiles():
    for mapTmp2 in TableInfoMapAll.values():
        sText = ''
        sModulePath = findModulePath(mapTmp2['moduleName'], ['TAB'])
        sSavePathTmp = sModulePath['TAB'][:-1] + mapTmp2['CNtableName'] + '.table_design'

        vLine = '''<?xml version="1.0" encoding="UTF-8"?>

<hsdoc version="1.1.0">
  <tablePrimaryInfo id="%(id)s" version="%(version)s" tableName="%(tableName)s" schema="%(schema)s" indexSchema="%(indexSchema)s" historySchema="%(historySchema)s" historyIndexSchema="%(historyIndexSchema)s" configString="%(configString)s" history="%(history)s" sett="%(sett)s" rtable="%(rtable)s" partition_field="%(partition_field)s" partition_amount="%(partition_amount)s" partition_date="%(partition_date)s" cur_partition="%(cur_partition)s" currentTableNeedPartition="%(currentTableNeedPartition)s" tableType="%(tableType)s"></tablePrimaryInfo>''' \
                % mapTmp2
        sText += vLine + '\n'

        for index in range(len(mapTmp2['name'])):
            sLine = '''  <tablefield flag="%(flag)s" name="%(name)s" cannull="%(cannull)s" isprimary="%(isprimary)s" comment="%(comment)s"/>''' % {
                'flag': mapTmp2['flag'][index],
                'name': mapTmp2['name'][index],
                'cannull': mapTmp2['cannull'][index],
                'isprimary': mapTmp2['isprimary'][index],
                'comment': mapTmp2['comment'][index]
            }
            sText += sLine + '\n'

        for index in range(len(mapTmp2['name2'])):
            sLine = '''  <tableIndex flag="%(flag2)s" name="%(name2)s" unique="%(unique)s" cluster="%(cluster)s" columnNames="%(columnNames)s" reverse="%(reverse)s"/>''' % {
                'flag2': mapTmp2['flag2'][index],
                'name2': mapTmp2['name2'][index],
                'unique': mapTmp2['unique'][index],
                'cluster': mapTmp2['cluster'][index],
                'columnNames': mapTmp2['columnNames'][index],
                'reverse': mapTmp2['reverse']
            }
            sText += sLine + '\n'

        vLine = '''  <relatingRoot/>
  <ModifyLog>'''
        sText += vLine + '\n'

        for index in range(len(mapTmp2['Modify'])):
            logs = mapTmp2['Modify'][index][0].split('||')
            modifyTmps = mapTmp2['Modify'][index][1].split('\n')
            modifyinfos = []
            for mod in modifyTmps:
                if '<modifyinfo' in mod:
                    modifyinfos.append(mod.strip())
                    modifyinfos.append(modifyTmps[modifyTmps.index(mod) + 1].strip())
                    break
            sLine = '''    <log>
      <position></position>
      <date>%(log0)s</date>
      <version>%(log1)s</version>
      <serialNumber>%(log2)s</serialNumber>
      <user>%(log3)s</user>
      <principal>%(log4)s</principal>
      <cause>%(log5)s</cause>
      <content>%(log6)s</content>
      <tester></tester>
      %(modifyinfo0)s
        %(modifyinfo1)s
      </modifyinfo>
    </log>''' % {
                'log0': logs[0],
                'log1': logs[1],
                'log2': logs[2],
                'log3': logs[3],
                'log4': logs[4],
                'log5': logs[5],
                'log6': logs[6],
                'modifyinfo0': modifyinfos[0],
                'modifyinfo1': modifyinfos[1]

            }
            sText += sLine + '\n'

        vLine = '''  </ModifyLog>
</hsdoc>'''
        sText += vLine + '\n'

        wFile = open(sSavePathTmp, 'w', encoding='UTF-8', newline='\n')
        wFile.write(sText)
        wFile.close()
        print('表结构：成功生成文件：' + sSavePathTmp.replace('\\', '/'))


def BuildBopFiles():
    for bopinfokey in BopInfoMapAll.keys():
        if bopinfokey in TableInfoMapAll.keys():
            bopinfomap: dict = BopInfoMapAll[bopinfokey]
            fieldnameXmlMap = {}
            for typeinfomap in bopinfomap.values():
                def buildFcnxml():
                    sText = ''
                    vLine = '''<?xml version="1.0" encoding="GBK"?>
<Function functionid="%(objectId)s"  hisFunctionId="%(HISobjectId)s"  postrInterceptor="">
    <Condition>''' % typeinfomap
                    sText += vLine + '\n'

                    qrynameList: List[str] = typeinfomap['qryname'].split(sMergedBar)
                    qryfieldText = typeinfomap['fieldText'].split(sMergedBar)
                    qryverify = typeinfomap['verify'].split(sMergedBar)
                    for qryname, fieldText, verify in zip(qrynameList, qryfieldText, qryverify):
                        if qryname.startswith('en_'):
                            _type = 'combox_multi'
                        else:
                            try:
                                stdmap = StdInfoMapAll.get(qryname, ReadHSStdfieldMap[qryname])
                            except KeyError as msg:
                                print('KeyError:' + str(msg))
                                print('意料之外的字段名')
                                raise
                            if stdmap['type'] in ['HSDate', 'HsDateTime']:
                                _type = 'calendar'
                            elif stdmap['dict'].strip() not in ['', '0']:
                                _type = 'combox'
                            else:
                                _type = 'textfield'
                        sLine = f'''        <ConditionField dict="" fieldText="{fieldText}" interceptor="" interceptorJavaScriptFunction="" range="" verify="{verify}" type="{_type}">{qryname}</ConditionField>'''
                        sText += sLine + '\n'

                    vLine = '''    </Condition>
        <Upper interceptor="">'''
                    sText += vLine + '\n'

                    sConfigField = ''
                    for name in TableInfoMapAll[bopinfokey]['name']:
                        try:
                            stdmap = StdInfoMapAll.get(name, ReadHSStdfieldMap[name])
                        except KeyError as msg:
                            print('KeyError:' + str(msg))
                            print('意料之外的字段名')
                            raise
                        sLine = f'''        <ConfigField detail="{stdmap['cname']}" show="true" fieldText="" color="" order="1" width="100" hieght="" align="0" interceptJavaSriptFunction="" dict="">{name}</ConfigField>'''
                        sXmlLine = f'''    <FieldItem english_name="{name}" entry_name="{stdmap['cname']}" dict_entry="{stdmap['dict']}"/>  '''
                        fieldnameXmlMap[name] = sXmlLine
                        sConfigField += sLine + '\n'
                        sText += sLine + '\n'

                    vLine = '''    </Upper>
        <Lower interceptor="" cols="0">'''
                    sText += vLine + '\n'

                    sText += sConfigField

                    vLine = '''    </Lower>
    <Total>
        <GrouopBys>
        </GrouopBys>
        <TotalFields>
        </TotalFields>
    </Total>
    <Print>
    </Print>
</Function>'''
                    sText += vLine + '\n'

                    sfilepath = sBopRootPath + '/function/' + typeinfomap['objectId'] + '.xml'
                    wFile = open(sfilepath, 'w', encoding='GBK')
                    wFile.write(sText)
                    wFile.close()
                    print('Bop：成功生成文件：' + sfilepath + '\n')

                def buildMenuxml():
                    sfilepath = sBopRootPath + '/menu/' + MenutypeXmlMap[typeinfomap['qryType']] + '.xml'
                    sText, sEncoding = tools.LoadSrcCode(sfilepath)
                    bComment = False
                    bMenu = False
                    sMaxOrder = '0'
                    sWriteText = ''
                    for index, sLine in enumerate(sText):
                        if '<!--' in sLine:
                            bComment = True
                        if '-->' in sLine:
                            bComment = False
                        sLineTmp = sLine.split('-->')[-1].strip()
                        if not bComment and '<Menu id="' + typeinfomap['menu_id'] + '"' in sLine:
                            bMenu = True
                        if bMenu:
                            if '<SubMenu' in sLineTmp:
                                sfcnId = re.search(reMatchBopFcnId, sLine).group(1)
                                if sfcnId == typeinfomap['objectId']:
                                    print('Bop：menu文件夹' + MenutypeXmlMap[
                                        typeinfomap['qryType']] + '.xml文件中记录功能号' + sfcnId + '已存在')
                                    break
                                sid = re.search(reMatchBopId, sLine).group(1)
                                sorder = re.search(reMatchBopOrder, sLine).group(1)
                                if sid.startswith(typeinfomap['menu_id']):
                                    sMaxOrder = max(sMaxOrder, sorder)
                            if sLine.expandtabs().strip() == '</Menu>':
                                _order = str(int(sMaxOrder) + 1)
                                _id = typeinfomap['menu_id'] + _order
                                _functionId = typeinfomap['objectId']
                                _text = typeinfomap['text']
                                vLine = f'''        <SubMenu id="{_id}" order="{_order}" show="true" functionId="{_functionId}" text="{_text}">
        <DefaultParams>
        </DefaultParams>
    </SubMenu>'''
                                sWriteText += vLine + '\n'
                                break

                        sWriteText += sLine + '\n'
                    for sLine in sText[index:]:
                        sWriteText += sLine + '\n'
                    else:
                        wFile = open(sfilepath, 'w', encoding=sEncoding)
                        wFile.write(sWriteText)
                        wFile.close()
                        print('Bop：menu文件夹' + MenutypeXmlMap[
                            typeinfomap['qryType']] + '.xml文件中记录功能号' + typeinfomap['objectId'] + '执行完成')

                buildFcnxml()
                buildMenuxml()

            sText, sEncoding = tools.LoadSrcCode(sBopfieldnameXmlPath)
            bComment = False
            bFieldItems = False
            sWriteText = ''
            for index, sLine in enumerate(sText):
                if '<!--' in sLine:
                    bComment = True
                if '-->' in sLine:
                    bComment = False
                sLineTmp = sLine.split('-->')[-1].strip()
                if not bComment and '<FieldItems>' in sLine:
                    bFieldItems = True
                if not bComment and bFieldItems:
                    if not fieldnameXmlMap:
                        break
                    if '<FieldItem english_name=' in sLineTmp:
                        enname = re.search(reMatchBopENname, sLineTmp).group(1)
                        fieldnameXmlMap.pop(enname, 0)
                if '</FieldItems>' in sLineTmp:
                    for field in fieldnameXmlMap.values():
                        sWriteText += field + '\n'
                sWriteText += sLine + '\n'

            for sLine in sText[index:]:
                sWriteText += sLine + '\n'
            else:
                wFile = open(sBopfieldnameXmlPath, 'w', encoding=sEncoding)
                wFile.write(sWriteText)
                wFile.close()
                print('\nBop：前端标准字段库新增字段：' + str(fieldnameXmlMap.keys()))


def readSheetFillMap(excel):
    global bBuildBopFiles
    print('读取Sheet并填充')

    sheetFcn = excel[sExcelSheet[1]]
    sheetBus = excel[sExcelSheet[2]]
    sheetArch = excel[sExcelSheet[3]]
    sheetStd = excel[sExcelSheet[4]]
    sheetCnst = excel[sExcelSheet[5]]
    sheetBop = excel[sExcelSheet[6]]

    readTableStruct(excel)
    readSheet(sheetFcn, ExcelFcnMap, 2, FcnInfoMapAll, 'englishName')
    readSheet(sheetBus, ExcelBusMap, 2, BusInfoMapAll, 'englishName', 'busType')
    readSheet(sheetArch, ExcelArchMap, 2, ArchInfoMapAll, 'englishName')
    readSheet(sheetStd, ExcelStdMap, 2, StdInfoMapAll, 'name')
    readSheet(sheetCnst, ExcelCnstMap, 2, CnstInfoMapAll, 'tableName')
    readSheet(sheetBop, ExcelBopMap, 2, BopInfoMapAll, 'tableName', 'qryType')
    print('读取完成\n')

    if sheetBop['B1'].value == 'Y':
        bBuildBopFiles = True


def BuildOptionalFiles():
    if bBuildFiles:
        BuildTableStructFiles()
    # Bop
    if bBuildBopFiles:
        BuildBopFiles()


def Multi_init():
    totalThread = 4  # 控制输出功能目录条目文件的线程数
    threads = [Thread(target=BuildOptionalFiles)]  # 创建线程列表
    totalThread -= 1
    lenFcnAll = len(FcnInfoMapAll)  # 列表的总长度
    if totalThread > lenFcnAll:
        totalThread = lenFcnAll
    gap = int(lenFcnAll / totalThread)  # 列表分配到每个线程的执行数
    FcnAllList = list(FcnInfoMapAll.values())
    # 创建新线程和添加线程到列表
    for i in range(totalThread):
        if i == 0:
            thread = Thread(target=BuildFunctionFiles, args=(FcnAllList[:gap],))
        elif totalThread == i + 1:
            thread = Thread(target=BuildFunctionFiles, args=(FcnAllList[i * gap:],))
        else:
            thread = Thread(target=BuildFunctionFiles, args=(FcnAllList[i * gap:(i + 1) * gap],))
        threads.append(thread)  # 添加线程到列表

    # 循环开启线程
    for t in threads:
        t.setDaemon(True)
        t.start()
    for t in threads:
        t.join()

    print("Exiting Main Thread")


def BuildCode():
    global ReadHSStdfieldMap
    global ReadHSDataTypeMap
    global sExcelPath
    global sRootPath
    global sStdfieldsPath
    global sFiledTypePath
    sExcelPath = sExcelPath.replace('\\', '/')
    sRootPath = sRootPath.replace('\\', '/')
    sStdfieldsPath = sRootPath + '/公共资源/stdfields.xml'
    sFiledTypePath = sRootPath + '/公共资源/datatypes.xml'
    excel = openpyxl.load_workbook(sExcelPath)
    DefaultInfoMap['updateDate'] = time.strftime("%Y%m%d", time.localtime())
    ReadHSStdfieldMap = rstds.ReadHSStdfield(sStdfieldsPath)
    ReadHSDataTypeMap = rftype.ReadHSDataType(sFiledTypePath)
    readSheetFillMap(excel)
    Multi_init()


if __name__ == '__main__':
    BuildCode()
