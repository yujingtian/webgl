# 本文件用来生成dalphi版的统一网关对接短信平台代码
import tools
import json
import os
import datetime
import shutil
from pathlib import Path

sysValList = ['timestamp', 'msg', 'phone']

sTimeStampDemo = '''\
function getTimeStamp: string;
var
  SysTime: TsystemTime;
  timen, time2: TDateTime;
  ss2, ss3: int64;
  str2: string;
begin
  GetLocalTime(SysTime);
  timen := SystemTimeToDateTime(SysTime);
  time2 := EncodeDateTime(1970, 1, 1, 0, 0, 0, 0);
  ss2 := 28800000;
  ss3 := MilliSecondsBetween(timen, time2);
  ss3 := ss3 - ss2;
  str2 := IntToStr(ss3);
  Result := str2;
end;
'''

sDecodeUnicodeStringDemo = '''\
function DecodeUnicodeString(const S: string): string;
var
  buf: array[0..4] of Char;
  i: Integer;
  Ch, PvCh: Char;
  US: string;
  Str: string;
begin
  Result := '';
  ZeroMemory(@buf[0], SizeOf(buf));
  i := 1;
  while i < Length(S) do
  begin
    Ch := S[i];
    if (Ch = 'u') and (i > 1) then
    begin
      PvCh := S[i - 1];
      if PvCh = '\\' then
      begin
        US := Copy(S, i + 3, 2) + Copy(S, i + 1, 2);
        HexToBin(PChar(US), buf, 2);
        Str := WideCharToString(@buf[0]);
        Result := Copy(Result, 1, Length(Result) - 1); // drop "\\"
        Result := Result + Str;
        Inc(i, 5);
        Continue;
      end;
    end;
    Inc(i, 1);
    Result := Result + Ch;
  end;
end;
'''

sHsUFGDemo = '''\
<?xml version="1.0" encoding="gb2312"?>
<hsufg>
	<!-- sysloglevel 日志级别:0-调试 1-提示 2-告警 3-错误 4-异常，程序输出大于等于sysloglevel的日志-->
	<!-- registerway 注册方式:0-注册后台程序状态表和消息中心 1-只注册后台程序状态表 2-只注册消息中心-->
	<!-- thread 业务线程数: 默认值为5 -->
	<main>
		<sysloglevel>0</sysloglevel>
		<registerway>1</registerway>
		<thread>5</thread>
		<plugins>
			<file>E:\\WorkSpace\\hstrade20\\trunk\\tywg\\HsClient\\Trade\\Biz\\%(name)s.dll</file></plugins>
	</main>
	<plugin name="%(name)s" note="%(name)s.dll配置">
		<url note="网关服务器">http://192.168.171.180:7777/%(inteface)s</url>
		<!--begin Request 配置 注意大小写要正确-->
		<RequestContentType note="ContentType">application/json</RequestContentType>
		<RequestAccept note="Accept">text/html, application/xhtml+xml, */*</RequestAccept>
		<RequestAcceptCharSet note="Accept">UTF-8</RequestAcceptCharSet>
%(config)s		<!--end Request 配置-->
		<RequestSysFlag note="系统标识">HS_Moniter_Out</RequestSysFlag>
		<begintime note="开始时间">80001</begintime>
		<endtime note="结束时间">235959</endtime>
		<alternation note="时间间隔,300000毫秒/5分钟">10000</alternation>
		<repeatnum note="错误重发次数">5</repeatnum>
	</plugin>
</hsufg>
'''


# 获取配置文件中的变量
def GetVal(sHttpJson):
    sValListMap = {}
    sAllList = []
    sMd5Key = {}
    sMd5Filed = []
    sMd5FiledMap = {}
    sListKey = {}
    intefaceList = sHttpJson['intefaceList']
    for intefaceItem in intefaceList:
        for itemInfo in intefaceList[intefaceItem]:
            if str(intefaceList[intefaceItem][itemInfo]).find('@') >= 0:
                sValKey = intefaceList[intefaceItem][itemInfo]
                if sValKey[:1] == '@':
                    sValKey = sValKey[1:]
                    if sValKey not in sValListMap and sValKey not in sysValList and len(
                            sValKey) > 0:
                        sValListMap[sValKey] = itemInfo
                    if sValKey not in sAllList:
                        sAllList.append(sValKey)
                elif sValKey[:4] == 'md5[':  #md5加密
                    sMd5Key[intefaceItem] = itemInfo
                    sValStr = sValKey[4:-1]
                    sValKeyList = str(sValStr).split(',')
                    for sValKey in sValKeyList:
                        if sValKey[:1] == '@':
                            sValKey = sValKey[1:]
                        if sValKey not in sMd5Filed:
                            sMd5Filed.append(sValKey)
                        if sValKey not in sValListMap and sValKey not in sysValList and len(
                                sValKey) > 0:
                            sValListMap[sValKey] = itemInfo
                        if sValKey not in sAllList:
                            sAllList.append(sValKey)
                    sMd5FiledMap[itemInfo] = sMd5Filed
                elif type(sValKey) is list:  #循环list
                    sListKey[intefaceItem] = itemInfo
                    sValMap = sValKey[0]
                    for sKey in sValMap:
                        sValKey = sValMap[sKey]
                        if sValKey[:1] == '@':
                            sValKey = sValKey[1:]
                            if sValKey not in sValListMap and sValKey not in sysValList and len(
                                    sValKey) > 0:
                                sValListMap[sValKey] = itemInfo
                            if sValKey not in sAllList:
                                sAllList.append(sValKey)
    return sValListMap, sMd5Key, sListKey, sAllList, sMd5FiledMap


# 生成dpr文件
def CreateDpr(sHttpJson, sXmlKeyMap, sDemoDir, sCodeOutDir):
    sName = sHttpJson['name']
    print('开始处理dpr文件:' + sName + '.dpr')
    sDllName = sName + '.dll'
    sCustName = sHttpJson['custName']
    sDeveloper = sHttpJson['developer']
    sDprPath = sDemoDir + 'g_dc_MessageHttp.dpr'
    sText, sEncoding = tools.LoadSrcCode(sDprPath)
    isStart = False
    with open(sCodeOutDir + sName + '.dpr', 'w', encoding=sEncoding) as wFile:
        for sLine in sText:
            if sLine == '程序名称：':
                sLine = sLine + ' ' + sDllName + ' ' + sCustName + '短信发送'
            elif sLine == '功能说明：':
                sLine = sLine + ' ' + '对接' + sCustName + 'HTTP协议平台'
            elif sLine == '编写时间：':
                sLine = sLine + ' ' + datetime.date.today().strftime(
                    '%Y-%m-%d')
            elif sLine == '编写人  ：':
                sLine = sLine + ' ' + sDeveloper
            elif sLine == 'library g_dc_MessageHttp;':
                sLine = 'library ' + sDllName.replace('.dll', ';')
            elif "GetNodeValue(xnHSNode, 'RequestSysFlag', RequestSysFlag);" in sLine:
                isStart = True
            elif 'g_dc_MessageHttp' in sLine:
                sLine = sLine.replace('g_dc_MessageHttp',
                                      sDllName.replace('.dll', ''))
            elif isStart:
                isStart = False
                wFile.write('\n')
                for sValKey in sXmlKeyMap:
                    wFile.write("  GetNodeValue(xnHSNode, '%s', %s);\n" %
                                (sValKey, sValKey))
            wFile.write(sLine + '\n')


# 生成untDataModule.pas
def CreateUntDataModule(sHttpJson, sDemoDir, sCodeOutDir):
    print('开始处理:untDataModule.pas')
    sCustName = sHttpJson['custName']
    sPasPath = sDemoDir + 'untDataModule.pas'
    sText, sEncoding = tools.LoadSrcCode(sPasPath)
    with open(sCodeOutDir + 'untDataModule.pas', 'w',
              encoding=sEncoding) as wFile:
        for sLine in sText:
            if "WriteSysLog(Format('http短信成功获取信息记录 %d 条', [BizUnpacker.RowCount]), lvlDebug);" in sLine:
                sLine = sLine.replace('http短信成功获取信息',
                                      sCustName + 'http短信成功获取信息')
            wFile.write(sLine + '\n')


# 生成untSHEntry.pas
def CreateUntSHEntry(sHttpJson, sXmlKeyMap, sDemoDir, sCodeOutDir, sAllList,
                     sMd5Key, sListKey, sMd5FiledMap):
    print('开始处理:untSHEntry.pas')
    sPasPath = sDemoDir + 'untSHEntry.pas'
    sText, sEncoding = tools.LoadSrcCode(sPasPath)
    isStd = False
    isWideToUTF8 = False
    isVar = True
    isGetDcPostJsonInfo = False
    with open(sCodeOutDir + 'untSHEntry.pas', 'w',
              encoding=sEncoding) as wFile:
        for sLine in sText:
            if 'var' == sLine:
                isVar = False
            if sLine == '  RequestSysFlag: String;':
                isStd = True
            elif sLine == "        ';SendResult=' + sSendResult + ';', lvlDebug);":
                sLine = "        ';SendResult=' + DecodeUnicodeString(sSendResult) + ';', lvlDebug);"
            elif sLine == "      AErroInfo := SuperObjec.O['message'].AsString;":
                sLine = sLine.replace("message", sHttpJson['ErroInfo'])
            elif sLine == "      if SuperObjec.O['success'].AsBoolean then":
                successMap = sHttpJson['success']
                if len(successMap) > 0:
                    for sSucessFiled in successMap:
                        sLine = "      if SuperObjec.O['%s'].AsString = '%s' then" % (
                            sSucessFiled, successMap[sSucessFiled])
            elif sLine == "      ppv^.Version := '20180930';":
                sLine = "      ppv^.Version := '%s';" % (
                    datetime.date.today().strftime('%Y%m%d'))
            elif sLine == "      ppv^.Caption := '山西HTTP协议短信发送';":
                sLine = sLine.replace('山西', sHttpJson['custName'])
            elif 'function CheckUnIntStr(AStr: String): Boolean;' in sLine:
                wFile.write(sDecodeUnicodeStringDemo + '\n')
                if 'timestamp' in sAllList:
                    wFile.write(sTimeStampDemo + '\n')
            elif '      sDataStr := GetDcPostJsonInfo(RequestSysFlag, sMobile, sCAddr, sContext);' in sLine:
                sLine = sLine.replace('RequestSysFlag', sValKeyStr)
            elif ',SyncObjs;' in sLine:
                sLine = sLine.replace('SyncObjs;',
                                      'SyncObjs, DateUtils, Dialogs;')
            elif 'function GetDcPostJsonInfo(ASysFlag, AMobile, ACAddr, AContext: String): String;' in sLine:
                isGetDcPostJsonInfo = True
                sValKeyStr = ''
                sVarStr = ''
                sValLine = ''
                sMd5FiledList = []
                for sValKey in sXmlKeyMap:
                    sValKeyStr = sValKeyStr + ', ' + sValKey
                sValKeyStr = sValKeyStr[2:]

                for sIntefaceName in sHttpJson['intefaceList']:
                    if 'timestamp' in sHttpJson['intefaceList'][sIntefaceName]:
                        sValLine = sValLine + "    sTimestamp := getTimeStamp();\n"

                    for sValKey in sHttpJson['intefaceList'][sIntefaceName]:
                        if sValKey == 'timestamp':
                            sValLine = sValLine + "    TempJson.S['timestamp'] := Trim(sTimestamp);\n"
                        elif sValKey in sMd5FiledMap:  #处理MD5加密
                            sMd5Cale = '    sMd5Src := '
                            for smd5Filed in sMd5FiledMap[sValKey]:
                                if smd5Filed == 'timestamp':
                                    smd5Filed = 'sTimestamp'
                                sMd5Cale = sMd5Cale + 'trim(%s) +' % (
                                    smd5Filed)
                            sValLine = sValLine + sMd5Cale[:-2] + ';\n'
                            sValLine = sValLine + '    %s := StrToMD5(sMd5Src);\n' % (
                                's' + str(sValKey[:1]).upper() + sValKey[1:])
                            sValLine = sValLine + "    TempJson.S['%s'] := Trim(%s);\n" % (
                                sValKey,
                                's' + str(sValKey[:1]).upper() + sValKey[1:])
                        elif sIntefaceName in sListKey:
                            if sValKey in sListKey[sIntefaceName]:  #处理List

                                sListJG = str(sHttpJson['intefaceList']
                                              [sIntefaceName][sValKey][0])
                                sOrderJG = ''
                                sAddOrderJG = ''
                                if '@msg' in sListJG and '@phone' in sListJG:
                                    if sListJG.find('@msg') < sListJG.find(
                                            '@phone'):
                                        sOrderJG = '[sMsg, sPhone]'
                                    else:
                                        sOrderJG = '[sPhone, sMsg]'
                                elif '@msg' in sListJG:
                                    sOrderJG = '[sMsg]'
                                elif '@phone' in sListJG:
                                    sOrderJG = '[sPhone]'
                                sAddOrderJG = sOrderJG.replace(
                                    'sPhone', 'tmpList[iLoop]')

                                sListJG = sListJG.replace(
                                    '@msg',
                                    '%%s').replace('@phone',
                                                   '%%s').replace("'", '"')

                                sValLine = sValLine + "\n    //处理" + sValKey + "\n\n"
                                sValLine = sValLine + '''\
    resultJson := TempJson.AsString;
    sPhone := Trim(AMobile);
    sMsg := StringReplace(Trim(AContext), #10#13, '', [rfReplaceAll]);

    tmpStr := '';
    tmpList := TStringList.Create;
    tmpList.Delimiter := ',';
    tmpList.DelimitedText := ACAddr;
    for iLoop := 0 to tmpList.Count - 1 do
    begin
      if Trim(tmpList.Strings[iLoop]) <> '' then
      begin
        tmpStr := tmpStr + ',' + Format('%s', %s);
      end;
    end;
    FreeAndNil(tmpList);
    tmpStr := ',"%s":[' + Format('%s', %s) + tmpStr + ']';
    resultJson := Copy(resultJson,0,Length(resultJson)-1)+tmpStr+'}';

    Result := resultJson;
    ''' % (sListJG, sAddOrderJG, sValKey, sListJG, sOrderJG)
                                sValLine = sValLine.replace('%%', '%')

                            else:
                                sValLine = sValLine + "    TempJson.S['%s'] := Trim(%s);\n" % (
                                    sValKey, sHttpJson['intefaceList']
                                    [sIntefaceName][sValKey][1:])
                        else:
                            if len(
                                    str(sHttpJson['intefaceList']
                                        [sIntefaceName][sValKey])) == 0:
                                sValLine = sValLine + "    TempJson.S['%s'] := '';\n" % (
                                    sValKey)
                            elif sValKey == 'phone':
                                sValLine = sValLine + '''\
    sPhone := Trim(AMobile);
    if Trim(ACAddr) <> '' then
    begin
      sPhone := Trim(ACAddr)+sPhone;
    end;
    TempJson.S['phone'] := Trim(sPhone);
'''
                            elif sValKey == 'msg':
                                sValLine = sValLine + '''\
    sMsg := StringReplace(Trim(AContext), #10#13, '', [rfReplaceAll]);
    TempJson.S['msg'] := Trim(sMsg);
'''
                            else:
                                sValLine = sValLine + "    TempJson.S['%s'] := Trim(%s);\n" % (
                                    sValKey, sHttpJson['intefaceList']
                                    [sIntefaceName][sValKey][1:])

                if sIntefaceName not in sListKey:
                    sValLine = sValLine + '\n    resultJson := TempJson.AsString;\n    Result := resultJson;'
                if len(sMd5Key) > 0:
                    sVarStr = sVarStr + 'sMd5Src'
                    for sintefaceName in sMd5Key:
                        sMd5FiledStd = sMd5Key[sintefaceName]
                        if sMd5FiledStd not in sMd5FiledList:
                            sMd5FiledList.append(sMd5FiledStd)
                            sVarStr = sVarStr + ', s' + str(
                                sMd5FiledStd[:1]).upper() + sMd5FiledStd[1:]

                if 'timestamp' in sAllList:
                    sVarStr = sVarStr + ', sTimestamp'

                if len(sVarStr) > 0:
                    sVarStr = '  ' + sVarStr + ': string;'

                if len(sListKey) > 0:
                    sVarStr = sVarStr + '''
  tmpStr: string;
  tmpList: TStringList;
  iLoop: Integer;'''

                vLine = '''\
function GetDcPostJsonInfo(%s, AMobile, ACAddr, AContext: string): string;
var
%s
  sMsg, sPhone , resultJson: string;
  sInfo : string;
  TempJson: ISuperObject;
begin
  Result := '';
  sInfo := '';
  try
    TempJson := SO();
%s
  except
    on e: Exception do
    begin
      sInfo := 'GetJsonInfoExcept:' + e.Message;
      WriteSysLog(sInfo, lvlWarning);
    end;
  end;
end;
''' % (sValKeyStr, sVarStr, sValLine)
                wFile.write(vLine + '\n')
                continue
            elif isGetDcPostJsonInfo and 'function GetDcSendJsonResult(AInfo: String; var AErroInfo: String): Integer;' in sLine:
                isGetDcPostJsonInfo = False
            elif 'function WideToUTF8(const WS: WideString): UTF8String;' in sLine and isVar:
                isWideToUTF8 = True
            elif isWideToUTF8:
                isWideToUTF8 = False
                if 'timestamp' in sAllList:
                    vLine = 'function getTimeStamp: string;'
                    wFile.write(vLine + '\n')
            elif isGetDcPostJsonInfo:
                continue
            elif isStd:
                isStd = False
                for sValKey in sXmlKeyMap:
                    if sValKey not in sysValList:
                        vLine = '  %s: string;' % (sValKey)
                        wFile.write(vLine + '\n')
                wFile.write(sLine + '\n')

            wFile.write(
                sLine.replace(' String;', ' string;').replace(
                    ' String)', ' string)').replace(
                        ' String ', ' string ').replace(' NOT', ' not') + '\n')


# 复制所有模板代码
def CopyALLCode(sHttpJson, sDemoDir, sCodeOutDir):
    sName = sHttpJson['name']
    for root, dirs, files in os.walk(sDemoDir):
        for fileName in files:
            sFilePath = root + '/' + fileName
            sFilePath = sFilePath.replace('\\', '/').replace('//', '/')
            print('生成' + fileName.replace('g_dc_MessageHttp', sName))
            shutil.copy(
                sFilePath,
                sCodeOutDir + fileName.replace('g_dc_MessageHttp', sName))


# 生成hsufg的参考xml
def CreateDEMOXml(sHttpJson, sCodeOutDir, sXmlKeyMap):
    print('生成hsufg的参考xml')
    for sintefaceName in sHttpJson['intefaceList']:
        break
    demoItem = {'name': sHttpJson['name'], 'inteface': sintefaceName}
    sConfig = ''
    for sKeyVal in sXmlKeyMap:
        sConfig = sConfig + '		<%(keyVal)s note="%(note)s">123456</%(keyVal)s>\n' % {
            'keyVal': sKeyVal,
            'note': sHttpJson['filedDesc'][sKeyVal]
        }
    demoItem['config'] = sConfig

    with open(sCodeOutDir + sHttpJson['custName'] + '统一网关短信接口示例hsufg.xml.txt',
              'w',
              encoding='gbk') as wFile:
        wFile.write(sHsUFGDemo % demoItem)


# 代码生成
def BuildCode(sOutDir: str, sHttpJson: map):
    sProjectPath = tools.getProjectPath()
    sDemoDir = sProjectPath.replace(
        '\\', '/') + '/codeFactory/codeDemo/delphi/messageHttp/'
    sXmlKeyMap, sMd5Key, sListKey, sAllList, sMd5FiledMap = GetVal(sHttpJson)
    proName = sHttpJson['name']
    if 'dir' in sHttpJson:
        sCodeOutDir = sOutDir + sHttpJson['dir'] + '/'
    else:
        sCodeOutDir = sOutDir + proName + '/'
    myCodeDir = Path(sCodeOutDir)
    if not myCodeDir.exists():
        print('文件夹创建:' + sCodeOutDir)
        os.makedirs(sCodeOutDir)
    CopyALLCode(sHttpJson, sDemoDir, sCodeOutDir)
    CreateDpr(sHttpJson, sXmlKeyMap, sDemoDir, sCodeOutDir)
    CreateUntDataModule(sHttpJson, sDemoDir, sCodeOutDir)
    CreateUntSHEntry(sHttpJson, sXmlKeyMap, sDemoDir, sCodeOutDir, sAllList,
                     sMd5Key, sListKey, sMd5FiledMap)
    CreateDEMOXml(sHttpJson, sCodeOutDir, sXmlKeyMap)


if __name__ == "__main__":
    sOutDir = 'F:/hundsun/svn/hstrade20/sourcesEx/HSUFG/'
    # sHttpJson = {
    #     'name': 'g_gs_MessageHttp',
    #     'custName': '国盛',
    #     'developer': '周鹏',
    #     'intefaceList': {
    #         'sms/distinct/v1': {
    #             "appkey": "@AppKey",
    #             "appcode": "@AppCode",
    #             "sign": "md5[@AppKey,@AppSecret,@timestamp]",
    #             "timestamp": "@timestamp",
    #             "sms": [{
    #                 "msg": "@msg",
    #                 "phone": "@phone",
    #                 "extend": ""
    #             }]
    #         }
    #     },
    #     'success': {
    #         'code': '00000'
    #     },
    #     'ErroInfo': 'desc',
    #     'filedDesc': {
    #         'AppKey': '应用key',
    #         'AppCode': '应用代码',
    #         'AppSecret': '秘钥'
    #     }
    # }
    sHttpJson = {
        'name': 'g_gs_MessageHttp',
        'custName': '国盛',
        'developer': '周鹏',
        'intefaceList': {
            'sms/batch/v1': {
                "sign": "md5[@AppKey,@AppSecret,@timestamp]",
                "timestamp": "@timestamp",
                "phone": "@phone",
                "extend": "",
                "appcode": "@AppCode",
                "appkey": "@AppKey",
                "msg": "@msg"
            }
        },
        'success': {
            'code': '00000'
        },
        'ErroInfo': 'desc',
        'filedDesc': {
            'AppKey': '应用key',
            'AppCode': '应用代码',
            'AppSecret': '秘钥'
        }
    }
    BuildCode(sOutDir, sHttpJson)
