package com.hundsun.analysis;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author: yangxl41671
 * @date:
 */
public class XmlProcess {

    public static Map<String, Object> getParams(String path) {
        Map<String, Object> xmlObj = new HashMap<>();
        String shardingInfo = "";
        String security = "";
        String service = "";

        try {
            // 创建解析器工厂
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder db = factory.newDocumentBuilder();
            // 创建一个Document对象
            Document doc = db.parse(new File(path));
            NodeList subList = doc.getElementsByTagName("sub");
            List<Map<String, Object>> interfaceList = new ArrayList<>();
            if (subList.getLength() > 0) {
                Element sub = (Element) subList.item(0);
                Element route = (Element) sub.getElementsByTagName("route").item(0);
                security = route.getAttribute("security");
                shardingInfo = route.getAttribute("shardingInfo");
                service = route.getAttribute("service");
            }
            for (int i = 0; i < subList.getLength(); i++) {
                Map<String, Object> interfaceDict = new HashMap<>();
                Element sub = (Element) subList.item(i);
                String id = sub.getAttribute("id");
                String note = sub.getAttribute("note");
                String alias = sub.getAttribute("alias");
                NodeList inParams = sub.getElementsByTagName("in");
                Map<String, String> paramDict = new HashMap<>();
                for (int j = 0; j < inParams.getLength(); j++) {
                    Element inParam = (Element) inParams.item(j);
                    paramDict.put(inParam.getAttribute("name"), inParam.getAttribute("value"));
                }
                interfaceDict.put("id", id);
                interfaceDict.put("note", note);
                interfaceDict.put("alias", alias);
                interfaceDict.put("paramDict", paramDict);
                interfaceList.add(interfaceDict);
            }
            xmlObj.put("shardingInfo", shardingInfo);
            xmlObj.put("security", security);
            xmlObj.put("service", service);
            xmlObj.put("interfaceList", interfaceList);
            System.out.println(xmlObj);

        } catch (Exception e) {
            e.printStackTrace();
        }


        return xmlObj;
    }
}
