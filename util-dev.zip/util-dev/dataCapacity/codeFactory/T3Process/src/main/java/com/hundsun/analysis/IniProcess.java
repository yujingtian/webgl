package com.hundsun.analysis;

import com.hundsun.send.T3ServicesUtil;
import com.hundsun.t3sdk.impl.client.T3Services;
import org.ini4j.Ini;
import com.hundsun.broker.base.biz.util.T3Sdk;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.ConnectException;
import java.net.NetworkInterface;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @author: yangxl41671
 * @date:
 */
public class IniProcess {

    /**
     * 加密参数，固定值
     */
    private static final String AUTH_ID_NO = "600570";

    /**
     * 认证类别：固定为1
     */
    private static final char AUTH_TYPE = '1';

    /**
     * 加密类别：AES
     */
    private static final char ENCODE_TYPE_AES = '0';

    public static T3Services getConnect() throws Exception {
        // 获取ini中配置信息
        File fileToParse = new File(JarTool.getJarDir() + "/config.ini");
        Ini ini = new Ini(fileToParse);
        String ip = ini.get("connect_setting", "ip");
        String port = ini.get("connect_setting", "port");
        String licenceAddress = ini.get("connect_setting", "licence_address");

        Map<String, String> iniMap = new HashMap<>();
        iniMap.put("ip", ip);
        iniMap.put("port", port);
        iniMap.put("licenceAddress", licenceAddress);

        File file = new File(licenceAddress);
        if (!file.exists()) {
            throw new ConnectException("找不到connect_setting.licence_address文件");
        }

        // 进行环境配置
        return readExternalConfiguration(iniMap);
    }

    /**
     * 读取外部配置文件
     */
    private static T3Services readExternalConfiguration(Map<String, String> iniMap) throws Exception {
        // 根据IP + port 查询微服务信息
        String EXTERNAL_PATH = JarTool.getJarDir() + "\\生成的环境配置文件(勿动)\\" + UUID.randomUUID().toString().substring(0, 20) + ".xml";
        // 添加server
        int index = T3ServicesUtil.addServer(iniMap.get("ip"),
                iniMap.get("port"), iniMap.get("licenceAddress"), EXTERNAL_PATH);
        return T3ServicesUtil.getServer(index);
    }

    /**
     * 校验资格
     */
    public static boolean getIdentified() throws IOException {
        // 获取ini中证书信息
        File fileToParse = new File(JarTool.getJarDir() + "/config.ini");
        Ini ini = new Ini(fileToParse);
        String path = ini.get("identity_licence", "path");

        BufferedReader reader;
        try {
            reader = new BufferedReader(new FileReader(path));
        } catch (Exception e) {
            System.out.println(e.getMessage());
            throw new ConnectException("找不到指定文件");
        }
        // 证书
        String licence = reader.readLine();
        String clearPassword = T3Sdk.decode(licence, null, null, AUTH_ID_NO);

        StringBuilder sb = new StringBuilder();
        Enumeration<NetworkInterface> allNetInterfaces = NetworkInterface.getNetworkInterfaces();
        byte[] mac = null;
        while (allNetInterfaces.hasMoreElements()) {
            NetworkInterface netInterface = allNetInterfaces.nextElement();
            if (netInterface.isLoopback() || netInterface.isVirtual() || netInterface.isPointToPoint() || !netInterface.isUp()) {
                continue;
            } else {
                mac = netInterface.getHardwareAddress();
                if (mac != null) {
                    for (int i = 0; i < mac.length; i++) {
                        sb.append(String.format("%02X%s", mac[i], (i < mac.length - 1) ? "-" : "\n"));
                    }
                }
            }
        }
        String macAdr = sb.toString().replace("-","");
        boolean isContain = false;
        List<String> macList = Arrays.asList(macAdr.split("\n"));
        for (String macSingle : macList) {
            if (clearPassword.contains(macSingle)) {
                isContain = true;
                break;
            }
        }
        if (isContain) {
            SimpleDateFormat df = new SimpleDateFormat("yyyyMMdd");
            return df.format(System.currentTimeMillis()).compareTo(clearPassword.substring(clearPassword.length() - 8, clearPassword.length() - 1)) <= 0;
        } else {
            return false;
        }
    }


    public static void generateInitFile() {
        File file = new File(JarTool.getJarDir() + "/config.ini");
        if(!file.exists()){
            try {
                file.createNewFile();
                Ini ini = new Ini();
                ini.load(file);
                ini.put("connect_setting", "ip", "");
                ini.put("connect_setting", "port", "");
                ini.put("connect_setting", "licence_address", JarTool.getJarDir()+ "\\license.dat");
                ini.put("identity_licence", "path", JarTool.getJarDir()+ "\\identity_licence.dat");
                ini.put("system_config", ";t3_tradePwd_encrypt", "1");
                ini.put("system_config", ";t3_fundPwd_encrypt", "1");
                ini.put("system_config", ";tool_update_is_delete_dat_file", "1");
                ini.put("system_config", "t3_threadPool_maxPoolSize", "50");
                ini.put("system_config", "t3_threadPool_aliveTime", "3000");
                ini.put("system_config", "t3_threadPool_blockingQueueSize", "20");
                ini.put("system_config", "t3_pool_aliveTime", "30");
                System.out.println(JarTool.getJarDir()+ "\\license.dat");
                ini.store(file);
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
    }
}
