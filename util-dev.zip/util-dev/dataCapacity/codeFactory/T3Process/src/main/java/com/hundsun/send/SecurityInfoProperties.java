package com.hundsun.send;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author Star_King
 */
public class SecurityInfoProperties {
    private static final String[] PROPERTIES = new String[]{"iar_token_checked", "trusted_terminal", "access_mode_str_reqheader",
    "weak_check_str_reqheader", "password_type", "pwd_auth_shadow", "pwd_auth_t2b64", "pwd_str_reqheader", "fund_account",
    "pwd_auth_type", "auth_fund_account", "ticket_json_reqheader", "authid_str_respheader", "righttype_str_respheader", "user_token"};

    public static boolean contains(String param) {
        List<String> list = Arrays.stream(PROPERTIES).filter((s) -> s.equals(param)).collect(Collectors.toList());
        return !list.isEmpty();
    }
}