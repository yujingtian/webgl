package com.hundsun.analysis;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.hundsun.tools.getIdNoTool;

import java.util.Random;

public class specialFieldsTool {
    public static String getFiledValue(String oldValue) {
        String newValue = oldValue;
        //判断需要特殊处理的标识
        if ((newValue.indexOf('[') == 0) && (newValue.lastIndexOf(']') == newValue.length() - 1)) {
            String jsonStr = newValue.substring(1, newValue.length() - 1);
            Random r = new Random();
            try {
                JSONObject jsonObject = JSON.parseObject(jsonStr);
                //处理证件号码
                if (jsonObject.containsKey("idno")) {
                    JSONObject idnoJson = jsonObject.getJSONObject("idno");
                    if (idnoJson.containsKey("idkind")) {
                        String idkind = idnoJson.getString("idkind");
                        if (idkind.equals("0")) { //处理身份证号码
                            String sex = null;
                            if (idnoJson.containsKey("sex")) {
                                sex = idnoJson.getString("sex");
                            }

                            if ("M".equals(sex)) {
                                newValue = getIdNoTool.getIdNo(true);
                            } else if ("F".equals(sex)) {
                                newValue = getIdNoTool.getIdNo(false);
                            } else {
                                newValue = getIdNoTool.getIdNo(r.nextBoolean());
                            }
                        }
                    }
                }
            }
            catch (Exception e){
                return newValue;
            }
        }
        return newValue;
    }
}
