package com.hundsun.analysis;

import java.io.File;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;

/**
 * @author: yangxl41671
 * @date:
 */
public class JarTool {
    public JarTool() {
    }

    public static String getJarPath() {
        File file = getFile();
        return file == null ? null : file.getAbsolutePath();
    }

    public static String getJarDir() {
        File file = getFile();
        return file == null ? null : getFile().getParent();
    }

    public static String getJarName() {
        File file = getFile();
        return file == null ? null : getFile().getName();
    }

    private static File getFile() {
        String path = JarTool.class.getProtectionDomain().getCodeSource().getLocation().getFile();

        try {
            path = URLDecoder.decode(path, "UTF-8");
        } catch (UnsupportedEncodingException var2) {
            return null;
        }

        return new File(path);
    }
}
