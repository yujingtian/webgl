package com.hundsun.send;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hundsun.jrescloud.common.t2.context.ContextUtil;
import com.hundsun.jrescloud.common.t2.event.EventType;
import com.hundsun.jrescloud.common.t2.event.T3Event;
import com.hundsun.jrescloud.common.util.JsonUtils;
import com.hundsun.t2sdk.interfaces.IClient;
import com.hundsun.t2sdk.interfaces.T2SDKException;
import com.hundsun.t3sdk.impl.client.T3Services;
import org.apache.commons.lang3.StringUtils;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.XMLWriter;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.logging.Logger;

/**
 * 外部调用T3时的工具类
 * @author Star_King
 */
public class T3Util {
    private static final Logger LOGGER = Logger.getLogger("com.hundsun.tool.encrypt.utils");

    public static Document createDocument(String serverIP, String serverPort, String licencePath) {
        Document document = DocumentHelper.createDocument();
        Element root = document.addElement("t2sdk-configuration");
        root.addElement("performance")
                .addAttribute("heartbeatTime", "400")
                .addAttribute("acquireConnWaitTime", "5000")
                .addAttribute("registerTime", "500")
                .addAttribute("reconnInterval", "0")
                .addAttribute("localServerName", "t3sdk")
                .addAttribute("callBackTime", "50000")
                .addAttribute("enmCompress", "false")
                .addAttribute("senderQueueLength", "200")
                .addAttribute("sendPoolSize", "50");
        Element parents = root.addElement("parents");
        Element parent = parents.addElement("parent")
                .addAttribute("parentName", "poc")
                .addAttribute("safeLevel", "NONE");
        parent.addElement("limit")
                .addAttribute("licenseFile", licencePath)
                .addAttribute("encrypt", "HSBlowfish");
        Element members = parent.addElement("members");
        Random r = new Random(1);
        int no = r.nextInt(100);
        members.addElement("member")
                .addAttribute("no", String.valueOf(no))
                .addAttribute("address", serverIP)
                .addAttribute("port", serverPort)
                .addAttribute("charset", "UTF-8")
                .addAttribute("poolSize", "1");
        LOGGER.info("生成配置文件成功！");
        return document;
    }

    public static void write(Document document, String path) throws IOException {
        File file = new File(path);
        if (!file.exists()) {
            LOGGER.info("外存中不存在配置文件！" + path);
            int index = -1;
            for (int i = path.length() - 1; i >= 0; i--) {
                if (path.charAt(i) == '\\') {
                    index = i;
                    break;
                }
            }
            if (index == -1) {
                return;
            } else {
                String dirPath = path.substring(0, index);
                File file1 = new File(dirPath);
                boolean success = file1.mkdirs();
//                if (success) {
//                    LOGGER.info("创建目录成功！");
//                } else {
//                    LOGGER.warning("创建目录失败！");
//                }
            }
            try {
                boolean success = file.createNewFile();
                if (success) {
                    LOGGER.info("创建配置文件成功！");
                } else {
                    LOGGER.warning("创建配置文件失败！");
                }
            } catch (IOException e) {
                LOGGER.warning("创建配置文件失败！");
            }
        }
        FileWriter fileWriter = new FileWriter(path);
        OutputFormat format = OutputFormat.createPrettyPrint();
        XMLWriter writer = new XMLWriter(fileWriter, format);
        writer.write(document);
        writer.close();
        LOGGER.info("写入配置文件成功！");
    }

    public static int returnCode(T3Event rsp, StringBuilder builder) {
        // 返回值
        int result = -1;
        if (rsp != null) {
            result = rsp.getReturnCode();
            String respBody = null;
            try {
                respBody = rsp.getEventBody();
            } catch (Exception ignored) {
            }
            //业务错误，或者小于0为平台错误
            if(result != 0){
                builder.append(result).append("|").append(rsp.getErrorNo()).append("|").append(rsp.getErrorInfo()).append("|").append(respBody);
                LOGGER.info(result + "|" + rsp.getErrorNo() + "|" + rsp.getErrorInfo() + "|" + respBody);
            } else {
                // 正常应答
                builder.append(respBody);
                LOGGER.info(respBody);
                LOGGER.info("OK");
            }
        } else {
            builder.append("rsp is null!");
            LOGGER.warning("rsp is null!");
        }
        return result;
    }

    public static void set23Scope(T3Event event, String microServerName) {
        String[] gsvInfo = new String[3];
        gsvInfo[1] = microServerName;
        event.setStringArrayAttributeValue("23", gsvInfo);
    }

    public static void set24Scope(T3Event event, Map<Object, Object> shardingInfo) throws JsonProcessingException {

        String jsonShardingInfo = new ObjectMapper().writeValueAsString(shardingInfo);
        event.setStringAttributeValue("24", jsonShardingInfo);
    }

    public static void set33Scope(T3Event event, Map<Object, Object> security) throws JsonProcessingException {
        Map<String, String> securityInfo = new HashMap<>(16);
        Set<Object> keySet = security.keySet();
        for (Object o : keySet) {
            String key = (String) o;
            if (SecurityInfoProperties.contains(key)) {
                // 加入到33号域
                securityInfo.put(key, (String) security.get(o));
            }
        }
        String jsonSecurityInfo = new ObjectMapper().writeValueAsString(securityInfo);
        // 设置security 33号域
        event.setStringAttributeValue("33", jsonSecurityInfo);
    }

    public static void set43Scope(T3Event event) {
        event.setAttributeValue("43", 1);
    }

    public static String trySend(T3Services server, String functionId, String microServerName, Map<Object, Object> shardingInfo, Map<Object, Object> security, Map<Object, Object> param) throws Exception {
        IClient client = server.getClient("poc");

        // 登录请求
        T3Event event = (T3Event) ContextUtil.getServiceContext().getT3EventFactory()
                .getEventByAlias(functionId, EventType.ET_REQUEST);

        // 设置23号域
        T3Util.set23Scope(event, microServerName);

        // 设置24号域
        T3Util.set24Scope(event, shardingInfo);

        // 设置33号域
        T3Util.set33Scope(event, security);

        //设置43号域，这个1表示请求和返回的通信包信息要压缩和解压，这样能防止通讯包过大，浪费带宽
        T3Util.set43Scope(event);

        String dataJson = JsonUtils.getObjectMapper().writeValueAsString(param);
        // 设置要传递的json格式的参数
        event.setEventBody(dataJson);

        T3Event rsp;
        try {
            if (client != null) {
                rsp = (T3Event) client.sendReceive(event);
            } else {
                LOGGER.warning("client is null!");
                return ResultEntity.failWithoutData("client is null!").returnResult();
            }
        } catch (T2SDKException e) {
            LOGGER.warning("sendReceive " + e.getErrorNo() + "|" + e.getErrorInfo() + "|" + e.getErrorMessage());
            return ResultEntity.failWithoutData("sendReceive " + e.getErrorNo() + "|" + e.getErrorInfo() + "|" + e.getErrorMessage()).returnResult();
        }
        // 返回值
        StringBuilder builder = new StringBuilder();
        int returnCode = T3Util.returnCode(rsp, builder);
        if (returnCode == 0 && rsp != null) {
            String result = rsp.getEventBody();
            if (StringUtils.isBlank(rsp.getEventBody())) {
                result = "";
            } else if (rsp.getEventBody().startsWith("{")) {
                result = "[" + result + "]";
            }
//            LOGGER.info(result);
            return ResultEntity.successWithData(result).returnResult();
        } else if (returnCode == 0) {
            return ResultEntity.successWithData("[]").returnResult();
        } else {
            return ResultEntity.failWithoutData(builder.toString()).returnResult();
        }
    }
}
