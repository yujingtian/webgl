package com.hundsun.analysis;

import com.alibaba.fastjson.JSONObject;
import com.hundsun.send.ExcelTool;
import com.hundsun.send.ResultEntity;
import com.hundsun.send.T3Util;
import com.hundsun.t3sdk.impl.client.T3Services;
import org.apache.commons.lang.StringUtils;

import javax.swing.*;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.filechooser.FileSystemView;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.util.*;
import java.util.List;
import java.util.regex.Pattern;

/**
 * @author: yangxl41671
 * @date:
 */
public class T3Process {
    private JFileChooser fc;
    private String filePath;
    private String fileType;
    private List<String> failAliasList = new ArrayList<>();
    private boolean isConnect = false;
    private boolean successFlag = true;

    private List<Map<String, Object>> inParamList;
    private List<Map<String, Object>> outParamList;

    private JFrame fm;
    private JButton btnImport;
    private JButton btnSend;
    private JButton btnOutput;
    private JButton btnConnect;
    private JLabel lbStatus;
    private JTextField tfFilePath;
    private JPanel fileSelectPanel;
    private JPanel outputPanel;
    private JPanel statusPanel;

    private T3Services server;

    private T3Process() {
        init();
        initFm();
        initBtns();
        initLabel();
        initIniFile();
        initTextFileds();
        initFileChooser();
        initOutputPanel();
        initstatusPanel();
        initFileSelectPanel();
        initListener();
        add(fileSelectPanel, btnConnect, btnImport, tfFilePath, btnSend);
        add(outputPanel, btnOutput);
        add(statusPanel, lbStatus);
        add(fm, fileSelectPanel, outputPanel, statusPanel);
        fm.setVisible(true);
        fm.validate();
    }

    private void init() {
        try {
            // 设置为当前操作系统的皮肤
            String lookAndFeel = UIManager.getSystemLookAndFeelClassName();
            UIManager.setLookAndFeel(lookAndFeel);
        } catch (Exception e) {
            outputException(e);
        }
    }

    private void initFm() {
        fm = new JFrame("T3流程调用工具") {
            private static final long serialVersionUID = 1L;

            protected void processWindowEvent(WindowEvent e) {
                super.processWindowEvent(e);
            }
        };
        fm.setLayout((LayoutManager)null);
        fm.setSize(1000, 180);
        fm.setResizable(false);
        fm.setLocationRelativeTo((Component)null);
        fm.setDefaultCloseOperation(3);
        fm.getContentPane().setBackground(new Color(215, 230, 234));
    }

    private void initBtns() {
        this.btnImport = new T3Process.MyBtn("导入用例");
        this.btnSend = new T3Process.MyBtn("发送请求");
        this.btnOutput = new T3Process.MyBtn("导出结果");
        this.btnConnect = new T3Process.MyBtn("连接");
    }

    private void initLabel() {
        this.lbStatus = new JLabel("未连接", SwingConstants.RIGHT);
        this.lbStatus.setPreferredSize(new Dimension(975, 30));
    }

    private void initIniFile() {
        IniProcess.generateInitFile();
    }

    private void initTextFileds() {
        this.tfFilePath = new JTextField(this.filePath);
        this.tfFilePath.setPreferredSize(new Dimension(540, 30));
    }

    private void initFileChooser() {
        fc = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());
        FileFilter filter = new FileNameExtensionFilter("Xml Files(*.xml)","xml");
        FileFilter filter1 = new FileNameExtensionFilter("Xls Files(*.xls)","xls");
        fc.setFileFilter(filter1);
        fc.setFileFilter(filter);
//        fc.setFileSelectionMode(1);
    }

    private void initFileSelectPanel() {
        this.fileSelectPanel = new JPanel();
        this.fileSelectPanel.setBounds(7, 5, 985, 40);
        this.fileSelectPanel.setBackground(Color.white);
    }

    private void initOutputPanel() {
        this.outputPanel = new JPanel();
        this.outputPanel.setBounds(7, 50, 985, 40);
        this.outputPanel.setBackground(Color.white);
    }

    private void initstatusPanel() {
        this.statusPanel = new JPanel();
        this.statusPanel.setBounds(7, 95, 985, 40);
        this.statusPanel.setBackground(new Color(215, 230, 234));
    }

    private void initListener() {
        btnConnect.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    lbStatus.setText("证书校验中...");
                    if (!IniProcess.getIdentified()) {
                        lbStatus.setText("证书校验失败...");
                        JOptionPane.showMessageDialog(null, "证书校验失败",
                                "错误提示",JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                    lbStatus.setText("ip、port连接中...");
                    server = IniProcess.getConnect();
                    lbStatus.setText("连接成功");
                    isConnect = true;
                } catch (Exception ioException) {
                    JOptionPane.showMessageDialog(null, ioException.getMessage(),
                            "错误提示",JOptionPane.ERROR_MESSAGE);
                    ioException.printStackTrace();
                    lbStatus.setText("失败");
                    isConnect = false;
                }
            }
        });
        btnImport.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (fc.showOpenDialog(fm) == 0) {
                    tfFilePath.setText(fc.getSelectedFile().toString());
                }
            }
        });
        btnOutput.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                lbStatus.setText("数据导出中...");
                try {
                    ExcelTool.doWork(inParamList, outParamList, fileType);

                } catch (IOException ioException) {
                    ioException.printStackTrace();
                }
                lbStatus.setText("数据导出完成" + JarTool.getJarDir() + "\\调用结果");
            }
        });
        btnSend.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (!isConnect) {
                    JOptionPane.showMessageDialog(null, "请先完成连接",
                            "错误提示",JOptionPane.ERROR_MESSAGE);
                    return;
                }
                try {
                    lbStatus.setText("文件读取中...");
                    getFilePath();
                    if (StringUtils.isBlank(filePath)) {
                        JOptionPane.showMessageDialog(null, "请先选择测试用例！",
                                "错误提示",JOptionPane.ERROR_MESSAGE);
                    }
                    fileType = filePath.substring(filePath.lastIndexOf(".") + 1);
                    inParamList = new ArrayList<>();
                    outParamList = new ArrayList<>();
                    if (fileType.equals("xml")) {
                        Map<String, Object> inParamMap = XmlProcess.getParams(filePath);
                        lbStatus.setText("请求发送中...");
                        String microServerName = String.valueOf(inParamMap.get("service"));

                        // 组装shardingInfo
                        String shardingInfoJson = String.valueOf(inParamMap.get("shardingInfo"));
                        Map<Object, Object> shardingInfo = JSONObject.parseObject(shardingInfoJson, Map.class);
                        if (shardingInfo.isEmpty()) {
                            shardingInfo.put("custId", "");
                        } else {
                            shardingInfo.replaceAll((k, v) -> v);
                        }
                        // 组装security
                        String securityJson = JSONObject.toJSONString(inParamMap.get("security"));
                        Map<Object, Object> security = JSONObject.parseObject(securityJson, Map.class);
                        if (!security.isEmpty()) {
                            security.replaceAll((k, v) -> v);
                        }
                        // 组装接口信息
                        List<Map<String, Object>> interfaceList = (List<Map<String, Object>>) inParamMap.get("interfaceList");
                        // 获取别名列表
                        List<String> aliasList = new ArrayList<>();
                        for (Map<String, Object> interfaceInfo : interfaceList) {
                            if (!String.valueOf(interfaceInfo.get("alias")).equals("") && aliasList.contains(String.valueOf(interfaceInfo.get("alias")))) {
                                lbStatus.setText("别名\"" + interfaceInfo.get("alias") + "\"重复");
                                JOptionPane.showMessageDialog(null, "别名\"" + interfaceInfo.get("alias") + "\"重复",
                                        "错误提示",JOptionPane.ERROR_MESSAGE);
                                return;
                            } else {
                                aliasList.add(String.valueOf(interfaceInfo.get("alias")));
                            }
                        }

                        // 初始化需要替换的列表
                        Map<String, Map<String, Object>> replaceMap = new HashMap<>();
                        for (int i = 0; i < interfaceList.size(); i++) {
                            Map<String, String> inFiledList = (Map<String, String>) interfaceList.get(i).get("paramDict");
                            if (i == 0) {
                                for (String key : inFiledList.keySet()) {
                                    inFiledList.put(key,specialFieldsTool.getFiledValue(String.valueOf(inFiledList.get(key))));
                                    String pattern = "^[a-zA-Z]+([\\w])?[\\.]([a-zA-Z_])+";
                                    Pattern r = Pattern.compile(pattern);
                                    if (r.matcher(String.valueOf(inFiledList.get(key))).matches()) {
                                        lbStatus.setText("首个接口不允许包含别名" + inFiledList.get(key));
                                        JOptionPane.showMessageDialog(null, "首个接口不允许包含别名" + inFiledList.get(key),
                                                "错误提示",JOptionPane.ERROR_MESSAGE);
                                        return;
                                    }
                                }
                            } else {
                                for (String key : inFiledList.keySet()) {
                                    inFiledList.put(key,specialFieldsTool.getFiledValue(String.valueOf(inFiledList.get(key))));
                                    String pattern = "^[a-zA-Z]+([\\w])?[\\.]([a-zA-Z_])+";
                                    Pattern r = Pattern.compile(pattern);
                                    if (r.matcher(String.valueOf(inFiledList.get(key))).matches()) {
                                        String alias = String.valueOf(inFiledList.get(key)).split("\\.")[0];
                                        String param = String.valueOf(inFiledList.get(key)).split("\\.")[1];
                                        Map<String, Object> iniMap = replaceMap.getOrDefault(alias, new HashMap<>());
                                        iniMap.put(param, "");
                                        replaceMap.put(alias, iniMap);
                                    }
                                }
                            }
                        }

                        // 出参列表
                        List<Map<String, Object>> outputList = new ArrayList<>();
                        // 发送功能并替换下一个接口出参
                        for (int i = 0; i < interfaceList.size(); i++) {
                            Map<Object, Object> paramDict = (Map<Object, Object>) interfaceList.get(i).get("paramDict");

                            if (i == 0) {
                                String functionId = String.valueOf(interfaceList.get(i).get("id"));
                                String resultJson = T3Util.trySend(server, functionId, microServerName, shardingInfo, security, paramDict);
                                ResultEntity resultMap = JSONObject.parseObject(resultJson, ResultEntity.class);
                                if (!resultMap.getSuccess()) {
                                    Map<String, Object> errorMap = new HashMap<String, Object>() {{
                                        put("error_info", resultMap.getMsg());
                                    }};
                                    List<Map<String, Object>> outList = new ArrayList<>();
                                    outList.add(errorMap);
                                    Map<String, Object> iniMap = new HashMap<>();
                                    iniMap.put("id", functionId);
                                    iniMap.put("note", interfaceList.get(i).get("note"));
                                    iniMap.put("alias", interfaceList.get(i).get("alias"));
                                    iniMap.put("outParams", outList);
                                    outputList.add(iniMap);
                                    if (!StringUtils.isBlank(String.valueOf(interfaceList.get(i).get("alias")))) {
                                        failAliasList.add(String.valueOf(interfaceList.get(i).get("alias")));
                                    }
                                } else {
                                    // 获取出参
                                    List<Map<String, Object>> outList;
                                    if (StringUtils.isBlank(String.valueOf(resultMap.getData()))) {
                                        outList = new ArrayList<>();
                                    } else {
                                        outList = JSONObject.parseObject((String) resultMap.getData(), ArrayList.class);
                                    }
                                    Map<String, Object> iniMap = new HashMap<>();
                                    iniMap.put("id", functionId);
                                    iniMap.put("note", interfaceList.get(i).get("note"));
                                    iniMap.put("alias", interfaceList.get(i).get("alias"));
                                    iniMap.put("outParams", outList);
                                    outputList.add(iniMap);
                                    // 为需要替换的值赋值
                                    if (outList != null && outList.size() == 1 && replaceMap.containsKey(String.valueOf(interfaceList.get(i).get("alias")))) {
                                        Map<String, Object> replaceParamMap = replaceMap.get(String.valueOf(interfaceList.get(i).get("alias")));
                                        for (Map.Entry<String, Object> replaceParam : replaceMap.get(String.valueOf(interfaceList.get(i).get("alias"))).entrySet()) {
                                            replaceParamMap.put(replaceParam.getKey(), outList.get(0).get(replaceParam.getKey()));
                                            replaceMap.put(String.valueOf(interfaceList.get(i).get("alias")), replaceParamMap);
                                        }
                                    }
                                }
                            } else if (i == interfaceList.size() - 1) {
                                successFlag = true;
                                // 替换入参
                                for (Map.Entry<Object, Object> inparam : paramDict.entrySet()) {
                                    String pattern = "^[a-zA-Z]+([\\w])?[\\.]([a-zA-Z_])+";
                                    Pattern r = Pattern.compile(pattern);
                                    if (r.matcher(String.valueOf(inparam.getValue())).matches()) {
                                        String alias = String.valueOf(inparam.getValue()).split("\\.")[0];
                                        String param = String.valueOf(inparam.getValue()).split("\\.")[1];
                                        if (failAliasList.contains(alias)) {
                                            successFlag = false;
                                            break;
                                        }
                                        paramDict.put(inparam.getKey(), replaceMap.get(alias).get(param));
                                    }
                                }

                                String functionId = String.valueOf(interfaceList.get(i).get("id"));
                                if (successFlag) {
                                    String resultJson = T3Util.trySend(server, functionId, microServerName, shardingInfo, security, paramDict);
                                    ResultEntity resultMap = JSONObject.parseObject(resultJson, ResultEntity.class);
                                    if (!resultMap.getSuccess()) {
                                        Map<String, Object> errorMap = new HashMap<String, Object>() {{
                                            put("error_info", String.valueOf(resultMap.getMsg()));
                                        }};
                                        List<Map<String, Object>> outList = new ArrayList<>();
                                        outList.add(errorMap);
                                        Map<String, Object> iniMap = new HashMap<>();
                                        iniMap.put("id", functionId);
                                        iniMap.put("note", interfaceList.get(i).get("note"));
                                        iniMap.put("alias", interfaceList.get(i).get("alias"));
                                        iniMap.put("outParams", outList);
                                        outputList.add(iniMap);
                                        if (!StringUtils.isBlank(String.valueOf(interfaceList.get(i).get("alias")))) {
                                            failAliasList.add(String.valueOf(interfaceList.get(i).get("alias")));
                                        }
                                    } else {
                                        // 获取出参
                                        List<Map<String, Object>> outList;
                                        if (StringUtils.isBlank(String.valueOf(resultMap.getData()))) {
                                            outList = new ArrayList<>();
                                        } else {
                                            outList = JSONObject.parseObject((String) resultMap.getData(), ArrayList.class);
                                        }
                                        Map<String, Object> iniMap = new HashMap<>();
                                        iniMap.put("id", functionId);
                                        iniMap.put("note", interfaceList.get(i).get("note"));
                                        iniMap.put("alias", interfaceList.get(i).get("alias"));
                                        iniMap.put("outParams", outList);
                                        outputList.add(iniMap);
                                    }
                                } else {
                                    Map<String, Object> interfaceInfo = interfaceList.get(i);
                                    interfaceInfo.put("sendFlag", "false");
                                    interfaceList.set(i, interfaceInfo);
                                }
                            } else {
                                successFlag = true;
                                // 替换入参
                                for (Map.Entry<Object, Object> inparam : paramDict.entrySet()) {
                                    String pattern = "^[a-zA-Z]+([\\w])?[\\.]([a-zA-Z_])+";
                                    Pattern r = Pattern.compile(pattern);
                                    if (r.matcher(String.valueOf(inparam.getValue())).matches()) {
                                        String alias = String.valueOf(inparam.getValue()).split("\\.")[0];
                                        String param = String.valueOf(inparam.getValue()).split("\\.")[1];
                                        if (failAliasList.contains(alias)) {
                                            successFlag = false;
                                            break;
                                        }
                                        paramDict.put(inparam.getKey(), replaceMap.get(alias).get(param));
                                    }
                                }

                                String functionId = String.valueOf(interfaceList.get(i).get("id"));
                                if (successFlag) {
                                    String resultJson = T3Util.trySend(server, functionId, microServerName, shardingInfo, security, paramDict);
                                    ResultEntity resultMap = JSONObject.parseObject(resultJson, ResultEntity.class);
                                    if (!resultMap.getSuccess()) {
                                        Map<String, Object> errorMap = new HashMap<String, Object>() {{
                                            put("error_info", resultMap.getMsg());
                                        }};
                                        List<Map<String, Object>> outList = new ArrayList<>();
                                        outList.add(errorMap);
                                        Map<String, Object> iniMap = new HashMap<>();
                                        iniMap.put("id", functionId);
                                        iniMap.put("note", interfaceList.get(i).get("note"));
                                        iniMap.put("alias", interfaceList.get(i).get("alias"));
                                        iniMap.put("outParams", outList);
                                        outputList.add(iniMap);
                                        if (!StringUtils.isBlank(String.valueOf(interfaceList.get(i).get("alias")))) {
                                            failAliasList.add(String.valueOf(interfaceList.get(i).get("alias")));
                                        }
                                    } else {
                                        // 获取出参
                                        List<Map<String, Object>> outList;
                                        if (StringUtils.isBlank(String.valueOf(resultMap.getData()))) {
                                            outList = new ArrayList<>();
                                        } else {
                                            outList = JSONObject.parseObject((String) resultMap.getData(), ArrayList.class);
                                        }
                                        Map<String, Object> iniMap = new HashMap<>();
                                        iniMap.put("id", functionId);
                                        iniMap.put("note", interfaceList.get(i).get("note"));
                                        iniMap.put("alias", interfaceList.get(i).get("alias"));
                                        iniMap.put("outParams", outList);
                                        outputList.add(iniMap);

                                        // 为需要替换的值赋值
                                        if (outList != null && outList.size() == 1 && replaceMap.containsKey(String.valueOf(interfaceList.get(i).get("alias")))) {
                                            Map<String, Object> replaceParamMap = replaceMap.get(String.valueOf(interfaceList.get(i).get("alias")));
                                            for (Map.Entry<String, Object> replaceParam : replaceMap.get(String.valueOf(interfaceList.get(i).get("alias"))).entrySet()) {
                                                replaceParamMap.put(replaceParam.getKey(), outList.get(0).get(replaceParam.getKey()));
                                                replaceMap.put(String.valueOf(interfaceList.get(i).get("alias")), replaceParamMap);
                                            }
                                        }
                                    }
                                } else {
                                    Map<String, Object> interfaceInfo = interfaceList.get(i);
                                    interfaceInfo.put("sendFlag", "false");
                                    interfaceList.set(i, interfaceInfo);
                                }
                            }
                        }
                        inParamList = interfaceList;
                        outParamList = outputList;
                    } else if (fileType.equals("xls")){
                        Map<String, Object> inParamMap = XlsProcess.getParams(filePath);
                        lbStatus.setText("请求发送中...");
                        String microServerName = String.valueOf(inParamMap.get("service"));

                        // 组装shardingInfo
                        String shardingInfoJson = String.valueOf(inParamMap.get("shardingInfo"));
                        Map<Object, Object> shardingInfo = JSONObject.parseObject(shardingInfoJson, Map.class);
                        if (shardingInfo.isEmpty()) {
                            shardingInfo.put("custId", "");
                        } else {
                            shardingInfo.replaceAll((k, v) -> v);
                        }
                        // 组装security
                        String securityJson = JSONObject.toJSONString(inParamMap.get("security"));
                        Map<Object, Object> security = JSONObject.parseObject(securityJson, Map.class);
                        if (!security.isEmpty()) {
                            security.replaceAll((k, v) -> v);
                        }
                        // 组装接口信息
                        List<Map<String, Object>> interfaceList = (List<Map<String, Object>>) inParamMap.get("interfaceList");
                        // 获取别名列表
                        List<String> aliasList = new ArrayList<>();
                        for (Map<String, Object> interfaceInfo : interfaceList) {
                            if (!String.valueOf(interfaceInfo.get("alias")).equals("") && aliasList.contains(String.valueOf(interfaceInfo.get("alias")))) {
                                lbStatus.setText("别名\"" + interfaceInfo.get("alias") + "\"重复");
                                JOptionPane.showMessageDialog(null, "别名\"" + interfaceInfo.get("alias") + "\"重复",
                                        "错误提示",JOptionPane.ERROR_MESSAGE);
                                return;
                            } else {
                                aliasList.add(String.valueOf(interfaceInfo.get("alias")));
                            }
                        }

                        // 初始化需要替换的列表
                        Map<String, Map<String, Object>> replaceMap = new HashMap<>();
                        for (int i = 0; i < interfaceList.size(); i++) {
                            Map<String, String> inFiledList = (Map<String, String>) interfaceList.get(i).get("paramDict");
                            if (i == 0) {
                                for (String key : inFiledList.keySet()) {
                                    inFiledList.put(key,specialFieldsTool.getFiledValue(String.valueOf(inFiledList.get(key))));
                                    String pattern = "^[a-zA-Z]+([\\w])?[\\.]([a-zA-Z_])+";
                                    Pattern r = Pattern.compile(pattern);
                                    if (r.matcher(String.valueOf(inFiledList.get(key))).matches()) {
                                        lbStatus.setText("首个接口不允许包含别名" + inFiledList.get(key));
                                        JOptionPane.showMessageDialog(null, "首个接口不允许包含别名" + inFiledList.get(key),
                                                "错误提示",JOptionPane.ERROR_MESSAGE);
                                        return;
                                    }
                                }
                            } else {
                                for (String key : inFiledList.keySet()) {
                                    inFiledList.put(key,specialFieldsTool.getFiledValue(String.valueOf(inFiledList.get(key))));
                                    String pattern = "^[a-zA-Z]+([\\w])?[\\.]([a-zA-Z_])+";
                                    Pattern r = Pattern.compile(pattern);
                                    if (r.matcher(String.valueOf(inFiledList.get(key))).matches()) {
                                        Map<String, Object> iniMap = new HashMap<>();
                                        String alias = String.valueOf(inFiledList.get(key)).split("\\.")[0];
                                        String param = String.valueOf(inFiledList.get(key)).split("\\.")[1];
                                        iniMap.put(param, "");
                                        replaceMap.put(alias, iniMap);
                                    }
                                }
                            }
                        }

                        // 出参列表
                        List<Map<String, Object>> outputList = new ArrayList<>();
                        // 发送功能并替换下一个接口出参
                        for (int i = 0; i < interfaceList.size(); i++) {
                            Map<Object, Object> paramDict = (Map<Object, Object>) interfaceList.get(i).get("paramDict");

                            if (i == 0) {
                                String functionId = String.valueOf(interfaceList.get(i).get("id"));
                                String resultJson = T3Util.trySend(server, functionId, microServerName, shardingInfo, security, paramDict);
                                ResultEntity resultMap = JSONObject.parseObject(resultJson, ResultEntity.class);
                                if (!resultMap.getSuccess()) {
                                    Map<String, Object> errorMap = new HashMap<String, Object>() {{
                                        put("error_info", resultMap.getMsg());
                                    }};
                                    List<Map<String, Object>> outList = new ArrayList<>();
                                    outList.add(errorMap);
                                    Map<String, Object> iniMap = new HashMap<>();
                                    iniMap.put("id", functionId);
                                    iniMap.put("note", interfaceList.get(i).get("note"));
                                    iniMap.put("alias", interfaceList.get(i).get("alias"));
                                    iniMap.put("outParams", outList);
                                    outputList.add(iniMap);
                                    if (!StringUtils.isBlank(String.valueOf(interfaceList.get(i).get("alias")))) {
                                        failAliasList.add(String.valueOf(interfaceList.get(i).get("alias")));
                                    }
                                } else {
                                    // 获取出参
                                    List<Map<String, Object>> outList;
                                    if (StringUtils.isBlank(String.valueOf(resultMap.getData()))) {
                                        outList = new ArrayList<>();
                                    } else {
                                        outList = JSONObject.parseObject((String) resultMap.getData(), ArrayList.class);
                                    }
                                    Map<String, Object> iniMap = new HashMap<>();
                                    iniMap.put("id", functionId);
                                    iniMap.put("note", interfaceList.get(i).get("note"));
                                    iniMap.put("alias", interfaceList.get(i).get("alias"));
                                    iniMap.put("outParams", outList);
                                    outputList.add(iniMap);
                                    // 为需要替换的值赋值
                                    if (outList.size() == 1 && replaceMap.containsKey(String.valueOf(interfaceList.get(i).get("alias")))) {
                                        Map<String, Object> replaceParamMap = replaceMap.get(String.valueOf(interfaceList.get(i).get("alias")));
                                        for (Map.Entry<String, Object> replaceParam : replaceMap.get(String.valueOf(interfaceList.get(i).get("alias"))).entrySet()) {
                                            replaceParamMap.put(String.valueOf(replaceParam.getKey()), outList.get(0).get(replaceParam.getKey()));
                                            replaceMap.put(String.valueOf(interfaceList.get(i).get("alias")), replaceParamMap);
                                        }
                                    }
                                }
                            } else if (i == interfaceList.size() - 1) {
                                successFlag = true;
                                // 替换入参
                                for (Map.Entry<Object, Object> inparam : paramDict.entrySet()) {
                                    String pattern = "^[a-zA-Z]+([\\w])?[\\.]([a-zA-Z_])+";
                                    Pattern r = Pattern.compile(pattern);
                                    if (r.matcher(String.valueOf(inparam.getValue())).matches()) {
                                        String alias = String.valueOf(inparam.getValue()).split("\\.")[0];
                                        String param = String.valueOf(inparam.getValue()).split("\\.")[1];
                                        if (failAliasList.contains(alias)) {
                                            successFlag = false;
                                            break;
                                        }paramDict.put(inparam.getKey(), replaceMap.get(alias).get(param));
                                    }
                                }

                                String functionId = String.valueOf(interfaceList.get(i).get("id"));
                                if (successFlag) {
                                    String resultJson = T3Util.trySend(server, functionId, microServerName, shardingInfo, security, paramDict);
                                    ResultEntity resultMap = JSONObject.parseObject(resultJson, ResultEntity.class);
                                    if (!resultMap.getSuccess()) {
                                        Map<String, Object> errorMap = new HashMap<String, Object>() {{
                                            put("error_info", String.valueOf(resultMap.getMsg()));
                                        }};
                                        List<Map<String, Object>> outList = new ArrayList<>();
                                        outList.add(errorMap);
                                        Map<String, Object> iniMap = new HashMap<>();
                                        iniMap.put("id", functionId);
                                        iniMap.put("note", interfaceList.get(i).get("note"));
                                        iniMap.put("alias", interfaceList.get(i).get("alias"));
                                        iniMap.put("outParams", outList);
                                        outputList.add(iniMap);
                                        if (!StringUtils.isBlank(String.valueOf(interfaceList.get(i).get("alias")))) {
                                            failAliasList.add(String.valueOf(interfaceList.get(i).get("alias")));
                                        }
                                    } else {
                                        // 获取出参
                                        List<Map<String, Object>> outList;
                                        if (StringUtils.isBlank(String.valueOf(resultMap.getData()))) {
                                            outList = new ArrayList<>();
                                        } else {
                                            outList = JSONObject.parseObject((String) resultMap.getData(), ArrayList.class);
                                        }
                                        Map<String, Object> iniMap = new HashMap<>();
                                        iniMap.put("id", functionId);
                                        iniMap.put("note", interfaceList.get(i).get("note"));
                                        iniMap.put("alias", interfaceList.get(i).get("alias"));
                                        iniMap.put("outParams", outList);
                                        outputList.add(iniMap);
                                    }
                                } else {
                                    Map<String, Object> interfaceInfo = interfaceList.get(i);
                                    interfaceInfo.put("sendFlag", "false");
                                    interfaceList.set(i, interfaceInfo);
                                }
                            } else {
                                successFlag = true;
                                // 替换入参
                                for (Map.Entry<Object, Object> inparam : paramDict.entrySet()) {
                                    String pattern = "^[a-zA-Z]+([\\w])?[\\.]([a-zA-Z_])+";
                                    Pattern r = Pattern.compile(pattern);
                                    if (r.matcher(String.valueOf(inparam.getValue())).matches()) {
                                        String alias = String.valueOf(inparam.getValue()).split("\\.")[0];
                                        String param = String.valueOf(inparam.getValue()).split("\\.")[1];
                                        if (failAliasList.contains(alias)) {
                                            successFlag = false;
                                            break;
                                        }
                                        paramDict.put(inparam.getKey(), replaceMap.get(alias).get(param));
                                    }
                                }

                                String functionId = String.valueOf(interfaceList.get(i).get("id"));
                                if (successFlag) {
                                    String resultJson = T3Util.trySend(server, functionId, microServerName, shardingInfo, security, paramDict);
                                    ResultEntity resultMap = JSONObject.parseObject(resultJson, ResultEntity.class);
                                    if (!resultMap.getSuccess()) {
                                        lbStatus.setText("调用报错，点击查看结果");
                                        Map<String, Object> errorMap = new HashMap<String, Object>() {{
                                            put("error_info", resultMap.getMsg());
                                        }};
                                        List<Map<String, Object>> outList = new ArrayList<>();
                                        outList.add(errorMap);
                                        Map<String, Object> iniMap = new HashMap<>();
                                        iniMap.put("id", functionId);
                                        iniMap.put("note", interfaceList.get(i).get("note"));
                                        iniMap.put("alias", interfaceList.get(i).get("alias"));
                                        iniMap.put("outParams", outList);
                                        outputList.add(iniMap);
                                        if (!StringUtils.isBlank(String.valueOf(interfaceList.get(i).get("alias")))) {
                                            failAliasList.add(String.valueOf(interfaceList.get(i).get("alias")));
                                        }
                                    } else {
                                        // 获取出参
                                        List<Map<String, Object>> outList;
                                        if (StringUtils.isBlank(String.valueOf(resultMap.getData()))) {
                                            outList = new ArrayList<>();
                                        } else {
                                            outList = JSONObject.parseObject((String) resultMap.getData(), ArrayList.class);
                                        }
                                        Map<String, Object> iniMap = new HashMap<>();
                                        iniMap.put("id", functionId);
                                        iniMap.put("note", interfaceList.get(i).get("note"));
                                        iniMap.put("alias", interfaceList.get(i).get("alias"));
                                        iniMap.put("outParams", outList);
                                        outputList.add(iniMap);

                                        // 为需要替换的值赋值
                                        if (outList.size() == 1 && replaceMap.containsKey(String.valueOf(interfaceList.get(i).get("alias")))) {
                                            Map<String, Object> replaceParamMap = replaceMap.get(String.valueOf(interfaceList.get(i).get("alias")));
                                            for (Map.Entry<String, Object> replaceParam : replaceMap.get(String.valueOf(interfaceList.get(i).get("alias"))).entrySet()) {
                                                replaceParamMap.put(String.valueOf(replaceParam.getKey()), outList.get(0).get(replaceParam.getKey()));
                                                replaceMap.put(String.valueOf(interfaceList.get(i).get("alias")), replaceParamMap);
                                            }
                                        }
                                    }
                                } else {
                                    Map<String, Object> interfaceInfo = interfaceList.get(i);
                                    interfaceInfo.put("sendFlag", "false");
                                    interfaceList.set(i, interfaceInfo);
                                }

                            }
                        }
                        inParamList = interfaceList;
                        outParamList = outputList;
                    }


                } catch (Exception ioException) {
                    ioException.printStackTrace();
                }
                lbStatus.setText("发送完成，点击导出查看结果");
            }
        });
    }

    private void getFilePath() {
        this.filePath = this.tfFilePath.getText();
    }

    /**
         * 添加组件
     */
    private void add(Container parent, JComponent... components) {
        for (JComponent c : components)
            parent.add(c);
    }
    /**

     * 打印异常信息

     */

    private void outputException(Exception e) {

        tfFilePath = new JTextField(e + "\n");

        for (StackTraceElement s : e.getStackTrace())

            tfFilePath = new JTextField(tfFilePath.getText() + "	" + s + "\n");

    }



    private static class MyBtn extends JButton {
        private static final long serialVersionUID = 1L;

        public MyBtn(String btnName) {
            super(btnName);
            this.setPreferredSize(new Dimension(120, 30));
        }
    }

    public static void main(String[] args) throws IOException {
        new T3Process();
    }
}
