package com.hundsun.send;

/**
 * @author: yangxl41671
 * @date:
 */

public class ConnectException extends Exception{
    public ConnectException(){};
    public ConnectException(String message) {
        super(message);
    }
    public ConnectException(String message, Throwable cause) {
        super(message, cause);
    }
}

