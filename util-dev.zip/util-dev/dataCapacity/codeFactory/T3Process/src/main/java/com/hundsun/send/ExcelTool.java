package com.hundsun.send;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.hundsun.analysis.JarTool;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

/**
 * @author: yangxl41671
 * @date:
 */
public class ExcelTool {

    public static void doWork(List<Map<String, Object>> inParamList, List<Map<String, Object>> outParamList, String fileType) throws IOException {

        // 1.创建一个工作簿
        Workbook workbook = new HSSFWorkbook();
        // 2.创建一个工作表
        Sheet sheet = workbook.createSheet("结果返回");
        sheet.setDefaultColumnWidth(20);
        CellStyle cellStyle = workbook.createCellStyle();
        cellStyle.setFillForegroundColor(IndexedColors.YELLOW.getIndex());
        cellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        cellStyle.setBorderBottom(BorderStyle.THIN);
        cellStyle.setBorderTop(BorderStyle.THIN);

        CellStyle cellStyle1 = workbook.createCellStyle();
        cellStyle1.setFillForegroundColor(IndexedColors.RED.getIndex());
        cellStyle1.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        cellStyle1.setBorderBottom(BorderStyle.THIN);
        cellStyle1.setBorderTop(BorderStyle.THIN);

        int z = 1;
        int k = 0;
        for (int i = 0; i < inParamList.size(); i ++) {
            Map<String, Object> inParam = inParamList.get(i);
            Row row = sheet.createRow(z++);
            row.setRowStyle(cellStyle);
            Cell id = row.createCell(1);
            id.setCellValue("功能号");
            id.setCellStyle(cellStyle);
            Cell idNote = row.createCell(2);
            idNote.setCellValue(String.valueOf(inParam.get("id")));
            idNote.setCellStyle(cellStyle);
            Cell note = row.createCell(3);
            note.setCellValue("中文名");
            note.setCellStyle(cellStyle);
            Cell noteNote = row.createCell(4);
            noteNote.setCellValue(String.valueOf(inParam.get("note")));
            noteNote.setCellStyle(cellStyle);
            Cell alias = row.createCell(5);
            alias.setCellValue("别名");
            alias.setCellStyle(cellStyle);
            Cell aliasNote = row.createCell(6);
            aliasNote.setCellValue(String.valueOf(inParam.get("alias")));
            aliasNote.setCellStyle(cellStyle);

            Row inParamRow = sheet.createRow(z++);
            Cell inParamNote = inParamRow.createCell(0);
            inParamNote.setCellValue("入参");
            Row inParamValueRow = sheet.createRow(z++);
            Map<Object, Object> paramDict = (Map<Object, Object>) inParam.get("paramDict");
            int j = 1;
            for (Map.Entry<Object, Object> paramDetail : paramDict.entrySet()) {
                Cell inParamKey = inParamRow.createCell(j);
                inParamKey.setCellValue(String.valueOf(paramDetail.getKey()));
                Cell inParamValue = inParamValueRow.createCell(j);
                inParamValue.setCellValue(String.valueOf(paramDetail.getValue()));
                j++;
            }

            if (k < outParamList.size() && (inParam.get("sendFlag") == null || !inParam.get("sendFlag").equals("false"))) {
                Map<String, Object> outParam = outParamList.get(k);
                List<Map<String, Object>> outParams = JSONObject.parseObject(JSON.toJSONString(outParam.get("outParams")), ArrayList.class);

                for (Map<String, Object> paramDetailMap : outParams) {
                    Row outParamRow = sheet.createRow(z++);
                    Cell outParamNote = outParamRow.createCell(0);
                    outParamNote.setCellValue("出参");
                    Row outParamValueRow = sheet.createRow(z++);
                    j = 1;
                    for (Map.Entry<String, Object> outParamDetail : paramDetailMap.entrySet()) {
                        Cell outParamKey = outParamRow.createCell(j);
                        outParamKey.setCellValue(String.valueOf(outParamDetail.getKey()));
                        Cell outParamValue = outParamValueRow.createCell(j);
                        outParamValue.setCellValue(String.valueOf(outParamDetail.getValue()));
                        j++;
                    }
                }

                if (fileType.equals("xls") && outParams.size() == 1) {
                    Map<Object, Object> paramCheckDict = (Map<Object, Object>) inParam.get("paramCheckDict");
                    Row checkParamRow = sheet.createRow(z++);
                    Cell checkParamNote = checkParamRow.createCell(0);
                    checkParamNote.setCellValue("校验（期望/实际）");
                    Row checkParamValueRow = sheet.createRow(z++);
                    j = 1;
                    for (Map.Entry<Object, Object> checkParamDetail : paramCheckDict.entrySet()) {
                        Cell checkParamKey = checkParamRow.createCell(j);
                        checkParamKey.setCellValue(String.valueOf(checkParamDetail.getKey()));
                        Cell checkParamValue = checkParamValueRow.createCell(j);
                        if (!checkParamDetail.getValue().equals(outParams.get(0).get(checkParamDetail.getKey()))) {
                            checkParamValue.setCellStyle(cellStyle1);
                        }
                        checkParamValue.setCellValue(checkParamDetail.getValue() + "/" + outParams.get(0).get(checkParamDetail.getKey()));
                        j++;
                    }
                }
                k++;
            }


            z++;
        }
        // 输出
        String outputPath = ExcelTool.workExcelFileName(JarTool.getJarDir() + "/调用结果/调用结果YYmmddHHMMSS.xls");
        File file1 = new File(JarTool.getJarDir() + "/调用结果");
        file1.mkdirs();

        FileOutputStream fileOutputStream = new FileOutputStream(outputPath);
        workbook.write(fileOutputStream);
        // 6.关闭流
        fileOutputStream.close();
        System.out.println("结果输出成功！");
    }

    public static String workExcelFileName(String fileName) {
        DateFormat df = new SimpleDateFormat("yyyyMMddHHmmss");
        Calendar calendar = Calendar.getInstance();
        String dateName = df.format(calendar.getTime());
        return fileName.replace("YYmmddHHMMSS", dateName);
    }
}
