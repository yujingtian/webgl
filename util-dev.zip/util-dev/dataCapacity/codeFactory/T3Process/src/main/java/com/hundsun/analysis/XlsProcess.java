package com.hundsun.analysis;

import com.hundsun.send.ConnectException;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.CellType;

import java.io.*;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author: yangxl41671
 * @date:
 */
public class XlsProcess {
    public static Map<String, Object> getParams(String path) throws ConnectException {

        File file = new File(path);
        try {
            HSSFWorkbook workbook = new HSSFWorkbook(new FileInputStream(file));
            HSSFSheet sheet = workbook.getSheetAt(0);
            return getData(sheet);
        } catch (IOException e) {
            e.printStackTrace();
            throw new ConnectException(e.getMessage());
        }
    }

    public static Map<String, Object> getData(HSSFSheet sheet) throws ConnectException {

        String shardingInfo = "";
        String service = "";
        // 得到总行数
        HSSFRow row = sheet.getRow(1);
        if (getStringCellValue(row.getCell(0)).equals("功能号")) {
            if (getStringCellValue(row.getCell(9)).equals("shardingInfo")){
                shardingInfo = getStringCellValue(row.getCell(10));
            } else {
                throw new ConnectException("格式错误，表(1,9)应为\"shardingInfo\"");
            }
            if (getStringCellValue(row.getCell(13)).equals("service")){
                service = getStringCellValue(row.getCell(14));
            } else {
                throw new ConnectException("格式错误，表(1,13)应为\"shardingInfo\"");
            }
        } else {
            throw new ConnectException("格式错误，表(1,0)应为\"功能号\"");
        }

        int rowNum = sheet.getLastRowNum();
        int i = 1;
        List<Map<String, Object>> interfaceList = new ArrayList<>();
        while (i <= rowNum) {
            row = sheet.getRow(i);
            if (row != null && getStringCellValue(row.getCell(0)).equals("功能号")) {
                Map<String, Object> interfaceDict = new HashMap<>();

                String id = getStringCellValue(row.getCell(1));
                String note;
                String alias;
                if (getStringCellValue(row.getCell(5)).equals("备注")){
                    note = getStringCellValue(row.getCell(6));
                } else {
                    throw new ConnectException("格式错误，表(" + i + ",5)应为\"备注\"");
                }
                if (getStringCellValue(row.getCell(18)).equals("别名")){
                    alias = getStringCellValue(row.getCell(19));
                } else {
                    throw new ConnectException("格式错误，表(" + i + ",18)应为\"别名\"");
                }

                HSSFRow rowKey = sheet.getRow(++i);
                if (!getStringCellValue(rowKey.getCell(0)).equals("入参")) {
                    throw new ConnectException("格式错误，表(" + i + ",0)应为\"入参\"");
                }
                HSSFRow rowValue = sheet.getRow(++i);
                if (!getStringCellValue(rowValue.getCell(0)).equals("值")) {
                    throw new ConnectException("格式错误，表(" + i + ",0)应为\"值\"");
                }
                Map<String, String> paramDict = new HashMap<>();
                int keyColNum = rowKey.getPhysicalNumberOfCells();
                for (int j = 1; j < keyColNum; j++) {
                    paramDict.put(getStringCellValue(rowKey.getCell(j)), getStringCellValue(rowValue.getCell(j)));
                }

                HSSFRow rowCheckKey = sheet.getRow(++i);
                if (!getStringCellValue(rowCheckKey.getCell(0)).equals("出参")) {
                    throw new ConnectException("格式错误，表(" + i + ",0)应为\"出参\"");
                }
                HSSFRow rowCheckValue = sheet.getRow(++i);
                if (!getStringCellValue(rowCheckValue.getCell(0)).equals("校验值")) {
                    throw new ConnectException("格式错误，表(" + i + ",0)应为\"校验值\"");
                }
                int keyCheckColNum = rowCheckKey.getPhysicalNumberOfCells();
                Map<String, String> paramCheckDict = new HashMap<>();
                for (int j = 1; j < keyCheckColNum; j++) {
                    paramCheckDict.put(getStringCellValue(rowCheckKey.getCell(j)), getStringCellValue(rowCheckValue.getCell(j)));
                }
                interfaceDict.put("id", id);
                interfaceDict.put("note", note);
                interfaceDict.put("alias", alias);
                interfaceDict.put("paramDict", paramDict);
                interfaceDict.put("paramCheckDict", paramCheckDict);
                interfaceList.add(interfaceDict);
            }

            i++;
        }


        Map<String, Object> xlsObj = new HashMap<>();
        xlsObj.put("shardingInfo", shardingInfo);
        xlsObj.put("security", "");
        xlsObj.put("service", service);
        xlsObj.put("interfaceList", interfaceList);
        System.out.println(xlsObj);
        return xlsObj;
    }


    /**
     * @ description:  获取单元格数据内容为字符串类型的数据
     * @param cell 单元格
     */
    private static String getStringCellValue(HSSFCell cell) {
        String strCell = "";
        switch (cell.getCellType()) {
            case STRING:
                strCell = cell.getStringCellValue();
                break;
            case NUMERIC:
                strCell = convertDoubleToString(cell.getNumericCellValue());
                break;
            case BOOLEAN:
                strCell = String.valueOf(cell.getBooleanCellValue());
                break;
            case BLANK:
                strCell = "";
                break;
            default:
                strCell = "";
                break;
        }
        if (strCell.equals("") || strCell == null) {
            return "";
        }
        if (cell == null) {
            return "";
        }
        return strCell;
    }

    private static String convertDoubleToString(double val) {
        BigDecimal bd = new BigDecimal(String.valueOf(val));
        return bd.stripTrailingZeros().toPlainString();
    }
}