package com.hundsun.actutils.utils;

import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;
import java.util.function.Consumer;
import java.util.function.Function;

import static com.hundsun.actutils.utils.PubUtils.split;

/**
 * @author studio-auto
 * @date
 */
@Slf4j
public class ParallelUtils {

    /** 定义线程池中线程数 */
    private static final int MAX_THREAD = (int)(Runtime.getRuntime().availableProcessors());

    /** 阻塞队列大小 */
    private static final int BLOCKING_QUEUE_SIZE = 2000;

    /**
     * 线程空闲存活时间：0
     * 阻塞队列：ArrayBlockingQueue
     * 拒绝策略：休息1秒之后再次提交任务
     */
    private static ExecutorService paexecutor =
            new ThreadPoolExecutor(MAX_THREAD, MAX_THREAD, 0L, TimeUnit.MILLISECONDS,
                    new ArrayBlockingQueue<>(BLOCKING_QUEUE_SIZE),
                    (r) -> {
                        return new Thread(r);
                    },
                    (r, e) -> {
                        if (!e.isShutdown()) {
                            try {
                                Thread.sleep(1000);
                            } catch (Exception ex){
                                ex.printStackTrace();
                            }
                            e.submit(r);
                        }else{
                            r.run();
                        }
                    });

    public static <T, R> void resolve(List<T> todoList, Function<T, R> action, List<R> results, List<T> errorList) {
        CompletableFuture[] cfs = todoList.stream()
                .map(o -> CompletableFuture.supplyAsync(() -> action.apply(o), paexecutor)
                        .exceptionally((t) -> {
//                            log.error("并发处理异常：{}, 数据: {}, 异常信息{}", t.getCause(), o, t);
                            log.error("数据: " + o + ",并发处理异常:", t);
                            return null;
                        })
                        .whenComplete((r, th) -> {
                            if (r == null) {
                                errorList.add(o);
                            } else {
                                results.add(r);
                            }
                        }))
                .toArray(CompletableFuture[]::new);
        CompletableFuture.allOf(cfs).join();
    }


    public static <T> void execute(List<T> todoList, Consumer<T> consumer, List<T> errorList) {
        CompletableFuture[] cfs = todoList.stream()
                .map(o -> CompletableFuture.runAsync(() -> consumer.accept(o), paexecutor)
                        .exceptionally((t) -> {
//                            log.error("初始化异常: {}", o);
                            log.error("初始化异常：" + o + ",异常信息：", t);
                            errorList.add(o);
                            return null;
                        }))
                .toArray(CompletableFuture[]::new);
        CompletableFuture.allOf(cfs).join();
    }

    public static <T, R> List<R> resolveByPatch(List<T> inputList, Function<T, R> action, Integer patchSize, Integer retryNum) {
        List<R> outputList = new CopyOnWriteArrayList<>();
        List<T> errorList = new CopyOnWriteArrayList<>();
        ArrayList<R> redoLogList;
        ArrayList<T> redoErrList;

        List<List<T>> inputLists = split(inputList, patchSize);

        for (int i = 0; i < inputLists.size(); i++) {
            resolve(inputLists.get(i), action, outputList, errorList);
        }

        // 异常重发
        while (retryNum > 0 && !errorList.isEmpty()) {
            redoLogList = new ArrayList<>();
            redoErrList = new ArrayList<>();
            System.out.printf("异常重发条数：%d .", errorList.size());
            ParallelUtils.resolve(errorList, action, redoLogList, redoErrList);
            outputList.addAll(redoLogList);
            errorList = redoErrList;
            -- retryNum;
        }

        return outputList;
    }


}
