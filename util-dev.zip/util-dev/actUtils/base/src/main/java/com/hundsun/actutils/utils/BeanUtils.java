package com.hundsun.actutils.utils;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeansException;
import org.springframework.cglib.beans.BeanMap;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@Component
@Slf4j
public class BeanUtils implements ApplicationContextAware {

    private static ApplicationContext appCtx;

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        appCtx = applicationContext;
    }
    public static Object getBean(String beanName) {
        return appCtx.getBean(beanName);
    }
    public static <T> T getBean(Class<T> clz) {
        return (T) appCtx.getBean(clz);
    }

    /**
     * bean转map工具方法
     * @param bean
     * @return
     * @param <T>
     */
    public static <T> Map<String, String> beanToMap(T bean) {
        BeanMap beanMap = BeanMap.create(bean);
        Map<String, String> map = new HashMap<>();

        beanMap.forEach((key, value) -> {
            map.put(String.valueOf(key), value.toString());
        });
        return map;
    }

    /**
     * 数据拷贝
     * 全属性拷贝
     * @param target 目标对象
     * @param source 源对象
     */
    public static void copyData(Object target, Object source) {
        try {
            org.springframework.beans.BeanUtils.copyProperties(source, target);
        } catch (BeansException  e) {
            log.error("BeanUtil property copy failed :{}", e);
        }
        catch (Exception e) {
            log.error("BeanUtil property copy failed :{}", e);
        }
    }
}