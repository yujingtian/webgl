package com.hundsun.actutils.entity;

import lombok.Data;

/**
 * 文件描述
 *
 * @ProductName Hundsun HEP
 * @ProjectName actUtils
 * @Package com.hundsun.actutils.entity
 * @Description note
 * @Author xuzd47380
 * @CreateDate 2023/5/31 14:27
 * @UpdateRemark The modified content
 * @Version 1.0
 * @Date 2023/5/31
 * <p>
 * Copyright  2023 Hundsun Technologies Inc. All Rights Reserved
 **/
@Data
public class Fundaccount {

    private String clientId = " ";

    private String fundAccount = " ";

    private String tradePassword = " ";

    private String fundPassword = " ";

    public Fundaccount(String clientId, String fundAccount, String tradePassword, String fundPassword) {
        this.clientId = clientId;
        this.fundAccount = fundAccount;
        this.tradePassword = tradePassword;
        this.fundPassword = fundPassword;
    }

    public Fundaccount(){}
}
