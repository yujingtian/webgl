package com.hundsun.actutils.entity;

import lombok.Data;
import lombok.ToString;

/**
 * 文件描述
 *
 * @ProductName Hundsun HEP
 * @ProjectName actUtils
 * @Package com.hundsun.actutils.entity
 * @Description note
 * @Author xuzd47380
 * @CreateDate 2023/5/30 10:08
 * @UpdateRemark The modified content
 * @Version 1.0
 * @Date 2023/5/30
 * <p>
 * Copyright  2023 Hundsun Technologies Inc. All Rights Reserved
 **/

@Data
public class Allbranch {

    /**
     * 分支机构
     */
    private Integer branchNo = 0;
    /**
     * 机构名称
     */
    private String branchName = " ";

    public Allbranch(int branchNo, String branchName) {
        this.branchNo = branchNo;
        this.branchName = branchName;
    }

    public Allbranch(){

    }

    public String toString () {
        return branchNo + "-" + branchName;
    }

}
