package com.hundsun.actutils.controller;

import com.hundsun.actutils.constant.ActUtilConstant;
import com.hundsun.actutils.dao.AllbranchDAO;
import com.hundsun.actutils.dao.FundAccountDAO;
import com.hundsun.actutils.entity.Allbranch;
import com.hundsun.actutils.entity.Fundaccount;
import com.hundsun.actutils.utils.BeanUtils;
import com.hundsun.actutils.utils.ParallelUtils;
import com.hundsun.jrescloud.common.t2.event.T3Event;
import com.hundsun.jrescloud.common.util.T3EncryptUtil;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.*;

import static com.hundsun.actutils.utils.T3Utils.*;

/**
 * 文件描述
 *
 * @ProductName Hundsun HEP
 * @ProjectName actUtils
 * @Package com.hundsun.actutils
 * @Description note
 * @Author xuzd47380
 * @CreateDate 2023/5/8 10:49
 * @UpdateRemark The modified content
 * @Version 1.0
     * @Date 2023/5/8
 * <p>
 * Copyright  2023 Hundsun Technologies Inc. All Rights Reserved
 **/

@Slf4j
public class PwdResetController {


    /**
     * 查询所有营业部
     * @return
     */
    public List<Allbranch> getAllBranch() {
        AllbranchDAO allbranchDAO = BeanUtils.getBean(AllbranchDAO.class);
        return allbranchDAO.getAllbranch();
    }

    /**
     * 查询数据库获取营业部下资产账户号
     * @return
     */
    public List<Fundaccount> getFundAccountByBranchNo(List<String> branchNoList) {
        FundAccountDAO fundAccountDAO = BeanUtils.getBean(FundAccountDAO.class);
        return fundAccountDAO.getFundAccountByBranchNo(branchNoList);
    }

    /**
     * 批量指定密码重置
     *
     * @return
     */
    public putPasswordResetOutput putPasswordReset(List<Fundaccount> fundacctresetList, String password, Character resetMode) {
        putPasswordResetOutput output = new putPasswordResetOutput();

        if (ActUtilConstant.INTERFACE_MOD.equals(resetMode)) {
            T3ServiceInit();
        }

        List<putFundaccountPwdModRegExtInput> extInputs = getExtInput(fundacctresetList, password);

        ArrayList<Result> results = new ArrayList<>();
        if (ActUtilConstant.INTERFACE_MOD.equals(resetMode)) {
            List<MyEvent> t3EventList = getT3Event("act.putFundaccountPwdModRegExt", extInputs);
            List<MyEvent> t3OutputList = ParallelUtils.resolveByPatch(t3EventList, event -> T3EventSendAndReceive(event), 500, 10);

            // 处理结果获取
            t3OutputList.stream()
                    .map(o -> getEventLog(o))
                    .forEach(result -> {
                        if (result.isSuccess) {
                            output.getSuccessLogList().add(result.getMassage());
                        } else {
                            output.getErrorLogList().add(result.getMassage());
                        }
            });
        } else if (ActUtilConstant.DATEBASE_MOD.equals(resetMode)){
            List<UpdateFundaccountPasswordOutput> dbOutputList = ParallelUtils.resolveByPatch(extInputs, extInput -> updateFundaccountPasswordByDB(extInput), 500, 10);

            // 处理结果获取
            dbOutputList.stream()
                    .map(o -> getDBLog(o))
                    .forEach(result -> {
                        if (result.isSuccess) {
                            output.getSuccessLogList().add(result.getMassage());
                        } else {
                            output.getErrorLogList().add(result.getMassage());
                        }
                    });
        }
        output.setRemark("批量密码重置完成，处理成功条数：" + output.getSuccessLogList().size() + "，处理失败条数：" + output.getErrorLogList().size());
        return output;
    }

    /**
     * 获取Ext接口入参
     * @param fundacctList
     * @param password
     * @return
     */
    private List<putFundaccountPwdModRegExtInput> getExtInput(List<Fundaccount> fundacctList, String password) {
        List<putFundaccountPwdModRegExtInput> extInputs = new ArrayList<>();


        for (int i = 0; i < fundacctList.size(); i++) {
            Fundaccount fundaccount = fundacctList.get(i);
            putFundaccountPwdModRegExtInput fundExtInput = new putFundaccountPwdModRegExtInput();
            putFundaccountPwdModRegExtInput tradeExtInput = new putFundaccountPwdModRegExtInput();
            fundExtInput.setOpEntrustWay('0');
            fundExtInput.setOpStation("0");
            fundExtInput.setClientId(fundaccount.getClientId());
            fundExtInput.setFundAccount(fundaccount.getFundAccount());
            fundExtInput.setPasswordType(ActUtilConstant.FUND_PASSWORD);
            fundExtInput.setNewPassword(StringUtils.isBlank(password) ? fundaccount.getFundPassword() : password);
            fundExtInput.setRemark("工具批量重置密码");
            extInputs.add(fundExtInput);

            BeanUtils.copyData(tradeExtInput, fundExtInput);
            tradeExtInput.setPasswordType(ActUtilConstant.TRADE_PASSWORD);
            tradeExtInput.setNewPassword(StringUtils.isBlank(password) ? fundaccount.getTradePassword() : password);
            extInputs.add(tradeExtInput);

        }


        return extInputs;
    }

    /**
     * T3调用结果日志解析
     * @param outputEvent
     */
    public static Result getEventLog(MyEvent outputEvent) {
        Result output = new Result();

        T3Event event = outputEvent.getT3Event();
        String respBody = null;
        Integer ReturnCode = -1;
        try {
            ReturnCode = event.getReturnCode();
            respBody = event.getEventBody();
        } catch (Exception e2) {
            output.setSuccess(false);
            output.setMassage(outputEvent.getFundAccount() + "\t:\t" + "应答失败");
            return output;
        }
        if (ReturnCode != 0) {
            //业务错误，或者小于0为平台错误
            output.setSuccess(false);
            output.setMassage(outputEvent.getFundAccount() + "\t:\t" + event.getErrorNo() + "|" + event.getErrorInfo());
        } else {
            // 正常应答
            output.setSuccess(true);
            output.setMassage(outputEvent.getFundAccount() + "\t:\t" + respBody);
        }
        return output;
    }

    private Result getDBLog(UpdateFundaccountPasswordOutput dbOuput) {
        Result output = new Result();
        String passwordTypeStr = ActUtilConstant.FUND_PASSWORD.equals(dbOuput.passwordType) ? "资金密码" : "交易密码";
        if (StringUtils.isBlank(dbOuput.getErrorInfo())) {
            output.setSuccess(true);
            output.setMassage(dbOuput.getFundAccount() + "\t:\t" + passwordTypeStr + "处理成功，影响数据条数：" + dbOuput.getDealNum());
        } else {
            output.setSuccess(false);
            output.setMassage(dbOuput.getFundAccount() + "\t:\t" + passwordTypeStr + "处理失败，报错信息：" + dbOuput.getErrorInfo());
        }
        return output;
    }

    /**
     * 调用dao方法重置密码
     * @param input
     * @return
     */
    private UpdateFundaccountPasswordOutput updateFundaccountPasswordByDB(putFundaccountPwdModRegExtInput input) {
        UpdateFundaccountPasswordOutput output = new UpdateFundaccountPasswordOutput();
        // todo 加密
        String encodeTradePassword = fundAccountPwdEncode(input.getFundAccount(), input.getNewPassword());
        String encodeFundPassword = fundAccountPwdEncode(input.getFundAccount(), input.getNewPassword());

        try {
            FundAccountDAO fundAccountDAO = BeanUtils.getBean(FundAccountDAO.class);
            output.setDealNum(fundAccountDAO.updateFundaccountPassword(input.getFundAccount(), encodeTradePassword, encodeFundPassword));
        } catch (Exception e) {
            output.setErrorInfo(e.getMessage());
        }
        output.setFundAccount(input.getFundAccount());
        output.setPasswordType(input.getPasswordType());
        return output;
    }

    /**
     * 资产账户加密
     * @param fundAccount 资产账户
     * @param clearPwd 明文密码
     * @return 加密后的密码
     */
    public static String fundAccountPwdEncode(String fundAccount, String clearPwd) {
        String encodePwd = T3EncryptUtil.encode(fundAccount, '2', '1', clearPwd);
        return encodePwd;
    }

    @Data
    public class putPasswordResetOutput {
        List<String> successLogList = new ArrayList<>();
        List<String> errorLogList = new ArrayList<>();
        String remark = "";
    }

    @Data
    private class putFundaccountPwdModRegExtInput {
        private String opStation = " ";
        private Character opEntrustWay = ' ';
        private String clientId = " ";
        private String fundAccount = " ";
        private Character passwordType = ' ';
        private String newPassword = " ";
        private String remark = " ";
    }

    @Data
    private class UpdateFundaccountPasswordOutput {
        private Integer dealNum = 0;
        private String fundAccount = "";
        private String errorInfo = "";
        private Character passwordType = ' ';
    }

    @Data
    public static class Result {
        boolean isSuccess;
        String massage;
    }
}
