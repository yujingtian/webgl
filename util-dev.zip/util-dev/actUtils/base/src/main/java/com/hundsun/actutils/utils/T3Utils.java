package com.hundsun.actutils.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.hundsun.jrescloud.common.t2.context.ContextUtil;
import com.hundsun.jrescloud.common.t2.event.EventType;
import com.hundsun.jrescloud.common.t2.event.T3Event;
import com.hundsun.t2sdk.interfaces.IClient;
import com.hundsun.t2sdk.interfaces.T2SDKException;
import com.hundsun.t3sdk.impl.client.T3Services;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * 文件描述
 *
 * @ProductName Hundsun HEP
 * @ProjectName actUtils
 * @Package com.hundsun.actutils.utils
 * @Description note
 * @Author xuzd47380
 * @CreateDate 2023/11/13 10:43
 * @UpdateRemark The modified content
 * @Version 1.0
 * @Date 2023/11/13
 * <p>
 * Copyright  2023 Hundsun Technologies Inc. All Rights Reserved
 **/
@Slf4j
public class T3Utils {

    private static IClient iClient = null;

    /**
     * 初始化并获取T3sdk连接
     * @return
     */
    public static boolean T3ServiceInit() {
        if (Objects.nonNull(iClient)) {
            return true;
        }

        T3Services server = T3Services.getInstance();

        String logInfo = "";
        // T3SDK服务实例化（getInstance）
        server.setT2sdkConfigString("config/t3sdk-config.xml");
        try {
            // T3SDK服务初始化（init）该函数在整个应用中只可以调用一次，并且不可以多线程调用。
            server.init();
        } catch (T2SDKException e1) {
            log.info("T3SDK服务初始化失败");
            log.info(e1.getErrorNo() + e1.getErrorInfo() + e1.getErrorMessage());
        }
        // T3SDK服务启动（start）该函数在整个应用中只可以调用一次，并且不可以多线程调用。
        server.start();

        // 等待创建完成，防止获取连接失败
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        log.info("T3SDK服务启动");

        try {
            // 获取上级节点接口（getClient） clientName为t3sdk-config.xml配置的parent节点。在初始化以及启动服务后，应用层就可以准备业务数据并获取对应服务端的客户端接口，进行数据的收发操作。该接口可以多线程调用。
            iClient = server.getClient("poc");
            log.info("节点获取成功");
            return true;
        } catch (T2SDKException e1) {
            log.info("T3SDK节点获取失败");
            log.info(e1.getErrorNo() + e1.getErrorInfo() + e1.getErrorMessage());
        }
        return false;
    }

    /**
     * 获取T3Event
     * @param functionId
     * @param objectList
     * @return
     */
    public static List<MyEvent> getT3Event(String functionId, List<?> objectList) {
        ArrayList<MyEvent> events = new ArrayList<>();
        // 设置服务信息
        String[] gsvInfo = new String[3];
        gsvInfo[1] = "hsbroker.act";
        String dataJson = null;

        for (Object obj : objectList) {
            dataJson = JsonUtils.toString(obj);

            // 构建功能event
            T3Event event = (T3Event) ContextUtil.getServiceContext().getT3EventFactory().getEventByAlias(functionId, EventType.ET_REQUEST);
            event.setStringArrayAttributeValue("23", gsvInfo);
            event.setStringAttributeValue("33", "{\"iar_token_checked\":\"1\"}");
            event.setEventBody(dataJson);

            MyEvent myEvent = new MyEvent();
            myEvent.setT3Event(event);
            BeanUtils.copyData(myEvent, obj);
            events.add(myEvent);
        }
        return events;
    }


    /**
     * 调用T3接口
     *
     * @param myEvent
     * @return
     */
    public static MyEvent T3EventSendAndReceive(MyEvent myEvent) {
        MyEvent rsp = new MyEvent();
        try {
            // 同步发送（sendReceive）
            T3Event returnEvent = (T3Event) iClient.sendReceive(myEvent.getT3Event());
            rsp.setT3Event(returnEvent);
        } catch (T2SDKException e) {
            // TODO Auto-generated catch block
            T3Event t3Event = new T3Event();
            t3Event.setReturnCode(-1);
            t3Event.setStringAttributeValue("19", e.getErrorNo());
            t3Event.setStringAttributeValue("20", e.getErrorInfo());
            rsp.setT3Event(t3Event);
            log.info("sendReceive " + e.getErrorNo() + "|" + e.getErrorInfo() + "|" + e.getErrorMessage());
        }
        rsp.setFundAccount(myEvent.getFundAccount());
        return rsp;
    }






    /**
     * 自定义T3Event扩展类，用于记录信息
     */
    @Data
    public static class MyEvent {
        private T3Event t3Event;
        private String fundAccount;
    }
}
