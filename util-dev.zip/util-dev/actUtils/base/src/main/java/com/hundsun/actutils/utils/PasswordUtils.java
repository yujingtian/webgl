/**     
  * 文件描述
  * @ProductName:    Hundsun HEP
  * @ProjectName:    act-pub
  * @Package:        com.hundsun.broker.act.pub.util
  * @FileName:		 PasswordUtils.java
  * @TypeName:		 PasswordUtils
  * @Description:    note
  * @Author:         hengxx25187
  * @CreateDate:     2019年12月25日 上午10:19:06
  * @UpdateUser:     hengxx25187
  * @UpdateDate:     2019年12月25日 上午10:19:06
  * @UpdateRemark:   The modified content
  * @Version:        1.0
  *
  * Copyright © 2019 Hundsun Technologies Inc. All Rights Reserved
**/
package com.hundsun.actutils.utils;


import com.hundsun.jrescloud.common.util.T3EncryptUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
* @Author hengxx25187
* @Date 2019年12月25日
*/
public class PasswordUtils {
    
    private static final Logger LOGGER = LoggerFactory.getLogger(PasswordUtils.class);
    
    /**
     * 国密加密方式
     */
    private static final char ENCODE_TYPE_GM = '1';
    /**
     * 一户通账户
     */
    private static final char CLIENT_ID = '1';
    /**
     * 资产账户
     */
    private static final char FUND_ACCOUNT = '2';
    
    /**
     * 一户通账户密码加密
     * @param clientId 一户通账户
     * @param clearPwd 明文密码
     * @return 加密后的密码
     */
    public static String clientIdPwdEncode(String clientId, String clearPwd) {        
        String encodePwd = T3EncryptUtil.encode(clientId, CLIENT_ID, ENCODE_TYPE_GM, clearPwd);
        return encodePwd;
    }

    /**
     * 一户通账户密码解密（不报错返回）
     * @param clientId 一户通账户
     * @param encodePwd 加密密码
     * @return 明文密码
     */
    public static String clientIdPwdDecodeNoCrash(String clientId, String encodePwd) {
        return T3EncryptUtil.decode(encodePwd, clientId, null, null);
    }
    
    /**
     * 资产账户加密
     * @param fundAccount 资产账户
     * @param clearPwd 明文密码
     * @return 加密后的密码
     */
    public static String fundAccountPwdEncode(String fundAccount, String clearPwd) {
        String encodePwd = T3EncryptUtil.encode(fundAccount, FUND_ACCOUNT, ENCODE_TYPE_GM, clearPwd);
        return encodePwd;
    }
    
    /**
     * 一户通账户密码解密
     * @param clientId 一户通账户
     * @param encodePwd 加密密码
     * @return 明文密码
     */
    public static String clientIdPwdDecode(String clientId, String encodePwd) {
       String clearPwd = T3EncryptUtil.decode(encodePwd, clientId, null, null);
       if (clearPwd == null) {
           LOGGER.error("解密失败, client_id:{}", clientId);
       }
       return clearPwd; 
    }
    
    /**
     * 资产账户密码解密
     * @param fundAccount 资产账户
     * @param encodePwd 加密密码
     * @return 明文密码
     */
    public static String fundAccountPwdDecode(String fundAccount, String encodePwd) {
        String clearPwd = T3EncryptUtil.decode(encodePwd, null, fundAccount, null);
        if (clearPwd == null) {
            LOGGER.error("解密失败, fund_account:{}", fundAccount);
        }
        return clearPwd;
    }

    /**
     * 资产账户密码解密（不报错返回）
     * @param fundAccount 资产账户
     * @param encodePwd 加密密码
     * @return 明文密码；若解密失败返回null
     */
    public static String fundAccountPwdDecodeNoCrash(String fundAccount, String encodePwd) {
        return T3EncryptUtil.decode(encodePwd, null, fundAccount, null);
    }
}
