package com.hundsun.actutils.dao.impl;

import com.hundsun.actutils.dao.AllbranchDAO;
import com.hundsun.actutils.entity.Allbranch;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;


/**
 * 文件描述
 *
 * @ProductName Hundsun HEP
 * @ProjectName actUtils
 * @Package com.hundsun.actutils.dao.impl
 * @Description note
 * @Author xuzd47380
 * @CreateDate 2023/5/30 10:19
 * @UpdateRemark The modified content
 * @Version 1.0
 * @Date 2023/5/30
 * <p>
 * Copyright  2023 Hundsun Technologies Inc. All Rights Reserved
 **/
@Service
public class AllBranchDAOImpl implements AllbranchDAO {

    @Resource
    private JdbcTemplate jdbcTemplate;

    @Override
    public List<Allbranch> getAllbranch() {
        String querySQL = "select branch_no, branch_name from act_all_branch ORDER BY BRANCH_NO";
        List<Allbranch> vo = jdbcTemplate.query(querySQL, new BeanPropertyRowMapper(Allbranch.class));
        return vo;
    }
}