package com.hundsun.actutils.utils;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.PropertyNamingStrategy;
import com.alibaba.fastjson.parser.Feature;
import com.alibaba.fastjson.serializer.SerializeConfig;
import com.hundsun.jrescloud.common.util.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;
import java.util.Objects;

/**
 * JsonUtils.java类
 * @author gukr15480
 * @date 2019年11月14日
 */
@Component
public class JsonUtils {

    private static SerializeConfig snakeCaseSerializeConfig;

    @Resource(name = "snakeCaseSerializeConfig")
    public void setSerializeConfig(SerializeConfig serializeConfig) {
        JsonUtils.snakeCaseSerializeConfig = serializeConfig;
    }

    /**
     * logger
     */
    private static Logger logger = LoggerFactory.getLogger(JsonUtils.class);

    public static <T> T parseObject(String text, Class<T> clazz) {
    	if (StringUtils.isBlank(text)) {
    		return null;
    	}
        try {
            return JSON.parseObject(text, clazz);
        } catch (Exception e) {
            logger.error("JSON解析失败：" + e.getMessage());
            logger.error("JSON原值：" + text);
            return null;
        }
    }

    /**
     * 按照字符串顺序解析为JSONObject
     * @param text
     * @param features
     * @return
     */
    public static JSONObject parseJSONObject(String text, Feature... features) {
        if (StringUtils.isBlank(text)) {
            return null;
        }
        try {
            return JSONObject.parseObject(text, features);
        } catch (Exception e) {
            logger.error("JSON解析失败：" + e.getMessage());
            logger.error("JSON原值：" + text);
            return null;
        }
    }
    
    public static <T> List<T> parseList(String text, Class<T> clazz) {
    	if (StringUtils.isBlank(text)) {
    		return null;
    	}
        try {
            return JSON.parseArray(text, clazz);
        } catch (Exception e) {
            logger.error("JSON解析失败：" + e.getMessage());
            logger.error("JSON原值：" + text);
            return null;
        }
    }

    /**
     * javabean转为json字符串（蛇形风格）
     *
     * @param object
     * @return
     */
    public static String toString(Object object) {
    	if (object == null) {
    		return null;
    	}

        SerializeConfig snakeCaseSerializeConfig=new SerializeConfig();
        snakeCaseSerializeConfig.propertyNamingStrategy= PropertyNamingStrategy.SnakeCase;

        try {
            return JSON.toJSONString(object, snakeCaseSerializeConfig);
        } catch (Exception e) {
            logger.error("转String失败：" + e.getMessage());
            logger.error("object值：" + object);
            return null;
        }
    }

    public static String toJsonString(Object object) {
        if (object == null) {
            return null;
        }
        try {
            return JSON.toJSONString(object);
        } catch (Exception e) {
            logger.error("转String失败：" + e.getMessage());
            logger.error("object值：" + object);
            return null;
        }
    }
}

