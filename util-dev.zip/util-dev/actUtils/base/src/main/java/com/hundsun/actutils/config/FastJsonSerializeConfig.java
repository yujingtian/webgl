package com.hundsun.actutils.config;

import com.alibaba.fastjson.PropertyNamingStrategy;
import com.alibaba.fastjson.serializer.SerializeConfig;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

/**
 * 文件描述
 *
 * @ProductName Hundsun HEP
 * @ProjectName ucm-dfzq-dev
 * @Package com.hundsun.broker.ucm.dfzq.pub.config
 * @Description note
 * @Author xuzd47380
 * @CreateDate 2023/9/22 13:41
 * @UpdateRemark The modified content
 * @Version 1.0
 * @Date 2023/9/22
 * <p>
 * Copyright  2023 Hundsun Technologies Inc. All Rights Reserved
 **/

@Configuration
public class FastJsonSerializeConfig {

    @Bean("snakeCaseSerializeConfig")
    @Scope("singleton")
    public SerializeConfig snakeCaseSerializeConfig() {
        SerializeConfig config = new SerializeConfig();
        config.propertyNamingStrategy = PropertyNamingStrategy.SnakeCase;
        return config;
    }

    @Bean("pascalCasSerializeConfig")
    @Scope("singleton")
    public SerializeConfig pascalCasSerializeConfig() {
        SerializeConfig config = new SerializeConfig();
        config.propertyNamingStrategy = PropertyNamingStrategy.PascalCase;
        return config;
    }
}