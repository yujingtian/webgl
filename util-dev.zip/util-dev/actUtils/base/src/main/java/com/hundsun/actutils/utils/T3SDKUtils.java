package com.hundsun.actutils.utils;

import com.hundsun.jrescloud.common.gm.GMCryptoUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.Charset;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @ClassName T3SDKUtils
 * @Description TODO
 * @Author hengxx25187
 * @Date 2023/4/20 17:11
 */
public class T3SDKUtils {

    public static String t3SdkEncode(String authId, char authType, char encodeType, String clearPassword) {
        return encode(authId, authType, encodeType, clearPassword);
    }

    public static String t3SdkDecode(String authId, String encodePwd) {
        String clearPwd = decode(encodePwd, authId, (String)null, (String)null);
        if (clearPwd != null) {
            return clearPwd;
        } else {
            clearPwd = decode(encodePwd, (String)null, authId, (String)null);
            if (clearPwd != null) {
                return clearPwd;
            } else {
                clearPwd = decode(encodePwd, (String)null, (String)null, authId);
                return clearPwd;
            }
        }    }

    private static final Logger LOGGER = LoggerFactory.getLogger(T3SDKUtils.class);
    private static final List<Character> UN_MESSY_CODE_LIST = Arrays.asList('|', '!', '@', '#', '$', '%', '^', '&', '*', '(', ')', '-', '=', '\\', '/', '_', '+', '{', '}', '[', ']', ':', '"', ';', '\'', '<', '>', '?', ',', '.', '~', '`');
    private static final Charset DEFAULT_CHARSET = Charset.forName("utf-8");
    private static final byte[] IV_FOR_NO_PADDING = new byte[]{1, -1, 3, 6, -2, 25, 6, 9, 23, 36, 98, 100, 121, -24, 33, 1};
    private static final String ALGORITHM_NOPADDING = "AES/CBC/NoPadding";
    private static final String AES = "AES";
    private static final String ENCODE_KEY = "wexihuanjingjing";
    private static final int SHORTEST_LENGTH = 2;
    private static final char ENCODE_TYPE_AES = '0';
    private static final char ENCODE_TYPE_GM = '1';
    private static final char AUTH_TYPE_CLIENTIID = '1';
    private static final char AUTH_TYPE_FUNDACCOUNT = '2';
    private static final char AUTH_TYPE_OPOPERATORNO = '3';
    private static final int MAX_ENCODEKEY_LEN = 16;
    private static final char PADDING_CHAR = '\u0007';

    public static String encode(String authId, char authType, char encodeType, String clearPassword) {
        byte[] key = calcSecretKey(authId, "wexihuanjingjing");
        byte[] encrypt = null;
        byte[] data = fill(clearPassword.getBytes(DEFAULT_CHARSET));
        if (encodeType == '0') {
            encrypt = encrypt(data, key);
        } else {
            if (encodeType != '1') {
                throw new IllegalArgumentException("Excepted encodeType is 0 or 1. encodeType: " + encodeType);
            }

            encrypt = GMCryptoUtil.SM4Encrypt(data, key);
        }

        byte[] result = new byte[encrypt.length + 2];
        System.arraycopy(encrypt, 0, result, 1, encrypt.length);
        result[0] = (byte)(encodeType - 48);
        result[encrypt.length + 1] = (byte)(authType - 48);
        return Base64.getEncoder().encodeToString(result);
    }

    private static byte[] fill(byte[] data) {
        if (data.length % 16 == 0) {
            return data;
        } else {
            byte[] result = new byte[(data.length / 16 + 1) * 16];
            System.arraycopy(data, 0, result, 0, data.length);
            return result;
        }
    }

    public static String decode(String cipher, String clientId, String fundAccount, String opOperatorNo) {
        if (isBlank(cipher)) {
            return null;
        } else {
            try {
                byte[] decode = Base64.getDecoder().decode(cipher);
                return decode(decode, clientId, fundAccount, opOperatorNo);
            } catch (Exception var5) {
                LOGGER.debug("Decode Fail. cipher: {}, client_id: {}, fund_account: {}, op_operator_no: {}.", new Object[]{cipher, clientId, fundAccount, opOperatorNo, var5});
                return null;
            }
        }
    }

    public static String decode(byte[] cipher, String clientId, String fundAccount, String opOperatorNo) {
        if (cipher == null) {
            return null;
        } else {
            int length = cipher.length;
            if (length <= 2) {
                return null;
            } else {
                char encodeType = String.valueOf(cipher[0]).charAt(0);
                byte[] data = new byte[length - 2];
                System.arraycopy(cipher, 1, data, 0, length - 2);
                char authType = String.valueOf(cipher[length - 1]).charAt(0);
                if (LOGGER.isDebugEnabled()) {
                    LOGGER.debug("cipher: {}, encode_type: {}, auth_type: {}, data: {}.", new Object[]{cipher, encodeType, authType, data});
                }

                String salt;
                if ('1' == authType) {
                    salt = clientId;
                } else if ('2' == authType) {
                    salt = fundAccount;
                } else {
                    if ('3' != authType) {
                        LOGGER.error("解密失败, 认证类别取值不合法, auth_type: {}. 预期的认证类别为: [{}-客户编号, {}-业务账号, {}-操作员号]", new Object[]{encodeType, '1', '2', '3'});
                        return null;
                    }

                    salt = opOperatorNo;
                }

                if (isBlank(salt)) {
                    LOGGER.error("解密失败, 认证类别为: {}, 但尝试使用空的盐值. client_id: {}, fund_account: {}, op_operator_no: {}.", new Object[]{authType, clientId, fundAccount, opOperatorNo});
                    return null;
                } else {
                    byte[] trueSecretKey = calcSecretKey(salt, "wexihuanjingjing");
                    String result = null;
                    if ('0' == encodeType) {
                        result = decrypt(data, trueSecretKey);
                    } else {
                        if ('1' != encodeType) {
                            LOGGER.error("解密失败, 加密类别取值不合法, 错误码: -2, encode_type: {}. 预期的加密类别为: [{}-AES, {}-国密]", new Object[]{encodeType, '0', '1'});
                            return null;
                        }

                        byte[] sm4Decrypt = GMCryptoUtil.SM4Decrypt(data, trueSecretKey);
                        result = new String(sm4Decrypt, DEFAULT_CHARSET);
                    }

                    if (isMessyCode(result)) {
                        if (LOGGER.isDebugEnabled()) {
                            LOGGER.debug("解密失败, 解密结果乱码. cipher: {}, encode_type: {}, decode data: {}.", new Object[]{Arrays.toString(cipher), encodeType, result});
                        }

                        return null;
                    } else {
                        return result;
                    }
                }
            }
        }
    }

    private static byte[] encrypt(byte[] data, byte[] key) {
        try {
            return doFinalWithNoPadding(data, key, 1);
        } catch (Exception var3) {
            LOGGER.error("Encrypt fail. data：{} key：{}", new Object[]{data, key, var3});
            return null;
        }
    }

    private static String decrypt(byte[] data, byte[] key) {
        try {
            byte[] result = doFinalWithNoPadding(data, key, 2);

            int i;
            for(i = result.length - 1; i >= 0 && result[i] == 0; --i) {
            }

            ++i;
            byte[] arr = new byte[i];
            System.arraycopy(result, 0, arr, 0, i);
            return new String(arr, DEFAULT_CHARSET);
        } catch (Exception var5) {
            LOGGER.error("Decrypt fail. data：{} key：{}", new Object[]{data, key, var5});
            return null;
        }
    }

    private static byte[] doFinalWithNoPadding(byte[] content, byte[] key, int mode) throws Exception {
        return doFinal(content, key, IV_FOR_NO_PADDING, mode, "AES/CBC/NoPadding");
    }

    private static byte[] doFinal(byte[] content, byte[] key, byte[] iv, int mode, String algorithm) throws Exception {
        SecretKeySpec keySpec = new SecretKeySpec(key, "AES");
        Cipher cipher = Cipher.getInstance(algorithm);
        cipher.init(mode, keySpec, new IvParameterSpec(iv));
        return cipher.doFinal(content);
    }

    private static byte[] calcSecretKey(String salt, String fakeKey) {
        byte[] resultArr = fakeKey.getBytes(DEFAULT_CHARSET);

        int saltLen;
        for(saltLen = 0; saltLen < 16; ++saltLen) {
            resultArr[saltLen] = (byte)(resultArr[saltLen] + 7);
        }

        saltLen = salt.length();

        for(int i = 0; i < 16; ++i) {
            char c;
            if (i >= saltLen) {
                c = 7;
            } else {
                c = salt.charAt(i);
            }

            resultArr[i] = (byte)(resultArr[i] + c);
        }

        return resultArr;
    }

    private static boolean isBlank(CharSequence cs) {
        int strLen;
        if (cs != null && (strLen = cs.length()) != 0) {
            for(int i = 0; i < strLen; ++i) {
                if (!Character.isWhitespace(cs.charAt(i))) {
                    return false;
                }
            }

            return true;
        } else {
            return true;
        }
    }

    private static boolean isMessyCode(String strName) {
        String patternStr = "\\s*|\t*|\r*|\n*";

        try {
            Pattern pattern = Pattern.compile(patternStr);
            Matcher m = pattern.matcher(strName);
            String after = m.replaceAll("");
            String temp = after.replaceAll("\\p{P}", "");
            char[] ch = temp.trim().toCharArray();
            int length = ch != null ? ch.length : 0;

            for(int i = 0; i < length; ++i) {
                char c = ch[i];
                if (!Character.isLetterOrDigit(c) && !UN_MESSY_CODE_LIST.contains(c) && !String.valueOf(ch[i]).matches("[一-龥]+")) {
                    return true;
                }
            }
        } catch (Exception var10) {
            LOGGER.error("Function: isMessyCode", var10);
        }

        return false;
    }


}
