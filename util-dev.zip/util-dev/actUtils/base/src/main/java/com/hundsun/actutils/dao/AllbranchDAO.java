package com.hundsun.actutils.dao;

import com.hundsun.actutils.entity.Allbranch;
import org.springframework.stereotype.Service;


import java.util.List;


public interface AllbranchDAO {
    List<Allbranch> getAllbranch();
}
