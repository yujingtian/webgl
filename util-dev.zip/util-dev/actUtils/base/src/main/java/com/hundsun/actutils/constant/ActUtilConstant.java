package com.hundsun.actutils.constant;

/**
 * 文件描述
 *
 * @ProductName Hundsun HEP
 * @ProjectName actUtils
 * @Package com.hundsun.actutils.constant
 * @Description note
 * @Author xuzd47380
 * @CreateDate 2023/11/15 9:38
 * @UpdateRemark The modified content
 * @Version 1.0
 * @Date 2023/11/15
 * <p>
 * Copyright  2023 Hundsun Technologies Inc. All Rights Reserved
 **/

public interface ActUtilConstant {
    String INTERFACE_MOD_STR = "接口重置";
    String DATEBASE_MOD_STR = "数据库重置";
    Character INTERFACE_MOD = '0';
    Character DATEBASE_MOD = '1';

    Character FUND_PASSWORD = '1';
    Character TRADE_PASSWORD = '2';
}
