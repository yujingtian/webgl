package com.hundsun.actutils.dao;

import com.hundsun.actutils.entity.Fundaccount;

import java.util.List;

/**
 * 文件描述
 *
 * @ProductName Hundsun HEP
 * @ProjectName actUtils
 * @Package com.hundsun.actutils.dao
 * @Description note
 * @Author xuzd47380
 * @CreateDate 2023/5/31 14:28
 * @UpdateRemark The modified content
 * @Version 1.0
 * @Date 2023/5/31
 * <p>
 * Copyright  2023 Hundsun Technologies Inc. All Rights Reserved
 **/

public interface FundAccountDAO {
    /**
     *
     * @param branchList
     * @return
     */
    public List<Fundaccount> getFundAccountByBranchNo(List<String> branchList);

    /**
     *
     * @param fundAccount
     * @param tradePassword
     * @param fundPassword
     * @return
     */
    public Integer updateFundaccountPassword(String fundAccount, String tradePassword, String fundPassword);
}
