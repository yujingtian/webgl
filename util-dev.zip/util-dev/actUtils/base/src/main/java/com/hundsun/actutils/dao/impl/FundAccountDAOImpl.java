package com.hundsun.actutils.dao.impl;

import com.hundsun.actutils.dao.FundAccountDAO;
import com.hundsun.actutils.entity.Fundaccount;
import org.apache.commons.lang3.StringUtils;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * 文件描述
 *
 * @ProductName Hundsun HEP
 * @ProjectName actUtils
 * @Package com.hundsun.actutils.dao.impl
 * @Description note
 * @Author xuzd47380
 * @CreateDate 2023/5/31 14:33
 * @UpdateRemark The modified content
 * @Version 1.0
 * @Date 2023/5/31
 * <p>
 * Copyright  2023 Hundsun Technologies Inc. All Rights Reserved
 **/
@Service
public class FundAccountDAOImpl implements FundAccountDAO {

    @Resource
    private JdbcTemplate jdbcTemplate;

    @Override
    public List<Fundaccount> getFundAccountByBranchNo(List<String> branchList) {
        String sql = "(" + StringUtils.join(branchList, ",") + ")";

        String querySQL = "select client_id, fund_account from act_fund_account where branch_no in" + sql;
        List<Fundaccount> fundaccountList = jdbcTemplate.query(querySQL, new BeanPropertyRowMapper<>(Fundaccount.class));
        return fundaccountList;
    }

    @Override
    public Integer updateFundaccountPassword(String fundAccount, String tradePassword, String fundPassword) {
        String sql = "update act_fund_account set fund_password=nvl(?,' '), trade_password=nvl(?,' ') where fund_account = ?";

        Object[] obj= new Object[] {
                //get获取测试类Test，set传过来的值
                fundPassword,
                tradePassword,
                fundAccount
        };

        return this.jdbcTemplate.update(sql,obj);
    }
}
