package com.hundsun.actutils.base;

import com.hundsun.actutils.component.T3SDKPwdPanel;
import com.hundsun.actutils.component.PwdResetByBranchPanel;
import com.hundsun.actutils.component.PwdResetPanel;
import org.springframework.stereotype.Component;

import javax.swing.*;

import java.awt.*;

import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

/**
 * @ClassName mainFrame
 * @Description 主窗口
 * @Author hengxx25187
 * @Date 2023/4/20 13:40
 */
@Component
public class mainFrame  {

    private JFrame window = new JFrame("资金账户批量密码重置工具");
    private JTabbedPane tabPanel = new JTabbedPane();

    public void createdUI() {
        // 设置关闭事件，关闭全部程序
        window.setDefaultCloseOperation(EXIT_ON_CLOSE);
        // 计算当前屏幕分辨率
        Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
        int screenDpi = Toolkit.getDefaultToolkit().getScreenResolution();
        int width = screenDpi*10 > (int)dimension.getWidth() ? (int)dimension.getWidth() : screenDpi*8;
        int height = width > (int)dimension.getHeight() ? (int)dimension.getHeight() : width;
        int x = (int)dimension.getWidth() /2 - width/2;
        int y = (int)dimension.getHeight() /2 - height/2;
        // 设置初始位置及大小
        window.setBounds(x, y, width, height);
        // 初始化其他组件
        // window.setLayout((LayoutManager)null);
        init();
        window.setResizable(Boolean.FALSE);
        // 设置页面为可见
        window.setVisible(Boolean.TRUE);

    }
    
    /**
     * Description: 初始化
     * @param
     * @return void
     * @author hengxx25187
     * @date 2023/4/20 15:56
     */
    private void init() {
        tabPanel.add("资产账户批量密码重置", new PwdResetPanel());
        tabPanel.add("营业部资产账户批量密码重置", new PwdResetByBranchPanel());
//        tabPanel.add("密码加解密", new T3SDKPwdPanel());

        window.add(tabPanel);
    }
}
