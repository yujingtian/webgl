package com.hundsun.actutils.component;





import com.hundsun.actutils.constant.ActUtilConstant;
import com.hundsun.actutils.entity.Allbranch;
import com.hundsun.actutils.entity.Fundaccount;
import com.hundsun.actutils.module.RwJComboBox;
import com.hundsun.actutils.controller.PwdResetController;
import com.hundsun.actutils.utils.T3Utils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.util.StopWatch;


import javax.swing.*;
import java.awt.*;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @ClassName T3SDKPwdPanel
 * @Description TODO
 * @Author hengxx25187
 * @Date 2023/4/20 16:32
 */
public class PwdResetByBranchPanel extends JPanel {

    private static final long serialVersionUID = 1L;
    // 调整页面内容整体向下偏移
    final int starty = 20;
    PwdResetController pwdResetController = new PwdResetController();
    JTextField title1_1 = new JTextField("请输入重置密码");
    JTextField f01_2 = new JTextField();
    JTextField title1_2 = new JTextField("选择营业部，支持手动输入");
    JComboBox initBranchSelectBox = new RwJComboBox(null);
    JTextField title1_3 = new JTextField("请选择密码重置方式");
    JComboBox modeSelectcomboBox = new JComboBox();
    final JButton serviceLinkBotton = new JButton("连接服务器");
    final JButton getFundAcctBotton = new JButton("获取资产账户");
    final JButton pwdResetBotton = new JButton("密码重置");
    final JButton clearBotton = new JButton("清空信息");
    final JButton successResultExportBotton = new JButton("成功结果导出");
    final JButton failResultExportBotton = new JButton("失败结果导出");
    JTextField title2 = new JTextField("执行日志");
    JTextField title3 = new JTextField("处理成功结果");
    JTextField title4 = new JTextField("处理失败结果");
    final JTextArea logTextArea = new JTextArea();
    final JScrollPane logScrollpane = new JScrollPane();
    final JTextArea successResultTextArea = new JTextArea();
    final JTextArea failResultTextArea = new JTextArea();
    final JScrollPane successResultScrollpane = new JScrollPane();
    final JScrollPane failResultScrollpane = new JScrollPane();
    final List<Allbranch> branchList = new ArrayList<>();
    final ArrayList<Fundaccount> fundacctList = new ArrayList<>();





    public PwdResetByBranchPanel() {
        // 初始化
        init();
        // 设置组件位置
        setArea();
        // 添加组件
        addPanel();
        // 设置监听事件
        setInteraction();
    }

    private void init() {
        this.setLayout((LayoutManager)null);
        title1_1.setEditable(false);
        title1_1.setBorder(null);
        f01_2.setEditable(true);
        title1_2.setEditable(false);
        title1_2.setBorder(null);
        initBranchSelectBox.setEditable(true);
        title1_3.setEditable(false);
        title1_3.setBorder(null);
        modeSelectcomboBox.setEditable(true);
        String[] strArray = {ActUtilConstant.INTERFACE_MOD_STR, ActUtilConstant.DATEBASE_MOD_STR };
        Arrays.stream(strArray).forEach(item -> modeSelectcomboBox.addItem(item));
        title2.setEditable(false);
        title2.setBorder(null);
        title3.setEditable(false);
        title3.setBorder(null);
        title4.setEditable(false);
        title4.setBorder(null);
        logTextArea.setEditable(false);
        logTextArea.setFont(new Font("黑体", 0, 14));
        logScrollpane.setViewportView(logTextArea);
        successResultTextArea.setEditable(false);
        successResultTextArea.setFont(new Font("黑体", 0, 14));
        successResultScrollpane.setViewportView(successResultTextArea);
        failResultTextArea.setEditable(false);
        failResultTextArea.setFont(new Font("黑体", 0, 14));
        failResultScrollpane.setViewportView(failResultTextArea);
    }

    private void setArea() {

        title1_1.setBounds(10, starty-15, 90, 20);
        f01_2.setBounds(10, starty+10, 90, 20);
        title1_2.setBounds(115, starty-15, 150, 20);
        initBranchSelectBox.setBounds(115, starty+10, 200, 20);
        title1_3.setBounds(330, starty-15, 110, 20);
        modeSelectcomboBox.setBounds(330, 10+starty, 110, 20);
        serviceLinkBotton.setBounds(10, starty+40, 150, 40);
        getFundAcctBotton.setBounds(170, starty+40, 150, 40);
        pwdResetBotton.setBounds(330, starty+40, 150, 40);
        clearBotton.setBounds(490, starty+40, 150, 40);
        title2.setBounds(10, starty+90, 150, 20);
        logScrollpane.setBounds(10, starty+120, 630, 100);
        title3.setBounds(10, starty+230, 150, 20);
        successResultScrollpane.setBounds(10, starty+260, 630, 150);
        title4.setBounds(10, starty+420, 150, 20);
        failResultScrollpane.setBounds(10, starty+450, 630, 150);
        successResultExportBotton.setBounds(10, starty+610, 310, 40);
        failResultExportBotton.setBounds(330, starty+610, 310, 40);
    }

    private void addPanel() {
        this.add(title1_1);
        this.add(f01_2);
        this.add(title1_2);
        this.add(initBranchSelectBox);
        this.add(title1_3);
        this.add(modeSelectcomboBox);
        this.add(serviceLinkBotton);
        this.add(getFundAcctBotton);
        this.add(pwdResetBotton);
        this.add(clearBotton);
        this.add(title2);
        this.add(logScrollpane);
        this.add(title3);
        this.add(successResultScrollpane);
        this.add(title4);
        this.add(failResultScrollpane);
        this.add(successResultExportBotton);
        this.add(failResultExportBotton);
    }

    private void  setInteraction() {

        serviceLinkBotton.addActionListener((o) -> {
            boolean initFlag = T3Utils.T3ServiceInit();
            if (initFlag) {
                logTextArea.append("T3sdk初始化连接成功\n");
            } else {
                logTextArea.append("T3sdk初始化连接失败，请检查配置文件\n");
                return;
            }

            try {
                List<Allbranch> branchListFromDB = pwdResetController.getAllBranch();
                branchList.addAll(branchListFromDB);
                logTextArea.append("读取数据库营业部数据成功\n");
            } catch (Exception e) {
                logTextArea.append("读取数据库营业部数据失败，请检查数据库连接配置\n");
            }

            remove(initBranchSelectBox);
            JComboBox newSelectBox = new RwJComboBox(branchList.toArray());
            newSelectBox.setEditable(true);
            newSelectBox.setBounds(115, starty+10, 200, 20);
            add(newSelectBox);
            initBranchSelectBox = newSelectBox;
            this.updateUI();
        });



        getFundAcctBotton.addActionListener((o) -> {
            fundacctList.clear();

            List<String> branchNoList = new ArrayList<>();
            int idx;
            JTextField jTextField = (JTextField) initBranchSelectBox.getEditor().getEditorComponent();
            String text = jTextField.getText();

            if (StringUtils.isBlank(text)) {
                logTextArea.append("未选择营业部，请选择或手动输入！\n");
                return;
            }

            for (String s : (text.split(","))) {
                idx = s.indexOf("-");
                if (idx == -1) {
                    branchNoList.add(s);
                } else {
                    branchNoList.add(s.substring(0, s.indexOf("-")));
                }
            }
            fundacctList.addAll(pwdResetController.getFundAccountByBranchNo(branchNoList));
            logTextArea.append("读取数据库资产账户数据成功，获取条数：" + fundacctList.size() + "\n");
        });



        pwdResetBotton.addActionListener((o) -> {
            successResultTextArea.setText("");
            failResultTextArea.setText("");
            if (StringUtils.isBlank(f01_2.getText())) {
                logTextArea.append("密码不能为空\n");
                return;
            }

            String modeStr = (String) modeSelectcomboBox.getSelectedItem();
            char resetMod = ActUtilConstant.INTERFACE_MOD_STR.equals(modeStr) ? ActUtilConstant.INTERFACE_MOD : ActUtilConstant.DATEBASE_MOD;

            StopWatch stopWatch = new StopWatch();
            stopWatch.start();
            PwdResetController.putPasswordResetOutput output =
                    pwdResetController.putPasswordReset(fundacctList, f01_2.getText(), resetMod);
            stopWatch.stop();


            output.getSuccessLogList().forEach(log -> successResultTextArea.append(log + "\n"));
            output.getErrorLogList().forEach(log -> failResultTextArea.append(log + "\n"));
            if (StringUtils.isNotBlank(output.getRemark())) {
                logTextArea.append(output.getRemark() + "，平均执行时长：" +
                        String.format("%.2f", stopWatch.getTotalTimeMillis()/(double)fundacctList.size()) + "毫秒\n");
            }
        });



        clearBotton.addActionListener((o) -> {
            successResultTextArea.setText("");
            failResultTextArea.setText("");
            logTextArea.setText("");

        });



        successResultExportBotton.addActionListener((o) -> {
            final JFileChooser SaveAs = new JFileChooser();
            SaveAs.setApproveButtonText("Save");
            int actionDialog = SaveAs.showOpenDialog(this);

            File fileName = new File(SaveAs.getSelectedFile() + ".txt");
            try {
                if (fileName == null) {
                    return;
                }
                BufferedWriter outFile = new BufferedWriter(new FileWriter(fileName));
                outFile.write(successResultTextArea.getText()); //put in textfile
                logTextArea.append("文件导出成功！\n");
                outFile.close();
            } catch (IOException ex) {
                logTextArea.append("文件导出失败，请重试\n");
            }


        });

        failResultExportBotton.addActionListener((o) -> {
            final JFileChooser SaveAs = new JFileChooser();
            SaveAs.setApproveButtonText("Save");
            int actionDialog = SaveAs.showOpenDialog(this);

            File fileName = new File(SaveAs.getSelectedFile() + ".txt");
            try {
                if (fileName == null) {
                    return;
                }
                BufferedWriter outFile = new BufferedWriter(new FileWriter(fileName));
                outFile.write(failResultTextArea.getText()); //put in textfile
                logTextArea.append("文件导出成功！\n");
                outFile.close();
            } catch (IOException ex) {
                logTextArea.append("文件导出失败，请重试\n");
            }


        });

    }

}
