package com.hundsun.actutils.base;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Service;

/**
 * @ClassName CreateApp
 * @Description TODO
 * @Author hengxx25187
 * @Date 2023/4/20 13:54
 */
@Service
public class CreateApp implements ApplicationListener<ContextRefreshedEvent> {

    @Autowired
    private mainFrame mainFrame;

    @Override
    public void onApplicationEvent(ContextRefreshedEvent event) {
        System.out.println("启动成功，开始创建页面");
        // 创建页面
        mainFrame.createdUI();
        System.out.println("创建页面结束");
    }
}
