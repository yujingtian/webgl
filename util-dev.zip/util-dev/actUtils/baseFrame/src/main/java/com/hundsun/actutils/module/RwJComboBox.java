package com.hundsun.actutils.module;

import java.util.Objects;

/**
 * 文件描述
 *
 * @ProductName Hundsun HEP
 * @ProjectName actUtils
 * @Package com.hundsun.actutils
 * @Description note
 * @Author xuzd47380
 * @CreateDate 2023/5/31 11:15
 * @UpdateRemark The modified content
 * @Version 1.0
 * @Date 2023/5/31
 * <p>
 * Copyright  2023 Hundsun Technologies Inc. All Rights Reserved
 **/

public class RwJComboBox extends javax.swing.JComboBox implements java.awt.event.FocusListener{

    protected java.util.Set set = new java.util.HashSet();

    public RwJComboBox(Object obj[]) {
        setModel(new RwDefaultComboBoxModel(obj));
        setUI(new RwMetalComboBoxUI(this));
        setRenderer(new RwJCheckBox());
        setSelectedIndex(-1);
    }

    public void focusGained(java.awt.event.FocusEvent e) {
    }

    public void focusLost(java.awt.event.FocusEvent e) {
    }

    public class RwMetalComboBoxUI extends javax.swing.plaf.metal.MetalComboBoxUI {
        private RwMetalComboBoxUI(RwJComboBox rwJComboBox) {
            this.comboBox = rwJComboBox;
        }

        protected javax.swing.plaf.basic.ComboPopup createPopup() {
            return new RwBasicComboPopup(comboBox);
        }
    }

    public class RwBasicComboPopup extends javax.swing.plaf.basic.BasicComboPopup {
        public RwBasicComboPopup(javax.swing.JComboBox combo) {
            super(combo);
        }

        protected void configureList() {
            super.configureList();
            list.setSelectionModel(new RwDefaultListSelectionModel(comboBox));
        }

        protected java.awt.event.MouseListener createListMouseListener() {
            return new RwMouseAdapter(list, comboBox);
        }
    }

    private class RwDefaultListSelectionModel extends javax.swing.DefaultListSelectionModel {
        protected RwJComboBox rwJComboBox;

        public RwDefaultListSelectionModel(javax.swing.JComboBox comboBox) {
            this.rwJComboBox = (RwJComboBox) comboBox;
        }

        public boolean isSelectedIndex(int index) {
            return rwJComboBox.set.contains(index);
        }
    }

    private class RwMouseAdapter extends java.awt.event.MouseAdapter {
        protected javax.swing.JList list;
        protected RwJComboBox rwJComboBox;

        private RwMouseAdapter(javax.swing.JList list, javax.swing.JComboBox comboBox) {
            this.list = list;
            this.rwJComboBox = (RwJComboBox) comboBox;
        }

        public void mousePressed(java.awt.event.MouseEvent anEvent) {
            StringBuilder sb, sb1, sb2, sb3;
            int k, index;
            javax.swing.JTextField jTextField = (javax.swing.JTextField) rwJComboBox.getEditor().getEditorComponent();


            index = list.getSelectedIndex();
            // 全选的情况
            if (index == 0) {
                if (rwJComboBox.set.contains(index)) {
                    // 包含取消
                    for (int i = 0; i < list.getModel().getSize(); i++) {
                        rwJComboBox.set.remove(i);
                    }
                    jTextField.setText("");
                } else {
                    // 不包含添加
                    for (int i = 0; i < list.getModel().getSize(); i++) {
                        rwJComboBox.set.add(i);
                    }
                    jTextField.setText("全选");
                }
            } else {
                sb = new StringBuilder(jTextField.getText());

                if (sb.length() > 0 && ',' != sb.charAt(0))
                    sb.insert(0, ",");
                if (sb.length() > 0 && ',' != sb.charAt(sb.length() - 1))
                    sb.append(",");
                if (sb.length() > 0 && ",".equals(sb.toString()))
                    sb = new StringBuilder();

                // 多选
                if (list.getSelectionMode() == javax.swing.ListSelectionModel.MULTIPLE_INTERVAL_SELECTION) {
                    if (rwJComboBox.set.contains(index)) {
                        // 包含取消
                        rwJComboBox.set.remove(index);
                        sb1 = new StringBuilder();
                        sb1.append(",").append(rwJComboBox.getModel().getElementAt(index)).append(",");
                        k = sb.indexOf(sb1.toString());
                        while (k != -1) {
                            sb.replace(k, k + sb1.length(), ",");
                            k = sb.indexOf(sb1.toString());
                        }
                    } else {
                        // 不包含添加
                        rwJComboBox.set.add(index);
                        if (sb.length() == 0)
                            sb.append(",").append(rwJComboBox.getModel().getElementAt(index)).append(",");
                        else
                            sb.append(rwJComboBox.getModel().getElementAt(index)).append(",");
                    }
                }
                Object obj;
                sb2 = new StringBuilder(sb);
                // 替换完正常的可选值，一般只剩一个逗号
                for (int i = 0; i < list.getModel().getSize(); i++) {
                    obj = list.getModel().getElementAt(i);
                    sb1 = new StringBuilder();
                    sb1.append(",").append(obj).append(",");
                    k = sb2.indexOf(sb1.toString());
                    while (k != -1) {
                        sb2.replace(k, k + sb1.length(), ",");
                        k = sb2.indexOf(sb1.toString());
                    }
                }
                java.util.List list1 = new java.util.ArrayList(rwJComboBox.set);
                java.util.Collections.sort(list1);
                for (int i = 0; i < list1.size(); i++) {
                    obj = rwJComboBox.getModel().getElementAt(Integer.parseInt(list1.get(i).toString()));
                    sb1 = new StringBuilder();
                    sb1.append(",").append(obj).append(",");
                    k = sb.indexOf(sb1.toString());
                    if (k != -1 && sb2.indexOf(sb1.toString()) == -1) {
                        sb2.append(obj).append(",");
                    }
                }

                // 删除首尾逗号
                sb = new StringBuilder(sb2);
                if (sb.length() > 0 && ',' == sb.charAt(0))
                    sb.deleteCharAt(0);
                if (sb.length() > 0 && ',' == sb.charAt(sb.length() - 1))
                    sb.deleteCharAt(sb.length() - 1);
                if (sb.length() > 0 && ",".equals(sb.toString()))
                    sb = new StringBuilder();
                jTextField.setText(sb.toString());
            }
            rwJComboBox.repaint();
            list.repaint();
        }
    }

    public class RwDefaultComboBoxModel extends javax.swing.DefaultComboBoxModel {
        private RwDefaultComboBoxModel(Object[] obj) {
            addElement("全选");
            if (!Objects.isNull(obj)) {
                for (int i = 0; i < obj.length; i++)
                    addElement(obj[i].toString());
            }
        }
    }

    public class RwJCheckBox extends javax.swing.JCheckBox implements javax.swing.ListCellRenderer {
        public java.awt.Component getListCellRendererComponent(javax.swing.JList list, Object value, int index,
                                                               boolean isSelected, boolean cellHasFocus) {
            setComponentOrientation(list.getComponentOrientation());
            if (isSelected) {
                setBackground(list.getSelectionBackground());
                setForeground(list.getSelectionForeground());
            } else {
                setBackground(list.getBackground());
                setForeground(list.getForeground());
            }
            setEnabled(list.isEnabled());
            setSelected(isSelected);
            setText(value == null ? "" : value.toString());
            setFont(list.getFont());
            return this;
        }
    }
}
