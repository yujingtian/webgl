package com.hundsun.actutils.utils;

import java.awt.*;

/**
 * @ClassName FrameUtils
 * @Description TODO
 * @Author hengxx25187
 * @Date 2023/4/20 16:50
 */
public class FrameUtils {
    public static void setBoundsBaseOnComp(Component componentLeft, Component component, int x, int y, int width, int height) {
        Rectangle bounds = componentLeft.getBounds();
        component.setBounds(x + bounds.x + bounds.width, bounds.y + y, width, height);
    }
}
