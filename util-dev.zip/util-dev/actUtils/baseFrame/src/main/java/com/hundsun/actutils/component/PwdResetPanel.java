package com.hundsun.actutils.component;


import com.hundsun.actutils.constant.ActUtilConstant;
import com.hundsun.actutils.entity.Fundaccount;
import com.hundsun.actutils.controller.PwdResetController;
import com.hundsun.actutils.utils.T3Utils;
import jxl.Cell;
import jxl.Sheet;

import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.util.*;

import jxl.Workbook;
import org.apache.commons.lang3.StringUtils;
import org.springframework.util.StopWatch;

/**
 * @ClassName T3SDKPwdPanel
 * @Description TODO
 * @Author hengxx25187
 * @Date 2023/4/20 16:32
 */
public class PwdResetPanel extends JPanel {

    private static final long serialVersionUID = 1L;

    PwdResetController pwdResetController = new PwdResetController();
    final JButton serviceLinkBotton = new JButton("连接服务器");
    final JButton dataImportBotton = new JButton("数据导入");
    final JButton pwdResetBotton = new JButton("密码重置");
    final JButton clearBotton = new JButton("清空信息");
    final JButton successResultExportBotton = new JButton("成功结果导出");
    final JButton failResultExportBotton = new JButton("失败结果导出");
    JTextField title1_1 = new JTextField("请输入重置密码");
    JTextField defaultPasswordTextField = new JTextField();
    JTextField title1_2 = new JTextField("请输入账号信息,文件导入时保持为空");
    JTextField acctTextField = new JTextField();
    JTextField title1_3 = new JTextField("请选择密码重置方式");
    JComboBox modeSelectcomboBox = new JComboBox();
    JTextField title2 = new JTextField("执行日志");
    JTextField title3 = new JTextField("处理成功结果");
    JTextField title4 = new JTextField("处理失败结果");
    final JTextArea logTextArea = new JTextArea();
    final JScrollPane logScrollpane = new JScrollPane();
    final JTextArea successResultTextArea = new JTextArea();
    final JTextArea failResultTextArea = new JTextArea();
    final JScrollPane successResultScrollpane = new JScrollPane();
    final JScrollPane failResultScrollpane = new JScrollPane();
    final ArrayList<Fundaccount> fundacctList = new ArrayList<>();





    public PwdResetPanel() {
        // 初始化
        init();
        // 设置组件位置
        setArea();
        // 添加组件
        addPanel();
        // 设置监听事件
        setInteraction();
    }

    private void init() {
        this.setLayout((LayoutManager)null);
        title1_1.setEditable(false);
        title1_1.setBorder(null);
        defaultPasswordTextField.setEditable(true);
        title1_2.setEditable(false);
        title1_2.setBorder(null);
        title1_3.setEditable(false);
        title1_3.setBorder(null);
        modeSelectcomboBox.setEditable(true);
        String[] strArray = {ActUtilConstant.INTERFACE_MOD_STR, ActUtilConstant.DATEBASE_MOD_STR };
        Arrays.stream(strArray).forEach(item -> modeSelectcomboBox.addItem(item));
        acctTextField.setEditable(true);
        title2.setEditable(false);
        title2.setBorder(null);
        title3.setEditable(false);
        title3.setBorder(null);
        title4.setEditable(false);
        title4.setBorder(null);
        logTextArea.setEditable(false);
        logTextArea.setFont(new Font("黑体", 0, 14));
        logScrollpane.setViewportView(logTextArea);
        successResultTextArea.setEditable(false);
        successResultTextArea.setFont(new Font("黑体", 0, 14));
        successResultScrollpane.setViewportView(successResultTextArea);
        failResultTextArea.setEditable(false);
        failResultTextArea.setFont(new Font("黑体", 0, 14));
        failResultScrollpane.setViewportView(failResultTextArea);
    }

    private void setArea() {
        // 调整页面内容整体向下偏移
        final int starty = 20;
        title1_1.setBounds(10, starty-15, 90, 20);
        defaultPasswordTextField.setBounds(10, 10+starty, 90, 20);
        title1_2.setBounds(115, starty-15, 200, 20);
        acctTextField.setBounds(115, 10+starty, 200, 20);
        title1_3.setBounds(330, starty-15, 110, 20);
        modeSelectcomboBox.setBounds(330, 10+starty, 110, 20);
        serviceLinkBotton.setBounds(10, 40+starty, 150, 40);
        dataImportBotton.setBounds(170, 40+starty, 150, 40);
        pwdResetBotton.setBounds(330, 40+starty, 150, 40);
        clearBotton.setBounds(490, 40+starty, 150, 40);
        title2.setBounds(10, 90+starty, 150, 20);
        logScrollpane.setBounds(10, 120+starty, 630, 100);
        title3.setBounds(10, 230+starty, 150, 20);
        successResultScrollpane.setBounds(10, 260+starty, 630, 150);
        title4.setBounds(10, 420+starty, 150, 20);
        failResultScrollpane.setBounds(10, 450+starty, 630, 150);
        successResultExportBotton.setBounds(10, 610+starty, 310, 40);
        failResultExportBotton.setBounds(330, 610+starty, 310, 40);
    }

    private void addPanel() {
        this.add(title1_1);
        this.add(defaultPasswordTextField);
        this.add(title1_2);
        this.add(acctTextField);
        this.add(title1_3);
        this.add(modeSelectcomboBox);
        this.add(title2);
        this.add(title3);
        this.add(title4);
        this.add(serviceLinkBotton);
        this.add(dataImportBotton);
        this.add(pwdResetBotton);
        this.add(clearBotton);
        this.add(successResultExportBotton);
        this.add(failResultExportBotton);
        this.add(logScrollpane);
        this.add(successResultScrollpane);
        this.add(failResultScrollpane);
    }

    private void  setInteraction() {
        //
        serviceLinkBotton.addActionListener((o) -> {
            boolean initFlag = T3Utils.T3ServiceInit();
            if (initFlag) {
                logTextArea.append("T3sdk初始化连接成功\n");
            } else {
                logTextArea.append("T3sdk初始化连接失败，请检查配置文件\n");
            }
        });

        dataImportBotton.addActionListener((o) -> {
            fundacctList.clear();

            String acctStr = acctTextField.getText();
            String defaultPassword = defaultPasswordTextField.getText();

            if (StringUtils.isNotBlank(acctStr)) {
                if (StringUtils.isBlank(defaultPassword)) {
                    logTextArea.append("文本数据导入，默认重置密码不能为空！\n");
                    fundacctList.clear();
                    return;
                }

                for (String acctInfo : acctStr.split(";")) {
                    String[] acct = acctInfo.split(",");
                    if (acct.length == 2) {
                        fundacctList.add(new Fundaccount(acct[0], acct[1], defaultPassword, defaultPassword));
                    }
                }
                logTextArea.append("文本数据导入成功，导入条数：" + fundacctList.size() + "\n");
                return;
            }

            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
            fileChooser.showOpenDialog(null);
            File file = fileChooser.getSelectedFile();
            Workbook workBook = null;

            // excel文件读取
            if (file != null) {
                try {
                    workBook = Workbook.getWorkbook(file);
                } catch (Exception e) {
                    logTextArea.append("仅支持导入.xls文件\n");
                    throw new RuntimeException(e);
                }

                // 得到工作簿所有的工作表对象,默认选择第一个表,可根据需求遍历所有表
                Sheet sheet = workBook.getSheet(0);
                // 得到所有列，在输出列中的内容
                int rows = sheet.getRows();
                for (int i = 0; i < rows; i++) {
                    Cell[] resetParam = sheet.getRow(i);
                    if (resetParam.length == 0 || resetParam[0].getContents().trim().isEmpty()) {
                        continue;
                    }
                    Fundaccount fundAccount = new Fundaccount();
                    fundAccount.setClientId(resetParam[0].getContents().trim());
                    fundAccount.setFundAccount(resetParam[1].getContents().trim());

                    if (StringUtils.isBlank(defaultPassword) && (resetParam.length < 4 || resetParam[2].getContents().trim().isEmpty())) {
                        logTextArea.append("文件内存在未指定密码数据，默认重置密码不能为空！\n");
                        fundacctList.clear();
                        return;
                    }

                    if (resetParam.length < 3 || resetParam[2].getContents().trim().isEmpty()) {
                        fundAccount.setTradePassword(defaultPassword);
                    } else {
                        fundAccount.setTradePassword(resetParam[2].getContents().trim());
                    }

                    if (resetParam.length < 4 || resetParam[3].getContents().trim().isEmpty()) {
                        fundAccount.setFundPassword(defaultPassword);
                    } else {
                        fundAccount.setFundPassword(resetParam[3].getContents().trim());
                    }

                    fundacctList.add(fundAccount);
                }
                workBook.close();
                logTextArea.append("Excel数据导入成功，导入条数：" + fundacctList.size() + "\n");

            }
        });



        pwdResetBotton.addActionListener((o) -> {
            successResultTextArea.setText("");
            failResultTextArea.setText("");
            String modeStr = (String) modeSelectcomboBox.getSelectedItem();
            char resetMod = ActUtilConstant.INTERFACE_MOD_STR.equals(modeStr) ? ActUtilConstant.INTERFACE_MOD : ActUtilConstant.DATEBASE_MOD;

            StopWatch stopWatch = new StopWatch();
            stopWatch.start();
            PwdResetController.putPasswordResetOutput output = pwdResetController.putPasswordReset(fundacctList, null, resetMod);
            stopWatch.stop();

            output.getSuccessLogList().forEach(log -> successResultTextArea.append(log + "\n"));
            output.getErrorLogList().forEach(log -> failResultTextArea.append(log + "\n"));
            if (StringUtils.isNotBlank(output.getRemark())) {
                logTextArea.append(output.getRemark() + "，平均执行时长：" +
                        String.format("%.2f", stopWatch.getTotalTimeMillis()/(double)fundacctList.size()) + "毫秒\n");
            }
        });



        clearBotton.addActionListener((o) -> {
            successResultTextArea.setText("");
            failResultTextArea.setText("");
            logTextArea.setText("");

        });



        successResultExportBotton.addActionListener((o) -> {
            final JFileChooser SaveAs = new JFileChooser();
            SaveAs.setApproveButtonText("Save");
            int actionDialog = SaveAs.showOpenDialog(this);

            File fileName = new File(SaveAs.getSelectedFile() + ".txt");
            try {
                if (fileName == null) {
                    return;
                }
                BufferedWriter outFile = new BufferedWriter(new FileWriter(fileName));
                outFile.write(successResultTextArea.getText()); //put in textfile
                logTextArea.append("文件导出成功！\n");
                outFile.close();
            } catch (IOException ex) {
                logTextArea.append("文件导出失败，请重试\n");
            }


        });

        failResultExportBotton.addActionListener((o) -> {
            final JFileChooser SaveAs = new JFileChooser();
            SaveAs.setApproveButtonText("Save");
            int actionDialog = SaveAs.showOpenDialog(this);

            File fileName = new File(SaveAs.getSelectedFile() + ".txt");
            try {
                if (fileName == null) {
                    return;
                }
                BufferedWriter outFile = new BufferedWriter(new FileWriter(fileName));
                outFile.write(failResultTextArea.getText()); //put in textfile
                logTextArea.append("文件导出成功！\n");
                outFile.close();
            } catch (IOException ex) {
                logTextArea.append("文件导出失败，请重试\n");
            }


        });

    }

}
