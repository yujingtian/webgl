package com.hundsun.actutils.component;

import com.hundsun.actutils.utils.FrameUtils;
import com.hundsun.actutils.utils.T3SDKUtils;
import org.apache.commons.lang3.StringUtils;

import javax.swing.*;
import java.awt.*;

/**
 * @ClassName T3SDKPwdPanel
 * @Description TODO
 * @Author hengxx25187
 * @Date 2023/4/20 16:32
 */
public class T3SDKPwdPanel extends JPanel {

    private static final long serialVersionUID = 1L;
    JLabel authTypeLabel = new JLabel("账户类别");
    ButtonGroup authTypeButtonGroup = new ButtonGroup();
    JRadioButton authTypeButtonClientId = new JRadioButton("一户通（1）", true);
    JRadioButton authTypeButtonFundaccount = new JRadioButton("资产账户（2）");
    JRadioButton authTypeButtonOperator = new JRadioButton("操作员（3）");
    JLabel encodeTypeLabel = new JLabel("加密算法");
    ButtonGroup encodeTypeButtonGroup = new ButtonGroup();
    JRadioButton randioButtonAes = new JRadioButton("AES（0）", true);
    JRadioButton randioButtonGm = new JRadioButton("国密（1）");
    JLabel authIdpeLabel = new JLabel("账户");
    JTextField authIdTextField = new JTextField();
    JLabel cleartextLabel = new JLabel("明文密码");
    JTextField cleartextTextField = new JTextField("1");
    JButton buttonGenPwd = new JButton("生成交易密码");
    JLabel pwdLabel = new JLabel("密文密码");
    JTextField pwdTextField = new JTextField();
    JLabel accountLabel = new JLabel("账户");
        JTextField accountTextField = new JTextField();
    JButton buttonGenDecode = new JButton("尝试解密密码");
    TextArea textArea = new TextArea("", 9, 35, 1);

    public T3SDKPwdPanel() {
        // 初始化
        init();
        // 设置组件位置
        setArea();
        // 添加组件
        addPanel();
        // 设置监听事件
        setInteraction();
    }

    private void init() {
        this.setLayout((LayoutManager)null);
        this.encodeTypeButtonGroup.add(this.randioButtonAes);
        this.encodeTypeButtonGroup.add(this.randioButtonGm);
        this.authTypeButtonGroup.add(this.authTypeButtonClientId);
        this.authTypeButtonGroup.add(this.authTypeButtonFundaccount);
        this.authTypeButtonGroup.add(this.authTypeButtonOperator);
        this.textArea.setEditable(false);
        this.textArea.setFont(new Font("黑体", 0, 14));
    }

    private void setArea() {
        this.authTypeLabel.setBounds(10, 30, 60, 25);
        FrameUtils.setBoundsBaseOnComp(this.authTypeLabel, this.authTypeButtonClientId, 10, 0, 90, 25);
        FrameUtils.setBoundsBaseOnComp(this.authTypeButtonClientId, this.authTypeButtonFundaccount, 10, 0, 90, 25);
        FrameUtils.setBoundsBaseOnComp(this.authTypeButtonFundaccount, this.authTypeButtonOperator, 10, 0, 90, 25);
        this.encodeTypeLabel.setBounds(10, 60, 60, 25);
        FrameUtils.setBoundsBaseOnComp(this.encodeTypeLabel, this.randioButtonAes, 10, 0, 90, 25);
        FrameUtils.setBoundsBaseOnComp(this.randioButtonAes, this.randioButtonGm, 10, 0, 90, 25);
        this.authIdpeLabel.setBounds(10, 100, 60, 25);
        FrameUtils.setBoundsBaseOnComp(this.authIdpeLabel, this.authIdTextField, 10, 0, 200, 25);
        this.cleartextLabel.setBounds(10, 125, 60, 25);
        FrameUtils.setBoundsBaseOnComp(this.cleartextLabel, this.cleartextTextField, 10, 0, 200, 25);
        this.buttonGenPwd.setBounds(300, 100, 140, 40);
        this.pwdLabel.setBounds(10, 175, 60, 25);
        FrameUtils.setBoundsBaseOnComp(this.pwdLabel, this.pwdTextField, 10, 0, 200, 25);
        this.accountLabel.setBounds(10, 200, 60, 25);
        FrameUtils.setBoundsBaseOnComp(this.accountLabel, this.accountTextField, 10, 0, 200, 25);
        this.buttonGenDecode.setBounds(300, 175, 140, 40);
        this.textArea.setBounds(10, 247, 495, 190);
    }

    private void addPanel() {
        this.add(this.authTypeLabel);
        this.add(this.authTypeButtonClientId);
        this.add(this.authTypeButtonFundaccount);
        this.add(this.authTypeButtonOperator);
        this.add(this.encodeTypeLabel);
        this.add(this.randioButtonAes);
        this.add(this.randioButtonGm);
        this.add(this.authIdpeLabel);
        this.add(this.authIdTextField);
        this.add(this.cleartextLabel);
        this.add(this.cleartextTextField);
        this.add(this.buttonGenPwd);
        this.add(this.pwdLabel);
        this.add(this.pwdTextField);
        this.add(this.accountLabel);
        this.add(this.accountTextField);
        this.add(this.buttonGenDecode);
        this.add(this.textArea);
    }

    private void  setInteraction() {
        this.buttonGenPwd.addActionListener((o) -> {
            String authId = this.authIdTextField.getText().trim();
            if (authId.isEmpty()) {
                JOptionPane.showMessageDialog((Component)null, "请输入认证账号", "消息提示！", 1);
            } else {
                String clearPwd = this.cleartextTextField.getText().trim();
                if (clearPwd.isEmpty()) {
                    JOptionPane.showMessageDialog((Component)null, "请输入密码", "消息提示！", 1);
                } else {
                    char authType = ' ';
                    if (this.authTypeButtonClientId.isSelected()) {
                        authType = '1';
                    } else if (this.authTypeButtonFundaccount.isSelected()) {
                        authType = '2';
                    } else if (this.authTypeButtonOperator.isSelected()) {
                        authType = '3';
                    }

                    char encodeType = this.randioButtonGm.isSelected() ? '1' : '0';
                    String encodePwd = T3SDKUtils.t3SdkEncode(authId, authType, (char)encodeType, clearPwd);
                    this.textArea.setText(StringUtils.isBlank(encodePwd) ? "加密结果为空" : encodePwd);
                }
            }
        });
        this.buttonGenDecode.addActionListener((e) -> {
            String pwd = this.pwdTextField.getText().trim();
            String authId = this.accountTextField.getText().trim();
            if (!StringUtils.isBlank(pwd) && !StringUtils.isBlank(authId)) {
                String clearPwd = T3SDKUtils.t3SdkDecode(authId, pwd);
                if (clearPwd == null) {
                    JOptionPane.showMessageDialog((Component)null, "尝试解密失败", "消息提示！", 1);
                } else {
                    this.textArea.setText(clearPwd);
                }
            } else {
                JOptionPane.showMessageDialog((Component)null, "输入账户和密码", "消息提示！", 1);
            }
        });
    }
}
