package com.hundsun.actutils;

import com.hundsun.t2sdk.interfaces.T2SDKException;
import com.hundsun.t3sdk.impl.client.T3Services;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;

@SpringBootApplication
public class ActUtilsApplication {

    public static void main(String[] args) {
        System.out.println("启动开始");
        SpringApplicationBuilder builder = new SpringApplicationBuilder(ActUtilsApplication.class);
        builder.headless(false).run(args);
    }

}
