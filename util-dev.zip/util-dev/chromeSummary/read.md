谷歌各个版本的特性汇总
chrome 1 
1. 支持canvas 绘制2d图形
2. css 'text'属性
3. 允许隐藏部分可见元素
4. postMessage()方法
5. xslt 一种用于转换XML的声明性语言

chrome 2
1. MessageChannel()

chrome 4
1. -webkit-box-reflect
2. -webkit-mask-* (-webkit-mask-clip)
3. websocket
4. X-Frame-Options

chrome 5
1. Web Storage  localStorage and sessionStorage
2. Geolocation 获取设备地理位置信息  得要翻墙
3. Notifications API

chrome 6
1.EventSource 是服务器推送的一个网络事件接口

chrome 7
1. 提供对设备物理方向的访问
2. FileReader
3. HTTP/2 (SPDY)  用于传输web内容的快速、开放的协议

chrome 9
1. WebGL canvas3d 绘制3D图形
2. WebP图像格式支持
3. matchMedia 
4. 可编辑的dom支持spellcheck属性

chrome 10
1. 表单校验 （pattern required）
2. window.onerror  未处理的异常会触发window.onerror回调

chrome 11
1. IndexedDB 一种异步客户端存储API，提供对大量结构化数据的快速访问

chrome 12
1. detail/summay 标签 显示隐藏的小组件
2. 不支持 -webkit-line-box-contain 属性

chrome 13
1. Timing  允许web应用程序访问与导航和元素相关的计时信息。
2. 支持ArrayBuffer, Float32Array , Int16Array, Uint8Array

chrome 14
1. 允许创建受信任内容源的白名单，并指示浏览器仅执行或呈现来自这些源的资源。
2. a标签支持下载

chrome 15
1. fullscreen 以编程方式指示页面上的内容以浏览器的全屏模式显示

chrome 18
1. 允许JS通过USB访问游戏控制器。
2. touch事件的支持
3. 在重新排列或修改DOM节点时提供通知  Observers

chrome 19
1. css filter 滤镜属性
2. css calc 计算属性
3. iframe sandbox 对iframe内容的额外限制

chrome 20
1. dataList标签
2. blob
3. input支持的事件类型 <input type=date>, <input type=datetime>, <input type=datetime-local>, <input type=month>, <input type=time>, and <input type=week>
4. iframe[seamless] 属性
5. iframe[srcdoc] 属性

chrome 21
1. flex布局
2. 允许使用HTML5拖放功能拖放整个文件夹 
3. getUserMedia

chrome 23
1. MediaSource对象，可以附加到video audio播放
2. mouse Lock 鼠标锁定 
3. track标签  在视频和音频中添加字幕，描述。。   WebVTT格式
4. 支持WebRTC

chrome 24
1. performance.now() 性能计时器 更精准
2. requestAnimationFrame() 根据浏览器性能的循环函数

chrome 25
1. css Gradients 渐变
2. Resource Timing 获取和分析应用程序资源加载的详细网络计时数据
3. use Timing 自定义时间测量
4. web speech 语音识别要挂vpn

chrome 26
1. 添加了template标签

chrome 28
1. css 条件规则 @supports

chrome 29
1. @viewport 这个特性主要被用于移动设备
2. @media 媒体查询
3. overflow: -webkit-marquee 
4. QUIC（Quick UDP Internet Connection）是谷歌制定的一种基于UDP的低时延的互联网传输层协议
5. 公开特定于Chrome的API，允许网站向扩展发送消息。仅对已安装的扩展插件列出的网站公开。
6. TLS 1.2 传输层安全（TLS）协议  使用非对称加密来确保谁在通信，并交换对称密钥
7. vp9 由Google开发的开放格式、无使用授权费的视频压缩标准
8. XMLHttpRequest 支持timeout  以及退出一些相应的事件  ontimeout

chrome30
1.  mouseenter  mouseleave 
2. CanvasRenderingContext2D.imageSmoothingEnabled  设置为true对图片进行平滑处理

chrome31
1. object-fit 和 object-position  (CSS)
2. wheel事件
3. deviceorientation  设备物理运动方向的访问
4. window.devicePixelRatio 准确地描绘css和设备像素之间的比率

chrome32
1. 支持动画WebP图像
2. canvas context  alpha改变透明度
3. Promises
4. URL构造函数 返回一个由一组参数定义的 URL

chrome33
1. font-kerning 字体字距  (CSS)
2. visibilitychange事件
3. 使用VTTCue构造函数 设置媒体文本跟踪
4. Web语音API（合成） 新增api和事件

chrome34
1. img srcset属性  根据不同屏幕加载不同的图片
2. CSS font-variant-ligatures 控制文本中连字的CSS属性

chrome35
1. css mix-blend-mode 背景混合
2. CSS Font Loading 应用程序能够知道是否确实加载了web字体  Document.fonts返回一个FontFaceSet对象，有一个status属性（'loading' or 'loaded'）
3. AudioContext构造函数 web应用程序中处理和合成音频的JavaScript API

chrome36 
1. css touch-action 用于设置触摸屏用户如何操纵元素的区域
2. css will-change 告知浏览器该元素会有哪些变化的方法,将一部分复杂的计算工作提前准备好，使页面的反应更为快速灵敏
3. css transforms
4. 支持WOFF 2.0 改进的字体压缩
5. WeakMap (ES6)
  1、WeakMap只接受对象作为key，如果设置其他类型的数据作为key，会报错。
  2、WeakMap的key所引用的对象都是弱引用，只要对象的其他引用被删除，垃圾回收机制就会释放该对象占用的内存，从而避免内存泄漏。
  3、由于WeakMap的成员随时可能被垃圾回收机制回收，成员的数量不稳定，所以没有size属性。
  4、没有clear()方法
  5、不能遍历
6. WeakSet (ES6)
  1.与Set相比，WeakSet 只能是对象的集合，而不能是任何类型的任意值。
  2.WeakSet持弱引用：集合中对象的引用为弱引用。 如果没有其他的对WeakSet中对象的引用，那么这些对象会被当成垃圾回收掉。 这也意味着WeakSet中没有存储当前对象的列表。 正因为这样，WeakSet 是不可枚举的。
7. element.animate() 通过js写动画的api

chrome37
1. 支持dialog标签
2. CSS all 简写属性 将除却 unicode-bidi 与 direction 之外的所有属性重设至其初始值，或继承值
3. CSS shapes属性 （shape-outside）
4. 阻止跨源字体加载，除非响应包含适当的CORS标题
5. 在Windows上使用DirectWrite而不是GDI来处理文本
6. 更新TouchEvent对象返回的坐标，包含底层平台提供的完整精度
7. 新增Navigator.hardwareConcurrency（window.navigator.hardwareConcurrency）返回理想情况下当前系统上可以并行有效运行的任务数量
8. 支持Navigator.languages和Navigator.language
9. 支持Web Crypto API



