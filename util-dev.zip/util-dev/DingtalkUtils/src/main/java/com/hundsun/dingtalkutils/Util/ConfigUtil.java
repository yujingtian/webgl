package com.hundsun.dingtalkutils.Util;


import org.springframework.context.EnvironmentAware;

import org.springframework.core.env.*;
import org.springframework.stereotype.Service;


/**
 * @ClassName ConfigUtil
 * @Description TODO
 * @Author hengxx25187
 * @Date 2023/6/25 18:16
 */
@Service
public class ConfigUtil implements EnvironmentAware {

    private static Environment environment;

    private static String getProperty(String property) {
        return environment.getProperty(property);
    }

    @Override
    public void setEnvironment(Environment environment) {
        this.environment = environment;
    }
    
    /**
     * Description: TODO
     * 获取gitLab私钥
     * @return java.lang.String
     * @author hengxx25187
     * @date 2023/6/26 10:01
     */
    public static String getHttpPrivateToken() {
        return getProperty("gitLab.http.private.token");
    }
    
    /**
     * Description: 获取gitLab地址
     * @param 
     * @return java.lang.String
     * @author hengxx25187
     * @date 2023/6/26 10:00
     */
    public static String getGitLabUrl() {
        return getProperty("gitLab.url");
    }
    
    /**
     * Description: 获取配置项目的文件名称
     * @param 
     * @return java.lang.String
     * @author hengxx25187
     * @date 2023/6/26 10:10
     */
    public static String getGitLabProjectsConfig () {
        return getProperty("gitLab.projects.config");
    }

    /**
     * Description: 获取钉钉机器人关键字
     * @param
     * @return java.lang.String
     * @author hengxx25187
     * @date 2023/6/26 10:12
     */
    public static String getDingTalkInfo() {
        return getProperty("dingtalk.rabot.key.msg");
    }

    /**
     * Description: 获取钉钉机器人聊天地址
     * @param
     * @return java.lang.String
     * @author hengxx25187
     * @date 2023/6/26 10:24
     */
    public static String getDingtalkUrl() {
        return getProperty("dingtalk.service.url");
    }

    /**
     * Description: 获取钉钉机器人token
     * @param
     * @return java.lang.String
     * @author hengxx25187
     * @date 2023/6/26 10:24
     */
    public static String getDingtalkToken() {
        return getProperty("dingtalk.access.token");
    }
}
