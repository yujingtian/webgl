package com.hundsun.dingtalkutils.gitLab.entity;

import lombok.Data;

/**
 * @ClassName Author
 * @Description TODO
 * @Author hengxx25187
 * @Date 2023/6/16 10:34
 */
@Data
public class Author {
    // 编号
    private Integer id;
    // 姓名
    private String name;
    // 状态
    private String state;

    private String avatar_url;
    // 账户
    private String web_url;

    public String getUserId() {
        return web_url.replace("https://gitlab.hundsun.com/","").replaceAll("[a-zA-Z]", "");
    }

    public String getUserIId() {
        return web_url.replace("https://gitlab.hundsun.com/","");
    }

}
