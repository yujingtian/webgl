package com.hundsun.dingtalkutils.gitLab.entity;

import lombok.Data;

import java.util.Date;

/**
 * @ClassName MergeInfo
 * @Description 合并信息实体类
 * @Author hengxx25187
 * @Date 2023/6/15 20:43
 */
@Data
public class MergeInfo {

    // 发起人编号
    private Integer id;
    // 发起的流程编号
    private Integer iid;
    // 所属项目编号
    private Integer project_id;
    // 发起请求的标题
    private String title;
    // 发起流程的描述
    private String description;
    // 发起流程的状态
    private String state;
    // 发起流程时间
    private Date created_at;
    // 更新流程时间
    private Date updated_at;
    // 合并请求所在分支
    private String target_branch;
    // 合并请求目标分支
    private String source_branch;
    private Integer upvotes;
    private Integer downvotes;
    // 发起人信息
    private Author author;
    // 接收处理人信息
    private Author assignee;
    private String source_project_id;
    private String target_project_id;
    private Boolean work_in_progress;
    private String milestone;
    private Boolean merge_when_pipeline_succeeds;
    private String merge_status;
    private String sha;
    private String merge_commit_sha;
    private Integer user_notes_count;
    private String discussion_locked;
    private String should_remove_source_branch;
    private Boolean force_remove_source_branch;
    // 合并请求的url
    private String web_url;
    private Boolean squash;

    @Override
    public String toString() {
      return this.title + " 待处理人：" + "@"+this.assignee.getName();
    }
}
