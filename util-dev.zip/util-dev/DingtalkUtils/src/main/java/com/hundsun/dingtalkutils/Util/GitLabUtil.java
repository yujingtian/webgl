package com.hundsun.dingtalkutils.Util;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.springframework.context.annotation.DependsOn;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.hundsun.dingtalkutils.Util.ConfigUtil.getGitLabProjectsConfig;
import static com.hundsun.dingtalkutils.Util.ConfigUtil.getGitLabUrl;

/**
 * @ClassName GitLabProject
 * @Description TODO
 * @Author hengxx25187
 * @Date 2023/6/25 10:47
 */
@Service
@DependsOn("configUtil")
public class GitLabUtil {

    private static String API = "/api/v4/projects/";
    public static Map<String, String> PROJECT = new HashMap<>();

    public static String GITLAB_URL = "";

    /**
     * Description: 启动时初始化加载xml文件
     * @param
     * @return void
     * @author hengxx25187
     * @date 2023/6/26 10:04
     */
    @PostConstruct
    public void init() {

        String fieldName = getGitLabProjectsConfig();
        System.out.println(fieldName);
        if (StringUtils.isEmpty(fieldName)) {
           return;
        }
        SAXReader reader = new SAXReader();
        Document document;
        String url = this.getClass().getResource("/").toString() + fieldName;
        try {
            document = reader.read(url);
        } catch (DocumentException e) {
            e.printStackTrace();
            return;
        }
        Element transRoot = document.getRootElement();
        // 获取根节点下级的所有信息
        List<Element> transFieldList = transRoot.elements();
        transFieldList.stream().map(e -> {
            String id = e.attributes().stream().filter(attr -> attr.getName().equals("id")).findFirst().get().getValue();
            String note = e.attributes().stream().filter(attr -> attr.getName().equals("note")).findFirst().get().getValue();
            PROJECT.put(id, note);
            return e;
        }).collect(Collectors.toList());

        GITLAB_URL = getGitLabUrl();
    }

    /**
     * Description: 获取单个项目合并请求的url
     * @param projectId 项目ID
     * @return java.lang.String
     * @author hengxx25187
     * @date 2023/6/26 10:04
     */
    public static String getMergeUrl(String projectId) {
        String url = null;
        url = GITLAB_URL + API + projectId + "/merge_requests";
        return url;
    }

    /**
     * Description: 获取配置文件中所有的项目合并请求地址
     * @param
     * @return java.util.Map<java.lang.String,java.lang.String>
     * @author hengxx25187
     * @date 2023/6/26 10:05
     */
    public static Map<String, String> getMergePrtojectUrl() {
        Map<String, String> result = new HashMap<>();
        PROJECT.forEach((k, v) -> {
            result.put(v, getMergeUrl(k));
        });
        return result;
    }
}
