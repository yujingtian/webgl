package com.hundsun.dingtalkutils.gitLab;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.dingtalk.api.request.OapiRobotSendRequest;
import com.hundsun.dingtalkutils.Util.DingTalkUtil;
import com.hundsun.dingtalkutils.Util.HttpClientUtils;
import com.hundsun.dingtalkutils.gitLab.entity.MergeInfo;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.hundsun.dingtalkutils.Util.GitLabUtil.getMergePrtojectUrl;

/**
 * @ClassName MergeInfoCtrl
 * @Description TODO
 * @Author hengxx25187
 * @Date 2023/6/16 10:54
 */
@Service
public class MergeInfoCtrl {

    
    /**
     * Description: 合并信息格式化
     * @param mergeInfo
     * @return java.util.List<com.hundsun.dingtalkutils.gitLab.MergeInfo>
     * @author hengxx25187
     * @date 2023/6/20 19:26
     */
    public static List<MergeInfo> mergeInfoFormat(String mergeInfo) {
        List<MergeInfo> mergeInfos = new ArrayList<>();
        if (StringUtils.isBlank(mergeInfo)) {
            return mergeInfos;
        }
        JSONArray jsonArray = JSONArray.parseArray(mergeInfo);
        for (Object jsonObject: jsonArray) {
            MergeInfo info = JSONObject.parseObject(jsonObject.toString(), MergeInfo.class);
            mergeInfos.add(info);
        }
        return mergeInfos;
    }

    /**
     * Description: 获取合并请求
     * @param url 请求地址
     * @return java.util.List<com.hundsun.dingtalkutils.gitLab.MergeInfo>
     * @author hengxx25187
     * @date 2023/6/26 10:07
     */
    public List<MergeInfo> getMergeInfo(String url) {
        Map<String , String> param = new HashMap<>();
        param.put("scope", "all");
        // 只查询打开状态的请求
        param.put("state", "opened");
        param.put("page", "1");
        param.put("per_page", "1000");
        String json = JSON.toJSONString(param);
        JSONObject object = JSONObject.parseObject(json);
        List<MergeInfo> result = mergeInfoFormat(HttpClientUtils.get(url, object));
        // 首先过滤掉没有发起合并人的请求
        result = result.stream().filter(o -> o.getAssignee() != null).collect(Collectors.toList());
        return result;
    }



    /**
     * Description: 获取配置文件项目中所有的合并请求
     * @param
     * @return void
     * @author hengxx25187
     * @date 2023/6/26 10:07
     */
    public void pullMergeInfo() {
        Map<String, String> projects = getMergePrtojectUrl();
        projects.forEach((k, v) -> {
            putMergeInfo(k, v);
        });
    }

    /**
     * Description: 获取单个项目的合并请求
     * @param projectName
     * @param url
     * @return void
     * @author hengxx25187
     * @date 2023/6/26 10:09
     */
    private void putMergeInfo(String projectName, String url) {
        List<MergeInfo> mergeInfos = getMergeInfo(url);

        DingTalkUtil dingTalkUser = new DingTalkUtil();
        dingTalkUser.instance();

        OapiRobotSendRequest req = new OapiRobotSendRequest();
        req.setMsgtype("text");
        OapiRobotSendRequest.Text obj1 = new OapiRobotSendRequest.Text();
        obj1.setContent("【" + projectName + "】"+ "合并信息： " + "代码待合并"  + "\n" + mergeInfos.get(0).toString());
        req.setText(obj1);

        List<String> atUserIds = new ArrayList<>();
        mergeInfos.stream().filter(o -> o.getAssignee() != null).map(e -> {
            if (!atUserIds.contains(e.getAssignee().getUserId())) {
                atUserIds.add(e.getAssignee().getUserId());
            }
            return e;
        }).collect(Collectors.toList());

        OapiRobotSendRequest.At at = new OapiRobotSendRequest.At();
        at.setAtUserIds(atUserIds);
        req.setAt(at);

        dingTalkUser.setRequest(req);
        dingTalkUser.excute();

    }

}
