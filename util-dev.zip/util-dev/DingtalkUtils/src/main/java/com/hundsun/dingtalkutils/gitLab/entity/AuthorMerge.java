package com.hundsun.dingtalkutils.gitLab.entity;

import lombok.Data;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;

/**
 * @ClassName AuthorMerge
 * @Description TODO
 * @Author hengxx25187
 * @Date 2023/6/26 11:12
 */
@Data
public class AuthorMerge {
    @Data
    public static class CanMerge{
        Map<Author, List<MergeInfo>> canMerge = new HashMap<>();

        public boolean containsKey(String authId) {
            AtomicReference<Boolean> match = new AtomicReference<>(Boolean.FALSE);
            this.canMerge.forEach((k, v) -> {
                if (k.getUserId().equals(authId)) {
                    match.set(Boolean.TRUE);
                }
            });
            return match.get();
        }

        public String getMergeInfo() {
            StringBuffer stringBuffer = new StringBuffer();

            List<MergeInfo> list = new ArrayList<>();
            this.canMerge.forEach((k, v) -> {
                list.addAll(v);
            });

            Map<String, Map<String, List<MergeInfo>>> merge = new HashMap<>();
            list.stream().map(o -> {
                if(!merge.containsKey(o.getTarget_branch())) {
                    merge.put(o.getTarget_branch(), new HashMap<>());
                }
                return o;
            }).collect(Collectors.toList());

            merge.forEach((a, b) -> {
                List<MergeInfo> targetMergeList = list.stream().filter(e -> e.getTarget_branch().equals(a)).collect(Collectors.toList());
                List<Author> author = targetMergeList.stream().map(e ->  e.getAssignee()).distinct().collect(Collectors.toList());
                author.stream().map(e -> {
                    b.put(e.getName(), targetMergeList.stream().filter(o -> o.getAssignee().getId().equals(e.getId())).collect(Collectors.toList()));
                    return e;
                }).collect(Collectors.toList());
            });
            merge.forEach((k, v) -> {
                stringBuffer.append("\n分支 ").append(k).append(":\n");
                v.forEach((a, b) -> {
                    stringBuffer.append(a).append("    待处理：").append(b.size()).append("\n");
                });
            });
            return stringBuffer.toString();
        }
    }

    @Data
    public static class NonMerge{
        Map<Author, List<MergeInfo>> NonMerge = new HashMap<>();
        public boolean containsKey(String authId) {
            AtomicReference<Boolean> match = new AtomicReference<>(Boolean.FALSE);
            this.NonMerge.forEach((k, v) -> {
                if (k.getUserId().equals(authId)) {
                    match.set(Boolean.TRUE);
                }
            });
            return match.get();
        }
        public String getMergeInfo() {
            StringBuffer stringBuffer = new StringBuffer();
            this.NonMerge.forEach((k, v) -> {
                stringBuffer.append(k.getName()).append("    待处理：").append(v.size()).append("\n");
            });
            return stringBuffer.toString();
        }
    }

    private CanMerge canMergeList = new CanMerge();

    private NonMerge NonMergeList = new NonMerge();


}
