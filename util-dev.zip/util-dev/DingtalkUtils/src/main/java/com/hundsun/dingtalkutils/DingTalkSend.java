package com.hundsun.dingtalkutils;

import com.dingtalk.api.request.OapiRobotSendRequest;
import com.hundsun.dingtalkutils.Util.ConfigUtil;
import com.hundsun.dingtalkutils.Util.DingTalkUtil;
import com.hundsun.dingtalkutils.Util.GitLabUtil;
import com.hundsun.dingtalkutils.gitLab.MergeInfoCtrl;
import com.hundsun.dingtalkutils.gitLab.entity.Author;
import com.hundsun.dingtalkutils.gitLab.entity.AuthorMerge;
import com.hundsun.dingtalkutils.gitLab.entity.MergeInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import sun.util.cldr.CLDRLocaleDataMetaInfo;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.hundsun.dingtalkutils.Util.GitLabUtil.getMergePrtojectUrl;

/**
 * @ClassName DingTalkSend
 * @Description TODO
 * @Author hengxx25187
 * @Date 2023/6/26 11:03
 */
@Service
public class DingTalkSend {

    private String CAN_BE_MERGED = "can_be_merged";

    @Autowired
    private MergeInfoCtrl mergeInfoCtrl;

    @Autowired
    private GitLabUtil gitLabUtil;
    // @PostConstruct
    @Scheduled(cron = "0 00 14 ? * MON-FRI")
    @Scheduled(cron = "0 30 16 ? * MON-FRI")
    public void pull() {
        Map<String, String> projects = getMergePrtojectUrl();
        projects.forEach((k, v) -> {
            AuthorMerge authorMerge = getAuthorMerge(mergeInfoCtrl.getMergeInfo(v));
            putMergeMsgSend(authorMerge, k);
        });
    }

    /**
     * Description: 获取合并请求
     * @param mergeInfos
     * @return com.hundsun.dingtalkutils.gitLab.entity.AuthorMerge
     * @author hengxx25187
     * @date 2023/6/26 11:41
     */
    public AuthorMerge getAuthorMerge(List<MergeInfo> mergeInfos) {
        AuthorMerge result = new AuthorMerge();
        mergeInfos.stream().map(e -> {
            // 可被合并
            if (e.getMerge_status().equals(CAN_BE_MERGED)) {
                String authId = e.getAssignee().getUserId();
                List<MergeInfo> mergeList = new ArrayList<>();
                if (result.getCanMergeList().containsKey(authId)) {
                    mergeList = result.getCanMergeList().getCanMerge().get(e.getAssignee());
                }
                mergeList.add(e);
                result.getCanMergeList().getCanMerge().put(e.getAssignee(), mergeList);
            }else {
                String authId = e.getAuthor().getUserId();
                List<MergeInfo> mergeList = new ArrayList<>();
                if (result.getNonMergeList().containsKey(authId)) {
                    mergeList = result.getNonMergeList().getNonMerge().get(e.getAuthor());
                }
                mergeList.add(e);
                result.getNonMergeList().getNonMerge().put(e.getAuthor(), mergeList);
            }
            return e;
        }).collect(Collectors.toList());

        return result;
    }

    /**
     * Description: 发送钉钉机器人消息
     * @param authorMerge
     * @param projectName
     * @return void
     * @author hengxx25187
     * @date 2023/6/26 16:26
     */

    public void putMergeMsgSend(AuthorMerge authorMerge, String projectName) {
        // 获取可合并请求列表
        Map<Author, List<MergeInfo>> canMerge = authorMerge.getCanMergeList().getCanMerge();
        List<String> authors = new ArrayList<>();
        canMerge.forEach((k, v) -> {
            if (!authors.contains(k.getUserId())) {
                authors.add(k.getUserId());
            }
            if (!authors.contains(k.getUserIId())) {
                authors.add(k.getUserIId());
            }
        });
        // 获取不可合并请求列表
        Map<Author, List<MergeInfo>> NonMerge = authorMerge.getNonMergeList().getNonMerge();
        NonMerge.forEach((k, v) -> {
            if (!authors.contains(k.getUserId())) {
                authors.add(k.getUserId());
            }
            if (!authors.contains(k.getUserIId())) {
                authors.add(k.getUserIId());
            }
        });
        if (authors.isEmpty()) {
            return;
        }
        DingTalkUtil dingTalkUser = new DingTalkUtil();
        dingTalkUser.instance();

        OapiRobotSendRequest req = new OapiRobotSendRequest();

        req.setMsgtype("text");
        OapiRobotSendRequest.Text text = new OapiRobotSendRequest.Text();
        StringBuffer content = new StringBuffer();
        content.append("【").append(projectName).append("】").append(ConfigUtil.getDingTalkInfo()).append("：\n")
                .append("当前待审核汇总信息：\n")
                .append(authorMerge.getCanMergeList().getMergeInfo())
                .append("\n")
                .append("当前冲突无法合并信息，待处理冲突：\n")
                .append(authorMerge.getNonMergeList().getMergeInfo());
        text.setContent(content.toString());
                req.setText(text);

        /*
        req.setMsgtype("markdown");
        OapiRobotSendRequest.Markdown markdown = new OapiRobotSendRequest.Markdown();
        markdown.setText(getMarkdownTest(projectName, authorMerge));
        markdown.setTitle("GitLab合并情况");
        req.setMarkdown(markdown);
        */
        Arrays.asList(authors);
        OapiRobotSendRequest.At at = new OapiRobotSendRequest.At();

        at.setAtUserIds(authors);
        req.setAt(at);

        dingTalkUser.setRequest(req);
        dingTalkUser.excute();
    }

    private String getMarkdownTest(String projectName,AuthorMerge authorMerge) {
        StringBuffer content = new StringBuffer();

        content.append("# ").append("【").append(projectName).append("】").append(ConfigUtil.getDingTalkInfo()).append("：# \n")
                .append("## 当前待审核汇总信息：## \n")
                .append(authorMerge.getCanMergeList().getMergeInfo())
                .append("\n")
                .append("## 当前冲突无法合并信息，待处理冲突：## \n")
                .append(authorMerge.getNonMergeList().getMergeInfo());

        return content.toString();
    }

}
