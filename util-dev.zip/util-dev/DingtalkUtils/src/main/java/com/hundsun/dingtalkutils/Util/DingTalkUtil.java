package com.hundsun.dingtalkutils.Util;

import com.dingtalk.api.DefaultDingTalkClient;
import com.dingtalk.api.DingTalkClient;
import com.dingtalk.api.request.OapiRobotSendRequest;
import com.taobao.api.ApiException;

/**
 * @ClassName DingTalkUser
 * @Description TODO
 * @Author hengxx25187
 * @Date 2023/6/15 20:19
 */
public class DingTalkUtil {

    private String ACCESS_TOKEN;

    private String SERVICE_URL;

    private DingTalkClient client = null;

    private OapiRobotSendRequest req = new OapiRobotSendRequest();

    /**
     * Description: 构造函数
     * @param token
     * @param url
     * @return
     * @author hengxx25187
     * @date 2023/6/15 20:36
     */
    public DingTalkUtil(String token, String url) {
        this.ACCESS_TOKEN = token;
        this.SERVICE_URL = url;
    }

    public DingTalkUtil() {
        this.ACCESS_TOKEN = ConfigUtil.getDingtalkToken();
        this.SERVICE_URL = ConfigUtil.getDingtalkUrl();
    }

    /**
     * Description: 实例化钉钉消息发送
     * @param
     * @return void
     * @author hengxx25187
     * @date 2023/6/15 20:34
     */
    public void instance() {
        DingTalkClient client =  new DefaultDingTalkClient(SERVICE_URL);
        this.client = client;
    }

    /**
     * Description: 设置发送钉钉消息的具体内容
     * @param req
     * @return void
     * @author hengxx25187
     * @date 2023/6/15 20:35
     */
    public void setRequest(OapiRobotSendRequest req) {
        this.req = req;
    }

    /**
     * Description: 发送钉钉消息
     * @param
     * @return java.lang.String
     * @author hengxx25187
     * @date 2023/6/15 20:33
     */
    public String excute() {
        String result;
        try {
            result = this.client.execute(req, ACCESS_TOKEN).getBody();
        } catch (ApiException e) {
            return null;
        }
        return result;
    }
}
