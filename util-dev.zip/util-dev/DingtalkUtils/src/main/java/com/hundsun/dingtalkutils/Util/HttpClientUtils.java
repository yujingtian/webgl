package com.hundsun.dingtalkutils.Util;

import com.alibaba.fastjson.JSONObject;
import org.apache.http.HttpEntity;
import org.apache.http.HttpStatus;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.io.IOException;
import java.util.Objects;

import static com.hundsun.dingtalkutils.Util.ConfigUtil.getHttpPrivateToken;

/**
 * @ClassName HttpClientUtils
 * @Description http请求工具类
 * @Author hengxx25187
 * @Date 2023/6/20 19:40
 */
public class HttpClientUtils {

    public static String get(String url, JSONObject params) {
        CloseableHttpClient httpClient = HttpClientBuilder.create().build();
        if (Objects.isNull(params) || params.size() <= 0) {
            return null;
        }
        String sendUrl = createHttpParams(url, params);
        HttpGet httpGet = new HttpGet(sendUrl);
        // 设置密钥
        httpGet.setHeader("PRIVATE-TOKEN", getHttpPrivateToken());
        CloseableHttpResponse response = null;
        try {
            response = httpClient.execute(httpGet);
            HttpEntity httpEntity = response.getEntity();
            if (HttpStatus.SC_OK == response.getStatusLine().getStatusCode() && null != httpEntity) {
                return EntityUtils.toString(httpEntity);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                close(httpClient, response);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    private static String createHttpParams(String url, JSONObject params) {
        StringBuffer buffer = new StringBuffer();
        buffer.append(url).append("?");
        params.forEach((x, y) -> buffer.append(x).append("=").append(y).append("&"));
        buffer.deleteCharAt(buffer.length() -1 );
        return buffer.toString();
    }

    private static void close(CloseableHttpClient httpClient, CloseableHttpResponse response) throws IOException {
        if (null != httpClient) {
            httpClient.close();
        }
        if (null != response) {
            response.close();
        }
    }
}
